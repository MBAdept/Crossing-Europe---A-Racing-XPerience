# PacketPeer :: <Native> class PacketPeer extends RefCounted
Abstraction and base class for packet-based protocols.
PacketPeer is an abstraction and base class for packet-based protocols (such as UDP). It provides an API for sending and receiving packets both as raw data or variables. This makes it easy to transfer data over a protocol, without having to encode data as low-level bytes or having to worry about network ordering.
[b]Note:[/b] When exporting to Android, make sure to enable the [code]INTERNET[/code] permission in the Android export preset before exporting the project or using one-click deploy. Otherwise, network communication of any kind will be blocked by Android.

## encode_buffer_max_size :: var PacketPeer.encode_buffer_max_size: int
Maximum buffer size allowed when encoding [Variant]s. Raise this value to support heavier memory allocations.
The [method put_var] method allocates memory on the stack, and the buffer used will grow automatically to the closest power of two to match the size of the [Variant]. If the [Variant] is bigger than [member encode_buffer_max_size], the method will error out with [constant ERR_OUT_OF_MEMORY].

## get_available_packet_count :: func PacketPeer.get_available_packet_count() -> int
Returns the number of packets currently available in the ring-buffer.

## get_packet :: func PacketPeer.get_packet() -> PackedByteArray
Gets a raw packet.

## get_packet_error :: func PacketPeer.get_packet_error() -> int
Returns the error state of the last packet received (via [method get_packet] and [method get_var]).

## get_var :: func PacketPeer.get_var(allow_objects: bool = false) -> Variant
Gets a Variant. If [param allow_objects] is [code]true[/code], decoding objects is allowed.
Internally, this uses the same decoding mechanism as the [method @GlobalScope.bytes_to_var] method.
[b]Warning:[/b] Deserialized objects can contain code which gets executed. Do not use this option if the serialized object comes from untrusted sources to avoid potential security threats such as remote code execution.

### allow_objects :: bool

## put_packet :: func PacketPeer.put_packet(buffer: PackedByteArray) -> int
Sends a raw packet.

### buffer :: PackedByteArray

## put_var :: func PacketPeer.put_var(var: Variant, full_objects: bool = false) -> int
Sends a [Variant] as a packet. If [param full_objects] is [code]true[/code], encoding objects is allowed (and can potentially include code).
Internally, this uses the same encoding mechanism as the [method @GlobalScope.var_to_bytes] method.

### var :: Variant

### full_objects :: bool
