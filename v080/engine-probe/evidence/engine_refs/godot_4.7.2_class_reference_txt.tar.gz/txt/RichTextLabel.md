# RichTextLabel :: <Native> class RichTextLabel extends Control
A control for displaying text that can contain different font styles, images, and basic formatting.
A control for displaying text that can contain custom fonts, images, and basic formatting. [RichTextLabel] manages these as an internal tag stack. It also adapts itself to given width/heights.
[b]Note:[/b] [method newline], [method push_paragraph], [code]"\n"[/code], [code]"\r\n"[/code], [code]p[/code] tag, and alignment tags start a new paragraph. Each paragraph is processed independently, in its own BiDi context. If you want to force line wrapping within paragraph, any other line breaking character can be used, for example, Form Feed (U+000C), Next Line (U+0085), Line Separator (U+2028).
[b]Note:[/b] Assignments to [member text] clear the tag stack and reconstruct it from the property's contents. Any edits made to [member text] will erase previous edits made from other manual sources such as [method append_text] and the [code]push_*[/code] / [method pop] methods.
[b]Note:[/b] RichTextLabel doesn't support entangled BBCode tags. For example, instead of using [code skip-lint][b]bold[i]bold italic[/b]italic[/i][/code], use [code skip-lint][b]bold[i]bold italic[/i][/b][i]italic[/i][/code].
[b]Note:[/b] [code]push_*/pop_*[/code] functions won't affect BBCode.
[b]Note:[/b] While [member bbcode_enabled] is enabled, alignment tags such as [code skip-lint][center][/code] will take priority over the [member horizontal_alignment] setting which determines the default text alignment.

## LIST_NUMBERS :: const RichTextLabel.LIST_NUMBERS: ListType = 0
Each list item has a number marker.

## LIST_LETTERS :: const RichTextLabel.LIST_LETTERS: ListType = 1
Each list item has a letter marker.

## LIST_ROMAN :: const RichTextLabel.LIST_ROMAN: ListType = 2
Each list item has a roman number marker.

## LIST_DOTS :: const RichTextLabel.LIST_DOTS: ListType = 3
Each list item has a filled circle marker.

## MENU_COPY :: const RichTextLabel.MENU_COPY: MenuItems = 0
Copies the selected text.

## MENU_SELECT_ALL :: const RichTextLabel.MENU_SELECT_ALL: MenuItems = 1
Selects the whole [RichTextLabel] text.

## MENU_MAX :: const RichTextLabel.MENU_MAX: MenuItems = 2
Represents the size of the [enum MenuItems] enum.

## META_UNDERLINE_NEVER :: const RichTextLabel.META_UNDERLINE_NEVER: MetaUnderline = 0
Meta tag does not display an underline, even if [member meta_underlined] is [code]true[/code].

## META_UNDERLINE_ALWAYS :: const RichTextLabel.META_UNDERLINE_ALWAYS: MetaUnderline = 1
If [member meta_underlined] is [code]true[/code], meta tag always display an underline.

## META_UNDERLINE_ON_HOVER :: const RichTextLabel.META_UNDERLINE_ON_HOVER: MetaUnderline = 2
If [member meta_underlined] is [code]true[/code], meta tag display an underline when the mouse cursor is over it.

## UPDATE_TEXTURE :: const RichTextLabel.UPDATE_TEXTURE: ImageUpdateMask = 1
If this bit is set, [method update_image] changes image texture.

## UPDATE_SIZE :: const RichTextLabel.UPDATE_SIZE: ImageUpdateMask = 2
If this bit is set, [method update_image] changes image size.

## UPDATE_COLOR :: const RichTextLabel.UPDATE_COLOR: ImageUpdateMask = 4
If this bit is set, [method update_image] changes image color.

## UPDATE_ALIGNMENT :: const RichTextLabel.UPDATE_ALIGNMENT: ImageUpdateMask = 8
If this bit is set, [method update_image] changes image inline alignment.

## UPDATE_REGION :: const RichTextLabel.UPDATE_REGION: ImageUpdateMask = 16
If this bit is set, [method update_image] changes image texture region.

## UPDATE_PAD :: const RichTextLabel.UPDATE_PAD: ImageUpdateMask = 32
If this bit is set, [method update_image] changes image padding.

## UPDATE_TOOLTIP :: const RichTextLabel.UPDATE_TOOLTIP: ImageUpdateMask = 64
If this bit is set, [method update_image] changes image tooltip.

## UPDATE_WIDTH_UNIT :: const RichTextLabel.UPDATE_WIDTH_UNIT: ImageUpdateMask = 128
If this bit is set, [method update_image] changes the units used to calculate image size.

## IMAGE_UNIT_PIXEL :: const RichTextLabel.IMAGE_UNIT_PIXEL: ImageUnit = 0
Images drawn with this unit will be in pixels.

## IMAGE_UNIT_PERCENT :: const RichTextLabel.IMAGE_UNIT_PERCENT: ImageUnit = 1
Images drawn with this unit will be in percentages of the control width.

## IMAGE_UNIT_EM :: const RichTextLabel.IMAGE_UNIT_EM: ImageUnit = 2
Images drawn with this unit will be in percentages of the surrounding font size.

## autowrap_mode :: var RichTextLabel.autowrap_mode: TextServer.AutowrapMode
If set to something other than [constant TextServer.AUTOWRAP_OFF], the text gets wrapped inside the node's bounding rectangle.
[b]Note:[/b] RichTextLabels with autowrapping and [member fit_content] enabled must have a custom maximum width configured to work correctly, either through the RichTextLabel's own [member Control.custom_maximum_size] or as a result of a propagated maximum size from a parent Control with [member Control.propagate_maximum_size] enabled.

## autowrap_trim_flags :: var RichTextLabel.autowrap_trim_flags: TextServer.LineBreakFlag
Autowrap space trimming flags. See [constant TextServer.BREAK_TRIM_START_EDGE_SPACES] and [constant TextServer.BREAK_TRIM_END_EDGE_SPACES] for more info.

## bbcode_enabled :: var RichTextLabel.bbcode_enabled: bool
If [code]true[/code], the label uses BBCode formatting.
[b]Note:[/b] This only affects the contents of [member text], not the tag stack.

## clip_contents :: var RichTextLabel.clip_contents: bool

## context_menu_enabled :: var RichTextLabel.context_menu_enabled: bool
If [code]true[/code], a right-click displays the context menu.

## custom_effects :: var RichTextLabel.custom_effects: Array
The currently installed custom effects. This is an array of [RichTextEffect]s.
To add a custom effect, it's more convenient to use [method install_effect].

## deselect_on_focus_loss_enabled :: var RichTextLabel.deselect_on_focus_loss_enabled: bool
If [code]true[/code], the selected text will be deselected when focus is lost.

## drag_and_drop_selection_enabled :: var RichTextLabel.drag_and_drop_selection_enabled: bool
If [code]true[/code], allow drag and drop of selected text.

## fit_content :: var RichTextLabel.fit_content: bool
If [code]true[/code], the label's minimum size will be automatically updated to fit its content, matching the behavior of [Label].
[b]Note:[/b] RichTextLabels with autowrapping and [member fit_content] enabled must have a custom maximum width configured to work correctly, either through the RichTextLabel's own [member Control.custom_maximum_size] or as a result of a propagated maximum size from a parent Control with [member Control.propagate_maximum_size] enabled.

## focus_mode :: var RichTextLabel.focus_mode: Control.FocusMode

## hint_underlined :: var RichTextLabel.hint_underlined: bool
If [code]true[/code], the label underlines hint tags such as [code skip-lint][hint=description]{text}[/hint][/code].

## horizontal_alignment :: var RichTextLabel.horizontal_alignment: HorizontalAlignment
Controls the text's horizontal alignment. Supports left, center, right, and fill (also known as justify).

## justification_flags :: var RichTextLabel.justification_flags: TextServer.JustificationFlag
Line fill alignment rules.

## language :: var RichTextLabel.language: String
Language code used for line-breaking and text shaping algorithms. If left empty, the current locale is used instead.

## meta_underlined :: var RichTextLabel.meta_underlined: bool
If [code]true[/code], the label underlines meta tags such as [code skip-lint][url]{text}[/url][/code]. These tags can call a function when clicked if [signal meta_clicked] is connected to a function.

## progress_bar_delay :: var RichTextLabel.progress_bar_delay: int
The delay after which the loading progress bar is displayed, in milliseconds. Set to [code]-1[/code] to disable progress bar entirely.
[b]Note:[/b] Progress bar is displayed only if [member threaded] is enabled.

## scroll_active :: var RichTextLabel.scroll_active: bool
If [code]true[/code], the scrollbar is visible. Setting this to [code]false[/code] does not block scrolling completely. See [method scroll_to_line].

## scroll_following :: var RichTextLabel.scroll_following: bool
If [code]true[/code], the window scrolls down to display new content automatically.

## scroll_following_visible_characters :: var RichTextLabel.scroll_following_visible_characters: bool
If [code]true[/code], the window scrolls to display the last visible line when [member visible_characters] or [member visible_ratio] is changed.

## selection_enabled :: var RichTextLabel.selection_enabled: bool
If [code]true[/code], the label allows text selection.

## shortcut_keys_enabled :: var RichTextLabel.shortcut_keys_enabled: bool
If [code]true[/code], shortcut keys for context menu items are enabled, even if the context menu is disabled.

## structured_text_bidi_override :: var RichTextLabel.structured_text_bidi_override: TextServer.StructuredTextParser
Set BiDi algorithm override for the structured text.

## structured_text_bidi_override_options :: var RichTextLabel.structured_text_bidi_override_options: Array
Set additional options for BiDi override.

## tab_size :: var RichTextLabel.tab_size: int
The number of spaces associated with a single tab length. Does not affect [code]\t[/code] in text tags, only indent tags.

## tab_stops :: var RichTextLabel.tab_stops: PackedFloat32Array
Aligns text to the given tab-stops.

## text :: var RichTextLabel.text: String
The label's text in BBCode format. Is not representative of manual modifications to the internal tag stack. Erases changes made by other methods when edited.
[b]Note:[/b] If [member bbcode_enabled] is [code]true[/code], it is unadvised to use the [code]+=[/code] operator with [member text] (e.g. [code]text += "some string"[/code]) as it replaces the whole text and can cause slowdowns. It will also erase all BBCode that was added to stack using [code]push_*[/code] methods. Use [method append_text] for adding text instead, unless you absolutely need to close a tag that was opened in an earlier method call.

## text_direction :: var RichTextLabel.text_direction: Control.TextDirection
Base text writing direction.

## threaded :: var RichTextLabel.threaded: bool
If [code]true[/code], text processing is done in a background thread.

## vertical_alignment :: var RichTextLabel.vertical_alignment: VerticalAlignment
Controls the text's vertical alignment. Supports top, center, bottom, and fill.

## visible_characters :: var RichTextLabel.visible_characters: int
The number of characters to display. If set to [code]-1[/code], all characters are displayed. This can be useful when animating the text appearing in a dialog box.
[b]Note:[/b] Setting this property updates [member visible_ratio] accordingly.
[b]Note:[/b] Characters are counted as Unicode codepoints. A single visible grapheme may contain multiple codepoints (e.g. certain emoji use three codepoints). A single codepoint may contain two UTF-16 characters, which are used in C# strings.

## visible_characters_behavior :: var RichTextLabel.visible_characters_behavior: TextServer.VisibleCharactersBehavior
The clipping behavior when [member visible_characters] or [member visible_ratio] is set.

## visible_ratio :: var RichTextLabel.visible_ratio: float
The fraction of characters to display, relative to the total number of characters (see [method get_total_character_count]). If set to [code]1.0[/code], all characters are displayed. If set to [code]0.5[/code], only half of the characters will be displayed. This can be useful when animating the text appearing in a dialog box.
[b]Note:[/b] Setting this property updates [member visible_characters] accordingly.

## default_color :: <Theme> var RichTextLabel.default_color: Color
The default text color.

## font_outline_color :: <Theme> var RichTextLabel.font_outline_color: Color
The default tint of text outline.

## font_selected_color :: <Theme> var RichTextLabel.font_selected_color: Color
The color of selected text, used when [member selection_enabled] is [code]true[/code]. If equal to [code]Color(0, 0, 0, 0)[/code], it will be ignored.

## font_shadow_color :: <Theme> var RichTextLabel.font_shadow_color: Color
The color of the font's shadow.

## selection_color :: <Theme> var RichTextLabel.selection_color: Color
The color of the selection box.

## table_border :: <Theme> var RichTextLabel.table_border: Color
The default cell border color.

## table_even_row_bg :: <Theme> var RichTextLabel.table_even_row_bg: Color
The default background color for even rows.

## table_odd_row_bg :: <Theme> var RichTextLabel.table_odd_row_bg: Color
The default background color for odd rows.

## line_separation :: <Theme> var RichTextLabel.line_separation: int
Additional vertical spacing between lines (in pixels), spacing is added to line descent. This value can be negative.

## outline_size :: <Theme> var RichTextLabel.outline_size: int
The size of the text outline.
[b]Note:[/b] If using a font with [member FontFile.multichannel_signed_distance_field] enabled, its [member FontFile.msdf_pixel_range] must be set to at least [i]twice[/i] the value of [theme_item outline_size] for outline rendering to look correct. Otherwise, the outline may appear to be cut off earlier than intended.

## paragraph_separation :: <Theme> var RichTextLabel.paragraph_separation: int
Additional vertical spacing between paragraphs (in pixels). Spacing is added after the last line. This value can be negative.

## shadow_offset_x :: <Theme> var RichTextLabel.shadow_offset_x: int
The horizontal offset of the font's shadow.

## shadow_offset_y :: <Theme> var RichTextLabel.shadow_offset_y: int
The vertical offset of the font's shadow.

## shadow_outline_size :: <Theme> var RichTextLabel.shadow_outline_size: int
The size of the shadow outline.

## strikethrough_alpha :: <Theme> var RichTextLabel.strikethrough_alpha: int
The default strikethrough color transparency (percent). For strikethroughs with a custom color, this theme item is only used if the custom color's alpha is [code]0.0[/code] (fully transparent).

## table_h_separation :: <Theme> var RichTextLabel.table_h_separation: int
The horizontal separation of elements in a table.

## table_v_separation :: <Theme> var RichTextLabel.table_v_separation: int
The vertical separation of elements in a table.

## text_highlight_h_padding :: <Theme> var RichTextLabel.text_highlight_h_padding: int
The horizontal padding around boxes drawn by the [code][fgcolor][/code] and [code][bgcolor][/code] tags. This does not affect the appearance of text selection. To avoid any risk of neighboring highlights overlapping each other, set this to [code]0[/code] to disable padding.

## text_highlight_v_padding :: <Theme> var RichTextLabel.text_highlight_v_padding: int
The vertical padding around boxes drawn by the [code][fgcolor][/code] and [code][bgcolor][/code] tags. This does not affect the appearance of text selection. To avoid any risk of neighboring highlights overlapping each other, set this to [code]0[/code] to disable padding.

## underline_alpha :: <Theme> var RichTextLabel.underline_alpha: int
The default underline color transparency (percent). For underlines with a custom color, this theme item is only used if the custom color's alpha is [code]0.0[/code] (fully transparent).

## bold_font :: <Theme> var RichTextLabel.bold_font: Font
The font used for bold text.

## bold_italics_font :: <Theme> var RichTextLabel.bold_italics_font: Font
The font used for bold italics text.

## italics_font :: <Theme> var RichTextLabel.italics_font: Font
The font used for italics text.

## mono_font :: <Theme> var RichTextLabel.mono_font: Font
The font used for monospace text.

## normal_font :: <Theme> var RichTextLabel.normal_font: Font
The default text font.

## bold_font_size :: <Theme> var RichTextLabel.bold_font_size: int
The font size used for bold text.

## bold_italics_font_size :: <Theme> var RichTextLabel.bold_italics_font_size: int
The font size used for bold italics text.

## italics_font_size :: <Theme> var RichTextLabel.italics_font_size: int
The font size used for italics text.

## mono_font_size :: <Theme> var RichTextLabel.mono_font_size: int
The font size used for monospace text.

## normal_font_size :: <Theme> var RichTextLabel.normal_font_size: int
The default text font size.

## horizontal_rule :: <Theme> var RichTextLabel.horizontal_rule: Texture2D
The horizontal rule texture.

## focus :: <Theme> var RichTextLabel.focus: StyleBox
The background used when the [RichTextLabel] is focused. The [theme_item focus] [StyleBox] is displayed [i]over[/i] the base [StyleBox], so a partially transparent [StyleBox] should be used to ensure the base [StyleBox] remains visible. A [StyleBox] that represents an outline or an underline works well for this purpose. To disable the focus visual effect, assign a [StyleBoxEmpty] resource. Note that disabling the focus visual effect will harm keyboard/controller navigation usability, so this is not recommended for accessibility reasons.

## normal :: <Theme> var RichTextLabel.normal: StyleBox
The normal background for the [RichTextLabel].

## add_hr :: func RichTextLabel.add_hr(width: int = 90, height: int = 2, color: Color = Color(1, 1, 1, 1), alignment: int = 1, width_in_percent: bool = true, height_in_percent: bool = false) -> void
Adds a horizontal rule that can be used to separate content.
If [param width_in_percent] is set, [param width] values are percentages of the control width instead of pixels.
If [param height_in_percent] is set, [param height] values are percentages of the control width instead of pixels.

### width :: int

### height :: int

### color :: Color

### alignment :: int

### width_in_percent :: bool

### height_in_percent :: bool

## add_image :: func RichTextLabel.add_image(image: Texture2D, width: float = 0, height: float = 0, color: Color = Color(1, 1, 1, 1), inline_align: int = 5, region: Rect2 = Rect2(0, 0, 0, 0), key: Variant = null, pad: bool = false, tooltip: String = "", width_unit: int = 0, height_unit: int = 0, alt_text: String = "") -> void
Adds an image's opening and closing tags to the tag stack, optionally providing a [param width] and [param height] to resize the image, a [param color] to tint the image and a [param region] to only use parts of the image.
If [param width] or [param height] is set to 0, the image size will be adjusted in order to keep the original aspect ratio.
If [param width] and [param height] are not set, but [param region] is, the region's rect will be used.
[param key] is an optional identifier, that can be used to modify the image via [method update_image].
If [param pad] is set, and the image is smaller than the size specified by [param width] and [param height], the image padding is added to match the size instead of upscaling.
Parameters [param width_unit] and [param height_unit] determine the units used to calculate the image width and height, respectively.
[param alt_text] is used as the image description for assistive apps.

### image :: Texture2D

### width :: float

### height :: float

### color :: Color

### inline_align :: int

### region :: Rect2

### key :: Variant

### pad :: bool

### tooltip :: String

### width_unit :: int

### height_unit :: int

### alt_text :: String

## add_text :: func RichTextLabel.add_text(text: String) -> void
Adds raw non-BBCode-parsed text to the tag stack.

### text :: String

## append_text :: func RichTextLabel.append_text(bbcode: String) -> void
Parses [param bbcode] and adds tags to the tag stack as needed.
[b]Note:[/b] Using this method, you can't close a tag that was opened in a previous [method append_text] call. This is done to improve performance, especially when updating large RichTextLabels since rebuilding the whole BBCode every time would be slower. If you absolutely need to close a tag in a future method call, append the [member text] instead of using [method append_text].

### bbcode :: String

## clear :: func RichTextLabel.clear() -> void
Clears the tag stack, causing the label to display nothing.
[b]Note:[/b] This method does not affect [member text], and its contents will show again if the label is redrawn. However, setting [member text] to an empty [String] also clears the stack.

## deselect :: func RichTextLabel.deselect() -> void
Clears the current selection.

## get_character_line :: func RichTextLabel.get_character_line(character: int) -> int
Returns the line number of the character position provided. Line and character numbers are both zero-indexed.
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether document is fully loaded.

### character :: int

## get_character_paragraph :: func RichTextLabel.get_character_paragraph(character: int) -> int
Returns the paragraph number of the character position provided. Paragraph and character numbers are both zero-indexed.
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether document is fully loaded.

### character :: int

## get_content_height :: func RichTextLabel.get_content_height() -> int
Returns the height of the content.
[b]Note:[/b] This method always returns the full content size, and is not affected by [member visible_ratio] and [member visible_characters]. To get the visible content size, use [method get_visible_content_rect].
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether document is fully loaded.

## get_content_width :: func RichTextLabel.get_content_width() -> int
Returns the width of the content.
[b]Note:[/b] This method always returns the full content size, and is not affected by [member visible_ratio] and [member visible_characters]. To get the visible content size, use [method get_visible_content_rect].
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether document is fully loaded.

## get_line_count :: func RichTextLabel.get_line_count() -> int
Returns the total number of lines in the text. Wrapped text is counted as multiple lines.
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether document is fully loaded.

## get_line_height :: func RichTextLabel.get_line_height(line: int) -> int
Returns the height of the line found at the provided index.
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether the document is fully loaded.

### line :: int

## get_line_offset :: func RichTextLabel.get_line_offset(line: int) -> float
Returns the vertical offset of the line found at the provided index.
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether document is fully loaded.

### line :: int

## get_line_range :: func RichTextLabel.get_line_range(line: int) -> Vector2i
Returns the indexes of the first and last visible characters for the given [param line], as a [Vector2i].
[b]Note:[/b] If [member visible_characters_behavior] is set to [constant TextServer.VC_CHARS_BEFORE_SHAPING] only visible wrapped lines are counted.
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether document is fully loaded.

### line :: int

## get_line_width :: func RichTextLabel.get_line_width(line: int) -> int
Returns the width of the line found at the provided index.
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether the document is fully loaded.

### line :: int

## get_menu :: func RichTextLabel.get_menu() -> PopupMenu
Returns the [PopupMenu] of this [RichTextLabel]. By default, this menu is displayed when right-clicking on the [RichTextLabel].
You can add custom menu items or remove standard ones. Make sure your IDs don't conflict with the standard ones (see [enum MenuItems]). For example:
[codeblocks]
[gdscript]
func _ready():
	var menu = get_menu()
	# Remove "Select All" item.
	menu.remove_item(MENU_SELECT_ALL)
	# Add custom items.
	menu.add_separator()
	menu.add_item("Duplicate Text", MENU_MAX + 1)
	# Connect callback.
	menu.id_pressed.connect(_on_item_pressed)

func _on_item_pressed(id):
	if id == MENU_MAX + 1:
		add_text("\n" + get_parsed_text())
[/gdscript]
[csharp]
public override void _Ready()
{
	var menu = GetMenu();
	// Remove "Select All" item.
	menu.RemoveItem(RichTextLabel.MenuItems.SelectAll);
	// Add custom items.
	menu.AddSeparator();
	menu.AddItem("Duplicate Text", RichTextLabel.MenuItems.Max + 1);
	// Add event handler.
	menu.IdPressed += OnItemPressed;
}

public void OnItemPressed(int id)
{
	if (id == TextEdit.MenuItems.Max + 1)
	{
		AddText("\n" + GetParsedText());
	}
}
[/csharp]
[/codeblocks]
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member Window.visible] property.

## get_paragraph_count :: func RichTextLabel.get_paragraph_count() -> int
Returns the total number of paragraphs (newlines or [code]p[/code] tags in the tag stack's text tags). Considers wrapped text as one paragraph.

## get_paragraph_offset :: func RichTextLabel.get_paragraph_offset(paragraph: int) -> float
Returns the vertical offset of the paragraph found at the provided index.
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether document is fully loaded.

### paragraph :: int

## get_parsed_text :: func RichTextLabel.get_parsed_text() -> String
Returns the text without BBCode mark-up.

## get_selected_text :: func RichTextLabel.get_selected_text() -> String
Returns the current selection text. Does not include BBCodes.

## get_selection_from :: func RichTextLabel.get_selection_from() -> int
Returns the current selection first character index if a selection is active, [code]-1[/code] otherwise. Does not include BBCodes.

## get_selection_line_offset :: func RichTextLabel.get_selection_line_offset() -> float
Returns the current selection vertical line offset if a selection is active, [code]-1.0[/code] otherwise.

## get_selection_to :: func RichTextLabel.get_selection_to() -> int
Returns the current selection last character index if a selection is active, [code]-1[/code] otherwise. Does not include BBCodes.

## get_total_character_count :: func RichTextLabel.get_total_character_count() -> int
Returns the total number of characters from text tags. Does not include BBCodes.

## get_v_scroll_bar :: func RichTextLabel.get_v_scroll_bar() -> VScrollBar
Returns the vertical scrollbar.
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member CanvasItem.visible] property.

## get_visible_content_rect :: func RichTextLabel.get_visible_content_rect() -> Rect2i
Returns the bounding rectangle of the visible content.
[b]Note:[/b] This method returns a correct value only after the label has been drawn.
[codeblocks]
[gdscript]
extends RichTextLabel

@export var background_panel: Panel

func _ready():
	await draw
	background_panel.position = get_visible_content_rect().position
	background_panel.size = get_visible_content_rect().size
[/gdscript]
[csharp]
public partial class TestLabel : RichTextLabel
{
	[Export]
	public Panel BackgroundPanel { get; set; }

	public override async void _Ready()
	{
		await ToSignal(this, Control.SignalName.Draw);
		BackgroundGPanel.Position = GetVisibleContentRect().Position;
		BackgroundPanel.Size = GetVisibleContentRect().Size;
	}
}
[/csharp]
[/codeblocks]

## get_visible_line_count :: func RichTextLabel.get_visible_line_count() -> int
Returns the number of visible lines.
[b]Note:[/b] This method returns a correct value only after the label has been drawn.
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether document is fully loaded.

## get_visible_paragraph_count :: func RichTextLabel.get_visible_paragraph_count() -> int
Returns the number of visible paragraphs. A paragraph is considered visible if at least one of its lines is visible.
[b]Note:[/b] This method returns a correct value only after the label has been drawn.
[b]Note:[/b] If [member threaded] is enabled, this method returns a value for the loaded part of the document. Use [method is_finished] or [signal finished] to determine whether document is fully loaded.

## install_effect :: func RichTextLabel.install_effect(effect: Variant) -> void
Installs a custom effect. This can also be done in the Inspector through the [member custom_effects] property. [param effect] should be a valid [RichTextEffect].
[b]Example:[/b] With the following script extending from [RichTextEffect]:
[codeblock]
# effect.gd
class_name MyCustomEffect
extends RichTextEffect

var bbcode = "my_custom_effect"

# ...
[/codeblock]
The above effect can be installed in [RichTextLabel] from a script:
[codeblock]
# rich_text_label.gd
extends RichTextLabel

func _ready():
	install_effect(MyCustomEffect.new())

	# Alternatively, if not using `class_name` in the script that extends RichTextEffect:
	install_effect(preload("res://effect.gd").new())
[/codeblock]

### effect :: Variant

## invalidate_paragraph :: func RichTextLabel.invalidate_paragraph(paragraph: int) -> bool
Invalidates [param paragraph] and all subsequent paragraphs cache.

### paragraph :: int

## is_finished :: func RichTextLabel.is_finished() -> bool
If [member threaded] is enabled, returns [code]true[/code] if the background thread has finished text processing, otherwise always return [code]true[/code].

## is_menu_visible :: func RichTextLabel.is_menu_visible() -> bool
Returns whether the menu is visible. Use this instead of [code]get_menu().visible[/code] to improve performance (so the creation of the menu is avoided).

## is_ready :: func RichTextLabel.is_ready() -> bool
If [member threaded] is enabled, returns [code]true[/code] if the background thread has finished text processing, otherwise always return [code]true[/code].

## menu_option :: func RichTextLabel.menu_option(option: int) -> void
Executes a given action as defined in the [enum MenuItems] enum.

### option :: int

## newline :: func RichTextLabel.newline() -> void
Adds a newline tag to the tag stack.

## parse_bbcode :: func RichTextLabel.parse_bbcode(bbcode: String) -> void
The assignment version of [method append_text]. Clears the tag stack and inserts the new content.

### bbcode :: String

## parse_expressions_for_values :: func RichTextLabel.parse_expressions_for_values(expressions: PackedStringArray) -> Dictionary
Parses BBCode parameter [param expressions] into a dictionary.

### expressions :: PackedStringArray

## pop :: func RichTextLabel.pop() -> void
Terminates the current tag. Use after [code]push_*[/code] methods to close BBCodes manually. Does not need to follow [code]add_*[/code] methods.

## pop_all :: func RichTextLabel.pop_all() -> void
Terminates all tags opened by [code]push_*[/code] methods.

## pop_context :: func RichTextLabel.pop_context() -> void
Terminates tags opened after the last [method push_context] call (including context marker), or all tags if there's no context marker on the stack.

## push_bgcolor :: func RichTextLabel.push_bgcolor(bgcolor: Color) -> void
Adds a [code skip-lint][bgcolor][/code] tag to the tag stack.
[b]Note:[/b] The background color has padding applied by default, which is controlled using [theme_item text_highlight_h_padding] and [theme_item text_highlight_v_padding]. This can lead to overlapping highlights if background colors are placed on neighboring lines/columns, so consider setting those theme items to [code]0[/code] if you want to avoid this.

### bgcolor :: Color

## push_bold :: func RichTextLabel.push_bold() -> void
Adds a [code skip-lint][font][/code] tag with a bold font to the tag stack. This is the same as adding a [code skip-lint][b][/code] tag if not currently in a [code skip-lint][i][/code] tag.

## push_bold_italics :: func RichTextLabel.push_bold_italics() -> void
Adds a [code skip-lint][font][/code] tag with a bold italics font to the tag stack.

## push_cell :: func RichTextLabel.push_cell() -> void
Adds a [code skip-lint][cell][/code] tag to the tag stack. Must be inside a [code skip-lint][table][/code] tag. See [method push_table] for details. Use [method set_table_column_expand] to set column expansion ratio, [method set_cell_border_color] to set cell border, [method set_cell_row_background_color] to set cell background, [method set_cell_size_override] to override cell size, and [method set_cell_padding] to set padding.

## push_color :: func RichTextLabel.push_color(color: Color) -> void
Adds a [code skip-lint][color][/code] tag to the tag stack.

### color :: Color

## push_context :: func RichTextLabel.push_context() -> void
Adds a context marker to the tag stack. See [method pop_context].

## push_customfx :: func RichTextLabel.push_customfx(effect: RichTextEffect, env: Dictionary) -> void
Adds a custom effect tag to the tag stack. The effect does not need to be in [member custom_effects]. The environment is directly passed to the effect.

### effect :: RichTextEffect

### env :: Dictionary

## push_dropcap :: func RichTextLabel.push_dropcap(string: String, font: Font, size: int, dropcap_margins: Rect2 = Rect2(0, 0, 0, 0), color: Color = Color(1, 1, 1, 1), outline_size: int = 0, outline_color: Color = Color(0, 0, 0, 0)) -> void
Adds a [code skip-lint][dropcap][/code] tag to the tag stack. Drop cap (dropped capital) is a decorative element at the beginning of a paragraph that is larger than the rest of the text.

### string :: String

### font :: Font

### size :: int

### dropcap_margins :: Rect2

### color :: Color

### outline_size :: int

### outline_color :: Color

## push_fgcolor :: func RichTextLabel.push_fgcolor(fgcolor: Color) -> void
Adds a [code skip-lint][fgcolor][/code] tag to the tag stack.
[b]Note:[/b] The foreground color has padding applied by default, which is controlled using [theme_item text_highlight_h_padding] and [theme_item text_highlight_v_padding]. This can lead to overlapping highlights if foreground colors are placed on neighboring lines/columns, so consider setting those theme items to [code]0[/code] if you want to avoid this.

### fgcolor :: Color

## push_font :: func RichTextLabel.push_font(font: Font, font_size: int = 0) -> void
Adds a [code skip-lint][font][/code] tag to the tag stack. Overrides default fonts for its duration.
Passing [code]0[/code] to [param font_size] will use the existing default font size.

### font :: Font

### font_size :: int

## push_font_size :: func RichTextLabel.push_font_size(font_size: int) -> void
Adds a [code skip-lint][font_size][/code] tag to the tag stack. Overrides default font size for its duration.

### font_size :: int

## push_hint :: func RichTextLabel.push_hint(description: String) -> void
Adds a [code skip-lint][hint][/code] tag to the tag stack. Same as BBCode [code skip-lint][hint=something]{text}[/hint][/code].

### description :: String

## push_indent :: func RichTextLabel.push_indent(level: int) -> void
Adds an [code skip-lint][indent][/code] tag to the tag stack. Multiplies [param level] by current [member tab_size] to determine new margin length.

### level :: int

## push_italics :: func RichTextLabel.push_italics() -> void
Adds a [code skip-lint][font][/code] tag with an italics font to the tag stack. This is the same as adding an [code skip-lint][i][/code] tag if not currently in a [code skip-lint][b][/code] tag.

## push_language :: func RichTextLabel.push_language(language: String) -> void
Adds language code used for text shaping algorithm and Open-Type font features.

### language :: String

## push_list :: func RichTextLabel.push_list(level: int, type: int, capitalize: bool, bullet: String = "•") -> void
Adds [code skip-lint][ol][/code] or [code skip-lint][ul][/code] tag to the tag stack. Multiplies [param level] by current [member tab_size] to determine new margin length.

### level :: int

### type :: int

### capitalize :: bool

### bullet :: String

## push_meta :: func RichTextLabel.push_meta(data: Variant, underline_mode: int = 1, tooltip: String = "") -> void
Adds a meta tag to the tag stack. Similar to the BBCode [code skip-lint][url=something]{text}[/url][/code], but supports non-[String] metadata types.
If [member meta_underlined] is [code]true[/code], meta tags display an underline. This behavior can be customized with [param underline_mode].
[b]Note:[/b] Meta tags do nothing by default when clicked. To assign behavior when clicked, connect [signal meta_clicked] to a function that is called when the meta tag is clicked.

### data :: Variant

### underline_mode :: int

### tooltip :: String

## push_mono :: func RichTextLabel.push_mono() -> void
Adds a [code skip-lint][font][/code] tag with a monospace font to the tag stack.

## push_normal :: func RichTextLabel.push_normal() -> void
Adds a [code skip-lint][font][/code] tag with a normal font to the tag stack.

## push_outline_color :: func RichTextLabel.push_outline_color(color: Color) -> void
Adds a [code skip-lint][outline_color][/code] tag to the tag stack. Adds text outline for its duration.

### color :: Color

## push_outline_size :: func RichTextLabel.push_outline_size(outline_size: int) -> void
Adds a [code skip-lint][outline_size][/code] tag to the tag stack. Overrides default text outline size for its duration.

### outline_size :: int

## push_paragraph :: func RichTextLabel.push_paragraph(alignment: int, base_direction: int = 0, language: String = "", st_parser: int = 0, justification_flags: int = 163, tab_stops: PackedFloat32Array = PackedFloat32Array()) -> void
Adds a [code skip-lint][p][/code] tag to the tag stack.

### alignment :: int

### base_direction :: int

### language :: String

### st_parser :: int

### justification_flags :: int

### tab_stops :: PackedFloat32Array

## push_strikethrough :: func RichTextLabel.push_strikethrough(color: Color = Color(0, 0, 0, 0)) -> void
Adds a [code skip-lint][s][/code] tag to the tag stack. If [param color]'s alpha value is [code]0.0[/code], the current font's color with its alpha multiplied by [theme_item strikethrough_alpha] is used.

### color :: Color

## push_table :: func RichTextLabel.push_table(columns: int, inline_align: int = 0, align_to_row: int = -1, name: String = "") -> void
Adds a [code skip-lint][table=columns,inline_align][/code] tag to the tag stack. Use [method set_table_column_expand] to set column expansion ratio. Use [method push_cell] to add cells. [param name] is used as the table name for assistive apps.

### columns :: int

### inline_align :: int

### align_to_row :: int

### name :: String

## push_underline :: func RichTextLabel.push_underline(color: Color = Color(0, 0, 0, 0)) -> void
Adds a [code skip-lint][u][/code] tag to the tag stack. If [param color]'s alpha value is [code]0.0[/code], the current font's color with its alpha multiplied by [theme_item underline_alpha] is used.

### color :: Color

## reload_effects :: func RichTextLabel.reload_effects() -> void
Reloads custom effects. Useful when [member custom_effects] is modified manually.

## remove_paragraph :: func RichTextLabel.remove_paragraph(paragraph: int, no_invalidate: bool = false) -> bool
Removes a paragraph of content from the label. Returns [code]true[/code] if the paragraph exists.
The [param paragraph] argument is the index of the paragraph to remove, it can take values in the interval [code][0, get_paragraph_count() - 1][/code].
If [param no_invalidate] is set to [code]true[/code], cache for the subsequent paragraphs is not invalidated. Use it for faster updates if deleted paragraph is fully self-contained (have no unclosed tags), or this call is part of the complex edit operation and [method invalidate_paragraph] will be called at the end of operation.

### paragraph :: int

### no_invalidate :: bool

## scroll_to_line :: func RichTextLabel.scroll_to_line(line: int) -> void
Scrolls the window's top line to match [param line].

### line :: int

## scroll_to_paragraph :: func RichTextLabel.scroll_to_paragraph(paragraph: int) -> void
Scrolls the window's top line to match first line of the [param paragraph].

### paragraph :: int

## scroll_to_selection :: func RichTextLabel.scroll_to_selection() -> void
Scrolls to the beginning of the current selection.

## select_all :: func RichTextLabel.select_all() -> void
Select all the text.
If [member selection_enabled] is [code]false[/code], no selection will occur.

## set_cell_border_color :: func RichTextLabel.set_cell_border_color(color: Color) -> void
Sets color of a table cell border.

### color :: Color

## set_cell_padding :: func RichTextLabel.set_cell_padding(padding: Rect2) -> void
Sets inner padding of a table cell.

### padding :: Rect2

## set_cell_row_background_color :: func RichTextLabel.set_cell_row_background_color(odd_row_bg: Color, even_row_bg: Color) -> void
Sets color of a table cell. Separate colors for alternating rows can be specified.

### odd_row_bg :: Color

### even_row_bg :: Color

## set_cell_size_override :: func RichTextLabel.set_cell_size_override(min_size: Vector2, max_size: Vector2) -> void
Sets minimum and maximum size overrides for a table cell.

### min_size :: Vector2

### max_size :: Vector2

## set_table_column_expand :: func RichTextLabel.set_table_column_expand(column: int, expand: bool, ratio: int = 1, shrink: bool = true) -> void
Edits the selected column's expansion options. If [param expand] is [code]true[/code], the column expands in proportion to its expansion ratio versus the other columns' ratios.
For example, 2 columns with ratios 3 and 4 plus 70 pixels in available width would expand 30 and 40 pixels, respectively.
If [param expand] is [code]false[/code], the column will not contribute to the total ratio.

### column :: int

### expand :: bool

### ratio :: int

### shrink :: bool

## set_table_column_name :: func RichTextLabel.set_table_column_name(column: int, name: String) -> void
Sets table column name for assistive apps.

### column :: int

### name :: String

## update_image :: func RichTextLabel.update_image(key: Variant, mask: int, image: Texture2D, width: float = 0, height: float = 0, color: Color = Color(1, 1, 1, 1), inline_align: int = 5, region: Rect2 = Rect2(0, 0, 0, 0), pad: bool = false, tooltip: String = "", width_unit: int = 0, height_unit: int = 0) -> void
Updates the existing images with the key [param key]. Only properties specified by [param mask] bits are updated. See [method add_image].

### key :: Variant

### mask :: int

### image :: Texture2D

### width :: float

### height :: float

### color :: Color

### inline_align :: int

### region :: Rect2

### pad :: bool

### tooltip :: String

### width_unit :: int

### height_unit :: int

## finished :: func RichTextLabel.finished() -> void
Triggered when the document is fully loaded.
[b]Note:[/b] This can happen before the text is processed for drawing. Scrolling values may not be valid until the document is drawn for the first time after this signal.

## meta_clicked :: func RichTextLabel.meta_clicked(meta: Variant) -> void
Triggered when the user clicks on content between meta (URL) tags. If the meta is defined in BBCode, e.g. [code skip-lint][url={"key": "value"}]Text[/url][/code], then the parameter for this signal will always be a [String] type. If a particular type or an object is desired, the [method push_meta] method must be used to manually insert the data into the tag stack. Alternatively, you can convert the [String] input to the desired type based on its contents (such as calling [method JSON.parse] on it).
For example, the following method can be connected to [signal meta_clicked] to open clicked URLs using the user's default web browser:
[codeblocks]
[gdscript]
# This assumes RichTextLabel's `meta_clicked` signal was connected to
# the function below using the signal connection dialog.
func _richtextlabel_on_meta_clicked(meta):
	# `meta` is of Variant type, so convert it to a String to avoid script errors at run-time.
	OS.shell_open(str(meta))
[/gdscript]
[/codeblocks]

### meta :: Variant

## meta_hover_ended :: func RichTextLabel.meta_hover_ended(meta: Variant) -> void
Triggers when the mouse exits a meta tag.

### meta :: Variant

## meta_hover_started :: func RichTextLabel.meta_hover_started(meta: Variant) -> void
Triggers when the mouse enters a meta tag.

### meta :: Variant
