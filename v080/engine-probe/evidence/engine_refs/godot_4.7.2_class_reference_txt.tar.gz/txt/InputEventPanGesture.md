# InputEventPanGesture :: <Native> class InputEventPanGesture extends InputEventGesture
Represents a panning touch gesture.
Stores information about pan gestures. A pan gesture is performed when the user swipes the touch screen with two fingers. It's typically used for panning/scrolling.
[b]Note:[/b] On Android, this requires the [member ProjectSettings.input_devices/pointing/android/enable_pan_and_scale_gestures] project setting to be enabled.

## delta :: var InputEventPanGesture.delta: Vector2
Panning amount since last pan event.
