# BitMap :: <Native> class BitMap extends Resource
Boolean matrix.
A two-dimensional array of boolean values, can be used to efficiently store a binary matrix (every matrix element takes only one bit) and query the values using natural cartesian coordinates.

## convert_to_image :: func BitMap.convert_to_image() -> Image
Returns an image of the same size as the bitmap and with an [enum Image.Format] of type [constant Image.FORMAT_L8]. [code]true[/code] bits of the bitmap are being converted into white pixels, and [code]false[/code] bits into black.

## create :: func BitMap.create(size: Vector2i) -> void
Creates a bitmap with the specified size, filled with [code]false[/code].

### size :: Vector2i

## create_from_image_alpha :: func BitMap.create_from_image_alpha(image: Image, threshold: float = 0.1) -> void
Creates a bitmap that matches the given image dimensions, every element of the bitmap is set to [code]false[/code] if the alpha value of the image at that position is equal to [param threshold] or less, and [code]true[/code] in other case.

### image :: Image

### threshold :: float

## get_bit :: func BitMap.get_bit(x: int, y: int) -> bool
Returns bitmap's value at the specified position.

### x :: int

### y :: int

## get_bitv :: func BitMap.get_bitv(position: Vector2i) -> bool
Returns bitmap's value at the specified position.

### position :: Vector2i

## get_size :: func BitMap.get_size() -> Vector2i
Returns bitmap's dimensions.

## get_true_bit_count :: func BitMap.get_true_bit_count() -> int
Returns the number of bitmap elements that are set to [code]true[/code].

## grow_mask :: func BitMap.grow_mask(pixels: int, rect: Rect2i) -> void
Applies morphological dilation or erosion to the bitmap. If [param pixels] is positive, dilation is applied to the bitmap. If [param pixels] is negative, erosion is applied to the bitmap. [param rect] defines the area where the morphological operation is applied. Pixels located outside the [param rect] are unaffected by [method grow_mask].

### pixels :: int

### rect :: Rect2i

## opaque_to_polygons :: func BitMap.opaque_to_polygons(rect: Rect2i, epsilon: float = 2.0) -> PackedVector2Array[]
Creates an [Array] of polygons covering a rectangular portion of the bitmap. It uses a marching squares algorithm, followed by Ramer-Douglas-Peucker (RDP) reduction of the number of vertices. Each polygon is described as a [PackedVector2Array] of its vertices.
To get polygons covering the whole bitmap, pass:
[codeblock]
Rect2(Vector2(), get_size())
[/codeblock]
[param epsilon] is passed to RDP to control how accurately the polygons cover the bitmap: a lower [param epsilon] corresponds to more points in the polygons.

### rect :: Rect2i

### epsilon :: float

## resize :: func BitMap.resize(new_size: Vector2i) -> void
Resizes the image to [param new_size].

### new_size :: Vector2i

## set_bit :: func BitMap.set_bit(x: int, y: int, bit: bool) -> void
Sets the bitmap's element at the specified position, to the specified value.

### x :: int

### y :: int

### bit :: bool

## set_bit_rect :: func BitMap.set_bit_rect(rect: Rect2i, bit: bool) -> void
Sets a rectangular portion of the bitmap to the specified value.

### rect :: Rect2i

### bit :: bool

## set_bitv :: func BitMap.set_bitv(position: Vector2i, bit: bool) -> void
Sets the bitmap's element at the specified position, to the specified value.

### position :: Vector2i

### bit :: bool
