# MissingResource :: <Native> class MissingResource extends Resource
An internal editor class intended for keeping the data of unrecognized resources.
This is an internal editor class intended for keeping data of resources of unknown type (most likely this type was supplied by an extension that is no longer loaded). It can't be manually instantiated or placed in a scene.
[b]Warning:[/b] Ignore missing resources unless you know what you are doing. Existing properties on a missing resource can be freely modified in code, regardless of the type they are intended to be.

## original_class :: var MissingResource.original_class: String
The name of the class this resource was supposed to be (see [method Object.get_class]).

## recording_properties :: var MissingResource.recording_properties: bool
If set to [code]true[/code], allows new properties to be added on top of the existing ones with [method Object.set].
