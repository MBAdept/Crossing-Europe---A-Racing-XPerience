# HFlowContainer :: <Native> class HFlowContainer extends FlowContainer
A container that arranges its child controls horizontally and wraps them around at the borders.
A variant of [FlowContainer] that can only arrange its child controls horizontally, wrapping them around at the borders. This is similar to how text in a book wraps around when no more words can fit on a line.
