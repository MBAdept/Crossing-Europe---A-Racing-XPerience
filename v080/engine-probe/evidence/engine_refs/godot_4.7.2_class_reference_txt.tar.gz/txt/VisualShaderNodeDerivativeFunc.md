# VisualShaderNodeDerivativeFunc :: <Native> class VisualShaderNodeDerivativeFunc extends VisualShaderNode
Calculates a derivative within the visual shader graph.
This node is only available in [code]Fragment[/code] and [code]Light[/code] visual shaders.

## OP_TYPE_SCALAR :: const VisualShaderNodeDerivativeFunc.OP_TYPE_SCALAR: OpType = 0
A floating-point scalar.

## OP_TYPE_VECTOR_2D :: const VisualShaderNodeDerivativeFunc.OP_TYPE_VECTOR_2D: OpType = 1
A 2D vector type.

## OP_TYPE_VECTOR_3D :: const VisualShaderNodeDerivativeFunc.OP_TYPE_VECTOR_3D: OpType = 2
A 3D vector type.

## OP_TYPE_VECTOR_4D :: const VisualShaderNodeDerivativeFunc.OP_TYPE_VECTOR_4D: OpType = 3
A 4D vector type.

## OP_TYPE_MAX :: const VisualShaderNodeDerivativeFunc.OP_TYPE_MAX: OpType = 4
Represents the size of the [enum OpType] enum.

## FUNC_SUM :: const VisualShaderNodeDerivativeFunc.FUNC_SUM: Function = 0
Sum of absolute derivative in [code]x[/code] and [code]y[/code].

## FUNC_X :: const VisualShaderNodeDerivativeFunc.FUNC_X: Function = 1
Derivative in [code]x[/code] using local differencing.

## FUNC_Y :: const VisualShaderNodeDerivativeFunc.FUNC_Y: Function = 2
Derivative in [code]y[/code] using local differencing.

## FUNC_MAX :: const VisualShaderNodeDerivativeFunc.FUNC_MAX: Function = 3
Represents the size of the [enum Function] enum.

## PRECISION_NONE :: const VisualShaderNodeDerivativeFunc.PRECISION_NONE: Precision = 0
No precision is specified, the GPU driver is allowed to use whatever level of precision it chooses. This is the default option and is equivalent to using [code]dFdx()[/code] or [code]dFdy()[/code] in text shaders.

## PRECISION_COARSE :: const VisualShaderNodeDerivativeFunc.PRECISION_COARSE: Precision = 1
The derivative will be calculated using the current fragment's neighbors (which may not include the current fragment). This tends to be faster than using [constant PRECISION_FINE], but may not be suitable when more precision is needed. This is equivalent to using [code]dFdxCoarse()[/code] or [code]dFdyCoarse()[/code] in text shaders.

## PRECISION_FINE :: const VisualShaderNodeDerivativeFunc.PRECISION_FINE: Precision = 2
The derivative will be calculated using the current fragment and its immediate neighbors. This tends to be slower than using [constant PRECISION_COARSE], but may be necessary when more precision is needed. This is equivalent to using [code]dFdxFine()[/code] or [code]dFdyFine()[/code] in text shaders.

## PRECISION_MAX :: const VisualShaderNodeDerivativeFunc.PRECISION_MAX: Precision = 3
Represents the size of the [enum Precision] enum.

## function :: var VisualShaderNodeDerivativeFunc.function: VisualShaderNodeDerivativeFunc.Function
A derivative function type.

## op_type :: var VisualShaderNodeDerivativeFunc.op_type: VisualShaderNodeDerivativeFunc.OpType
A type of operands and returned value.

## precision :: var VisualShaderNodeDerivativeFunc.precision: VisualShaderNodeDerivativeFunc.Precision
Sets the level of precision to use for the derivative function. When using the Compatibility renderer, this setting has no effect.
