# PortableCompressedTexture2D :: <Native> class PortableCompressedTexture2D extends Texture2D
Provides a compressed texture for disk and/or VRAM in a way that is portable.
This class allows storing compressed textures as self contained (not imported) resources.
For 2D usage (compressed on disk, uncompressed on VRAM), the lossy and lossless modes are recommended. For 3D usage (compressed on VRAM) it depends on the target platform.
If you intend to only use desktop, S3TC or BPTC are recommended. For only mobile, ETC2 is recommended.
For portable, self contained 3D textures that work on both desktop and mobile, Basis Universal is recommended (although it has a small quality cost and longer compression time as a tradeoff).
This resource is intended to be created from code.

## COMPRESSION_MODE_LOSSLESS :: const PortableCompressedTexture2D.COMPRESSION_MODE_LOSSLESS: CompressionMode = 0

## COMPRESSION_MODE_LOSSY :: const PortableCompressedTexture2D.COMPRESSION_MODE_LOSSY: CompressionMode = 1

## COMPRESSION_MODE_BASIS_UNIVERSAL :: const PortableCompressedTexture2D.COMPRESSION_MODE_BASIS_UNIVERSAL: CompressionMode = 2

## COMPRESSION_MODE_S3TC :: const PortableCompressedTexture2D.COMPRESSION_MODE_S3TC: CompressionMode = 3

## COMPRESSION_MODE_ETC2 :: const PortableCompressedTexture2D.COMPRESSION_MODE_ETC2: CompressionMode = 4

## COMPRESSION_MODE_BPTC :: const PortableCompressedTexture2D.COMPRESSION_MODE_BPTC: CompressionMode = 5

## COMPRESSION_MODE_ASTC :: const PortableCompressedTexture2D.COMPRESSION_MODE_ASTC: CompressionMode = 6

## keep_compressed_buffer :: var PortableCompressedTexture2D.keep_compressed_buffer: bool
If [code]true[/code], when running in the editor, this texture will keep the source-compressed data in memory, allowing the data to persist after loading. Otherwise, the source-compressed data is lost after loading and the texture can't be re-saved.
[b]Note:[/b] This property must be set before [method create_from_image] for this to work.

## resource_local_to_scene :: var PortableCompressedTexture2D.resource_local_to_scene: bool

## size_override :: var PortableCompressedTexture2D.size_override: Vector2
Allows overriding the texture's size (for 2D only).

## create_from_image :: func PortableCompressedTexture2D.create_from_image(image: Image, compression_mode: int, normal_map: bool = false, lossy_quality: float = 0.8) -> void
Initializes the compressed texture from a base image. The compression mode must be provided.
[param normal_map] is recommended to ensure optimum quality if this image will be used as a normal map.
If lossy compression is requested, the quality setting can optionally be provided. This maps to Lossy WebP compression quality.

### image :: Image

### compression_mode :: int

### normal_map :: bool

### lossy_quality :: float

## get_compression_mode :: func PortableCompressedTexture2D.get_compression_mode() -> int
Return the compression mode used (valid after initialized).

## is_keeping_all_compressed_buffers :: func PortableCompressedTexture2D.is_keeping_all_compressed_buffers() -> bool
Returns [code]true[/code] if the flag is overridden for all textures of this type.

## set_basisu_compressor_params :: func PortableCompressedTexture2D.set_basisu_compressor_params(uastc_level: int, rdo_quality_loss: float) -> void
Sets the compressor parameters for Basis Universal compression. See also the settings in [ResourceImporterTexture].
[b]Note:[/b] This method must be called before [method create_from_image] for this to work.

### uastc_level :: int

### rdo_quality_loss :: float

## set_keep_all_compressed_buffers :: func PortableCompressedTexture2D.set_keep_all_compressed_buffers(keep: bool) -> void
If [param keep] is [code]true[/code], overrides the flag globally for all textures of this type. This is used primarily by the editor.

### keep :: bool
