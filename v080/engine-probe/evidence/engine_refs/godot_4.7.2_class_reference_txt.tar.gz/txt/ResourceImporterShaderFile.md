# ResourceImporterShaderFile :: <Native> class ResourceImporterShaderFile extends ResourceImporter
Imports native GLSL shaders (not Godot shaders) as an [RDShaderFile].
This imports native GLSL shaders as [RDShaderFile] resources, for use with low-level [RenderingDevice] operations. This importer does [i]not[/i] handle [code].gdshader[/code] files.
