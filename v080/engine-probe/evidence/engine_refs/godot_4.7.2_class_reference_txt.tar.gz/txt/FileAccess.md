# FileAccess :: <Native> class FileAccess extends RefCounted
Provides methods for file reading and writing operations.
This class can be used to permanently store data in the user device's file system and to read from it. This is useful for storing game save data or player configuration files.
[b]Example:[/b] How to write and read from a file. The file named [code]"save_game.dat"[/code] will be stored in the user data folder, as specified in the [url=https://docs.godotengine.org/en/4.7/tutorials/io/data_paths.html]Data paths[/url] documentation:
[codeblocks]
[gdscript]
func save_to_file(content):
	var file = FileAccess.open("user://save_game.dat", FileAccess.WRITE)
	file.store_string(content)

func load_from_file():
	var file = FileAccess.open("user://save_game.dat", FileAccess.READ)
	var content = file.get_as_text()
	return content
[/gdscript]
[csharp]
public void SaveToFile(string content)
{
	using var file = FileAccess.Open("user://save_game.dat", FileAccess.ModeFlags.Write);
	file.StoreString(content);
}

public string LoadFromFile()
{
	using var file = FileAccess.Open("user://save_game.dat", FileAccess.ModeFlags.Read);
	string content = file.GetAsText();
	return content;
}
[/csharp]
[/codeblocks]
A [FileAccess] instance has its own file cursor, which is the position in bytes in the file where the next read/write operation will occur. Functions such as [method get_8], [method get_16], [method store_8], and [method store_16] will move the file cursor forward by the number of bytes read/written. The file cursor can be moved to a specific position using [method seek] or [method seek_end], and its position can be retrieved using [method get_position].
A [FileAccess] instance will close its file when the instance is freed. Since it inherits [RefCounted], this happens automatically when it is no longer in use. [method close] can be called to close it earlier. In C#, the reference must be disposed manually, which can be done with the [code]using[/code] statement or by calling the [code]Dispose[/code] method directly.
[b]Note:[/b] To access project resources once exported, it is recommended to use [ResourceLoader] instead of [FileAccess], as some files are converted to engine-specific formats and their original source files might not be present in the exported PCK package. If using [FileAccess], make sure the file is included in the export by changing its import mode to [b]Keep File (exported as is)[/b] in the Import dock, or, for files where this option is not available, change the non-resource export filter in the Export dialog to include the file's extension (e.g. [code]*.txt[/code]).
[b]Note:[/b] Files are automatically closed only if the process exits "normally" (such as by clicking the window manager's close button or pressing [kbd]Alt + F4[/kbd]). If you stop the project execution by pressing [kbd]F8[/kbd] while the project is running, the file won't be closed as the game process will be killed. You can work around this by calling [method flush] at regular intervals.

## READ :: const FileAccess.READ: ModeFlags = 1
Opens the file for read operations. The file cursor is positioned at the beginning of the file.

## WRITE :: const FileAccess.WRITE: ModeFlags = 2
Opens the file for write operations. If the file exists, it is truncated to zero length and its contents are cleared. Otherwise, it is created.
[b]Note:[/b] When creating a file it must be in an already existing directory. To recursively create directories for a file path, see [method DirAccess.make_dir_recursive].

## READ_WRITE :: const FileAccess.READ_WRITE: ModeFlags = 3
Opens the file for read and write operations. Does not truncate the file. The file cursor is positioned at the beginning of the file.

## WRITE_READ :: const FileAccess.WRITE_READ: ModeFlags = 7
Opens the file for read and write operations. If the file exists, it is truncated to zero length and its contents are cleared. Otherwise, it is created. The file cursor is positioned at the beginning of the file.
[b]Note:[/b] When creating a file it must be in an already existing directory. To recursively create directories for a file path, see [method DirAccess.make_dir_recursive].

## COMPRESSION_FASTLZ :: const FileAccess.COMPRESSION_FASTLZ: CompressionMode = 0
Uses the [url=https://fastlz.org/]FastLZ[/url] compression method.

## COMPRESSION_DEFLATE :: const FileAccess.COMPRESSION_DEFLATE: CompressionMode = 1
Uses the [url=https://en.wikipedia.org/wiki/DEFLATE]DEFLATE[/url] compression method.

## COMPRESSION_ZSTD :: const FileAccess.COMPRESSION_ZSTD: CompressionMode = 2
Uses the [url=https://facebook.github.io/zstd/]Zstandard[/url] compression method.

## COMPRESSION_GZIP :: const FileAccess.COMPRESSION_GZIP: CompressionMode = 3
Uses the [url=https://www.gzip.org/]gzip[/url] compression method.

## COMPRESSION_BROTLI :: const FileAccess.COMPRESSION_BROTLI: CompressionMode = 4
Uses the [url=https://github.com/google/brotli]brotli[/url] compression method (only decompression is supported).

## UNIX_READ_OWNER :: const FileAccess.UNIX_READ_OWNER: UnixPermissionFlags = 256
Read for owner bit.

## UNIX_WRITE_OWNER :: const FileAccess.UNIX_WRITE_OWNER: UnixPermissionFlags = 128
Write for owner bit.

## UNIX_EXECUTE_OWNER :: const FileAccess.UNIX_EXECUTE_OWNER: UnixPermissionFlags = 64
Execute for owner bit.

## UNIX_READ_GROUP :: const FileAccess.UNIX_READ_GROUP: UnixPermissionFlags = 32
Read for group bit.

## UNIX_WRITE_GROUP :: const FileAccess.UNIX_WRITE_GROUP: UnixPermissionFlags = 16
Write for group bit.

## UNIX_EXECUTE_GROUP :: const FileAccess.UNIX_EXECUTE_GROUP: UnixPermissionFlags = 8
Execute for group bit.

## UNIX_READ_OTHER :: const FileAccess.UNIX_READ_OTHER: UnixPermissionFlags = 4
Read for other bit.

## UNIX_WRITE_OTHER :: const FileAccess.UNIX_WRITE_OTHER: UnixPermissionFlags = 2
Write for other bit.

## UNIX_EXECUTE_OTHER :: const FileAccess.UNIX_EXECUTE_OTHER: UnixPermissionFlags = 1
Execute for other bit.

## UNIX_SET_USER_ID :: const FileAccess.UNIX_SET_USER_ID: UnixPermissionFlags = 2048
Set user id on execution bit.

## UNIX_SET_GROUP_ID :: const FileAccess.UNIX_SET_GROUP_ID: UnixPermissionFlags = 1024
Set group id on execution bit.

## UNIX_RESTRICTED_DELETE :: const FileAccess.UNIX_RESTRICTED_DELETE: UnixPermissionFlags = 512
Restricted deletion (sticky) bit.

## big_endian :: var FileAccess.big_endian: bool
If [code]true[/code], the file is read with big-endian [url=https://en.wikipedia.org/wiki/Endianness]endianness[/url]. If [code]false[/code], the file is read with little-endian endianness. If in doubt, leave this to [code]false[/code] as most files are written with little-endian endianness.
[b]Note:[/b] This is always reset to system endianness, which is little-endian on all supported platforms, whenever you open the file. Therefore, you must set [member big_endian] [i]after[/i] opening the file, not before.

## close :: func FileAccess.close() -> void
Closes the currently opened file and prevents subsequent read/write operations. Use [method flush] to persist the data to disk without closing the file.
[b]Note:[/b] [FileAccess] will automatically close when it's freed, which happens when it goes out of scope or when it gets assigned with [code]null[/code]. In C# the reference must be disposed after we are done using it, this can be done with the [code]using[/code] statement or calling the [code]Dispose[/code] method directly.

## create_temp :: func FileAccess.create_temp(mode_flags: int, prefix: String = "", extension: String = "", keep: bool = false) -> FileAccess
Creates a temporary file. This file will be freed when the returned [FileAccess] is freed.
If [param prefix] is not empty, it will be prefixed to the file name, separated by a [code]-[/code].
If [param extension] is not empty, it will be appended to the temporary file name.
If [param keep] is [code]true[/code], the file is not deleted when the returned [FileAccess] is freed.
Returns [code]null[/code] if opening the file failed. You can use [method get_open_error] to check the error that occurred.

### mode_flags :: int

### prefix :: String

### extension :: String

### keep :: bool

## eof_reached :: func FileAccess.eof_reached() -> bool
Returns [code]true[/code] if the file cursor has already read past the end of the file.
[b]Note:[/b] [code]eof_reached() == false[/code] cannot be used to check whether there is more data available. To loop while there is more data available, use:
[codeblocks]
[gdscript]
while file.get_position() < file.get_length():
	# Read data
[/gdscript]
[csharp]
while (file.GetPosition() < file.GetLength())
{
	// Read data
}
[/csharp]
[/codeblocks]

## file_exists :: func FileAccess.file_exists(path: String) -> bool
Returns [code]true[/code] if the file exists in the given path.
[b]Note:[/b] Many resources types are imported (e.g. textures or sound files), and their source asset will not be included in the exported game, as only the imported version is used. See [method ResourceLoader.exists] for an alternative approach that takes resource remapping into account.
For a non-static, relative equivalent, use [method DirAccess.file_exists].

### path :: String

## flush :: func FileAccess.flush() -> void
Writes the file's buffer to disk. Flushing is automatically performed when the file is closed. This means you don't need to call [method flush] manually before closing a file. Still, calling [method flush] can be used to ensure the data is safe even if the project crashes instead of being closed gracefully.
[b]Note:[/b] Only call [method flush] when you actually need it. Otherwise, it will decrease performance due to constant disk writes.

## get_8 :: func FileAccess.get_8() -> int
Returns the next 8 bits from the file as an integer. This advances the file cursor by 1 byte. See [method store_8] for details on what values can be stored and retrieved this way.

## get_16 :: func FileAccess.get_16() -> int
Returns the next 16 bits from the file as an integer. This advances the file cursor by 2 bytes. See [method store_16] for details on what values can be stored and retrieved this way.

## get_32 :: func FileAccess.get_32() -> int
Returns the next 32 bits from the file as an integer. This advances the file cursor by 4 bytes. See [method store_32] for details on what values can be stored and retrieved this way.

## get_64 :: func FileAccess.get_64() -> int
Returns the next 64 bits from the file as an integer. This advances the file cursor by 8 bytes. See [method store_64] for details on what values can be stored and retrieved this way.

## get_access_time :: func FileAccess.get_access_time(file: String) -> int
Returns the last time the [param file] was accessed in Unix timestamp format, or [code]0[/code] on error. This Unix timestamp can be converted to another format using the [Time] singleton.

### file :: String

## get_as_text :: func FileAccess.get_as_text() -> String
Returns the whole file as a [String]. Text is interpreted as being UTF-8 encoded. This ignores the file cursor and does not affect it.

## get_buffer :: func FileAccess.get_buffer(length: int) -> PackedByteArray
Returns next [param length] bytes of the file as a [PackedByteArray]. This advances the file cursor by [param length] bytes.

### length :: int

## get_csv_line :: func FileAccess.get_csv_line(delim: String = ",") -> PackedStringArray
Returns the next value of the file in CSV (Comma-Separated Values) format. You can pass a different delimiter [param delim] to use other than the default [code]","[/code] (comma). This delimiter must be one-character long, and cannot be a double quotation mark.
Text is interpreted as being UTF-8 encoded. Text values must be enclosed in double quotes if they include the delimiter character. Double quotes within a text value can be escaped by doubling their occurrence. This advances the file cursor to after the newline character at the end of the line.
For example, the following CSV lines are valid and will be properly parsed as two strings each:
[codeblock lang=text]
Alice,"Hello, Bob!"
Bob,Alice! What a surprise!
Alice,"I thought you'd reply with ""Hello, world""."
[/codeblock]
Note how the second line can omit the enclosing quotes as it does not include the delimiter. However it [i]could[/i] very well use quotes, it was only written without for demonstration purposes. The third line must use [code]""[/code] for each quotation mark that needs to be interpreted as such instead of the end of a text value.

### delim :: String

## get_double :: func FileAccess.get_double() -> float
Returns the next 64 bits from the file as a floating-point number. This advances the file cursor by 8 bytes.

## get_error :: func FileAccess.get_error() -> int
Returns the last error that happened when trying to perform operations. Compare with the [code]ERR_FILE_*[/code] constants from [enum Error].

## get_extended_attribute :: func FileAccess.get_extended_attribute(file: String, attribute_name: String) -> PackedByteArray
Reads the file extended attribute with name [param attribute_name] as a byte array.
[b]Note:[/b] This method is implemented on Linux, macOS, and Windows.
[b]Note:[/b] Extended attributes support depends on the file system. Attributes will be lost when the file is moved between incompatible file systems.
[b]Note:[/b] On Linux, only "user" namespace attributes are accessible, namespace prefix should not be included.
[b]Note:[/b] On Windows, alternate data streams are used to store extended attributes.

### file :: String

### attribute_name :: String

## get_extended_attribute_string :: func FileAccess.get_extended_attribute_string(file: String, attribute_name: String) -> String
Reads the file extended attribute with name [param attribute_name] as a UTF-8 encoded string.
[b]Note:[/b] This method is implemented on Linux, macOS, and Windows.
[b]Note:[/b] Extended attributes support depends on the file system. Attributes will be lost when the file is moved between incompatible file systems.
[b]Note:[/b] On Linux, only "user" namespace attributes are accessible, namespace prefix should not be included.
[b]Note:[/b] On Windows, alternate data streams are used to store extended attributes.

### file :: String

### attribute_name :: String

## get_extended_attributes_list :: func FileAccess.get_extended_attributes_list(file: String) -> PackedStringArray
Returns a list of file extended attributes.
[b]Note:[/b] This method is implemented on Linux, macOS, and Windows.
[b]Note:[/b] Extended attributes support depends on the file system. Attributes will be lost when the file is moved between incompatible file systems.
[b]Note:[/b] On Linux, only "user" namespace attributes are accessible, namespace prefix should not be included.
[b]Note:[/b] On Windows, alternate data streams are used to store extended attributes.

### file :: String

## get_file_as_bytes :: func FileAccess.get_file_as_bytes(path: String) -> PackedByteArray
Returns the whole [param path] file contents as a [PackedByteArray] without any decoding.
Returns an empty [PackedByteArray] if an error occurred while opening the file. You can use [method get_open_error] to check the error that occurred.

### path :: String

## get_file_as_string :: func FileAccess.get_file_as_string(path: String) -> String
Returns the whole [param path] file contents as a [String]. Text is interpreted as being UTF-8 encoded.
Returns an empty [String] if an error occurred while opening the file. You can use [method get_open_error] to check the error that occurred.

### path :: String

## get_float :: func FileAccess.get_float() -> float
Returns the next 32 bits from the file as a floating-point number. This advances the file cursor by 4 bytes.

## get_half :: func FileAccess.get_half() -> float
Returns the next 16 bits from the file as a half-precision floating-point number. This advances the file cursor by 2 bytes.

## get_hidden_attribute :: func FileAccess.get_hidden_attribute(file: String) -> bool
Returns [code]true[/code] if the [b]hidden[/b] attribute is set on the file at the given path.
[b]Note:[/b] This method is implemented on iOS, BSD, macOS, and Windows.

### file :: String

## get_length :: func FileAccess.get_length() -> int
Returns the size of the file in bytes. For a pipe, returns the number of bytes available for reading from the pipe.

## get_line :: func FileAccess.get_line() -> String
Returns the next line of the file as a [String]. The returned string doesn't include newline ([code]\n[/code]) or carriage return ([code]\r[/code]) characters, but does include any other leading or trailing whitespace. This advances the file cursor to after the newline character at the end of the line.
Text is interpreted as being UTF-8 encoded.

## get_md5 :: func FileAccess.get_md5(path: String) -> String
Returns an MD5 String representing the file at the given path or an empty [String] on failure.

### path :: String

## get_modified_time :: func FileAccess.get_modified_time(file: String) -> int
Returns the last time the [param file] was modified in Unix timestamp format, or [code]0[/code] on error. This Unix timestamp can be converted to another format using the [Time] singleton.

### file :: String

## get_open_error :: func FileAccess.get_open_error() -> int
Returns the result of the last [method open] call in the current thread.

## get_pascal_string :: func FileAccess.get_pascal_string() -> String
Returns a [String] saved in Pascal format from the file, meaning that the length of the string is explicitly stored at the start. See [method store_pascal_string]. This may include newline characters. The file cursor is advanced after the bytes read.
Text is interpreted as being UTF-8 encoded.

## get_path :: func FileAccess.get_path() -> String
Returns the path as a [String] for the current open file.

## get_path_absolute :: func FileAccess.get_path_absolute() -> String
Returns the absolute path as a [String] for the current open file.

## get_position :: func FileAccess.get_position() -> int
Returns the file cursor's position in bytes from the beginning of the file. This is the file reading/writing cursor set by [method seek] or [method seek_end] and advanced by read/write operations.

## get_read_only_attribute :: func FileAccess.get_read_only_attribute(file: String) -> bool
Returns [code]true[/code] if the [b]read only[/b] attribute is set on the file at the given path.
[b]Note:[/b] This method is implemented on iOS, BSD, macOS, and Windows.

### file :: String

## get_real :: func FileAccess.get_real() -> float
Returns the next bits from the file as a floating-point number. This advances the file cursor by either 4 or 8 bytes, depending on the precision used by the Godot build that saved the file.
If the file was saved by a Godot build compiled with the [code]precision=single[/code] option (the default), the number of read bits for that file is 32. Otherwise, if compiled with the [code]precision=double[/code] option, the number of read bits is 64.

## get_sha256 :: func FileAccess.get_sha256(path: String) -> String
Returns an SHA-256 [String] representing the file at the given path or an empty [String] on failure.

### path :: String

## get_size :: func FileAccess.get_size(file: String) -> int
Returns the size of the file at the given path, in bytes, or [code]-1[/code] on error.

### file :: String

## get_unix_permissions :: func FileAccess.get_unix_permissions(file: String) -> int
Returns the UNIX permissions of the file at the given path.
[b]Note:[/b] This method is implemented on iOS, Linux/BSD, and macOS.

### file :: String

## get_var :: func FileAccess.get_var(allow_objects: bool = false) -> Variant
Returns the next [Variant] value from the file. If [param allow_objects] is [code]true[/code], decoding objects is allowed. This advances the file cursor by the number of bytes read.
Internally, this uses the same decoding mechanism as the [method @GlobalScope.bytes_to_var] method, as described in the [url=https://docs.godotengine.org/en/4.7/tutorials/io/binary_serialization_api.html]Binary serialization API[/url] documentation.
[b]Warning:[/b] Deserialized objects can contain code which gets executed. Do not use this option if the serialized object comes from untrusted sources to avoid potential security threats such as remote code execution.

### allow_objects :: bool

## is_open :: func FileAccess.is_open() -> bool
Returns [code]true[/code] if the file is currently opened.

## open :: func FileAccess.open(path: String, flags: int) -> FileAccess
Creates a new [FileAccess] object and opens the file for writing or reading, depending on the flags.
Returns [code]null[/code] if opening the file failed. You can use [method get_open_error] to check the error that occurred.

### path :: String

### flags :: int

## open_compressed :: func FileAccess.open_compressed(path: String, mode_flags: int, compression_mode: int = 0) -> FileAccess
Creates a new [FileAccess] object and opens a compressed file for reading or writing.
[b]Note:[/b] [method open_compressed] can only read files that were saved by Godot, not third-party compression formats. See [url=https://github.com/godotengine/godot/issues/28999]GitHub issue #28999[/url] for a workaround.
Returns [code]null[/code] if opening the file failed. You can use [method get_open_error] to check the error that occurred.

### path :: String

### mode_flags :: int

### compression_mode :: int

## open_encrypted :: func FileAccess.open_encrypted(path: String, mode_flags: int, key: PackedByteArray, iv: PackedByteArray = PackedByteArray()) -> FileAccess
Creates a new [FileAccess] object and opens an encrypted file in write or read mode. You need to pass a binary key to encrypt/decrypt it.
[b]Note:[/b] The provided key must be 32 bytes long.
Returns [code]null[/code] if opening the file failed. You can use [method get_open_error] to check the error that occurred.

### path :: String

### mode_flags :: int

### key :: PackedByteArray

### iv :: PackedByteArray

## open_encrypted_with_pass :: func FileAccess.open_encrypted_with_pass(path: String, mode_flags: int, pass: String) -> FileAccess
Creates a new [FileAccess] object and opens an encrypted file in write or read mode. You need to pass a password to encrypt/decrypt it.
Returns [code]null[/code] if opening the file failed. You can use [method get_open_error] to check the error that occurred.

### path :: String

### mode_flags :: int

### pass :: String

## remove_extended_attribute :: func FileAccess.remove_extended_attribute(file: String, attribute_name: String) -> int
Removes file extended attribute with name [param attribute_name].
[b]Note:[/b] This method is implemented on Linux, macOS, and Windows.
[b]Note:[/b] Extended attributes support depends on the file system. Attributes will be lost when the file is moved between incompatible file systems.
[b]Note:[/b] On Linux, only "user" namespace attributes are accessible, namespace prefix should not be included.
[b]Note:[/b] On Windows, alternate data streams are used to store extended attributes.

### file :: String

### attribute_name :: String

## resize :: func FileAccess.resize(length: int) -> int
Resizes the file to a specified length. The file must be open in a mode that permits writing. If the file is extended, NUL characters are appended. If the file is truncated, all data from the end file to the original length of the file is lost.

### length :: int

## seek :: func FileAccess.seek(position: int) -> void
Sets the file cursor to the specified position in bytes, from the beginning of the file. This changes the value returned by [method get_position].

### position :: int

## seek_end :: func FileAccess.seek_end(position: int = 0) -> void
Sets the file cursor to the specified position in bytes, from the end of the file. This changes the value returned by [method get_position].
[b]Note:[/b] This is an offset, so you should use negative numbers otherwise the file cursor will move past the end of the file.

### position :: int

## set_extended_attribute :: func FileAccess.set_extended_attribute(file: String, attribute_name: String, data: PackedByteArray) -> int
Writes file extended attribute with name [param attribute_name] as a byte array.
[b]Note:[/b] This method is implemented on Linux, macOS, and Windows.
[b]Note:[/b] Extended attributes support depends on the file system. Attributes will be lost when the file is moved between incompatible file systems.
[b]Note:[/b] On Linux, only "user" namespace attributes are accessible, namespace prefix should not be included.
[b]Note:[/b] On Windows, alternate data streams are used to store extended attributes.

### file :: String

### attribute_name :: String

### data :: PackedByteArray

## set_extended_attribute_string :: func FileAccess.set_extended_attribute_string(file: String, attribute_name: String, data: String) -> int
Writes file extended attribute with name [param attribute_name] as a UTF-8 encoded string.
[b]Note:[/b] This method is implemented on Linux, macOS, and Windows.
[b]Note:[/b] Extended attributes support depends on the file system. Attributes will be lost when the file is moved between incompatible file systems.
[b]Note:[/b] On Linux, only "user" namespace attributes are accessible, namespace prefix should not be included.
[b]Note:[/b] On Windows, alternate data streams are used to store extended attributes.

### file :: String

### attribute_name :: String

### data :: String

## set_hidden_attribute :: func FileAccess.set_hidden_attribute(file: String, hidden: bool) -> int
Sets file [b]hidden[/b] attribute.
[b]Note:[/b] This method is implemented on iOS, BSD, macOS, and Windows.

### file :: String

### hidden :: bool

## set_read_only_attribute :: func FileAccess.set_read_only_attribute(file: String, ro: bool) -> int
Sets file [b]read only[/b] attribute.
[b]Note:[/b] This method is implemented on iOS, BSD, macOS, and Windows.

### file :: String

### ro :: bool

## set_unix_permissions :: func FileAccess.set_unix_permissions(file: String, permissions: int) -> int
Sets file UNIX permissions.
[b]Note:[/b] This method is implemented on iOS, Linux/BSD, and macOS.

### file :: String

### permissions :: int

## store_8 :: func FileAccess.store_8(value: int) -> bool
Stores an integer as 8 bits in the file. This advances the file cursor by 1 byte. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] The [param value] should lie in the interval [code][0, 255][/code]. Any other value will overflow and wrap around.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.
To store a signed integer, use [method store_64], or convert it manually (see [method store_16] for an example).

### value :: int

## store_16 :: func FileAccess.store_16(value: int) -> bool
Stores an integer as 16 bits in the file. This advances the file cursor by 2 bytes. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] The [param value] should lie in the interval [code][0, 2^16 - 1][/code]. Any other value will overflow and wrap around.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.
To store a signed integer, use [method store_64] or store a signed integer from the interval [code][-2^15, 2^15 - 1][/code] (i.e. keeping one bit for the signedness) and compute its sign manually when reading. For example:
[codeblocks]
[gdscript]
const MAX_15B = 1 << 15
const MAX_16B = 1 << 16

func unsigned16_to_signed(unsigned):
	return (unsigned + MAX_15B) % MAX_16B - MAX_15B

func _ready():
	var f = FileAccess.open("user://file.dat", FileAccess.WRITE_READ)
	f.store_16(-42) # This wraps around and stores 65494 (2^16 - 42).
	f.store_16(121) # In bounds, will store 121.
	f.seek(0) # Go back to start to read the stored value.
	var read1 = f.get_16() # 65494
	var read2 = f.get_16() # 121
	var converted1 = unsigned16_to_signed(read1) # -42
	var converted2 = unsigned16_to_signed(read2) # 121
[/gdscript]
[csharp]
public override void _Ready()
{
	using var f = FileAccess.Open("user://file.dat", FileAccess.ModeFlags.WriteRead);
	f.Store16(unchecked((ushort)-42)); // This wraps around and stores 65494 (2^16 - 42).
	f.Store16(121); // In bounds, will store 121.
	f.Seek(0); // Go back to start to read the stored value.
	ushort read1 = f.Get16(); // 65494
	ushort read2 = f.Get16(); // 121
	short converted1 = (short)read1; // -42
	short converted2 = (short)read2; // 121
}
[/csharp]
[/codeblocks]

### value :: int

## store_32 :: func FileAccess.store_32(value: int) -> bool
Stores an integer as 32 bits in the file. This advances the file cursor by 4 bytes. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] The [param value] should lie in the interval [code][0, 2^32 - 1][/code]. Any other value will overflow and wrap around.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.
To store a signed integer, use [method store_64], or convert it manually (see [method store_16] for an example).

### value :: int

## store_64 :: func FileAccess.store_64(value: int) -> bool
Stores an integer as 64 bits in the file. This advances the file cursor by 8 bytes. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] The [param value] must lie in the interval [code][-2^63, 2^63 - 1][/code] (i.e. be a valid [int] value).
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.

### value :: int

## store_buffer :: func FileAccess.store_buffer(buffer: PackedByteArray) -> bool
Stores the given array of bytes in the file. This advances the file cursor by the number of bytes written. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.

### buffer :: PackedByteArray

## store_csv_line :: func FileAccess.store_csv_line(values: PackedStringArray, delim: String = ",") -> bool
Stores the given [PackedStringArray] in the file as a line formatted in the CSV (Comma-Separated Values) format. You can pass a different delimiter [param delim] to use other than the default [code]","[/code] (comma). This delimiter must be one-character long.
Text will be encoded as UTF-8. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.

### values :: PackedStringArray

### delim :: String

## store_double :: func FileAccess.store_double(value: float) -> bool
Stores a floating-point number as 64 bits in the file. This advances the file cursor by 8 bytes. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.

### value :: float

## store_float :: func FileAccess.store_float(value: float) -> bool
Stores a floating-point number as 32 bits in the file. This advances the file cursor by 4 bytes. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.

### value :: float

## store_half :: func FileAccess.store_half(value: float) -> bool
Stores a half-precision floating-point number as 16 bits in the file. This advances the file cursor by 2 bytes. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.

### value :: float

## store_line :: func FileAccess.store_line(line: String) -> bool
Stores [param line] in the file followed by a newline character ([code]\n[/code]), encoding the text as UTF-8. This advances the file cursor by the length of the line, after the newline character. The amount of bytes written depends on the UTF-8 encoded bytes, which may be different from [method String.length] which counts the number of UTF-32 codepoints. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.

### line :: String

## store_pascal_string :: func FileAccess.store_pascal_string(string: String) -> bool
Stores the given [String] as a line in the file in Pascal format (i.e. also store the length of the string). Text will be encoded as UTF-8. This advances the file cursor by the number of bytes written depending on the UTF-8 encoded bytes, which may be different from [method String.length] which counts the number of UTF-32 codepoints. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.

### string :: String

## store_real :: func FileAccess.store_real(value: float) -> bool
Stores a floating-point number in the file. This advances the file cursor by either 4 or 8 bytes, depending on the precision used by the current Godot build.
If using a Godot build compiled with the [code]precision=single[/code] option (the default), this method will save a 32-bit float. Otherwise, if compiled with the [code]precision=double[/code] option, this will save a 64-bit float. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.

### value :: float

## store_string :: func FileAccess.store_string(string: String) -> bool
Stores [param string] in the file without a newline character ([code]\n[/code]), encoding the text as UTF-8. This advances the file cursor by the length of the string in UTF-8 encoded bytes, which may be different from [method String.length] which counts the number of UTF-32 codepoints. Returns [code]true[/code] if the operation is successful.
[b]Note:[/b] This method is intended to be used to write text files. The string is stored as a UTF-8 encoded buffer without string length or terminating zero, which means that it can't be loaded back easily. If you want to store a retrievable string in a binary file, consider using [method store_pascal_string] instead. For retrieving strings from a text file, you can use [code]get_buffer(length).get_string_from_utf8()[/code] (if you know the length) or [method get_as_text].
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.

### string :: String

## store_var :: func FileAccess.store_var(value: Variant, full_objects: bool = false) -> bool
Stores any Variant value in the file. If [param full_objects] is [code]true[/code], encoding objects is allowed (and can potentially include code). This advances the file cursor by the number of bytes written. Returns [code]true[/code] if the operation is successful.
Internally, this uses the same encoding mechanism as the [method @GlobalScope.var_to_bytes] method, as described in the [url=https://docs.godotengine.org/en/4.7/tutorials/io/binary_serialization_api.html]Binary serialization API[/url] documentation.
[b]Note:[/b] Not all properties are included. Only properties that are configured with the [constant PROPERTY_USAGE_STORAGE] flag set will be serialized. You can add a new usage flag to a property by overriding the [method Object._get_property_list] method in your class. You can also check how property usage is configured by calling [method Object._get_property_list]. See [enum PropertyUsageFlags] for the possible usage flags.
[b]Note:[/b] If an error occurs, the resulting value of the file position indicator is indeterminate.

### value :: Variant

### full_objects :: bool
