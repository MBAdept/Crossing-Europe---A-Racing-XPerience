# GLTFObjectModelProperty :: <Native> class GLTFObjectModelProperty extends RefCounted
Describes how to access a property as defined in the glTF object model.
GLTFObjectModelProperty defines a mapping between a property in the glTF object model and a NodePath in the Godot scene tree. This can be used to animate properties in a glTF file using the [code]KHR_animation_pointer[/code] extension, or to access them through an engine-agnostic script such as a behavior graph as defined by the [code]KHR_interactivity[/code] extension.
The glTF property is identified by JSON pointer(s) stored in [member json_pointers], while the Godot property it maps to is defined by [member node_paths]. In most cases [member json_pointers] and [member node_paths] will each only have one item, but in some cases a single glTF JSON pointer will map to multiple Godot properties, or a single Godot property will be mapped to multiple glTF JSON pointers, or it might be a many-to-many relationship.
[Expression] objects can be used to define conversions between the data, such as when glTF defines an angle in radians and Godot uses degrees. The [member object_model_type] property defines the type of data stored in the glTF file as defined by the object model, see [enum GLTFObjectModelType] for possible values.

## GLTF_OBJECT_MODEL_TYPE_UNKNOWN :: const GLTFObjectModelProperty.GLTF_OBJECT_MODEL_TYPE_UNKNOWN: GLTFObjectModelType = 0
Unknown or not set object model type. If the object model type is set to this value, the real type still needs to be determined.

## GLTF_OBJECT_MODEL_TYPE_BOOL :: const GLTFObjectModelProperty.GLTF_OBJECT_MODEL_TYPE_BOOL: GLTFObjectModelType = 1
Object model type "bool". Represented in the glTF JSON as a boolean, and encoded in a [GLTFAccessor] as "SCALAR". When encoded in an accessor, a value of [code]0[/code] is [code]false[/code], and any other value is [code]true[/code].

## GLTF_OBJECT_MODEL_TYPE_FLOAT :: const GLTFObjectModelProperty.GLTF_OBJECT_MODEL_TYPE_FLOAT: GLTFObjectModelType = 2
Object model type "float". Represented in the glTF JSON as a number, and encoded in a [GLTFAccessor] as "SCALAR".

## GLTF_OBJECT_MODEL_TYPE_FLOAT_ARRAY :: const GLTFObjectModelProperty.GLTF_OBJECT_MODEL_TYPE_FLOAT_ARRAY: GLTFObjectModelType = 3
Object model type "float[lb][rb]". Represented in the glTF JSON as an array of numbers, and encoded in a [GLTFAccessor] as "SCALAR".

## GLTF_OBJECT_MODEL_TYPE_FLOAT2 :: const GLTFObjectModelProperty.GLTF_OBJECT_MODEL_TYPE_FLOAT2: GLTFObjectModelType = 4
Object model type "float2". Represented in the glTF JSON as an array of two numbers, and encoded in a [GLTFAccessor] as "VEC2".

## GLTF_OBJECT_MODEL_TYPE_FLOAT3 :: const GLTFObjectModelProperty.GLTF_OBJECT_MODEL_TYPE_FLOAT3: GLTFObjectModelType = 5
Object model type "float3". Represented in the glTF JSON as an array of three numbers, and encoded in a [GLTFAccessor] as "VEC3".

## GLTF_OBJECT_MODEL_TYPE_FLOAT4 :: const GLTFObjectModelProperty.GLTF_OBJECT_MODEL_TYPE_FLOAT4: GLTFObjectModelType = 6
Object model type "float4". Represented in the glTF JSON as an array of four numbers, and encoded in a [GLTFAccessor] as "VEC4".

## GLTF_OBJECT_MODEL_TYPE_FLOAT2X2 :: const GLTFObjectModelProperty.GLTF_OBJECT_MODEL_TYPE_FLOAT2X2: GLTFObjectModelType = 7
Object model type "float2x2". Represented in the glTF JSON as an array of four numbers, and encoded in a [GLTFAccessor] as "MAT2".

## GLTF_OBJECT_MODEL_TYPE_FLOAT3X3 :: const GLTFObjectModelProperty.GLTF_OBJECT_MODEL_TYPE_FLOAT3X3: GLTFObjectModelType = 8
Object model type "float3x3". Represented in the glTF JSON as an array of nine numbers, and encoded in a [GLTFAccessor] as "MAT3".

## GLTF_OBJECT_MODEL_TYPE_FLOAT4X4 :: const GLTFObjectModelProperty.GLTF_OBJECT_MODEL_TYPE_FLOAT4X4: GLTFObjectModelType = 9
Object model type "float4x4". Represented in the glTF JSON as an array of sixteen numbers, and encoded in a [GLTFAccessor] as "MAT4".

## GLTF_OBJECT_MODEL_TYPE_INT :: const GLTFObjectModelProperty.GLTF_OBJECT_MODEL_TYPE_INT: GLTFObjectModelType = 10
Object model type "int". Represented in the glTF JSON as a number, and encoded in a [GLTFAccessor] as "SCALAR". The range of values is limited to signed integers. For [code]KHR_interactivity[/code], only 32-bit integers are supported.

## gltf_to_godot_expression :: var GLTFObjectModelProperty.gltf_to_godot_expression: Expression
If set, this [Expression] will be used to convert the property value from the glTF object model to the value expected by the Godot property. This is useful when the glTF object model uses a different unit system, or when the data needs to be transformed in some way. If [code]null[/code], the value will be copied as-is.

## godot_to_gltf_expression :: var GLTFObjectModelProperty.godot_to_gltf_expression: Expression
If set, this [Expression] will be used to convert the property value from the Godot property to the value expected by the glTF object model. This is useful when the glTF object model uses a different unit system, or when the data needs to be transformed in some way. If [code]null[/code], the value will be copied as-is.

## json_pointers :: var GLTFObjectModelProperty.json_pointers: PackedStringArray[]
The glTF object model JSON pointers used to identify the property in the glTF object model. In most cases, there will be only one item in this array, but specific cases may require multiple pointers. The items are themselves arrays which represent the JSON pointer split into its components.

## node_paths :: var GLTFObjectModelProperty.node_paths: NodePath[]
An array of [NodePath]s that point to a property, or multiple properties, in the Godot scene tree. On import, this will either be set by [GLTFDocument], or by a [GLTFDocumentExtension] class. For simple cases, use [method append_path_to_property] to add properties to this array.
In most cases [member node_paths] will only have one item, but in some cases a single glTF JSON pointer will map to multiple Godot properties. For example, a [GLTFCamera] or [GLTFLight] used on multiple glTF nodes will be represented by multiple Godot nodes.

## object_model_type :: var GLTFObjectModelProperty.object_model_type: GLTFObjectModelProperty.GLTFObjectModelType
The type of data stored in the glTF file as defined by the object model. This is a superset of the available accessor types, and determines the accessor type.

## variant_type :: var GLTFObjectModelProperty.variant_type: Variant.Type
The type of data stored in the Godot property. This is the type of the property that the [member node_paths] point to.

## append_node_path :: func GLTFObjectModelProperty.append_node_path(node_path: NodePath) -> void
Appends a [NodePath] to [member node_paths]. This can be used by [GLTFDocumentExtension] classes to define how a glTF object model property maps to a Godot property, or multiple Godot properties. Prefer using [method append_path_to_property] for simple cases. Be sure to also call [method set_types] once (the order does not matter).

### node_path :: NodePath

## append_path_to_property :: func GLTFObjectModelProperty.append_path_to_property(node_path: NodePath, prop_name: StringName) -> void
High-level wrapper over [method append_node_path] that handles the most common cases. It constructs a new [NodePath] using [param node_path] as a base and appends [param prop_name] to the subpath. Be sure to also call [method set_types] once (the order does not matter).

### node_path :: NodePath

### prop_name :: StringName

## get_accessor_type :: func GLTFObjectModelProperty.get_accessor_type() -> int
The GLTF accessor type associated with this property's [member object_model_type]. See [member GLTFAccessor.accessor_type] for possible values, and see [enum GLTFObjectModelType] for how the object model type maps to accessor types.

## has_json_pointers :: func GLTFObjectModelProperty.has_json_pointers() -> bool
Returns [code]true[/code] if [member json_pointers] is not empty. This is used during export to determine if a [GLTFObjectModelProperty] can handle converting a Godot property to a glTF object model property.

## has_node_paths :: func GLTFObjectModelProperty.has_node_paths() -> bool
Returns [code]true[/code] if [member node_paths] is not empty. This is used during import to determine if a [GLTFObjectModelProperty] can handle converting a glTF object model property to a Godot property.

## set_types :: func GLTFObjectModelProperty.set_types(variant_type: int, obj_model_type: int) -> void
Sets the [member variant_type] and [member object_model_type] properties. This is a convenience method to set both properties at once, since they are almost always known at the same time. This method should be called once. Calling it again with the same values will have no effect.

### variant_type :: int

### obj_model_type :: int
