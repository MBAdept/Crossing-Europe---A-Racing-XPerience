# UPNPDevice :: <Native> class UPNPDevice extends RefCounted
Universal Plug and Play (UPnP) device.
Universal Plug and Play (UPnP) device. See [UPNP] for UPnP discovery and utility functions. Provides low-level access to UPNP control commands. Allows to manage port mappings (port forwarding) and to query network information of the device (like local and external IP address and status). Note that methods on this class are synchronous and block the calling thread.

## IGD_STATUS_OK :: const UPNPDevice.IGD_STATUS_OK: IGDStatus = 0
OK.

## IGD_STATUS_HTTP_ERROR :: const UPNPDevice.IGD_STATUS_HTTP_ERROR: IGDStatus = 1
HTTP error.

## IGD_STATUS_HTTP_EMPTY :: const UPNPDevice.IGD_STATUS_HTTP_EMPTY: IGDStatus = 2
Empty HTTP response.

## IGD_STATUS_NO_URLS :: const UPNPDevice.IGD_STATUS_NO_URLS: IGDStatus = 3
Returned response contained no URLs.

## IGD_STATUS_NO_IGD :: const UPNPDevice.IGD_STATUS_NO_IGD: IGDStatus = 4
Not a valid IGD.

## IGD_STATUS_DISCONNECTED :: const UPNPDevice.IGD_STATUS_DISCONNECTED: IGDStatus = 5
Disconnected.

## IGD_STATUS_UNKNOWN_DEVICE :: const UPNPDevice.IGD_STATUS_UNKNOWN_DEVICE: IGDStatus = 6
Unknown device.

## IGD_STATUS_INVALID_CONTROL :: const UPNPDevice.IGD_STATUS_INVALID_CONTROL: IGDStatus = 7
Invalid control.

## IGD_STATUS_MALLOC_ERROR :: const UPNPDevice.IGD_STATUS_MALLOC_ERROR: IGDStatus = 8
Memory allocation error.

## IGD_STATUS_UNKNOWN_ERROR :: const UPNPDevice.IGD_STATUS_UNKNOWN_ERROR: IGDStatus = 9
Unknown error.

## description_url :: var UPNPDevice.description_url: String
URL to the device description.

## igd_control_url :: var UPNPDevice.igd_control_url: String
IDG control URL.

## igd_our_addr :: var UPNPDevice.igd_our_addr: String
Address of the local machine in the network connecting it to this [UPNPDevice].

## igd_service_type :: var UPNPDevice.igd_service_type: String
IGD service type.

## igd_status :: var UPNPDevice.igd_status: UPNPDevice.IGDStatus
IGD status.

## service_type :: var UPNPDevice.service_type: String
Service type.

## add_port_mapping :: func UPNPDevice.add_port_mapping(port: int, port_internal: int = 0, desc: String = "", proto: String = "UDP", duration: int = 0) -> int
Adds a port mapping to forward the given external port on this [UPNPDevice] for the given protocol to the local machine. See [method UPNP.add_port_mapping].

### port :: int

### port_internal :: int

### desc :: String

### proto :: String

### duration :: int

## delete_port_mapping :: func UPNPDevice.delete_port_mapping(port: int, proto: String = "UDP") -> int
Deletes the port mapping identified by the given port and protocol combination on this device. See [method UPNP.delete_port_mapping].

### port :: int

### proto :: String

## is_valid_gateway :: func UPNPDevice.is_valid_gateway() -> bool
Returns [code]true[/code] if this is a valid IGD (InternetGatewayDevice) which potentially supports port forwarding.

## query_external_address :: func UPNPDevice.query_external_address() -> String
Returns the external IP address of this [UPNPDevice] or an empty string.
