# VisualShaderNodeParticleRandomness :: <Native> class VisualShaderNodeParticleRandomness extends VisualShaderNode
Visual shader node for randomizing particle values.
Randomness node will output pseudo-random values of the given type based on the specified minimum and maximum values.

## OP_TYPE_SCALAR :: const VisualShaderNodeParticleRandomness.OP_TYPE_SCALAR: OpType = 0
A floating-point scalar.

## OP_TYPE_VECTOR_2D :: const VisualShaderNodeParticleRandomness.OP_TYPE_VECTOR_2D: OpType = 1
A 2D vector type.

## OP_TYPE_VECTOR_3D :: const VisualShaderNodeParticleRandomness.OP_TYPE_VECTOR_3D: OpType = 2
A 3D vector type.

## OP_TYPE_VECTOR_4D :: const VisualShaderNodeParticleRandomness.OP_TYPE_VECTOR_4D: OpType = 3
A 4D vector type.

## OP_TYPE_MAX :: const VisualShaderNodeParticleRandomness.OP_TYPE_MAX: OpType = 4
Represents the size of the [enum OpType] enum.

## op_type :: var VisualShaderNodeParticleRandomness.op_type: VisualShaderNodeParticleRandomness.OpType
A type of operands and returned value.
