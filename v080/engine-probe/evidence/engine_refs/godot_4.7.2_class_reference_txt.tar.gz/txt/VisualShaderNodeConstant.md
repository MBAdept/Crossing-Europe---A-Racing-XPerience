# VisualShaderNodeConstant :: <Native> class VisualShaderNodeConstant extends VisualShaderNode
A base type for the constants within the visual shader graph.
This is an abstract class. See the derived types for descriptions of the possible values.
