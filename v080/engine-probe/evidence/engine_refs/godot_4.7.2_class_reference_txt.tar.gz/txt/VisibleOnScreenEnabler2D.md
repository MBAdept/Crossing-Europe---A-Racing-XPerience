# VisibleOnScreenEnabler2D :: <Native> class VisibleOnScreenEnabler2D extends VisibleOnScreenNotifier2D
A rectangular region of 2D space that, when visible on screen, enables a target node.
[VisibleOnScreenEnabler2D] contains a rectangular region of 2D space and a target node. The target node will be automatically enabled (via its [member Node.process_mode] property) when any part of this region becomes visible on the screen, and automatically disabled otherwise. This can for example be used to activate enemies only when the player approaches them.
See [VisibleOnScreenNotifier2D] if you only want to be notified when the region is visible on screen.
[b]Note:[/b] [VisibleOnScreenEnabler2D] uses the render culling code to determine whether it's visible on screen, so it won't function unless [member CanvasItem.visible] is set to [code]true[/code].

## ENABLE_MODE_INHERIT :: const VisibleOnScreenEnabler2D.ENABLE_MODE_INHERIT: EnableMode = 0
Corresponds to [constant Node.PROCESS_MODE_INHERIT].

## ENABLE_MODE_ALWAYS :: const VisibleOnScreenEnabler2D.ENABLE_MODE_ALWAYS: EnableMode = 1
Corresponds to [constant Node.PROCESS_MODE_ALWAYS].

## ENABLE_MODE_WHEN_PAUSED :: const VisibleOnScreenEnabler2D.ENABLE_MODE_WHEN_PAUSED: EnableMode = 2
Corresponds to [constant Node.PROCESS_MODE_WHEN_PAUSED].

## enable_mode :: var VisibleOnScreenEnabler2D.enable_mode: VisibleOnScreenEnabler2D.EnableMode
Determines how the target node is enabled. Corresponds to [enum Node.ProcessMode]. When the node is disabled, it always uses [constant Node.PROCESS_MODE_DISABLED].

## enable_node_path :: var VisibleOnScreenEnabler2D.enable_node_path: NodePath
The path to the target node, relative to the [VisibleOnScreenEnabler2D]. The target node is cached; it's only assigned when setting this property (if the [VisibleOnScreenEnabler2D] is inside the scene tree) and every time the [VisibleOnScreenEnabler2D] enters the scene tree. If the path is empty, no node will be affected. If the path is invalid, an error is also generated.
