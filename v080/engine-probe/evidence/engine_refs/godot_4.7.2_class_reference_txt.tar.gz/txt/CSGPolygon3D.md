# CSGPolygon3D :: <Native> class CSGPolygon3D extends CSGPrimitive3D
Extrudes a 2D polygon shape to create a 3D mesh.
An array of 2D points is extruded to quickly and easily create a variety of 3D meshes. See also [CSGMesh3D] for using 3D meshes as CSG nodes.
[b]Note:[/b] CSG nodes are intended to be used for level prototyping. Creating CSG nodes has a significant CPU cost compared to creating a [MeshInstance3D] with a [PrimitiveMesh]. Moving a CSG node within another CSG node also has a significant CPU cost, so it should be avoided during gameplay.

## MODE_DEPTH :: const CSGPolygon3D.MODE_DEPTH: Mode = 0
The [member polygon] shape is extruded along the negative Z axis.

## MODE_SPIN :: const CSGPolygon3D.MODE_SPIN: Mode = 1
The [member polygon] shape is extruded by rotating it around the Y axis.

## MODE_PATH :: const CSGPolygon3D.MODE_PATH: Mode = 2
The [member polygon] shape is extruded along the [Path3D] specified in [member path_node].

## PATH_ROTATION_POLYGON :: const CSGPolygon3D.PATH_ROTATION_POLYGON: PathRotation = 0
The [member polygon] shape is not rotated.
[b]Note:[/b] Requires the path Z coordinates to continually decrease to ensure viable shapes.

## PATH_ROTATION_PATH :: const CSGPolygon3D.PATH_ROTATION_PATH: PathRotation = 1
The [member polygon] shape is rotated along the path, but it is not rotated around the path axis.
[b]Note:[/b] Requires the path Z coordinates to continually decrease to ensure viable shapes.

## PATH_ROTATION_PATH_FOLLOW :: const CSGPolygon3D.PATH_ROTATION_PATH_FOLLOW: PathRotation = 2
The [member polygon] shape follows the path and its rotations around the path axis.

## PATH_INTERVAL_DISTANCE :: const CSGPolygon3D.PATH_INTERVAL_DISTANCE: PathIntervalType = 0
When [member mode] is set to [constant MODE_PATH], [member path_interval] will determine the distance, in meters, each interval of the path will extrude.

## PATH_INTERVAL_SUBDIVIDE :: const CSGPolygon3D.PATH_INTERVAL_SUBDIVIDE: PathIntervalType = 1
When [member mode] is set to [constant MODE_PATH], [member path_interval] will subdivide the polygons along the path.

## depth :: var CSGPolygon3D.depth: float
When [member mode] is [constant MODE_DEPTH], the depth of the extrusion.

## material :: var CSGPolygon3D.material: Material
Material to use for the resulting mesh. The UV maps the top half of the material to the extruded shape (U along the length of the extrusions and V around the outline of the [member polygon]), the bottom-left quarter to the front end face, and the bottom-right quarter to the back end face.

## mode :: var CSGPolygon3D.mode: CSGPolygon3D.Mode
The [member mode] used to extrude the [member polygon].

## path_continuous_u :: var CSGPolygon3D.path_continuous_u: bool
When [member mode] is [constant MODE_PATH], by default, the top half of the [member material] is stretched along the entire length of the extruded shape. If [code]false[/code] the top half of the material is repeated every step of the extrusion.

## path_interval :: var CSGPolygon3D.path_interval: float
When [member mode] is [constant MODE_PATH], the path interval or ratio of path points to extrusions.

## path_interval_type :: var CSGPolygon3D.path_interval_type: CSGPolygon3D.PathIntervalType
When [member mode] is [constant MODE_PATH], this will determine if the interval should be by distance ([constant PATH_INTERVAL_DISTANCE]) or subdivision fractions ([constant PATH_INTERVAL_SUBDIVIDE]).

## path_joined :: var CSGPolygon3D.path_joined: bool
When [member mode] is [constant MODE_PATH], if [code]true[/code] the ends of the path are joined, by adding an extrusion between the last and first points of the path.

## path_local :: var CSGPolygon3D.path_local: bool
When [member mode] is [constant MODE_PATH], if [code]true[/code] the [Transform3D] of the [CSGPolygon3D] is used as the starting point for the extrusions, not the [Transform3D] of the [member path_node].

## path_node :: var CSGPolygon3D.path_node: NodePath
When [member mode] is [constant MODE_PATH], the location of the [Path3D] object used to extrude the [member polygon].

## path_rotation :: var CSGPolygon3D.path_rotation: CSGPolygon3D.PathRotation
When [member mode] is [constant MODE_PATH], the path rotation method used to rotate the [member polygon] as it is extruded.

## path_rotation_accurate :: var CSGPolygon3D.path_rotation_accurate: bool
When [member mode] is [constant MODE_PATH], if [code]true[/code] the polygon will be rotated according to the proper tangent of the path at the sampled points. If [code]false[/code] an approximation is used, which decreases in accuracy as the number of subdivisions decreases.

## path_simplify_angle :: var CSGPolygon3D.path_simplify_angle: float
When [member mode] is [constant MODE_PATH], extrusions that are less than this angle, will be merged together to reduce polygon count.

## path_u_distance :: var CSGPolygon3D.path_u_distance: float
When [member mode] is [constant MODE_PATH], this is the distance along the path, in meters, the texture coordinates will tile. When set to 0, texture coordinates will match geometry exactly with no tiling.

## polygon :: var CSGPolygon3D.polygon: PackedVector2Array
The point array that defines the 2D polygon that is extruded. This can be a convex or concave polygon with 3 or more points. The polygon must [i]not[/i] have any intersecting edges. Otherwise, triangulation will fail and no mesh will be generated.
[b]Note:[/b] If only 1 or 2 points are defined in [member polygon], no mesh will be generated.

## smooth_faces :: var CSGPolygon3D.smooth_faces: bool
If [code]true[/code], applies smooth shading to the extrusions.

## spin_degrees :: var CSGPolygon3D.spin_degrees: float
When [member mode] is [constant MODE_SPIN], the total number of degrees the [member polygon] is rotated when extruding.

## spin_sides :: var CSGPolygon3D.spin_sides: int
When [member mode] is [constant MODE_SPIN], the number of extrusions made.
