# AudioStreamOggVorbis :: <Native> class AudioStreamOggVorbis extends AudioStream
A class representing an Ogg Vorbis audio stream.
The AudioStreamOggVorbis class is a specialized [AudioStream] for handling Ogg Vorbis file formats. It offers functionality for loading and playing back Ogg Vorbis files, as well as managing looping and other playback properties. More info can be found in [ResourceImporterOggVorbis].
This class is part of the audio stream system, which also supports WAV files through the [AudioStreamWAV] class, and MP3 files through the [AudioStreamMP3] class.

## bar_beats :: var AudioStreamOggVorbis.bar_beats: int
The number of beats within a single bar in the audio track.

## beat_count :: var AudioStreamOggVorbis.beat_count: int
The length of the audio track, in beats. The actual duration of the audio file might be longer than what is indicated by this property. It defines the end of the audio for looping, [AudioStreamPlaylist], and [AudioStreamInteractive].

## bpm :: var AudioStreamOggVorbis.bpm: float
The tempo of the audio track, measured in beats per minute.

## loop :: var AudioStreamOggVorbis.loop: bool
If [code]true[/code], the stream will play again from the specified [member loop_offset] once it reaches the end of the audio track, or once it reaches the end of the last beat according to the amount specified in [member beat_count]. Useful for ambient sounds and background music.

## loop_offset :: var AudioStreamOggVorbis.loop_offset: float
Time in seconds at which the stream starts after being looped.

## packet_sequence :: var AudioStreamOggVorbis.packet_sequence: OggPacketSequence
Contains the raw Ogg data for this stream.

## tags :: var AudioStreamOggVorbis.tags: Dictionary
Contains user-defined tags if found in the Ogg Vorbis data.
Commonly used tags include [code]title[/code], [code]artist[/code], [code]album[/code], [code]tracknumber[/code], and [code]date[/code] ([code]date[/code] does not have a standard date format).
[b]Note:[/b] No tag is [i]guaranteed[/i] to be present in every file, so make sure to account for the keys not always existing.

## load_from_buffer :: func AudioStreamOggVorbis.load_from_buffer(stream_data: PackedByteArray) -> AudioStreamOggVorbis
Creates a new [AudioStreamOggVorbis] instance from the given buffer. The buffer must contain Ogg Vorbis data.

### stream_data :: PackedByteArray

## load_from_file :: func AudioStreamOggVorbis.load_from_file(path: String) -> AudioStreamOggVorbis
Creates a new [AudioStreamOggVorbis] instance from the given file path. The file must be in Ogg Vorbis format.

### path :: String
