# TwoBoneIK3D :: <Native> class TwoBoneIK3D extends IKModifier3D
Rotation based intersection of two circles inverse kinematics solver.
This [IKModifier3D] requires a pole target. It provides deterministic results by constructing a plane from each joint and pole target and finding the intersection of two circles (disks in 3D).
This IK can handle twist by setting the pole direction. If there are more than one bone between each set bone, their rotations are ignored, and the straight line connecting the root-middle and middle-end joints are treated as virtual bones.
[b]Note:[/b] All the methods in this class take an [code]index[/code] parameter. This parameter specifies which setting list entry to return if the IK has multiple entries (e.g. [code]settings/<index>/root_bone_name[/code]).

## setting_count :: var TwoBoneIK3D.setting_count: int
The number of settings.

## get_end_bone :: func TwoBoneIK3D.get_end_bone(index: int) -> int
Returns the end bone index.

### index :: int

## get_end_bone_direction :: func TwoBoneIK3D.get_end_bone_direction(index: int) -> int
Returns the end bone's tail direction when [method is_end_bone_extended] is [code]true[/code].

### index :: int

## get_end_bone_length :: func TwoBoneIK3D.get_end_bone_length(index: int) -> float
Returns the end bone tail length of the bone chain when [method is_end_bone_extended] is [code]true[/code].

### index :: int

## get_end_bone_name :: func TwoBoneIK3D.get_end_bone_name(index: int) -> String
Returns the end bone name.

### index :: int

## get_middle_bone :: func TwoBoneIK3D.get_middle_bone(index: int) -> int
Returns the middle bone index.

### index :: int

## get_middle_bone_name :: func TwoBoneIK3D.get_middle_bone_name(index: int) -> String
Returns the middle bone name.

### index :: int

## get_pole_direction :: func TwoBoneIK3D.get_pole_direction(index: int) -> int
Returns the pole direction.

### index :: int

## get_pole_direction_vector :: func TwoBoneIK3D.get_pole_direction_vector(index: int) -> Vector3
Returns the pole direction vector.
If [method get_pole_direction] is [constant SkeletonModifier3D.SECONDARY_DIRECTION_NONE], this method returns [code]Vector3(0, 0, 0)[/code].

### index :: int

## get_pole_node :: func TwoBoneIK3D.get_pole_node(index: int) -> NodePath
Returns the pole target node that constructs a plane which the joints are all on and the pole is trying to direct.

### index :: int

## get_root_bone :: func TwoBoneIK3D.get_root_bone(index: int) -> int
Returns the root bone index.

### index :: int

## get_root_bone_name :: func TwoBoneIK3D.get_root_bone_name(index: int) -> String
Returns the root bone name.

### index :: int

## get_target_node :: func TwoBoneIK3D.get_target_node(index: int) -> NodePath
Returns the target node that the end bone is trying to reach.

### index :: int

## is_end_bone_extended :: func TwoBoneIK3D.is_end_bone_extended(index: int) -> bool
Returns [code]true[/code] if the end bone is extended to have a tail.

### index :: int

## is_using_virtual_end :: func TwoBoneIK3D.is_using_virtual_end(index: int) -> bool
Returns [code]true[/code] if the end bone is extended from the middle bone as a virtual bone.

### index :: int

## set_end_bone :: func TwoBoneIK3D.set_end_bone(index: int, bone: int) -> void
Sets the end bone index.

### index :: int

### bone :: int

## set_end_bone_direction :: func TwoBoneIK3D.set_end_bone_direction(index: int, bone_direction: int) -> void
Sets the end bone tail direction when [method is_end_bone_extended] is [code]true[/code].

### index :: int

### bone_direction :: int

## set_end_bone_length :: func TwoBoneIK3D.set_end_bone_length(index: int, length: float) -> void
Sets the end bone tail length when [method is_end_bone_extended] is [code]true[/code].

### index :: int

### length :: float

## set_end_bone_name :: func TwoBoneIK3D.set_end_bone_name(index: int, bone_name: String) -> void
Sets the end bone name.
[b]Note:[/b] The end bone must be a child of the middle bone.

### index :: int

### bone_name :: String

## set_extend_end_bone :: func TwoBoneIK3D.set_extend_end_bone(index: int, enabled: bool) -> void
If [param enabled] is [code]true[/code], the end bone is extended to have a tail.

### index :: int

### enabled :: bool

## set_middle_bone :: func TwoBoneIK3D.set_middle_bone(index: int, bone: int) -> void
Sets the middle bone index.

### index :: int

### bone :: int

## set_middle_bone_name :: func TwoBoneIK3D.set_middle_bone_name(index: int, bone_name: String) -> void
Sets the middle bone name.
[b]Note:[/b] The middle bone must be a child of the root bone.

### index :: int

### bone_name :: String

## set_pole_direction :: func TwoBoneIK3D.set_pole_direction(index: int, direction: int) -> void
Sets the pole direction.
The pole is on the middle bone and will direct to the pole target.
The rotation axis is a vector that is orthogonal to this and the forward vector.
[b]Note:[/b] The pole direction and the forward vector shouldn't be colinear to avoid unintended rotation.

### index :: int

### direction :: int

## set_pole_direction_vector :: func TwoBoneIK3D.set_pole_direction_vector(index: int, vector: Vector3) -> void
Sets the pole direction vector.
This vector is normalized by an internal process.
If the vector length is [code]0[/code], it is considered synonymous with [constant SkeletonModifier3D.SECONDARY_DIRECTION_NONE].

### index :: int

### vector :: Vector3

## set_pole_node :: func TwoBoneIK3D.set_pole_node(index: int, pole_node: NodePath) -> void
Sets the pole target node that constructs a plane which the joints are all on and the pole is trying to direct.

### index :: int

### pole_node :: NodePath

## set_root_bone :: func TwoBoneIK3D.set_root_bone(index: int, bone: int) -> void
Sets the root bone index.

### index :: int

### bone :: int

## set_root_bone_name :: func TwoBoneIK3D.set_root_bone_name(index: int, bone_name: String) -> void
Sets the root bone name.

### index :: int

### bone_name :: String

## set_target_node :: func TwoBoneIK3D.set_target_node(index: int, target_node: NodePath) -> void
Sets the target node that the end bone is trying to reach.

### index :: int

### target_node :: NodePath

## set_use_virtual_end :: func TwoBoneIK3D.set_use_virtual_end(index: int, enabled: bool) -> void
If [param enabled] is [code]true[/code], the end bone is extended from the middle bone as a virtual bone.

### index :: int

### enabled :: bool
