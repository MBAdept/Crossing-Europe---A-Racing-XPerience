# RDPipelineRasterizationState :: <Native> class RDPipelineRasterizationState extends RefCounted
Pipeline rasterization state (used by [RenderingDevice]).
This object is used by [RenderingDevice].

## cull_mode :: var RDPipelineRasterizationState.cull_mode: RenderingDevice.PolygonCullMode
The cull mode to use when drawing polygons, which determines whether front faces or backfaces are hidden.

## depth_bias_clamp :: var RDPipelineRasterizationState.depth_bias_clamp: float
A limit for how much each depth value can be offset. If negative, it serves as a minimum value, but if positive, it serves as a maximum value.

## depth_bias_constant_factor :: var RDPipelineRasterizationState.depth_bias_constant_factor: float
A constant offset added to each depth value. Applied after [member depth_bias_slope_factor].

## depth_bias_enabled :: var RDPipelineRasterizationState.depth_bias_enabled: bool
If [code]true[/code], each generated depth value will by offset by some amount. The specific amount is generated per polygon based on the values of [member depth_bias_slope_factor] and [member depth_bias_constant_factor].

## depth_bias_slope_factor :: var RDPipelineRasterizationState.depth_bias_slope_factor: float
A constant scale applied to the slope of each polygons' depth. Applied before [member depth_bias_constant_factor].

## discard_primitives :: var RDPipelineRasterizationState.discard_primitives: bool
If [code]true[/code], primitives are discarded immediately before the rasterization stage.

## enable_depth_clamp :: var RDPipelineRasterizationState.enable_depth_clamp: bool
If [code]true[/code], clamps depth values according to the minimum and maximum depth of the associated viewport.

## front_face :: var RDPipelineRasterizationState.front_face: RenderingDevice.PolygonFrontFace
The winding order to use to determine which face of a triangle is considered its front face.

## line_width :: var RDPipelineRasterizationState.line_width: float
The line width to use when drawing lines (in pixels). Thick lines may not be supported on all hardware.

## patch_control_points :: var RDPipelineRasterizationState.patch_control_points: int
The number of control points to use when drawing a patch with tessellation enabled. Higher values result in higher quality at the cost of performance.

## wireframe :: var RDPipelineRasterizationState.wireframe: bool
If [code]true[/code], performs wireframe rendering for triangles instead of flat or textured rendering.
