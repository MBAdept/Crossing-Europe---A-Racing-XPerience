# NavigationAgent2D :: <Native> class NavigationAgent2D extends Node
A 2D agent used to pathfind to a position while avoiding obstacles.
A 2D agent used to pathfind to a position while avoiding static and dynamic obstacles. The calculation can be used by the parent node to dynamically move it along the path. Requires navigation data to work correctly.
Dynamic obstacles are avoided using RVO collision avoidance. Avoidance is computed before physics, so the pathfinding information can be used safely in the physics step.
[b]Note:[/b] After setting the [member target_position] property, the [method get_next_path_position] method must be used once every physics frame to update the internal path logic of the navigation agent. The vector position it returns should be used as the next movement position for the agent's parent node.
[b]Note:[/b] Several methods of this class, such as [method get_next_path_position], can trigger a new path calculation. Calling these in your callback to an agent's signal, such as [signal waypoint_reached], can cause infinite recursion. It is recommended to call these methods in the physics step or, alternatively, delay their call until the end of the frame (see [method Object.call_deferred] or [constant Object.CONNECT_DEFERRED]).

## avoidance_enabled :: var NavigationAgent2D.avoidance_enabled: bool
If [code]true[/code] the agent is registered for an RVO avoidance callback on the [NavigationServer2D]. When [member velocity] is used and the processing is completed a [code]safe_velocity[/code] Vector2 is received with a signal connection to [signal velocity_computed]. Avoidance processing with many registered agents has a significant performance cost and should only be enabled on agents that currently require it.

## avoidance_layers :: var NavigationAgent2D.avoidance_layers: int
A bitfield determining the avoidance layers for this NavigationAgent. Other agents with a matching bit on the [member avoidance_mask] will avoid this agent.

## avoidance_mask :: var NavigationAgent2D.avoidance_mask: int
A bitfield determining what other avoidance agents and obstacles this NavigationAgent will avoid when a bit matches at least one of their [member avoidance_layers].

## avoidance_priority :: var NavigationAgent2D.avoidance_priority: float
The agent does not adjust the velocity for other agents that would match the [member avoidance_mask] but have a lower [member avoidance_priority]. This in turn makes the other agents with lower priority adjust their velocities even more to avoid collision with this agent.

## debug_enabled :: var NavigationAgent2D.debug_enabled: bool
If [code]true[/code] shows debug visuals for this agent.

## debug_path_custom_color :: var NavigationAgent2D.debug_path_custom_color: Color
If [member debug_use_custom] is [code]true[/code] uses this color for this agent instead of global color.

## debug_path_custom_line_width :: var NavigationAgent2D.debug_path_custom_line_width: float
If [member debug_use_custom] is [code]true[/code] uses this line width for rendering paths for this agent instead of global line width.

## debug_path_custom_point_size :: var NavigationAgent2D.debug_path_custom_point_size: float
If [member debug_use_custom] is [code]true[/code] uses this rasterized point size for rendering path points for this agent instead of global point size.

## debug_use_custom :: var NavigationAgent2D.debug_use_custom: bool
If [code]true[/code] uses the defined [member debug_path_custom_color] for this agent instead of global color.

## max_neighbors :: var NavigationAgent2D.max_neighbors: int
The maximum number of neighbors for the agent to consider.

## max_speed :: var NavigationAgent2D.max_speed: float
The maximum speed that an agent can move.

## navigation_layers :: var NavigationAgent2D.navigation_layers: int
A bitfield determining which navigation layers of navigation regions this agent will use to calculate a path. Changing it during runtime will clear the current navigation path and generate a new one, according to the new navigation layers.

## neighbor_distance :: var NavigationAgent2D.neighbor_distance: float
The distance to search for other agents.

## path_desired_distance :: var NavigationAgent2D.path_desired_distance: float
The distance threshold before a path point is considered to be reached. This allows agents to not have to hit a path point on the path exactly, but only to reach its general area. If this value is set too high, the NavigationAgent will skip points on the path, which can lead to it leaving the navigation mesh. If this value is set too low, the NavigationAgent will be stuck in a repath loop because it will constantly overshoot the distance to the next point on each physics frame update.

## path_max_distance :: var NavigationAgent2D.path_max_distance: float
The maximum distance the agent is allowed away from the ideal path to the final position. This can happen due to trying to avoid collisions. When the maximum distance is exceeded, it recalculates the ideal path.

## path_metadata_flags :: var NavigationAgent2D.path_metadata_flags: NavigationPathQueryParameters2D.PathMetadataFlags
Additional information to return with the navigation path.

## path_postprocessing :: var NavigationAgent2D.path_postprocessing: NavigationPathQueryParameters2D.PathPostProcessing
The path postprocessing applied to the raw path corridor found by the [member pathfinding_algorithm].

## path_return_max_length :: var NavigationAgent2D.path_return_max_length: float
The maximum allowed length of the returned path in world units. A path will be clipped when going over this length.

## path_return_max_radius :: var NavigationAgent2D.path_return_max_radius: float
The maximum allowed radius in world units that the returned path can be from the path start. The path will be clipped when going over this radius. Compared to [member path_return_max_length], this allows the agent to go that much further, if they need to walk around a corner.
[b]Note:[/b] This will perform a sphere clip considering only the actual navigation mesh path points with the first path position being the sphere's center.

## path_search_max_distance :: var NavigationAgent2D.path_search_max_distance: float
The maximum distance a searched polygon can be away from the start polygon before the pathfinding cancels the search for a path to the (possibly unreachable or very far away) target position polygon. In this case the pathfinding resets and builds a path from the start polygon to the polygon that was found closest to the target position so far. A value of [code]0[/code] or below counts as unlimited. In case of unlimited the pathfinding will search all polygons connected with the start polygon until either the target position polygon is found or all available polygon search options are exhausted.

## path_search_max_polygons :: var NavigationAgent2D.path_search_max_polygons: int
The maximum number of polygons that are searched before the pathfinding cancels the search for a path to the (possibly unreachable or very far away) target position polygon. In this case the pathfinding resets and builds a path from the start polygon to the polygon that was found closest to the target position so far. A value of [code]0[/code] or below counts as unlimited. In case of unlimited the pathfinding will search all polygons connected with the start polygon until either the target position polygon is found or all available polygon search options are exhausted.

## pathfinding_algorithm :: var NavigationAgent2D.pathfinding_algorithm: NavigationPathQueryParameters2D.PathfindingAlgorithm
The pathfinding algorithm used in the path query.

## radius :: var NavigationAgent2D.radius: float
The radius of the avoidance agent. This is the "body" of the avoidance agent and not the avoidance maneuver starting radius (which is controlled by [member neighbor_distance]).
Does not affect normal pathfinding. To change an actor's pathfinding radius bake [NavigationPolygon] resources with a different [member NavigationPolygon.agent_radius] property and use different navigation maps for each actor size.

## simplify_epsilon :: var NavigationAgent2D.simplify_epsilon: float
The path simplification amount in worlds units.

## simplify_path :: var NavigationAgent2D.simplify_path: bool
If [code]true[/code] a simplified version of the path will be returned with less critical path points removed. The simplification amount is controlled by [member simplify_epsilon]. The simplification uses a variant of Ramer-Douglas-Peucker algorithm for curve point decimation.
Path simplification can be helpful to mitigate various path following issues that can arise with certain agent types and script behaviors. E.g. "steering" agents or avoidance in "open fields".

## target_desired_distance :: var NavigationAgent2D.target_desired_distance: float
The distance threshold before the target is considered to be reached. On reaching the target, [signal target_reached] is emitted and navigation ends (see [method is_navigation_finished] and [signal navigation_finished]).
You can make navigation end early by setting this property to a value greater than [member path_desired_distance] (navigation will end before reaching the last waypoint).
You can also make navigation end closer to the target than each individual path position by setting this property to a value lower than [member path_desired_distance] (navigation won't immediately end when reaching the last waypoint). However, if the value set is too low, the agent will be stuck in a repath loop because it will constantly overshoot the distance to the target on each physics frame update.

## target_position :: var NavigationAgent2D.target_position: Vector2
If set, a new navigation path from the current agent position to the [member target_position] is requested from the NavigationServer.

## time_horizon_agents :: var NavigationAgent2D.time_horizon_agents: float
The minimal amount of time for which this agent's velocities, that are computed with the collision avoidance algorithm, are safe with respect to other agents. The larger the number, the sooner the agent will respond to other agents, but less freedom in choosing its velocities. A too high value will slow down agents movement considerably. Must be positive.

## time_horizon_obstacles :: var NavigationAgent2D.time_horizon_obstacles: float
The minimal amount of time for which this agent's velocities, that are computed with the collision avoidance algorithm, are safe with respect to static avoidance obstacles. The larger the number, the sooner the agent will respond to static avoidance obstacles, but less freedom in choosing its velocities. A too high value will slow down agents movement considerably. Must be positive.

## velocity :: var NavigationAgent2D.velocity: Vector2
Sets the new wanted velocity for the agent. The avoidance simulation will try to fulfill this velocity if possible but will modify it to avoid collision with other agents and obstacles. When an agent is teleported to a new position, use [method set_velocity_forced] as well to reset the internal simulation velocity.

## distance_to_target :: func NavigationAgent2D.distance_to_target() -> float
Returns the distance to the target position, using the agent's global position. The user must set [member target_position] in order for this to be accurate.

## get_avoidance_layer_value :: func NavigationAgent2D.get_avoidance_layer_value(layer_number: int) -> bool
Returns whether or not the specified layer of the [member avoidance_layers] bitmask is enabled, given a [param layer_number] between 1 and 32.

### layer_number :: int

## get_avoidance_mask_value :: func NavigationAgent2D.get_avoidance_mask_value(mask_number: int) -> bool
Returns whether or not the specified mask of the [member avoidance_mask] bitmask is enabled, given a [param mask_number] between 1 and 32.

### mask_number :: int

## get_current_navigation_path :: func NavigationAgent2D.get_current_navigation_path() -> PackedVector2Array
Returns this agent's current path from start to finish in global coordinates. The path only updates when the target position is changed or the agent requires a repath. The path array is not intended to be used in direct path movement as the agent has its own internal path logic that would get corrupted by changing the path array manually. Use the intended [method get_next_path_position] once every physics frame to receive the next path point for the agents movement as this function also updates the internal path logic.

## get_current_navigation_path_index :: func NavigationAgent2D.get_current_navigation_path_index() -> int
Returns which index the agent is currently on in the navigation path's [PackedVector2Array].

## get_current_navigation_result :: func NavigationAgent2D.get_current_navigation_result() -> NavigationPathQueryResult2D
Returns the path query result for the path the agent is currently following.

## get_final_position :: func NavigationAgent2D.get_final_position() -> Vector2
Returns the reachable final position of the current navigation path in global coordinates. This position can change if the agent needs to update the navigation path which makes the agent emit the [signal path_changed] signal.

## get_navigation_layer_value :: func NavigationAgent2D.get_navigation_layer_value(layer_number: int) -> bool
Returns whether or not the specified layer of the [member navigation_layers] bitmask is enabled, given a [param layer_number] between 1 and 32.

### layer_number :: int

## get_navigation_map :: func NavigationAgent2D.get_navigation_map() -> RID
Returns the [RID] of the navigation map for this NavigationAgent node. This function returns always the map set on the NavigationAgent node and not the map of the abstract agent on the NavigationServer. If the agent map is changed directly with the NavigationServer API the NavigationAgent node will not be aware of the map change. Use [method set_navigation_map] to change the navigation map for the NavigationAgent and also update the agent on the NavigationServer.

## get_next_path_position :: func NavigationAgent2D.get_next_path_position() -> Vector2
Returns the next position in global coordinates that can be moved to, making sure that there are no static objects in the way. If the agent does not have a navigation path, it will return the position of the agent's parent. The use of this function once every physics frame is required to update the internal path logic of the NavigationAgent.

## get_path_length :: func NavigationAgent2D.get_path_length() -> float
Returns the length of the currently calculated path. The returned value is [code]0.0[/code], if the path is still calculating or no calculation has been requested yet.

## get_rid :: func NavigationAgent2D.get_rid() -> RID
Returns the [RID] of this agent on the [NavigationServer2D].

## is_navigation_finished :: func NavigationAgent2D.is_navigation_finished() -> bool
Returns [code]true[/code] if the agent's navigation has finished. If the target is reachable, navigation ends when the target is reached. If the target is unreachable, navigation ends when the last waypoint of the path is reached.
[b]Note:[/b] While [code]true[/code] prefer to stop calling update functions like [method get_next_path_position]. This avoids jittering the standing agent due to calling repeated path updates.

## is_target_reachable :: func NavigationAgent2D.is_target_reachable() -> bool
Returns [code]true[/code] if [method get_final_position] is within [member target_desired_distance] of the [member target_position].

## is_target_reached :: func NavigationAgent2D.is_target_reached() -> bool
Returns [code]true[/code] if the agent reached the target, i.e. the agent moved within [member target_desired_distance] of the [member target_position]. It may not always be possible to reach the target but it should always be possible to reach the final position. See [method get_final_position].

## set_avoidance_layer_value :: func NavigationAgent2D.set_avoidance_layer_value(layer_number: int, value: bool) -> void
Based on [param value], enables or disables the specified layer in the [member avoidance_layers] bitmask, given a [param layer_number] between 1 and 32.

### layer_number :: int

### value :: bool

## set_avoidance_mask_value :: func NavigationAgent2D.set_avoidance_mask_value(mask_number: int, value: bool) -> void
Based on [param value], enables or disables the specified mask in the [member avoidance_mask] bitmask, given a [param mask_number] between 1 and 32.

### mask_number :: int

### value :: bool

## set_navigation_layer_value :: func NavigationAgent2D.set_navigation_layer_value(layer_number: int, value: bool) -> void
Based on [param value], enables or disables the specified layer in the [member navigation_layers] bitmask, given a [param layer_number] between 1 and 32.

### layer_number :: int

### value :: bool

## set_navigation_map :: func NavigationAgent2D.set_navigation_map(navigation_map: RID) -> void
Sets the [RID] of the navigation map this NavigationAgent node should use and also updates the [code]agent[/code] on the NavigationServer.

### navigation_map :: RID

## set_velocity_forced :: func NavigationAgent2D.set_velocity_forced(velocity: Vector2) -> void
Replaces the internal velocity in the collision avoidance simulation with [param velocity]. When an agent is teleported to a new position this function should be used in the same frame. If called frequently this function can get agents stuck.

### velocity :: Vector2

## link_reached :: func NavigationAgent2D.link_reached(details: Dictionary) -> void
Signals that the agent reached a navigation link. Emitted when the agent moves within [member path_desired_distance] of the next position of the path when that position is a navigation link.
The details dictionary may contain the following keys depending on the value of [member path_metadata_flags]:
- [code]position[/code]: The start position of the link that was reached.
- [code]type[/code]: Always [constant NavigationPathQueryResult2D.PATH_SEGMENT_TYPE_LINK].
- [code]rid[/code]: The [RID] of the link.
- [code]owner[/code]: The object which manages the link (usually [NavigationLink2D]).
- [code]link_entry_position[/code]: If [code]owner[/code] is available and the owner is a [NavigationLink2D], it will contain the global position of the link's point the agent is entering.
- [code]link_exit_position[/code]: If [code]owner[/code] is available and the owner is a [NavigationLink2D], it will contain the global position of the link's point which the agent is exiting.

### details :: Dictionary

## navigation_finished :: func NavigationAgent2D.navigation_finished() -> void
Signals that the agent's navigation has finished. If the target is reachable, navigation ends when the target is reached. If the target is unreachable, navigation ends when the last waypoint of the path is reached. This signal is emitted only once per loaded path.
This signal will be emitted just after [signal target_reached] when the target is reachable.

## path_changed :: func NavigationAgent2D.path_changed() -> void
Emitted when the agent had to update the loaded path:
- because path was previously empty.
- because navigation map has changed.
- because agent pushed further away from the current path segment than the [member path_max_distance].

## target_reached :: func NavigationAgent2D.target_reached() -> void
Signals that the agent reached the target, i.e. the agent moved within [member target_desired_distance] of the [member target_position]. This signal is emitted only once per loaded path.
This signal will be emitted just before [signal navigation_finished] when the target is reachable.
It may not always be possible to reach the target but it should always be possible to reach the final position. See [method get_final_position].

## velocity_computed :: func NavigationAgent2D.velocity_computed(safe_velocity: Vector2) -> void
Notifies when the collision avoidance velocity is calculated. Emitted every update as long as [member avoidance_enabled] is [code]true[/code] and the agent has a navigation map.

### safe_velocity :: Vector2

## waypoint_reached :: func NavigationAgent2D.waypoint_reached(details: Dictionary) -> void
Signals that the agent reached a waypoint. Emitted when the agent moves within [member path_desired_distance] of the next position of the path.
The details dictionary may contain the following keys depending on the value of [member path_metadata_flags]:
- [code]position[/code]: The position of the waypoint that was reached.
- [code]type[/code]: The type of navigation primitive (region or link) that contains this waypoint.
- [code]rid[/code]: The [RID] of the containing navigation primitive (region or link).
- [code]owner[/code]: The object which manages the containing navigation primitive (region or link).

### details :: Dictionary
