# XRBodyTracker :: <Native> class XRBodyTracker extends XRPositionalTracker
A tracked body in XR.
A body tracking system will create an instance of this object and add it to the [XRServer]. This tracking system will then obtain skeleton data, convert it to the Godot Humanoid skeleton and store this data on the [XRBodyTracker] object.
Use [XRBodyModifier3D] to animate a body mesh using body tracking data.

## BODY_FLAG_UPPER_BODY_SUPPORTED :: const XRBodyTracker.BODY_FLAG_UPPER_BODY_SUPPORTED: BodyFlags = 1
Upper body tracking supported.

## BODY_FLAG_LOWER_BODY_SUPPORTED :: const XRBodyTracker.BODY_FLAG_LOWER_BODY_SUPPORTED: BodyFlags = 2
Lower body tracking supported.

## BODY_FLAG_HANDS_SUPPORTED :: const XRBodyTracker.BODY_FLAG_HANDS_SUPPORTED: BodyFlags = 4
Hand tracking supported.

## JOINT_ROOT :: const XRBodyTracker.JOINT_ROOT: Joint = 0
Root joint.

## JOINT_HIPS :: const XRBodyTracker.JOINT_HIPS: Joint = 1
Hips joint.

## JOINT_SPINE :: const XRBodyTracker.JOINT_SPINE: Joint = 2
Spine joint.

## JOINT_CHEST :: const XRBodyTracker.JOINT_CHEST: Joint = 3
Chest joint.

## JOINT_UPPER_CHEST :: const XRBodyTracker.JOINT_UPPER_CHEST: Joint = 4
Upper chest joint.

## JOINT_NECK :: const XRBodyTracker.JOINT_NECK: Joint = 5
Neck joint.

## JOINT_HEAD :: const XRBodyTracker.JOINT_HEAD: Joint = 6
Head joint.

## JOINT_HEAD_TIP :: const XRBodyTracker.JOINT_HEAD_TIP: Joint = 7
Head tip joint.

## JOINT_LEFT_SHOULDER :: const XRBodyTracker.JOINT_LEFT_SHOULDER: Joint = 8
Left shoulder joint.

## JOINT_LEFT_UPPER_ARM :: const XRBodyTracker.JOINT_LEFT_UPPER_ARM: Joint = 9
Left upper arm joint.

## JOINT_LEFT_LOWER_ARM :: const XRBodyTracker.JOINT_LEFT_LOWER_ARM: Joint = 10
Left lower arm joint.

## JOINT_RIGHT_SHOULDER :: const XRBodyTracker.JOINT_RIGHT_SHOULDER: Joint = 11
Right shoulder joint.

## JOINT_RIGHT_UPPER_ARM :: const XRBodyTracker.JOINT_RIGHT_UPPER_ARM: Joint = 12
Right upper arm joint.

## JOINT_RIGHT_LOWER_ARM :: const XRBodyTracker.JOINT_RIGHT_LOWER_ARM: Joint = 13
Right lower arm joint.

## JOINT_LEFT_UPPER_LEG :: const XRBodyTracker.JOINT_LEFT_UPPER_LEG: Joint = 14
Left upper leg joint.

## JOINT_LEFT_LOWER_LEG :: const XRBodyTracker.JOINT_LEFT_LOWER_LEG: Joint = 15
Left lower leg joint.

## JOINT_LEFT_FOOT :: const XRBodyTracker.JOINT_LEFT_FOOT: Joint = 16
Left foot joint.

## JOINT_LEFT_TOES :: const XRBodyTracker.JOINT_LEFT_TOES: Joint = 17
Left toes joint.

## JOINT_RIGHT_UPPER_LEG :: const XRBodyTracker.JOINT_RIGHT_UPPER_LEG: Joint = 18
Right upper leg joint.

## JOINT_RIGHT_LOWER_LEG :: const XRBodyTracker.JOINT_RIGHT_LOWER_LEG: Joint = 19
Right lower leg joint.

## JOINT_RIGHT_FOOT :: const XRBodyTracker.JOINT_RIGHT_FOOT: Joint = 20
Right foot joint.

## JOINT_RIGHT_TOES :: const XRBodyTracker.JOINT_RIGHT_TOES: Joint = 21
Right toes joint.

## JOINT_LEFT_HAND :: const XRBodyTracker.JOINT_LEFT_HAND: Joint = 22
Left hand joint.

## JOINT_LEFT_PALM :: const XRBodyTracker.JOINT_LEFT_PALM: Joint = 23
Left palm joint.

## JOINT_LEFT_WRIST :: const XRBodyTracker.JOINT_LEFT_WRIST: Joint = 24
Left wrist joint.

## JOINT_LEFT_THUMB_METACARPAL :: const XRBodyTracker.JOINT_LEFT_THUMB_METACARPAL: Joint = 25
Left thumb metacarpal joint.

## JOINT_LEFT_THUMB_PHALANX_PROXIMAL :: const XRBodyTracker.JOINT_LEFT_THUMB_PHALANX_PROXIMAL: Joint = 26
Left thumb phalanx proximal joint.

## JOINT_LEFT_THUMB_PHALANX_DISTAL :: const XRBodyTracker.JOINT_LEFT_THUMB_PHALANX_DISTAL: Joint = 27
Left thumb phalanx distal joint.

## JOINT_LEFT_THUMB_TIP :: const XRBodyTracker.JOINT_LEFT_THUMB_TIP: Joint = 28
Left thumb tip joint.

## JOINT_LEFT_INDEX_FINGER_METACARPAL :: const XRBodyTracker.JOINT_LEFT_INDEX_FINGER_METACARPAL: Joint = 29
Left index finger metacarpal joint.

## JOINT_LEFT_INDEX_FINGER_PHALANX_PROXIMAL :: const XRBodyTracker.JOINT_LEFT_INDEX_FINGER_PHALANX_PROXIMAL: Joint = 30
Left index finger phalanx proximal joint.

## JOINT_LEFT_INDEX_FINGER_PHALANX_INTERMEDIATE :: const XRBodyTracker.JOINT_LEFT_INDEX_FINGER_PHALANX_INTERMEDIATE: Joint = 31
Left index finger phalanx intermediate joint.

## JOINT_LEFT_INDEX_FINGER_PHALANX_DISTAL :: const XRBodyTracker.JOINT_LEFT_INDEX_FINGER_PHALANX_DISTAL: Joint = 32
Left index finger phalanx distal joint.

## JOINT_LEFT_INDEX_FINGER_TIP :: const XRBodyTracker.JOINT_LEFT_INDEX_FINGER_TIP: Joint = 33
Left index finger tip joint.

## JOINT_LEFT_MIDDLE_FINGER_METACARPAL :: const XRBodyTracker.JOINT_LEFT_MIDDLE_FINGER_METACARPAL: Joint = 34
Left middle finger metacarpal joint.

## JOINT_LEFT_MIDDLE_FINGER_PHALANX_PROXIMAL :: const XRBodyTracker.JOINT_LEFT_MIDDLE_FINGER_PHALANX_PROXIMAL: Joint = 35
Left middle finger phalanx proximal joint.

## JOINT_LEFT_MIDDLE_FINGER_PHALANX_INTERMEDIATE :: const XRBodyTracker.JOINT_LEFT_MIDDLE_FINGER_PHALANX_INTERMEDIATE: Joint = 36
Left middle finger phalanx intermediate joint.

## JOINT_LEFT_MIDDLE_FINGER_PHALANX_DISTAL :: const XRBodyTracker.JOINT_LEFT_MIDDLE_FINGER_PHALANX_DISTAL: Joint = 37
Left middle finger phalanx distal joint.

## JOINT_LEFT_MIDDLE_FINGER_TIP :: const XRBodyTracker.JOINT_LEFT_MIDDLE_FINGER_TIP: Joint = 38
Left middle finger tip joint.

## JOINT_LEFT_RING_FINGER_METACARPAL :: const XRBodyTracker.JOINT_LEFT_RING_FINGER_METACARPAL: Joint = 39
Left ring finger metacarpal joint.

## JOINT_LEFT_RING_FINGER_PHALANX_PROXIMAL :: const XRBodyTracker.JOINT_LEFT_RING_FINGER_PHALANX_PROXIMAL: Joint = 40
Left ring finger phalanx proximal joint.

## JOINT_LEFT_RING_FINGER_PHALANX_INTERMEDIATE :: const XRBodyTracker.JOINT_LEFT_RING_FINGER_PHALANX_INTERMEDIATE: Joint = 41
Left ring finger phalanx intermediate joint.

## JOINT_LEFT_RING_FINGER_PHALANX_DISTAL :: const XRBodyTracker.JOINT_LEFT_RING_FINGER_PHALANX_DISTAL: Joint = 42
Left ring finger phalanx distal joint.

## JOINT_LEFT_RING_FINGER_TIP :: const XRBodyTracker.JOINT_LEFT_RING_FINGER_TIP: Joint = 43
Left ring finger tip joint.

## JOINT_LEFT_PINKY_FINGER_METACARPAL :: const XRBodyTracker.JOINT_LEFT_PINKY_FINGER_METACARPAL: Joint = 44
Left pinky finger metacarpal joint.

## JOINT_LEFT_PINKY_FINGER_PHALANX_PROXIMAL :: const XRBodyTracker.JOINT_LEFT_PINKY_FINGER_PHALANX_PROXIMAL: Joint = 45
Left pinky finger phalanx proximal joint.

## JOINT_LEFT_PINKY_FINGER_PHALANX_INTERMEDIATE :: const XRBodyTracker.JOINT_LEFT_PINKY_FINGER_PHALANX_INTERMEDIATE: Joint = 46
Left pinky finger phalanx intermediate joint.

## JOINT_LEFT_PINKY_FINGER_PHALANX_DISTAL :: const XRBodyTracker.JOINT_LEFT_PINKY_FINGER_PHALANX_DISTAL: Joint = 47
Left pinky finger phalanx distal joint.

## JOINT_LEFT_PINKY_FINGER_TIP :: const XRBodyTracker.JOINT_LEFT_PINKY_FINGER_TIP: Joint = 48
Left pinky finger tip joint.

## JOINT_RIGHT_HAND :: const XRBodyTracker.JOINT_RIGHT_HAND: Joint = 49
Right hand joint.

## JOINT_RIGHT_PALM :: const XRBodyTracker.JOINT_RIGHT_PALM: Joint = 50
Right palm joint.

## JOINT_RIGHT_WRIST :: const XRBodyTracker.JOINT_RIGHT_WRIST: Joint = 51
Right wrist joint.

## JOINT_RIGHT_THUMB_METACARPAL :: const XRBodyTracker.JOINT_RIGHT_THUMB_METACARPAL: Joint = 52
Right thumb metacarpal joint.

## JOINT_RIGHT_THUMB_PHALANX_PROXIMAL :: const XRBodyTracker.JOINT_RIGHT_THUMB_PHALANX_PROXIMAL: Joint = 53
Right thumb phalanx proximal joint.

## JOINT_RIGHT_THUMB_PHALANX_DISTAL :: const XRBodyTracker.JOINT_RIGHT_THUMB_PHALANX_DISTAL: Joint = 54
Right thumb phalanx distal joint.

## JOINT_RIGHT_THUMB_TIP :: const XRBodyTracker.JOINT_RIGHT_THUMB_TIP: Joint = 55
Right thumb tip joint.

## JOINT_RIGHT_INDEX_FINGER_METACARPAL :: const XRBodyTracker.JOINT_RIGHT_INDEX_FINGER_METACARPAL: Joint = 56
Right index finger metacarpal joint.

## JOINT_RIGHT_INDEX_FINGER_PHALANX_PROXIMAL :: const XRBodyTracker.JOINT_RIGHT_INDEX_FINGER_PHALANX_PROXIMAL: Joint = 57
Right index finger phalanx proximal joint.

## JOINT_RIGHT_INDEX_FINGER_PHALANX_INTERMEDIATE :: const XRBodyTracker.JOINT_RIGHT_INDEX_FINGER_PHALANX_INTERMEDIATE: Joint = 58
Right index finger phalanx intermediate joint.

## JOINT_RIGHT_INDEX_FINGER_PHALANX_DISTAL :: const XRBodyTracker.JOINT_RIGHT_INDEX_FINGER_PHALANX_DISTAL: Joint = 59
Right index finger phalanx distal joint.

## JOINT_RIGHT_INDEX_FINGER_TIP :: const XRBodyTracker.JOINT_RIGHT_INDEX_FINGER_TIP: Joint = 60
Right index finger tip joint.

## JOINT_RIGHT_MIDDLE_FINGER_METACARPAL :: const XRBodyTracker.JOINT_RIGHT_MIDDLE_FINGER_METACARPAL: Joint = 61
Right middle finger metacarpal joint.

## JOINT_RIGHT_MIDDLE_FINGER_PHALANX_PROXIMAL :: const XRBodyTracker.JOINT_RIGHT_MIDDLE_FINGER_PHALANX_PROXIMAL: Joint = 62
Right middle finger phalanx proximal joint.

## JOINT_RIGHT_MIDDLE_FINGER_PHALANX_INTERMEDIATE :: const XRBodyTracker.JOINT_RIGHT_MIDDLE_FINGER_PHALANX_INTERMEDIATE: Joint = 63
Right middle finger phalanx intermediate joint.

## JOINT_RIGHT_MIDDLE_FINGER_PHALANX_DISTAL :: const XRBodyTracker.JOINT_RIGHT_MIDDLE_FINGER_PHALANX_DISTAL: Joint = 64
Right middle finger phalanx distal joint.

## JOINT_RIGHT_MIDDLE_FINGER_TIP :: const XRBodyTracker.JOINT_RIGHT_MIDDLE_FINGER_TIP: Joint = 65
Right middle finger tip joint.

## JOINT_RIGHT_RING_FINGER_METACARPAL :: const XRBodyTracker.JOINT_RIGHT_RING_FINGER_METACARPAL: Joint = 66
Right ring finger metacarpal joint.

## JOINT_RIGHT_RING_FINGER_PHALANX_PROXIMAL :: const XRBodyTracker.JOINT_RIGHT_RING_FINGER_PHALANX_PROXIMAL: Joint = 67
Right ring finger phalanx proximal joint.

## JOINT_RIGHT_RING_FINGER_PHALANX_INTERMEDIATE :: const XRBodyTracker.JOINT_RIGHT_RING_FINGER_PHALANX_INTERMEDIATE: Joint = 68
Right ring finger phalanx intermediate joint.

## JOINT_RIGHT_RING_FINGER_PHALANX_DISTAL :: const XRBodyTracker.JOINT_RIGHT_RING_FINGER_PHALANX_DISTAL: Joint = 69
Right ring finger phalanx distal joint.

## JOINT_RIGHT_RING_FINGER_TIP :: const XRBodyTracker.JOINT_RIGHT_RING_FINGER_TIP: Joint = 70
Right ring finger tip joint.

## JOINT_RIGHT_PINKY_FINGER_METACARPAL :: const XRBodyTracker.JOINT_RIGHT_PINKY_FINGER_METACARPAL: Joint = 71
Right pinky finger metacarpal joint.

## JOINT_RIGHT_PINKY_FINGER_PHALANX_PROXIMAL :: const XRBodyTracker.JOINT_RIGHT_PINKY_FINGER_PHALANX_PROXIMAL: Joint = 72
Right pinky finger phalanx proximal joint.

## JOINT_RIGHT_PINKY_FINGER_PHALANX_INTERMEDIATE :: const XRBodyTracker.JOINT_RIGHT_PINKY_FINGER_PHALANX_INTERMEDIATE: Joint = 73
Right pinky finger phalanx intermediate joint.

## JOINT_RIGHT_PINKY_FINGER_PHALANX_DISTAL :: const XRBodyTracker.JOINT_RIGHT_PINKY_FINGER_PHALANX_DISTAL: Joint = 74
Right pinky finger phalanx distal joint.

## JOINT_RIGHT_PINKY_FINGER_TIP :: const XRBodyTracker.JOINT_RIGHT_PINKY_FINGER_TIP: Joint = 75
Right pinky finger tip joint.

## JOINT_LOWER_CHEST :: const XRBodyTracker.JOINT_LOWER_CHEST: Joint = 76
Lower chest joint.

## JOINT_LEFT_SCAPULA :: const XRBodyTracker.JOINT_LEFT_SCAPULA: Joint = 77
Left scapula joint.

## JOINT_LEFT_WRIST_TWIST :: const XRBodyTracker.JOINT_LEFT_WRIST_TWIST: Joint = 78
Left wrist twist joint.

## JOINT_RIGHT_SCAPULA :: const XRBodyTracker.JOINT_RIGHT_SCAPULA: Joint = 79
Right scapula joint.

## JOINT_RIGHT_WRIST_TWIST :: const XRBodyTracker.JOINT_RIGHT_WRIST_TWIST: Joint = 80
Right wrist twist joint.

## JOINT_LEFT_FOOT_TWIST :: const XRBodyTracker.JOINT_LEFT_FOOT_TWIST: Joint = 81
Left foot twist joint.

## JOINT_LEFT_HEEL :: const XRBodyTracker.JOINT_LEFT_HEEL: Joint = 82
Left heel joint.

## JOINT_LEFT_MIDDLE_FOOT :: const XRBodyTracker.JOINT_LEFT_MIDDLE_FOOT: Joint = 83
Left middle foot joint.

## JOINT_RIGHT_FOOT_TWIST :: const XRBodyTracker.JOINT_RIGHT_FOOT_TWIST: Joint = 84
Right foot twist joint.

## JOINT_RIGHT_HEEL :: const XRBodyTracker.JOINT_RIGHT_HEEL: Joint = 85
Right heel joint.

## JOINT_RIGHT_MIDDLE_FOOT :: const XRBodyTracker.JOINT_RIGHT_MIDDLE_FOOT: Joint = 86
Right middle foot joint.

## JOINT_MAX :: const XRBodyTracker.JOINT_MAX: Joint = 87
Represents the size of the [enum Joint] enum.

## JOINT_FLAG_ORIENTATION_VALID :: const XRBodyTracker.JOINT_FLAG_ORIENTATION_VALID: JointFlags = 1
The joint's orientation data is valid.

## JOINT_FLAG_ORIENTATION_TRACKED :: const XRBodyTracker.JOINT_FLAG_ORIENTATION_TRACKED: JointFlags = 2
The joint's orientation is actively tracked. May not be set if tracking has been temporarily lost.

## JOINT_FLAG_POSITION_VALID :: const XRBodyTracker.JOINT_FLAG_POSITION_VALID: JointFlags = 4
The joint's position data is valid.

## JOINT_FLAG_POSITION_TRACKED :: const XRBodyTracker.JOINT_FLAG_POSITION_TRACKED: JointFlags = 8
The joint's position is actively tracked. May not be set if tracking has been temporarily lost.

## body_flags :: var XRBodyTracker.body_flags: XRBodyTracker.BodyFlags
The type of body tracking data captured.

## has_tracking_data :: var XRBodyTracker.has_tracking_data: bool
If [code]true[/code], the body tracking data is valid.

## type :: var XRBodyTracker.type: XRServer.TrackerType

## get_joint_flags :: func XRBodyTracker.get_joint_flags(joint: int) -> int
Returns flags about the validity of the tracking data for the given body joint.

### joint :: int

## get_joint_transform :: func XRBodyTracker.get_joint_transform(joint: int) -> Transform3D
Returns the transform for the given body joint.

### joint :: int

## set_joint_flags :: func XRBodyTracker.set_joint_flags(joint: int, flags: int) -> void
Sets flags about the validity of the tracking data for the given body joint.

### joint :: int

### flags :: int

## set_joint_transform :: func XRBodyTracker.set_joint_transform(joint: int, transform: Transform3D) -> void
Sets the transform for the given body joint.

### joint :: int

### transform :: Transform3D
