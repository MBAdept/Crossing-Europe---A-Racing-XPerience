# Texture2DRD :: <Native> class Texture2DRD extends Texture2D
Texture for 2D that is bound to a texture created on the [RenderingDevice].
This texture class allows you to use a 2D texture created directly on the [RenderingDevice] as a texture for materials, meshes, etc.
[b]Note:[/b] [Texture2DRD] is intended for low-level usage with [RenderingDevice]. For most use cases, use [Texture2D] instead.

## resource_local_to_scene :: var Texture2DRD.resource_local_to_scene: bool

## texture_rd_rid :: var Texture2DRD.texture_rd_rid: RID
The RID of the texture object created on the [RenderingDevice].
