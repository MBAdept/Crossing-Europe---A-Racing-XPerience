# Parallax2D :: <Native> class Parallax2D extends Node2D
A node used to create a parallax scrolling background.
A [Parallax2D] is used to create a parallax effect. It can move at a different speed relative to the camera movement using [member scroll_scale]. This creates an illusion of depth in a 2D game. If manual scrolling is desired, the [Camera2D] position can be ignored with [member ignore_camera_scroll].
[b]Note:[/b] Any changes to this node's position made after it enters the scene tree will be overridden if [member ignore_camera_scroll] is [code]false[/code] or [member screen_offset] is modified.

## autoscroll :: var Parallax2D.autoscroll: Vector2
Velocity at which the offset scrolls automatically, in pixels per second.

## follow_viewport :: var Parallax2D.follow_viewport: bool
If [code]true[/code], this [Parallax2D] is offset by the current camera's position. If the [Parallax2D] is in a [CanvasLayer] separate from the current camera, it may be desired to match the value with [member CanvasLayer.follow_viewport_enabled].

## ignore_camera_scroll :: var Parallax2D.ignore_camera_scroll: bool
If [code]true[/code], [Parallax2D]'s position is not affected by the position of the camera.

## limit_begin :: var Parallax2D.limit_begin: Vector2
Top-left limits for scrolling to begin. If the camera is outside of this limit, the [Parallax2D] stops scrolling. Must be lower than [member limit_end] minus the viewport size to work.

## limit_end :: var Parallax2D.limit_end: Vector2
Bottom-right limits for scrolling to end. If the camera is outside of this limit, the [Parallax2D] will stop scrolling. Must be higher than [member limit_begin] and the viewport size combined to work.

## physics_interpolation_mode :: var Parallax2D.physics_interpolation_mode: Node.PhysicsInterpolationMode

## repeat_size :: var Parallax2D.repeat_size: Vector2
Repeats the [Texture2D] of each of this node's children and offsets them by this value. When scrolling, the node's position loops, giving the illusion of an infinite scrolling background if the values are larger than the screen size. If an axis is set to [code]0[/code], the [Texture2D] will not be repeated.

## repeat_times :: var Parallax2D.repeat_times: int
Overrides the amount of times the texture repeats. Each texture copy spreads evenly from the original by [member repeat_size]. Useful for when zooming out with a camera.

## screen_offset :: var Parallax2D.screen_offset: Vector2
Offset used to scroll this [Parallax2D]. This value is updated automatically unless [member ignore_camera_scroll] is [code]true[/code].

## scroll_offset :: var Parallax2D.scroll_offset: Vector2
The [Parallax2D]'s offset. Similar to [member screen_offset] and [member Node2D.position], but will not be overridden.
[b]Note:[/b] Values will loop if [member repeat_size] is set higher than [code]0[/code].

## scroll_scale :: var Parallax2D.scroll_scale: Vector2
Multiplier to the final [Parallax2D]'s offset. Can be used to simulate distance from the camera.
For example, a value of [code]1[/code] scrolls at the same speed as the camera. A value greater than [code]1[/code] scrolls faster, making objects appear closer. Less than [code]1[/code] scrolls slower, making objects appear further, and a value of [code]0[/code] stops the objects completely.
