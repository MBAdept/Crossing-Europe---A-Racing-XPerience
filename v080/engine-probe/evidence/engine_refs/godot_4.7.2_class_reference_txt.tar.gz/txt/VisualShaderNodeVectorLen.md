# VisualShaderNodeVectorLen :: <Native> class VisualShaderNodeVectorLen extends VisualShaderNodeVectorBase
Returns the length of a [Vector3] within the visual shader graph.
Translated to [code]length(p0)[/code] in the shader language.
