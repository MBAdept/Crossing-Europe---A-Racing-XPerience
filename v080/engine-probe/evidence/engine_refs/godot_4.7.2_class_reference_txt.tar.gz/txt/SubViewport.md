# SubViewport :: <Native> class SubViewport extends Viewport
An interface to a game world that doesn't create a window or draw to the screen directly.
[SubViewport] Isolates a rectangular region of a scene to be displayed independently. This can be used, for example, to display UI in 3D space.
[b]Note:[/b] [SubViewport] is a [Viewport] that isn't a [Window], i.e. it doesn't draw anything by itself. To display anything, [SubViewport] must have a non-zero size and be either put inside a [SubViewportContainer] or assigned to a [ViewportTexture].
[b]Note:[/b] [InputEvent]s are not passed to a standalone [SubViewport] by default. To ensure [InputEvent] propagation, a [SubViewport] can be placed inside of a [SubViewportContainer].

## CLEAR_MODE_ALWAYS :: const SubViewport.CLEAR_MODE_ALWAYS: ClearMode = 0
Always clear the render target before drawing.

## CLEAR_MODE_NEVER :: const SubViewport.CLEAR_MODE_NEVER: ClearMode = 1
Never clear the render target.

## CLEAR_MODE_ONCE :: const SubViewport.CLEAR_MODE_ONCE: ClearMode = 2
Clear the render target on the next frame, then switch to [constant CLEAR_MODE_NEVER].

## UPDATE_DISABLED :: const SubViewport.UPDATE_DISABLED: UpdateMode = 0
Do not update the render target.

## UPDATE_ONCE :: const SubViewport.UPDATE_ONCE: UpdateMode = 1
Update the render target once, then switch to [constant UPDATE_DISABLED].

## UPDATE_WHEN_VISIBLE :: const SubViewport.UPDATE_WHEN_VISIBLE: UpdateMode = 2
Update the render target only when it is visible. This is the default value.

## UPDATE_WHEN_PARENT_VISIBLE :: const SubViewport.UPDATE_WHEN_PARENT_VISIBLE: UpdateMode = 3
Update the render target only when its parent is visible.

## UPDATE_ALWAYS :: const SubViewport.UPDATE_ALWAYS: UpdateMode = 4
Always update the render target.

## render_target_clear_mode :: var SubViewport.render_target_clear_mode: SubViewport.ClearMode
The clear mode when the sub-viewport is used as a render target.
[b]Note:[/b] This property is intended for 2D usage.

## render_target_update_mode :: var SubViewport.render_target_update_mode: SubViewport.UpdateMode
The update mode when the sub-viewport is used as a render target.

## size :: var SubViewport.size: Vector2i
The width and height of the sub-viewport. Must be set to a value greater than or equal to 2 pixels on both dimensions. Otherwise, nothing will be displayed.
[b]Note:[/b] If the parent node is a [SubViewportContainer] and its [member SubViewportContainer.stretch] is [code]true[/code], the viewport size cannot be changed manually.

## size_2d_override :: var SubViewport.size_2d_override: Vector2i
The 2D size override of the sub-viewport. If either the width or height is [code]0[/code], the override is disabled.

## size_2d_override_stretch :: var SubViewport.size_2d_override_stretch: bool
If [code]true[/code], the 2D size override affects stretch as well.

## view_count :: var SubViewport.view_count: int
The number of view layers we are rendering to. Set this to [code]2[/code] to enable stereo rendering.
