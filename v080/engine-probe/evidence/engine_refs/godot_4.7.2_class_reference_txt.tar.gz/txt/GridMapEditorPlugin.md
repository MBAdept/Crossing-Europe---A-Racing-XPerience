# GridMapEditorPlugin :: <Native> class GridMapEditorPlugin extends EditorPlugin
Editor for [GridMap] nodes.
GridMapEditorPlugin provides access to the [GridMap] editor functionality.

## clear_selection :: func GridMapEditorPlugin.clear_selection() -> void
Deselects any currently selected cells.

## get_current_grid_map :: func GridMapEditorPlugin.get_current_grid_map() -> GridMap
Returns the [GridMap] node currently edited by the grid map editor.

## get_selected_cells :: func GridMapEditorPlugin.get_selected_cells() -> Array
Returns an array of [Vector3i]s with the selected cells' coordinates.

## get_selected_palette_item :: func GridMapEditorPlugin.get_selected_palette_item() -> int
Returns the index of the selected [MeshLibrary] item in the grid map editor's palette or [code]-1[/code] if no item is selected.
[b]Note:[/b] The indices might not be in the same order as they appear in the editor's interface.

## get_selection :: func GridMapEditorPlugin.get_selection() -> AABB
Returns the cell coordinate bounds of the current selection. Use [method has_selection] to check if there is an active selection.

## has_selection :: func GridMapEditorPlugin.has_selection() -> bool
Returns [code]true[/code] if there are selected cells.

## set_selected_palette_item :: func GridMapEditorPlugin.set_selected_palette_item(item: int) -> void
Selects the [MeshLibrary] item with the given index in the grid map editor's palette. If a negative index is given, no item will be selected. If a value greater than the last index is given, the last item will be selected.
[b]Note:[/b] The indices might not be in the same order as they appear in the editor's interface.

### item :: int

## set_selection :: func GridMapEditorPlugin.set_selection(begin: Vector3i, end: Vector3i) -> void
Selects the cells inside the given bounds from [param begin] to [param end].

### begin :: Vector3i

### end :: Vector3i
