# ColorRect :: <Native> class ColorRect extends Control
A control that displays a solid color rectangle.
Displays a rectangle filled with a solid [member color]. If you need to display the border alone, consider using a [Panel] instead.

## color :: var ColorRect.color: Color
The fill color of the rectangle.
