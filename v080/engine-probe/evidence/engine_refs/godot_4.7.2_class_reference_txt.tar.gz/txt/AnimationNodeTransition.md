# AnimationNodeTransition :: <Native> class AnimationNodeTransition extends AnimationNodeSync
A transition within an [AnimationTree] connecting two [AnimationNode]s.
Simple state machine for cases which don't require a more advanced [AnimationNodeStateMachine]. Animations can be connected to the inputs and transition times can be specified.
After setting the request and changing the animation playback, the transition node automatically clears the request on the next process frame by setting its [code]transition_request[/code] value to empty.
[b]Note:[/b] When using a cross-fade, [code]current_state[/code] and [code]current_index[/code] change to the next state immediately after the cross-fade begins.
[codeblocks]
[gdscript]
# Play child animation connected to "state_2" port.
animation_tree.set("parameters/Transition/transition_request", "state_2")
# Alternative syntax (same result as above).
animation_tree["parameters/Transition/transition_request"] = "state_2"

# Get current state name (read-only).
animation_tree.get("parameters/Transition/current_state")
# Alternative syntax (same result as above).
animation_tree["parameters/Transition/current_state"]

# Get current state index (read-only).
animation_tree.get("parameters/Transition/current_index")
# Alternative syntax (same result as above).
animation_tree["parameters/Transition/current_index"]
[/gdscript]
[csharp]
// Play child animation connected to "state_2" port.
animationTree.Set("parameters/Transition/transition_request", "state_2");

// Get current state name (read-only).
animationTree.Get("parameters/Transition/current_state");

// Get current state index (read-only).
animationTree.Get("parameters/Transition/current_index");
[/csharp]
[/codeblocks]

## allow_transition_to_self :: var AnimationNodeTransition.allow_transition_to_self: bool
If [code]true[/code], allows transition to the self state. When the reset option is enabled in input, the animation is restarted. If [code]false[/code], nothing happens on the transition to the self state.

## input_count :: var AnimationNodeTransition.input_count: int
The number of enabled input ports for this animation node.

## xfade_curve :: var AnimationNodeTransition.xfade_curve: Curve
Determines how cross-fading between animations is eased. If empty, the transition will be linear. Should be a unit [Curve].

## xfade_time :: var AnimationNodeTransition.xfade_time: float
Cross-fading time (in seconds) between each animation connected to the inputs.
[b]Note:[/b] [AnimationNodeTransition] transitions the current state immediately after the start of the fading. The precise remaining time can only be inferred from the main animation. When [AnimationNodeOutput] is considered as the most upstream, so the [member xfade_time] is not scaled depending on the downstream delta. See also [member AnimationNodeOneShot.fadeout_time].

## is_input_loop_broken_at_end :: func AnimationNodeTransition.is_input_loop_broken_at_end(input: int) -> bool
Returns whether the animation breaks the loop at the end of the loop cycle for transition.

### input :: int

## is_input_reset :: func AnimationNodeTransition.is_input_reset(input: int) -> bool
Returns whether the animation restarts when the animation transitions from the other animation.

### input :: int

## is_input_set_as_auto_advance :: func AnimationNodeTransition.is_input_set_as_auto_advance(input: int) -> bool
Returns [code]true[/code] if auto-advance is enabled for the given [param input] index.

### input :: int

## set_input_as_auto_advance :: func AnimationNodeTransition.set_input_as_auto_advance(input: int, enable: bool) -> void
Enables or disables auto-advance for the given [param input] index. If enabled, state changes to the next input after playing the animation once. If enabled for the last input state, it loops to the first.

### input :: int

### enable :: bool

## set_input_break_loop_at_end :: func AnimationNodeTransition.set_input_break_loop_at_end(input: int, enable: bool) -> void
If [code]true[/code], breaks the loop at the end of the loop cycle for transition, even if the animation is looping.

### input :: int

### enable :: bool

## set_input_reset :: func AnimationNodeTransition.set_input_reset(input: int, enable: bool) -> void
If [code]true[/code], the destination animation is restarted when the animation transitions.

### input :: int

### enable :: bool
