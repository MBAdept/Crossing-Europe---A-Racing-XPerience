# TextureLayered :: <Native> class TextureLayered extends Texture
Base class for texture types which contain the data of multiple [Image]s. Each image is of the same size and format.
Base class for [ImageTextureLayered] and [CompressedTextureLayered]. Cannot be used directly, but contains all the functions necessary for accessing the derived resource types. See also [Texture3D].
Data is set on a per-layer basis. For [Texture2DArray]s, the layer specifies the array layer.
All images need to have the same width, height and number of mipmap levels.
A [TextureLayered] can be loaded with [method ResourceLoader.load].
Internally, Godot maps these files to their respective counterparts in the target rendering driver (Vulkan, OpenGL3).

## LAYERED_TYPE_2D_ARRAY :: const TextureLayered.LAYERED_TYPE_2D_ARRAY: LayeredType = 0
Texture is a generic [Texture2DArray].

## LAYERED_TYPE_CUBEMAP :: const TextureLayered.LAYERED_TYPE_CUBEMAP: LayeredType = 1
Texture is a [Cubemap], with each side in its own layer (6 in total).

## LAYERED_TYPE_CUBEMAP_ARRAY :: const TextureLayered.LAYERED_TYPE_CUBEMAP_ARRAY: LayeredType = 2
Texture is a [CubemapArray], with each cubemap being made of 6 layers.

## _get_format :: func TextureLayered._get_format() -> int
Called when the [TextureLayered]'s format is queried.

## _get_height :: func TextureLayered._get_height() -> int
Called when the [TextureLayered]'s height is queried.

## _get_layer_data :: func TextureLayered._get_layer_data(layer_index: int) -> Image
Called when the data for a layer in the [TextureLayered] is queried.

### layer_index :: int

## _get_layered_type :: func TextureLayered._get_layered_type() -> int
Called when the layers' type in the [TextureLayered] is queried.

## _get_layers :: func TextureLayered._get_layers() -> int
Called when the number of layers in the [TextureLayered] is queried.

## _get_width :: func TextureLayered._get_width() -> int
Called when the [TextureLayered]'s width queried.

## _has_mipmaps :: func TextureLayered._has_mipmaps() -> bool
Called when the presence of mipmaps in the [TextureLayered] is queried.

## get_format :: func TextureLayered.get_format() -> int
Returns the current format being used by this texture.

## get_height :: func TextureLayered.get_height() -> int
Returns the height of the texture in pixels. Height is typically represented by the Y axis.

## get_layer_data :: func TextureLayered.get_layer_data(layer: int) -> Image
Returns an [Image] resource with the data from specified [param layer].

### layer :: int

## get_layered_type :: func TextureLayered.get_layered_type() -> int
Returns the [TextureLayered]'s type. The type determines how the data is accessed, with cubemaps having special types.

## get_layers :: func TextureLayered.get_layers() -> int
Returns the number of referenced [Image]s.

## get_width :: func TextureLayered.get_width() -> int
Returns the width of the texture in pixels. Width is typically represented by the X axis.

## has_mipmaps :: func TextureLayered.has_mipmaps() -> bool
Returns [code]true[/code] if the layers have generated mipmaps.
