# StreamPeerExtension :: <Native> class StreamPeerExtension extends StreamPeer


## _get_available_bytes :: func StreamPeerExtension._get_available_bytes() -> int

## _get_data :: func StreamPeerExtension._get_data(r_buffer: uint8_t*, r_bytes: int, r_received: int32_t*) -> int

### r_buffer :: uint8_t*

### r_bytes :: int

### r_received :: int32_t*

## _get_partial_data :: func StreamPeerExtension._get_partial_data(r_buffer: uint8_t*, r_bytes: int, r_received: int32_t*) -> int

### r_buffer :: uint8_t*

### r_bytes :: int

### r_received :: int32_t*

## _put_data :: func StreamPeerExtension._put_data(data: const uint8_t*, bytes: int, r_sent: int32_t*) -> int

### data :: const uint8_t*

### bytes :: int

### r_sent :: int32_t*

## _put_partial_data :: func StreamPeerExtension._put_partial_data(data: const uint8_t*, bytes: int, r_sent: int32_t*) -> int

### data :: const uint8_t*

### bytes :: int

### r_sent :: int32_t*
