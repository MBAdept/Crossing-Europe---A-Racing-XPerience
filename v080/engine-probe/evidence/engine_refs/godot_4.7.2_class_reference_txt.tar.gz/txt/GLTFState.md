# GLTFState :: <Native> class GLTFState extends Resource
Represents all data of a glTF file.
Contains all nodes and resources of a glTF file. This is used by [GLTFDocument] as data storage, which allows [GLTFDocument] and all [GLTFDocumentExtension] classes to remain stateless.
GLTFState can be populated by [GLTFDocument] reading a file or by converting a Godot scene. Then the data can either be used to create a Godot scene or save to a glTF file. The code that converts to/from a Godot scene can be intercepted at arbitrary points by [GLTFDocumentExtension] classes. This allows for custom data to be stored in the glTF file or for custom data to be converted to/from Godot nodes.

## HANDLE_BINARY_IMAGE_MODE_DISCARD_TEXTURES :: const GLTFState.HANDLE_BINARY_IMAGE_MODE_DISCARD_TEXTURES: HandleBinaryImageMode = 0
When importing a glTF file with embedded binary images, discards all images and uses untextured materials in their place. Images stored as separate files in the [code]res://[/code] folder are not affected by this; those will be used as Godot imported them.

## HANDLE_BINARY_IMAGE_MODE_EXTRACT_TEXTURES :: const GLTFState.HANDLE_BINARY_IMAGE_MODE_EXTRACT_TEXTURES: HandleBinaryImageMode = 1
When importing a glTF file with embedded binary images, extracts them and saves them to their own files. This allows the image to be imported by Godot's image importer, which can then have their import options customized by the user, including optionally compressing the image to VRAM texture formats.
This will save the images's bytes exactly as-is, without recompression. For image formats supplied by glTF extensions, the file will have a filename ending with the file extension supplied by [method GLTFDocumentExtension._get_image_file_extension] of the extension class.
[b]Note:[/b] This option is editor-only. At runtime, this acts the same as [constant HANDLE_BINARY_IMAGE_MODE_EMBED_AS_UNCOMPRESSED].

## HANDLE_BINARY_IMAGE_MODE_EMBED_AS_BASISU :: const GLTFState.HANDLE_BINARY_IMAGE_MODE_EMBED_AS_BASISU: HandleBinaryImageMode = 2
When importing a glTF file with embedded binary images, embeds textures VRAM compressed with Basis Universal into the generated scene. Images stored as separate files in the [code]res://[/code] folder are not affected by this; those will be used as Godot imported them.

## HANDLE_BINARY_IMAGE_MODE_EMBED_AS_UNCOMPRESSED :: const GLTFState.HANDLE_BINARY_IMAGE_MODE_EMBED_AS_UNCOMPRESSED: HandleBinaryImageMode = 3
When importing a glTF file with embedded binary images, embeds textures compressed losslessly into the generated scene. Images stored as separate files in the [code]res://[/code] folder are not affected by this; those will be used as Godot imported them.

## HANDLE_BINARY_DISCARD_TEXTURES :: const GLTFState.HANDLE_BINARY_DISCARD_TEXTURES = 0
Discards all embedded textures and uses untextured materials.

## HANDLE_BINARY_EXTRACT_TEXTURES :: const GLTFState.HANDLE_BINARY_EXTRACT_TEXTURES = 1
Extracts embedded textures to be reimported and compressed. Editor only. Acts as uncompressed at runtime.

## HANDLE_BINARY_EMBED_AS_BASISU :: const GLTFState.HANDLE_BINARY_EMBED_AS_BASISU = 2
Embeds textures VRAM compressed with Basis Universal into the generated scene.

## HANDLE_BINARY_EMBED_AS_UNCOMPRESSED :: const GLTFState.HANDLE_BINARY_EMBED_AS_UNCOMPRESSED = 3
Embeds textures compressed losslessly into the generated scene, matching old behavior.

## bake_fps :: var GLTFState.bake_fps: float
The baking fps of the animation for either import or export.

## base_path :: var GLTFState.base_path: String
The folder path associated with this glTF data. This is used to find other files the glTF file references, like images or binary buffers. This will be set during import when appending from a file, and will be set during export when writing to a file.

## buffers :: var GLTFState.buffers: PackedByteArray[]

## copyright :: var GLTFState.copyright: String
The copyright string in the asset header of the glTF file. This is set during import if present and export if non-empty. See the glTF asset header documentation for more information.

## create_animations :: var GLTFState.create_animations: bool

## filename :: var GLTFState.filename: String
The file name associated with this glTF data. If it ends with [code].gltf[/code], this is text-based glTF, otherwise this is binary GLB. This will be set during import when appending from a file, and will be set during export when writing to a file. If writing to a buffer, this will be an empty string.

## glb_data :: var GLTFState.glb_data: PackedByteArray
The binary buffer attached to a .glb file.

## handle_binary_image_mode :: var GLTFState.handle_binary_image_mode: GLTFState.HandleBinaryImageMode
When importing a glTF file with unimported raw binary images embedded inside of binary blob buffers, in data URIs, or separate files not imported by Godot, this controls how the images are handled. Images can be discarded, saved as separate files, or embedded in the scene lossily or losslessly. See [enum HandleBinaryImageMode] for options.
This property does nothing for image files in the [code]res://[/code] folder imported by Godot, as those are handled by Godot's image importer directly, and then the Godot scene generated from the glTF file will use the images as Godot imported them.

## import_as_skeleton_bones :: var GLTFState.import_as_skeleton_bones: bool
If [code]true[/code], forces all GLTFNodes in the document to be bones of a single [Skeleton3D] Godot node.

## json :: var GLTFState.json: Dictionary
The original raw JSON document corresponding to this GLTFState.

## major_version :: var GLTFState.major_version: int

## minor_version :: var GLTFState.minor_version: int

## root_nodes :: var GLTFState.root_nodes: PackedInt32Array
The root nodes of the glTF file. Typically, a glTF file will only have one scene, and therefore one root node. However, a glTF file may have multiple scenes and therefore multiple root nodes, which will be generated as siblings of each other and as children of the root node of the generated Godot scene.

## scene_name :: var GLTFState.scene_name: String
The name of the scene. When importing, if not specified, this will be the file name. When exporting, if specified, the scene name will be saved to the glTF file.

## use_named_skin_binds :: var GLTFState.use_named_skin_binds: bool

## add_used_extension :: func GLTFState.add_used_extension(extension_name: String, required: bool) -> void
Appends an extension to the list of extensions used by this glTF file during serialization. If [param required] is [code]true[/code], the extension will also be added to the list of required extensions. Do not run this in [method GLTFDocumentExtension._export_post], as that stage is too late to add extensions. The final list is sorted alphabetically.

### extension_name :: String

### required :: bool

## append_data_to_buffers :: func GLTFState.append_data_to_buffers(data: PackedByteArray, deduplication: bool) -> int
Appends the given byte array [param data] to the buffers and creates a [GLTFBufferView] for it. The index of the destination [GLTFBufferView] is returned. If [param deduplication] is [code]true[/code], the buffers are first searched for duplicate data, otherwise new bytes are always appended.

### data :: PackedByteArray

### deduplication :: bool

## append_gltf_node :: func GLTFState.append_gltf_node(gltf_node: GLTFNode, godot_scene_node: Node, parent_node_index: int) -> int
Appends the given [GLTFNode] to the state, and returns its new index. This can be used to export one Godot node as multiple glTF nodes, or inject new glTF nodes at import time. On import, this must be called before [method GLTFDocumentExtension._generate_scene_node] finishes for the parent node. On export, this must be called before [method GLTFDocumentExtension._export_node] runs for the parent node.
The [param godot_scene_node] parameter is the Godot scene node that corresponds to this glTF node. This is highly recommended to be set to a valid node, but may be [code]null[/code] if there is no corresponding Godot scene node. One Godot scene node may be used for multiple glTF nodes, so if exporting multiple glTF nodes for one Godot scene node, use the same Godot scene node for each.
The [param parent_node_index] parameter is the index of the parent [GLTFNode] in the state. If [code]-1[/code], the node will be a root node, otherwise the new node will be added to the parent's list of children. The index will also be written to the [member GLTFNode.parent] property of the new node.

### gltf_node :: GLTFNode

### godot_scene_node :: Node

### parent_node_index :: int

## get_accessors :: func GLTFState.get_accessors() -> GLTFAccessor[]

## get_additional_data :: func GLTFState.get_additional_data(extension_name: StringName) -> Variant
Gets additional arbitrary data in this [GLTFState] instance. This can be used to keep per-file state data in [GLTFDocumentExtension] classes, which is important because they are stateless.
The argument should be the [GLTFDocumentExtension] name (does not have to match the extension name in the glTF file), and the return value can be anything you set. If nothing was set, the return value is [code]null[/code].

### extension_name :: StringName

## get_animation_player :: func GLTFState.get_animation_player(anim_player_index: int) -> AnimationPlayer
Returns the [AnimationPlayer] node with the given index. These nodes are only used during the export process when converting Godot [AnimationPlayer] nodes to glTF animations.

### anim_player_index :: int

## get_animation_players_count :: func GLTFState.get_animation_players_count(anim_player_index: int) -> int
Returns the number of [AnimationPlayer] nodes in this [GLTFState]. These nodes are only used during the export process when converting Godot [AnimationPlayer] nodes to glTF animations.

### anim_player_index :: int

## get_animations :: func GLTFState.get_animations() -> GLTFAnimation[]
Returns an array of all [GLTFAnimation]s in the glTF file. When importing, these will be generated as animations in an [AnimationPlayer] node. When exporting, these will be generated from Godot [AnimationPlayer] nodes.

## get_buffer_views :: func GLTFState.get_buffer_views() -> GLTFBufferView[]

## get_cameras :: func GLTFState.get_cameras() -> GLTFCamera[]
Returns an array of all [GLTFCamera]s in the glTF file. These are the cameras that the [member GLTFNode.camera] index refers to.

## get_handle_binary_image :: func GLTFState.get_handle_binary_image() -> int
Deprecated untyped alias for [member handle_binary_image_mode]. When importing a glTF file with unimported raw binary images embedded inside of binary blob buffers, in data URIs, or separate files not imported by Godot, this controls how the images are handled.

## get_images :: func GLTFState.get_images() -> Texture2D[]
Gets the images of the glTF file as an array of [Texture2D]s. These are the images that the [member GLTFTexture.src_image] index refers to.

## get_lights :: func GLTFState.get_lights() -> GLTFLight[]
Returns an array of all [GLTFLight]s in the glTF file. These are the lights that the [member GLTFNode.light] index refers to.

## get_materials :: func GLTFState.get_materials() -> Material[]

## get_meshes :: func GLTFState.get_meshes() -> GLTFMesh[]
Returns an array of all [GLTFMesh]es in the glTF file. These are the meshes that the [member GLTFNode.mesh] index refers to.

## get_node_index :: func GLTFState.get_node_index(scene_node: Node) -> int
Returns the index of the [GLTFNode] corresponding to this Godot scene node. This is the inverse of [method get_scene_node]. Useful during the export process.
[b]Note:[/b] Not every Godot scene node will have a corresponding [GLTFNode], and not every [GLTFNode] will have a scene node generated. If there is no [GLTFNode] index for this scene node, [code]-1[/code] is returned.

### scene_node :: Node

## get_nodes :: func GLTFState.get_nodes() -> GLTFNode[]
Returns an array of all [GLTFNode]s in the glTF file. These are the nodes that [member GLTFNode.children] and [member root_nodes] refer to. This includes nodes that may not be generated in the Godot scene, or nodes that may generate multiple Godot scene nodes.

## get_scene_node :: func GLTFState.get_scene_node(gltf_node_index: int) -> Node
Returns the Godot scene node that corresponds to the same index as the [GLTFNode] it was generated from. This is the inverse of [method get_node_index]. Useful during the import process.
[b]Note:[/b] Not every [GLTFNode] will have a scene node generated, and not every generated scene node will have a corresponding [GLTFNode]. If there is no scene node for this [GLTFNode] index, [code]null[/code] is returned.

### gltf_node_index :: int

## get_skeletons :: func GLTFState.get_skeletons() -> GLTFSkeleton[]
Returns an array of all [GLTFSkeleton]s in the glTF file. These are the skeletons that the [member GLTFNode.skeleton] index refers to.

## get_skins :: func GLTFState.get_skins() -> GLTFSkin[]
Returns an array of all [GLTFSkin]s in the glTF file. These are the skins that the [member GLTFNode.skin] index refers to.

## get_texture_samplers :: func GLTFState.get_texture_samplers() -> GLTFTextureSampler[]
Retrieves the array of texture samplers that are used by the textures contained in the glTF.

## get_textures :: func GLTFState.get_textures() -> GLTFTexture[]

## get_unique_animation_names :: func GLTFState.get_unique_animation_names() -> String[]
Returns an array of unique animation names. This is only used during the import process.

## get_unique_names :: func GLTFState.get_unique_names() -> String[]
Returns an array of unique node names. This is used in both the import process and export process.

## set_accessors :: func GLTFState.set_accessors(accessors: GLTFAccessor[]) -> void

### accessors :: GLTFAccessor[]

## set_additional_data :: func GLTFState.set_additional_data(extension_name: StringName, additional_data: Variant) -> void
Sets additional arbitrary data in this [GLTFState] instance. This can be used to keep per-file state data in [GLTFDocumentExtension] classes, which is important because they are stateless.
The first argument should be the [GLTFDocumentExtension] name (does not have to match the extension name in the glTF file), and the second argument can be anything you want.

### extension_name :: StringName

### additional_data :: Variant

## set_animations :: func GLTFState.set_animations(animations: GLTFAnimation[]) -> void
Sets the [GLTFAnimation]s in the state. When importing, these will be generated as animations in an [AnimationPlayer] node. When exporting, these will be generated from Godot [AnimationPlayer] nodes.

### animations :: GLTFAnimation[]

## set_buffer_views :: func GLTFState.set_buffer_views(buffer_views: GLTFBufferView[]) -> void

### buffer_views :: GLTFBufferView[]

## set_cameras :: func GLTFState.set_cameras(cameras: GLTFCamera[]) -> void
Sets the [GLTFCamera]s in the state. These are the cameras that the [member GLTFNode.camera] index refers to.

### cameras :: GLTFCamera[]

## set_handle_binary_image :: func GLTFState.set_handle_binary_image(method: int) -> void
Deprecated untyped alias for [member handle_binary_image_mode]. When importing a glTF file with unimported raw binary images embedded inside of binary blob buffers, in data URIs, or separate files not imported by Godot, this controls how the images are handled.

### method :: int

## set_images :: func GLTFState.set_images(images: Texture2D[]) -> void
Sets the images in the state stored as an array of [Texture2D]s. This can be used during export. These are the images that the [member GLTFTexture.src_image] index refers to.

### images :: Texture2D[]

## set_lights :: func GLTFState.set_lights(lights: GLTFLight[]) -> void
Sets the [GLTFLight]s in the state. These are the lights that the [member GLTFNode.light] index refers to.

### lights :: GLTFLight[]

## set_materials :: func GLTFState.set_materials(materials: Material[]) -> void

### materials :: Material[]

## set_meshes :: func GLTFState.set_meshes(meshes: GLTFMesh[]) -> void
Sets the [GLTFMesh]es in the state. These are the meshes that the [member GLTFNode.mesh] index refers to.

### meshes :: GLTFMesh[]

## set_nodes :: func GLTFState.set_nodes(nodes: GLTFNode[]) -> void
Sets the [GLTFNode]s in the state. These are the nodes that [member GLTFNode.children] and [member root_nodes] refer to. Some of the nodes set here may not be generated in the Godot scene, or may generate multiple Godot scene nodes.

### nodes :: GLTFNode[]

## set_skeletons :: func GLTFState.set_skeletons(skeletons: GLTFSkeleton[]) -> void
Sets the [GLTFSkeleton]s in the state. These are the skeletons that the [member GLTFNode.skeleton] index refers to.

### skeletons :: GLTFSkeleton[]

## set_skins :: func GLTFState.set_skins(skins: GLTFSkin[]) -> void
Sets the [GLTFSkin]s in the state. These are the skins that the [member GLTFNode.skin] index refers to.

### skins :: GLTFSkin[]

## set_texture_samplers :: func GLTFState.set_texture_samplers(texture_samplers: GLTFTextureSampler[]) -> void
Sets the array of texture samplers that are used by the textures contained in the glTF.

### texture_samplers :: GLTFTextureSampler[]

## set_textures :: func GLTFState.set_textures(textures: GLTFTexture[]) -> void

### textures :: GLTFTexture[]

## set_unique_animation_names :: func GLTFState.set_unique_animation_names(unique_animation_names: String[]) -> void
Sets the unique animation names in the state. This is only used during the import process.

### unique_animation_names :: String[]

## set_unique_names :: func GLTFState.set_unique_names(unique_names: String[]) -> void
Sets the unique node names in the state. This is used in both the import process and export process.

### unique_names :: String[]
