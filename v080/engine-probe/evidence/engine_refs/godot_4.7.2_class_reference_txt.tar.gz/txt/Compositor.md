# Compositor :: <Native> class Compositor extends Resource
Stores attributes used to customize how a Viewport is rendered.
The compositor resource stores attributes used to customize how a [Viewport] is rendered.

## compositor_effects :: var Compositor.compositor_effects: CompositorEffect[]
The custom [CompositorEffect]s that are applied during rendering of viewports using this compositor.
