# XRBodyModifier3D :: <Native> class XRBodyModifier3D extends SkeletonModifier3D
A node for driving body meshes from [XRBodyTracker] data.
This node uses body tracking data from an [XRBodyTracker] to pose the skeleton of a body mesh.
Positioning of the body is performed by creating an [XRNode3D] ancestor of the body mesh driven by the same [XRBodyTracker].
The body tracking position-data is scaled by [member Skeleton3D.motion_scale] when applied to the skeleton, which can be used to adjust the tracked body to match the scale of the body model.

## BODY_UPDATE_UPPER_BODY :: const XRBodyModifier3D.BODY_UPDATE_UPPER_BODY: BodyUpdate = 1
The skeleton's upper body joints are updated.

## BODY_UPDATE_LOWER_BODY :: const XRBodyModifier3D.BODY_UPDATE_LOWER_BODY: BodyUpdate = 2
The skeleton's lower body joints are updated.

## BODY_UPDATE_HANDS :: const XRBodyModifier3D.BODY_UPDATE_HANDS: BodyUpdate = 4
The skeleton's hand joints are updated.

## BONE_UPDATE_FULL :: const XRBodyModifier3D.BONE_UPDATE_FULL: BoneUpdate = 0
The skeleton's bones are fully updated (both position and rotation) to match the tracked bones.

## BONE_UPDATE_ROTATION_ONLY :: const XRBodyModifier3D.BONE_UPDATE_ROTATION_ONLY: BoneUpdate = 1
The skeleton's bones are only rotated to align with the tracked bones, preserving bone length.

## BONE_UPDATE_MAX :: const XRBodyModifier3D.BONE_UPDATE_MAX: BoneUpdate = 2
Represents the size of the [enum BoneUpdate] enum.

## body_tracker :: var XRBodyModifier3D.body_tracker: StringName
The name of the [XRBodyTracker] registered with [XRServer] to obtain the body tracking data from.

## body_update :: var XRBodyModifier3D.body_update: XRBodyModifier3D.BodyUpdate
Specifies the body parts to update.

## bone_update :: var XRBodyModifier3D.bone_update: XRBodyModifier3D.BoneUpdate
Specifies the type of updates to perform on the bones.
