# Generic6DOFJoint3D :: <Native> class Generic6DOFJoint3D extends Joint3D
A physics joint that allows for complex movement and rotation between two 3D physics bodies.
The [Generic6DOFJoint3D] (6 Degrees Of Freedom) joint allows for implementing custom types of joints by locking the rotation and translation of certain axes.
The first 3 DOF represent the linear motion of the physics bodies and the last 3 DOF represent the angular motion of the physics bodies. Each axis can be either locked, or limited.

## PARAM_LINEAR_LOWER_LIMIT :: const Generic6DOFJoint3D.PARAM_LINEAR_LOWER_LIMIT: Param = 0
The minimum difference between the pivot points' axes.

## PARAM_LINEAR_UPPER_LIMIT :: const Generic6DOFJoint3D.PARAM_LINEAR_UPPER_LIMIT: Param = 1
The maximum difference between the pivot points' axes.

## PARAM_LINEAR_LIMIT_SOFTNESS :: const Generic6DOFJoint3D.PARAM_LINEAR_LIMIT_SOFTNESS: Param = 2
A factor applied to the movement across the axes. The lower, the slower the movement.

## PARAM_LINEAR_RESTITUTION :: const Generic6DOFJoint3D.PARAM_LINEAR_RESTITUTION: Param = 3
The amount of restitution on the axes' movement. The lower, the more momentum gets lost.

## PARAM_LINEAR_DAMPING :: const Generic6DOFJoint3D.PARAM_LINEAR_DAMPING: Param = 4
The amount of damping that happens at the linear motion across the axes.

## PARAM_LINEAR_MOTOR_TARGET_VELOCITY :: const Generic6DOFJoint3D.PARAM_LINEAR_MOTOR_TARGET_VELOCITY: Param = 5
The velocity the linear motor will try to reach.

## PARAM_LINEAR_MOTOR_FORCE_LIMIT :: const Generic6DOFJoint3D.PARAM_LINEAR_MOTOR_FORCE_LIMIT: Param = 6
The maximum force the linear motor will apply while trying to reach the velocity target.

## PARAM_LINEAR_SPRING_STIFFNESS :: const Generic6DOFJoint3D.PARAM_LINEAR_SPRING_STIFFNESS: Param = 7

## PARAM_LINEAR_SPRING_DAMPING :: const Generic6DOFJoint3D.PARAM_LINEAR_SPRING_DAMPING: Param = 8

## PARAM_LINEAR_SPRING_EQUILIBRIUM_POINT :: const Generic6DOFJoint3D.PARAM_LINEAR_SPRING_EQUILIBRIUM_POINT: Param = 9

## PARAM_ANGULAR_LOWER_LIMIT :: const Generic6DOFJoint3D.PARAM_ANGULAR_LOWER_LIMIT: Param = 10
The minimum rotation in negative direction to break loose and rotate around the axes.

## PARAM_ANGULAR_UPPER_LIMIT :: const Generic6DOFJoint3D.PARAM_ANGULAR_UPPER_LIMIT: Param = 11
The minimum rotation in positive direction to break loose and rotate around the axes.

## PARAM_ANGULAR_LIMIT_SOFTNESS :: const Generic6DOFJoint3D.PARAM_ANGULAR_LIMIT_SOFTNESS: Param = 12
The speed of all rotations across the axes.

## PARAM_ANGULAR_DAMPING :: const Generic6DOFJoint3D.PARAM_ANGULAR_DAMPING: Param = 13
The amount of rotational damping across the axes. The lower, the more damping occurs.

## PARAM_ANGULAR_RESTITUTION :: const Generic6DOFJoint3D.PARAM_ANGULAR_RESTITUTION: Param = 14
The amount of rotational restitution across the axes. The lower, the more restitution occurs.

## PARAM_ANGULAR_FORCE_LIMIT :: const Generic6DOFJoint3D.PARAM_ANGULAR_FORCE_LIMIT: Param = 15
The maximum amount of force that can occur, when rotating around the axes.

## PARAM_ANGULAR_ERP :: const Generic6DOFJoint3D.PARAM_ANGULAR_ERP: Param = 16
When rotating across the axes, this error tolerance factor defines how much the correction gets slowed down. The lower, the slower.

## PARAM_ANGULAR_MOTOR_TARGET_VELOCITY :: const Generic6DOFJoint3D.PARAM_ANGULAR_MOTOR_TARGET_VELOCITY: Param = 17
Target speed for the motor at the axes.

## PARAM_ANGULAR_MOTOR_FORCE_LIMIT :: const Generic6DOFJoint3D.PARAM_ANGULAR_MOTOR_FORCE_LIMIT: Param = 18
Maximum acceleration for the motor at the axes.

## PARAM_ANGULAR_SPRING_STIFFNESS :: const Generic6DOFJoint3D.PARAM_ANGULAR_SPRING_STIFFNESS: Param = 19

## PARAM_ANGULAR_SPRING_DAMPING :: const Generic6DOFJoint3D.PARAM_ANGULAR_SPRING_DAMPING: Param = 20

## PARAM_ANGULAR_SPRING_EQUILIBRIUM_POINT :: const Generic6DOFJoint3D.PARAM_ANGULAR_SPRING_EQUILIBRIUM_POINT: Param = 21

## PARAM_MAX :: const Generic6DOFJoint3D.PARAM_MAX: Param = 22
Represents the size of the [enum Param] enum.

## FLAG_ENABLE_LINEAR_LIMIT :: const Generic6DOFJoint3D.FLAG_ENABLE_LINEAR_LIMIT: Flag = 0
If enabled, linear motion is possible within the given limits.

## FLAG_ENABLE_ANGULAR_LIMIT :: const Generic6DOFJoint3D.FLAG_ENABLE_ANGULAR_LIMIT: Flag = 1
If enabled, rotational motion is possible within the given limits.

## FLAG_ENABLE_LINEAR_SPRING :: const Generic6DOFJoint3D.FLAG_ENABLE_LINEAR_SPRING: Flag = 3

## FLAG_ENABLE_ANGULAR_SPRING :: const Generic6DOFJoint3D.FLAG_ENABLE_ANGULAR_SPRING: Flag = 2

## FLAG_ENABLE_MOTOR :: const Generic6DOFJoint3D.FLAG_ENABLE_MOTOR: Flag = 4
If enabled, there is a rotational motor across these axes.

## FLAG_ENABLE_LINEAR_MOTOR :: const Generic6DOFJoint3D.FLAG_ENABLE_LINEAR_MOTOR: Flag = 5
If enabled, there is a linear motor across these axes.

## FLAG_MAX :: const Generic6DOFJoint3D.FLAG_MAX: Flag = 6
Represents the size of the [enum Flag] enum.

## angular_limit_x/damping :: var Generic6DOFJoint3D.angular_limit_x/damping: float
The amount of rotational damping across the X axis.
The lower, the longer an impulse from one side takes to travel to the other side.

## angular_limit_x/enabled :: var Generic6DOFJoint3D.angular_limit_x/enabled: bool
If [code]true[/code], rotation across the X axis is limited.

## angular_limit_x/erp :: var Generic6DOFJoint3D.angular_limit_x/erp: float
When rotating across the X axis, this error tolerance factor defines how much the correction gets slowed down. The lower, the slower.

## angular_limit_x/force_limit :: var Generic6DOFJoint3D.angular_limit_x/force_limit: float
The maximum amount of force that can occur, when rotating around the X axis.

## angular_limit_x/lower_angle :: var Generic6DOFJoint3D.angular_limit_x/lower_angle: float
The minimum rotation in negative direction to break loose and rotate around the X axis.

## angular_limit_x/restitution :: var Generic6DOFJoint3D.angular_limit_x/restitution: float
The amount of rotational restitution across the X axis. The lower, the more restitution occurs.

## angular_limit_x/softness :: var Generic6DOFJoint3D.angular_limit_x/softness: float
The speed of all rotations across the X axis.

## angular_limit_x/upper_angle :: var Generic6DOFJoint3D.angular_limit_x/upper_angle: float
The minimum rotation in positive direction to break loose and rotate around the X axis.

## angular_limit_y/damping :: var Generic6DOFJoint3D.angular_limit_y/damping: float
The amount of rotational damping across the Y axis. The lower, the more damping occurs.

## angular_limit_y/enabled :: var Generic6DOFJoint3D.angular_limit_y/enabled: bool
If [code]true[/code], rotation across the Y axis is limited.

## angular_limit_y/erp :: var Generic6DOFJoint3D.angular_limit_y/erp: float
When rotating across the Y axis, this error tolerance factor defines how much the correction gets slowed down. The lower, the slower.

## angular_limit_y/force_limit :: var Generic6DOFJoint3D.angular_limit_y/force_limit: float
The maximum amount of force that can occur, when rotating around the Y axis.

## angular_limit_y/lower_angle :: var Generic6DOFJoint3D.angular_limit_y/lower_angle: float
The minimum rotation in negative direction to break loose and rotate around the Y axis.

## angular_limit_y/restitution :: var Generic6DOFJoint3D.angular_limit_y/restitution: float
The amount of rotational restitution across the Y axis. The lower, the more restitution occurs.

## angular_limit_y/softness :: var Generic6DOFJoint3D.angular_limit_y/softness: float
The speed of all rotations across the Y axis.

## angular_limit_y/upper_angle :: var Generic6DOFJoint3D.angular_limit_y/upper_angle: float
The minimum rotation in positive direction to break loose and rotate around the Y axis.

## angular_limit_z/damping :: var Generic6DOFJoint3D.angular_limit_z/damping: float
The amount of rotational damping across the Z axis. The lower, the more damping occurs.

## angular_limit_z/enabled :: var Generic6DOFJoint3D.angular_limit_z/enabled: bool
If [code]true[/code], rotation across the Z axis is limited.

## angular_limit_z/erp :: var Generic6DOFJoint3D.angular_limit_z/erp: float
When rotating across the Z axis, this error tolerance factor defines how much the correction gets slowed down. The lower, the slower.

## angular_limit_z/force_limit :: var Generic6DOFJoint3D.angular_limit_z/force_limit: float
The maximum amount of force that can occur, when rotating around the Z axis.

## angular_limit_z/lower_angle :: var Generic6DOFJoint3D.angular_limit_z/lower_angle: float
The minimum rotation in negative direction to break loose and rotate around the Z axis.

## angular_limit_z/restitution :: var Generic6DOFJoint3D.angular_limit_z/restitution: float
The amount of rotational restitution across the Z axis. The lower, the more restitution occurs.

## angular_limit_z/softness :: var Generic6DOFJoint3D.angular_limit_z/softness: float
The speed of all rotations across the Z axis.

## angular_limit_z/upper_angle :: var Generic6DOFJoint3D.angular_limit_z/upper_angle: float
The minimum rotation in positive direction to break loose and rotate around the Z axis.

## angular_motor_x/enabled :: var Generic6DOFJoint3D.angular_motor_x/enabled: bool
If [code]true[/code], a rotating motor at the X axis is enabled.

## angular_motor_x/force_limit :: var Generic6DOFJoint3D.angular_motor_x/force_limit: float
Maximum acceleration for the motor at the X axis.

## angular_motor_x/target_velocity :: var Generic6DOFJoint3D.angular_motor_x/target_velocity: float
Target speed for the motor at the X axis.

## angular_motor_y/enabled :: var Generic6DOFJoint3D.angular_motor_y/enabled: bool
If [code]true[/code], a rotating motor at the Y axis is enabled.

## angular_motor_y/force_limit :: var Generic6DOFJoint3D.angular_motor_y/force_limit: float
Maximum acceleration for the motor at the Y axis.

## angular_motor_y/target_velocity :: var Generic6DOFJoint3D.angular_motor_y/target_velocity: float
Target speed for the motor at the Y axis.

## angular_motor_z/enabled :: var Generic6DOFJoint3D.angular_motor_z/enabled: bool
If [code]true[/code], a rotating motor at the Z axis is enabled.

## angular_motor_z/force_limit :: var Generic6DOFJoint3D.angular_motor_z/force_limit: float
Maximum acceleration for the motor at the Z axis.

## angular_motor_z/target_velocity :: var Generic6DOFJoint3D.angular_motor_z/target_velocity: float
Target speed for the motor at the Z axis.

## angular_spring_x/damping :: var Generic6DOFJoint3D.angular_spring_x/damping: float

## angular_spring_x/enabled :: var Generic6DOFJoint3D.angular_spring_x/enabled: bool

## angular_spring_x/equilibrium_point :: var Generic6DOFJoint3D.angular_spring_x/equilibrium_point: float

## angular_spring_x/stiffness :: var Generic6DOFJoint3D.angular_spring_x/stiffness: float

## angular_spring_y/damping :: var Generic6DOFJoint3D.angular_spring_y/damping: float

## angular_spring_y/enabled :: var Generic6DOFJoint3D.angular_spring_y/enabled: bool

## angular_spring_y/equilibrium_point :: var Generic6DOFJoint3D.angular_spring_y/equilibrium_point: float

## angular_spring_y/stiffness :: var Generic6DOFJoint3D.angular_spring_y/stiffness: float

## angular_spring_z/damping :: var Generic6DOFJoint3D.angular_spring_z/damping: float

## angular_spring_z/enabled :: var Generic6DOFJoint3D.angular_spring_z/enabled: bool

## angular_spring_z/equilibrium_point :: var Generic6DOFJoint3D.angular_spring_z/equilibrium_point: float

## angular_spring_z/stiffness :: var Generic6DOFJoint3D.angular_spring_z/stiffness: float

## linear_limit_x/damping :: var Generic6DOFJoint3D.linear_limit_x/damping: float
The amount of damping that happens at the X motion.

## linear_limit_x/enabled :: var Generic6DOFJoint3D.linear_limit_x/enabled: bool
If [code]true[/code], the linear motion across the X axis is limited.

## linear_limit_x/lower_distance :: var Generic6DOFJoint3D.linear_limit_x/lower_distance: float
The minimum difference between the pivot points' X axis.

## linear_limit_x/restitution :: var Generic6DOFJoint3D.linear_limit_x/restitution: float
The amount of restitution on the X axis movement. The lower, the more momentum gets lost.

## linear_limit_x/softness :: var Generic6DOFJoint3D.linear_limit_x/softness: float
A factor applied to the movement across the X axis. The lower, the slower the movement.

## linear_limit_x/upper_distance :: var Generic6DOFJoint3D.linear_limit_x/upper_distance: float
The maximum difference between the pivot points' X axis.

## linear_limit_y/damping :: var Generic6DOFJoint3D.linear_limit_y/damping: float
The amount of damping that happens at the Y motion.

## linear_limit_y/enabled :: var Generic6DOFJoint3D.linear_limit_y/enabled: bool
If [code]true[/code], the linear motion across the Y axis is limited.

## linear_limit_y/lower_distance :: var Generic6DOFJoint3D.linear_limit_y/lower_distance: float
The minimum difference between the pivot points' Y axis.

## linear_limit_y/restitution :: var Generic6DOFJoint3D.linear_limit_y/restitution: float
The amount of restitution on the Y axis movement. The lower, the more momentum gets lost.

## linear_limit_y/softness :: var Generic6DOFJoint3D.linear_limit_y/softness: float
A factor applied to the movement across the Y axis. The lower, the slower the movement.

## linear_limit_y/upper_distance :: var Generic6DOFJoint3D.linear_limit_y/upper_distance: float
The maximum difference between the pivot points' Y axis.

## linear_limit_z/damping :: var Generic6DOFJoint3D.linear_limit_z/damping: float
The amount of damping that happens at the Z motion.

## linear_limit_z/enabled :: var Generic6DOFJoint3D.linear_limit_z/enabled: bool
If [code]true[/code], the linear motion across the Z axis is limited.

## linear_limit_z/lower_distance :: var Generic6DOFJoint3D.linear_limit_z/lower_distance: float
The minimum difference between the pivot points' Z axis.

## linear_limit_z/restitution :: var Generic6DOFJoint3D.linear_limit_z/restitution: float
The amount of restitution on the Z axis movement. The lower, the more momentum gets lost.

## linear_limit_z/softness :: var Generic6DOFJoint3D.linear_limit_z/softness: float
A factor applied to the movement across the Z axis. The lower, the slower the movement.

## linear_limit_z/upper_distance :: var Generic6DOFJoint3D.linear_limit_z/upper_distance: float
The maximum difference between the pivot points' Z axis.

## linear_motor_x/enabled :: var Generic6DOFJoint3D.linear_motor_x/enabled: bool
If [code]true[/code], then there is a linear motor on the X axis. It will attempt to reach the target velocity while staying within the force limits.

## linear_motor_x/force_limit :: var Generic6DOFJoint3D.linear_motor_x/force_limit: float
The maximum force the linear motor can apply on the X axis while trying to reach the target velocity.

## linear_motor_x/target_velocity :: var Generic6DOFJoint3D.linear_motor_x/target_velocity: float
The speed that the linear motor will attempt to reach on the X axis.

## linear_motor_y/enabled :: var Generic6DOFJoint3D.linear_motor_y/enabled: bool
If [code]true[/code], then there is a linear motor on the Y axis. It will attempt to reach the target velocity while staying within the force limits.

## linear_motor_y/force_limit :: var Generic6DOFJoint3D.linear_motor_y/force_limit: float
The maximum force the linear motor can apply on the Y axis while trying to reach the target velocity.

## linear_motor_y/target_velocity :: var Generic6DOFJoint3D.linear_motor_y/target_velocity: float
The speed that the linear motor will attempt to reach on the Y axis.

## linear_motor_z/enabled :: var Generic6DOFJoint3D.linear_motor_z/enabled: bool
If [code]true[/code], then there is a linear motor on the Z axis. It will attempt to reach the target velocity while staying within the force limits.

## linear_motor_z/force_limit :: var Generic6DOFJoint3D.linear_motor_z/force_limit: float
The maximum force the linear motor can apply on the Z axis while trying to reach the target velocity.

## linear_motor_z/target_velocity :: var Generic6DOFJoint3D.linear_motor_z/target_velocity: float
The speed that the linear motor will attempt to reach on the Z axis.

## linear_spring_x/damping :: var Generic6DOFJoint3D.linear_spring_x/damping: float

## linear_spring_x/enabled :: var Generic6DOFJoint3D.linear_spring_x/enabled: bool

## linear_spring_x/equilibrium_point :: var Generic6DOFJoint3D.linear_spring_x/equilibrium_point: float

## linear_spring_x/stiffness :: var Generic6DOFJoint3D.linear_spring_x/stiffness: float

## linear_spring_y/damping :: var Generic6DOFJoint3D.linear_spring_y/damping: float

## linear_spring_y/enabled :: var Generic6DOFJoint3D.linear_spring_y/enabled: bool

## linear_spring_y/equilibrium_point :: var Generic6DOFJoint3D.linear_spring_y/equilibrium_point: float

## linear_spring_y/stiffness :: var Generic6DOFJoint3D.linear_spring_y/stiffness: float

## linear_spring_z/damping :: var Generic6DOFJoint3D.linear_spring_z/damping: float

## linear_spring_z/enabled :: var Generic6DOFJoint3D.linear_spring_z/enabled: bool

## linear_spring_z/equilibrium_point :: var Generic6DOFJoint3D.linear_spring_z/equilibrium_point: float

## linear_spring_z/stiffness :: var Generic6DOFJoint3D.linear_spring_z/stiffness: float

## get_flag_x :: func Generic6DOFJoint3D.get_flag_x(flag: int) -> bool

### flag :: int

## get_flag_y :: func Generic6DOFJoint3D.get_flag_y(flag: int) -> bool

### flag :: int

## get_flag_z :: func Generic6DOFJoint3D.get_flag_z(flag: int) -> bool

### flag :: int

## get_param_x :: func Generic6DOFJoint3D.get_param_x(param: int) -> float

### param :: int

## get_param_y :: func Generic6DOFJoint3D.get_param_y(param: int) -> float

### param :: int

## get_param_z :: func Generic6DOFJoint3D.get_param_z(param: int) -> float

### param :: int

## set_flag_x :: func Generic6DOFJoint3D.set_flag_x(flag: int, value: bool) -> void

### flag :: int

### value :: bool

## set_flag_y :: func Generic6DOFJoint3D.set_flag_y(flag: int, value: bool) -> void

### flag :: int

### value :: bool

## set_flag_z :: func Generic6DOFJoint3D.set_flag_z(flag: int, value: bool) -> void

### flag :: int

### value :: bool

## set_param_x :: func Generic6DOFJoint3D.set_param_x(param: int, value: float) -> void

### param :: int

### value :: float

## set_param_y :: func Generic6DOFJoint3D.set_param_y(param: int, value: float) -> void

### param :: int

### value :: float

## set_param_z :: func Generic6DOFJoint3D.set_param_z(param: int, value: float) -> void

### param :: int

### value :: float
