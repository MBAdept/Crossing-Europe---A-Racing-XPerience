# VideoStreamPlayback :: <Native> class VideoStreamPlayback extends Resource
Internal class used by [VideoStream] to manage playback state when played from a [VideoStreamPlayer].
This class is intended to be overridden by video decoder extensions with custom implementations of [VideoStream].

## _get_channels :: func VideoStreamPlayback._get_channels() -> int
Returns the number of audio channels.

## _get_length :: func VideoStreamPlayback._get_length() -> float
Returns the video duration in seconds, if known, or 0 if unknown.

## _get_mix_rate :: func VideoStreamPlayback._get_mix_rate() -> int
Returns the audio sample rate used for mixing.

## _get_playback_position :: func VideoStreamPlayback._get_playback_position() -> float
Return the current playback timestamp. Called in response to the [member VideoStreamPlayer.stream_position] getter.

## _get_texture :: func VideoStreamPlayback._get_texture() -> Texture2D
Allocates a [Texture2D] in which decoded video frames will be drawn.

## _is_paused :: func VideoStreamPlayback._is_paused() -> bool
Returns the paused status, as set by [method _set_paused].

## _is_playing :: func VideoStreamPlayback._is_playing() -> bool
Returns the playback state, as determined by calls to [method _play] and [method _stop].

## _play :: func VideoStreamPlayback._play() -> void
Called in response to [member VideoStreamPlayer.autoplay] or [method VideoStreamPlayer.play]. Note that manual playback may also invoke [method _stop] multiple times before this method is called. [method _is_playing] should return [code]true[/code] once playing.

## _seek :: func VideoStreamPlayback._seek(time: float) -> void
Seeks to [param time] seconds. Called in response to the [member VideoStreamPlayer.stream_position] setter.

### time :: float

## _set_audio_track :: func VideoStreamPlayback._set_audio_track(idx: int) -> void
Select the audio track [param idx]. Called when playback starts, and in response to the [member VideoStreamPlayer.audio_track] setter.

### idx :: int

## _set_paused :: func VideoStreamPlayback._set_paused(paused: bool) -> void
Set the paused status of video playback. [method _is_paused] must return [param paused]. Called in response to the [member VideoStreamPlayer.paused] setter.

### paused :: bool

## _stop :: func VideoStreamPlayback._stop() -> void
Stops playback. May be called multiple times before [method _play], or in response to [method VideoStreamPlayer.stop]. [method _is_playing] should return [code]false[/code] once stopped.

## _update :: func VideoStreamPlayback._update(delta: float) -> void
Ticks video playback for [param delta] seconds. Called every frame as long as both [method _is_paused] and [method _is_playing] return [code]true[/code].

### delta :: float

## mix_audio :: func VideoStreamPlayback.mix_audio(num_frames: int, buffer: PackedFloat32Array = PackedFloat32Array(), offset: int = 0) -> int
Render [param num_frames] audio frames (of [method _get_channels] floats each) from [param buffer], starting from index [param offset] in the array. Returns the number of audio frames rendered, or -1 on error.

### num_frames :: int

### buffer :: PackedFloat32Array

### offset :: int
