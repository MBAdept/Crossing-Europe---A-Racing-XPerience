# CompressedTextureLayered :: <Native> class CompressedTextureLayered extends TextureLayered
Base class for texture arrays that can optionally be compressed.
Base class for [CompressedTexture2DArray] and [CompressedTexture3D]. Cannot be used directly, but contains all the functions necessary for accessing the derived resource types. See also [TextureLayered].

## load_path :: var CompressedTextureLayered.load_path: String
The path the texture should be loaded from.

## load :: func CompressedTextureLayered.load(path: String) -> int
Loads the texture at [param path].

### path :: String
