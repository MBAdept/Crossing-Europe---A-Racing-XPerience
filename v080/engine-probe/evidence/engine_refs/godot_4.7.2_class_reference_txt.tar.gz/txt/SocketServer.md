# SocketServer :: <Native> class SocketServer extends RefCounted
An abstract class for servers based on sockets.
A socket server.

## is_connection_available :: func SocketServer.is_connection_available() -> bool
Returns [code]true[/code] if a connection is available for taking.

## is_listening :: func SocketServer.is_listening() -> bool
Returns [code]true[/code] if the server is currently listening for connections.

## stop :: func SocketServer.stop() -> void
Stops listening.

## take_socket_connection :: func SocketServer.take_socket_connection() -> StreamPeerSocket
If a connection is available, returns a StreamPeerSocket with the connection.
