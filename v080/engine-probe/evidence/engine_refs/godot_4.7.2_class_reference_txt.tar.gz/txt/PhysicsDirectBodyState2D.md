# PhysicsDirectBodyState2D :: <Native> class PhysicsDirectBodyState2D extends Object
Provides direct access to a physics body in the [PhysicsServer2D].
Provides direct access to a physics body in the [PhysicsServer2D], allowing safe changes to physics properties. This object is passed via the direct state callback of [RigidBody2D], and is intended for changing the direct state of that body. See [method RigidBody2D._integrate_forces].

## angular_velocity :: var PhysicsDirectBodyState2D.angular_velocity: float
The body's rotational velocity in [i]radians[/i] per second.

## center_of_mass :: var PhysicsDirectBodyState2D.center_of_mass: Vector2
The body's center of mass position relative to the body's center in the global coordinate system.

## center_of_mass_local :: var PhysicsDirectBodyState2D.center_of_mass_local: Vector2
The body's center of mass position in the body's local coordinate system.

## collision_layer :: var PhysicsDirectBodyState2D.collision_layer: int
The body's collision layer.

## collision_mask :: var PhysicsDirectBodyState2D.collision_mask: int
The body's collision mask.

## inverse_inertia :: var PhysicsDirectBodyState2D.inverse_inertia: float
The inverse of the inertia of the body.

## inverse_mass :: var PhysicsDirectBodyState2D.inverse_mass: float
The inverse of the mass of the body.

## linear_velocity :: var PhysicsDirectBodyState2D.linear_velocity: Vector2
The body's linear velocity in pixels per second.

## sleeping :: var PhysicsDirectBodyState2D.sleeping: bool
If [code]true[/code], this body is currently sleeping (not active).

## step :: var PhysicsDirectBodyState2D.step: float
The timestep (delta) used for the simulation.

## total_angular_damp :: var PhysicsDirectBodyState2D.total_angular_damp: float
The rate at which the body stops rotating, if there are not any other forces moving it.

## total_gravity :: var PhysicsDirectBodyState2D.total_gravity: Vector2
The total gravity vector being currently applied to this body.

## total_linear_damp :: var PhysicsDirectBodyState2D.total_linear_damp: float
The rate at which the body stops moving, if there are not any other forces moving it.

## transform :: var PhysicsDirectBodyState2D.transform: Transform2D
The body's transformation matrix.

## add_constant_central_force :: func PhysicsDirectBodyState2D.add_constant_central_force(force: Vector2 = Vector2(0, 0)) -> void
Adds a constant directional force without affecting rotation that keeps being applied over time until cleared with [code]constant_force = Vector2(0, 0)[/code].
This is equivalent to using [method add_constant_force] at the body's center of mass.

### force :: Vector2

## add_constant_force :: func PhysicsDirectBodyState2D.add_constant_force(force: Vector2, position: Vector2 = Vector2(0, 0)) -> void
Adds a constant positioned force to the body that keeps being applied over time until cleared with [code]constant_force = Vector2(0, 0)[/code].
[param position] is the offset from the body origin in global coordinates.

### force :: Vector2

### position :: Vector2

## add_constant_torque :: func PhysicsDirectBodyState2D.add_constant_torque(torque: float) -> void
Adds a constant rotational force without affecting position that keeps being applied over time until cleared with [code]constant_torque = 0[/code].

### torque :: float

## apply_central_force :: func PhysicsDirectBodyState2D.apply_central_force(force: Vector2 = Vector2(0, 0)) -> void
Applies a directional force without affecting rotation. A force is time dependent and meant to be applied every physics update.
This is equivalent to using [method apply_force] at the body's center of mass.

### force :: Vector2

## apply_central_impulse :: func PhysicsDirectBodyState2D.apply_central_impulse(impulse: Vector2) -> void
Applies a directional impulse without affecting rotation.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).
This is equivalent to using [method apply_impulse] at the body's center of mass.

### impulse :: Vector2

## apply_force :: func PhysicsDirectBodyState2D.apply_force(force: Vector2, position: Vector2 = Vector2(0, 0)) -> void
Applies a positioned force to the body. A force is time dependent and meant to be applied every physics update.
[param position] is the offset from the body origin in global coordinates.

### force :: Vector2

### position :: Vector2

## apply_impulse :: func PhysicsDirectBodyState2D.apply_impulse(impulse: Vector2, position: Vector2 = Vector2(0, 0)) -> void
Applies a positioned impulse to the body.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).
[param position] is the offset from the body origin in global coordinates.

### impulse :: Vector2

### position :: Vector2

## apply_torque :: func PhysicsDirectBodyState2D.apply_torque(torque: float) -> void
Applies a rotational force without affecting position. A force is time dependent and meant to be applied every physics update.
[b]Note:[/b] [member inverse_inertia] is required for this to work. To have [member inverse_inertia], an active [CollisionShape2D] must be a child of the node, or you can manually set [member inverse_inertia].

### torque :: float

## apply_torque_impulse :: func PhysicsDirectBodyState2D.apply_torque_impulse(impulse: float) -> void
Applies a rotational impulse to the body without affecting the position.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).
[b]Note:[/b] [member inverse_inertia] is required for this to work. To have [member inverse_inertia], an active [CollisionShape2D] must be a child of the node, or you can manually set [member inverse_inertia].

### impulse :: float

## get_constant_force :: func PhysicsDirectBodyState2D.get_constant_force() -> Vector2
Returns the body's total constant positional forces applied during each physics update.
See [method add_constant_force] and [method add_constant_central_force].

## get_constant_torque :: func PhysicsDirectBodyState2D.get_constant_torque() -> float
Returns the body's total constant rotational forces applied during each physics update.
See [method add_constant_torque].

## get_contact_collider :: func PhysicsDirectBodyState2D.get_contact_collider(contact_idx: int) -> RID
Returns the collider's [RID].

### contact_idx :: int

## get_contact_collider_id :: func PhysicsDirectBodyState2D.get_contact_collider_id(contact_idx: int) -> int
Returns the collider's object id.

### contact_idx :: int

## get_contact_collider_object :: func PhysicsDirectBodyState2D.get_contact_collider_object(contact_idx: int) -> Object
Returns the collider object. This depends on how it was created (will return a scene node if such was used to create it).

### contact_idx :: int

## get_contact_collider_position :: func PhysicsDirectBodyState2D.get_contact_collider_position(contact_idx: int) -> Vector2
Returns the position of the contact point on the collider in the global coordinate system.

### contact_idx :: int

## get_contact_collider_shape :: func PhysicsDirectBodyState2D.get_contact_collider_shape(contact_idx: int) -> int
Returns the collider's shape index.

### contact_idx :: int

## get_contact_collider_velocity_at_position :: func PhysicsDirectBodyState2D.get_contact_collider_velocity_at_position(contact_idx: int) -> Vector2
Returns the velocity vector at the collider's contact point.

### contact_idx :: int

## get_contact_count :: func PhysicsDirectBodyState2D.get_contact_count() -> int
Returns the number of contacts this body has with other bodies.
[b]Note:[/b] By default, this returns 0 unless bodies are configured to monitor contacts. See [member RigidBody2D.contact_monitor].

## get_contact_impulse :: func PhysicsDirectBodyState2D.get_contact_impulse(contact_idx: int) -> Vector2
Returns the impulse created by the contact.

### contact_idx :: int

## get_contact_local_normal :: func PhysicsDirectBodyState2D.get_contact_local_normal(contact_idx: int) -> Vector2
Returns the local normal at the contact point.

### contact_idx :: int

## get_contact_local_position :: func PhysicsDirectBodyState2D.get_contact_local_position(contact_idx: int) -> Vector2
Returns the position of the contact point on the body in the global coordinate system.

### contact_idx :: int

## get_contact_local_shape :: func PhysicsDirectBodyState2D.get_contact_local_shape(contact_idx: int) -> int
Returns the local shape index of the collision.

### contact_idx :: int

## get_contact_local_velocity_at_position :: func PhysicsDirectBodyState2D.get_contact_local_velocity_at_position(contact_idx: int) -> Vector2
Returns the velocity vector at the body's contact point.

### contact_idx :: int

## get_space_state :: func PhysicsDirectBodyState2D.get_space_state() -> PhysicsDirectSpaceState2D
Returns the current state of the space, useful for queries.

## get_velocity_at_local_position :: func PhysicsDirectBodyState2D.get_velocity_at_local_position(local_position: Vector2) -> Vector2
Returns the body's velocity at the given relative position.
[param local_position] is the offset from the body origin in global coordinates.

### local_position :: Vector2

## integrate_forces :: func PhysicsDirectBodyState2D.integrate_forces() -> void
Updates the body's linear and angular velocity by applying gravity and damping for the equivalent of one physics tick.

## set_constant_force :: func PhysicsDirectBodyState2D.set_constant_force(force: Vector2) -> void
Sets the body's total constant positional forces applied during each physics update.
See [method add_constant_force] and [method add_constant_central_force].

### force :: Vector2

## set_constant_torque :: func PhysicsDirectBodyState2D.set_constant_torque(torque: float) -> void
Sets the body's total constant rotational forces applied during each physics update.
See [method add_constant_torque].

### torque :: float
