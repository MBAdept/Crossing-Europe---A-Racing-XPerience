# InputEventFromWindow :: <Native> class InputEventFromWindow extends InputEvent
Abstract base class for [Viewport]-based input events.
InputEventFromWindow represents events specifically received by windows. This includes mouse events, keyboard events in focused windows or touch screen actions.

## window_id :: var InputEventFromWindow.window_id: int
The ID of a [Window] that received this event.
