# CenterContainer :: <Native> class CenterContainer extends Container
A container that keeps child controls in its center.
[CenterContainer] is a container that keeps all of its child controls in its center at their minimum size.

## use_top_left :: var CenterContainer.use_top_left: bool
If [code]true[/code], centers children relative to the [CenterContainer]'s top left corner.
