# Gradient :: <Native> class Gradient extends Resource
A color transition.
This resource describes a color transition by defining a set of colored points and how to interpolate between them.
See also [Curve] which supports more complex easing methods, but does not support colors.

## GRADIENT_INTERPOLATE_LINEAR :: const Gradient.GRADIENT_INTERPOLATE_LINEAR: InterpolationMode = 0
Linear interpolation.

## GRADIENT_INTERPOLATE_CONSTANT :: const Gradient.GRADIENT_INTERPOLATE_CONSTANT: InterpolationMode = 1
Constant interpolation, color changes abruptly at each point and stays uniform between. This might cause visible aliasing when used for a gradient texture in some cases.

## GRADIENT_INTERPOLATE_CUBIC :: const Gradient.GRADIENT_INTERPOLATE_CUBIC: InterpolationMode = 2
Cubic interpolation.

## GRADIENT_COLOR_SPACE_SRGB :: const Gradient.GRADIENT_COLOR_SPACE_SRGB: ColorSpace = 0
sRGB color space.

## GRADIENT_COLOR_SPACE_LINEAR_SRGB :: const Gradient.GRADIENT_COLOR_SPACE_LINEAR_SRGB: ColorSpace = 1
Linear sRGB color space.

## GRADIENT_COLOR_SPACE_OKLAB :: const Gradient.GRADIENT_COLOR_SPACE_OKLAB: ColorSpace = 2
[url=https://bottosson.github.io/posts/oklab/]Oklab[/url] color space. This color space provides a smooth and uniform-looking transition between colors.

## colors :: var Gradient.colors: PackedColorArray
Gradient's colors as a [PackedColorArray].
[b]Note:[/b] Setting this property updates all colors at once. To update any color individually use [method set_color].

## interpolation_color_space :: var Gradient.interpolation_color_space: Gradient.ColorSpace
The color space used to interpolate between points of the gradient. It does not affect the returned colors, which will always use nonlinear sRGB encoding.
[b]Note:[/b] This setting has no effect when [member interpolation_mode] is set to [constant GRADIENT_INTERPOLATE_CONSTANT].

## interpolation_mode :: var Gradient.interpolation_mode: Gradient.InterpolationMode
The algorithm used to interpolate between points of the gradient.

## offsets :: var Gradient.offsets: PackedFloat32Array
Gradient's offsets as a [PackedFloat32Array].
[b]Note:[/b] Setting this property updates all offsets at once. To update any offset individually use [method set_offset].

## add_point :: func Gradient.add_point(offset: float, color: Color) -> void
Adds the specified color to the gradient, with the specified offset.

### offset :: float

### color :: Color

## get_color :: func Gradient.get_color(point: int) -> Color
Returns the color of the gradient color at index [param point].

### point :: int

## get_offset :: func Gradient.get_offset(point: int) -> float
Returns the offset of the gradient color at index [param point].

### point :: int

## get_point_count :: func Gradient.get_point_count() -> int
Returns the number of colors in the gradient.

## remove_point :: func Gradient.remove_point(point: int) -> void
Removes the color at index [param point].

### point :: int

## reverse :: func Gradient.reverse() -> void
Reverses/mirrors the gradient.
[b]Note:[/b] This method mirrors all points around the middle of the gradient, which may produce unexpected results when [member interpolation_mode] is set to [constant GRADIENT_INTERPOLATE_CONSTANT].

## sample :: func Gradient.sample(offset: float) -> Color
Returns the interpolated color specified by [param offset]. [param offset] should be between [code]0.0[/code] and [code]1.0[/code] (inclusive). Using a value lower than [code]0.0[/code] will return the same color as [code]0.0[/code], and using a value higher than [code]1.0[/code] will return the same color as [code]1.0[/code]. If your input value is not within this range, consider using [method @GlobalScope.remap] on the input value with output values set to [code]0.0[/code] and [code]1.0[/code].

### offset :: float

## set_color :: func Gradient.set_color(point: int, color: Color) -> void
Sets the color of the gradient color at index [param point].

### point :: int

### color :: Color

## set_offset :: func Gradient.set_offset(point: int, offset: float) -> void
Sets the offset for the gradient color at index [param point].

### point :: int

### offset :: float
