# PhysicalBone3D :: <Native> class PhysicalBone3D extends PhysicsBody3D
A physics body used to make bones in a [Skeleton3D] react to physics.
The [PhysicalBone3D] node is a physics body that can be used to make bones in a [Skeleton3D] react to physics.
[b]Note:[/b] In order to detect physical bones with raycasts, the [member SkeletonModifier3D.active] property of the parent [PhysicalBoneSimulator3D] must be [code]true[/code] and the [Skeleton3D]'s bone must be assigned to [PhysicalBone3D] correctly; it means that [method get_bone_id] should return a valid id ([code]>= 0[/code]).

## DAMP_MODE_COMBINE :: const PhysicalBone3D.DAMP_MODE_COMBINE: DampMode = 0
In this mode, the body's damping value is added to any value set in areas or the default value.

## DAMP_MODE_REPLACE :: const PhysicalBone3D.DAMP_MODE_REPLACE: DampMode = 1
In this mode, the body's damping value replaces any value set in areas or the default value.

## JOINT_TYPE_NONE :: const PhysicalBone3D.JOINT_TYPE_NONE: JointType = 0
No joint is applied to the PhysicsBone3D.

## JOINT_TYPE_PIN :: const PhysicalBone3D.JOINT_TYPE_PIN: JointType = 1
A pin joint is applied to the PhysicsBone3D.

## JOINT_TYPE_CONE :: const PhysicalBone3D.JOINT_TYPE_CONE: JointType = 2
A cone joint is applied to the PhysicsBone3D.

## JOINT_TYPE_HINGE :: const PhysicalBone3D.JOINT_TYPE_HINGE: JointType = 3
A hinge joint is applied to the PhysicsBone3D.

## JOINT_TYPE_SLIDER :: const PhysicalBone3D.JOINT_TYPE_SLIDER: JointType = 4
A slider joint is applied to the PhysicsBone3D.

## JOINT_TYPE_6DOF :: const PhysicalBone3D.JOINT_TYPE_6DOF: JointType = 5
A 6 degrees of freedom joint is applied to the PhysicsBone3D.

## angular_damp :: var PhysicalBone3D.angular_damp: float
Damps the body's rotation. By default, the body will use the [member ProjectSettings.physics/3d/default_angular_damp] project setting or any value override set by an [Area3D] the body is in. Depending on [member angular_damp_mode], you can set [member angular_damp] to be added to or to replace the body's damping value.
See [member ProjectSettings.physics/3d/default_angular_damp] for more details about damping.

## angular_damp_mode :: var PhysicalBone3D.angular_damp_mode: PhysicalBone3D.DampMode
Defines how [member angular_damp] is applied.

## angular_velocity :: var PhysicalBone3D.angular_velocity: Vector3
The PhysicalBone3D's rotational velocity in [i]radians[/i] per second.

## body_offset :: var PhysicalBone3D.body_offset: Transform3D
Sets the body's transform.

## bounce :: var PhysicalBone3D.bounce: float
The body's bounciness. Values range from [code]0[/code] (no bounce) to [code]1[/code] (full bounciness).
[b]Note:[/b] Even with [member bounce] set to [code]1.0[/code], some energy will be lost over time due to linear and angular damping. To have a [PhysicalBone3D] that preserves all its energy over time, set [member bounce] to [code]1.0[/code], [member linear_damp_mode] to [constant DAMP_MODE_REPLACE], [member linear_damp] to [code]0.0[/code], [member angular_damp_mode] to [constant DAMP_MODE_REPLACE], and [member angular_damp] to [code]0.0[/code].

## can_sleep :: var PhysicalBone3D.can_sleep: bool
If [code]true[/code], the body is deactivated when there is no movement, so it will not take part in the simulation until it is awakened by an external force.

## custom_integrator :: var PhysicalBone3D.custom_integrator: bool
If [code]true[/code], the standard force integration (like gravity or damping) will be disabled for this body. Other than collision response, the body will only move as determined by the [method _integrate_forces] method, if that virtual method is overridden.
Setting this property will call the method [method PhysicsServer3D.body_set_omit_force_integration] internally.

## friction :: var PhysicalBone3D.friction: float
The body's friction, from [code]0[/code] (frictionless) to [code]1[/code] (max friction).

## gravity_scale :: var PhysicalBone3D.gravity_scale: float
This is multiplied by [member ProjectSettings.physics/3d/default_gravity] to produce this body's gravity. For example, a value of [code]1.0[/code] will apply normal gravity, [code]2.0[/code] will apply double the gravity, and [code]0.5[/code] will apply half the gravity to this body.

## joint_offset :: var PhysicalBone3D.joint_offset: Transform3D
Sets the joint's transform.

## joint_rotation :: var PhysicalBone3D.joint_rotation: Vector3
Sets the joint's rotation in radians.

## joint_type :: var PhysicalBone3D.joint_type: PhysicalBone3D.JointType
Sets the joint type.

## linear_damp :: var PhysicalBone3D.linear_damp: float
Damps the body's movement. By default, the body will use [member ProjectSettings.physics/3d/default_linear_damp] or any value override set by an [Area3D] the body is in. Depending on [member linear_damp_mode], [member linear_damp] may be added to or replace the body's damping value.
See [member ProjectSettings.physics/3d/default_linear_damp] for more details about damping.

## linear_damp_mode :: var PhysicalBone3D.linear_damp_mode: PhysicalBone3D.DampMode
Defines how [member linear_damp] is applied.

## linear_velocity :: var PhysicalBone3D.linear_velocity: Vector3
The body's linear velocity in units per second. Can be used sporadically, but [b]don't set this every frame[/b], because physics may run in another thread and runs at a different granularity. Use [method _integrate_forces] as your process loop for precise control of the body state.

## mass :: var PhysicalBone3D.mass: float
The body's mass.

## _integrate_forces :: func PhysicalBone3D._integrate_forces(state: PhysicsDirectBodyState3D) -> void
Called during physics processing, allowing you to read and safely modify the simulation state for the object. By default, it is called before the standard force integration, but the [member custom_integrator] property allows you to disable the standard force integration and do fully custom force integration for a body.

### state :: PhysicsDirectBodyState3D

## apply_central_impulse :: func PhysicalBone3D.apply_central_impulse(impulse: Vector3) -> void
Applies a directional impulse without affecting rotation.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_integrate_forces" functions otherwise).
This is equivalent to using [method apply_impulse] at the body's center of mass.

### impulse :: Vector3

## apply_impulse :: func PhysicalBone3D.apply_impulse(impulse: Vector3, position: Vector3 = Vector3(0, 0, 0)) -> void
Applies a positioned impulse to the PhysicsBone3D.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_integrate_forces" functions otherwise).
[param position] is the offset from the PhysicsBone3D origin in global coordinates.

### impulse :: Vector3

### position :: Vector3

## get_bone_id :: func PhysicalBone3D.get_bone_id() -> int
Returns the unique identifier of the PhysicsBone3D.

## get_simulate_physics :: func PhysicalBone3D.get_simulate_physics() -> bool
Returns [code]true[/code] if the PhysicsBone3D is allowed to simulate physics.

## is_simulating_physics :: func PhysicalBone3D.is_simulating_physics() -> bool
Returns [code]true[/code] if the PhysicsBone3D is currently simulating physics.
