# AudioStreamPlaybackOggVorbis :: <Native> class AudioStreamPlaybackOggVorbis extends AudioStreamPlaybackResampled
Playback class used for [AudioStreamOggVorbis].
Playback component of [AudioStreamOggVorbis]. Uses [OggPacketSequencePlayback] for playback data.
