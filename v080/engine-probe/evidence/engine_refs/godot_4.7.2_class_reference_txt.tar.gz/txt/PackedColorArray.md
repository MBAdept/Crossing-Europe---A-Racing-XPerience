# PackedColorArray :: <Native> class PackedColorArray
A packed array of [Color]s.
An array specifically designed to hold [Color]. Packs data tightly, so it saves memory for large array sizes.
[b]Differences between packed arrays, typed arrays, and untyped arrays:[/b] Packed arrays are generally faster to iterate on and modify compared to a typed array of the same type (e.g. [PackedColorArray] versus [code]Array[Color][/code]). Also, packed arrays consume less memory. As a downside, packed arrays are less flexible as they don't offer as many convenience methods such as [method Array.map]. Typed arrays are in turn faster to iterate on and modify than untyped arrays.
[b]Note:[/b] Packed arrays are always passed by reference. To get a copy of an array that can be modified independently of the original array, use [method duplicate]. This is [i]not[/i] the case for built-in properties and methods. In these cases the returned packed array is a copy, and changing it will [i]not[/i] affect the original value. To update a built-in property of this type, modify the returned array and then assign it to the property again.
[b]Note:[/b] In a boolean context, a packed array will evaluate to [code]false[/code] if it's empty. Otherwise, a packed array will always evaluate to [code]true[/code].

## append :: func PackedColorArray.append(value: Color) -> bool
Appends an element at the end of the array (alias of [method push_back]).

### value :: Color

## append_array :: func PackedColorArray.append_array(array: PackedColorArray) -> void
Appends a [PackedColorArray] at the end of this array.

### array :: PackedColorArray

## bsearch :: func PackedColorArray.bsearch(value: Color, before: bool = true) -> int
Finds the index of an existing value (or the insertion index that maintains sorting order, if the value is not yet present in the array) using binary search. Optionally, a [param before] specifier can be passed. If [code]false[/code], the returned index comes after all existing entries of the value in the array.
[b]Note:[/b] Calling [method bsearch] on an unsorted array results in unexpected behavior.

### value :: Color

### before :: bool

## clear :: func PackedColorArray.clear() -> void
Clears the array. This is equivalent to using [method resize] with a size of [code]0[/code].

## count :: func PackedColorArray.count(value: Color) -> int
Returns the number of times an element is in the array.

### value :: Color

## duplicate :: func PackedColorArray.duplicate() -> PackedColorArray
Creates a copy of the array, and returns it.

## erase :: func PackedColorArray.erase(value: Color) -> bool
Removes the first occurrence of a value from the array and returns [code]true[/code]. If the value does not exist in the array, nothing happens and [code]false[/code] is returned. To remove an element by index, use [method remove_at] instead.

### value :: Color

## fill :: func PackedColorArray.fill(value: Color) -> void
Assigns the given value to all elements in the array. This can typically be used together with [method resize] to create an array with a given size and initialized elements.

### value :: Color

## find :: func PackedColorArray.find(value: Color, from: int = 0) -> int
Searches the array for a value and returns its index or [code]-1[/code] if not found. Optionally, the initial search index can be passed.

### value :: Color

### from :: int

## get :: func PackedColorArray.get(index: int) -> Color
Returns the [Color] at the given [param index] in the array. If [param index] is out-of-bounds or negative, this method fails and returns [code]Color(0, 0, 0, 1)[/code].
This method is similar (but not identical) to the [code][][/code] operator. Most notably, when this method fails, it doesn't pause project execution if run from the editor.

### index :: int

## has :: func PackedColorArray.has(value: Color) -> bool
Returns [code]true[/code] if the array contains [param value].

### value :: Color

## insert :: func PackedColorArray.insert(at_index: int, value: Color) -> int
Inserts a new element at a given position in the array. The position must be valid, or at the end of the array ([code]idx == size()[/code]).

### at_index :: int

### value :: Color

## is_empty :: func PackedColorArray.is_empty() -> bool
Returns [code]true[/code] if the array is empty.

## push_back :: func PackedColorArray.push_back(value: Color) -> bool
Appends a value to the array.

### value :: Color

## remove_at :: func PackedColorArray.remove_at(index: int) -> void
Removes an element from the array by index.

### index :: int

## resize :: func PackedColorArray.resize(new_size: int) -> int
Sets the size of the array. If the array is grown, reserves elements at the end of the array. If the array is shrunk, truncates the array to the new size. Calling [method resize] once and assigning the new values is faster than adding new elements one by one.
Returns [constant OK] on success, or one of the following [enum Error] constants if this method fails: [constant ERR_INVALID_PARAMETER] if the size is negative, or [constant ERR_OUT_OF_MEMORY] if allocations fail. Use [method size] to find the actual size of the array after resize.

### new_size :: int

## reverse :: func PackedColorArray.reverse() -> void
Reverses the order of the elements in the array.

## rfind :: func PackedColorArray.rfind(value: Color, from: int = -1) -> int
Searches the array in reverse order. Optionally, a start search index can be passed. If negative, the start index is considered relative to the end of the array.

### value :: Color

### from :: int

## set :: func PackedColorArray.set(index: int, value: Color) -> void
Changes the [Color] at the given index.

### index :: int

### value :: Color

## size :: func PackedColorArray.size() -> int
Returns the number of elements in the array.

## slice :: func PackedColorArray.slice(begin: int, end: int = 2147483647) -> PackedColorArray
Returns the slice of the [PackedColorArray], from [param begin] (inclusive) to [param end] (exclusive), as a new [PackedColorArray].
The absolute value of [param begin] and [param end] will be clamped to the array size, so the default value for [param end] makes it slice to the size of the array by default (i.e. [code]arr.slice(1)[/code] is a shorthand for [code]arr.slice(1, arr.size())[/code]).
If either [param begin] or [param end] are negative, they will be relative to the end of the array (i.e. [code]arr.slice(0, -2)[/code] is a shorthand for [code]arr.slice(0, arr.size() - 2)[/code]).

### begin :: int

### end :: int

## sort :: func PackedColorArray.sort() -> void
Sorts the elements of the array in ascending order.

## to_byte_array :: func PackedColorArray.to_byte_array() -> PackedByteArray
Returns a [PackedByteArray] with each color encoded as bytes.

## PackedColorArray :: func PackedColorArray.PackedColorArray() -> PackedColorArray
Constructs an empty [PackedColorArray].

## PackedColorArray :: func PackedColorArray.PackedColorArray(from: PackedColorArray) -> PackedColorArray
Constructs a [PackedColorArray] as a copy of the given [PackedColorArray].

### from :: PackedColorArray

## PackedColorArray :: func PackedColorArray.PackedColorArray(from: Array) -> PackedColorArray
Constructs a new [PackedColorArray]. Optionally, you can pass in a generic [Array] that will be converted.
[b]Note:[/b] When initializing a [PackedColorArray] with elements, it must be initialized with an [Array] of [Color] values:
[codeblock]
var array = PackedColorArray([Color(0.1, 0.2, 0.3), Color(0.4, 0.5, 0.6)])
[/codeblock]

### from :: Array

## operator != :: func PackedColorArray.operator !=(right: PackedColorArray) -> bool
Returns [code]true[/code] if contents of the arrays differ.

### right :: PackedColorArray

## operator + :: func PackedColorArray.operator +(right: PackedColorArray) -> PackedColorArray
Returns a new [PackedColorArray] with contents of [param right] added at the end of this array. For better performance, consider using [method append_array] instead.

### right :: PackedColorArray

## operator == :: func PackedColorArray.operator ==(right: PackedColorArray) -> bool
Returns [code]true[/code] if contents of both arrays are the same, i.e. they have all equal [Color]s at the corresponding indices.

### right :: PackedColorArray

## operator [] :: func PackedColorArray.operator [](index: int) -> Color
Returns the [Color] at index [param index]. Negative indices can be used to access the elements starting from the end. Using index out of array's bounds will result in an error.

### index :: int
