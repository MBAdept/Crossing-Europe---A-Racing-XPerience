# AnimationNodeStateMachinePlayback :: <Native> class AnimationNodeStateMachinePlayback extends Resource
Provides playback control for an [AnimationNodeStateMachine].
Allows control of [AnimationTree] state machines created with [AnimationNodeStateMachine]. Retrieve with [code]$AnimationTree.get("parameters/playback")[/code].
[codeblocks]
[gdscript]
var state_machine = $AnimationTree.get("parameters/playback")
state_machine.travel("some_state")
[/gdscript]
[csharp]
var stateMachine = GetNode<AnimationTree>("AnimationTree").Get("parameters/playback").As<AnimationNodeStateMachinePlayback>();
stateMachine.Travel("some_state");
[/csharp]
[/codeblocks]

## resource_local_to_scene :: var AnimationNodeStateMachinePlayback.resource_local_to_scene: bool

## get_current_length :: func AnimationNodeStateMachinePlayback.get_current_length() -> float
Returns the current state length.
[b]Note:[/b] It is possible that any [AnimationRootNode] can be nodes as well as animations. This means that there can be multiple animations within a single state. Which animation length has priority depends on the nodes connected inside it. Also, if a transition does not reset, the remaining length at that point will be returned.

## get_current_node :: func AnimationNodeStateMachinePlayback.get_current_node() -> StringName
Returns the currently playing animation state.
[b]Note:[/b] When using a cross-fade, the current state changes to the next state immediately after the cross-fade begins.

## get_current_play_position :: func AnimationNodeStateMachinePlayback.get_current_play_position() -> float
Returns the playback position within the current animation state.

## get_fading_from_length :: func AnimationNodeStateMachinePlayback.get_fading_from_length() -> float
Returns the playback state length of the node from [method get_fading_from_node]. Returns [code]0[/code] if no animation fade is occurring.

## get_fading_from_node :: func AnimationNodeStateMachinePlayback.get_fading_from_node() -> StringName
Returns the starting state of currently fading animation.

## get_fading_from_play_position :: func AnimationNodeStateMachinePlayback.get_fading_from_play_position() -> float
Returns the playback position of the node from [method get_fading_from_node]. Returns [code]0[/code] if no animation fade is occurring.

## get_fading_length :: func AnimationNodeStateMachinePlayback.get_fading_length() -> float
Returns the length of the current fade animation. Returns [code]0[/code] if no animation fade is occurring.

## get_fading_position :: func AnimationNodeStateMachinePlayback.get_fading_position() -> float
Returns the playback position of the current fade animation. Returns [code]0[/code] if no animation fade is occurring.

## get_travel_path :: func AnimationNodeStateMachinePlayback.get_travel_path() -> StringName[]
Returns the current travel path as computed internally by the A* algorithm.

## is_playing :: func AnimationNodeStateMachinePlayback.is_playing() -> bool
Returns [code]true[/code] if an animation is playing.

## next :: func AnimationNodeStateMachinePlayback.next() -> void
If there is a next path by travel or auto advance, immediately transitions from the current state to the next state.

## start :: func AnimationNodeStateMachinePlayback.start(node: StringName, reset: bool = true) -> void
Starts playing the given animation.
If [param reset] is [code]true[/code], the animation is played from the beginning.

### node :: StringName

### reset :: bool

## stop :: func AnimationNodeStateMachinePlayback.stop() -> void
Stops the currently playing animation.

## travel :: func AnimationNodeStateMachinePlayback.travel(to_node: StringName, reset_on_teleport: bool = true) -> void
Transitions from the current state to another one, following the shortest path.
If the path does not connect from the current state, the animation will play after the state teleports.
If [param reset_on_teleport] is [code]true[/code], the animation is played from the beginning when the travel cause a teleportation.

### to_node :: StringName

### reset_on_teleport :: bool

## state_finished :: func AnimationNodeStateMachinePlayback.state_finished(state: StringName) -> void
Emitted when the [param state] finishes playback. If [param state] is a state machine set to grouped mode, its signals are passed through with its name prefixed.
If there is a crossfade, this will be fired when the influence of the [method get_fading_from_node] animation is no longer present.

### state :: StringName

## state_started :: func AnimationNodeStateMachinePlayback.state_started(state: StringName) -> void
Emitted when the [param state] starts playback. If [param state] is a state machine set to grouped mode, its signals are passed through with its name prefixed.

### state :: StringName
