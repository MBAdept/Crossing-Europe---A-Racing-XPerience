# PackedVector3Array :: <Native> class PackedVector3Array
A packed array of [Vector3]s.
An array specifically designed to hold [Vector3]. Packs data tightly, so it saves memory for large array sizes.
[b]Differences between packed arrays, typed arrays, and untyped arrays:[/b] Packed arrays are generally faster to iterate on and modify compared to a typed array of the same type (e.g. [PackedVector3Array] versus [code]Array[Vector3][/code]). Also, packed arrays consume less memory. As a downside, packed arrays are less flexible as they don't offer as many convenience methods such as [method Array.map]. Typed arrays are in turn faster to iterate on and modify than untyped arrays.
[b]Note:[/b] Packed arrays are always passed by reference. To get a copy of an array that can be modified independently of the original array, use [method duplicate]. This is [i]not[/i] the case for built-in properties and methods. In these cases the returned packed array is a copy, and changing it will [i]not[/i] affect the original value. To update a built-in property of this type, modify the returned array and then assign it to the property again.
[b]Note:[/b] In a boolean context, a packed array will evaluate to [code]false[/code] if it's empty. Otherwise, a packed array will always evaluate to [code]true[/code].

## append :: func PackedVector3Array.append(value: Vector3) -> bool
Appends an element at the end of the array (alias of [method push_back]).

### value :: Vector3

## append_array :: func PackedVector3Array.append_array(array: PackedVector3Array) -> void
Appends a [PackedVector3Array] at the end of this array.

### array :: PackedVector3Array

## bsearch :: func PackedVector3Array.bsearch(value: Vector3, before: bool = true) -> int
Finds the index of an existing value (or the insertion index that maintains sorting order, if the value is not yet present in the array) using binary search. Optionally, a [param before] specifier can be passed. If [code]false[/code], the returned index comes after all existing entries of the value in the array.
[b]Note:[/b] Calling [method bsearch] on an unsorted array results in unexpected behavior.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector3

### before :: bool

## clear :: func PackedVector3Array.clear() -> void
Clears the array. This is equivalent to using [method resize] with a size of [code]0[/code].

## count :: func PackedVector3Array.count(value: Vector3) -> int
Returns the number of times an element is in the array.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector3

## duplicate :: func PackedVector3Array.duplicate() -> PackedVector3Array
Creates a copy of the array, and returns it.

## erase :: func PackedVector3Array.erase(value: Vector3) -> bool
Removes the first occurrence of a value from the array and returns [code]true[/code]. If the value does not exist in the array, nothing happens and [code]false[/code] is returned. To remove an element by index, use [method remove_at] instead.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector3

## fill :: func PackedVector3Array.fill(value: Vector3) -> void
Assigns the given value to all elements in the array. This can typically be used together with [method resize] to create an array with a given size and initialized elements.

### value :: Vector3

## find :: func PackedVector3Array.find(value: Vector3, from: int = 0) -> int
Searches the array for a value and returns its index or [code]-1[/code] if not found. Optionally, the initial search index can be passed.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector3

### from :: int

## get :: func PackedVector3Array.get(index: int) -> Vector3
Returns the [Vector3] at the given [param index] in the array. If [param index] is out-of-bounds or negative, this method fails and returns [code]Vector3(0, 0, 0)[/code].
This method is similar (but not identical) to the [code][][/code] operator. Most notably, when this method fails, it doesn't pause project execution if run from the editor.

### index :: int

## has :: func PackedVector3Array.has(value: Vector3) -> bool
Returns [code]true[/code] if the array contains [param value].
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector3

## insert :: func PackedVector3Array.insert(at_index: int, value: Vector3) -> int
Inserts a new element at a given position in the array. The position must be valid, or at the end of the array ([code]idx == size()[/code]).

### at_index :: int

### value :: Vector3

## is_empty :: func PackedVector3Array.is_empty() -> bool
Returns [code]true[/code] if the array is empty.

## push_back :: func PackedVector3Array.push_back(value: Vector3) -> bool
Inserts a [Vector3] at the end.

### value :: Vector3

## remove_at :: func PackedVector3Array.remove_at(index: int) -> void
Removes an element from the array by index.

### index :: int

## resize :: func PackedVector3Array.resize(new_size: int) -> int
Sets the size of the array. If the array is grown, reserves elements at the end of the array. If the array is shrunk, truncates the array to the new size. Calling [method resize] once and assigning the new values is faster than adding new elements one by one.
Returns [constant OK] on success, or one of the following [enum Error] constants if this method fails: [constant ERR_INVALID_PARAMETER] if the size is negative, or [constant ERR_OUT_OF_MEMORY] if allocations fail. Use [method size] to find the actual size of the array after resize.

### new_size :: int

## reverse :: func PackedVector3Array.reverse() -> void
Reverses the order of the elements in the array.

## rfind :: func PackedVector3Array.rfind(value: Vector3, from: int = -1) -> int
Searches the array in reverse order. Optionally, a start search index can be passed. If negative, the start index is considered relative to the end of the array.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector3

### from :: int

## set :: func PackedVector3Array.set(index: int, value: Vector3) -> void
Changes the [Vector3] at the given index.

### index :: int

### value :: Vector3

## size :: func PackedVector3Array.size() -> int
Returns the number of elements in the array.

## slice :: func PackedVector3Array.slice(begin: int, end: int = 2147483647) -> PackedVector3Array
Returns the slice of the [PackedVector3Array], from [param begin] (inclusive) to [param end] (exclusive), as a new [PackedVector3Array].
The absolute value of [param begin] and [param end] will be clamped to the array size, so the default value for [param end] makes it slice to the size of the array by default (i.e. [code]arr.slice(1)[/code] is a shorthand for [code]arr.slice(1, arr.size())[/code]).
If either [param begin] or [param end] are negative, they will be relative to the end of the array (i.e. [code]arr.slice(0, -2)[/code] is a shorthand for [code]arr.slice(0, arr.size() - 2)[/code]).

### begin :: int

### end :: int

## sort :: func PackedVector3Array.sort() -> void
Sorts the elements of the array in ascending order.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

## to_byte_array :: func PackedVector3Array.to_byte_array() -> PackedByteArray
Returns a [PackedByteArray] with each vector encoded as bytes.

## PackedVector3Array :: func PackedVector3Array.PackedVector3Array() -> PackedVector3Array
Constructs an empty [PackedVector3Array].

## PackedVector3Array :: func PackedVector3Array.PackedVector3Array(from: PackedVector3Array) -> PackedVector3Array
Constructs a [PackedVector3Array] as a copy of the given [PackedVector3Array].

### from :: PackedVector3Array

## PackedVector3Array :: func PackedVector3Array.PackedVector3Array(from: Array) -> PackedVector3Array
Constructs a new [PackedVector3Array]. Optionally, you can pass in a generic [Array] that will be converted.
[b]Note:[/b] When initializing a [PackedVector3Array] with elements, it must be initialized with an [Array] of [Vector3] values:
[codeblock]
var array = PackedVector3Array([Vector3(12, 34, 56), Vector3(78, 90, 12)])
[/codeblock]

### from :: Array

## operator != :: func PackedVector3Array.operator !=(right: PackedVector3Array) -> bool
Returns [code]true[/code] if contents of the arrays differ.

### right :: PackedVector3Array

## operator * :: func PackedVector3Array.operator *(right: Transform3D) -> PackedVector3Array
Returns a new [PackedVector3Array] with all vectors in this array inversely transformed (multiplied) by the given [Transform3D] transformation matrix, under the assumption that the transformation basis is orthonormal (i.e. rotation/reflection is fine, scaling/skew is not).
[code]array * transform[/code] is equivalent to [code]transform.inverse() * array[/code]. See [method Transform3D.inverse].
For transforming by inverse of an affine transformation (e.g. with scaling) [code]transform.affine_inverse() * array[/code] can be used instead. See [method Transform3D.affine_inverse].

### right :: Transform3D

## operator + :: func PackedVector3Array.operator +(right: PackedVector3Array) -> PackedVector3Array
Returns a new [PackedVector3Array] with contents of [param right] added at the end of this array. For better performance, consider using [method append_array] instead.

### right :: PackedVector3Array

## operator == :: func PackedVector3Array.operator ==(right: PackedVector3Array) -> bool
Returns [code]true[/code] if contents of both arrays are the same, i.e. they have all equal [Vector3]s at the corresponding indices.

### right :: PackedVector3Array

## operator [] :: func PackedVector3Array.operator [](index: int) -> Vector3
Returns the [Vector3] at index [param index]. Negative indices can be used to access the elements starting from the end. Using index out of array's bounds will result in an error.

### index :: int
