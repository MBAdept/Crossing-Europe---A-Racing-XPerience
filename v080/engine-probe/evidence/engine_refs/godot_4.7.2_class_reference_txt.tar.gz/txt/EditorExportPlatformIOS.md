# EditorExportPlatformIOS :: <Native> class EditorExportPlatformIOS extends EditorExportPlatformAppleEmbedded
Exporter for iOS.

## application/additional_plist_content :: var EditorExportPlatformIOS.application/additional_plist_content: String
Additional data added to the root [code]<dict>[/code] section of the [url=https://developer.apple.com/documentation/bundleresources/information_property_list]Info.plist[/url] file. The value should be an XML section with pairs of key-value elements, e.g.:
[codeblock lang=text]
<key>key_name</key>
<string>value</string>
[/codeblock]

## application/app_store_team_id :: var EditorExportPlatformIOS.application/app_store_team_id: String
Apple Team ID, unique 10-character string. To locate your Team ID check "Membership details" section in your Apple developer account dashboard, or "Organizational Unit" of your code signing certificate. See [url=https://developer.apple.com/help/account/manage-your-team/locate-your-team-id]Locate your Team ID[/url].

## application/bundle_identifier :: var EditorExportPlatformIOS.application/bundle_identifier: String
Unique application identifier in a reverse-DNS format, can only contain alphanumeric characters ([code]A-Z[/code], [code]a-z[/code], and [code]0-9[/code]), hyphens ([code]-[/code]), and periods ([code].[/code]).

## application/code_sign_identity_debug :: var EditorExportPlatformIOS.application/code_sign_identity_debug: String
The "Full Name", "Common Name", or SHA-1 hash of the signing identity used for debug export.

## application/code_sign_identity_release :: var EditorExportPlatformIOS.application/code_sign_identity_release: String
The "Full Name", "Common Name", or SHA-1 hash of the signing identity used for release export.

## application/delete_old_export_files_unconditionally :: var EditorExportPlatformIOS.application/delete_old_export_files_unconditionally: bool
If [code]true[/code], existing "project name" and "project name.xcodeproj" in the export destination directory will be unconditionally deleted during export.

## application/export_method_debug :: var EditorExportPlatformIOS.application/export_method_debug: int
Application distribution target (debug export).

## application/export_method_release :: var EditorExportPlatformIOS.application/export_method_release: int
Application distribution target (release export).

## application/export_project_only :: var EditorExportPlatformIOS.application/export_project_only: bool
If [code]true[/code], exports iOS project files without building an XCArchive or [code].ipa[/code] file. If [code]false[/code], exports iOS project files and builds an XCArchive and [code].ipa[/code] file at the same time. When combining Godot with Fastlane or other build pipelines, you may want to set this to [code]true[/code].

## application/icon_interpolation :: var EditorExportPlatformIOS.application/icon_interpolation: int
Interpolation method used to resize application icon.

## application/min_ios_version :: var EditorExportPlatformIOS.application/min_ios_version: String
Minimum version of iOS required for this application to run in the [code]major.minor.patch[/code] or [code]major.minor[/code] format, can only contain numeric characters ([code]0-9[/code]) and periods ([code].[/code]).

## application/provisioning_profile_specifier_debug :: var EditorExportPlatformIOS.application/provisioning_profile_specifier_debug: String
Name of the provisioning profile. Sets Xcode PROVISIONING_PROFILE_SPECIFIER for debug. [url=https://developer.apple.com/documentation/xcode/build-settings-reference#Provisioning-Profile]Used for manual provisioning[/url].
Can be overridden with the environment variable [code]GODOT_APPLE_PLATFORM_PROFILE_SPECIFIER_DEBUG[/code].

## application/provisioning_profile_specifier_release :: var EditorExportPlatformIOS.application/provisioning_profile_specifier_release: String
Name of the provisioning profile. Sets Xcode PROVISIONING_PROFILE_SPECIFIER for release. [url=https://developer.apple.com/documentation/xcode/build-settings-reference#Provisioning-Profile]Used for manual provisioning[/url].
Can be overridden with the environment variable [code]GODOT_APPLE_PLATFORM_PROFILE_SPECIFIER_RELEASE[/code].

## application/provisioning_profile_uuid_debug :: var EditorExportPlatformIOS.application/provisioning_profile_uuid_debug: String
UUID of the provisioning profile. If left empty, Xcode will download or create a provisioning profile automatically. See [url=https://developer.apple.com/help/account/manage-profiles/edit-download-or-delete-profiles]Edit, download, or delete provisioning profiles[/url].
Can be overridden with the environment variable [code]GODOT_APPLE_PLATFORM_PROVISIONING_PROFILE_UUID_DEBUG[/code].

## application/provisioning_profile_uuid_release :: var EditorExportPlatformIOS.application/provisioning_profile_uuid_release: String
UUID of the provisioning profile. If left empty, Xcode will download or create a provisioning profile automatically. See [url=https://developer.apple.com/help/account/manage-profiles/edit-download-or-delete-profiles]Edit, download, or delete provisioning profiles[/url].
Can be overridden with the environment variable [code]GODOT_APPLE_PLATFORM_PROVISIONING_PROFILE_UUID_RELEASE[/code].

## application/short_version :: var EditorExportPlatformIOS.application/short_version: String
Application version visible to the user. Can only contain numeric characters ([code]0-9[/code]) and periods ([code].[/code]). Falls back to [member ProjectSettings.application/config/version] if left empty.
[b]Note:[/b] This value is used for the [i]Identity > Version[/i] value in the generated Xcode project.

## application/signature :: var EditorExportPlatformIOS.application/signature: String
A four-character creator code that is specific to the bundle. Optional.

## application/targeted_device_family :: var EditorExportPlatformIOS.application/targeted_device_family: int
Supported device family.

## application/version :: var EditorExportPlatformIOS.application/version: String
Machine-readable application version in the [code]major.minor.patch[/code] format. Can only contain numeric characters ([code]0-9[/code]) and periods ([code].[/code]). This must be incremented with every new release pushed to the App Store. Falls back to [member ProjectSettings.application/config/version] if left empty.
[b]Note:[/b] This value is used for the [i]Identity > Build[/i] value in the generated Xcode project.

## architectures/arm64 :: var EditorExportPlatformIOS.architectures/arm64: bool
If [code]true[/code], [code]arm64[/code] binaries are included into exported project.

## capabilities/access_wifi :: var EditorExportPlatformIOS.capabilities/access_wifi: bool
If [code]true[/code], networking features related to Wi-Fi access are enabled. See [url=https://developer.apple.com/support/required-device-capabilities/]Required Device Capabilities[/url].

## capabilities/additional :: var EditorExportPlatformIOS.capabilities/additional: PackedStringArray
Additional data added to the [code]UIRequiredDeviceCapabilities[/code] array of the [code]Info.plist[/code] file.

## capabilities/performance_a12 :: var EditorExportPlatformIOS.capabilities/performance_a12: bool
Requires the graphics performance and features of the A12 Bionic and later chips (devices supporting all Vulkan renderer features).
Enabling this option limits supported devices to: iPhone XS, iPhone XR, iPad Mini (5th gen.), iPad Air (3rd gen.), iPad (8th gen), and newer.

## capabilities/performance_gaming_tier :: var EditorExportPlatformIOS.capabilities/performance_gaming_tier: bool
Requires the graphics performance and features of the A17 Pro and later chips.
Enabling this option limits supported devices to: iPhone 15 Pro and newer.

## custom_template/debug :: var EditorExportPlatformIOS.custom_template/debug: String
Path to the custom export template. If left empty, default template is used.

## custom_template/release :: var EditorExportPlatformIOS.custom_template/release: String
Path to the custom export template. If left empty, default template is used.

## entitlements/additional :: var EditorExportPlatformIOS.entitlements/additional: String
Additional data added to the root [code]<dict>[/code] section of the [url=https://developer.apple.com/documentation/bundleresources/entitlements].entitlements[/url] file. The value should be an XML section with pairs of key-value elements, for example:
[codeblock lang=text]
<key>key_name</key>
<string>value</string>
[/codeblock]

## entitlements/game_center :: var EditorExportPlatformIOS.entitlements/game_center: bool
If [code]true[/code], allows access to Game Center features. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_developer_game-center]com.apple.developer.game-center[/url].

## entitlements/increased_memory_limit :: var EditorExportPlatformIOS.entitlements/increased_memory_limit: bool
If [code]true[/code], hints that the app might perform better with a higher memory limit. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_developer_kernel_increased-memory-limit]com.apple.developer.kernel.increased-memory-limit[/url].

## entitlements/push_notifications :: var EditorExportPlatformIOS.entitlements/push_notifications: String
Environment for Apple Push Notification service. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/aps-environment]aps-environment[/url].

## icons/app_store_1024x1024 :: var EditorExportPlatformIOS.icons/app_store_1024x1024: String
App Store application icon file. If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/app_store_1024x1024_dark :: var EditorExportPlatformIOS.icons/app_store_1024x1024_dark: String
App Store application icon file, dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/app_store_1024x1024_tinted :: var EditorExportPlatformIOS.icons/app_store_1024x1024_tinted: String
App Store application icon file, tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/icon_1024x1024 :: var EditorExportPlatformIOS.icons/icon_1024x1024: String
Base application icon used to generate other icons. If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/icon_1024x1024_dark :: var EditorExportPlatformIOS.icons/icon_1024x1024_dark: String
Base application icon used to generate other icons, dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/icon_1024x1024_tinted :: var EditorExportPlatformIOS.icons/icon_1024x1024_tinted: String
Base application icon used to generate other icons, tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ios_128x128 :: var EditorExportPlatformIOS.icons/ios_128x128: String
iOS application 64x64 icon file (2x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ios_128x128_dark :: var EditorExportPlatformIOS.icons/ios_128x128_dark: String
iOS application 64x64 icon file (2x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ios_128x128_tinted :: var EditorExportPlatformIOS.icons/ios_128x128_tinted: String
iOS application 64x64 icon file (2x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ios_136x136 :: var EditorExportPlatformIOS.icons/ios_136x136: String
iOS application 68x68 icon file (2x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ios_136x136_dark :: var EditorExportPlatformIOS.icons/ios_136x136_dark: String
iOS application 68x68 icon file (2x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ios_136x136_tinted :: var EditorExportPlatformIOS.icons/ios_136x136_tinted: String
iOS application 68x68 icon file (2x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ios_192x192 :: var EditorExportPlatformIOS.icons/ios_192x192: String
iOS application 64x64 icon file (3x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ios_192x192_dark :: var EditorExportPlatformIOS.icons/ios_192x192_dark: String
iOS application 64x64 icon file (3x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ios_192x192_tinted :: var EditorExportPlatformIOS.icons/ios_192x192_tinted: String
iOS application 64x64 icon file (3x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ipad_152x152 :: var EditorExportPlatformIOS.icons/ipad_152x152: String
Home screen application icon file on iPad (2x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ipad_152x152_dark :: var EditorExportPlatformIOS.icons/ipad_152x152_dark: String
Home screen application icon file on iPad (2x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ipad_152x152_tinted :: var EditorExportPlatformIOS.icons/ipad_152x152_tinted: String
Home screen application icon file on iPad (2x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ipad_167x167 :: var EditorExportPlatformIOS.icons/ipad_167x167: String
Home screen application icon file on iPad (3x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ipad_167x167_dark :: var EditorExportPlatformIOS.icons/ipad_167x167_dark: String
Home screen application icon file on iPad (3x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/ipad_167x167_tinted :: var EditorExportPlatformIOS.icons/ipad_167x167_tinted: String
Home screen application icon file on iPad (3x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/iphone_120x120 :: var EditorExportPlatformIOS.icons/iphone_120x120: String
Home screen application icon file on iPhone (2x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/iphone_120x120_dark :: var EditorExportPlatformIOS.icons/iphone_120x120_dark: String
Home screen application icon file on iPhone (2x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/iphone_120x120_tinted :: var EditorExportPlatformIOS.icons/iphone_120x120_tinted: String
Home screen application icon file on iPhone (2x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/iphone_180x180 :: var EditorExportPlatformIOS.icons/iphone_180x180: String
Home screen application icon file on iPhone (3x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/iphone_180x180_dark :: var EditorExportPlatformIOS.icons/iphone_180x180_dark: String
Home screen application icon file on iPhone (3x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/iphone_180x180_tinted :: var EditorExportPlatformIOS.icons/iphone_180x180_tinted: String
Home screen application icon file on iPhone (3x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_40x40 :: var EditorExportPlatformIOS.icons/notification_40x40: String
Notification icon file on iPad and iPhone (2x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_40x40_dark :: var EditorExportPlatformIOS.icons/notification_40x40_dark: String
Notification icon file on iPad and iPhone (2x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_40x40_tinted :: var EditorExportPlatformIOS.icons/notification_40x40_tinted: String
Notification icon file on iPad and iPhone (2x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_60x60 :: var EditorExportPlatformIOS.icons/notification_60x60: String
Notification icon file on iPhone (3x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_60x60_dark :: var EditorExportPlatformIOS.icons/notification_60x60_dark: String
Notification icon file on iPhone (3x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_60x60_tinted :: var EditorExportPlatformIOS.icons/notification_60x60_tinted: String
Notification icon file on iPhone (3x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_76x76 :: var EditorExportPlatformIOS.icons/notification_76x76: String
Notification icon file on iPad and iPhone (2x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_76x76_dark :: var EditorExportPlatformIOS.icons/notification_76x76_dark: String
Notification icon file on iPad and iPhone (2x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_76x76_tinted :: var EditorExportPlatformIOS.icons/notification_76x76_tinted: String
Notification icon file on iPad and iPhone (2x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_114x114 :: var EditorExportPlatformIOS.icons/notification_114x114: String
Notification icon file on iPad and iPhone (3x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_114x114_dark :: var EditorExportPlatformIOS.icons/notification_114x114_dark: String
Notification icon file on iPad and iPhone (3x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/notification_114x114_tinted :: var EditorExportPlatformIOS.icons/notification_114x114_tinted: String
Notification icon file on iPad and iPhone (3x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/settings_58x58 :: var EditorExportPlatformIOS.icons/settings_58x58: String
Application settings icon file on iPad and iPhone (2x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/settings_58x58_dark :: var EditorExportPlatformIOS.icons/settings_58x58_dark: String
Application settings icon file on iPad and iPhone (2x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/settings_58x58_tinted :: var EditorExportPlatformIOS.icons/settings_58x58_tinted: String
Application settings icon file on iPad and iPhone (2x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/settings_87x87 :: var EditorExportPlatformIOS.icons/settings_87x87: String
Application settings icon file on iPhone (3x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/settings_87x87_dark :: var EditorExportPlatformIOS.icons/settings_87x87_dark: String
Application settings icon file on iPhone (3x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/settings_87x87_tinted :: var EditorExportPlatformIOS.icons/settings_87x87_tinted: String
Application settings icon file on iPhone (3x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/spotlight_80x80 :: var EditorExportPlatformIOS.icons/spotlight_80x80: String
Spotlight icon file on iPad and iPhone (2x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/spotlight_80x80_dark :: var EditorExportPlatformIOS.icons/spotlight_80x80_dark: String
Spotlight icon file on iPad and iPhone (2x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/spotlight_80x80_tinted :: var EditorExportPlatformIOS.icons/spotlight_80x80_tinted: String
Spotlight icon file on iPad and iPhone (2x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/spotlight_120x120 :: var EditorExportPlatformIOS.icons/spotlight_120x120: String
Spotlight icon file on iPad and iPhone (3x DPI). If left empty, it will fallback to [member ProjectSettings.application/config/icon]. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/spotlight_120x120_dark :: var EditorExportPlatformIOS.icons/spotlight_120x120_dark: String
Spotlight icon file on iPad and iPhone (3x DPI), dark version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## icons/spotlight_120x120_tinted :: var EditorExportPlatformIOS.icons/spotlight_120x120_tinted: String
Spotlight icon file on iPad and iPhone (3x DPI), tinted version. See [url=https://developer.apple.com/design/human-interface-guidelines/foundations/app-icons]App icons[/url].

## modules/camera :: var EditorExportPlatformIOS.modules/camera: bool
If [code]true[/code], [CameraServer] module is added to the exported project.

## privacy/active_keyboard_access_reasons :: var EditorExportPlatformIOS.privacy/active_keyboard_access_reasons: int
The reasons your app use active keyboard API. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_use_of_required_reason_api]Describing use of required reason API[/url].

## privacy/camera_usage_description :: var EditorExportPlatformIOS.privacy/camera_usage_description: String
A message displayed when requesting access to the device's camera (in English).

## privacy/camera_usage_description_localized :: var EditorExportPlatformIOS.privacy/camera_usage_description_localized: Dictionary
A message displayed when requesting access to the device's camera (localized).

## privacy/collected_data/advertising_data/collected :: var EditorExportPlatformIOS.privacy/collected_data/advertising_data/collected: bool
Indicates whether your app collects advertising data.

## privacy/collected_data/advertising_data/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/advertising_data/collection_purposes: int
The reasons your app collects advertising data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/advertising_data/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/advertising_data/linked_to_user: bool
Indicates whether your app links advertising data to the user's identity.

## privacy/collected_data/advertising_data/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/advertising_data/used_for_tracking: bool
Indicates whether your app uses advertising data for tracking.

## privacy/collected_data/audio_data/collected :: var EditorExportPlatformIOS.privacy/collected_data/audio_data/collected: bool
Indicates whether your app collects audio data.

## privacy/collected_data/audio_data/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/audio_data/collection_purposes: int
The reasons your app collects audio data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/audio_data/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/audio_data/linked_to_user: bool
Indicates whether your app links audio data to the user's identity.

## privacy/collected_data/audio_data/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/audio_data/used_for_tracking: bool
Indicates whether your app uses audio data for tracking.

## privacy/collected_data/browsing_history/collected :: var EditorExportPlatformIOS.privacy/collected_data/browsing_history/collected: bool
Indicates whether your app collects browsing history.

## privacy/collected_data/browsing_history/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/browsing_history/collection_purposes: int
The reasons your app collects browsing history. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/browsing_history/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/browsing_history/linked_to_user: bool
Indicates whether your app links browsing history to the user's identity.

## privacy/collected_data/browsing_history/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/browsing_history/used_for_tracking: bool
Indicates whether your app uses browsing history for tracking.

## privacy/collected_data/coarse_location/collected :: var EditorExportPlatformIOS.privacy/collected_data/coarse_location/collected: bool
Indicates whether your app collects coarse location data.

## privacy/collected_data/coarse_location/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/coarse_location/collection_purposes: int
The reasons your app collects coarse location data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/coarse_location/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/coarse_location/linked_to_user: bool
Indicates whether your app links coarse location data to the user's identity.

## privacy/collected_data/coarse_location/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/coarse_location/used_for_tracking: bool
Indicates whether your app uses coarse location data for tracking.

## privacy/collected_data/contacts/collected :: var EditorExportPlatformIOS.privacy/collected_data/contacts/collected: bool
Indicates whether your app collects contacts.

## privacy/collected_data/contacts/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/contacts/collection_purposes: int
The reasons your app collects contacts. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/contacts/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/contacts/linked_to_user: bool
Indicates whether your app links contacts to the user's identity.

## privacy/collected_data/contacts/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/contacts/used_for_tracking: bool
Indicates whether your app uses contacts for tracking.

## privacy/collected_data/crash_data/collected :: var EditorExportPlatformIOS.privacy/collected_data/crash_data/collected: bool
Indicates whether your app collects crash data.

## privacy/collected_data/crash_data/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/crash_data/collection_purposes: int
The reasons your app collects crash data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/crash_data/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/crash_data/linked_to_user: bool
Indicates whether your app links crash data to the user's identity.

## privacy/collected_data/crash_data/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/crash_data/used_for_tracking: bool
Indicates whether your app uses crash data for tracking.

## privacy/collected_data/credit_info/collected :: var EditorExportPlatformIOS.privacy/collected_data/credit_info/collected: bool
Indicates whether your app collects credit information.

## privacy/collected_data/credit_info/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/credit_info/collection_purposes: int
The reasons your app collects credit information. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/credit_info/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/credit_info/linked_to_user: bool
Indicates whether your app links credit information to the user's identity.

## privacy/collected_data/credit_info/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/credit_info/used_for_tracking: bool
Indicates whether your app uses credit information for tracking.

## privacy/collected_data/customer_support/collected :: var EditorExportPlatformIOS.privacy/collected_data/customer_support/collected: bool
Indicates whether your app collects customer support data.

## privacy/collected_data/customer_support/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/customer_support/collection_purposes: int
The reasons your app collects customer support data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/customer_support/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/customer_support/linked_to_user: bool
Indicates whether your app links customer support data to the user's identity.

## privacy/collected_data/customer_support/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/customer_support/used_for_tracking: bool
Indicates whether your app uses customer support data for tracking.

## privacy/collected_data/device_id/collected :: var EditorExportPlatformIOS.privacy/collected_data/device_id/collected: bool
Indicates whether your app collects device IDs.

## privacy/collected_data/device_id/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/device_id/collection_purposes: int
The reasons your app collects device IDs. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/device_id/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/device_id/linked_to_user: bool
Indicates whether your app links device IDs to the user's identity.

## privacy/collected_data/device_id/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/device_id/used_for_tracking: bool
Indicates whether your app uses device IDs for tracking.

## privacy/collected_data/email_address/collected :: var EditorExportPlatformIOS.privacy/collected_data/email_address/collected: bool
Indicates whether your app collects email address.

## privacy/collected_data/email_address/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/email_address/collection_purposes: int
The reasons your app collects email address. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/email_address/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/email_address/linked_to_user: bool
Indicates whether your app links email address to the user's identity.

## privacy/collected_data/email_address/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/email_address/used_for_tracking: bool
Indicates whether your app uses email address for tracking.

## privacy/collected_data/emails_or_text_messages/collected :: var EditorExportPlatformIOS.privacy/collected_data/emails_or_text_messages/collected: bool
Indicates whether your app collects emails or text messages.

## privacy/collected_data/emails_or_text_messages/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/emails_or_text_messages/collection_purposes: int
The reasons your app collects emails or text messages. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/emails_or_text_messages/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/emails_or_text_messages/linked_to_user: bool
Indicates whether your app links emails or text messages to the user's identity.

## privacy/collected_data/emails_or_text_messages/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/emails_or_text_messages/used_for_tracking: bool
Indicates whether your app uses emails or text messages for tracking.

## privacy/collected_data/environment_scanning/collected :: var EditorExportPlatformIOS.privacy/collected_data/environment_scanning/collected: bool
Indicates whether your app collects environment scanning data.

## privacy/collected_data/environment_scanning/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/environment_scanning/collection_purposes: int
The reasons your app collects environment scanning data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/environment_scanning/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/environment_scanning/linked_to_user: bool
Indicates whether your app links environment scanning data to the user's identity.

## privacy/collected_data/environment_scanning/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/environment_scanning/used_for_tracking: bool
Indicates whether your app uses environment scanning data for tracking.

## privacy/collected_data/fitness/collected :: var EditorExportPlatformIOS.privacy/collected_data/fitness/collected: bool
Indicates whether your app collects fitness and exercise data.

## privacy/collected_data/fitness/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/fitness/collection_purposes: int
The reasons your app collects fitness and exercise data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/fitness/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/fitness/linked_to_user: bool
Indicates whether your app links fitness and exercise data to the user's identity.

## privacy/collected_data/fitness/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/fitness/used_for_tracking: bool
Indicates whether your app uses fitness and exercise data for tracking.

## privacy/collected_data/gameplay_content/collected :: var EditorExportPlatformIOS.privacy/collected_data/gameplay_content/collected: bool
Indicates whether your app collects gameplay content.

## privacy/collected_data/gameplay_content/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/gameplay_content/collection_purposes: int
The reasons your app collects gameplay content. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/gameplay_content/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/gameplay_content/linked_to_user: bool
Indicates whether your app links gameplay content to the user's identity.

## privacy/collected_data/gameplay_content/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/gameplay_content/used_for_tracking: bool
Indicates whether your app uses gameplay content for tracking.

## privacy/collected_data/hands/collected :: var EditorExportPlatformIOS.privacy/collected_data/hands/collected: bool
Indicates whether your app collects user's hand structure and hand movements.

## privacy/collected_data/hands/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/hands/collection_purposes: int
The reasons your app collects user's hand structure and hand movements. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/hands/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/hands/linked_to_user: bool
Indicates whether your app links user's hand structure and hand movements to the user's identity.

## privacy/collected_data/hands/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/hands/used_for_tracking: bool
Indicates whether your app uses user's hand structure and hand movements for tracking.

## privacy/collected_data/head/collected :: var EditorExportPlatformIOS.privacy/collected_data/head/collected: bool
Indicates whether your app collects user's head movement.

## privacy/collected_data/head/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/head/collection_purposes: int
The reasons your app collects user's head movement. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/head/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/head/linked_to_user: bool
Indicates whether your app links user's head movement to the user's identity.

## privacy/collected_data/head/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/head/used_for_tracking: bool
Indicates whether your app uses user's head movement for tracking.

## privacy/collected_data/health/collected :: var EditorExportPlatformIOS.privacy/collected_data/health/collected: bool
Indicates whether your app collects health and medical data.

## privacy/collected_data/health/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/health/collection_purposes: int
The reasons your app collects health and medical data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/health/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/health/linked_to_user: bool
Indicates whether your app links health and medical data to the user's identity.

## privacy/collected_data/health/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/health/used_for_tracking: bool
Indicates whether your app uses health and medical data for tracking.

## privacy/collected_data/name/collected :: var EditorExportPlatformIOS.privacy/collected_data/name/collected: bool
Indicates whether your app collects user's name.

## privacy/collected_data/name/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/name/collection_purposes: int
The reasons your app collects user's name. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/name/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/name/linked_to_user: bool
Indicates whether your app links user's name to the user's identity.

## privacy/collected_data/name/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/name/used_for_tracking: bool
Indicates whether your app uses user's name for tracking.

## privacy/collected_data/other_contact_info/collected :: var EditorExportPlatformIOS.privacy/collected_data/other_contact_info/collected: bool
Indicates whether your app collects any other contact information.

## privacy/collected_data/other_contact_info/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/other_contact_info/collection_purposes: int
The reasons your app collects any other contact information. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_contact_info/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/other_contact_info/linked_to_user: bool
Indicates whether your app links any other contact information to the user's identity.

## privacy/collected_data/other_contact_info/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/other_contact_info/used_for_tracking: bool
Indicates whether your app uses any other contact information for tracking.

## privacy/collected_data/other_data_types/collected :: var EditorExportPlatformIOS.privacy/collected_data/other_data_types/collected: bool
Indicates whether your app collects any other data.

## privacy/collected_data/other_data_types/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/other_data_types/collection_purposes: int
The reasons your app collects any other data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_data_types/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/other_data_types/linked_to_user: bool
Indicates whether your app links any other data to the user's identity.

## privacy/collected_data/other_data_types/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/other_data_types/used_for_tracking: bool
Indicates whether your app uses any other data for tracking.

## privacy/collected_data/other_diagnostic_data/collected :: var EditorExportPlatformIOS.privacy/collected_data/other_diagnostic_data/collected: bool
Indicates whether your app collects any other diagnostic data.

## privacy/collected_data/other_diagnostic_data/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/other_diagnostic_data/collection_purposes: int
The reasons your app collects any other diagnostic data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_diagnostic_data/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/other_diagnostic_data/linked_to_user: bool
Indicates whether your app links any other diagnostic data to the user's identity.

## privacy/collected_data/other_diagnostic_data/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/other_diagnostic_data/used_for_tracking: bool
Indicates whether your app uses any other diagnostic data for tracking.

## privacy/collected_data/other_financial_info/collected :: var EditorExportPlatformIOS.privacy/collected_data/other_financial_info/collected: bool
Indicates whether your app collects any other financial information.

## privacy/collected_data/other_financial_info/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/other_financial_info/collection_purposes: int
The reasons your app collects any other financial information. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_financial_info/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/other_financial_info/linked_to_user: bool
Indicates whether your app links any other financial information to the user's identity.

## privacy/collected_data/other_financial_info/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/other_financial_info/used_for_tracking: bool
Indicates whether your app uses any other financial information for tracking.

## privacy/collected_data/other_usage_data/collected :: var EditorExportPlatformIOS.privacy/collected_data/other_usage_data/collected: bool
Indicates whether your app collects any other usage data.

## privacy/collected_data/other_usage_data/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/other_usage_data/collection_purposes: int
The reasons your app collects any other usage data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_usage_data/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/other_usage_data/linked_to_user: bool
Indicates whether your app links any other usage data to the user's identity.

## privacy/collected_data/other_usage_data/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/other_usage_data/used_for_tracking: bool
Indicates whether your app uses any other usage data for tracking.

## privacy/collected_data/other_user_content/collected :: var EditorExportPlatformIOS.privacy/collected_data/other_user_content/collected: bool
Indicates whether your app collects any other user generated content.

## privacy/collected_data/other_user_content/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/other_user_content/collection_purposes: int
The reasons your app collects any other user generated content. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_user_content/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/other_user_content/linked_to_user: bool
Indicates whether your app links any other user generated content to the user's identity.

## privacy/collected_data/other_user_content/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/other_user_content/used_for_tracking: bool
Indicates whether your app uses any other user generated content for tracking.

## privacy/collected_data/payment_info/collected :: var EditorExportPlatformIOS.privacy/collected_data/payment_info/collected: bool
Indicates whether your app collects payment information.

## privacy/collected_data/payment_info/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/payment_info/collection_purposes: int
The reasons your app collects payment information. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/payment_info/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/payment_info/linked_to_user: bool
Indicates whether your app links payment information to the user's identity.

## privacy/collected_data/payment_info/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/payment_info/used_for_tracking: bool
Indicates whether your app uses payment information for tracking.

## privacy/collected_data/performance_data/collected :: var EditorExportPlatformIOS.privacy/collected_data/performance_data/collected: bool
Indicates whether your app collects performance data.

## privacy/collected_data/performance_data/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/performance_data/collection_purposes: int
The reasons your app collects performance data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/performance_data/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/performance_data/linked_to_user: bool
Indicates whether your app links performance data to the user's identity.

## privacy/collected_data/performance_data/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/performance_data/used_for_tracking: bool
Indicates whether your app uses performance data for tracking.

## privacy/collected_data/phone_number/collected :: var EditorExportPlatformIOS.privacy/collected_data/phone_number/collected: bool
Indicates whether your app collects phone number.

## privacy/collected_data/phone_number/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/phone_number/collection_purposes: int
The reasons your app collects phone number. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/phone_number/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/phone_number/linked_to_user: bool
Indicates whether your app links phone number to the user's identity.

## privacy/collected_data/phone_number/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/phone_number/used_for_tracking: bool
Indicates whether your app uses phone number for tracking.

## privacy/collected_data/photos_or_videos/collected :: var EditorExportPlatformIOS.privacy/collected_data/photos_or_videos/collected: bool
Indicates whether your app collects photos or videos.

## privacy/collected_data/photos_or_videos/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/photos_or_videos/collection_purposes: int
The reasons your app collects photos or videos. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/photos_or_videos/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/photos_or_videos/linked_to_user: bool
Indicates whether your app links photos or videos to the user's identity.

## privacy/collected_data/photos_or_videos/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/photos_or_videos/used_for_tracking: bool
Indicates whether your app uses photos or videos for tracking.

## privacy/collected_data/physical_address/collected :: var EditorExportPlatformIOS.privacy/collected_data/physical_address/collected: bool
Indicates whether your app collects physical address.

## privacy/collected_data/physical_address/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/physical_address/collection_purposes: int
The reasons your app collects physical address. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/physical_address/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/physical_address/linked_to_user: bool
Indicates whether your app links physical address to the user's identity.

## privacy/collected_data/physical_address/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/physical_address/used_for_tracking: bool
Indicates whether your app uses physical address for tracking.

## privacy/collected_data/precise_location/collected :: var EditorExportPlatformIOS.privacy/collected_data/precise_location/collected: bool
Indicates whether your app collects precise location data.

## privacy/collected_data/precise_location/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/precise_location/collection_purposes: int
The reasons your app collects precise location data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/precise_location/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/precise_location/linked_to_user: bool
Indicates whether your app links precise location data to the user's identity.

## privacy/collected_data/precise_location/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/precise_location/used_for_tracking: bool
Indicates whether your app uses precise location data for tracking.

## privacy/collected_data/product_interaction/collected :: var EditorExportPlatformIOS.privacy/collected_data/product_interaction/collected: bool
Indicates whether your app collects product interaction data.

## privacy/collected_data/product_interaction/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/product_interaction/collection_purposes: int
The reasons your app collects product interaction data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/product_interaction/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/product_interaction/linked_to_user: bool
Indicates whether your app links product interaction data to the user's identity.

## privacy/collected_data/product_interaction/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/product_interaction/used_for_tracking: bool
Indicates whether your app uses product interaction data for tracking.

## privacy/collected_data/purchase_history/collected :: var EditorExportPlatformIOS.privacy/collected_data/purchase_history/collected: bool
Indicates whether your app collects purchase history.

## privacy/collected_data/purchase_history/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/purchase_history/collection_purposes: int
The reasons your app collects purchase history. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/purchase_history/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/purchase_history/linked_to_user: bool
Indicates whether your app links purchase history to the user's identity.

## privacy/collected_data/purchase_history/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/purchase_history/used_for_tracking: bool
Indicates whether your app uses purchase history for tracking.

## privacy/collected_data/search_history/collected :: var EditorExportPlatformIOS.privacy/collected_data/search_history/collected: bool
Indicates whether your app collects search history.

## privacy/collected_data/search_history/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/search_history/collection_purposes: int
The reasons your app collects search history. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/search_history/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/search_history/linked_to_user: bool
Indicates whether your app links search history to the user's identity.

## privacy/collected_data/search_history/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/search_history/used_for_tracking: bool
Indicates whether your app uses search history for tracking.

## privacy/collected_data/sensitive_info/collected :: var EditorExportPlatformIOS.privacy/collected_data/sensitive_info/collected: bool
Indicates whether your app collects sensitive user information.

## privacy/collected_data/sensitive_info/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/sensitive_info/collection_purposes: int
The reasons your app collects sensitive user information. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/sensitive_info/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/sensitive_info/linked_to_user: bool
Indicates whether your app links sensitive user information to the user's identity.

## privacy/collected_data/sensitive_info/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/sensitive_info/used_for_tracking: bool
Indicates whether your app uses sensitive user information for tracking.

## privacy/collected_data/user_id/collected :: var EditorExportPlatformIOS.privacy/collected_data/user_id/collected: bool
Indicates whether your app collects user IDs.

## privacy/collected_data/user_id/collection_purposes :: var EditorExportPlatformIOS.privacy/collected_data/user_id/collection_purposes: int
The reasons your app collects user IDs. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/user_id/linked_to_user :: var EditorExportPlatformIOS.privacy/collected_data/user_id/linked_to_user: bool
Indicates whether your app links user IDs to the user's identity.

## privacy/collected_data/user_id/used_for_tracking :: var EditorExportPlatformIOS.privacy/collected_data/user_id/used_for_tracking: bool
Indicates whether your app uses user IDs for tracking.

## privacy/disk_space_access_reasons :: var EditorExportPlatformIOS.privacy/disk_space_access_reasons: int
The reasons your app use free disk space API. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_use_of_required_reason_api]Describing use of required reason API[/url].

## privacy/file_timestamp_access_reasons :: var EditorExportPlatformIOS.privacy/file_timestamp_access_reasons: int
The reasons your app use file timestamp/metadata API. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_use_of_required_reason_api]Describing use of required reason API[/url].

## privacy/microphone_usage_description :: var EditorExportPlatformIOS.privacy/microphone_usage_description: String
A message displayed when requesting access to the device's microphone (in English).

## privacy/microphone_usage_description_localized :: var EditorExportPlatformIOS.privacy/microphone_usage_description_localized: Dictionary
A message displayed when requesting access to the device's microphone (localized).

## privacy/photolibrary_usage_description :: var EditorExportPlatformIOS.privacy/photolibrary_usage_description: String
A message displayed when requesting access to the user's photo library (in English).

## privacy/photolibrary_usage_description_localized :: var EditorExportPlatformIOS.privacy/photolibrary_usage_description_localized: Dictionary
A message displayed when requesting access to the user's photo library (localized).

## privacy/system_boot_time_access_reasons :: var EditorExportPlatformIOS.privacy/system_boot_time_access_reasons: int
The reasons your app use system boot time / absolute time API. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_use_of_required_reason_api]Describing use of required reason API[/url].

## privacy/tracking_domains :: var EditorExportPlatformIOS.privacy/tracking_domains: PackedStringArray
The list of internet domains your app connects to that engage in tracking. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files]Privacy manifest files[/url].

## privacy/tracking_enabled :: var EditorExportPlatformIOS.privacy/tracking_enabled: bool
Indicates whether your app uses data for tracking. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files]Privacy manifest files[/url].

## privacy/user_defaults_access_reasons :: var EditorExportPlatformIOS.privacy/user_defaults_access_reasons: int
The reasons your app use user defaults API. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_use_of_required_reason_api]Describing use of required reason API[/url].

## shader_baker/enabled :: var EditorExportPlatformIOS.shader_baker/enabled: bool
If [code]true[/code], shaders will be compiled and embedded in the application. This option is only supported when using the Forward+ or Mobile renderers.
[b]Note:[/b] When exporting as a dedicated server, the shader baker is always disabled since no rendering is performed.

## storyboard/custom_bg_color :: var EditorExportPlatformIOS.storyboard/custom_bg_color: Color
A custom background color of the storyboard launch screen.

## storyboard/custom_image@2x :: var EditorExportPlatformIOS.storyboard/custom_image@2x: String
Application launch screen image file (2x DPI). If left empty, it will fallback to [member ProjectSettings.application/boot_splash/image].

## storyboard/custom_image@3x :: var EditorExportPlatformIOS.storyboard/custom_image@3x: String
Application launch screen image file (3x DPI). If left empty, it will fallback to [member ProjectSettings.application/boot_splash/image].

## storyboard/image_scale_mode :: var EditorExportPlatformIOS.storyboard/image_scale_mode: int
Launch screen image scaling mode.

## storyboard/use_custom_bg_color :: var EditorExportPlatformIOS.storyboard/use_custom_bg_color: bool
If [code]true[/code], [member storyboard/custom_bg_color] is used as a launch screen background color, otherwise [code]application/boot_splash/bg_color[/code] project setting is used.

## user_data/accessible_from_files_app :: var EditorExportPlatformIOS.user_data/accessible_from_files_app: bool
If [code]true[/code], the app "Documents" folder can be accessed via "Files" app. See [url=https://developer.apple.com/documentation/bundleresources/information_property_list/lssupportsopeningdocumentsinplace]LSSupportsOpeningDocumentsInPlace[/url].

## user_data/accessible_from_itunes_sharing :: var EditorExportPlatformIOS.user_data/accessible_from_itunes_sharing: bool
If [code]true[/code], the app "Documents" folder can be accessed via iTunes file sharing. See [url=https://developer.apple.com/documentation/bundleresources/information_property_list/uifilesharingenabled]UIFileSharingEnabled[/url].
