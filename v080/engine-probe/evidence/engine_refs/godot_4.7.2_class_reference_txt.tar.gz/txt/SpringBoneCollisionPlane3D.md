# SpringBoneCollisionPlane3D :: <Native> class SpringBoneCollisionPlane3D extends SpringBoneCollision3D
An infinite plane collision that interacts with [SpringBoneSimulator3D].
An infinite plane collision that interacts with [SpringBoneSimulator3D]. It is an infinite size XZ plane, and the +Y direction is treated as normal.
