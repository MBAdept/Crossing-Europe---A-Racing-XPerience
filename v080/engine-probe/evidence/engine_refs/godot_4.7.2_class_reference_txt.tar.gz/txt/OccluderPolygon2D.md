# OccluderPolygon2D :: <Native> class OccluderPolygon2D extends Resource
Defines a 2D polygon for LightOccluder2D.
Editor facility that helps you draw a 2D polygon used as resource for [LightOccluder2D].

## CULL_DISABLED :: const OccluderPolygon2D.CULL_DISABLED: CullMode = 0
Culling is disabled. See [member cull_mode].

## CULL_CLOCKWISE :: const OccluderPolygon2D.CULL_CLOCKWISE: CullMode = 1
Culling is performed in the clockwise direction. See [member cull_mode].

## CULL_COUNTER_CLOCKWISE :: const OccluderPolygon2D.CULL_COUNTER_CLOCKWISE: CullMode = 2
Culling is performed in the counterclockwise direction. See [member cull_mode].

## closed :: var OccluderPolygon2D.closed: bool
If [code]true[/code], closes the polygon. A closed OccluderPolygon2D occludes the light coming from any direction. An opened OccluderPolygon2D occludes the light only at its outline's direction.

## cull_mode :: var OccluderPolygon2D.cull_mode: OccluderPolygon2D.CullMode
The culling mode to use.

## polygon :: var OccluderPolygon2D.polygon: PackedVector2Array
A [Vector2] array with the index for polygon's vertices positions.
