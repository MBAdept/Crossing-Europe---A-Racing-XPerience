# MissingNode :: <Native> class MissingNode extends Node
An internal editor class intended for keeping the data of unrecognized nodes.
This is an internal editor class intended for keeping data of nodes of unknown type (most likely this type was supplied by an extension that is no longer loaded). It can't be manually instantiated or placed in a scene.
[b]Warning:[/b] Ignore missing nodes unless you know what you are doing. Existing properties on a missing node can be freely modified in code, regardless of the type they are intended to be.

## original_class :: var MissingNode.original_class: String
The name of the class this node was supposed to be (see [method Object.get_class]).

## original_scene :: var MissingNode.original_scene: String
Returns the path of the scene this node was instance of originally.

## recording_properties :: var MissingNode.recording_properties: bool
If [code]true[/code], allows new properties to be set along with existing ones. If [code]false[/code], only existing properties' values can be set, and new properties cannot be added.

## recording_signals :: var MissingNode.recording_signals: bool
If [code]true[/code], allows new signals to be connected to along with existing ones. If [code]false[/code], only existing signals can be connected to, and new signals cannot be added.
