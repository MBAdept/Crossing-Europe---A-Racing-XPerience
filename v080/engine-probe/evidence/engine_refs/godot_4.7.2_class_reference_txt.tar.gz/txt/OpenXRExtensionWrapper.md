# OpenXRExtensionWrapper :: <Native> class OpenXRExtensionWrapper extends Object
Allows implementing OpenXR extensions with GDExtension.
[OpenXRExtensionWrapper] allows implementing OpenXR extensions with GDExtension. The extension should be registered with [method register_extension_wrapper].
When [OpenXRInterface] is initialized as the primary interface and any [Viewport] has [member Viewport.use_xr] set to [code]true[/code], OpenXR will become involved in Godot's rendering process. If [member ProjectSettings.rendering/driver/threads/thread_model] is set to "Separate", Godot's renderer will run on its own thread, and special care must be taken in all [OpenXRExtensionWrapper]s in order to prevent crashes or unexpected behavior. Some virtual methods will be called on the render thread, and any data they access should not be directly written to on the main thread. This is to prevent two potential issues:
1. Changes intended for the next frame, taking effect on the current frame. When using the "Separate" thread model, the main thread will immediately start working on the next frame while the render thread may still be rendering the current frame. If the main thread changes anything used by the render thread directly, the change could end up being used one frame earlier than intended.
2. Reading and writing to the same data at the same time from different threads can lead to the render thread using data in an invalid state.
In most cases, the solution is to use [method RenderingServer.call_on_render_thread] to schedule [Callable]s to write to any data used on the render thread. When using the "Separate" thread model, these [Callable]s will run after the renderer finishes the current frame and before it starts rendering the next frame. When not using this mode, they'll run immediately, so it's recommended to always use [method RenderingServer.call_on_render_thread] in these cases, which will allow your code to do the right thing regardless of the thread model.
Any virtual methods that run on the render thread will be noted below.

## _get_composition_layer :: func OpenXRExtensionWrapper._get_composition_layer(index: int) -> int
Returns a pointer to an [code]XrCompositionLayerBaseHeader[/code] struct to provide the given composition layer.
This will only be called if the extension previously registered itself with [method OpenXRAPIExtension.register_composition_layer_provider].
[b]Note:[/b] This virtual method will be called on the render thread. Additionally, the data it returns will be used shortly after this method is called, so it needs to remain valid until the next time [method _on_pre_render] runs.

### index :: int

## _get_composition_layer_count :: func OpenXRExtensionWrapper._get_composition_layer_count() -> int
Returns the number of composition layers this extension wrapper provides via [method _get_composition_layer].
This will only be called if the extension previously registered itself with [method OpenXRAPIExtension.register_composition_layer_provider].
[b]Note:[/b] This virtual method will be called on the render thread. Additionally, the data it returns will be used shortly after this method is called, so it needs to remain valid until the next time [method _on_pre_render] runs.

## _get_composition_layer_order :: func OpenXRExtensionWrapper._get_composition_layer_order(index: int) -> int
Returns an integer that will be used to sort the given composition layer provided via [method _get_composition_layer]. Lower numbers will move the layer to the front of the list, and higher numbers to the end. The default projection layer has an order of [code]0[/code], so layers provided by this method should probably be above or below (but not exactly) [code]0[/code].
This will only be called if the extension previously registered itself with [method OpenXRAPIExtension.register_composition_layer_provider].
[b]Note:[/b] This virtual method will be called on the render thread. Additionally, the data it returns will be used shortly after this method is called, so it needs to remain valid until the next time [method _on_pre_render] runs.

### index :: int

## _get_requested_extensions :: func OpenXRExtensionWrapper._get_requested_extensions(xr_version: int) -> Dictionary
Returns a [Dictionary] of OpenXR extensions related to this extension. [param xr_version] specifies the OpenXR version we're instantiating. This will be zero if the editor requests this list to flag supported features. The [Dictionary] should contain the name of the extension, mapped to a [code]bool *[/code] cast to an integer:
- If the [code]bool *[/code] is a [code]nullptr[/code] this extension is mandatory.
- If the [code]bool *[/code] points to a boolean, the boolean will be updated to [code]true[/code] if the extension is enabled.

### xr_version :: int

## _get_suggested_tracker_names :: func OpenXRExtensionWrapper._get_suggested_tracker_names() -> PackedStringArray
Returns a [PackedStringArray] of positional tracker names that are used within the extension wrapper.

## _get_viewport_composition_layer_extension_properties :: func OpenXRExtensionWrapper._get_viewport_composition_layer_extension_properties() -> Dictionary[]
Gets an array of [Dictionary]s that represent properties, just like [method Object._get_property_list], that will be added to [OpenXRCompositionLayer] nodes.
[b]Note:[/b] This virtual method will be called on the render thread.

## _get_viewport_composition_layer_extension_property_defaults :: func OpenXRExtensionWrapper._get_viewport_composition_layer_extension_property_defaults() -> Dictionary
Gets a [Dictionary] containing the default values for the properties returned by [method _get_viewport_composition_layer_extension_properties].

## _on_before_instance_created :: func OpenXRExtensionWrapper._on_before_instance_created() -> void
Called before the OpenXR instance is created.
[b]Note:[/b] This virtual method will be called on the main thread, however, it will be called [i]before[/i] OpenXR becomes involved in rendering, so it is safe to write to data that will be used by the render thread.

## _on_event_polled :: func OpenXRExtensionWrapper._on_event_polled(event: const void*) -> bool
Called when there is an OpenXR event to process. When implementing, return [code]true[/code] if the event was handled, return [code]false[/code] otherwise.

### event :: const void*

## _on_instance_created :: func OpenXRExtensionWrapper._on_instance_created(instance: int) -> void
Called right after the OpenXR instance is created.
[b]Note:[/b] This virtual method will be called on the main thread, however, it will be called [i]before[/i] OpenXR becomes involved in rendering, so it is safe to write to data that will be used by the render thread.

### instance :: int

## _on_instance_destroyed :: func OpenXRExtensionWrapper._on_instance_destroyed() -> void
Called right before the OpenXR instance is destroyed.
[b]Note:[/b] This virtual method will be called on the main thread, however, it will be called [i]after[/i] OpenXR is done being involved in rendering, so it is safe to write to data that was used by the render thread.

## _on_main_swapchains_created :: func OpenXRExtensionWrapper._on_main_swapchains_created() -> void
Called right after the main swapchains are (re)created.
[b]Note:[/b] This virtual method will be called on the render thread.

## _on_post_draw_viewport :: func OpenXRExtensionWrapper._on_post_draw_viewport(viewport: RID) -> void
Called right after the given viewport is rendered.
[b]Note:[/b] The draw commands might only be queued at this point, not executed.
[b]Note:[/b] This virtual method will be called on the render thread.

### viewport :: RID

## _on_pre_draw_viewport :: func OpenXRExtensionWrapper._on_pre_draw_viewport(viewport: RID) -> void
Called right before the given viewport is rendered.
[b]Note:[/b] This virtual method will be called on the render thread.

### viewport :: RID

## _on_pre_render :: func OpenXRExtensionWrapper._on_pre_render() -> void
Called right before the XR viewports begin their rendering step.
[b]Note:[/b] This virtual method will be called on the render thread.

## _on_process :: func OpenXRExtensionWrapper._on_process() -> void
Called as part of the OpenXR process handling. This happens right before general and physics processing steps of the main loop. During this step controller data is queried and made available to game logic.

## _on_register_metadata :: func OpenXRExtensionWrapper._on_register_metadata(interaction_profile_metadata: OpenXRInteractionProfileMetadata) -> void
Allows extensions to register additional controller metadata. This function is called even when the OpenXR API is not constructed as the metadata needs to be available to the editor.
Extensions should also provide metadata regardless of whether they are supported on the host system. The controller data is used to setup action maps for users who may have access to the relevant hardware.

### interaction_profile_metadata :: OpenXRInteractionProfileMetadata

## _on_session_created :: func OpenXRExtensionWrapper._on_session_created(session: int) -> void
Called right after the OpenXR session is created.
[b]Note:[/b] This virtual method will be called on the main thread, however, it will be called [i]before[/i] OpenXR becomes involved in rendering, so it is safe to write to data that will be used by the render thread.

### session :: int

## _on_session_destroyed :: func OpenXRExtensionWrapper._on_session_destroyed() -> void
Called right before the OpenXR session is destroyed.
[b]Note:[/b] This virtual method will be called on the main thread, however, it will be called [i]after[/i] OpenXR is done being involved in rendering, so it is safe to write to data that was used by the render thread.

## _on_state_exiting :: func OpenXRExtensionWrapper._on_state_exiting() -> void
Called when the OpenXR session state is changed to exiting.

## _on_state_focused :: func OpenXRExtensionWrapper._on_state_focused() -> void
Called when the OpenXR session state is changed to focused. This state is the active state when the game runs.

## _on_state_idle :: func OpenXRExtensionWrapper._on_state_idle() -> void
Called when the OpenXR session state is changed to idle.

## _on_state_loss_pending :: func OpenXRExtensionWrapper._on_state_loss_pending() -> void
Called when the OpenXR session state is changed to loss pending.

## _on_state_ready :: func OpenXRExtensionWrapper._on_state_ready() -> void
Called when the OpenXR session state is changed to ready. This means OpenXR is ready to set up the session.

## _on_state_stopping :: func OpenXRExtensionWrapper._on_state_stopping() -> void
Called when the OpenXR session state is changed to stopping.

## _on_state_synchronized :: func OpenXRExtensionWrapper._on_state_synchronized() -> void
Called when the OpenXR session state is changed to synchronized. OpenXR also returns to this state when the application loses focus.

## _on_state_visible :: func OpenXRExtensionWrapper._on_state_visible() -> void
Called when the OpenXR session state is changed to visible. This means OpenXR is now ready to receive frames.

## _on_sync_actions :: func OpenXRExtensionWrapper._on_sync_actions() -> void
Called when OpenXR has performed its action sync.

## _on_viewport_composition_layer_destroyed :: func OpenXRExtensionWrapper._on_viewport_composition_layer_destroyed(layer: const void*) -> void
Called when a composition layer created via [OpenXRCompositionLayer] is destroyed.
[param layer] is a pointer to an [code]XrCompositionLayerBaseHeader[/code] struct.

### layer :: const void*

## _prepare_view_configuration :: func OpenXRExtensionWrapper._prepare_view_configuration(view_count: int) -> void
Called before [method _set_view_configuration_and_get_next_pointer] to allow the extension to reserve data for the given number of views.

### view_count :: int

## _print_view_configuration_info :: func OpenXRExtensionWrapper._print_view_configuration_info(view: int) -> void
Called to allow an extension to print additional information about its view configuration, if applicable. This will only be called if verbose output is enabled.

### view :: int

## _set_android_surface_swapchain_create_info_and_get_next_pointer :: func OpenXRExtensionWrapper._set_android_surface_swapchain_create_info_and_get_next_pointer(property_values: Dictionary, next_pointer: void*) -> int
Add additional data structures to Android surface swapchains created by [OpenXRCompositionLayer].
[param property_values] contains the values of the properties returned by [method _get_viewport_composition_layer_extension_properties].
[b]Note:[/b] This virtual method will be called on the render thread.

### property_values :: Dictionary

### next_pointer :: void*

## _set_frame_end_info_and_get_next_pointer :: func OpenXRExtensionWrapper._set_frame_end_info_and_get_next_pointer(next_pointer: void*) -> int
Add additional data structures to [code]XrFrameEndInfo[/code].
This will only be called if the extension previously registered itself with [method OpenXRAPIExtension.register_frame_info_extension].
[b]Note:[/b] This virtual method will be called on the render thread. Additionally, the data it returns will be used shortly after this method is called, so it needs to remain valid until the next time [method _on_pre_render] runs.

### next_pointer :: void*

## _set_frame_wait_info_and_get_next_pointer :: func OpenXRExtensionWrapper._set_frame_wait_info_and_get_next_pointer(next_pointer: void*) -> int
Add additional data structures to [code]XrFrameWaitInfo[/code].
This will only be called if the extension previously registered itself with [method OpenXRAPIExtension.register_frame_info_extension].
[b]Note:[/b] This virtual method will be called on the render thread.

### next_pointer :: void*

## _set_hand_joint_locations_and_get_next_pointer :: func OpenXRExtensionWrapper._set_hand_joint_locations_and_get_next_pointer(hand_index: int, next_pointer: void*) -> int
Add additional data structures when each hand tracker is created.

### hand_index :: int

### next_pointer :: void*

## _set_instance_create_info_and_get_next_pointer :: func OpenXRExtensionWrapper._set_instance_create_info_and_get_next_pointer(xr_version: int, next_pointer: void*) -> int
Add additional data structures when the OpenXR instance is created. [param xr_version] specifies the OpenXR version we're instantiating.

### xr_version :: int

### next_pointer :: void*

## _set_projection_layer_and_get_next_pointer :: func OpenXRExtensionWrapper._set_projection_layer_and_get_next_pointer(next_pointer: void*) -> int
Adds additional data structures to [code]XrCompositionLayerProjection[/code].
This will only be called if the extension previously registered itself with [method OpenXRAPIExtension.register_projection_layer_extension].

### next_pointer :: void*

## _set_projection_views_and_get_next_pointer :: func OpenXRExtensionWrapper._set_projection_views_and_get_next_pointer(view_index: int, next_pointer: void*) -> int
Add additional data structures to the projection view of the given [param view_index].
[b]Note:[/b] This virtual method will be called on the render thread. Additionally, the data it returns will be used shortly after this method is called, so it needs to remain valid until the next time [method _on_pre_render] runs.

### view_index :: int

### next_pointer :: void*

## _set_reference_space_create_info_and_get_next_pointer :: func OpenXRExtensionWrapper._set_reference_space_create_info_and_get_next_pointer(reference_space_type: int, next_pointer: void*) -> int
Add additional data structures to [code]XrReferenceSpaceCreateInfo[/code].

### reference_space_type :: int

### next_pointer :: void*

## _set_session_create_and_get_next_pointer :: func OpenXRExtensionWrapper._set_session_create_and_get_next_pointer(next_pointer: void*) -> int
Add additional data structures when the OpenXR session is created.

### next_pointer :: void*

## _set_swapchain_create_info_and_get_next_pointer :: func OpenXRExtensionWrapper._set_swapchain_create_info_and_get_next_pointer(next_pointer: void*) -> int
Add additional data structures when creating OpenXR swapchains.

### next_pointer :: void*

## _set_system_properties_and_get_next_pointer :: func OpenXRExtensionWrapper._set_system_properties_and_get_next_pointer(next_pointer: void*) -> int
Add additional data structures when querying OpenXR system abilities.

### next_pointer :: void*

## _set_view_configuration_and_get_next_pointer :: func OpenXRExtensionWrapper._set_view_configuration_and_get_next_pointer(view: int, next_pointer: void*) -> int
Add additional data structures when querying OpenXR view configuration.

### view :: int

### next_pointer :: void*

## _set_view_locate_info_and_get_next_pointer :: func OpenXRExtensionWrapper._set_view_locate_info_and_get_next_pointer(next_pointer: void*) -> int
Add additional data structures to [code]XrViewLocateInfo[/code].
This will only be called if the extension previously registered itself with [method OpenXRAPIExtension.register_frame_info_extension].
[b]Note:[/b] This virtual method will be called on the render thread. Additionally, the data it returns will be used shortly after this method is called, so it needs to remain valid until the next time [method _on_pre_render] runs.

### next_pointer :: void*

## _set_viewport_composition_layer_and_get_next_pointer :: func OpenXRExtensionWrapper._set_viewport_composition_layer_and_get_next_pointer(layer: const void*, property_values: Dictionary, next_pointer: void*) -> int
Add additional data structures to composition layers created by [OpenXRCompositionLayer].
[param property_values] contains the values of the properties returned by [method _get_viewport_composition_layer_extension_properties].
[param layer] is a pointer to an [code]XrCompositionLayerBaseHeader[/code] struct.
[b]Note:[/b] This virtual method will be called on the render thread. Additionally, the data it returns will be used shortly after this method is called, so it needs to remain valid until the next time [method _on_pre_render] runs.

### layer :: const void*

### property_values :: Dictionary

### next_pointer :: void*

## get_openxr_api :: func OpenXRExtensionWrapper.get_openxr_api() -> OpenXRAPIExtension
Returns the created [OpenXRAPIExtension], which can be used to access the OpenXR API.

## register_extension_wrapper :: func OpenXRExtensionWrapper.register_extension_wrapper() -> void
Registers the extension. This should happen at core module initialization level.
[b]Note:[/b] This cannot be called once OpenXR has been initialized.
