# EditorFileSystemDirectory :: <Native> class EditorFileSystemDirectory extends Object
A directory for the resource filesystem.
A more generalized, low-level variation of the directory concept.

## find_dir_index :: func EditorFileSystemDirectory.find_dir_index(name: String) -> int
Returns the index of the directory with name [param name] or [code]-1[/code] if not found.

### name :: String

## find_file_index :: func EditorFileSystemDirectory.find_file_index(name: String) -> int
Returns the index of the file with name [param name] or [code]-1[/code] if not found.

### name :: String

## get_file :: func EditorFileSystemDirectory.get_file(idx: int) -> String
Returns the name of the file at index [param idx].

### idx :: int

## get_file_count :: func EditorFileSystemDirectory.get_file_count() -> int
Returns the number of files in this directory.

## get_file_import_is_valid :: func EditorFileSystemDirectory.get_file_import_is_valid(idx: int) -> bool
Returns [code]true[/code] if the file at index [param idx] imported properly.

### idx :: int

## get_file_path :: func EditorFileSystemDirectory.get_file_path(idx: int) -> String
Returns the path to the file at index [param idx].

### idx :: int

## get_file_script_class_extends :: func EditorFileSystemDirectory.get_file_script_class_extends(idx: int) -> String
Returns the base class of the script class defined in the file at index [param idx]. If the file doesn't define a script class using the [code]class_name[/code] syntax, this will return an empty string.

### idx :: int

## get_file_script_class_name :: func EditorFileSystemDirectory.get_file_script_class_name(idx: int) -> String
Returns the name of the script class defined in the file at index [param idx]. If the file doesn't define a script class using the [code]class_name[/code] syntax, this will return an empty string.

### idx :: int

## get_file_type :: func EditorFileSystemDirectory.get_file_type(idx: int) -> StringName
Returns the resource type of the file at index [param idx]. This returns a string such as [code]"Resource"[/code] or [code]"GDScript"[/code], [i]not[/i] a file extension such as [code]".gd"[/code].

### idx :: int

## get_name :: func EditorFileSystemDirectory.get_name() -> String
Returns the name of this directory.

## get_parent :: func EditorFileSystemDirectory.get_parent() -> EditorFileSystemDirectory
Returns the parent directory for this directory or [code]null[/code] if called on a directory at [code]res://[/code] or [code]user://[/code].

## get_path :: func EditorFileSystemDirectory.get_path() -> String
Returns the path to this directory.

## get_subdir :: func EditorFileSystemDirectory.get_subdir(idx: int) -> EditorFileSystemDirectory
Returns the subdirectory at index [param idx].

### idx :: int

## get_subdir_count :: func EditorFileSystemDirectory.get_subdir_count() -> int
Returns the number of subdirectories in this directory.
