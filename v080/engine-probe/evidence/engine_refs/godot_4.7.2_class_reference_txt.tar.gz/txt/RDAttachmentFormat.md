# RDAttachmentFormat :: <Native> class RDAttachmentFormat extends RefCounted
Attachment format (used by [RenderingDevice]).
This object is used by [RenderingDevice].

## format :: var RDAttachmentFormat.format: RenderingDevice.DataFormat
The attachment's data format.

## samples :: var RDAttachmentFormat.samples: RenderingDevice.TextureSamples
The number of samples used when sampling the attachment.

## usage_flags :: var RDAttachmentFormat.usage_flags: int
The attachment's usage flags, which determine what can be done with it.
