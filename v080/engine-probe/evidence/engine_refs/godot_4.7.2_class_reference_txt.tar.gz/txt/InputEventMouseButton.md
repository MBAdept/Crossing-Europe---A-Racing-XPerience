# InputEventMouseButton :: <Native> class InputEventMouseButton extends InputEventMouse
Represents a mouse button being pressed or released.
Stores information about mouse click events. See [method Node._input].
[b]Note:[/b] On Wear OS devices, rotary input is mapped to [constant MOUSE_BUTTON_WHEEL_UP] and [constant MOUSE_BUTTON_WHEEL_DOWN]. This can be changed to [constant MOUSE_BUTTON_WHEEL_LEFT] and [constant MOUSE_BUTTON_WHEEL_RIGHT] with the [member ProjectSettings.input_devices/pointing/android/rotary_input_scroll_axis] setting.

## button_index :: var InputEventMouseButton.button_index: MouseButton
The mouse button identifier, one of the [enum MouseButton] button or button wheel constants.

## canceled :: var InputEventMouseButton.canceled: bool
If [code]true[/code], the mouse button event has been canceled.

## double_click :: var InputEventMouseButton.double_click: bool
If [code]true[/code], the mouse button's state is a double-click.

## factor :: var InputEventMouseButton.factor: float
The amount (or delta) of the event. When used for high-precision scroll events, this indicates the scroll amount (vertical or horizontal). This is only supported on some platforms; the reported sensitivity varies depending on the platform. May be [code]0[/code] if not supported.

## pressed :: var InputEventMouseButton.pressed: bool
If [code]true[/code], the mouse button's state is pressed. If [code]false[/code], the mouse button's state is released.
