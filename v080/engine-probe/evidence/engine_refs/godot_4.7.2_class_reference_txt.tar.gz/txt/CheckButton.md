# CheckButton :: <Native> class CheckButton extends Button
A button that represents a binary choice.
[CheckButton] is a toggle button displayed as a check field. It's similar to [CheckBox] in functionality, but it has a different appearance. To follow established UX patterns, it's recommended to use [CheckButton] when toggling it has an [b]immediate[/b] effect on something. For example, it can be used when pressing it shows or hides advanced settings, without asking the user to confirm this action.
See also [BaseButton] which contains common properties and methods associated with this node.

## alignment :: var CheckButton.alignment: HorizontalAlignment

## toggle_mode :: var CheckButton.toggle_mode: bool

## button_checked_color :: <Theme> var CheckButton.button_checked_color: Color
The color of the checked icon when the checkbox is pressed.

## button_unchecked_color :: <Theme> var CheckButton.button_unchecked_color: Color
The color of the unchecked icon when the checkbox is not pressed.

## check_v_offset :: <Theme> var CheckButton.check_v_offset: int
The vertical offset used when rendering the toggle icons (in pixels).

## checked :: <Theme> var CheckButton.checked: Texture2D
The icon to display when the [CheckButton] is checked (for left-to-right layouts).

## checked_disabled :: <Theme> var CheckButton.checked_disabled: Texture2D
The icon to display when the [CheckButton] is checked and disabled (for left-to-right layouts).

## checked_disabled_mirrored :: <Theme> var CheckButton.checked_disabled_mirrored: Texture2D
The icon to display when the [CheckButton] is checked and disabled (for right-to-left layouts).

## checked_mirrored :: <Theme> var CheckButton.checked_mirrored: Texture2D
The icon to display when the [CheckButton] is checked (for right-to-left layouts).

## unchecked :: <Theme> var CheckButton.unchecked: Texture2D
The icon to display when the [CheckButton] is unchecked (for left-to-right layouts).

## unchecked_disabled :: <Theme> var CheckButton.unchecked_disabled: Texture2D
The icon to display when the [CheckButton] is unchecked and disabled (for left-to-right layouts).

## unchecked_disabled_mirrored :: <Theme> var CheckButton.unchecked_disabled_mirrored: Texture2D
The icon to display when the [CheckButton] is unchecked and disabled (for right-to-left layouts).

## unchecked_mirrored :: <Theme> var CheckButton.unchecked_mirrored: Texture2D
The icon to display when the [CheckButton] is unchecked (for right-to-left layouts).
