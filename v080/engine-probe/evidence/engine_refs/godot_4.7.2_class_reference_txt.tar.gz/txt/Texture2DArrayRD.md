# Texture2DArrayRD :: <Native> class Texture2DArrayRD extends TextureLayeredRD
Texture Array for 2D that is bound to a texture created on the [RenderingDevice].
This texture array class allows you to use a 2D array texture created directly on the [RenderingDevice] as a texture for materials, meshes, etc.
[b]Note:[/b] [Texture2DArrayRD] is intended for low-level usage with [RenderingDevice]. For most use cases, use [Texture2DArray] instead.
