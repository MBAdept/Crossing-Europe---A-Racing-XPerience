# OpenXRInterface :: <Native> class OpenXRInterface extends XRInterface
Our OpenXR interface.
The OpenXR interface allows Godot to interact with OpenXR runtimes and make it possible to create XR experiences and games.
Due to the needs of OpenXR this interface works slightly different than other plugin based XR interfaces. It needs to be initialized when Godot starts. You need to enable OpenXR, settings for this can be found in your games project settings under the XR heading. You do need to mark a viewport for use with XR in order for Godot to know which render result should be output to the headset.

## SESSION_STATE_UNKNOWN :: const OpenXRInterface.SESSION_STATE_UNKNOWN: SessionState = 0
The state of the session is unknown, we haven't tried setting up OpenXR yet.

## SESSION_STATE_IDLE :: const OpenXRInterface.SESSION_STATE_IDLE: SessionState = 1
The initial state after the OpenXR session is created or after the session is destroyed.

## SESSION_STATE_READY :: const OpenXRInterface.SESSION_STATE_READY: SessionState = 2
OpenXR is ready to begin our session. [signal session_begun] is emitted when we change to this state.

## SESSION_STATE_SYNCHRONIZED :: const OpenXRInterface.SESSION_STATE_SYNCHRONIZED: SessionState = 3
The application has synched its frame loop with the runtime but we're not rendering anything. [signal session_synchronized] is emitted when we change to this state.

## SESSION_STATE_VISIBLE :: const OpenXRInterface.SESSION_STATE_VISIBLE: SessionState = 4
The application has synched its frame loop with the runtime and we're rendering output to the user, however we receive no user input. [signal session_visible] is emitted when we change to this state.
[b]Note:[/b] This is the current state just before we get the focused state, whenever the user opens a system menu, switches to another application, or takes off their headset.

## SESSION_STATE_FOCUSED :: const OpenXRInterface.SESSION_STATE_FOCUSED: SessionState = 5
The application has synched its frame loop with the runtime, we're rendering output to the user and we're receiving XR input. [signal session_focussed] is emitted when we change to this state.
[b]Note:[/b] This is the state OpenXR will be in when the user can fully interact with your game.

## SESSION_STATE_STOPPING :: const OpenXRInterface.SESSION_STATE_STOPPING: SessionState = 6
Our session is being stopped. [signal session_stopping] is emitted when we change to this state.

## SESSION_STATE_LOSS_PENDING :: const OpenXRInterface.SESSION_STATE_LOSS_PENDING: SessionState = 7
The session is about to be lost. [signal session_loss_pending] is emitted when we change to this state.

## SESSION_STATE_EXITING :: const OpenXRInterface.SESSION_STATE_EXITING: SessionState = 8
The OpenXR instance is about to be destroyed and we're exiting. [signal instance_exiting] is emitted when we change to this state.

## HAND_LEFT :: const OpenXRInterface.HAND_LEFT: Hand = 0
Left hand.

## HAND_RIGHT :: const OpenXRInterface.HAND_RIGHT: Hand = 1
Right hand.

## HAND_MAX :: const OpenXRInterface.HAND_MAX: Hand = 2
Maximum value for the hand enum.

## HAND_MOTION_RANGE_UNOBSTRUCTED :: const OpenXRInterface.HAND_MOTION_RANGE_UNOBSTRUCTED: HandMotionRange = 0
Full hand range, if user closes their hands, we make a full fist.

## HAND_MOTION_RANGE_CONFORM_TO_CONTROLLER :: const OpenXRInterface.HAND_MOTION_RANGE_CONFORM_TO_CONTROLLER: HandMotionRange = 1
Conform to controller, if user closes their hands, the tracked data conforms to the shape of the controller.

## HAND_MOTION_RANGE_MAX :: const OpenXRInterface.HAND_MOTION_RANGE_MAX: HandMotionRange = 2
Maximum value for the motion range enum.

## HAND_TRACKED_SOURCE_UNKNOWN :: const OpenXRInterface.HAND_TRACKED_SOURCE_UNKNOWN: HandTrackedSource = 0
The source of hand tracking data is unknown (the extension is likely unsupported).

## HAND_TRACKED_SOURCE_UNOBSTRUCTED :: const OpenXRInterface.HAND_TRACKED_SOURCE_UNOBSTRUCTED: HandTrackedSource = 1
The source of hand tracking is unobstructed, this means that an accurate method of hand tracking is used, e.g. optical hand tracking, data gloves, etc.

## HAND_TRACKED_SOURCE_CONTROLLER :: const OpenXRInterface.HAND_TRACKED_SOURCE_CONTROLLER: HandTrackedSource = 2
The source of hand tracking is a controller, bone positions are inferred from controller inputs.

## HAND_TRACKED_SOURCE_MAX :: const OpenXRInterface.HAND_TRACKED_SOURCE_MAX: HandTrackedSource = 3
Represents the size of the [enum HandTrackedSource] enum.

## HAND_JOINT_PALM :: const OpenXRInterface.HAND_JOINT_PALM: HandJoints = 0
Palm joint.

## HAND_JOINT_WRIST :: const OpenXRInterface.HAND_JOINT_WRIST: HandJoints = 1
Wrist joint.

## HAND_JOINT_THUMB_METACARPAL :: const OpenXRInterface.HAND_JOINT_THUMB_METACARPAL: HandJoints = 2
Thumb metacarpal joint.

## HAND_JOINT_THUMB_PROXIMAL :: const OpenXRInterface.HAND_JOINT_THUMB_PROXIMAL: HandJoints = 3
Thumb proximal joint.

## HAND_JOINT_THUMB_DISTAL :: const OpenXRInterface.HAND_JOINT_THUMB_DISTAL: HandJoints = 4
Thumb distal joint.

## HAND_JOINT_THUMB_TIP :: const OpenXRInterface.HAND_JOINT_THUMB_TIP: HandJoints = 5
Thumb tip joint.

## HAND_JOINT_INDEX_METACARPAL :: const OpenXRInterface.HAND_JOINT_INDEX_METACARPAL: HandJoints = 6
Index finger metacarpal joint.

## HAND_JOINT_INDEX_PROXIMAL :: const OpenXRInterface.HAND_JOINT_INDEX_PROXIMAL: HandJoints = 7
Index finger phalanx proximal joint.

## HAND_JOINT_INDEX_INTERMEDIATE :: const OpenXRInterface.HAND_JOINT_INDEX_INTERMEDIATE: HandJoints = 8
Index finger phalanx intermediate joint.

## HAND_JOINT_INDEX_DISTAL :: const OpenXRInterface.HAND_JOINT_INDEX_DISTAL: HandJoints = 9
Index finger phalanx distal joint.

## HAND_JOINT_INDEX_TIP :: const OpenXRInterface.HAND_JOINT_INDEX_TIP: HandJoints = 10
Index finger tip joint.

## HAND_JOINT_MIDDLE_METACARPAL :: const OpenXRInterface.HAND_JOINT_MIDDLE_METACARPAL: HandJoints = 11
Middle finger metacarpal joint.

## HAND_JOINT_MIDDLE_PROXIMAL :: const OpenXRInterface.HAND_JOINT_MIDDLE_PROXIMAL: HandJoints = 12
Middle finger phalanx proximal joint.

## HAND_JOINT_MIDDLE_INTERMEDIATE :: const OpenXRInterface.HAND_JOINT_MIDDLE_INTERMEDIATE: HandJoints = 13
Middle finger phalanx intermediate joint.

## HAND_JOINT_MIDDLE_DISTAL :: const OpenXRInterface.HAND_JOINT_MIDDLE_DISTAL: HandJoints = 14
Middle finger phalanx distal joint.

## HAND_JOINT_MIDDLE_TIP :: const OpenXRInterface.HAND_JOINT_MIDDLE_TIP: HandJoints = 15
Middle finger tip joint.

## HAND_JOINT_RING_METACARPAL :: const OpenXRInterface.HAND_JOINT_RING_METACARPAL: HandJoints = 16
Ring finger metacarpal joint.

## HAND_JOINT_RING_PROXIMAL :: const OpenXRInterface.HAND_JOINT_RING_PROXIMAL: HandJoints = 17
Ring finger phalanx proximal joint.

## HAND_JOINT_RING_INTERMEDIATE :: const OpenXRInterface.HAND_JOINT_RING_INTERMEDIATE: HandJoints = 18
Ring finger phalanx intermediate joint.

## HAND_JOINT_RING_DISTAL :: const OpenXRInterface.HAND_JOINT_RING_DISTAL: HandJoints = 19
Ring finger phalanx distal joint.

## HAND_JOINT_RING_TIP :: const OpenXRInterface.HAND_JOINT_RING_TIP: HandJoints = 20
Ring finger tip joint.

## HAND_JOINT_LITTLE_METACARPAL :: const OpenXRInterface.HAND_JOINT_LITTLE_METACARPAL: HandJoints = 21
Pinky finger metacarpal joint.

## HAND_JOINT_LITTLE_PROXIMAL :: const OpenXRInterface.HAND_JOINT_LITTLE_PROXIMAL: HandJoints = 22
Pinky finger phalanx proximal joint.

## HAND_JOINT_LITTLE_INTERMEDIATE :: const OpenXRInterface.HAND_JOINT_LITTLE_INTERMEDIATE: HandJoints = 23
Pinky finger phalanx intermediate joint.

## HAND_JOINT_LITTLE_DISTAL :: const OpenXRInterface.HAND_JOINT_LITTLE_DISTAL: HandJoints = 24
Pinky finger phalanx distal joint.

## HAND_JOINT_LITTLE_TIP :: const OpenXRInterface.HAND_JOINT_LITTLE_TIP: HandJoints = 25
Pinky finger tip joint.

## HAND_JOINT_MAX :: const OpenXRInterface.HAND_JOINT_MAX: HandJoints = 26
Represents the size of the [enum HandJoints] enum.

## PERF_SETTINGS_LEVEL_POWER_SAVINGS :: const OpenXRInterface.PERF_SETTINGS_LEVEL_POWER_SAVINGS: PerfSettingsLevel = 0
The application has entered a non-XR section (head-locked / static screen), during which power savings are to be prioritized.

## PERF_SETTINGS_LEVEL_SUSTAINED_LOW :: const OpenXRInterface.PERF_SETTINGS_LEVEL_SUSTAINED_LOW: PerfSettingsLevel = 1
The application has entered a low and stable complexity section, during which reducing power is more important than occasional late rendering frames.

## PERF_SETTINGS_LEVEL_SUSTAINED_HIGH :: const OpenXRInterface.PERF_SETTINGS_LEVEL_SUSTAINED_HIGH: PerfSettingsLevel = 2
The application has entered a high or dynamic complexity section, during which the XR Runtime strives for consistent XR compositing and frame rendering within a thermally sustainable range.

## PERF_SETTINGS_LEVEL_BOOST :: const OpenXRInterface.PERF_SETTINGS_LEVEL_BOOST: PerfSettingsLevel = 3
The application has entered a section with very high complexity, during which the XR Runtime is allowed to step up beyond the thermally sustainable range.

## PERF_SETTINGS_SUB_DOMAIN_COMPOSITING :: const OpenXRInterface.PERF_SETTINGS_SUB_DOMAIN_COMPOSITING: PerfSettingsSubDomain = 0
The compositing performance within the runtime has reached a new level.

## PERF_SETTINGS_SUB_DOMAIN_RENDERING :: const OpenXRInterface.PERF_SETTINGS_SUB_DOMAIN_RENDERING: PerfSettingsSubDomain = 1
The application rendering performance has reached a new level.

## PERF_SETTINGS_SUB_DOMAIN_THERMAL :: const OpenXRInterface.PERF_SETTINGS_SUB_DOMAIN_THERMAL: PerfSettingsSubDomain = 2
The temperature of the device has reached a new level.

## PERF_SETTINGS_NOTIF_LEVEL_NORMAL :: const OpenXRInterface.PERF_SETTINGS_NOTIF_LEVEL_NORMAL: PerfSettingsNotificationLevel = 0
The sub-domain has reached a level where no further actions other than currently applied are necessary.

## PERF_SETTINGS_NOTIF_LEVEL_WARNING :: const OpenXRInterface.PERF_SETTINGS_NOTIF_LEVEL_WARNING: PerfSettingsNotificationLevel = 1
The sub-domain has reached an early warning level where the application should start proactive mitigation actions.

## PERF_SETTINGS_NOTIF_LEVEL_IMPAIRED :: const OpenXRInterface.PERF_SETTINGS_NOTIF_LEVEL_IMPAIRED: PerfSettingsNotificationLevel = 2
The sub-domain has reached a critical level where the application should start drastic mitigation actions.

## HAND_JOINT_NONE :: const OpenXRInterface.HAND_JOINT_NONE: HandJointFlags = 0
No flags are set.

## HAND_JOINT_ORIENTATION_VALID :: const OpenXRInterface.HAND_JOINT_ORIENTATION_VALID: HandJointFlags = 1
If set, the orientation data is valid, otherwise, the orientation data is unreliable and should not be used.

## HAND_JOINT_ORIENTATION_TRACKED :: const OpenXRInterface.HAND_JOINT_ORIENTATION_TRACKED: HandJointFlags = 2
If set, the orientation data comes from tracking data, otherwise, the orientation data contains predicted data.

## HAND_JOINT_POSITION_VALID :: const OpenXRInterface.HAND_JOINT_POSITION_VALID: HandJointFlags = 4
If set, the positional data is valid, otherwise, the positional data is unreliable and should not be used.

## HAND_JOINT_POSITION_TRACKED :: const OpenXRInterface.HAND_JOINT_POSITION_TRACKED: HandJointFlags = 8
If set, the positional data comes from tracking data, otherwise, the positional data contains predicted data.

## HAND_JOINT_LINEAR_VELOCITY_VALID :: const OpenXRInterface.HAND_JOINT_LINEAR_VELOCITY_VALID: HandJointFlags = 16
If set, our linear velocity data is valid, otherwise, the linear velocity data is unreliable and should not be used.

## HAND_JOINT_ANGULAR_VELOCITY_VALID :: const OpenXRInterface.HAND_JOINT_ANGULAR_VELOCITY_VALID: HandJointFlags = 32
If set, our angular velocity data is valid, otherwise, the angular velocity data is unreliable and should not be used.

## display_refresh_rate :: var OpenXRInterface.display_refresh_rate: float
The display refresh rate for the current HMD. Only functional if this feature is supported by the OpenXR runtime and after the interface has been initialized.

## foveation_dynamic :: var OpenXRInterface.foveation_dynamic: bool
If [code]true[/code], enables dynamic foveation adjustment. The interface must be initialized before this is accessible. If enabled, foveation will automatically be adjusted between low and [member foveation_level].

## foveation_level :: var OpenXRInterface.foveation_level: int
The foveation level, from [code]0[/code] (off) to [code]3[/code] (high). The interface must be initialized before this is accessible.

## foveation_with_subsampled_images :: var OpenXRInterface.foveation_with_subsampled_images: bool
If [code]true[/code], enables subsampled images with foveation, which can provide a performance boost on Vulkan.

## render_target_size_multiplier :: var OpenXRInterface.render_target_size_multiplier: float
The render size multiplier for the current HMD. Must be set before the interface has been initialized.

## vrs_min_radius :: var OpenXRInterface.vrs_min_radius: float
The minimum radius around the focal point where full quality is guaranteed if VRS is used as a percentage of screen size.
[b]Note:[/b] Mobile and Forward+ renderers only. Requires [member Viewport.vrs_mode] to be set to [constant Viewport.VRS_XR].

## vrs_strength :: var OpenXRInterface.vrs_strength: float
The strength used to calculate the VRS density map. The greater this value, the more noticeable VRS is. This improves performance at the cost of quality.
[b]Note:[/b] Mobile and Forward+ renderers only. Requires [member Viewport.vrs_mode] to be set to [constant Viewport.VRS_XR].

## get_action_sets :: func OpenXRInterface.get_action_sets() -> Array
Returns a list of action sets registered with Godot (loaded from the action map at runtime).

## get_available_display_refresh_rates :: func OpenXRInterface.get_available_display_refresh_rates() -> Array
Returns a list of display refresh rates supported by the current HMD. Only returned if this feature is supported by the OpenXR runtime and after the interface has been initialized.

## get_hand_joint_angular_velocity :: func OpenXRInterface.get_hand_joint_angular_velocity(hand: int, joint: int) -> Vector3
If handtracking is enabled, returns the angular velocity of a joint ([param joint]) of a hand ([param hand]) as provided by OpenXR. This is relative to [XROrigin3D]!

### hand :: int

### joint :: int

## get_hand_joint_flags :: func OpenXRInterface.get_hand_joint_flags(hand: int, joint: int) -> int
If handtracking is enabled, returns flags that inform us of the validity of the tracking data.

### hand :: int

### joint :: int

## get_hand_joint_linear_velocity :: func OpenXRInterface.get_hand_joint_linear_velocity(hand: int, joint: int) -> Vector3
If handtracking is enabled, returns the linear velocity of a joint ([param joint]) of a hand ([param hand]) as provided by OpenXR. This is relative to [XROrigin3D] without worldscale applied!

### hand :: int

### joint :: int

## get_hand_joint_position :: func OpenXRInterface.get_hand_joint_position(hand: int, joint: int) -> Vector3
If handtracking is enabled, returns the position of a joint ([param joint]) of a hand ([param hand]) as provided by OpenXR. This is relative to [XROrigin3D] without worldscale applied!

### hand :: int

### joint :: int

## get_hand_joint_radius :: func OpenXRInterface.get_hand_joint_radius(hand: int, joint: int) -> float
If handtracking is enabled, returns the radius of a joint ([param joint]) of a hand ([param hand]) as provided by OpenXR. This is without worldscale applied!

### hand :: int

### joint :: int

## get_hand_joint_rotation :: func OpenXRInterface.get_hand_joint_rotation(hand: int, joint: int) -> Quaternion
If handtracking is enabled, returns the rotation of a joint ([param joint]) of a hand ([param hand]) as provided by OpenXR.

### hand :: int

### joint :: int

## get_hand_tracking_source :: func OpenXRInterface.get_hand_tracking_source(hand: int) -> int
If handtracking is enabled and hand tracking source is supported, gets the source of the hand tracking data for [param hand].

### hand :: int

## get_motion_range :: func OpenXRInterface.get_motion_range(hand: int) -> int
If handtracking is enabled and motion range is supported, gets the currently configured motion range for [param hand].

### hand :: int

## get_session_state :: func OpenXRInterface.get_session_state() -> int
Returns the current state of our OpenXR session.

## is_action_set_active :: func OpenXRInterface.is_action_set_active(name: String) -> bool
Returns [code]true[/code] if the given action set is active.

### name :: String

## is_eye_gaze_interaction_supported :: func OpenXRInterface.is_eye_gaze_interaction_supported() -> bool
Returns the capabilities of the eye gaze interaction extension.
[b]Note:[/b] This only returns a valid value after OpenXR has been initialized.

## is_foveation_supported :: func OpenXRInterface.is_foveation_supported() -> bool
Returns [code]true[/code] if OpenXR's foveation extension is supported. The interface must be initialized before this returns a valid value.
[b]Note:[/b] When using the Vulkan rendering driver, [member Viewport.vrs_mode] must be set to [constant Viewport.VRS_XR] to support foveation.

## is_hand_interaction_supported :: func OpenXRInterface.is_hand_interaction_supported() -> bool
Returns [code]true[/code] if OpenXR's hand interaction profile is supported and enabled.
[b]Note:[/b] This only returns a valid value after OpenXR has been initialized.

## is_hand_tracking_supported :: func OpenXRInterface.is_hand_tracking_supported() -> bool
Returns [code]true[/code] if OpenXR's hand tracking is supported and enabled.
[b]Note:[/b] This only returns a valid value after OpenXR has been initialized.

## is_user_presence_supported :: func OpenXRInterface.is_user_presence_supported() -> bool
Returns [code]true[/code] if OpenXR's user presence extension is supported and enabled.
[b]Note:[/b] This only returns a valid value after OpenXR has been initialized.

## is_user_present :: func OpenXRInterface.is_user_present() -> bool
Returns [code]true[/code] if system has detected the presence of a user in the XR experience.

## set_action_set_active :: func OpenXRInterface.set_action_set_active(name: String, active: bool) -> void
Sets the given action set as active or inactive.

### name :: String

### active :: bool

## set_cpu_level :: func OpenXRInterface.set_cpu_level(level: int) -> void
Sets the CPU performance level of the OpenXR device.

### level :: int

## set_gpu_level :: func OpenXRInterface.set_gpu_level(level: int) -> void
Sets the GPU performance level of the OpenXR device.

### level :: int

## set_motion_range :: func OpenXRInterface.set_motion_range(hand: int, motion_range: int) -> void
If handtracking is enabled and motion range is supported, sets the currently configured motion range for [param hand] to [param motion_range].

### hand :: int

### motion_range :: int

## cpu_level_changed :: func OpenXRInterface.cpu_level_changed(sub_domain: int, from_level: int, to_level: int) -> void
Informs the device CPU performance level has changed in the specified subdomain.

### sub_domain :: int

### from_level :: int

### to_level :: int

## gpu_level_changed :: func OpenXRInterface.gpu_level_changed(sub_domain: int, from_level: int, to_level: int) -> void
Informs the device GPU performance level has changed in the specified subdomain.

### sub_domain :: int

### from_level :: int

### to_level :: int

## instance_exiting :: func OpenXRInterface.instance_exiting() -> void
Informs our OpenXR instance is exiting.

## pose_recentered :: func OpenXRInterface.pose_recentered() -> void
Informs the user queued a recenter of the player position.

## refresh_rate_changed :: func OpenXRInterface.refresh_rate_changed(refresh_rate: float) -> void
Informs the user the HMD refresh rate has changed.
[b]Note:[/b] Only emitted if XR runtime supports the refresh rate extension.

### refresh_rate :: float

## session_begun :: func OpenXRInterface.session_begun() -> void
Informs our OpenXR session has been started.

## session_focussed :: func OpenXRInterface.session_focussed() -> void
Informs our OpenXR session now has focus, for example output is sent to the HMD and we're receiving XR input.

## session_loss_pending :: func OpenXRInterface.session_loss_pending() -> void
Informs our OpenXR session is in the process of being lost.

## session_stopping :: func OpenXRInterface.session_stopping() -> void
Informs our OpenXR session is stopping.

## session_synchronized :: func OpenXRInterface.session_synchronized() -> void
Informs our OpenXR session has been synchronized.

## session_visible :: func OpenXRInterface.session_visible() -> void
Informs our OpenXR session is now visible, for example output is sent to the HMD but we don't receive XR input.

## user_presence_changed :: func OpenXRInterface.user_presence_changed(is_user_present: bool) -> void
Signal emitted when the user presence value changes.
[b]Note:[/b] This signal will not be emitted during application startup and application shutdown. Developers should assume user presence is gained on startup and lost on shutdown.

### is_user_present :: bool
