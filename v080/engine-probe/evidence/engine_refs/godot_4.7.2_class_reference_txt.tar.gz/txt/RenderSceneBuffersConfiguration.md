# RenderSceneBuffersConfiguration :: <Native> class RenderSceneBuffersConfiguration extends RefCounted
Configuration object used to setup a [RenderSceneBuffers] object.
This configuration object is created and populated by the render engine on a viewport change and used to (re)configure a [RenderSceneBuffers] object.

## anisotropic_filtering_level :: var RenderSceneBuffersConfiguration.anisotropic_filtering_level: RenderingServer.ViewportAnisotropicFiltering
Level of the anisotropic filter.

## fsr_sharpness :: var RenderSceneBuffersConfiguration.fsr_sharpness: float
FSR Sharpness applicable if FSR upscaling is used.

## internal_size :: var RenderSceneBuffersConfiguration.internal_size: Vector2i
The size of the 3D render buffer used for rendering.

## msaa_3d :: var RenderSceneBuffersConfiguration.msaa_3d: RenderingServer.ViewportMSAA
The MSAA mode we're using for 3D rendering.

## render_target :: var RenderSceneBuffersConfiguration.render_target: RID
The render target associated with these buffer.

## scaling_3d_mode :: var RenderSceneBuffersConfiguration.scaling_3d_mode: RenderingServer.ViewportScaling3DMode
The requested scaling mode with which we upscale/downscale if [member internal_size] and [member target_size] are not equal.

## screen_space_aa :: var RenderSceneBuffersConfiguration.screen_space_aa: RenderingServer.ViewportScreenSpaceAA
The requested screen space AA applied in post processing.

## target_size :: var RenderSceneBuffersConfiguration.target_size: Vector2i
The target (upscale) size if scaling is used.

## texture_mipmap_bias :: var RenderSceneBuffersConfiguration.texture_mipmap_bias: float
Bias applied to mipmaps.
[b]Note:[/b] This property is only supported in the Forward+ and Mobile renderers, not Compatibility. In Compatibility, this property is always treated as if it was set to [code]0.0[/code].

## view_count :: var RenderSceneBuffersConfiguration.view_count: int
The number of views we're rendering.
