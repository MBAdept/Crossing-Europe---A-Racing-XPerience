# WebSocketPeer :: <Native> class WebSocketPeer extends PacketPeer
A WebSocket connection.
This class represents WebSocket connection, and can be used as a WebSocket client ([url=https://datatracker.ietf.org/doc/html/rfc6455]RFC 6455[/url]-compliant) or as a remote peer of a WebSocket server.
You can send WebSocket binary frames using [method PacketPeer.put_packet], and WebSocket text frames using [method send] (prefer text frames when interacting with text-based API). You can check the frame type of the last packet via [method was_string_packet].
To start a WebSocket client, first call [method connect_to_url], then regularly call [method poll] (e.g. during [Node] process). You can query the socket state via [method get_ready_state], get the number of pending packets using [method PacketPeer.get_available_packet_count], and retrieve them via [method PacketPeer.get_packet].
[codeblocks]
[gdscript]
extends Node

var socket = WebSocketPeer.new()

func _ready():
	socket.connect_to_url("wss://example.com")

func _process(delta):
	socket.poll()
	var state = socket.get_ready_state()
	if state == WebSocketPeer.STATE_OPEN:
		while socket.get_available_packet_count():
			print("Packet: ", socket.get_packet())
	elif state == WebSocketPeer.STATE_CLOSING:
		# Keep polling to achieve proper close.
		pass
	elif state == WebSocketPeer.STATE_CLOSED:
		var code = socket.get_close_code()
		var reason = socket.get_close_reason()
		print("WebSocket closed with code: %d, reason %s. Clean: %s" % [code, reason, code != -1])
		set_process(false) # Stop processing.
[/gdscript]
[/codeblocks]
To use the peer as part of a WebSocket server refer to [method accept_stream] and the online tutorial.

## WRITE_MODE_TEXT :: const WebSocketPeer.WRITE_MODE_TEXT: WriteMode = 0
Specifies that WebSockets messages should be transferred as text payload (only valid UTF-8 is allowed).

## WRITE_MODE_BINARY :: const WebSocketPeer.WRITE_MODE_BINARY: WriteMode = 1
Specifies that WebSockets messages should be transferred as binary payload (any byte combination is allowed).

## STATE_CONNECTING :: const WebSocketPeer.STATE_CONNECTING: State = 0
Socket has been created. The connection is not yet open.

## STATE_OPEN :: const WebSocketPeer.STATE_OPEN: State = 1
The connection is open and ready to communicate.

## STATE_CLOSING :: const WebSocketPeer.STATE_CLOSING: State = 2
The connection is in the process of closing. This means a close request has been sent to the remote peer but confirmation has not been received.

## STATE_CLOSED :: const WebSocketPeer.STATE_CLOSED: State = 3
The connection is closed or couldn't be opened.

## handshake_headers :: var WebSocketPeer.handshake_headers: PackedStringArray
The extra HTTP headers to be sent during the WebSocket handshake.
[b]Note:[/b] Not supported in Web exports due to browsers' restrictions.

## heartbeat_interval :: var WebSocketPeer.heartbeat_interval: float
The interval (in seconds) at which the peer will automatically send WebSocket "ping" control frames. When set to [code]0[/code], no "ping" control frames will be sent.
[b]Note:[/b] Has no effect in Web exports due to browser restrictions.

## inbound_buffer_size :: var WebSocketPeer.inbound_buffer_size: int
The size of the input buffer in bytes (roughly the maximum amount of memory that will be allocated for the inbound packets).

## max_queued_packets :: var WebSocketPeer.max_queued_packets: int
The maximum amount of packets that will be allowed in the queues (both inbound and outbound).

## outbound_buffer_size :: var WebSocketPeer.outbound_buffer_size: int
The size of the input buffer in bytes (roughly the maximum amount of memory that will be allocated for the outbound packets).

## supported_protocols :: var WebSocketPeer.supported_protocols: PackedStringArray
The WebSocket sub-protocols allowed during the WebSocket handshake.

## accept_stream :: func WebSocketPeer.accept_stream(stream: StreamPeer) -> int
Accepts a peer connection performing the HTTP handshake as a WebSocket server. The [param stream] must be a valid TCP stream retrieved via [method TCPServer.take_connection], or a TLS stream accepted via [method StreamPeerTLS.accept_stream].
[b]Note:[/b] Not supported in Web exports due to browsers' restrictions.

### stream :: StreamPeer

## close :: func WebSocketPeer.close(code: int = 1000, reason: String = "") -> void
Closes this WebSocket connection.
[param code] is the status code for the closure (see [url=https://datatracker.ietf.org/doc/html/rfc6455#section-7.4.1]RFC 6455 section 7.4[/url] for a list of valid status codes). If [param code] is negative, the connection will be closed immediately without notifying the remote peer.
[param reason] is the human-readable reason for closing the connection. It can be any UTF-8 string that's smaller than 123 bytes.
[b]Note:[/b] To achieve a clean closure, you will need to keep polling until [constant STATE_CLOSED] is reached.
[b]Note:[/b] The Web export might not support all status codes. Please refer to browser-specific documentation for more details.

### code :: int

### reason :: String

## connect_to_url :: func WebSocketPeer.connect_to_url(url: String, tls_client_options: TLSOptions = null) -> int
Connects to the given URL. TLS certificates will be verified against the hostname when connecting using the [code]wss://[/code] protocol. You can pass the optional [param tls_client_options] parameter to customize the trusted certification authorities, or disable the common name verification. See [method TLSOptions.client] and [method TLSOptions.client_unsafe].
[b]Note:[/b] This method is non-blocking, and will return [constant OK] before the connection is established as long as the provided parameters are valid and the peer is not in an invalid state (e.g. already connected). Regularly call [method poll] (e.g. during [Node] process) and check the result of [method get_ready_state] to know whether the connection succeeds or fails.
[b]Note:[/b] To avoid mixed content warnings or errors in Web, you may have to use a [param url] that starts with [code]wss://[/code] (secure) instead of [code]ws://[/code]. When doing so, make sure to use the fully qualified domain name that matches the one defined in the server's TLS certificate. Do not connect directly via the IP address for [code]wss://[/code] connections, as it won't match with the TLS certificate.

### url :: String

### tls_client_options :: TLSOptions

## get_close_code :: func WebSocketPeer.get_close_code() -> int
Returns the received WebSocket close frame status code, or [code]-1[/code] when the connection was not cleanly closed. Only call this method when [method get_ready_state] returns [constant STATE_CLOSED].

## get_close_reason :: func WebSocketPeer.get_close_reason() -> String
Returns the received WebSocket close frame status reason string. Only call this method when [method get_ready_state] returns [constant STATE_CLOSED].

## get_connected_host :: func WebSocketPeer.get_connected_host() -> String
Returns the IP address of the connected peer.
[b]Note:[/b] Not available in the Web export.

## get_connected_port :: func WebSocketPeer.get_connected_port() -> int
Returns the remote port of the connected peer.
[b]Note:[/b] Not available in the Web export.

## get_current_outbound_buffered_amount :: func WebSocketPeer.get_current_outbound_buffered_amount() -> int
Returns the current amount of data in the outbound websocket buffer. [b]Note:[/b] Web exports use WebSocket.bufferedAmount, while other platforms use an internal buffer.

## get_ready_state :: func WebSocketPeer.get_ready_state() -> int
Returns the ready state of the connection.

## get_requested_url :: func WebSocketPeer.get_requested_url() -> String
Returns the URL requested by this peer. The URL is derived from the [code]url[/code] passed to [method connect_to_url] or from the HTTP headers when acting as server (i.e. when using [method accept_stream]).

## get_selected_protocol :: func WebSocketPeer.get_selected_protocol() -> String
Returns the selected WebSocket sub-protocol for this connection or an empty string if the sub-protocol has not been selected yet.

## poll :: func WebSocketPeer.poll() -> void
Updates the connection state and receive incoming packets. Call this function regularly to keep it in a clean state.

## send :: func WebSocketPeer.send(message: PackedByteArray, write_mode: int = 1) -> int
Sends the given [param message] using the desired [param write_mode]. When sending a [String], prefer using [method send_text].

### message :: PackedByteArray

### write_mode :: int

## send_text :: func WebSocketPeer.send_text(message: String) -> int
Sends the given [param message] using WebSocket text mode. Prefer this method over [method PacketPeer.put_packet] when interacting with third-party text-based API (e.g. when using [JSON] formatted messages).

### message :: String

## set_no_delay :: func WebSocketPeer.set_no_delay(enabled: bool) -> void
Disable Nagle's algorithm on the underlying TCP socket (default). See [method StreamPeerTCP.set_no_delay] for more information.
[b]Note:[/b] Not available in the Web export.

### enabled :: bool

## was_string_packet :: func WebSocketPeer.was_string_packet() -> bool
Returns [code]true[/code] if the last received packet was sent as a text payload. See [enum WriteMode].
