# CanvasItem :: <Native> class CanvasItem extends Node
Abstract base class for everything in 2D space.
Abstract base class for everything in 2D space. Canvas items are laid out in a tree; children inherit and extend their parent's transform. [CanvasItem] is extended by [Control] for GUI-related nodes, and by [Node2D] for 2D game objects.
Any [CanvasItem] can draw. For this, [method queue_redraw] is called by the engine, then [constant NOTIFICATION_DRAW] will be received on idle time to request a redraw. Because of this, canvas items don't need to be redrawn on every frame, improving the performance significantly. Several functions for drawing on the [CanvasItem] are provided (see [code]draw_*[/code] functions). However, they can only be used inside [method _draw], its corresponding [method Object._notification] or methods connected to the [signal draw] signal.
Canvas items are drawn in tree order on their canvas layer. By default, children are on top of their parents, so a root [CanvasItem] will be drawn behind everything. This behavior can be changed on a per-item basis.
A [CanvasItem] can be hidden, which will also hide its children. By adjusting various other properties of a [CanvasItem], you can also modulate its color (via [member modulate] or [member self_modulate]), change its Z-index, blend mode, and more.
Note that properties like transform, modulation, and visibility are only propagated to [i]direct[/i] [CanvasItem] child nodes. If there is a non-[CanvasItem] node in between, like [Node] or [AnimationPlayer], the [CanvasItem] nodes below will have an independent position and [member modulate] chain. See also [member top_level].

## NOTIFICATION_TRANSFORM_CHANGED :: const CanvasItem.NOTIFICATION_TRANSFORM_CHANGED = 2000
Notification received when this node's global transform changes, if [method is_transform_notification_enabled] is [code]true[/code]. See also [method set_notify_transform] and [method get_transform].
[b]Note:[/b] Many canvas items such as [Camera2D] or [CollisionObject2D] automatically enable this in order to function correctly.

## NOTIFICATION_LOCAL_TRANSFORM_CHANGED :: const CanvasItem.NOTIFICATION_LOCAL_TRANSFORM_CHANGED = 35
Notification received when this node's transform changes, if [method is_local_transform_notification_enabled] is [code]true[/code]. This is not received when a parent [Node2D]'s transform changes. See also [method set_notify_local_transform].
[b]Note:[/b] Many canvas items such as [Camera2D] or [CollisionShape2D] automatically enable this in order to function correctly.

## NOTIFICATION_DRAW :: const CanvasItem.NOTIFICATION_DRAW = 30
The [CanvasItem] is requested to draw (see [method _draw]).

## NOTIFICATION_VISIBILITY_CHANGED :: const CanvasItem.NOTIFICATION_VISIBILITY_CHANGED = 31
Notification received when this node's visibility changes (see [member visible] and [method is_visible_in_tree]).
This notification is received [i]before[/i] the related [signal visibility_changed] signal.

## NOTIFICATION_ENTER_CANVAS :: const CanvasItem.NOTIFICATION_ENTER_CANVAS = 32
The [CanvasItem] has entered the canvas.

## NOTIFICATION_EXIT_CANVAS :: const CanvasItem.NOTIFICATION_EXIT_CANVAS = 33
The [CanvasItem] has exited the canvas.
This notification is sent in reversed order.

## NOTIFICATION_WORLD_2D_CHANGED :: const CanvasItem.NOTIFICATION_WORLD_2D_CHANGED = 36
Notification received when this [CanvasItem] is registered to a new [World2D] (see [method get_world_2d]).

## TEXTURE_FILTER_PARENT_NODE :: const CanvasItem.TEXTURE_FILTER_PARENT_NODE: TextureFilter = 0
The [CanvasItem] will inherit the filter from its parent.

## TEXTURE_FILTER_NEAREST :: const CanvasItem.TEXTURE_FILTER_NEAREST: TextureFilter = 1
The texture filter reads from the nearest pixel only. This makes the texture look pixelated from up close, and grainy from a distance (due to mipmaps not being sampled).

## TEXTURE_FILTER_LINEAR :: const CanvasItem.TEXTURE_FILTER_LINEAR: TextureFilter = 2
The texture filter blends between the nearest 4 pixels. This makes the texture look smooth from up close, and grainy from a distance (due to mipmaps not being sampled).

## TEXTURE_FILTER_NEAREST_WITH_MIPMAPS :: const CanvasItem.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS: TextureFilter = 3
The texture filter reads from the nearest pixel and blends between the nearest 2 mipmaps (or uses the nearest mipmap if [member ProjectSettings.rendering/textures/default_filters/use_nearest_mipmap_filter] is [code]true[/code]). This makes the texture look pixelated from up close, and smooth from a distance.
Use this for non-pixel art textures that may be viewed at a low scale (e.g. due to [Camera2D] zoom or sprite scaling), as mipmaps are important to smooth out pixels that are smaller than on-screen pixels.

## TEXTURE_FILTER_LINEAR_WITH_MIPMAPS :: const CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS: TextureFilter = 4
The texture filter blends between the nearest 4 pixels and between the nearest 2 mipmaps (or uses the nearest mipmap if [member ProjectSettings.rendering/textures/default_filters/use_nearest_mipmap_filter] is [code]true[/code]). This makes the texture look smooth from up close, and smooth from a distance.
Use this for non-pixel art textures that may be viewed at a low scale (e.g. due to [Camera2D] zoom or sprite scaling), as mipmaps are important to smooth out pixels that are smaller than on-screen pixels.

## TEXTURE_FILTER_NEAREST_WITH_MIPMAPS_ANISOTROPIC :: const CanvasItem.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS_ANISOTROPIC: TextureFilter = 5
The texture filter reads from the nearest pixel and blends between 2 mipmaps (or uses the nearest mipmap if [member ProjectSettings.rendering/textures/default_filters/use_nearest_mipmap_filter] is [code]true[/code]) based on the angle between the surface and the camera view. This makes the texture look pixelated from up close, and smooth from a distance. Anisotropic filtering improves texture quality on surfaces that are almost in line with the camera, but is slightly slower. The anisotropic filtering level can be changed by adjusting [member ProjectSettings.rendering/textures/default_filters/anisotropic_filtering_level].
[b]Note:[/b] This texture filter is rarely useful in 2D projects. [constant TEXTURE_FILTER_NEAREST_WITH_MIPMAPS] is usually more appropriate in this case.

## TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC :: const CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC: TextureFilter = 6
The texture filter blends between the nearest 4 pixels and blends between 2 mipmaps (or uses the nearest mipmap if [member ProjectSettings.rendering/textures/default_filters/use_nearest_mipmap_filter] is [code]true[/code]) based on the angle between the surface and the camera view. This makes the texture look smooth from up close, and smooth from a distance. Anisotropic filtering improves texture quality on surfaces that are almost in line with the camera, but is slightly slower. The anisotropic filtering level can be changed by adjusting [member ProjectSettings.rendering/textures/default_filters/anisotropic_filtering_level].
[b]Note:[/b] This texture filter is rarely useful in 2D projects. [constant TEXTURE_FILTER_LINEAR_WITH_MIPMAPS] is usually more appropriate in this case.

## TEXTURE_FILTER_MAX :: const CanvasItem.TEXTURE_FILTER_MAX: TextureFilter = 7
Represents the size of the [enum TextureFilter] enum.

## TEXTURE_REPEAT_PARENT_NODE :: const CanvasItem.TEXTURE_REPEAT_PARENT_NODE: TextureRepeat = 0
The [CanvasItem] will inherit the repeat mode from its parent.

## TEXTURE_REPEAT_DISABLED :: const CanvasItem.TEXTURE_REPEAT_DISABLED: TextureRepeat = 1
The texture does not repeat. Sampling the texture outside its extents will result in "stretching" of the edge pixels. You can avoid this by ensuring a 1-pixel fully transparent border on each side of the texture.

## TEXTURE_REPEAT_ENABLED :: const CanvasItem.TEXTURE_REPEAT_ENABLED: TextureRepeat = 2
The texture repeats when exceeding the texture's size.

## TEXTURE_REPEAT_MIRROR :: const CanvasItem.TEXTURE_REPEAT_MIRROR: TextureRepeat = 3
The texture repeats when the exceeding the texture's size in a "2×2 tiled mode". Repeated textures at even positions are mirrored.

## TEXTURE_REPEAT_MAX :: const CanvasItem.TEXTURE_REPEAT_MAX: TextureRepeat = 4
Represents the size of the [enum TextureRepeat] enum.

## CLIP_CHILDREN_DISABLED :: const CanvasItem.CLIP_CHILDREN_DISABLED: ClipChildrenMode = 0
Children are drawn over this node and are not clipped.

## CLIP_CHILDREN_ONLY :: const CanvasItem.CLIP_CHILDREN_ONLY: ClipChildrenMode = 1
This node is used as a mask and is [b]not[/b] drawn. The mask is based on this node's alpha channel: Opaque pixels are kept, transparent pixels are discarded, and semi-transparent pixels are blended in according to their opacity. Children are clipped to this node's drawn area.

## CLIP_CHILDREN_AND_DRAW :: const CanvasItem.CLIP_CHILDREN_AND_DRAW: ClipChildrenMode = 2
This node is used as a mask and is also drawn. The mask is based on this node's alpha channel: Opaque pixels are kept, transparent pixels are discarded, and semi-transparent pixels are blended in according to their opacity. Children are clipped to the parent's drawn area.

## CLIP_CHILDREN_MAX :: const CanvasItem.CLIP_CHILDREN_MAX: ClipChildrenMode = 3
Represents the size of the [enum ClipChildrenMode] enum.

## OVERSAMPLING_WITH_SCALE_PARENT_NODE :: const CanvasItem.OVERSAMPLING_WITH_SCALE_PARENT_NODE: OversamplingWithScale = 0
The [CanvasItem] will inherit the oversampling mode from its parent.

## OVERSAMPLING_WITH_SCALE_DISABLED :: const CanvasItem.OVERSAMPLING_WITH_SCALE_DISABLED: OversamplingWithScale = 1
The oversampling is not affected by [CanvasItem] scale, and is equal to the [Viewport] oversampling.

## OVERSAMPLING_WITH_SCALE_ENABLED :: const CanvasItem.OVERSAMPLING_WITH_SCALE_ENABLED: OversamplingWithScale = 2
The oversampling is a product of [CanvasItem] scale and [Viewport] oversampling.

## OVERSAMPLING_WITH_SCALE_MAX :: const CanvasItem.OVERSAMPLING_WITH_SCALE_MAX: OversamplingWithScale = 3
Represents the size of the [enum OversamplingWithScale] enum.

## clip_children :: var CanvasItem.clip_children: CanvasItem.ClipChildrenMode
The mode in which this node clips its children, acting as a mask.
[b]Note:[/b] Clipping nodes cannot be nested or placed within a [CanvasGroup]. If an ancestor of this node clips its children or is a [CanvasGroup], then this node's clip mode should be set to [constant CLIP_CHILDREN_DISABLED] to avoid unexpected behavior.

## light_mask :: var CanvasItem.light_mask: int
The rendering layers in which this [CanvasItem] responds to [Light2D] nodes.

## material :: var CanvasItem.material: Material
The material applied to this [CanvasItem].

## modulate :: var CanvasItem.modulate: Color
The color applied to this [CanvasItem]. This property does affect child [CanvasItem]s, unlike [member self_modulate] which only affects the node itself.

## oversampling_with_scale :: var CanvasItem.oversampling_with_scale: CanvasItem.OversamplingWithScale
If enabled, oversampling for this [CanvasItem] is automatically adjusted with scale.

## self_modulate :: var CanvasItem.self_modulate: Color
The color applied to this [CanvasItem]. This property does [b]not[/b] affect child [CanvasItem]s, unlike [member modulate] which affects both the node itself and its children.
[b]Note:[/b] Internal children are also not affected by this property (see the [code]include_internal[/code] parameter in [method Node.add_child]). For built-in nodes this includes sliders in [ColorPicker], and the tab bar in [TabContainer].

## show_behind_parent :: var CanvasItem.show_behind_parent: bool
If [code]true[/code], this node draws behind its parent.

## texture_filter :: var CanvasItem.texture_filter: CanvasItem.TextureFilter
The filtering mode used to render this [CanvasItem]'s texture(s).

## texture_repeat :: var CanvasItem.texture_repeat: CanvasItem.TextureRepeat
The repeating mode used to render this [CanvasItem]'s texture(s). It affects what happens when the texture is sampled outside its extents, for example by setting a [member Sprite2D.region_rect] that is larger than the texture or assigning [Polygon2D] UV points outside the texture.
[b]Note:[/b] [TextureRect] is not affected by [member texture_repeat], as it uses its own texture repeating implementation.

## top_level :: var CanvasItem.top_level: bool
If [code]true[/code], this [CanvasItem] will [i]not[/i] inherit its transform from parent [CanvasItem]s. Its draw order will also be changed to make it draw on top of other [CanvasItem]s that do not have [member top_level] set to [code]true[/code]. The [CanvasItem] will effectively act as if it was placed as a child of a bare [Node].

## use_parent_material :: var CanvasItem.use_parent_material: bool
If [code]true[/code], the parent [CanvasItem]'s [member material] is used as this node's material.

## visibility_layer :: var CanvasItem.visibility_layer: int
The rendering layer in which this [CanvasItem] is rendered by [Viewport] nodes. A [Viewport] will render a [CanvasItem] if it and all its parents share a layer with the [Viewport]'s canvas cull mask.
[b]Note:[/b] A [CanvasItem] does not inherit its parents' visibility layers. This means that if a parent [CanvasItem] does not have all the same layers as its child, the child may not be visible even if both the parent and child have [member visible] set to [code]true[/code]. For example, if a parent has layer 1 and a child has layer 2, the child will not be visible in a [Viewport] with the canvas cull mask set to layer 1 or 2 (see [member Viewport.canvas_cull_mask]). To ensure that both the parent and child are visible, the parent must have both layers 1 and 2, or the child must have [member top_level] set to [code]true[/code].

## visible :: var CanvasItem.visible: bool
If [code]true[/code], this [CanvasItem] may be drawn. Whether this [CanvasItem] is actually drawn depends on the visibility of all of its [CanvasItem] ancestors. In other words: this [CanvasItem] will be drawn when [method is_visible_in_tree] returns [code]true[/code] and all [CanvasItem] ancestors share at least one [member visibility_layer] with this [CanvasItem].
[b]Note:[/b] For controls that inherit [Popup], the correct way to make them visible is to call one of the multiple [code]popup*()[/code] functions instead.

## y_sort_enabled :: var CanvasItem.y_sort_enabled: bool
If [code]true[/code], this and child [CanvasItem] nodes with a higher Y position are rendered in front of nodes with a lower Y position. If [code]false[/code], this and child [CanvasItem] nodes are rendered normally in scene tree order.
With Y-sorting enabled on a parent node ('A') but disabled on a child node ('B'), the child node ('B') is sorted but its children ('C1', 'C2', etc.) render together on the same Y position as the child node ('B'). This allows you to organize the render order of a scene without changing the scene tree.
Nodes sort relative to each other only if they are on the same [member z_index].

## z_as_relative :: var CanvasItem.z_as_relative: bool
If [code]true[/code], this node's final Z index is relative to its parent's Z index.
For example, if [member z_index] is [code]2[/code] and its parent's final Z index is [code]3[/code], then this node's final Z index will be [code]5[/code] ([code]2 + 3[/code]).

## z_index :: var CanvasItem.z_index: int
The order in which this node is drawn. A node with a higher Z index will display in front of others. Must be between [constant RenderingServer.CANVAS_ITEM_Z_MIN] and [constant RenderingServer.CANVAS_ITEM_Z_MAX] (inclusive).
[b]Note:[/b] The Z index does [b]not[/b] affect the order in which [CanvasItem] nodes are processed or the way input events are handled. This is especially important to keep in mind for [Control] nodes.

## _draw :: func CanvasItem._draw() -> void
Called when [CanvasItem] has been requested to redraw (after [method queue_redraw] is called, either manually or by the engine).
Corresponds to the [constant NOTIFICATION_DRAW] notification in [method Object._notification].

## draw_animation_slice :: func CanvasItem.draw_animation_slice(animation_length: float, slice_begin: float, slice_end: float, offset: float = 0.0) -> void
Subsequent drawing commands will be ignored unless they fall within the specified animation slice. This is a faster way to implement animations that loop on background rather than redrawing constantly.

### animation_length :: float

### slice_begin :: float

### slice_end :: float

### offset :: float

## draw_arc :: func CanvasItem.draw_arc(center: Vector2, radius: float, start_angle: float, end_angle: float, point_count: int, color: Color, width: float = -1.0, antialiased: bool = false) -> void
Draws an unfilled arc between the given angles with a uniform [param color] and [param width] and optional antialiasing (supported only for positive [param width]). The larger the value of [param point_count], the smoother the curve. [param center] is defined in local space. For elliptical arcs, see [method draw_ellipse_arc]. See also [method draw_circle].
If [param width] is negative, it will be ignored and the arc will be drawn using [constant RenderingServer.PRIMITIVE_LINE_STRIP]. This means that when the CanvasItem is scaled, the arc will remain thin. If this behavior is not desired, then pass a positive [param width] like [code]1.0[/code].
The arc is drawn from [param start_angle] towards the value of [param end_angle] so in clockwise direction if [code]start_angle < end_angle[/code] and counter-clockwise otherwise. Passing the same angles but in reversed order will produce the same arc. If absolute difference of [param start_angle] and [param end_angle] is greater than [constant @GDScript.TAU] radians, then a full circle arc is drawn (i.e. arc will not overlap itself).

### center :: Vector2

### radius :: float

### start_angle :: float

### end_angle :: float

### point_count :: int

### color :: Color

### width :: float

### antialiased :: bool

## draw_char :: func CanvasItem.draw_char(font: Font, pos: Vector2, char: String, font_size: int = 16, modulate: Color = Color(1, 1, 1, 1), oversampling: float = 0.0) -> void
Draws a string first character using a custom font. If [param oversampling] is greater than zero, it is used as font oversampling factor, otherwise viewport oversampling settings are used. [param pos] is defined in local space.

### font :: Font

### pos :: Vector2

### char :: String

### font_size :: int

### modulate :: Color

### oversampling :: float

## draw_char_outline :: func CanvasItem.draw_char_outline(font: Font, pos: Vector2, char: String, font_size: int = 16, size: int = -1, modulate: Color = Color(1, 1, 1, 1), oversampling: float = 0.0) -> void
Draws a string first character outline using a custom font. If [param oversampling] is greater than zero, it is used as font oversampling factor, otherwise viewport oversampling settings are used. [param pos] is defined in local space.

### font :: Font

### pos :: Vector2

### char :: String

### font_size :: int

### size :: int

### modulate :: Color

### oversampling :: float

## draw_circle :: func CanvasItem.draw_circle(position: Vector2, radius: float, color: Color, filled: bool = true, width: float = -1.0, antialiased: bool = false) -> void
Draws a circle, with [param position] defined in local space. See also [method draw_ellipse], [method draw_arc], [method draw_polyline], and [method draw_polygon].
If [param filled] is [code]true[/code], the circle will be filled with the [param color] specified. If [param filled] is [code]false[/code], the circle will be drawn as a stroke with the [param color] and [param width] specified.
If [param width] is negative, then two-point primitives will be drawn instead of a four-point ones. This means that when the CanvasItem is scaled, the lines will remain thin. If this behavior is not desired, then pass a positive [param width] like [code]1.0[/code].
If [param antialiased] is [code]true[/code], half transparent "feathers" will be attached to the boundary, making outlines smooth.
[b]Note:[/b] [param width] is only effective if [param filled] is [code]false[/code].

### position :: Vector2

### radius :: float

### color :: Color

### filled :: bool

### width :: float

### antialiased :: bool

## draw_colored_polygon :: func CanvasItem.draw_colored_polygon(points: PackedVector2Array, color: Color, uvs: PackedVector2Array = PackedVector2Array(), texture: Texture2D = null) -> void
Draws a colored polygon of any number of points, convex or concave. The points in the [param points] array are defined in local space. Unlike [method draw_polygon], a single color must be specified for the whole polygon.
[b]Note:[/b] If you frequently redraw the same polygon with a large number of vertices, consider pre-calculating the triangulation with [method Geometry2D.triangulate_polygon] and using [method draw_mesh], [method draw_multimesh], or [method RenderingServer.canvas_item_add_triangle_array].
[b]Note:[/b] Styleboxes, textures, and meshes stored only inside local variables should [b]not[/b] be used with this method in GDScript, because the drawing operation doesn't begin immediately once this method is called. In GDScript, when the function with the local variables ends, the local variables get destroyed before the rendering takes place.

### points :: PackedVector2Array

### color :: Color

### uvs :: PackedVector2Array

### texture :: Texture2D

## draw_dashed_line :: func CanvasItem.draw_dashed_line(from: Vector2, to: Vector2, color: Color, width: float = -1.0, dash: float = 2.0, aligned: bool = true, antialiased: bool = false) -> void
Draws a dashed line from a 2D point to another, with a given color and width. The [param from] and [param to] positions are defined in local space. See also [method draw_line], [method draw_multiline], and [method draw_polyline].
If [param width] is negative, then a two-point primitives will be drawn instead of a four-point ones. This means that when the CanvasItem is scaled, the line parts will remain thin. If this behavior is not desired, then pass a positive [param width] like [code]1.0[/code].
[param dash] is the length of each dash in pixels, with the gap between each dash being the same length. If [param aligned] is [code]true[/code], the length of the first and last dashes may be shortened or lengthened to allow the line to begin and end at the precise points defined by [param from] and [param to]. Both ends are always symmetrical when [param aligned] is [code]true[/code]. If [param aligned] is [code]false[/code], all dashes will have the same length, but the line may appear incomplete at the end due to the dash length not dividing evenly into the line length. Only full dashes are drawn when [param aligned] is [code]false[/code].
If [param antialiased] is [code]true[/code], half transparent "feathers" will be attached to the boundary, making outlines smooth.
[b]Note:[/b] [param antialiased] is only effective if [param width] is greater than [code]0.0[/code].

### from :: Vector2

### to :: Vector2

### color :: Color

### width :: float

### dash :: float

### aligned :: bool

### antialiased :: bool

## draw_ellipse :: func CanvasItem.draw_ellipse(position: Vector2, major: float, minor: float, color: Color, filled: bool = true, width: float = -1.0, antialiased: bool = false) -> void
Draws an ellipse with semi-major axis [param major] and semi-minor axis [param minor]. See also [method draw_circle], [method draw_ellipse_arc], [method draw_polyline], and [method draw_polygon].
If [param filled] is [code]true[/code], the ellipse will be filled with the [param color] specified. If [param filled] is [code]false[/code], the ellipse will be drawn as a stroke with the [param color] and [param width] specified.
If [param width] is negative, then two-point primitives will be drawn instead of four-point ones. This means that when the CanvasItem is scaled, the lines will remain thin. If this behavior is not desired, then pass a positive [param width] like [code]1.0[/code].
If [param antialiased] is [code]true[/code], half transparent "feathers" will be attached to the boundary, making outlines smooth.
[b]Note:[/b] [param width] is only effective if [param filled] is [code]false[/code].

### position :: Vector2

### major :: float

### minor :: float

### color :: Color

### filled :: bool

### width :: float

### antialiased :: bool

## draw_ellipse_arc :: func CanvasItem.draw_ellipse_arc(center: Vector2, major: float, minor: float, start_angle: float, end_angle: float, point_count: int, color: Color, width: float = -1.0, antialiased: bool = false) -> void
Draws an unfilled elliptical arc between the given angles with a uniform [param color] and [param width] and optional antialiasing (supported only for positive [param width]). The larger the value of [param point_count], the smoother the curve. For circular arcs, see [method draw_arc]. See also [method draw_ellipse].
If [param width] is negative, it will be ignored and the arc will be drawn using [constant RenderingServer.PRIMITIVE_LINE_STRIP]. This means that when the CanvasItem is scaled, the arc will remain thin. If this behavior is not desired, then pass a positive [param width] like [code]1.0[/code].
The arc is drawn from [param start_angle] towards the value of [param end_angle] so in clockwise direction if [code]start_angle < end_angle[/code] and counter-clockwise otherwise. Passing the same angles but in reversed order will produce the same arc. If absolute difference of [param start_angle] and [param end_angle] is greater than [constant @GDScript.TAU] radians, then a full ellipse is drawn (i.e. arc will not overlap itself).

### center :: Vector2

### major :: float

### minor :: float

### start_angle :: float

### end_angle :: float

### point_count :: int

### color :: Color

### width :: float

### antialiased :: bool

## draw_end_animation :: func CanvasItem.draw_end_animation() -> void
After submitting all animations slices via [method draw_animation_slice], this function can be used to revert drawing to its default state (all subsequent drawing commands will be visible). If you don't care about this particular use case, usage of this function after submitting the slices is not required.

## draw_lcd_texture_rect_region :: func CanvasItem.draw_lcd_texture_rect_region(texture: Texture2D, rect: Rect2, src_rect: Rect2, modulate: Color = Color(1, 1, 1, 1)) -> void
Draws a textured rectangle region of the font texture with LCD subpixel anti-aliasing at a given position, optionally modulated by a color. The [param rect] is defined in local space.
Texture is drawn using the following blend operation, blend mode of the [CanvasItemMaterial] is ignored:
[codeblock]
dst.r = texture.r * modulate.r * modulate.a + dst.r * (1.0 - texture.r * modulate.a);
dst.g = texture.g * modulate.g * modulate.a + dst.g * (1.0 - texture.g * modulate.a);
dst.b = texture.b * modulate.b * modulate.a + dst.b * (1.0 - texture.b * modulate.a);
dst.a = modulate.a + dst.a * (1.0 - modulate.a);
[/codeblock]
[b]Note:[/b] Styleboxes, textures, and meshes stored only inside local variables should [b]not[/b] be used with this method in GDScript, because the drawing operation doesn't begin immediately once this method is called. In GDScript, when the function with the local variables ends, the local variables get destroyed before the rendering takes place.

### texture :: Texture2D

### rect :: Rect2

### src_rect :: Rect2

### modulate :: Color

## draw_line :: func CanvasItem.draw_line(from: Vector2, to: Vector2, color: Color, width: float = -1.0, antialiased: bool = false) -> void
Draws a line from a 2D point to another, with a given color and width. It can be optionally antialiased. The [param from] and [param to] positions are defined in local space. See also [method draw_dashed_line], [method draw_multiline], and [method draw_polyline].
If [param width] is negative, then a two-point primitive will be drawn instead of a four-point one. This means that when the CanvasItem is scaled, the line will remain thin. If this behavior is not desired, then pass a positive [param width] like [code]1.0[/code].

### from :: Vector2

### to :: Vector2

### color :: Color

### width :: float

### antialiased :: bool

## draw_mesh :: func CanvasItem.draw_mesh(mesh: Mesh, texture: Texture2D, transform: Transform2D = Transform2D(1, 0, 0, 1, 0, 0), modulate: Color = Color(1, 1, 1, 1)) -> void
Draws a [Mesh] in 2D, using the provided texture. See [MeshInstance2D] for related documentation. The [param transform] is defined in local space.
[b]Note:[/b] Styleboxes, textures, and meshes stored only inside local variables should [b]not[/b] be used with this method in GDScript, because the drawing operation doesn't begin immediately once this method is called. In GDScript, when the function with the local variables ends, the local variables get destroyed before the rendering takes place.

### mesh :: Mesh

### texture :: Texture2D

### transform :: Transform2D

### modulate :: Color

## draw_msdf_texture_rect_region :: func CanvasItem.draw_msdf_texture_rect_region(texture: Texture2D, rect: Rect2, src_rect: Rect2, modulate: Color = Color(1, 1, 1, 1), outline: float = 0.0, pixel_range: float = 4.0, scale: float = 1.0) -> void
Draws a textured rectangle region of the multichannel signed distance field texture at a given position, optionally modulated by a color. The [param rect] is defined in local space. See [member FontFile.multichannel_signed_distance_field] for more information and caveats about MSDF font rendering.
If [param outline] is positive, each alpha channel value of pixel in region is set to maximum value of true distance in the [param outline] radius.
Value of the [param pixel_range] should the same that was used during distance field texture generation.
[b]Note:[/b] Styleboxes, textures, and meshes stored only inside local variables should [b]not[/b] be used with this method in GDScript, because the drawing operation doesn't begin immediately once this method is called. In GDScript, when the function with the local variables ends, the local variables get destroyed before the rendering takes place.

### texture :: Texture2D

### rect :: Rect2

### src_rect :: Rect2

### modulate :: Color

### outline :: float

### pixel_range :: float

### scale :: float

## draw_multiline :: func CanvasItem.draw_multiline(points: PackedVector2Array, color: Color, width: float = -1.0, antialiased: bool = false) -> void
Draws multiple disconnected lines with a uniform [param width] and [param color]. Each line is defined by two consecutive points from [param points] array in local space, i.e. i-th segment consists of [code]points[2 * i][/code], [code]points[2 * i + 1][/code] endpoints. When drawing large amounts of lines, this is faster than using individual [method draw_line] calls. To draw interconnected lines, use [method draw_polyline] instead.
If [param width] is negative, then two-point primitives will be drawn instead of a four-point ones. This means that when the CanvasItem is scaled, the lines will remain thin. If this behavior is not desired, then pass a positive [param width] like [code]1.0[/code].
[b]Note:[/b] [param antialiased] is only effective if [param width] is greater than [code]0.0[/code].

### points :: PackedVector2Array

### color :: Color

### width :: float

### antialiased :: bool

## draw_multiline_colors :: func CanvasItem.draw_multiline_colors(points: PackedVector2Array, colors: PackedColorArray, width: float = -1.0, antialiased: bool = false) -> void
Draws multiple disconnected lines with a uniform [param width] and segment-by-segment coloring. Each segment is defined by two consecutive points from [param points] array in local space and a corresponding color from [param colors] array, i.e. i-th segment consists of [code]points[2 * i][/code], [code]points[2 * i + 1][/code] endpoints and has [code]colors[i][/code] color. When drawing large amounts of lines, this is faster than using individual [method draw_line] calls. To draw interconnected lines, use [method draw_polyline_colors] instead.
If [param width] is negative, then two-point primitives will be drawn instead of a four-point ones. This means that when the CanvasItem is scaled, the lines will remain thin. If this behavior is not desired, then pass a positive [param width] like [code]1.0[/code].
[b]Note:[/b] [param antialiased] is only effective if [param width] is greater than [code]0.0[/code].

### points :: PackedVector2Array

### colors :: PackedColorArray

### width :: float

### antialiased :: bool

## draw_multiline_string :: func CanvasItem.draw_multiline_string(font: Font, pos: Vector2, text: String, alignment: int = 0, width: float = -1, font_size: int = 16, max_lines: int = -1, modulate: Color = Color(1, 1, 1, 1), brk_flags: int = 3, justification_flags: int = 3, direction: int = 0, orientation: int = 0, oversampling: float = 0.0) -> void
Breaks [param text] into lines and draws it using the specified [param font] at the [param pos] in local space (top-left corner). The text will have its color multiplied by [param modulate]. If [param width] is greater than or equal to 0, the text will be clipped if it exceeds the specified width. If [param oversampling] is greater than zero, it is used as font oversampling factor, otherwise viewport oversampling settings are used.

### font :: Font

### pos :: Vector2

### text :: String

### alignment :: int

### width :: float

### font_size :: int

### max_lines :: int

### modulate :: Color

### brk_flags :: int

### justification_flags :: int

### direction :: int

### orientation :: int

### oversampling :: float

## draw_multiline_string_outline :: func CanvasItem.draw_multiline_string_outline(font: Font, pos: Vector2, text: String, alignment: int = 0, width: float = -1, font_size: int = 16, max_lines: int = -1, size: int = 1, modulate: Color = Color(1, 1, 1, 1), brk_flags: int = 3, justification_flags: int = 3, direction: int = 0, orientation: int = 0, oversampling: float = 0.0) -> void
Breaks [param text] to the lines and draws text outline using the specified [param font] at the [param pos] in local space (top-left corner). The text will have its color multiplied by [param modulate]. If [param width] is greater than or equal to 0, the text will be clipped if it exceeds the specified width. If [param oversampling] is greater than zero, it is used as font oversampling factor, otherwise viewport oversampling settings are used.

### font :: Font

### pos :: Vector2

### text :: String

### alignment :: int

### width :: float

### font_size :: int

### max_lines :: int

### size :: int

### modulate :: Color

### brk_flags :: int

### justification_flags :: int

### direction :: int

### orientation :: int

### oversampling :: float

## draw_multimesh :: func CanvasItem.draw_multimesh(multimesh: MultiMesh, texture: Texture2D) -> void
Draws a [MultiMesh] in 2D with the provided texture. See [MultiMeshInstance2D] for related documentation.
[b]Note:[/b] Styleboxes, textures, and meshes stored only inside local variables should [b]not[/b] be used with this method in GDScript, because the drawing operation doesn't begin immediately once this method is called. In GDScript, when the function with the local variables ends, the local variables get destroyed before the rendering takes place.

### multimesh :: MultiMesh

### texture :: Texture2D

## draw_polygon :: func CanvasItem.draw_polygon(points: PackedVector2Array, colors: PackedColorArray, uvs: PackedVector2Array = PackedVector2Array(), texture: Texture2D = null) -> void
Draws a solid polygon of any number of points, convex or concave. Unlike [method draw_colored_polygon], each point's color can be changed individually. The [param points] array is defined in local space. See also [method draw_polyline] and [method draw_polyline_colors]. If you need more flexibility (such as being able to use bones), use [method RenderingServer.canvas_item_add_triangle_array] instead.
[b]Note:[/b] If you frequently redraw the same polygon with a large number of vertices, consider pre-calculating the triangulation with [method Geometry2D.triangulate_polygon] and using [method draw_mesh], [method draw_multimesh], or [method RenderingServer.canvas_item_add_triangle_array].
[b]Note:[/b] Styleboxes, textures, and meshes stored only inside local variables should [b]not[/b] be used with this method in GDScript, because the drawing operation doesn't begin immediately once this method is called. In GDScript, when the function with the local variables ends, the local variables get destroyed before the rendering takes place.

### points :: PackedVector2Array

### colors :: PackedColorArray

### uvs :: PackedVector2Array

### texture :: Texture2D

## draw_polyline :: func CanvasItem.draw_polyline(points: PackedVector2Array, color: Color, width: float = -1.0, antialiased: bool = false) -> void
Draws interconnected line segments with a uniform [param color] and [param width] and optional antialiasing (supported only for positive [param width]). The [param points] array is defined in local space. When drawing large amounts of lines, this is faster than using individual [method draw_line] calls. To draw disconnected lines, use [method draw_multiline] instead. See also [method draw_polygon].
If [param width] is negative, it will be ignored and the polyline will be drawn using [constant RenderingServer.PRIMITIVE_LINE_STRIP]. This means that when the CanvasItem is scaled, the polyline will remain thin. If this behavior is not desired, then pass a positive [param width] like [code]1.0[/code].

### points :: PackedVector2Array

### color :: Color

### width :: float

### antialiased :: bool

## draw_polyline_colors :: func CanvasItem.draw_polyline_colors(points: PackedVector2Array, colors: PackedColorArray, width: float = -1.0, antialiased: bool = false) -> void
Draws interconnected line segments with a uniform [param width], point-by-point coloring, and optional antialiasing (supported only for positive [param width]). Colors assigned to line points match by index between [param points] and [param colors], i.e. each line segment is filled with a gradient between the colors of the endpoints. The [param points] array is defined in local space. When drawing large amounts of lines, this is faster than using individual [method draw_line] calls. To draw disconnected lines, use [method draw_multiline_colors] instead. See also [method draw_polygon].
If [param width] is negative, it will be ignored and the polyline will be drawn using [constant RenderingServer.PRIMITIVE_LINE_STRIP]. This means that when the CanvasItem is scaled, the polyline will remain thin. If this behavior is not desired, then pass a positive [param width] like [code]1.0[/code].

### points :: PackedVector2Array

### colors :: PackedColorArray

### width :: float

### antialiased :: bool

## draw_primitive :: func CanvasItem.draw_primitive(points: PackedVector2Array, colors: PackedColorArray, uvs: PackedVector2Array, texture: Texture2D = null) -> void
Draws a custom primitive. 1 point for a point, 2 points for a line, 3 points for a triangle, and 4 points for a quad. If 0 points or more than 4 points are specified, nothing will be drawn and an error message will be printed. The [param points] array is defined in local space. See also [method draw_line], [method draw_polyline], [method draw_polygon], and [method draw_rect].
[b]Note:[/b] Styleboxes, textures, and meshes stored only inside local variables should [b]not[/b] be used with this method in GDScript, because the drawing operation doesn't begin immediately once this method is called. In GDScript, when the function with the local variables ends, the local variables get destroyed before the rendering takes place.

### points :: PackedVector2Array

### colors :: PackedColorArray

### uvs :: PackedVector2Array

### texture :: Texture2D

## draw_rect :: func CanvasItem.draw_rect(rect: Rect2, color: Color, filled: bool = true, width: float = -1.0, antialiased: bool = false) -> void
Draws a rectangle. If [param filled] is [code]true[/code], the rectangle will be filled with the [param color] specified. If [param filled] is [code]false[/code], the rectangle will be drawn as a stroke with the [param color] and [param width] specified. The [param rect] is specified in local space. See also [method draw_texture_rect].
If [param width] is negative, then two-point primitives will be drawn instead of a four-point ones. This means that when the CanvasItem is scaled, the lines will remain thin. If this behavior is not desired, then pass a positive [param width] like [code]1.0[/code].
If [param antialiased] is [code]true[/code], half transparent "feathers" will be attached to the boundary, making outlines smooth.
[b]Note:[/b] [param width] is only effective if [param filled] is [code]false[/code].
[b]Note:[/b] Unfilled rectangles drawn with a negative [param width] may not display perfectly. For example, corners may be missing or brighter due to overlapping lines (for a translucent [param color]).

### rect :: Rect2

### color :: Color

### filled :: bool

### width :: float

### antialiased :: bool

## draw_set_transform :: func CanvasItem.draw_set_transform(position: Vector2, rotation: float = 0.0, scale: Vector2 = Vector2(1, 1)) -> void
Sets a custom local transform for drawing via components. Anything drawn afterwards will be transformed by this.
[b]Note:[/b] [member FontFile.oversampling] does [i]not[/i] take [param scale] into account. This means that scaling up/down will cause bitmap fonts and rasterized (non-MSDF) dynamic fonts to appear blurry or pixelated. To ensure text remains crisp regardless of scale, you can enable MSDF font rendering by enabling [member ProjectSettings.gui/theme/default_font_multichannel_signed_distance_field] (applies to the default project font only), or enabling [b]Multichannel Signed Distance Field[/b] in the import options of a DynamicFont for custom fonts. On system fonts, [member SystemFont.multichannel_signed_distance_field] can be enabled in the inspector.

### position :: Vector2

### rotation :: float

### scale :: Vector2

## draw_set_transform_matrix :: func CanvasItem.draw_set_transform_matrix(xform: Transform2D) -> void
Sets a custom local transform for drawing via matrix. Anything drawn afterwards will be transformed by this.

### xform :: Transform2D

## draw_string :: func CanvasItem.draw_string(font: Font, pos: Vector2, text: String, alignment: int = 0, width: float = -1, font_size: int = 16, modulate: Color = Color(1, 1, 1, 1), justification_flags: int = 3, direction: int = 0, orientation: int = 0, oversampling: float = 0.0) -> void
Draws [param text] using the specified [param font] at the [param pos] in local space (bottom-left corner using the baseline of the font). The text will have its color multiplied by [param modulate]. If [param width] is greater than or equal to 0, the text will be clipped if it exceeds the specified width. If [param oversampling] is greater than zero, it is used as font oversampling factor, otherwise viewport oversampling settings are used.
[b]Example:[/b] Draw "Hello world", using the project's default font:
[codeblocks]
[gdscript]
draw_string(ThemeDB.fallback_font, Vector2(64, 64), "Hello world", HORIZONTAL_ALIGNMENT_LEFT, -1, ThemeDB.fallback_font_size)
[/gdscript]
[csharp]
DrawString(ThemeDB.FallbackFont, new Vector2(64, 64), "Hello world", HorizontalAlignment.Left, -1, ThemeDB.FallbackFontSize);
[/csharp]
[/codeblocks]
See also [method Font.draw_string].

### font :: Font

### pos :: Vector2

### text :: String

### alignment :: int

### width :: float

### font_size :: int

### modulate :: Color

### justification_flags :: int

### direction :: int

### orientation :: int

### oversampling :: float

## draw_string_outline :: func CanvasItem.draw_string_outline(font: Font, pos: Vector2, text: String, alignment: int = 0, width: float = -1, font_size: int = 16, size: int = 1, modulate: Color = Color(1, 1, 1, 1), justification_flags: int = 3, direction: int = 0, orientation: int = 0, oversampling: float = 0.0) -> void
Draws [param text] outline using the specified [param font] at the [param pos] in local space (bottom-left corner using the baseline of the font). The text will have its color multiplied by [param modulate]. If [param width] is greater than or equal to 0, the text will be clipped if it exceeds the specified width. If [param oversampling] is greater than zero, it is used as font oversampling factor, otherwise viewport oversampling settings are used.

### font :: Font

### pos :: Vector2

### text :: String

### alignment :: int

### width :: float

### font_size :: int

### size :: int

### modulate :: Color

### justification_flags :: int

### direction :: int

### orientation :: int

### oversampling :: float

## draw_style_box :: func CanvasItem.draw_style_box(style_box: StyleBox, rect: Rect2) -> void
Draws a styled rectangle. The [param rect] is defined in local space.
[b]Note:[/b] Styleboxes, textures, and meshes stored only inside local variables should [b]not[/b] be used with this method in GDScript, because the drawing operation doesn't begin immediately once this method is called. In GDScript, when the function with the local variables ends, the local variables get destroyed before the rendering takes place.

### style_box :: StyleBox

### rect :: Rect2

## draw_texture :: func CanvasItem.draw_texture(texture: Texture2D, position: Vector2, modulate: Color = Color(1, 1, 1, 1)) -> void
Draws a texture at a given position. The [param position] is defined in local space.
[b]Note:[/b] Styleboxes, textures, and meshes stored only inside local variables should [b]not[/b] be used with this method in GDScript, because the drawing operation doesn't begin immediately once this method is called. In GDScript, when the function with the local variables ends, the local variables get destroyed before the rendering takes place.

### texture :: Texture2D

### position :: Vector2

### modulate :: Color

## draw_texture_rect :: func CanvasItem.draw_texture_rect(texture: Texture2D, rect: Rect2, tile: bool, modulate: Color = Color(1, 1, 1, 1), transpose: bool = false) -> void
Draws a textured rectangle at a given position, optionally modulated by a color. The [param rect] is defined in local space. If [param transpose] is [code]true[/code], the texture will have its X and Y coordinates swapped. See also [method draw_rect] and [method draw_texture_rect_region].
[b]Note:[/b] Styleboxes, textures, and meshes stored only inside local variables should [b]not[/b] be used with this method in GDScript, because the drawing operation doesn't begin immediately once this method is called. In GDScript, when the function with the local variables ends, the local variables get destroyed before the rendering takes place.

### texture :: Texture2D

### rect :: Rect2

### tile :: bool

### modulate :: Color

### transpose :: bool

## draw_texture_rect_region :: func CanvasItem.draw_texture_rect_region(texture: Texture2D, rect: Rect2, src_rect: Rect2, modulate: Color = Color(1, 1, 1, 1), transpose: bool = false, clip_uv: bool = true) -> void
Draws a textured rectangle from a texture's region (specified by [param src_rect]) at a given position in local space, optionally modulated by a color. If [param transpose] is [code]true[/code], the texture will have its X and Y coordinates swapped. See also [method draw_texture_rect].
[b]Note:[/b] Styleboxes, textures, and meshes stored only inside local variables should [b]not[/b] be used with this method in GDScript, because the drawing operation doesn't begin immediately once this method is called. In GDScript, when the function with the local variables ends, the local variables get destroyed before the rendering takes place.

### texture :: Texture2D

### rect :: Rect2

### src_rect :: Rect2

### modulate :: Color

### transpose :: bool

### clip_uv :: bool

## force_update_transform :: func CanvasItem.force_update_transform() -> void
Forces the node's transform to update. Fails if the node is not inside the tree. See also [method get_transform].
[b]Note:[/b] For performance reasons, transform changes are usually accumulated and applied [i]once[/i] at the end of the frame. The update propagates through [CanvasItem] children, as well. Therefore, use this method only when you need an up-to-date transform (such as during physics operations).

## get_canvas :: func CanvasItem.get_canvas() -> RID
Returns the [RID] of the [World2D] canvas where this node is registered to, used by the [RenderingServer].

## get_canvas_item :: func CanvasItem.get_canvas_item() -> RID
Returns the internal canvas item [RID] used by the [RenderingServer] for this node.

## get_canvas_layer_node :: func CanvasItem.get_canvas_layer_node() -> CanvasLayer
Returns the [CanvasLayer] that contains this node, or [code]null[/code] if the node is not in any [CanvasLayer].

## get_canvas_transform :: func CanvasItem.get_canvas_transform() -> Transform2D
Returns the transform of this node, converted from its registered canvas's coordinate system to its viewport's coordinate system. See also [method Node.get_viewport].

## get_global_mouse_position :: func CanvasItem.get_global_mouse_position() -> Vector2
Returns mouse cursor's global position relative to the [CanvasLayer] that contains this node.
[b]Note:[/b] For screen-space coordinates (e.g. when using a non-embedded [Popup]), you can use [method DisplayServer.mouse_get_position].

## get_global_transform :: func CanvasItem.get_global_transform() -> Transform2D
Returns the global transform matrix of this item, i.e. the combined transform up to the topmost [CanvasItem] node. The topmost item is a [CanvasItem] that either has no parent, has non-[CanvasItem] parent or it has [member top_level] enabled.

## get_global_transform_with_canvas :: func CanvasItem.get_global_transform_with_canvas() -> Transform2D
Returns the transform from the local coordinate system of this [CanvasItem] to the [Viewport]s coordinate system.

## get_instance_shader_parameter :: func CanvasItem.get_instance_shader_parameter(name: StringName) -> Variant
Get the value of a shader parameter as set on this instance.

### name :: StringName

## get_local_mouse_position :: func CanvasItem.get_local_mouse_position() -> Vector2
Returns the mouse's position in this [CanvasItem] using the local coordinate system of this [CanvasItem].

## get_screen_transform :: func CanvasItem.get_screen_transform() -> Transform2D
Returns the transform of this [CanvasItem] in global screen coordinates (i.e. taking window position into account). Mostly useful for editor plugins.
Equivalent to [method get_global_transform_with_canvas] if the window is embedded (see [member Viewport.gui_embed_subwindows]).

## get_transform :: func CanvasItem.get_transform() -> Transform2D
Returns the transform matrix of this [CanvasItem].

## get_viewport_rect :: func CanvasItem.get_viewport_rect() -> Rect2
Returns this node's viewport boundaries as a [Rect2]. See also [method Node.get_viewport].

## get_viewport_transform :: func CanvasItem.get_viewport_transform() -> Transform2D
Returns the transform of this node, converted from its registered canvas's coordinate system to its viewport embedder's coordinate system. See also [method Viewport.get_final_transform] and [method Node.get_viewport].

## get_visibility_layer_bit :: func CanvasItem.get_visibility_layer_bit(layer: int) -> bool
Returns [code]true[/code] if the layer at the given index is set in [member visibility_layer].

### layer :: int

## get_world_2d :: func CanvasItem.get_world_2d() -> World2D
Returns the [World2D] this node is registered to.
Usually, this is the same as this node's viewport (see [method Node.get_viewport] and [method Viewport.find_world_2d]).

## hide :: func CanvasItem.hide() -> void
Hide the [CanvasItem] if it's currently visible. This is equivalent to setting [member visible] to [code]false[/code].

## is_local_transform_notification_enabled :: func CanvasItem.is_local_transform_notification_enabled() -> bool
Returns [code]true[/code] if the node receives [constant NOTIFICATION_LOCAL_TRANSFORM_CHANGED] whenever its local transform changes. This is enabled with [method set_notify_local_transform].

## is_transform_notification_enabled :: func CanvasItem.is_transform_notification_enabled() -> bool
Returns [code]true[/code] if the node receives [constant NOTIFICATION_TRANSFORM_CHANGED] whenever its global transform changes. This is enabled with [method set_notify_transform].

## is_visible_in_tree :: func CanvasItem.is_visible_in_tree() -> bool
Returns [code]true[/code] if the node is present in the [SceneTree], its [member visible] property is [code]true[/code] and all its ancestors are also visible. If any ancestor is hidden, this node will not be visible in the scene tree, and is therefore not drawn (see [method _draw]).
Visibility is checked only in parent nodes that inherit from [CanvasItem], [CanvasLayer], and [Window]. If the parent is of any other type (such as [Node], [AnimationPlayer], or [Node3D]), it is assumed to be visible.
[b]Note:[/b] This method does not take [member visibility_layer] into account, so even if this method returns [code]true[/code], the node might end up not being rendered.

## make_canvas_position_local :: func CanvasItem.make_canvas_position_local(viewport_point: Vector2) -> Vector2
Transforms [param viewport_point] from the viewport's coordinates to this node's local coordinates.
For the opposite operation, use [method get_global_transform_with_canvas].
[codeblock]
var viewport_point = get_global_transform_with_canvas() * local_point
[/codeblock]

### viewport_point :: Vector2

## make_input_local :: func CanvasItem.make_input_local(event: InputEvent) -> InputEvent
Returns a copy of the given [param event] with its coordinates converted from global space to this [CanvasItem]'s local space. If not possible, returns the same [InputEvent] unchanged.

### event :: InputEvent

## move_to_front :: func CanvasItem.move_to_front() -> void
Moves this node below its siblings, usually causing the node to draw on top of its siblings. Does nothing if this node does not have a parent. See also [method Node.move_child].

## queue_redraw :: func CanvasItem.queue_redraw() -> void
Queues the [CanvasItem] to redraw. During idle time, if [CanvasItem] is visible, [constant NOTIFICATION_DRAW] is sent and [method _draw] is called. This only occurs [b]once[/b] per frame, even if this method has been called multiple times.

## set_instance_shader_parameter :: func CanvasItem.set_instance_shader_parameter(name: StringName, value: Variant) -> void
Set the value of a shader uniform for this instance only ([url=https://docs.godotengine.org/en/4.7/tutorials/shaders/shader_reference/shading_language.html#per-instance-uniforms]per-instance uniform[/url]). See also [method ShaderMaterial.set_shader_parameter] to assign a uniform on all instances using the same [ShaderMaterial].
[b]Note:[/b] For a shader uniform to be assignable on a per-instance basis, it [i]must[/i] be defined with [code]instance uniform ...[/code] rather than [code]uniform ...[/code] in the shader code.
[b]Note:[/b] [param name] is case-sensitive and must match the name of the uniform in the code exactly (not the capitalized name in the inspector).

### name :: StringName

### value :: Variant

## set_notify_local_transform :: func CanvasItem.set_notify_local_transform(enable: bool) -> void
If [code]true[/code], the node will receive [constant NOTIFICATION_LOCAL_TRANSFORM_CHANGED] whenever its local transform changes.
[b]Note:[/b] Many canvas items such as [Bone2D] or [CollisionShape2D] automatically enable this in order to function correctly.

### enable :: bool

## set_notify_transform :: func CanvasItem.set_notify_transform(enable: bool) -> void
If [code]true[/code], the node will receive [constant NOTIFICATION_TRANSFORM_CHANGED] whenever its global transform changes.
[b]Note:[/b] Many canvas items such as [Camera2D] or [Light2D] automatically enable this in order to function correctly.

### enable :: bool

## set_visibility_layer_bit :: func CanvasItem.set_visibility_layer_bit(layer: int, enabled: bool) -> void
Set/clear individual bits on the rendering visibility layer. This simplifies editing this [CanvasItem]'s visibility layer.

### layer :: int

### enabled :: bool

## show :: func CanvasItem.show() -> void
Show the [CanvasItem] if it's currently hidden. This is equivalent to setting [member visible] to [code]true[/code].
[b]Note:[/b] For controls that inherit [Popup], the correct way to make them visible is to call one of the multiple [code]popup*()[/code] functions instead.

## draw :: func CanvasItem.draw() -> void
Emitted when the [CanvasItem] must redraw, [i]after[/i] the related [constant NOTIFICATION_DRAW] notification, and [i]before[/i] [method _draw] is called.
[b]Note:[/b] Deferred connections do not allow drawing through the [code]draw_*[/code] methods.

## hidden :: func CanvasItem.hidden() -> void
Emitted when this node becomes hidden, i.e. it's no longer visible in the tree (see [method is_visible_in_tree]).

## item_rect_changed :: func CanvasItem.item_rect_changed() -> void
Emitted when the [CanvasItem]'s boundaries (position or size) change, or when an action took place that may have affected these boundaries (e.g. changing [member Sprite2D.texture]).

## visibility_changed :: func CanvasItem.visibility_changed() -> void
Emitted when the [CanvasItem]'s visibility changes, either because its own [member visible] property changed or because its visibility in the tree changed (see [method is_visible_in_tree]).
This signal is emitted [i]after[/i] the related [constant NOTIFICATION_VISIBILITY_CHANGED] notification.
