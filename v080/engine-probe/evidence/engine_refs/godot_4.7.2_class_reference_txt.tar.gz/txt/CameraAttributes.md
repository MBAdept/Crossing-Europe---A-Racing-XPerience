# CameraAttributes :: <Native> class CameraAttributes extends Resource
Parent class for camera settings.
Controls camera-specific attributes such as depth of field and exposure override.
When used in a [WorldEnvironment] it provides default settings for exposure, auto-exposure, and depth of field that will be used by all cameras without their own [CameraAttributes], including the editor camera. When used in a [Camera3D] it will override any [CameraAttributes] set in the [WorldEnvironment]. When used in [VoxelGI] or [LightmapGI], only the exposure settings will be used.
See also [Environment] for general 3D environment settings.
This is a pure virtual class that is inherited by [CameraAttributesPhysical] and [CameraAttributesPractical].

## auto_exposure_enabled :: var CameraAttributes.auto_exposure_enabled: bool
If [code]true[/code], enables the tonemapping auto exposure mode of the scene renderer. If [code]true[/code], the renderer will automatically determine the exposure setting to adapt to the scene's illumination and the observed light.
[b]Note:[/b] Auto-exposure is only supported in the Forward+ rendering method, not Mobile or Compatibility.

## auto_exposure_scale :: var CameraAttributes.auto_exposure_scale: float
The scale of the auto exposure effect. Affects the intensity of auto exposure.

## auto_exposure_speed :: var CameraAttributes.auto_exposure_speed: float
The speed of the auto exposure effect. Affects the time needed for the camera to perform auto exposure.

## exposure_multiplier :: var CameraAttributes.exposure_multiplier: float
Multiplier for the exposure amount. A higher value results in a brighter image.

## exposure_sensitivity :: var CameraAttributes.exposure_sensitivity: float
Sensitivity of camera sensors, measured in ISO. A higher sensitivity results in a brighter image.
If [member auto_exposure_enabled] is [code]true[/code], this can be used as a method of exposure compensation, doubling the value will increase the exposure value (measured in EV100) by 1 stop.
[b]Note:[/b] Only available when [member ProjectSettings.rendering/lights_and_shadows/use_physical_light_units] is enabled.
