# ImageFormatLoaderExtension :: <Native> class ImageFormatLoaderExtension extends ImageFormatLoader
Base class for creating [ImageFormatLoader] extensions (adding support for extra image formats).
The engine supports multiple image formats out of the box (PNG, SVG, JPEG, WebP to name a few), but you can choose to implement support for additional image formats by extending this class.
Be sure to respect the documented return types and values. You should create an instance of it, and call [method add_format_loader] to register that loader during the initialization phase.

## _get_recognized_extensions :: func ImageFormatLoaderExtension._get_recognized_extensions() -> PackedStringArray
Returns the list of file extensions for this image format. Files with the given extensions will be treated as image file and loaded using this class.

## _load_image :: func ImageFormatLoaderExtension._load_image(image: Image, fileaccess: FileAccess, flags: int, scale: float) -> int
Loads the content of [param fileaccess] into the provided [param image].

### image :: Image

### fileaccess :: FileAccess

### flags :: int

### scale :: float

## add_format_loader :: func ImageFormatLoaderExtension.add_format_loader() -> void
Add this format loader to the engine, allowing it to recognize the file extensions returned by [method _get_recognized_extensions].

## remove_format_loader :: func ImageFormatLoaderExtension.remove_format_loader() -> void
Remove this format loader from the engine.
