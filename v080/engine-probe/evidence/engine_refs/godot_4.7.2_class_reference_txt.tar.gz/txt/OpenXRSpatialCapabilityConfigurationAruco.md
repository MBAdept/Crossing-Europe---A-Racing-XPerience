# OpenXRSpatialCapabilityConfigurationAruco :: <Native> class OpenXRSpatialCapabilityConfigurationAruco extends OpenXRSpatialCapabilityConfigurationBaseHeader
Configuration header for Aruco markers.
Configuration header for Aruco markers. Pass this to [method OpenXRSpatialEntityExtension.create_spatial_context] to create a spatial context that can detect Aruco markers.

## ARUCO_DICT_4X4_50 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_4X4_50: ArucoDict = 1
4 by 4 pixel Aruco marker dictionary with 50 IDs.

## ARUCO_DICT_4X4_100 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_4X4_100: ArucoDict = 2
4 by 4 pixel Aruco marker dictionary with 100 IDs.

## ARUCO_DICT_4X4_250 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_4X4_250: ArucoDict = 3
4 by 4 pixel Aruco marker dictionary with 250 IDs.

## ARUCO_DICT_4X4_1000 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_4X4_1000: ArucoDict = 4
4 by 4 pixel Aruco marker dictionary with 1000 IDs.

## ARUCO_DICT_5X5_50 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_5X5_50: ArucoDict = 5
5 by 5 pixel Aruco marker dictionary with 50 IDs.

## ARUCO_DICT_5X5_100 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_5X5_100: ArucoDict = 6
5 by 5 pixel Aruco marker dictionary with 100 IDs.

## ARUCO_DICT_5X5_250 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_5X5_250: ArucoDict = 7
5 by 5 pixel Aruco marker dictionary with 250 IDs.

## ARUCO_DICT_5X5_1000 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_5X5_1000: ArucoDict = 8
5 by 5 pixel Aruco marker dictionary with 1000 IDs.

## ARUCO_DICT_6X6_50 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_6X6_50: ArucoDict = 9
6 by 6 pixel Aruco marker dictionary with 50 IDs.

## ARUCO_DICT_6X6_100 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_6X6_100: ArucoDict = 10
6 by 6 pixel Aruco marker dictionary with 100 IDs.

## ARUCO_DICT_6X6_250 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_6X6_250: ArucoDict = 11
6 by 6 pixel Aruco marker dictionary with 250 IDs.

## ARUCO_DICT_6X6_1000 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_6X6_1000: ArucoDict = 12
6 by 6 pixel Aruco marker dictionary with 1000 IDs.

## ARUCO_DICT_7X7_50 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_7X7_50: ArucoDict = 13
7 by 7 pixel Aruco marker dictionary with 50 IDs.

## ARUCO_DICT_7X7_100 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_7X7_100: ArucoDict = 14
7 by 7 pixel Aruco marker dictionary with 100 IDs.

## ARUCO_DICT_7X7_250 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_7X7_250: ArucoDict = 15
7 by 7 pixel Aruco marker dictionary with 250 IDs.

## ARUCO_DICT_7X7_1000 :: const OpenXRSpatialCapabilityConfigurationAruco.ARUCO_DICT_7X7_1000: ArucoDict = 16
7 by 7 pixel Aruco marker dictionary with 1000 IDs.

## aruco_dict :: var OpenXRSpatialCapabilityConfigurationAruco.aruco_dict: OpenXRSpatialCapabilityConfigurationAruco.ArucoDict
Dictionary to use to decode Aruco markers.
[b]Note:[/b] Must be set before using this configuration to create a spatial context.

## get_enabled_components :: func OpenXRSpatialCapabilityConfigurationAruco.get_enabled_components() -> PackedInt64Array
Returns the components enabled by this configuration.
[b]Note:[/b] Only valid after this configuration was used to create a spatial context.
