# PhysicsServer3D :: <Native> class PhysicsServer3D extends Object
A server interface for low-level 3D physics access.
PhysicsServer3D is the server responsible for all 3D physics. It can directly create and manipulate all physics objects:
- A [i]space[/i] is a self-contained world for a physics simulation. It contains bodies, areas, and joints. Its state can be queried for collision and intersection information, and several parameters of the simulation can be modified.
- A [i]shape[/i] is a geometric shape such as a sphere, a box, a cylinder, or a polygon. It can be used for collision detection by adding it to a body/area, possibly with an extra transformation relative to the body/area's origin. Bodies/areas can have multiple (transformed) shapes added to them, and a single shape can be added to bodies/areas multiple times with different local transformations.
- A [i]body[/i] is a physical object which can be in static, kinematic, or rigid mode. Its state (such as position and velocity) can be queried and updated. A force integration callback can be set to customize the body's physics.
- An [i]area[/i] is a region in space which can be used to detect bodies and areas entering and exiting it. A body monitoring callback can be set to report entering/exiting body shapes, and similarly an area monitoring callback can be set. Gravity and damping can be overridden within the area by setting area parameters.
- A [i]joint[/i] is a constraint, either between two bodies or on one body relative to a point. Parameters such as the joint bias and the rest length of a spring joint can be adjusted.
Physics objects in [PhysicsServer3D] may be created and manipulated independently; they do not have to be tied to nodes in the scene tree.
[b]Note:[/b] All the 3D physics nodes use the physics server internally. Adding a physics node to the scene tree will cause a corresponding physics object to be created in the physics server. A rigid body node registers a callback that updates the node's transform with the transform of the respective body object in the physics server (every physics update). An area node registers a callback to inform the area node about overlaps with the respective area object in the physics server. The raycast node queries the direct state of the relevant space in the physics server.

## JOINT_TYPE_PIN :: const PhysicsServer3D.JOINT_TYPE_PIN: JointType = 0
The [Joint3D] is a [PinJoint3D].

## JOINT_TYPE_HINGE :: const PhysicsServer3D.JOINT_TYPE_HINGE: JointType = 1
The [Joint3D] is a [HingeJoint3D].

## JOINT_TYPE_SLIDER :: const PhysicsServer3D.JOINT_TYPE_SLIDER: JointType = 2
The [Joint3D] is a [SliderJoint3D].

## JOINT_TYPE_CONE_TWIST :: const PhysicsServer3D.JOINT_TYPE_CONE_TWIST: JointType = 3
The [Joint3D] is a [ConeTwistJoint3D].

## JOINT_TYPE_6DOF :: const PhysicsServer3D.JOINT_TYPE_6DOF: JointType = 4
The [Joint3D] is a [Generic6DOFJoint3D].

## JOINT_TYPE_MAX :: const PhysicsServer3D.JOINT_TYPE_MAX: JointType = 5
Represents the size of the [enum JointType] enum.

## PIN_JOINT_BIAS :: const PhysicsServer3D.PIN_JOINT_BIAS: PinJointParam = 0
The strength with which the pinned objects try to stay in positional relation to each other. The higher, the stronger.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## PIN_JOINT_DAMPING :: const PhysicsServer3D.PIN_JOINT_DAMPING: PinJointParam = 1
The strength with which the pinned objects try to stay in velocity relation to each other. The higher, the stronger.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## PIN_JOINT_IMPULSE_CLAMP :: const PhysicsServer3D.PIN_JOINT_IMPULSE_CLAMP: PinJointParam = 2
If above 0, this value is the maximum value for an impulse that this Joint3D puts on its ends.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## HINGE_JOINT_BIAS :: const PhysicsServer3D.HINGE_JOINT_BIAS: HingeJointParam = 0
The speed with which the two bodies get pulled together when they move in different directions.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## HINGE_JOINT_LIMIT_UPPER :: const PhysicsServer3D.HINGE_JOINT_LIMIT_UPPER: HingeJointParam = 1
The maximum rotation across the Hinge.

## HINGE_JOINT_LIMIT_LOWER :: const PhysicsServer3D.HINGE_JOINT_LIMIT_LOWER: HingeJointParam = 2
The minimum rotation across the Hinge.

## HINGE_JOINT_LIMIT_BIAS :: const PhysicsServer3D.HINGE_JOINT_LIMIT_BIAS: HingeJointParam = 3
The speed with which the rotation across the axis perpendicular to the hinge gets corrected.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## HINGE_JOINT_LIMIT_SOFTNESS :: const PhysicsServer3D.HINGE_JOINT_LIMIT_SOFTNESS: HingeJointParam = 4
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## HINGE_JOINT_LIMIT_RELAXATION :: const PhysicsServer3D.HINGE_JOINT_LIMIT_RELAXATION: HingeJointParam = 5
The lower this value, the more the rotation gets slowed down.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## HINGE_JOINT_MOTOR_TARGET_VELOCITY :: const PhysicsServer3D.HINGE_JOINT_MOTOR_TARGET_VELOCITY: HingeJointParam = 6
Target speed for the motor.

## HINGE_JOINT_MOTOR_MAX_IMPULSE :: const PhysicsServer3D.HINGE_JOINT_MOTOR_MAX_IMPULSE: HingeJointParam = 7
Maximum acceleration for the motor.

## HINGE_JOINT_FLAG_USE_LIMIT :: const PhysicsServer3D.HINGE_JOINT_FLAG_USE_LIMIT: HingeJointFlag = 0
If [code]true[/code], the Hinge has a maximum and a minimum rotation.

## HINGE_JOINT_FLAG_ENABLE_MOTOR :: const PhysicsServer3D.HINGE_JOINT_FLAG_ENABLE_MOTOR: HingeJointFlag = 1
If [code]true[/code], a motor turns the Hinge.

## SLIDER_JOINT_LINEAR_LIMIT_UPPER :: const PhysicsServer3D.SLIDER_JOINT_LINEAR_LIMIT_UPPER: SliderJointParam = 0
The maximum difference between the pivot points on their X axis before damping happens.

## SLIDER_JOINT_LINEAR_LIMIT_LOWER :: const PhysicsServer3D.SLIDER_JOINT_LINEAR_LIMIT_LOWER: SliderJointParam = 1
The minimum difference between the pivot points on their X axis before damping happens.

## SLIDER_JOINT_LINEAR_LIMIT_SOFTNESS :: const PhysicsServer3D.SLIDER_JOINT_LINEAR_LIMIT_SOFTNESS: SliderJointParam = 2
A factor applied to the movement across the slider axis once the limits get surpassed. The lower, the slower the movement.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_LINEAR_LIMIT_RESTITUTION :: const PhysicsServer3D.SLIDER_JOINT_LINEAR_LIMIT_RESTITUTION: SliderJointParam = 3
The amount of restitution once the limits are surpassed. The lower, the more velocity-energy gets lost.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_LINEAR_LIMIT_DAMPING :: const PhysicsServer3D.SLIDER_JOINT_LINEAR_LIMIT_DAMPING: SliderJointParam = 4
The amount of damping once the slider limits are surpassed.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_LINEAR_MOTION_SOFTNESS :: const PhysicsServer3D.SLIDER_JOINT_LINEAR_MOTION_SOFTNESS: SliderJointParam = 5
A factor applied to the movement across the slider axis as long as the slider is in the limits. The lower, the slower the movement.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_LINEAR_MOTION_RESTITUTION :: const PhysicsServer3D.SLIDER_JOINT_LINEAR_MOTION_RESTITUTION: SliderJointParam = 6
The amount of restitution inside the slider limits.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_LINEAR_MOTION_DAMPING :: const PhysicsServer3D.SLIDER_JOINT_LINEAR_MOTION_DAMPING: SliderJointParam = 7
The amount of damping inside the slider limits.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_LINEAR_ORTHOGONAL_SOFTNESS :: const PhysicsServer3D.SLIDER_JOINT_LINEAR_ORTHOGONAL_SOFTNESS: SliderJointParam = 8
A factor applied to the movement across axes orthogonal to the slider.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_LINEAR_ORTHOGONAL_RESTITUTION :: const PhysicsServer3D.SLIDER_JOINT_LINEAR_ORTHOGONAL_RESTITUTION: SliderJointParam = 9
The amount of restitution when movement is across axes orthogonal to the slider.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_LINEAR_ORTHOGONAL_DAMPING :: const PhysicsServer3D.SLIDER_JOINT_LINEAR_ORTHOGONAL_DAMPING: SliderJointParam = 10
The amount of damping when movement is across axes orthogonal to the slider.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_ANGULAR_LIMIT_UPPER :: const PhysicsServer3D.SLIDER_JOINT_ANGULAR_LIMIT_UPPER: SliderJointParam = 11
The upper limit of rotation in the slider.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_ANGULAR_LIMIT_LOWER :: const PhysicsServer3D.SLIDER_JOINT_ANGULAR_LIMIT_LOWER: SliderJointParam = 12
The lower limit of rotation in the slider.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_ANGULAR_LIMIT_SOFTNESS :: const PhysicsServer3D.SLIDER_JOINT_ANGULAR_LIMIT_SOFTNESS: SliderJointParam = 13
A factor applied to the all rotation once the limit is surpassed.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_ANGULAR_LIMIT_RESTITUTION :: const PhysicsServer3D.SLIDER_JOINT_ANGULAR_LIMIT_RESTITUTION: SliderJointParam = 14
The amount of restitution of the rotation when the limit is surpassed.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_ANGULAR_LIMIT_DAMPING :: const PhysicsServer3D.SLIDER_JOINT_ANGULAR_LIMIT_DAMPING: SliderJointParam = 15
The amount of damping of the rotation when the limit is surpassed.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_ANGULAR_MOTION_SOFTNESS :: const PhysicsServer3D.SLIDER_JOINT_ANGULAR_MOTION_SOFTNESS: SliderJointParam = 16
A factor that gets applied to the all rotation in the limits.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_ANGULAR_MOTION_RESTITUTION :: const PhysicsServer3D.SLIDER_JOINT_ANGULAR_MOTION_RESTITUTION: SliderJointParam = 17
The amount of restitution of the rotation in the limits.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_ANGULAR_MOTION_DAMPING :: const PhysicsServer3D.SLIDER_JOINT_ANGULAR_MOTION_DAMPING: SliderJointParam = 18
The amount of damping of the rotation in the limits.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_ANGULAR_ORTHOGONAL_SOFTNESS :: const PhysicsServer3D.SLIDER_JOINT_ANGULAR_ORTHOGONAL_SOFTNESS: SliderJointParam = 19
A factor that gets applied to the all rotation across axes orthogonal to the slider.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_ANGULAR_ORTHOGONAL_RESTITUTION :: const PhysicsServer3D.SLIDER_JOINT_ANGULAR_ORTHOGONAL_RESTITUTION: SliderJointParam = 20
The amount of restitution of the rotation across axes orthogonal to the slider.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_ANGULAR_ORTHOGONAL_DAMPING :: const PhysicsServer3D.SLIDER_JOINT_ANGULAR_ORTHOGONAL_DAMPING: SliderJointParam = 21
The amount of damping of the rotation across axes orthogonal to the slider.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SLIDER_JOINT_MAX :: const PhysicsServer3D.SLIDER_JOINT_MAX: SliderJointParam = 22
Represents the size of the [enum SliderJointParam] enum.

## CONE_TWIST_JOINT_SWING_SPAN :: const PhysicsServer3D.CONE_TWIST_JOINT_SWING_SPAN: ConeTwistJointParam = 0
Swing is rotation from side to side, around the axis perpendicular to the twist axis.
The swing span defines, how much rotation will not get corrected along the swing axis.
Could be defined as looseness in the [ConeTwistJoint3D]. If below 0.05, this behavior is locked.

## CONE_TWIST_JOINT_TWIST_SPAN :: const PhysicsServer3D.CONE_TWIST_JOINT_TWIST_SPAN: ConeTwistJointParam = 1
Twist is the rotation around the twist axis, this value defined how far the joint can twist. Twist is locked if below 0.05.

## CONE_TWIST_JOINT_BIAS :: const PhysicsServer3D.CONE_TWIST_JOINT_BIAS: ConeTwistJointParam = 2
The speed with which the swing or twist will take place. The higher, the faster.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## CONE_TWIST_JOINT_SOFTNESS :: const PhysicsServer3D.CONE_TWIST_JOINT_SOFTNESS: ConeTwistJointParam = 3
The ease with which the Joint3D twists, if it's too low, it takes more force to twist the joint.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## CONE_TWIST_JOINT_RELAXATION :: const PhysicsServer3D.CONE_TWIST_JOINT_RELAXATION: ConeTwistJointParam = 4
Defines, how fast the swing- and twist-speed-difference on both sides gets synced.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## G6DOF_JOINT_LINEAR_LOWER_LIMIT :: const PhysicsServer3D.G6DOF_JOINT_LINEAR_LOWER_LIMIT: G6DOFJointAxisParam = 0
The minimum difference between the pivot points' axes.

## G6DOF_JOINT_LINEAR_UPPER_LIMIT :: const PhysicsServer3D.G6DOF_JOINT_LINEAR_UPPER_LIMIT: G6DOFJointAxisParam = 1
The maximum difference between the pivot points' axes.

## G6DOF_JOINT_LINEAR_LIMIT_SOFTNESS :: const PhysicsServer3D.G6DOF_JOINT_LINEAR_LIMIT_SOFTNESS: G6DOFJointAxisParam = 2
A factor that gets applied to the movement across the axes. The lower, the slower the movement.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## G6DOF_JOINT_LINEAR_RESTITUTION :: const PhysicsServer3D.G6DOF_JOINT_LINEAR_RESTITUTION: G6DOFJointAxisParam = 3
The amount of restitution on the axes movement. The lower, the more velocity-energy gets lost.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## G6DOF_JOINT_LINEAR_DAMPING :: const PhysicsServer3D.G6DOF_JOINT_LINEAR_DAMPING: G6DOFJointAxisParam = 4
The amount of damping that happens at the linear motion across the axes.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## G6DOF_JOINT_LINEAR_MOTOR_TARGET_VELOCITY :: const PhysicsServer3D.G6DOF_JOINT_LINEAR_MOTOR_TARGET_VELOCITY: G6DOFJointAxisParam = 5
The velocity that the joint's linear motor will attempt to reach.

## G6DOF_JOINT_LINEAR_MOTOR_FORCE_LIMIT :: const PhysicsServer3D.G6DOF_JOINT_LINEAR_MOTOR_FORCE_LIMIT: G6DOFJointAxisParam = 6
The maximum force that the linear motor can apply while trying to reach the target velocity.

## G6DOF_JOINT_LINEAR_SPRING_STIFFNESS :: const PhysicsServer3D.G6DOF_JOINT_LINEAR_SPRING_STIFFNESS: G6DOFJointAxisParam = 7

## G6DOF_JOINT_LINEAR_SPRING_DAMPING :: const PhysicsServer3D.G6DOF_JOINT_LINEAR_SPRING_DAMPING: G6DOFJointAxisParam = 8

## G6DOF_JOINT_LINEAR_SPRING_EQUILIBRIUM_POINT :: const PhysicsServer3D.G6DOF_JOINT_LINEAR_SPRING_EQUILIBRIUM_POINT: G6DOFJointAxisParam = 9

## G6DOF_JOINT_ANGULAR_LOWER_LIMIT :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_LOWER_LIMIT: G6DOFJointAxisParam = 10
The minimum rotation in negative direction to break loose and rotate around the axes.

## G6DOF_JOINT_ANGULAR_UPPER_LIMIT :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_UPPER_LIMIT: G6DOFJointAxisParam = 11
The minimum rotation in positive direction to break loose and rotate around the axes.

## G6DOF_JOINT_ANGULAR_LIMIT_SOFTNESS :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_LIMIT_SOFTNESS: G6DOFJointAxisParam = 12
A factor that gets multiplied onto all rotations across the axes.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## G6DOF_JOINT_ANGULAR_DAMPING :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_DAMPING: G6DOFJointAxisParam = 13
The amount of rotational damping across the axes. The lower, the more damping occurs.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## G6DOF_JOINT_ANGULAR_RESTITUTION :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_RESTITUTION: G6DOFJointAxisParam = 14
The amount of rotational restitution across the axes. The lower, the more restitution occurs.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## G6DOF_JOINT_ANGULAR_FORCE_LIMIT :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_FORCE_LIMIT: G6DOFJointAxisParam = 15
The maximum amount of force that can occur, when rotating around the axes.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## G6DOF_JOINT_ANGULAR_ERP :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_ERP: G6DOFJointAxisParam = 16
When correcting the crossing of limits in rotation across the axes, this error tolerance factor defines how much the correction gets slowed down. The lower, the slower.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## G6DOF_JOINT_ANGULAR_MOTOR_TARGET_VELOCITY :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_MOTOR_TARGET_VELOCITY: G6DOFJointAxisParam = 17
Target speed for the motor at the axes.

## G6DOF_JOINT_ANGULAR_MOTOR_FORCE_LIMIT :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_MOTOR_FORCE_LIMIT: G6DOFJointAxisParam = 18
Maximum acceleration for the motor at the axes.

## G6DOF_JOINT_ANGULAR_SPRING_STIFFNESS :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_SPRING_STIFFNESS: G6DOFJointAxisParam = 19

## G6DOF_JOINT_ANGULAR_SPRING_DAMPING :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_SPRING_DAMPING: G6DOFJointAxisParam = 20

## G6DOF_JOINT_ANGULAR_SPRING_EQUILIBRIUM_POINT :: const PhysicsServer3D.G6DOF_JOINT_ANGULAR_SPRING_EQUILIBRIUM_POINT: G6DOFJointAxisParam = 21

## G6DOF_JOINT_MAX :: const PhysicsServer3D.G6DOF_JOINT_MAX: G6DOFJointAxisParam = 22
Represents the size of the [enum G6DOFJointAxisParam] enum.

## G6DOF_JOINT_FLAG_ENABLE_LINEAR_LIMIT :: const PhysicsServer3D.G6DOF_JOINT_FLAG_ENABLE_LINEAR_LIMIT: G6DOFJointAxisFlag = 0
If set, linear motion is possible within the given limits.

## G6DOF_JOINT_FLAG_ENABLE_ANGULAR_LIMIT :: const PhysicsServer3D.G6DOF_JOINT_FLAG_ENABLE_ANGULAR_LIMIT: G6DOFJointAxisFlag = 1
If set, rotational motion is possible.

## G6DOF_JOINT_FLAG_ENABLE_ANGULAR_SPRING :: const PhysicsServer3D.G6DOF_JOINT_FLAG_ENABLE_ANGULAR_SPRING: G6DOFJointAxisFlag = 2

## G6DOF_JOINT_FLAG_ENABLE_LINEAR_SPRING :: const PhysicsServer3D.G6DOF_JOINT_FLAG_ENABLE_LINEAR_SPRING: G6DOFJointAxisFlag = 3

## G6DOF_JOINT_FLAG_ENABLE_MOTOR :: const PhysicsServer3D.G6DOF_JOINT_FLAG_ENABLE_MOTOR: G6DOFJointAxisFlag = 4
If set, there is a rotational motor across these axes.

## G6DOF_JOINT_FLAG_ENABLE_LINEAR_MOTOR :: const PhysicsServer3D.G6DOF_JOINT_FLAG_ENABLE_LINEAR_MOTOR: G6DOFJointAxisFlag = 5
If set, there is a linear motor on this axis that targets a specific velocity.

## G6DOF_JOINT_FLAG_MAX :: const PhysicsServer3D.G6DOF_JOINT_FLAG_MAX: G6DOFJointAxisFlag = 6
Represents the size of the [enum G6DOFJointAxisFlag] enum.

## SHAPE_WORLD_BOUNDARY :: const PhysicsServer3D.SHAPE_WORLD_BOUNDARY: ShapeType = 0
Constant for creating a world boundary shape (used by the [WorldBoundaryShape3D] resource).

## SHAPE_SEPARATION_RAY :: const PhysicsServer3D.SHAPE_SEPARATION_RAY: ShapeType = 1
Constant for creating a separation ray shape (used by the [SeparationRayShape3D] resource).

## SHAPE_SPHERE :: const PhysicsServer3D.SHAPE_SPHERE: ShapeType = 2
Constant for creating a sphere shape (used by the [SphereShape3D] resource).

## SHAPE_BOX :: const PhysicsServer3D.SHAPE_BOX: ShapeType = 3
Constant for creating a box shape (used by the [BoxShape3D] resource).

## SHAPE_CAPSULE :: const PhysicsServer3D.SHAPE_CAPSULE: ShapeType = 4
Constant for creating a capsule shape (used by the [CapsuleShape3D] resource).

## SHAPE_CYLINDER :: const PhysicsServer3D.SHAPE_CYLINDER: ShapeType = 5
Constant for creating a cylinder shape (used by the [CylinderShape3D] resource).

## SHAPE_CONVEX_POLYGON :: const PhysicsServer3D.SHAPE_CONVEX_POLYGON: ShapeType = 6
Constant for creating a convex polygon shape (used by the [ConvexPolygonShape3D] resource).

## SHAPE_CONCAVE_POLYGON :: const PhysicsServer3D.SHAPE_CONCAVE_POLYGON: ShapeType = 7
Constant for creating a concave polygon (trimesh) shape (used by the [ConcavePolygonShape3D] resource).

## SHAPE_HEIGHTMAP :: const PhysicsServer3D.SHAPE_HEIGHTMAP: ShapeType = 8
Constant for creating a heightmap shape (used by the [HeightMapShape3D] resource).

## SHAPE_SOFT_BODY :: const PhysicsServer3D.SHAPE_SOFT_BODY: ShapeType = 9
Constant used internally for a soft body shape. Any attempt to create this kind of shape results in an error.

## SHAPE_CUSTOM :: const PhysicsServer3D.SHAPE_CUSTOM: ShapeType = 10
Constant used internally for a custom shape. Any attempt to create this kind of shape results in an error when using Godot Physics or Jolt Physics.

## AREA_PARAM_GRAVITY_OVERRIDE_MODE :: const PhysicsServer3D.AREA_PARAM_GRAVITY_OVERRIDE_MODE: AreaParameter = 0
Constant to set/get gravity override mode in an area. See [enum AreaSpaceOverrideMode] for possible values.

## AREA_PARAM_GRAVITY :: const PhysicsServer3D.AREA_PARAM_GRAVITY: AreaParameter = 1
Constant to set/get gravity strength in an area.

## AREA_PARAM_GRAVITY_VECTOR :: const PhysicsServer3D.AREA_PARAM_GRAVITY_VECTOR: AreaParameter = 2
Constant to set/get gravity vector/center in an area.

## AREA_PARAM_GRAVITY_IS_POINT :: const PhysicsServer3D.AREA_PARAM_GRAVITY_IS_POINT: AreaParameter = 3
Constant to set/get whether the gravity vector of an area is a direction, or a center point.

## AREA_PARAM_GRAVITY_POINT_UNIT_DISTANCE :: const PhysicsServer3D.AREA_PARAM_GRAVITY_POINT_UNIT_DISTANCE: AreaParameter = 4
Constant to set/get the distance at which the gravity strength is equal to the gravity controlled by [constant AREA_PARAM_GRAVITY]. For example, on a planet 100 meters in radius with a surface gravity of 4.0 m/s², set the gravity to 4.0 and the unit distance to 100.0. The gravity will have falloff according to the inverse square law, so in the example, at 200 meters from the center the gravity will be 1.0 m/s² (twice the distance, 1/4th the gravity), at 50 meters it will be 16.0 m/s² (half the distance, 4x the gravity), and so on.
The above is true only when the unit distance is a positive number. When this is set to 0.0, the gravity will be constant regardless of distance.

## AREA_PARAM_LINEAR_DAMP_OVERRIDE_MODE :: const PhysicsServer3D.AREA_PARAM_LINEAR_DAMP_OVERRIDE_MODE: AreaParameter = 5
Constant to set/get linear damping override mode in an area. See [enum AreaSpaceOverrideMode] for possible values.

## AREA_PARAM_LINEAR_DAMP :: const PhysicsServer3D.AREA_PARAM_LINEAR_DAMP: AreaParameter = 6
Constant to set/get the linear damping factor of an area.

## AREA_PARAM_ANGULAR_DAMP_OVERRIDE_MODE :: const PhysicsServer3D.AREA_PARAM_ANGULAR_DAMP_OVERRIDE_MODE: AreaParameter = 7
Constant to set/get angular damping override mode in an area. See [enum AreaSpaceOverrideMode] for possible values.

## AREA_PARAM_ANGULAR_DAMP :: const PhysicsServer3D.AREA_PARAM_ANGULAR_DAMP: AreaParameter = 8
Constant to set/get the angular damping factor of an area.

## AREA_PARAM_PRIORITY :: const PhysicsServer3D.AREA_PARAM_PRIORITY: AreaParameter = 9
Constant to set/get the priority (order of processing) of an area.

## AREA_PARAM_WIND_FORCE_MAGNITUDE :: const PhysicsServer3D.AREA_PARAM_WIND_FORCE_MAGNITUDE: AreaParameter = 10
Constant to set/get the magnitude of area-specific wind force. This wind force only applies to [SoftBody3D] nodes. Other physics bodies are currently not affected by wind.

## AREA_PARAM_WIND_SOURCE :: const PhysicsServer3D.AREA_PARAM_WIND_SOURCE: AreaParameter = 11
Constant to set/get the 3D vector that specifies the origin from which an area-specific wind blows.

## AREA_PARAM_WIND_DIRECTION :: const PhysicsServer3D.AREA_PARAM_WIND_DIRECTION: AreaParameter = 12
Constant to set/get the 3D vector that specifies the direction in which an area-specific wind blows.

## AREA_PARAM_WIND_ATTENUATION_FACTOR :: const PhysicsServer3D.AREA_PARAM_WIND_ATTENUATION_FACTOR: AreaParameter = 13
Constant to set/get the exponential rate at which wind force decreases with distance from its origin.

## AREA_SPACE_OVERRIDE_DISABLED :: const PhysicsServer3D.AREA_SPACE_OVERRIDE_DISABLED: AreaSpaceOverrideMode = 0
This area does not affect gravity/damp. These are generally areas that exist only to detect collisions, and objects entering or exiting them.

## AREA_SPACE_OVERRIDE_COMBINE :: const PhysicsServer3D.AREA_SPACE_OVERRIDE_COMBINE: AreaSpaceOverrideMode = 1
This area adds its gravity/damp values to whatever has been calculated so far. This way, many overlapping areas can combine their physics to make interesting effects.

## AREA_SPACE_OVERRIDE_COMBINE_REPLACE :: const PhysicsServer3D.AREA_SPACE_OVERRIDE_COMBINE_REPLACE: AreaSpaceOverrideMode = 2
This area adds its gravity/damp values to whatever has been calculated so far. Then stops taking into account the rest of the areas, even the default one.

## AREA_SPACE_OVERRIDE_REPLACE :: const PhysicsServer3D.AREA_SPACE_OVERRIDE_REPLACE: AreaSpaceOverrideMode = 3
This area replaces any gravity/damp, even the default one, and stops taking into account the rest of the areas.

## AREA_SPACE_OVERRIDE_REPLACE_COMBINE :: const PhysicsServer3D.AREA_SPACE_OVERRIDE_REPLACE_COMBINE: AreaSpaceOverrideMode = 4
This area replaces any gravity/damp calculated so far, but keeps calculating the rest of the areas, down to the default one.

## BODY_MODE_STATIC :: const PhysicsServer3D.BODY_MODE_STATIC: BodyMode = 0
Constant for static bodies. In this mode, a body can be only moved by user code and doesn't collide with other bodies along its path when moved.

## BODY_MODE_KINEMATIC :: const PhysicsServer3D.BODY_MODE_KINEMATIC: BodyMode = 1
Constant for kinematic bodies. In this mode, a body can be only moved by user code and collides with other bodies along its path.

## BODY_MODE_RIGID :: const PhysicsServer3D.BODY_MODE_RIGID: BodyMode = 2
Constant for rigid bodies. In this mode, a body can be pushed by other bodies and has forces applied.

## BODY_MODE_RIGID_LINEAR :: const PhysicsServer3D.BODY_MODE_RIGID_LINEAR: BodyMode = 3
Constant for linear rigid bodies. In this mode, a body can not rotate, and only its linear velocity is affected by external forces.

## BODY_PARAM_BOUNCE :: const PhysicsServer3D.BODY_PARAM_BOUNCE: BodyParameter = 0
Constant to set/get a body's bounce factor.

## BODY_PARAM_FRICTION :: const PhysicsServer3D.BODY_PARAM_FRICTION: BodyParameter = 1
Constant to set/get a body's friction.

## BODY_PARAM_MASS :: const PhysicsServer3D.BODY_PARAM_MASS: BodyParameter = 2
Constant to set/get a body's mass.

## BODY_PARAM_INERTIA :: const PhysicsServer3D.BODY_PARAM_INERTIA: BodyParameter = 3
Constant to set/get a body's inertia.

## BODY_PARAM_CENTER_OF_MASS :: const PhysicsServer3D.BODY_PARAM_CENTER_OF_MASS: BodyParameter = 4
Constant to set/get a body's center of mass position in the body's local coordinate system.

## BODY_PARAM_GRAVITY_SCALE :: const PhysicsServer3D.BODY_PARAM_GRAVITY_SCALE: BodyParameter = 5
Constant to set/get a body's gravity multiplier.

## BODY_PARAM_LINEAR_DAMP_MODE :: const PhysicsServer3D.BODY_PARAM_LINEAR_DAMP_MODE: BodyParameter = 6
Constant to set/get a body's linear damping mode. See [enum BodyDampMode] for possible values.

## BODY_PARAM_ANGULAR_DAMP_MODE :: const PhysicsServer3D.BODY_PARAM_ANGULAR_DAMP_MODE: BodyParameter = 7
Constant to set/get a body's angular damping mode. See [enum BodyDampMode] for possible values.

## BODY_PARAM_LINEAR_DAMP :: const PhysicsServer3D.BODY_PARAM_LINEAR_DAMP: BodyParameter = 8
Constant to set/get a body's linear damping factor.

## BODY_PARAM_ANGULAR_DAMP :: const PhysicsServer3D.BODY_PARAM_ANGULAR_DAMP: BodyParameter = 9
Constant to set/get a body's angular damping factor.

## BODY_PARAM_MAX :: const PhysicsServer3D.BODY_PARAM_MAX: BodyParameter = 10
Represents the size of the [enum BodyParameter] enum.

## BODY_DAMP_MODE_COMBINE :: const PhysicsServer3D.BODY_DAMP_MODE_COMBINE: BodyDampMode = 0
The body's damping value is added to any value set in areas or the default value.

## BODY_DAMP_MODE_REPLACE :: const PhysicsServer3D.BODY_DAMP_MODE_REPLACE: BodyDampMode = 1
The body's damping value replaces any value set in areas or the default value.

## BODY_STATE_TRANSFORM :: const PhysicsServer3D.BODY_STATE_TRANSFORM: BodyState = 0
Constant to set/get the current transform matrix of the body.

## BODY_STATE_LINEAR_VELOCITY :: const PhysicsServer3D.BODY_STATE_LINEAR_VELOCITY: BodyState = 1
Constant to set/get the current linear velocity of the body.

## BODY_STATE_ANGULAR_VELOCITY :: const PhysicsServer3D.BODY_STATE_ANGULAR_VELOCITY: BodyState = 2
Constant to set/get the current angular velocity of the body.

## BODY_STATE_SLEEPING :: const PhysicsServer3D.BODY_STATE_SLEEPING: BodyState = 3
Constant to sleep/wake up a body, or to get whether it is sleeping.

## BODY_STATE_CAN_SLEEP :: const PhysicsServer3D.BODY_STATE_CAN_SLEEP: BodyState = 4
Constant to set/get whether the body can sleep.

## AREA_BODY_ADDED :: const PhysicsServer3D.AREA_BODY_ADDED: AreaBodyStatus = 0
The value of the first parameter and area callback function receives, when an object enters one of its shapes.

## AREA_BODY_REMOVED :: const PhysicsServer3D.AREA_BODY_REMOVED: AreaBodyStatus = 1
The value of the first parameter and area callback function receives, when an object exits one of its shapes.

## INFO_ACTIVE_OBJECTS :: const PhysicsServer3D.INFO_ACTIVE_OBJECTS: ProcessInfo = 0
Constant to get the number of objects that are not sleeping.

## INFO_COLLISION_PAIRS :: const PhysicsServer3D.INFO_COLLISION_PAIRS: ProcessInfo = 1
Constant to get the number of possible collisions.

## INFO_ISLAND_COUNT :: const PhysicsServer3D.INFO_ISLAND_COUNT: ProcessInfo = 2
Constant to get the number of space regions where a collision could occur.

## SPACE_PARAM_CONTACT_RECYCLE_RADIUS :: const PhysicsServer3D.SPACE_PARAM_CONTACT_RECYCLE_RADIUS: SpaceParameter = 0
Constant to set/get the maximum distance a pair of bodies has to move before their collision status has to be recalculated.

## SPACE_PARAM_CONTACT_MAX_SEPARATION :: const PhysicsServer3D.SPACE_PARAM_CONTACT_MAX_SEPARATION: SpaceParameter = 1
Constant to set/get the maximum distance a shape can be from another before they are considered separated and the contact is discarded.

## SPACE_PARAM_CONTACT_MAX_ALLOWED_PENETRATION :: const PhysicsServer3D.SPACE_PARAM_CONTACT_MAX_ALLOWED_PENETRATION: SpaceParameter = 2
Constant to set/get the maximum distance a shape can penetrate another shape before it is considered a collision.

## SPACE_PARAM_CONTACT_DEFAULT_BIAS :: const PhysicsServer3D.SPACE_PARAM_CONTACT_DEFAULT_BIAS: SpaceParameter = 3
Constant to set/get the default solver bias for all physics contacts. A solver bias is a factor controlling how much two objects "rebound", after overlapping, to avoid leaving them in that state because of numerical imprecision.

## SPACE_PARAM_BODY_LINEAR_VELOCITY_SLEEP_THRESHOLD :: const PhysicsServer3D.SPACE_PARAM_BODY_LINEAR_VELOCITY_SLEEP_THRESHOLD: SpaceParameter = 4
Constant to set/get the threshold linear velocity of activity. A body marked as potentially inactive for both linear and angular velocity will be put to sleep after the time given.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SPACE_PARAM_BODY_ANGULAR_VELOCITY_SLEEP_THRESHOLD :: const PhysicsServer3D.SPACE_PARAM_BODY_ANGULAR_VELOCITY_SLEEP_THRESHOLD: SpaceParameter = 5
Constant to set/get the threshold angular velocity of activity. A body marked as potentially inactive for both linear and angular velocity will be put to sleep after the time given.
[b]Note:[/b] Only supported when using GodotPhysics3D. This parameter is ignored when using Jolt Physics.

## SPACE_PARAM_BODY_TIME_TO_SLEEP :: const PhysicsServer3D.SPACE_PARAM_BODY_TIME_TO_SLEEP: SpaceParameter = 6
Constant to set/get the maximum time of activity. A body marked as potentially inactive for both linear and angular velocity will be put to sleep after this time.

## SPACE_PARAM_SOLVER_ITERATIONS :: const PhysicsServer3D.SPACE_PARAM_SOLVER_ITERATIONS: SpaceParameter = 7
Constant to set/get the number of solver iterations for contacts and constraints. The greater the number of iterations, the more accurate the collisions and constraints will be. However, a greater number of iterations requires more CPU power, which can decrease performance.

## BODY_AXIS_LINEAR_X :: const PhysicsServer3D.BODY_AXIS_LINEAR_X: BodyAxis = 1

## BODY_AXIS_LINEAR_Y :: const PhysicsServer3D.BODY_AXIS_LINEAR_Y: BodyAxis = 2

## BODY_AXIS_LINEAR_Z :: const PhysicsServer3D.BODY_AXIS_LINEAR_Z: BodyAxis = 4

## BODY_AXIS_ANGULAR_X :: const PhysicsServer3D.BODY_AXIS_ANGULAR_X: BodyAxis = 8

## BODY_AXIS_ANGULAR_Y :: const PhysicsServer3D.BODY_AXIS_ANGULAR_Y: BodyAxis = 16

## BODY_AXIS_ANGULAR_Z :: const PhysicsServer3D.BODY_AXIS_ANGULAR_Z: BodyAxis = 32

## area_add_shape :: func PhysicsServer3D.area_add_shape(area: RID, shape: RID, transform: Transform3D = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0), disabled: bool = false) -> void
Adds a shape to the area, along with a transform matrix. Shapes are usually referenced by their index, so you should track which shape has a given index.

### area :: RID

### shape :: RID

### transform :: Transform3D

### disabled :: bool

## area_attach_object_instance_id :: func PhysicsServer3D.area_attach_object_instance_id(area: RID, id: int) -> void
Assigns the area to a descendant of [Object], so it can exist in the node tree.

### area :: RID

### id :: int

## area_clear_shapes :: func PhysicsServer3D.area_clear_shapes(area: RID) -> void
Removes all shapes from an area. It does not delete the shapes, so they can be reassigned later.

### area :: RID

## area_create :: func PhysicsServer3D.area_create() -> RID
Creates a 3D area object in the physics server, and returns the [RID] that identifies it. The default settings for the created area include a collision layer and mask set to [code]1[/code], and [code]monitorable[/code] set to [code]false[/code].
Use [method area_add_shape] to add shapes to it, use [method area_set_transform] to set its transform, and use [method area_set_space] to add the area to a space. If you want the area to be detectable use [method area_set_monitorable].

## area_get_collision_layer :: func PhysicsServer3D.area_get_collision_layer(area: RID) -> int
Returns the physics layer or layers an area belongs to.

### area :: RID

## area_get_collision_mask :: func PhysicsServer3D.area_get_collision_mask(area: RID) -> int
Returns the physics layer or layers an area can contact with.

### area :: RID

## area_get_object_instance_id :: func PhysicsServer3D.area_get_object_instance_id(area: RID) -> int
Gets the instance ID of the object the area is assigned to.

### area :: RID

## area_get_param :: func PhysicsServer3D.area_get_param(area: RID, param: int) -> Variant
Returns an area parameter value. A list of available parameters is on the [enum AreaParameter] constants.

### area :: RID

### param :: int

## area_get_shape :: func PhysicsServer3D.area_get_shape(area: RID, shape_idx: int) -> RID
Returns the [RID] of the nth shape of an area.

### area :: RID

### shape_idx :: int

## area_get_shape_count :: func PhysicsServer3D.area_get_shape_count(area: RID) -> int
Returns the number of shapes assigned to an area.

### area :: RID

## area_get_shape_transform :: func PhysicsServer3D.area_get_shape_transform(area: RID, shape_idx: int) -> Transform3D
Returns the transform matrix of a shape within an area.

### area :: RID

### shape_idx :: int

## area_get_space :: func PhysicsServer3D.area_get_space(area: RID) -> RID
Returns the space assigned to the area.

### area :: RID

## area_get_transform :: func PhysicsServer3D.area_get_transform(area: RID) -> Transform3D
Returns the transform matrix for an area.

### area :: RID

## area_remove_shape :: func PhysicsServer3D.area_remove_shape(area: RID, shape_idx: int) -> void
Removes a shape from an area. It does not delete the shape, so it can be reassigned later.

### area :: RID

### shape_idx :: int

## area_set_area_monitor_callback :: func PhysicsServer3D.area_set_area_monitor_callback(area: RID, callback: Callable) -> void
Sets the area's area monitor callback. This callback will be called when any other (shape of an) area enters or exits (a shape of) the given area, and must take the following five parameters:
1. an integer [code]status[/code]: either [constant AREA_BODY_ADDED] or [constant AREA_BODY_REMOVED] depending on whether the other area's shape entered or exited the area,
2. an [RID] [code]area_rid[/code]: the [RID] of the other area that entered or exited the area,
3. an integer [code]instance_id[/code]: the [code]ObjectID[/code] attached to the other area,
4. an integer [code]area_shape_idx[/code]: the index of the shape of the other area that entered or exited the area,
5. an integer [code]self_shape_idx[/code]: the index of the shape of the area where the other area entered or exited.
By counting (or keeping track of) the shapes that enter and exit, it can be determined if an area (with all its shapes) is entering for the first time or exiting for the last time.

### area :: RID

### callback :: Callable

## area_set_collision_layer :: func PhysicsServer3D.area_set_collision_layer(area: RID, layer: int) -> void
Assigns the area to one or many physics layers.

### area :: RID

### layer :: int

## area_set_collision_mask :: func PhysicsServer3D.area_set_collision_mask(area: RID, mask: int) -> void
Sets which physics layers the area will monitor.

### area :: RID

### mask :: int

## area_set_monitor_callback :: func PhysicsServer3D.area_set_monitor_callback(area: RID, callback: Callable) -> void
Sets the area's body monitor callback. This callback will be called when any other (shape of a) body enters or exits (a shape of) the given area, and must take the following five parameters:
1. an integer [code]status[/code]: either [constant AREA_BODY_ADDED] or [constant AREA_BODY_REMOVED] depending on whether the other body shape entered or exited the area,
2. an [RID] [code]body_rid[/code]: the [RID] of the body that entered or exited the area,
3. an integer [code]instance_id[/code]: the [code]ObjectID[/code] attached to the body,
4. an integer [code]body_shape_idx[/code]: the index of the shape of the body that entered or exited the area,
5. an integer [code]self_shape_idx[/code]: the index of the shape of the area where the body entered or exited.
By counting (or keeping track of) the shapes that enter and exit, it can be determined if a body (with all its shapes) is entering for the first time or exiting for the last time.

### area :: RID

### callback :: Callable

## area_set_monitorable :: func PhysicsServer3D.area_set_monitorable(area: RID, monitorable: bool) -> void

### area :: RID

### monitorable :: bool

## area_set_param :: func PhysicsServer3D.area_set_param(area: RID, param: int, value: Variant) -> void
Sets the value for an area parameter. A list of available parameters is on the [enum AreaParameter] constants.

### area :: RID

### param :: int

### value :: Variant

## area_set_ray_pickable :: func PhysicsServer3D.area_set_ray_pickable(area: RID, enable: bool) -> void
Sets object pickable with rays.

### area :: RID

### enable :: bool

## area_set_shape :: func PhysicsServer3D.area_set_shape(area: RID, shape_idx: int, shape: RID) -> void
Substitutes a given area shape by another. The old shape is selected by its index, the new one by its [RID].

### area :: RID

### shape_idx :: int

### shape :: RID

## area_set_shape_disabled :: func PhysicsServer3D.area_set_shape_disabled(area: RID, shape_idx: int, disabled: bool) -> void

### area :: RID

### shape_idx :: int

### disabled :: bool

## area_set_shape_transform :: func PhysicsServer3D.area_set_shape_transform(area: RID, shape_idx: int, transform: Transform3D) -> void
Sets the transform matrix for an area shape.

### area :: RID

### shape_idx :: int

### transform :: Transform3D

## area_set_space :: func PhysicsServer3D.area_set_space(area: RID, space: RID) -> void
Assigns a space to the area.

### area :: RID

### space :: RID

## area_set_transform :: func PhysicsServer3D.area_set_transform(area: RID, transform: Transform3D) -> void
Sets the transform matrix for an area.

### area :: RID

### transform :: Transform3D

## body_add_collision_exception :: func PhysicsServer3D.body_add_collision_exception(body: RID, excepted_body: RID) -> void
Adds a body to the list of bodies exempt from collisions.

### body :: RID

### excepted_body :: RID

## body_add_constant_central_force :: func PhysicsServer3D.body_add_constant_central_force(body: RID, force: Vector3) -> void
Adds a constant directional force without affecting rotation that keeps being applied over time until cleared with [code]body_set_constant_force(body, Vector3(0, 0, 0))[/code].
This is equivalent to using [method body_add_constant_force] at the body's center of mass.

### body :: RID

### force :: Vector3

## body_add_constant_force :: func PhysicsServer3D.body_add_constant_force(body: RID, force: Vector3, position: Vector3 = Vector3(0, 0, 0)) -> void
Adds a constant positioned force to the body that keeps being applied over time until cleared with [code]body_set_constant_force(body, Vector3(0, 0, 0))[/code].
[param position] is the offset from the body origin in global coordinates.

### body :: RID

### force :: Vector3

### position :: Vector3

## body_add_constant_torque :: func PhysicsServer3D.body_add_constant_torque(body: RID, torque: Vector3) -> void
Adds a constant rotational force without affecting position that keeps being applied over time until cleared with [code]body_set_constant_torque(body, Vector3(0, 0, 0))[/code].

### body :: RID

### torque :: Vector3

## body_add_shape :: func PhysicsServer3D.body_add_shape(body: RID, shape: RID, transform: Transform3D = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0), disabled: bool = false) -> void
Adds a shape to the body, along with a transform matrix. Shapes are usually referenced by their index, so you should track which shape has a given index.

### body :: RID

### shape :: RID

### transform :: Transform3D

### disabled :: bool

## body_apply_central_force :: func PhysicsServer3D.body_apply_central_force(body: RID, force: Vector3) -> void
Applies a directional force without affecting rotation. A force is time dependent and meant to be applied every physics update.
This is equivalent to using [method body_apply_force] at the body's center of mass.

### body :: RID

### force :: Vector3

## body_apply_central_impulse :: func PhysicsServer3D.body_apply_central_impulse(body: RID, impulse: Vector3) -> void
Applies a directional impulse without affecting rotation.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).
This is equivalent to using [method body_apply_impulse] at the body's center of mass.

### body :: RID

### impulse :: Vector3

## body_apply_force :: func PhysicsServer3D.body_apply_force(body: RID, force: Vector3, position: Vector3 = Vector3(0, 0, 0)) -> void
Applies a positioned force to the body. A force is time dependent and meant to be applied every physics update.
[param position] is the offset from the body origin in global coordinates.

### body :: RID

### force :: Vector3

### position :: Vector3

## body_apply_impulse :: func PhysicsServer3D.body_apply_impulse(body: RID, impulse: Vector3, position: Vector3 = Vector3(0, 0, 0)) -> void
Applies a positioned impulse to the body.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).
[param position] is the offset from the body origin in global coordinates.

### body :: RID

### impulse :: Vector3

### position :: Vector3

## body_apply_torque :: func PhysicsServer3D.body_apply_torque(body: RID, torque: Vector3) -> void
Applies a rotational force without affecting position. A force is time dependent and meant to be applied every physics update.

### body :: RID

### torque :: Vector3

## body_apply_torque_impulse :: func PhysicsServer3D.body_apply_torque_impulse(body: RID, impulse: Vector3) -> void
Applies a rotational impulse to the body without affecting the position.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).

### body :: RID

### impulse :: Vector3

## body_attach_object_instance_id :: func PhysicsServer3D.body_attach_object_instance_id(body: RID, id: int) -> void
Assigns the area to a descendant of [Object], so it can exist in the node tree.

### body :: RID

### id :: int

## body_clear_shapes :: func PhysicsServer3D.body_clear_shapes(body: RID) -> void
Removes all shapes from a body.

### body :: RID

## body_create :: func PhysicsServer3D.body_create() -> RID
Creates a 3D body object in the physics server, and returns the [RID] that identifies it. The default settings for the created area include a collision layer and mask set to [code]1[/code], and body mode set to [constant BODY_MODE_RIGID].
Use [method body_add_shape] to add shapes to it, use [method body_set_state] to set its transform, and use [method body_set_space] to add the body to a space.

## body_get_collision_layer :: func PhysicsServer3D.body_get_collision_layer(body: RID) -> int
Returns the physics layer or layers a body belongs to.

### body :: RID

## body_get_collision_mask :: func PhysicsServer3D.body_get_collision_mask(body: RID) -> int
Returns the physics layer or layers a body can collide with.

### body :: RID

## body_get_collision_priority :: func PhysicsServer3D.body_get_collision_priority(body: RID) -> float
Returns the body's collision priority.

### body :: RID

## body_get_constant_force :: func PhysicsServer3D.body_get_constant_force(body: RID) -> Vector3
Returns the body's total constant positional forces applied during each physics update.
See [method body_add_constant_force] and [method body_add_constant_central_force].

### body :: RID

## body_get_constant_torque :: func PhysicsServer3D.body_get_constant_torque(body: RID) -> Vector3
Returns the body's total constant rotational forces applied during each physics update.
See [method body_add_constant_torque].

### body :: RID

## body_get_direct_state :: func PhysicsServer3D.body_get_direct_state(body: RID) -> PhysicsDirectBodyState3D
Returns the [PhysicsDirectBodyState3D] of the body. Returns [code]null[/code] if the body is destroyed or removed from the physics space.

### body :: RID

## body_get_max_contacts_reported :: func PhysicsServer3D.body_get_max_contacts_reported(body: RID) -> int
Returns the maximum contacts that can be reported. See [method body_set_max_contacts_reported].

### body :: RID

## body_get_mode :: func PhysicsServer3D.body_get_mode(body: RID) -> int
Returns the body mode.

### body :: RID

## body_get_object_instance_id :: func PhysicsServer3D.body_get_object_instance_id(body: RID) -> int
Gets the instance ID of the object the area is assigned to.

### body :: RID

## body_get_param :: func PhysicsServer3D.body_get_param(body: RID, param: int) -> Variant
Returns the value of a body parameter. A list of available parameters is on the [enum BodyParameter] constants.

### body :: RID

### param :: int

## body_get_shape :: func PhysicsServer3D.body_get_shape(body: RID, shape_idx: int) -> RID
Returns the [RID] of the nth shape of a body.

### body :: RID

### shape_idx :: int

## body_get_shape_count :: func PhysicsServer3D.body_get_shape_count(body: RID) -> int
Returns the number of shapes assigned to a body.

### body :: RID

## body_get_shape_transform :: func PhysicsServer3D.body_get_shape_transform(body: RID, shape_idx: int) -> Transform3D
Returns the transform matrix of a body shape.

### body :: RID

### shape_idx :: int

## body_get_space :: func PhysicsServer3D.body_get_space(body: RID) -> RID
Returns the [RID] of the space assigned to a body.

### body :: RID

## body_get_state :: func PhysicsServer3D.body_get_state(body: RID, state: int) -> Variant
Returns a body state.

### body :: RID

### state :: int

## body_is_axis_locked :: func PhysicsServer3D.body_is_axis_locked(body: RID, axis: int) -> bool

### body :: RID

### axis :: int

## body_is_continuous_collision_detection_enabled :: func PhysicsServer3D.body_is_continuous_collision_detection_enabled(body: RID) -> bool
If [code]true[/code], the continuous collision detection mode is enabled.

### body :: RID

## body_is_omitting_force_integration :: func PhysicsServer3D.body_is_omitting_force_integration(body: RID) -> bool
Returns [code]true[/code] if the body is omitting the standard force integration. See [method body_set_omit_force_integration].

### body :: RID

## body_remove_collision_exception :: func PhysicsServer3D.body_remove_collision_exception(body: RID, excepted_body: RID) -> void
Removes a body from the list of bodies exempt from collisions.
Continuous collision detection tries to predict where a moving body will collide, instead of moving it and correcting its movement if it collided.

### body :: RID

### excepted_body :: RID

## body_remove_shape :: func PhysicsServer3D.body_remove_shape(body: RID, shape_idx: int) -> void
Removes a shape from a body. The shape is not deleted, so it can be reused afterwards.

### body :: RID

### shape_idx :: int

## body_reset_mass_properties :: func PhysicsServer3D.body_reset_mass_properties(body: RID) -> void
Restores the default inertia and center of mass based on shapes to cancel any custom values previously set using [method body_set_param].

### body :: RID

## body_set_axis_lock :: func PhysicsServer3D.body_set_axis_lock(body: RID, axis: int, lock: bool) -> void

### body :: RID

### axis :: int

### lock :: bool

## body_set_axis_velocity :: func PhysicsServer3D.body_set_axis_velocity(body: RID, axis_velocity: Vector3) -> void
Sets an axis velocity. The velocity in the given vector axis will be set as the given vector length. This is useful for jumping behavior.

### body :: RID

### axis_velocity :: Vector3

## body_set_collision_layer :: func PhysicsServer3D.body_set_collision_layer(body: RID, layer: int) -> void
Sets the physics layer or layers a body belongs to.

### body :: RID

### layer :: int

## body_set_collision_mask :: func PhysicsServer3D.body_set_collision_mask(body: RID, mask: int) -> void
Sets the physics layer or layers a body can collide with.

### body :: RID

### mask :: int

## body_set_collision_priority :: func PhysicsServer3D.body_set_collision_priority(body: RID, priority: float) -> void
Sets the body's collision priority.

### body :: RID

### priority :: float

## body_set_constant_force :: func PhysicsServer3D.body_set_constant_force(body: RID, force: Vector3) -> void
Sets the body's total constant positional forces applied during each physics update.
See [method body_add_constant_force] and [method body_add_constant_central_force].

### body :: RID

### force :: Vector3

## body_set_constant_torque :: func PhysicsServer3D.body_set_constant_torque(body: RID, torque: Vector3) -> void
Sets the body's total constant rotational forces applied during each physics update.
See [method body_add_constant_torque].

### body :: RID

### torque :: Vector3

## body_set_enable_continuous_collision_detection :: func PhysicsServer3D.body_set_enable_continuous_collision_detection(body: RID, enable: bool) -> void
If [code]true[/code], the continuous collision detection mode is enabled.
Continuous collision detection tries to predict where a moving body will collide, instead of moving it and correcting its movement if it collided.

### body :: RID

### enable :: bool

## body_set_force_integration_callback :: func PhysicsServer3D.body_set_force_integration_callback(body: RID, callable: Callable, userdata: Variant = null) -> void
Sets the body's custom force integration callback function to [param callable]. Use an empty [Callable] ([code skip-lint]Callable()[/code]) to clear the custom callback.
The function [param callable] will be called every physics tick, before the standard force integration (see [method body_set_omit_force_integration]). It can be used for example to update the body's linear and angular velocity based on contact with other bodies.
If [param userdata] is not [code]null[/code], the function [param callable] must take the following two parameters:
1. [code]state[/code]: a [PhysicsDirectBodyState3D], used to retrieve and modify the body's state,
2. [code skip-lint]userdata[/code]: a [Variant]; its value will be the [param userdata] passed into this method.
If [param userdata] is [code]null[/code], then [param callable] must take only the [code]state[/code] parameter.

### body :: RID

### callable :: Callable

### userdata :: Variant

## body_set_max_contacts_reported :: func PhysicsServer3D.body_set_max_contacts_reported(body: RID, amount: int) -> void
Sets the maximum contacts to report. Bodies can keep a log of the contacts with other bodies. This is enabled by setting the maximum number of contacts reported to a number greater than 0.

### body :: RID

### amount :: int

## body_set_mode :: func PhysicsServer3D.body_set_mode(body: RID, mode: int) -> void
Sets the body mode.

### body :: RID

### mode :: int

## body_set_omit_force_integration :: func PhysicsServer3D.body_set_omit_force_integration(body: RID, enable: bool) -> void
Sets whether the body omits the standard force integration. If [param enable] is [code]true[/code], the body will not automatically use applied forces, torques, and damping to update the body's linear and angular velocity. In this case, [method body_set_force_integration_callback] can be used to manually update the linear and angular velocity instead.
This method is called when the property [member RigidBody3D.custom_integrator] is set.

### body :: RID

### enable :: bool

## body_set_param :: func PhysicsServer3D.body_set_param(body: RID, param: int, value: Variant) -> void
Sets a body parameter. A list of available parameters is on the [enum BodyParameter] constants.

### body :: RID

### param :: int

### value :: Variant

## body_set_ray_pickable :: func PhysicsServer3D.body_set_ray_pickable(body: RID, enable: bool) -> void
Sets the body pickable with rays if [param enable] is set.

### body :: RID

### enable :: bool

## body_set_shape :: func PhysicsServer3D.body_set_shape(body: RID, shape_idx: int, shape: RID) -> void
Substitutes a given body shape by another. The old shape is selected by its index, the new one by its [RID].

### body :: RID

### shape_idx :: int

### shape :: RID

## body_set_shape_disabled :: func PhysicsServer3D.body_set_shape_disabled(body: RID, shape_idx: int, disabled: bool) -> void

### body :: RID

### shape_idx :: int

### disabled :: bool

## body_set_shape_transform :: func PhysicsServer3D.body_set_shape_transform(body: RID, shape_idx: int, transform: Transform3D) -> void
Sets the transform matrix for a body shape.

### body :: RID

### shape_idx :: int

### transform :: Transform3D

## body_set_space :: func PhysicsServer3D.body_set_space(body: RID, space: RID) -> void
Assigns a space to the body (see [method space_create]).

### body :: RID

### space :: RID

## body_set_state :: func PhysicsServer3D.body_set_state(body: RID, state: int, value: Variant) -> void
Sets a body state.

### body :: RID

### state :: int

### value :: Variant

## body_set_state_sync_callback :: func PhysicsServer3D.body_set_state_sync_callback(body: RID, callable: Callable) -> void
Sets the body's state synchronization callback function to [param callable]. Use an empty [Callable] ([code skip-lint]Callable()[/code]) to clear the callback.
The function [param callable] will be called every physics frame, assuming that the body was active during the previous physics tick, and can be used to fetch the latest state from the physics server.
The function [param callable] must take the following parameters:
1. [code]state[/code]: a [PhysicsDirectBodyState3D], used to retrieve the body's state.

### body :: RID

### callable :: Callable

## body_test_motion :: func PhysicsServer3D.body_test_motion(body: RID, parameters: PhysicsTestMotionParameters3D, result: PhysicsTestMotionResult3D = null) -> bool
Returns [code]true[/code] if a collision would result from moving along a motion vector from a given point in space. [PhysicsTestMotionParameters3D] is passed to set motion parameters. [PhysicsTestMotionResult3D] can be passed to return additional information.

### body :: RID

### parameters :: PhysicsTestMotionParameters3D

### result :: PhysicsTestMotionResult3D

## box_shape_create :: func PhysicsServer3D.box_shape_create() -> RID
Creates a 3D box shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the box's half-extents.

## capsule_shape_create :: func PhysicsServer3D.capsule_shape_create() -> RID
Creates a 3D capsule shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the capsule's height and radius.

## concave_polygon_shape_create :: func PhysicsServer3D.concave_polygon_shape_create() -> RID
Creates a 3D concave polygon shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the concave polygon's triangles.

## cone_twist_joint_get_param :: func PhysicsServer3D.cone_twist_joint_get_param(joint: RID, param: int) -> float
Gets a cone twist joint parameter.

### joint :: RID

### param :: int

## cone_twist_joint_set_param :: func PhysicsServer3D.cone_twist_joint_set_param(joint: RID, param: int, value: float) -> void
Sets a cone twist joint parameter.

### joint :: RID

### param :: int

### value :: float

## convex_polygon_shape_create :: func PhysicsServer3D.convex_polygon_shape_create() -> RID
Creates a 3D convex polygon shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the convex polygon's points.

## custom_shape_create :: func PhysicsServer3D.custom_shape_create() -> RID
Creates a custom shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the shape's data.
[b]Note:[/b] Custom shapes are not supported by the built-in physics servers, so calling this method always produces an error when using Godot Physics or Jolt Physics. Custom physics servers implemented as GDExtensions may support a custom shape.

## cylinder_shape_create :: func PhysicsServer3D.cylinder_shape_create() -> RID
Creates a 3D cylinder shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the cylinder's height and radius.

## free_rid :: func PhysicsServer3D.free_rid(rid: RID) -> void
Destroys any of the objects created by PhysicsServer3D. If the [RID] passed is not one of the objects that can be created by PhysicsServer3D, an error will be sent to the console.

### rid :: RID

## generic_6dof_joint_get_flag :: func PhysicsServer3D.generic_6dof_joint_get_flag(joint: RID, axis: int, flag: int) -> bool
Returns the value of a generic 6DOF joint flag.

### joint :: RID

### axis :: int

### flag :: int

## generic_6dof_joint_get_param :: func PhysicsServer3D.generic_6dof_joint_get_param(joint: RID, axis: int, param: int) -> float
Returns the value of a generic 6DOF joint parameter.

### joint :: RID

### axis :: int

### param :: int

## generic_6dof_joint_set_flag :: func PhysicsServer3D.generic_6dof_joint_set_flag(joint: RID, axis: int, flag: int, enable: bool) -> void
Sets the value of a given generic 6DOF joint flag.

### joint :: RID

### axis :: int

### flag :: int

### enable :: bool

## generic_6dof_joint_set_param :: func PhysicsServer3D.generic_6dof_joint_set_param(joint: RID, axis: int, param: int, value: float) -> void
Sets the value of a given generic 6DOF joint parameter.

### joint :: RID

### axis :: int

### param :: int

### value :: float

## get_process_info :: func PhysicsServer3D.get_process_info(process_info: int) -> int
Returns the value of a physics engine state specified by [param process_info].

### process_info :: int

## heightmap_shape_create :: func PhysicsServer3D.heightmap_shape_create() -> RID
Creates a 3D heightmap shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the heightmap's data.

## hinge_joint_get_flag :: func PhysicsServer3D.hinge_joint_get_flag(joint: RID, flag: int) -> bool
Gets a hinge joint flag.

### joint :: RID

### flag :: int

## hinge_joint_get_param :: func PhysicsServer3D.hinge_joint_get_param(joint: RID, param: int) -> float
Gets a hinge joint parameter.

### joint :: RID

### param :: int

## hinge_joint_set_flag :: func PhysicsServer3D.hinge_joint_set_flag(joint: RID, flag: int, enabled: bool) -> void
Sets a hinge joint flag.

### joint :: RID

### flag :: int

### enabled :: bool

## hinge_joint_set_param :: func PhysicsServer3D.hinge_joint_set_param(joint: RID, param: int, value: float) -> void
Sets a hinge joint parameter.

### joint :: RID

### param :: int

### value :: float

## joint_clear :: func PhysicsServer3D.joint_clear(joint: RID) -> void

### joint :: RID

## joint_create :: func PhysicsServer3D.joint_create() -> RID

## joint_disable_collisions_between_bodies :: func PhysicsServer3D.joint_disable_collisions_between_bodies(joint: RID, disable: bool) -> void
Sets whether the bodies attached to the [Joint3D] will collide with each other.

### joint :: RID

### disable :: bool

## joint_get_solver_priority :: func PhysicsServer3D.joint_get_solver_priority(joint: RID) -> int
Gets the priority value of the Joint3D.
[b]Note:[/b] Only supported when using GodotPhysics3D. This method always returns [code]1[/code] when using Jolt Physics, as it does not support joint solver priority.

### joint :: RID

## joint_get_type :: func PhysicsServer3D.joint_get_type(joint: RID) -> int
Returns the type of the Joint3D.

### joint :: RID

## joint_is_disabled_collisions_between_bodies :: func PhysicsServer3D.joint_is_disabled_collisions_between_bodies(joint: RID) -> bool
Returns whether the bodies attached to the [Joint3D] will collide with each other.

### joint :: RID

## joint_make_cone_twist :: func PhysicsServer3D.joint_make_cone_twist(joint: RID, body_A: RID, local_ref_A: Transform3D, body_B: RID, local_ref_B: Transform3D) -> void

### joint :: RID

### body_A :: RID

### local_ref_A :: Transform3D

### body_B :: RID

### local_ref_B :: Transform3D

## joint_make_generic_6dof :: func PhysicsServer3D.joint_make_generic_6dof(joint: RID, body_A: RID, local_ref_A: Transform3D, body_B: RID, local_ref_B: Transform3D) -> void
Make the joint a generic six degrees of freedom (6DOF) joint. Use [method generic_6dof_joint_set_flag] and [method generic_6dof_joint_set_param] to set the joint's flags and parameters respectively.

### joint :: RID

### body_A :: RID

### local_ref_A :: Transform3D

### body_B :: RID

### local_ref_B :: Transform3D

## joint_make_hinge :: func PhysicsServer3D.joint_make_hinge(joint: RID, body_A: RID, hinge_A: Transform3D, body_B: RID, hinge_B: Transform3D) -> void

### joint :: RID

### body_A :: RID

### hinge_A :: Transform3D

### body_B :: RID

### hinge_B :: Transform3D

## joint_make_pin :: func PhysicsServer3D.joint_make_pin(joint: RID, body_A: RID, local_A: Vector3, body_B: RID, local_B: Vector3) -> void

### joint :: RID

### body_A :: RID

### local_A :: Vector3

### body_B :: RID

### local_B :: Vector3

## joint_make_slider :: func PhysicsServer3D.joint_make_slider(joint: RID, body_A: RID, local_ref_A: Transform3D, body_B: RID, local_ref_B: Transform3D) -> void

### joint :: RID

### body_A :: RID

### local_ref_A :: Transform3D

### body_B :: RID

### local_ref_B :: Transform3D

## joint_set_solver_priority :: func PhysicsServer3D.joint_set_solver_priority(joint: RID, priority: int) -> void
Sets the priority value of the Joint3D.
[b]Note:[/b] Only supported when using GodotPhysics3D. This method has no effect when using Jolt Physics, as it does not support joint solver priority.

### joint :: RID

### priority :: int

## pin_joint_get_local_a :: func PhysicsServer3D.pin_joint_get_local_a(joint: RID) -> Vector3
Returns position of the joint in the local space of body a of the joint.

### joint :: RID

## pin_joint_get_local_b :: func PhysicsServer3D.pin_joint_get_local_b(joint: RID) -> Vector3
Returns position of the joint in the local space of body b of the joint.

### joint :: RID

## pin_joint_get_param :: func PhysicsServer3D.pin_joint_get_param(joint: RID, param: int) -> float
Gets a pin joint parameter.

### joint :: RID

### param :: int

## pin_joint_set_local_a :: func PhysicsServer3D.pin_joint_set_local_a(joint: RID, local_A: Vector3) -> void
Sets position of the joint in the local space of body a of the joint.

### joint :: RID

### local_A :: Vector3

## pin_joint_set_local_b :: func PhysicsServer3D.pin_joint_set_local_b(joint: RID, local_B: Vector3) -> void
Sets position of the joint in the local space of body b of the joint.

### joint :: RID

### local_B :: Vector3

## pin_joint_set_param :: func PhysicsServer3D.pin_joint_set_param(joint: RID, param: int, value: float) -> void
Sets a pin joint parameter.

### joint :: RID

### param :: int

### value :: float

## separation_ray_shape_create :: func PhysicsServer3D.separation_ray_shape_create() -> RID
Creates a 3D separation ray shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the shape's [code]length[/code] and [code]slide_on_slope[/code] properties.

## set_active :: func PhysicsServer3D.set_active(active: bool) -> void
Activates or deactivates the 3D physics engine.

### active :: bool

## shape_get_data :: func PhysicsServer3D.shape_get_data(shape: RID) -> Variant
Returns the shape data that configures the shape, such as the half-extents of a box or the triangles of a concave (trimesh) shape. See [method shape_set_data] for the precise format of this data in each case.

### shape :: RID

## shape_get_margin :: func PhysicsServer3D.shape_get_margin(shape: RID) -> float
Returns the collision margin for the shape.
[b]Note:[/b] This is not used in Godot Physics, so will always return [code]0[/code].

### shape :: RID

## shape_get_type :: func PhysicsServer3D.shape_get_type(shape: RID) -> int
Returns the shape's type.

### shape :: RID

## shape_set_data :: func PhysicsServer3D.shape_set_data(shape: RID, data: Variant) -> void
Sets the shape data that configures the shape. The [param data] to be passed depends on the shape's type (see [method shape_get_type]):
- [constant SHAPE_WORLD_BOUNDARY]: a [Plane],
- [constant SHAPE_SEPARATION_RAY]: a dictionary containing the key [code]"length"[/code] with a [float] value and the key [code]"slide_on_slope"[/code] with a [bool] value,
- [constant SHAPE_SPHERE]: a [float] that is the radius of the sphere,
- [constant SHAPE_BOX]: a [Vector3] containing the half-extents of the box,
- [constant SHAPE_CAPSULE]: a dictionary containing the keys [code]"height"[/code] and [code]"radius"[/code] with [float] values,
- [constant SHAPE_CYLINDER]: a dictionary containing the keys [code]"height"[/code] and [code]"radius"[/code] with [float] values,
- [constant SHAPE_CONVEX_POLYGON]: a [PackedVector3Array] of points defining a convex polygon (the shape will be the convex hull of the points),
- [constant SHAPE_CONCAVE_POLYGON]: a dictionary containing the key [code]"faces"[/code] with a [PackedVector3Array] value (with a length divisible by 3, so that each 3-tuple of points forms a face) and the key [code]"backface_collision"[/code] with a [bool] value,
- [constant SHAPE_HEIGHTMAP]: a dictionary containing the keys [code]"width"[/code] and [code]"depth"[/code] with [int] values, and the key [code]"heights"[/code] with a value that is a packed array of [float]s of length [code]width * depth[/code] (that is a [PackedFloat32Array], or a [PackedFloat64Array] if Godot was compiled with the [code]precision=double[/code] option), and optionally the keys [code]"min_height"[/code] and [code]"max_height"[/code] with [float] values,
- [constant SHAPE_SOFT_BODY]: the input [param data] is ignored and this method has no effect,
- [constant SHAPE_CUSTOM]: the input [param data] is interpreted by a custom physics server, if it supports custom shapes.

### shape :: RID

### data :: Variant

## shape_set_margin :: func PhysicsServer3D.shape_set_margin(shape: RID, margin: float) -> void
Sets the collision margin for the shape.
[b]Note:[/b] This is not used in Godot Physics.

### shape :: RID

### margin :: float

## slider_joint_get_param :: func PhysicsServer3D.slider_joint_get_param(joint: RID, param: int) -> float
Gets a slider joint parameter.

### joint :: RID

### param :: int

## slider_joint_set_param :: func PhysicsServer3D.slider_joint_set_param(joint: RID, param: int, value: float) -> void
Gets a slider joint parameter.

### joint :: RID

### param :: int

### value :: float

## soft_body_add_collision_exception :: func PhysicsServer3D.soft_body_add_collision_exception(body: RID, body_b: RID) -> void
Adds the given body to the list of bodies exempt from collisions.

### body :: RID

### body_b :: RID

## soft_body_apply_central_force :: func PhysicsServer3D.soft_body_apply_central_force(body: RID, force: Vector3) -> void
Distributes and applies a force to all points. A force is time dependent and meant to be applied every physics update.

### body :: RID

### force :: Vector3

## soft_body_apply_central_impulse :: func PhysicsServer3D.soft_body_apply_central_impulse(body: RID, impulse: Vector3) -> void
Distributes and applies an impulse to all points.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).

### body :: RID

### impulse :: Vector3

## soft_body_apply_point_force :: func PhysicsServer3D.soft_body_apply_point_force(body: RID, point_index: int, force: Vector3) -> void
Applies a force to a point. A force is time dependent and meant to be applied every physics update.

### body :: RID

### point_index :: int

### force :: Vector3

## soft_body_apply_point_impulse :: func PhysicsServer3D.soft_body_apply_point_impulse(body: RID, point_index: int, impulse: Vector3) -> void
Applies an impulse to a point.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).

### body :: RID

### point_index :: int

### impulse :: Vector3

## soft_body_create :: func PhysicsServer3D.soft_body_create() -> RID
Creates a new soft body and returns its internal [RID].

## soft_body_get_bounds :: func PhysicsServer3D.soft_body_get_bounds(body: RID) -> AABB
Returns the bounds of the given soft body in global coordinates.

### body :: RID

## soft_body_get_collision_layer :: func PhysicsServer3D.soft_body_get_collision_layer(body: RID) -> int
Returns the physics layer or layers that the given soft body belongs to.

### body :: RID

## soft_body_get_collision_mask :: func PhysicsServer3D.soft_body_get_collision_mask(body: RID) -> int
Returns the physics layer or layers that the given soft body can collide with.

### body :: RID

## soft_body_get_damping_coefficient :: func PhysicsServer3D.soft_body_get_damping_coefficient(body: RID) -> float
Returns the damping coefficient of the given soft body.

### body :: RID

## soft_body_get_drag_coefficient :: func PhysicsServer3D.soft_body_get_drag_coefficient(body: RID) -> float
Returns the drag coefficient of the given soft body.

### body :: RID

## soft_body_get_linear_stiffness :: func PhysicsServer3D.soft_body_get_linear_stiffness(body: RID) -> float
Returns the linear stiffness of the given soft body.

### body :: RID

## soft_body_get_point_global_position :: func PhysicsServer3D.soft_body_get_point_global_position(body: RID, point_index: int) -> Vector3
Returns the current position of the given soft body point in global coordinates.

### body :: RID

### point_index :: int

## soft_body_get_pressure_coefficient :: func PhysicsServer3D.soft_body_get_pressure_coefficient(body: RID) -> float
Returns the pressure coefficient of the given soft body.

### body :: RID

## soft_body_get_shrinking_factor :: func PhysicsServer3D.soft_body_get_shrinking_factor(body: RID) -> float
Returns the shrinking factor of the given soft body.

### body :: RID

## soft_body_get_simulation_precision :: func PhysicsServer3D.soft_body_get_simulation_precision(body: RID) -> int
Returns the simulation precision of the given soft body.

### body :: RID

## soft_body_get_space :: func PhysicsServer3D.soft_body_get_space(body: RID) -> RID
Returns the [RID] of the space assigned to the given soft body.

### body :: RID

## soft_body_get_state :: func PhysicsServer3D.soft_body_get_state(body: RID, state: int) -> Variant
Returns the given soft body state.
[b]Note:[/b] Godot's default physics implementation does not support [constant BODY_STATE_LINEAR_VELOCITY], [constant BODY_STATE_ANGULAR_VELOCITY], [constant BODY_STATE_SLEEPING], or [constant BODY_STATE_CAN_SLEEP].

### body :: RID

### state :: int

## soft_body_get_total_mass :: func PhysicsServer3D.soft_body_get_total_mass(body: RID) -> float
Returns the total mass assigned to the given soft body.

### body :: RID

## soft_body_is_point_pinned :: func PhysicsServer3D.soft_body_is_point_pinned(body: RID, point_index: int) -> bool
Returns whether the given soft body point is pinned.

### body :: RID

### point_index :: int

## soft_body_move_point :: func PhysicsServer3D.soft_body_move_point(body: RID, point_index: int, global_position: Vector3) -> void
Moves the given soft body point to a position in global coordinates.

### body :: RID

### point_index :: int

### global_position :: Vector3

## soft_body_pin_point :: func PhysicsServer3D.soft_body_pin_point(body: RID, point_index: int, pin: bool) -> void
Pins or unpins the given soft body point based on the value of [param pin].
[b]Note:[/b] Pinning a point effectively makes it kinematic, preventing it from being affected by forces, but you can still move it using [method soft_body_move_point].

### body :: RID

### point_index :: int

### pin :: bool

## soft_body_remove_all_pinned_points :: func PhysicsServer3D.soft_body_remove_all_pinned_points(body: RID) -> void
Unpins all points of the given soft body.

### body :: RID

## soft_body_remove_collision_exception :: func PhysicsServer3D.soft_body_remove_collision_exception(body: RID, body_b: RID) -> void
Removes the given body from the list of bodies exempt from collisions.

### body :: RID

### body_b :: RID

## soft_body_set_collision_layer :: func PhysicsServer3D.soft_body_set_collision_layer(body: RID, layer: int) -> void
Sets the physics layer or layers the given soft body belongs to.

### body :: RID

### layer :: int

## soft_body_set_collision_mask :: func PhysicsServer3D.soft_body_set_collision_mask(body: RID, mask: int) -> void
Sets the physics layer or layers the given soft body can collide with.

### body :: RID

### mask :: int

## soft_body_set_damping_coefficient :: func PhysicsServer3D.soft_body_set_damping_coefficient(body: RID, damping_coefficient: float) -> void
Sets the damping coefficient of the given soft body. Higher values will slow down the body more noticeably when forces are applied.

### body :: RID

### damping_coefficient :: float

## soft_body_set_drag_coefficient :: func PhysicsServer3D.soft_body_set_drag_coefficient(body: RID, drag_coefficient: float) -> void
Sets the drag coefficient of the given soft body. Higher values increase this body's air resistance.
[b]Note:[/b] This value is currently unused by Godot's default physics implementation.

### body :: RID

### drag_coefficient :: float

## soft_body_set_linear_stiffness :: func PhysicsServer3D.soft_body_set_linear_stiffness(body: RID, stiffness: float) -> void
Sets the linear stiffness of the given soft body. Higher values will result in a stiffer body, while lower values will increase the body's ability to bend. The value can be between [code]0.0[/code] and [code]1.0[/code] (inclusive).

### body :: RID

### stiffness :: float

## soft_body_set_mesh :: func PhysicsServer3D.soft_body_set_mesh(body: RID, mesh: RID) -> void
Sets the mesh of the given soft body.

### body :: RID

### mesh :: RID

## soft_body_set_pressure_coefficient :: func PhysicsServer3D.soft_body_set_pressure_coefficient(body: RID, pressure_coefficient: float) -> void
Sets the pressure coefficient of the given soft body. Simulates pressure build-up from inside this body. Higher values increase the strength of this effect.

### body :: RID

### pressure_coefficient :: float

## soft_body_set_ray_pickable :: func PhysicsServer3D.soft_body_set_ray_pickable(body: RID, enable: bool) -> void
Sets whether the given soft body will be pickable when using object picking.

### body :: RID

### enable :: bool

## soft_body_set_shrinking_factor :: func PhysicsServer3D.soft_body_set_shrinking_factor(body: RID, shrinking_factor: float) -> void
Sets the shrinking factor of the given soft body.

### body :: RID

### shrinking_factor :: float

## soft_body_set_simulation_precision :: func PhysicsServer3D.soft_body_set_simulation_precision(body: RID, simulation_precision: int) -> void
Sets the simulation precision of the given soft body. Increasing this value will improve the resulting simulation, but can affect performance. Use with care.

### body :: RID

### simulation_precision :: int

## soft_body_set_space :: func PhysicsServer3D.soft_body_set_space(body: RID, space: RID) -> void
Assigns a space to the given soft body (see [method space_create]).

### body :: RID

### space :: RID

## soft_body_set_state :: func PhysicsServer3D.soft_body_set_state(body: RID, state: int, variant: Variant) -> void
Sets the given body state for the given body.
[b]Note:[/b] Godot's default physics implementation does not support [constant BODY_STATE_LINEAR_VELOCITY], [constant BODY_STATE_ANGULAR_VELOCITY], [constant BODY_STATE_SLEEPING], or [constant BODY_STATE_CAN_SLEEP].

### body :: RID

### state :: int

### variant :: Variant

## soft_body_set_total_mass :: func PhysicsServer3D.soft_body_set_total_mass(body: RID, total_mass: float) -> void
Sets the total mass for the given soft body.

### body :: RID

### total_mass :: float

## soft_body_set_transform :: func PhysicsServer3D.soft_body_set_transform(body: RID, transform: Transform3D) -> void
Sets the global transform of the given soft body.

### body :: RID

### transform :: Transform3D

## soft_body_update_rendering_server :: func PhysicsServer3D.soft_body_update_rendering_server(body: RID, rendering_server_handler: PhysicsServer3DRenderingServerHandler) -> void
Requests that the physics server updates the rendering server with the latest positions of the given soft body's points through the [param rendering_server_handler] interface.

### body :: RID

### rendering_server_handler :: PhysicsServer3DRenderingServerHandler

## space_create :: func PhysicsServer3D.space_create() -> RID
Creates a space. A space is a collection of parameters for the physics engine that can be assigned to an area or a body. It can be assigned to an area with [method area_set_space], or to a body with [method body_set_space].

## space_get_direct_state :: func PhysicsServer3D.space_get_direct_state(space: RID) -> PhysicsDirectSpaceState3D
Returns the state of a space, a [PhysicsDirectSpaceState3D]. This object can be used to make collision/intersection queries.

### space :: RID

## space_get_param :: func PhysicsServer3D.space_get_param(space: RID, param: int) -> float
Returns the value of a space parameter.

### space :: RID

### param :: int

## space_is_active :: func PhysicsServer3D.space_is_active(space: RID) -> bool
Returns whether the space is active.

### space :: RID

## space_set_active :: func PhysicsServer3D.space_set_active(space: RID, active: bool) -> void
Marks a space as active. It will not have an effect, unless it is assigned to an area or body.

### space :: RID

### active :: bool

## space_set_param :: func PhysicsServer3D.space_set_param(space: RID, param: int, value: float) -> void
Sets the value for a space parameter. A list of available parameters is on the [enum SpaceParameter] constants.

### space :: RID

### param :: int

### value :: float

## sphere_shape_create :: func PhysicsServer3D.sphere_shape_create() -> RID
Creates a 3D sphere shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the sphere's radius.

## world_boundary_shape_create :: func PhysicsServer3D.world_boundary_shape_create() -> RID
Creates a 3D world boundary shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the shape's normal direction and distance properties.
