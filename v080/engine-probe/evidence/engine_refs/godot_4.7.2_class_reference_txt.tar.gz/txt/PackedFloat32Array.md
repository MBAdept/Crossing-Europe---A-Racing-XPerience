# PackedFloat32Array :: <Native> class PackedFloat32Array
A packed array of 32-bit floating-point values.
An array specifically designed to hold 32-bit floating-point values (float). Packs data tightly, so it saves memory for large array sizes.
If you need to pack 64-bit floats tightly, see [PackedFloat64Array].
[b]Note:[/b] Packed arrays are always passed by reference. To get a copy of an array that can be modified independently of the original array, use [method duplicate]. This is [i]not[/i] the case for built-in properties and methods. In these cases the returned packed array is a copy, and changing it will [i]not[/i] affect the original value. To update a built-in property of this type, modify the returned array and then assign it to the property again.
[b]Note:[/b] In a boolean context, a packed array will evaluate to [code]false[/code] if it's empty. Otherwise, a packed array will always evaluate to [code]true[/code].

## append :: func PackedFloat32Array.append(value: float) -> bool
Appends an element at the end of the array (alias of [method push_back]).

### value :: float

## append_array :: func PackedFloat32Array.append_array(array: PackedFloat32Array) -> void
Appends a [PackedFloat32Array] at the end of this array.

### array :: PackedFloat32Array

## bsearch :: func PackedFloat32Array.bsearch(value: float, before: bool = true) -> int
Finds the index of an existing value (or the insertion index that maintains sorting order, if the value is not yet present in the array) using binary search. Optionally, a [param before] specifier can be passed. If [code]false[/code], the returned index comes after all existing entries of the value in the array.
[b]Note:[/b] Calling [method bsearch] on an unsorted array results in unexpected behavior.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

### before :: bool

## clear :: func PackedFloat32Array.clear() -> void
Clears the array. This is equivalent to using [method resize] with a size of [code]0[/code].

## count :: func PackedFloat32Array.count(value: float) -> int
Returns the number of times an element is in the array.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

## duplicate :: func PackedFloat32Array.duplicate() -> PackedFloat32Array
Creates a copy of the array, and returns it.

## erase :: func PackedFloat32Array.erase(value: float) -> bool
Removes the first occurrence of a value from the array and returns [code]true[/code]. If the value does not exist in the array, nothing happens and [code]false[/code] is returned. To remove an element by index, use [method remove_at] instead.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

## fill :: func PackedFloat32Array.fill(value: float) -> void
Assigns the given value to all elements in the array. This can typically be used together with [method resize] to create an array with a given size and initialized elements.

### value :: float

## find :: func PackedFloat32Array.find(value: float, from: int = 0) -> int
Searches the array for a value and returns its index or [code]-1[/code] if not found. Optionally, the initial search index can be passed.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

### from :: int

## get :: func PackedFloat32Array.get(index: int) -> float
Returns the 32-bit float at the given [param index] in the array. If [param index] is out-of-bounds or negative, this method fails and returns [code]0.0[/code].
This method is similar (but not identical) to the [code][][/code] operator. Most notably, when this method fails, it doesn't pause project execution if run from the editor.

### index :: int

## has :: func PackedFloat32Array.has(value: float) -> bool
Returns [code]true[/code] if the array contains [param value].
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

## insert :: func PackedFloat32Array.insert(at_index: int, value: float) -> int
Inserts a new element at a given position in the array. The position must be valid, or at the end of the array ([code]idx == size()[/code]).

### at_index :: int

### value :: float

## is_empty :: func PackedFloat32Array.is_empty() -> bool
Returns [code]true[/code] if the array is empty.

## push_back :: func PackedFloat32Array.push_back(value: float) -> bool
Appends an element at the end of the array.

### value :: float

## remove_at :: func PackedFloat32Array.remove_at(index: int) -> void
Removes an element from the array by index.

### index :: int

## resize :: func PackedFloat32Array.resize(new_size: int) -> int
Sets the size of the array. If the array is grown, reserves elements at the end of the array. If the array is shrunk, truncates the array to the new size. Calling [method resize] once and assigning the new values is faster than adding new elements one by one.
Returns [constant OK] on success, or one of the following [enum Error] constants if this method fails: [constant ERR_INVALID_PARAMETER] if the size is negative, or [constant ERR_OUT_OF_MEMORY] if allocations fail. Use [method size] to find the actual size of the array after resize.

### new_size :: int

## reverse :: func PackedFloat32Array.reverse() -> void
Reverses the order of the elements in the array.

## rfind :: func PackedFloat32Array.rfind(value: float, from: int = -1) -> int
Searches the array in reverse order. Optionally, a start search index can be passed. If negative, the start index is considered relative to the end of the array.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

### from :: int

## set :: func PackedFloat32Array.set(index: int, value: float) -> void
Changes the float at the given index.

### index :: int

### value :: float

## size :: func PackedFloat32Array.size() -> int
Returns the number of elements in the array.

## slice :: func PackedFloat32Array.slice(begin: int, end: int = 2147483647) -> PackedFloat32Array
Returns the slice of the [PackedFloat32Array], from [param begin] (inclusive) to [param end] (exclusive), as a new [PackedFloat32Array].
The absolute value of [param begin] and [param end] will be clamped to the array size, so the default value for [param end] makes it slice to the size of the array by default (i.e. [code]arr.slice(1)[/code] is a shorthand for [code]arr.slice(1, arr.size())[/code]).
If either [param begin] or [param end] are negative, they will be relative to the end of the array (i.e. [code]arr.slice(0, -2)[/code] is a shorthand for [code]arr.slice(0, arr.size() - 2)[/code]).

### begin :: int

### end :: int

## sort :: func PackedFloat32Array.sort() -> void
Sorts the elements of the array in ascending order.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

## to_byte_array :: func PackedFloat32Array.to_byte_array() -> PackedByteArray
Returns a copy of the data converted to a [PackedByteArray], where each element has been encoded as 4 bytes.
The size of the new array will be [code]float32_array.size() * 4[/code].

## PackedFloat32Array :: func PackedFloat32Array.PackedFloat32Array() -> PackedFloat32Array
Constructs an empty [PackedFloat32Array].

## PackedFloat32Array :: func PackedFloat32Array.PackedFloat32Array(from: PackedFloat32Array) -> PackedFloat32Array
Constructs a [PackedFloat32Array] as a copy of the given [PackedFloat32Array].

### from :: PackedFloat32Array

## PackedFloat32Array :: func PackedFloat32Array.PackedFloat32Array(from: Array) -> PackedFloat32Array
Constructs a new [PackedFloat32Array]. Optionally, you can pass in a generic [Array] that will be converted.

### from :: Array

## operator != :: func PackedFloat32Array.operator !=(right: PackedFloat32Array) -> bool
Returns [code]true[/code] if contents of the arrays differ.

### right :: PackedFloat32Array

## operator + :: func PackedFloat32Array.operator +(right: PackedFloat32Array) -> PackedFloat32Array
Returns a new [PackedFloat32Array] with contents of [param right] added at the end of this array. For better performance, consider using [method append_array] instead.

### right :: PackedFloat32Array

## operator == :: func PackedFloat32Array.operator ==(right: PackedFloat32Array) -> bool
Returns [code]true[/code] if contents of both arrays are the same, i.e. they have all equal floats at the corresponding indices.

### right :: PackedFloat32Array

## operator [] :: func PackedFloat32Array.operator [](index: int) -> float
Returns the [float] at index [param index]. Negative indices can be used to access the elements starting from the end. Using index out of array's bounds will result in an error.
Note that [float] type is 64-bit, unlike the values stored in the array.

### index :: int
