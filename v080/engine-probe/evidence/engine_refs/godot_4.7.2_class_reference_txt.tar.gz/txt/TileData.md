# TileData :: <Native> class TileData extends Object
Settings for a single tile in a [TileSet].
[TileData] object represents a single tile in a [TileSet]. It is usually edited using the tileset editor, but it can be modified at runtime using [method TileMapLayer._tile_data_runtime_update].

## flip_h :: var TileData.flip_h: bool
If [code]true[/code], the tile will have its texture flipped horizontally.

## flip_v :: var TileData.flip_v: bool
If [code]true[/code], the tile will have its texture flipped vertically.

## material :: var TileData.material: Material
The [Material] to use for this [TileData]. This can be a [CanvasItemMaterial] to use the default shader, or a [ShaderMaterial] to use a custom shader.

## modulate :: var TileData.modulate: Color
Color modulation of the tile.

## probability :: var TileData.probability: float
Relative probability of this tile being selected when drawing a pattern of random tiles.

## terrain :: var TileData.terrain: int
ID of the terrain from the terrain set that the tile uses.

## terrain_set :: var TileData.terrain_set: int
ID of the terrain set that the tile uses.

## texture_origin :: var TileData.texture_origin: Vector2i
Offsets the position of where the tile is drawn.

## transpose :: var TileData.transpose: bool
If [code]true[/code], the tile will display transposed, i.e. with horizontal and vertical texture UVs swapped.

## y_sort_origin :: var TileData.y_sort_origin: int
Vertical point of the tile used for determining y-sorted order.

## z_index :: var TileData.z_index: int
Ordering index of this tile, relative to [TileMapLayer].

## add_collision_polygon :: func TileData.add_collision_polygon(layer_id: int) -> void
Adds a collision polygon to the tile on the given TileSet physics layer.

### layer_id :: int

## add_occluder_polygon :: func TileData.add_occluder_polygon(layer_id: int) -> void
Adds an occlusion polygon to the tile on the TileSet occlusion layer with index [param layer_id].

### layer_id :: int

## get_collision_polygon_one_way_margin :: func TileData.get_collision_polygon_one_way_margin(layer_id: int, polygon_index: int) -> float
Returns the one-way margin (for one-way platforms) of the polygon at index [param polygon_index] for TileSet physics layer with index [param layer_id].

### layer_id :: int

### polygon_index :: int

## get_collision_polygon_points :: func TileData.get_collision_polygon_points(layer_id: int, polygon_index: int) -> PackedVector2Array
Returns the points of the polygon at index [param polygon_index] for TileSet physics layer with index [param layer_id].

### layer_id :: int

### polygon_index :: int

## get_collision_polygons_count :: func TileData.get_collision_polygons_count(layer_id: int) -> int
Returns how many polygons the tile has for TileSet physics layer with index [param layer_id].

### layer_id :: int

## get_constant_angular_velocity :: func TileData.get_constant_angular_velocity(layer_id: int) -> float
Returns the constant angular velocity applied to objects colliding with this tile.

### layer_id :: int

## get_constant_linear_velocity :: func TileData.get_constant_linear_velocity(layer_id: int) -> Vector2
Returns the constant linear velocity applied to objects colliding with this tile.

### layer_id :: int

## get_custom_data :: func TileData.get_custom_data(layer_name: String) -> Variant
Returns the custom data value for custom data layer named [param layer_name]. To check if a custom data layer exists, use [method has_custom_data].

### layer_name :: String

## get_custom_data_by_layer_id :: func TileData.get_custom_data_by_layer_id(layer_id: int) -> Variant
Returns the custom data value for custom data layer with index [param layer_id].

### layer_id :: int

## get_navigation_polygon :: func TileData.get_navigation_polygon(layer_id: int, flip_h: bool = false, flip_v: bool = false, transpose: bool = false) -> NavigationPolygon
Returns the navigation polygon of the tile for the TileSet navigation layer with index [param layer_id].
[param flip_h], [param flip_v], and [param transpose] allow transforming the returned polygon.

### layer_id :: int

### flip_h :: bool

### flip_v :: bool

### transpose :: bool

## get_occluder :: func TileData.get_occluder(layer_id: int, flip_h: bool = false, flip_v: bool = false, transpose: bool = false) -> OccluderPolygon2D
Returns the occluder polygon of the tile for the TileSet occlusion layer with index [param layer_id].
[param flip_h], [param flip_v], and [param transpose] allow transforming the returned polygon.

### layer_id :: int

### flip_h :: bool

### flip_v :: bool

### transpose :: bool

## get_occluder_polygon :: func TileData.get_occluder_polygon(layer_id: int, polygon_index: int, flip_h: bool = false, flip_v: bool = false, transpose: bool = false) -> OccluderPolygon2D
Returns the occluder polygon at index [param polygon_index] from the TileSet occlusion layer with index [param layer_id].
The [param flip_h], [param flip_v], and [param transpose] parameters can be [code]true[/code] to transform the returned polygon.

### layer_id :: int

### polygon_index :: int

### flip_h :: bool

### flip_v :: bool

### transpose :: bool

## get_occluder_polygons_count :: func TileData.get_occluder_polygons_count(layer_id: int) -> int
Returns the number of occluder polygons of the tile in the TileSet occlusion layer with index [param layer_id].

### layer_id :: int

## get_terrain_peering_bit :: func TileData.get_terrain_peering_bit(peering_bit: int) -> int
Returns the tile's terrain bit for the given [param peering_bit] direction. To check that a direction is valid, use [method is_valid_terrain_peering_bit].

### peering_bit :: int

## has_custom_data :: func TileData.has_custom_data(layer_name: String) -> bool
Returns whether there exists a custom data layer named [param layer_name].

### layer_name :: String

## is_collision_polygon_one_way :: func TileData.is_collision_polygon_one_way(layer_id: int, polygon_index: int) -> bool
Returns whether one-way collisions are enabled for the polygon at index [param polygon_index] for TileSet physics layer with index [param layer_id].

### layer_id :: int

### polygon_index :: int

## is_valid_terrain_peering_bit :: func TileData.is_valid_terrain_peering_bit(peering_bit: int) -> bool
Returns whether the given [param peering_bit] direction is valid for this tile.

### peering_bit :: int

## remove_collision_polygon :: func TileData.remove_collision_polygon(layer_id: int, polygon_index: int) -> void
Removes the polygon at index [param polygon_index] for TileSet physics layer with index [param layer_id].

### layer_id :: int

### polygon_index :: int

## remove_occluder_polygon :: func TileData.remove_occluder_polygon(layer_id: int, polygon_index: int) -> void
Removes the polygon at index [param polygon_index] for TileSet occlusion layer with index [param layer_id].

### layer_id :: int

### polygon_index :: int

## set_collision_polygon_one_way :: func TileData.set_collision_polygon_one_way(layer_id: int, polygon_index: int, one_way: bool) -> void
Enables/disables one-way collisions on the polygon at index [param polygon_index] for TileSet physics layer with index [param layer_id].

### layer_id :: int

### polygon_index :: int

### one_way :: bool

## set_collision_polygon_one_way_margin :: func TileData.set_collision_polygon_one_way_margin(layer_id: int, polygon_index: int, one_way_margin: float) -> void
Sets the one-way margin (for one-way platforms) of the polygon at index [param polygon_index] for TileSet physics layer with index [param layer_id].

### layer_id :: int

### polygon_index :: int

### one_way_margin :: float

## set_collision_polygon_points :: func TileData.set_collision_polygon_points(layer_id: int, polygon_index: int, polygon: PackedVector2Array) -> void
Sets the points of the polygon at index [param polygon_index] for TileSet physics layer with index [param layer_id].

### layer_id :: int

### polygon_index :: int

### polygon :: PackedVector2Array

## set_collision_polygons_count :: func TileData.set_collision_polygons_count(layer_id: int, polygons_count: int) -> void
Sets the polygons count for TileSet physics layer with index [param layer_id].

### layer_id :: int

### polygons_count :: int

## set_constant_angular_velocity :: func TileData.set_constant_angular_velocity(layer_id: int, velocity: float) -> void
Sets the constant angular velocity. This does not rotate the tile. This angular velocity is applied to objects colliding with this tile.

### layer_id :: int

### velocity :: float

## set_constant_linear_velocity :: func TileData.set_constant_linear_velocity(layer_id: int, velocity: Vector2) -> void
Sets the constant linear velocity. This does not move the tile. This linear velocity is applied to objects colliding with this tile. This is useful to create conveyor belts.

### layer_id :: int

### velocity :: Vector2

## set_custom_data :: func TileData.set_custom_data(layer_name: String, value: Variant) -> void
Sets the tile's custom data value for the TileSet custom data layer with name [param layer_name].

### layer_name :: String

### value :: Variant

## set_custom_data_by_layer_id :: func TileData.set_custom_data_by_layer_id(layer_id: int, value: Variant) -> void
Sets the tile's custom data value for the TileSet custom data layer with index [param layer_id].

### layer_id :: int

### value :: Variant

## set_navigation_polygon :: func TileData.set_navigation_polygon(layer_id: int, navigation_polygon: NavigationPolygon) -> void
Sets the navigation polygon for the TileSet navigation layer with index [param layer_id].

### layer_id :: int

### navigation_polygon :: NavigationPolygon

## set_occluder :: func TileData.set_occluder(layer_id: int, occluder_polygon: OccluderPolygon2D) -> void
Sets the occluder for the TileSet occlusion layer with index [param layer_id].

### layer_id :: int

### occluder_polygon :: OccluderPolygon2D

## set_occluder_polygon :: func TileData.set_occluder_polygon(layer_id: int, polygon_index: int, polygon: OccluderPolygon2D) -> void
Sets the occluder for polygon with index [param polygon_index] in the TileSet occlusion layer with index [param layer_id].

### layer_id :: int

### polygon_index :: int

### polygon :: OccluderPolygon2D

## set_occluder_polygons_count :: func TileData.set_occluder_polygons_count(layer_id: int, polygons_count: int) -> void
Sets the occluder polygon count in the TileSet occlusion layer with index [param layer_id].

### layer_id :: int

### polygons_count :: int

## set_terrain_peering_bit :: func TileData.set_terrain_peering_bit(peering_bit: int, terrain: int) -> void
Sets the tile's terrain bit for the given [param peering_bit] direction. To check that a direction is valid, use [method is_valid_terrain_peering_bit].

### peering_bit :: int

### terrain :: int

## changed :: func TileData.changed() -> void
Emitted when any of the properties are changed.
