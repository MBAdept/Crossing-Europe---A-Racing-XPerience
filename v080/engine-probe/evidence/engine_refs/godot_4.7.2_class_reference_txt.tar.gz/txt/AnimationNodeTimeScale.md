# AnimationNodeTimeScale :: <Native> class AnimationNodeTimeScale extends AnimationNode
A time-scaling animation node used in [AnimationTree].
Allows to scale the speed of the animation (or reverse it) in any child [AnimationNode]s. Setting it to [code]0.0[/code] will pause the animation.
