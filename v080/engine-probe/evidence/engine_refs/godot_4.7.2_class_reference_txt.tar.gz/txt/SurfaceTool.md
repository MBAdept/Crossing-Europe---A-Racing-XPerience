# SurfaceTool :: <Native> class SurfaceTool extends RefCounted
Helper tool to create geometry.
The [SurfaceTool] is used to construct a [Mesh] by specifying vertex attributes individually. It can be used to construct a [Mesh] from a script. All properties except indices need to be added before calling [method add_vertex]. For example, to add vertex colors and UVs:
[codeblocks]
[gdscript]
var st = SurfaceTool.new()
st.begin(Mesh.PRIMITIVE_TRIANGLES)
st.set_color(Color(1, 0, 0))
st.set_uv(Vector2(0, 0))
st.add_vertex(Vector3(0, 0, 0))
[/gdscript]
[csharp]
var st = new SurfaceTool();
st.Begin(Mesh.PrimitiveType.Triangles);
st.SetColor(new Color(1, 0, 0));
st.SetUV(new Vector2(0, 0));
st.AddVertex(new Vector3(0, 0, 0));
[/csharp]
[/codeblocks]
The above [SurfaceTool] now contains one vertex of a triangle which has a UV coordinate and a specified [Color]. If another vertex were added without calling [method set_uv] or [method set_color], then the last values would be used.
Vertex attributes must be passed [b]before[/b] calling [method add_vertex]. Failure to do so will result in an error when committing the vertex information to a mesh.
Additionally, the attributes used before the first vertex is added determine the format of the mesh. For example, if you only add UVs to the first vertex, you cannot add color to any of the subsequent vertices.
See also [ArrayMesh], [ImmediateMesh] and [MeshDataTool] for procedural geometry generation.
[b]Note:[/b] Godot uses clockwise [url=https://learnopengl.com/Advanced-OpenGL/Face-culling]winding order[/url] for front faces of triangle primitive modes.

## CUSTOM_RGBA8_UNORM :: const SurfaceTool.CUSTOM_RGBA8_UNORM: CustomFormat = 0
Limits range of data passed to [method set_custom] to unsigned normalized 0 to 1 stored in 8 bits per channel. See [constant Mesh.ARRAY_CUSTOM_RGBA8_UNORM].

## CUSTOM_RGBA8_SNORM :: const SurfaceTool.CUSTOM_RGBA8_SNORM: CustomFormat = 1
Limits range of data passed to [method set_custom] to signed normalized -1 to 1 stored in 8 bits per channel. See [constant Mesh.ARRAY_CUSTOM_RGBA8_SNORM].

## CUSTOM_RG_HALF :: const SurfaceTool.CUSTOM_RG_HALF: CustomFormat = 2
Stores data passed to [method set_custom] as half precision floats, and uses only red and green color channels. See [constant Mesh.ARRAY_CUSTOM_RG_HALF].

## CUSTOM_RGBA_HALF :: const SurfaceTool.CUSTOM_RGBA_HALF: CustomFormat = 3
Stores data passed to [method set_custom] as half precision floats and uses all color channels. See [constant Mesh.ARRAY_CUSTOM_RGBA_HALF].

## CUSTOM_R_FLOAT :: const SurfaceTool.CUSTOM_R_FLOAT: CustomFormat = 4
Stores data passed to [method set_custom] as full precision floats, and uses only red color channel. See [constant Mesh.ARRAY_CUSTOM_R_FLOAT].

## CUSTOM_RG_FLOAT :: const SurfaceTool.CUSTOM_RG_FLOAT: CustomFormat = 5
Stores data passed to [method set_custom] as full precision floats, and uses only red and green color channels. See [constant Mesh.ARRAY_CUSTOM_RG_FLOAT].

## CUSTOM_RGB_FLOAT :: const SurfaceTool.CUSTOM_RGB_FLOAT: CustomFormat = 6
Stores data passed to [method set_custom] as full precision floats, and uses only red, green and blue color channels. See [constant Mesh.ARRAY_CUSTOM_RGB_FLOAT].

## CUSTOM_RGBA_FLOAT :: const SurfaceTool.CUSTOM_RGBA_FLOAT: CustomFormat = 7
Stores data passed to [method set_custom] as full precision floats, and uses all color channels. See [constant Mesh.ARRAY_CUSTOM_RGBA_FLOAT].

## CUSTOM_MAX :: const SurfaceTool.CUSTOM_MAX: CustomFormat = 8
Used to indicate a disabled custom channel.

## SKIN_4_WEIGHTS :: const SurfaceTool.SKIN_4_WEIGHTS: SkinWeightCount = 0
Each individual vertex can be influenced by only 4 bone weights.

## SKIN_8_WEIGHTS :: const SurfaceTool.SKIN_8_WEIGHTS: SkinWeightCount = 1
Each individual vertex can be influenced by up to 8 bone weights.

## add_index :: func SurfaceTool.add_index(index: int) -> void
Adds a vertex to index array if you are using indexed vertices. Does not need to be called before adding vertices.

### index :: int

## add_triangle_fan :: func SurfaceTool.add_triangle_fan(vertices: PackedVector3Array, uvs: PackedVector2Array = PackedVector2Array(), colors: PackedColorArray = PackedColorArray(), uv2s: PackedVector2Array = PackedVector2Array(), normals: PackedVector3Array = PackedVector3Array(), tangents: Plane[] = []) -> void
Inserts a triangle fan made of array data into [Mesh] being constructed.
Requires the primitive type be set to [constant Mesh.PRIMITIVE_TRIANGLES].

### vertices :: PackedVector3Array

### uvs :: PackedVector2Array

### colors :: PackedColorArray

### uv2s :: PackedVector2Array

### normals :: PackedVector3Array

### tangents :: Plane[]

## add_vertex :: func SurfaceTool.add_vertex(vertex: Vector3) -> void
Specifies the position of current vertex. Should be called after specifying other vertex properties (e.g. Color, UV).

### vertex :: Vector3

## append_from :: func SurfaceTool.append_from(existing: Mesh, surface: int, transform: Transform3D) -> void
Append vertices from a given [Mesh] surface onto the current vertex array with specified [Transform3D].

### existing :: Mesh

### surface :: int

### transform :: Transform3D

## begin :: func SurfaceTool.begin(primitive: int) -> void
Called before adding any vertices. Takes the primitive type as an argument (e.g. [constant Mesh.PRIMITIVE_TRIANGLES]).

### primitive :: int

## clear :: func SurfaceTool.clear() -> void
Clear all information passed into the surface tool so far.

## commit :: func SurfaceTool.commit(existing: ArrayMesh = null, flags: int = 0) -> ArrayMesh
Returns a constructed [ArrayMesh] from current information passed in. If an existing [ArrayMesh] is passed in as an argument, will add an extra surface to the existing [ArrayMesh].
The [param flags] argument can be the bitwise OR of [constant Mesh.ARRAY_FLAG_USE_DYNAMIC_UPDATE], [constant Mesh.ARRAY_FLAG_USE_8_BONE_WEIGHTS], or [constant Mesh.ARRAY_FLAG_USES_EMPTY_VERTEX_ARRAY].

### existing :: ArrayMesh

### flags :: int

## commit_to_arrays :: func SurfaceTool.commit_to_arrays() -> Array
Commits the data to the same format used by [method ArrayMesh.add_surface_from_arrays], [method ImporterMesh.add_surface], and [method create_from_arrays]. This way you can further process the mesh data using the [ArrayMesh] or [ImporterMesh] APIs.

## create_from :: func SurfaceTool.create_from(existing: Mesh, surface: int) -> void
Creates a vertex array from an existing [Mesh].

### existing :: Mesh

### surface :: int

## create_from_arrays :: func SurfaceTool.create_from_arrays(arrays: Array, primitive_type: int = 3) -> void
Creates this SurfaceTool from existing vertex arrays such as returned by [method commit_to_arrays], [method Mesh.surface_get_arrays], [method Mesh.surface_get_blend_shape_arrays], [method ImporterMesh.get_surface_arrays], and [method ImporterMesh.get_surface_blend_shape_arrays]. [param primitive_type] controls the type of mesh data, defaulting to [constant Mesh.PRIMITIVE_TRIANGLES].

### arrays :: Array

### primitive_type :: int

## create_from_blend_shape :: func SurfaceTool.create_from_blend_shape(existing: Mesh, surface: int, blend_shape: String) -> void
Creates a vertex array from the specified blend shape of an existing [Mesh]. This can be used to extract a specific pose from a blend shape.

### existing :: Mesh

### surface :: int

### blend_shape :: String

## deindex :: func SurfaceTool.deindex() -> void
Removes the index array by expanding the vertex array.

## generate_lod :: func SurfaceTool.generate_lod(nd_threshold: float, target_index_count: int = 3) -> PackedInt32Array
Generates an LOD for a given [param nd_threshold] in linear units (square root of quadric error metric), using at most [param target_index_count] indices.

### nd_threshold :: float

### target_index_count :: int

## generate_normals :: func SurfaceTool.generate_normals(flip: bool = false) -> void
Generates normals from vertices so you do not have to do it manually. If [param flip] is [code]true[/code], the resulting normals will be inverted. [method generate_normals] should be called [i]after[/i] generating geometry and [i]before[/i] committing the mesh using [method commit] or [method commit_to_arrays]. For correct display of normal-mapped surfaces, you will also have to generate tangents using [method generate_tangents].
[b]Note:[/b] [method generate_normals] only works if the primitive type is set to [constant Mesh.PRIMITIVE_TRIANGLES].
[b]Note:[/b] [method generate_normals] takes smooth groups into account. To generate smooth normals, set the smooth group to a value greater than or equal to [code]0[/code] using [method set_smooth_group] or leave the smooth group at the default of [code]0[/code]. To generate flat normals, set the smooth group to [code]-1[/code] using [method set_smooth_group] prior to adding vertices.

### flip :: bool

## generate_tangents :: func SurfaceTool.generate_tangents() -> void
Generates a tangent vector for each vertex. Requires that each vertex already has UVs and normals set (see [method generate_normals]).

## get_aabb :: func SurfaceTool.get_aabb() -> AABB
Returns the axis-aligned bounding box of the vertex positions.

## get_custom_format :: func SurfaceTool.get_custom_format(channel_index: int) -> int
Returns the format for custom [param channel_index] (currently up to 4). Returns [constant CUSTOM_MAX] if this custom channel is unused.

### channel_index :: int

## get_primitive_type :: func SurfaceTool.get_primitive_type() -> int
Returns the type of mesh geometry, such as [constant Mesh.PRIMITIVE_TRIANGLES].

## get_skin_weight_count :: func SurfaceTool.get_skin_weight_count() -> int
By default, returns [constant SKIN_4_WEIGHTS] to indicate only 4 bone influences per vertex are used.
Returns [constant SKIN_8_WEIGHTS] if up to 8 influences are used.
[b]Note:[/b] This function returns an enum, not the exact number of weights.

## index :: func SurfaceTool.index() -> void
Shrinks the vertex array by creating an index array. This can improve performance by avoiding vertex reuse.

## optimize_indices_for_cache :: func SurfaceTool.optimize_indices_for_cache() -> void
Optimizes triangle sorting for performance. Requires that [method get_primitive_type] is [constant Mesh.PRIMITIVE_TRIANGLES].

## set_bones :: func SurfaceTool.set_bones(bones: PackedInt32Array) -> void
Specifies an array of bones to use for the [i]next[/i] vertex. [param bones] must contain 4 integers.

### bones :: PackedInt32Array

## set_color :: func SurfaceTool.set_color(color: Color) -> void
Specifies a [Color] to use for the [i]next[/i] vertex. If every vertex needs to have this information set and you fail to submit it for the first vertex, this information may not be used at all.
[b]Note:[/b] The material must have [member BaseMaterial3D.vertex_color_use_as_albedo] enabled for the vertex color to be visible.

### color :: Color

## set_custom :: func SurfaceTool.set_custom(channel_index: int, custom_color: Color) -> void
Sets the custom value on this vertex for [param channel_index].
[method set_custom_format] must be called first for this [param channel_index]. Formats which are not RGBA will ignore other color channels.

### channel_index :: int

### custom_color :: Color

## set_custom_format :: func SurfaceTool.set_custom_format(channel_index: int, format: int) -> void
Sets the color format for this custom [param channel_index]. Use [constant CUSTOM_MAX] to disable.
Must be invoked after [method begin] and should be set before [method commit] or [method commit_to_arrays].

### channel_index :: int

### format :: int

## set_material :: func SurfaceTool.set_material(material: Material) -> void
Sets [Material] to be used by the [Mesh] you are constructing.

### material :: Material

## set_normal :: func SurfaceTool.set_normal(normal: Vector3) -> void
Specifies a normal to use for the [i]next[/i] vertex. If every vertex needs to have this information set and you fail to submit it for the first vertex, this information may not be used at all.

### normal :: Vector3

## set_skin_weight_count :: func SurfaceTool.set_skin_weight_count(count: int) -> void
Set to [constant SKIN_8_WEIGHTS] to indicate that up to 8 bone influences per vertex may be used.
By default, only 4 bone influences are used ([constant SKIN_4_WEIGHTS]).
[b]Note:[/b] This function takes an enum, not the exact number of weights.

### count :: int

## set_smooth_group :: func SurfaceTool.set_smooth_group(index: int) -> void
Specifies the smooth group to use for the [i]next[/i] vertex. If this is never called, all vertices will have the default smooth group of [code]0[/code] and will be smoothed with adjacent vertices of the same group. To produce a mesh with flat normals, set the smooth group to [code]-1[/code].
[b]Note:[/b] This function actually takes a [code]uint32_t[/code], so C# users should use [code]uint32.MaxValue[/code] instead of [code]-1[/code] to produce a mesh with flat normals.

### index :: int

## set_tangent :: func SurfaceTool.set_tangent(tangent: Plane) -> void
Specifies a tangent to use for the [i]next[/i] vertex. If every vertex needs to have this information set and you fail to submit it for the first vertex, this information may not be used at all.
[b]Note:[/b] Even though [param tangent] is a [Plane], it does not directly represent the tangent plane. Its [member Plane.x], [member Plane.y], and [member Plane.z] represent the tangent vector and [member Plane.d] should be either [code]-1[/code] or [code]1[/code]. See also [constant Mesh.ARRAY_TANGENT].

### tangent :: Plane

## set_uv :: func SurfaceTool.set_uv(uv: Vector2) -> void
Specifies a set of UV coordinates to use for the [i]next[/i] vertex. If every vertex needs to have this information set and you fail to submit it for the first vertex, this information may not be used at all.

### uv :: Vector2

## set_uv2 :: func SurfaceTool.set_uv2(uv2: Vector2) -> void
Specifies an optional second set of UV coordinates to use for the [i]next[/i] vertex. If every vertex needs to have this information set and you fail to submit it for the first vertex, this information may not be used at all.

### uv2 :: Vector2

## set_weights :: func SurfaceTool.set_weights(weights: PackedFloat32Array) -> void
Specifies weight values to use for the [i]next[/i] vertex. [param weights] must contain 4 values. If every vertex needs to have this information set and you fail to submit it for the first vertex, this information may not be used at all.

### weights :: PackedFloat32Array
