# XRFaceModifier3D :: <Native> class XRFaceModifier3D extends Node3D
A node for driving standard face meshes from [XRFaceTracker] weights.
This node applies weights from an [XRFaceTracker] to a mesh with supporting face blend shapes.
The [url=https://docs.vrcft.io/docs/tutorial-avatars/tutorial-avatars-extras/unified-blendshapes]Unified Expressions[/url] blend shapes are supported, as well as ARKit and SRanipal blend shapes.
The node attempts to identify blend shapes based on name matching. Blend shapes should match the names listed in the [url=https://docs.vrcft.io/docs/tutorial-avatars/tutorial-avatars-extras/compatibility/overview]Unified Expressions Compatibility[/url] chart.

## face_tracker :: var XRFaceModifier3D.face_tracker: StringName
The [XRFaceTracker] path.

## target :: var XRFaceModifier3D.target: NodePath
The [NodePath] of the face [MeshInstance3D].
