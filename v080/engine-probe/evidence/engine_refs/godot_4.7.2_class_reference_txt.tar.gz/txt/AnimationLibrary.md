# AnimationLibrary :: <Native> class AnimationLibrary extends Resource
Container for [Animation] resources.
An animation library stores a set of animations accessible through [StringName] keys, for use with [AnimationPlayer] nodes.

## add_animation :: func AnimationLibrary.add_animation(name: StringName, animation: Animation) -> int
Adds the [param animation] to the library, accessible by the key [param name].

### name :: StringName

### animation :: Animation

## get_animation :: func AnimationLibrary.get_animation(name: StringName) -> Animation
Returns the [Animation] with the key [param name]. If the animation does not exist, [code]null[/code] is returned and an error is logged.

### name :: StringName

## get_animation_list :: func AnimationLibrary.get_animation_list() -> StringName[]
Returns the keys for the [Animation]s stored in the library.

## get_animation_list_size :: func AnimationLibrary.get_animation_list_size() -> int
Returns the key count for the [Animation]s stored in the library.

## has_animation :: func AnimationLibrary.has_animation(name: StringName) -> bool
Returns [code]true[/code] if the library stores an [Animation] with [param name] as the key.

### name :: StringName

## remove_animation :: func AnimationLibrary.remove_animation(name: StringName) -> void
Removes the [Animation] with the key [param name].

### name :: StringName

## rename_animation :: func AnimationLibrary.rename_animation(name: StringName, newname: StringName) -> void
Changes the key of the [Animation] associated with the key [param name] to [param newname].

### name :: StringName

### newname :: StringName

## animation_added :: func AnimationLibrary.animation_added(anim_name: StringName) -> void
Emitted when an [Animation] is added, under the key [param anim_name].

### anim_name :: StringName

## animation_changed :: func AnimationLibrary.animation_changed(anim_name: StringName) -> void
Emitted when there's a change in one of the animations, e.g. tracks are added, moved or have changed paths. [param anim_name] is the key of the animation that was changed.
See also [signal Resource.changed], which this acts as a relay for.

### anim_name :: StringName

## animation_removed :: func AnimationLibrary.animation_removed(anim_name: StringName) -> void
Emitted when an [Animation] stored with the key [param anim_name] is removed.

### anim_name :: StringName

## animation_renamed :: func AnimationLibrary.animation_renamed(old_name: StringName, new_name: StringName) -> void
Emitted when the key for an [Animation] is changed, from [param old_name] to [param new_name].

### old_name :: StringName

### new_name :: StringName
