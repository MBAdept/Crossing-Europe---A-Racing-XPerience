# Performance :: <Native> class Performance extends Object
Exposes performance-related data.
This class provides access to a number of different monitors related to performance, such as memory usage, draw calls, and FPS. These are the same as the values displayed in the [b]Monitor[/b] tab in the editor's [b]Debugger[/b] panel. By using the [method get_monitor] method of this class, you can access this data from your code.
You can add custom monitors using the [method add_custom_monitor] method. Custom monitors are available in [b]Monitor[/b] tab in the editor's [b]Debugger[/b] panel together with built-in monitors.
[b]Note:[/b] Some of the built-in monitors are only available in debug mode and will always return [code]0[/code] when used in a project exported in release mode.
[b]Note:[/b] Some of the built-in monitors are not updated in real-time for performance reasons, so there may be a delay of up to 1 second between changes.
[b]Note:[/b] Custom monitors do not support negative values. Negative values are clamped to 0.

## TIME_FPS :: const Performance.TIME_FPS: Monitor = 0
The number of frames rendered in the last second. This metric is only updated once per second, even if queried more often. [i]Higher is better.[/i]

## TIME_PROCESS :: const Performance.TIME_PROCESS: Monitor = 1
Time it took to complete one frame, in seconds. [i]Lower is better.[/i]

## TIME_PHYSICS_PROCESS :: const Performance.TIME_PHYSICS_PROCESS: Monitor = 2
Time it took to complete one physics frame, in seconds. [i]Lower is better.[/i]

## TIME_NAVIGATION_PROCESS :: const Performance.TIME_NAVIGATION_PROCESS: Monitor = 3
Time it took to complete one navigation step, in seconds. This includes navigation map updates as well as agent avoidance calculations. [i]Lower is better.[/i]

## MEMORY_STATIC :: const Performance.MEMORY_STATIC: Monitor = 4
Static memory currently used, in bytes. Not available in release builds. [i]Lower is better.[/i]

## MEMORY_STATIC_MAX :: const Performance.MEMORY_STATIC_MAX: Monitor = 5
Available static memory. Not available in release builds. [i]Lower is better.[/i]

## MEMORY_MESSAGE_BUFFER_MAX :: const Performance.MEMORY_MESSAGE_BUFFER_MAX: Monitor = 6
Largest amount of memory the message queue buffer has used, in bytes. The message queue is used for deferred functions calls and notifications. [i]Lower is better.[/i]

## OBJECT_COUNT :: const Performance.OBJECT_COUNT: Monitor = 7
Number of objects currently instantiated (including nodes). [i]Lower is better.[/i]

## OBJECT_RESOURCE_COUNT :: const Performance.OBJECT_RESOURCE_COUNT: Monitor = 8
Number of resources currently used. [i]Lower is better.[/i]

## OBJECT_NODE_COUNT :: const Performance.OBJECT_NODE_COUNT: Monitor = 9
Number of nodes currently instantiated in the scene tree. This also includes the root node. [i]Lower is better.[/i]

## OBJECT_ORPHAN_NODE_COUNT :: const Performance.OBJECT_ORPHAN_NODE_COUNT: Monitor = 10
Number of orphan nodes, i.e. nodes which are not parented to a node of the scene tree. [i]Lower is better.[/i]
[b]Note:[/b] This is only available in debug mode and will always return [code]0[/code] when used in a project exported in release mode.

## RENDER_TOTAL_OBJECTS_IN_FRAME :: const Performance.RENDER_TOTAL_OBJECTS_IN_FRAME: Monitor = 11
The total number of objects in the last rendered frame. This metric doesn't include culled objects (either via hiding nodes, frustum culling or occlusion culling). [i]Lower is better.[/i]

## RENDER_TOTAL_PRIMITIVES_IN_FRAME :: const Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME: Monitor = 12
The total number of vertices or indices rendered in the last rendered frame. This metric doesn't include primitives from culled objects (either via hiding nodes, frustum culling or occlusion culling). Due to the depth prepass and shadow passes, the number of primitives is always higher than the actual number of vertices in the scene (typically double or triple the original vertex count). [i]Lower is better.[/i]

## RENDER_TOTAL_DRAW_CALLS_IN_FRAME :: const Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME: Monitor = 13
The total number of draw calls performed in the last rendered frame. This metric doesn't include culled objects (either via hiding nodes, frustum culling or occlusion culling), since they do not result in draw calls. [i]Lower is better.[/i]

## RENDER_VIDEO_MEM_USED :: const Performance.RENDER_VIDEO_MEM_USED: Monitor = 14
The amount of video memory used (texture and vertex memory combined, in bytes). Since this metric also includes miscellaneous allocations, this value is always greater than the sum of [constant RENDER_TEXTURE_MEM_USED] and [constant RENDER_BUFFER_MEM_USED]. [i]Lower is better.[/i]

## RENDER_TEXTURE_MEM_USED :: const Performance.RENDER_TEXTURE_MEM_USED: Monitor = 15
The amount of texture memory used (in bytes). [i]Lower is better.[/i]

## RENDER_BUFFER_MEM_USED :: const Performance.RENDER_BUFFER_MEM_USED: Monitor = 16
The amount of render buffer memory used (in bytes). [i]Lower is better.[/i]

## PHYSICS_2D_ACTIVE_OBJECTS :: const Performance.PHYSICS_2D_ACTIVE_OBJECTS: Monitor = 17
Number of active [RigidBody2D] nodes in the game. [i]Lower is better.[/i]

## PHYSICS_2D_COLLISION_PAIRS :: const Performance.PHYSICS_2D_COLLISION_PAIRS: Monitor = 18
Number of collision pairs in the 2D physics engine. [i]Lower is better.[/i]

## PHYSICS_2D_ISLAND_COUNT :: const Performance.PHYSICS_2D_ISLAND_COUNT: Monitor = 19
Number of islands in the 2D physics engine. [i]Lower is better.[/i]

## PHYSICS_3D_ACTIVE_OBJECTS :: const Performance.PHYSICS_3D_ACTIVE_OBJECTS: Monitor = 20
Number of active [RigidBody3D] and [VehicleBody3D] nodes in the game. [i]Lower is better.[/i]

## PHYSICS_3D_COLLISION_PAIRS :: const Performance.PHYSICS_3D_COLLISION_PAIRS: Monitor = 21
Number of collision pairs in the 3D physics engine. [i]Lower is better.[/i]

## PHYSICS_3D_ISLAND_COUNT :: const Performance.PHYSICS_3D_ISLAND_COUNT: Monitor = 22
Number of islands in the 3D physics engine. [i]Lower is better.[/i]

## AUDIO_OUTPUT_LATENCY :: const Performance.AUDIO_OUTPUT_LATENCY: Monitor = 23
Output latency of the [AudioServer]. Equivalent to calling [method AudioServer.get_output_latency], it is not recommended to call this every frame.

## NAVIGATION_ACTIVE_MAPS :: const Performance.NAVIGATION_ACTIVE_MAPS: Monitor = 24
Number of active navigation maps in [NavigationServer2D] and [NavigationServer3D]. This also includes the empty default navigation maps created by [World2D] and [World3D] instances.

## NAVIGATION_REGION_COUNT :: const Performance.NAVIGATION_REGION_COUNT: Monitor = 25
Number of active navigation regions in [NavigationServer2D] and [NavigationServer3D].

## NAVIGATION_AGENT_COUNT :: const Performance.NAVIGATION_AGENT_COUNT: Monitor = 26
Number of active navigation agents processing avoidance in [NavigationServer2D] and [NavigationServer3D].

## NAVIGATION_LINK_COUNT :: const Performance.NAVIGATION_LINK_COUNT: Monitor = 27
Number of active navigation links in [NavigationServer2D] and [NavigationServer3D].

## NAVIGATION_POLYGON_COUNT :: const Performance.NAVIGATION_POLYGON_COUNT: Monitor = 28
Number of navigation mesh polygons in [NavigationServer2D] and [NavigationServer3D].

## NAVIGATION_EDGE_COUNT :: const Performance.NAVIGATION_EDGE_COUNT: Monitor = 29
Number of navigation mesh polygon edges in [NavigationServer2D] and [NavigationServer3D].

## NAVIGATION_EDGE_MERGE_COUNT :: const Performance.NAVIGATION_EDGE_MERGE_COUNT: Monitor = 30
Number of navigation mesh polygon edges that were merged due to edge key overlap in [NavigationServer2D] and [NavigationServer3D].

## NAVIGATION_EDGE_CONNECTION_COUNT :: const Performance.NAVIGATION_EDGE_CONNECTION_COUNT: Monitor = 31
Number of polygon edges that are considered connected by edge proximity [NavigationServer2D] and [NavigationServer3D].

## NAVIGATION_EDGE_FREE_COUNT :: const Performance.NAVIGATION_EDGE_FREE_COUNT: Monitor = 32
Number of navigation mesh polygon edges that could not be merged in [NavigationServer2D] and [NavigationServer3D]. The edges still may be connected by edge proximity or with links.

## NAVIGATION_OBSTACLE_COUNT :: const Performance.NAVIGATION_OBSTACLE_COUNT: Monitor = 33
Number of active navigation obstacles in the [NavigationServer2D] and [NavigationServer3D].

## PIPELINE_COMPILATIONS_CANVAS :: const Performance.PIPELINE_COMPILATIONS_CANVAS: Monitor = 34
Number of pipeline compilations that were triggered by the 2D canvas renderer.

## PIPELINE_COMPILATIONS_MESH :: const Performance.PIPELINE_COMPILATIONS_MESH: Monitor = 35
Number of pipeline compilations that were triggered by loading meshes. These compilations will show up as longer loading times the first time a user runs the game and the pipeline is required.

## PIPELINE_COMPILATIONS_SURFACE :: const Performance.PIPELINE_COMPILATIONS_SURFACE: Monitor = 36
Number of pipeline compilations that were triggered by building the surface cache before rendering the scene. These compilations will show up as a stutter when loading a scene the first time a user runs the game and the pipeline is required.

## PIPELINE_COMPILATIONS_DRAW :: const Performance.PIPELINE_COMPILATIONS_DRAW: Monitor = 37
Number of pipeline compilations that were triggered while drawing the scene. These compilations will show up as stutters during gameplay the first time a user runs the game and the pipeline is required.

## PIPELINE_COMPILATIONS_SPECIALIZATION :: const Performance.PIPELINE_COMPILATIONS_SPECIALIZATION: Monitor = 38
Number of pipeline compilations that were triggered to optimize the current scene. These compilations are done in the background and should not cause any stutters whatsoever.

## NAVIGATION_2D_ACTIVE_MAPS :: const Performance.NAVIGATION_2D_ACTIVE_MAPS: Monitor = 39
Number of active navigation maps in the [NavigationServer2D]. This also includes the empty default navigation maps created by [World2D] instances.

## NAVIGATION_2D_REGION_COUNT :: const Performance.NAVIGATION_2D_REGION_COUNT: Monitor = 40
Number of active navigation regions in the [NavigationServer2D].

## NAVIGATION_2D_AGENT_COUNT :: const Performance.NAVIGATION_2D_AGENT_COUNT: Monitor = 41
Number of active navigation agents processing avoidance in the [NavigationServer2D].

## NAVIGATION_2D_LINK_COUNT :: const Performance.NAVIGATION_2D_LINK_COUNT: Monitor = 42
Number of active navigation links in the [NavigationServer2D].

## NAVIGATION_2D_POLYGON_COUNT :: const Performance.NAVIGATION_2D_POLYGON_COUNT: Monitor = 43
Number of navigation mesh polygons in the [NavigationServer2D].

## NAVIGATION_2D_EDGE_COUNT :: const Performance.NAVIGATION_2D_EDGE_COUNT: Monitor = 44
Number of navigation mesh polygon edges in the [NavigationServer2D].

## NAVIGATION_2D_EDGE_MERGE_COUNT :: const Performance.NAVIGATION_2D_EDGE_MERGE_COUNT: Monitor = 45
Number of navigation mesh polygon edges that were merged due to edge key overlap in the [NavigationServer2D].

## NAVIGATION_2D_EDGE_CONNECTION_COUNT :: const Performance.NAVIGATION_2D_EDGE_CONNECTION_COUNT: Monitor = 46
Number of polygon edges that are considered connected by edge proximity [NavigationServer2D].

## NAVIGATION_2D_EDGE_FREE_COUNT :: const Performance.NAVIGATION_2D_EDGE_FREE_COUNT: Monitor = 47
Number of navigation mesh polygon edges that could not be merged in the [NavigationServer2D]. The edges still may be connected by edge proximity or with links.

## NAVIGATION_2D_OBSTACLE_COUNT :: const Performance.NAVIGATION_2D_OBSTACLE_COUNT: Monitor = 48
Number of active navigation obstacles in the [NavigationServer2D].

## NAVIGATION_3D_ACTIVE_MAPS :: const Performance.NAVIGATION_3D_ACTIVE_MAPS: Monitor = 49
Number of active navigation maps in the [NavigationServer3D]. This also includes the empty default navigation maps created by [World3D] instances.

## NAVIGATION_3D_REGION_COUNT :: const Performance.NAVIGATION_3D_REGION_COUNT: Monitor = 50
Number of active navigation regions in the [NavigationServer3D].

## NAVIGATION_3D_AGENT_COUNT :: const Performance.NAVIGATION_3D_AGENT_COUNT: Monitor = 51
Number of active navigation agents processing avoidance in the [NavigationServer3D].

## NAVIGATION_3D_LINK_COUNT :: const Performance.NAVIGATION_3D_LINK_COUNT: Monitor = 52
Number of active navigation links in the [NavigationServer3D].

## NAVIGATION_3D_POLYGON_COUNT :: const Performance.NAVIGATION_3D_POLYGON_COUNT: Monitor = 53
Number of navigation mesh polygons in the [NavigationServer3D].

## NAVIGATION_3D_EDGE_COUNT :: const Performance.NAVIGATION_3D_EDGE_COUNT: Monitor = 54
Number of navigation mesh polygon edges in the [NavigationServer3D].

## NAVIGATION_3D_EDGE_MERGE_COUNT :: const Performance.NAVIGATION_3D_EDGE_MERGE_COUNT: Monitor = 55
Number of navigation mesh polygon edges that were merged due to edge key overlap in the [NavigationServer3D].

## NAVIGATION_3D_EDGE_CONNECTION_COUNT :: const Performance.NAVIGATION_3D_EDGE_CONNECTION_COUNT: Monitor = 56
Number of polygon edges that are considered connected by edge proximity [NavigationServer3D].

## NAVIGATION_3D_EDGE_FREE_COUNT :: const Performance.NAVIGATION_3D_EDGE_FREE_COUNT: Monitor = 57
Number of navigation mesh polygon edges that could not be merged in the [NavigationServer3D]. The edges still may be connected by edge proximity or with links.

## NAVIGATION_3D_OBSTACLE_COUNT :: const Performance.NAVIGATION_3D_OBSTACLE_COUNT: Monitor = 58
Number of active navigation obstacles in the [NavigationServer3D].

## MONITOR_MAX :: const Performance.MONITOR_MAX: Monitor = 59
Represents the size of the [enum Monitor] enum.

## MONITOR_TYPE_QUANTITY :: const Performance.MONITOR_TYPE_QUANTITY: MonitorType = 0
Monitor output is formatted as an integer value.

## MONITOR_TYPE_MEMORY :: const Performance.MONITOR_TYPE_MEMORY: MonitorType = 1
Monitor output is formatted as computer memory. Submitted values should represent a number of bytes.

## MONITOR_TYPE_TIME :: const Performance.MONITOR_TYPE_TIME: MonitorType = 2
Monitor output is formatted as time in milliseconds. Submitted values should represent a time in seconds (not milliseconds).

## MONITOR_TYPE_PERCENTAGE :: const Performance.MONITOR_TYPE_PERCENTAGE: MonitorType = 3
Monitor output is formatted as a percentage. Submitted values should represent a fractional value rather than the percentage directly, e.g. [code]0.5[/code] for [code]50.00%[/code].

## add_custom_monitor :: func Performance.add_custom_monitor(id: StringName, callable: Callable, arguments: Array = [], type: int = 0) -> void
Adds a custom monitor with the name [param id]. You can specify the category of the monitor using slash delimiters in [param id] (for example: [code]"Game/NumberOfNPCs"[/code]). If there is more than one slash delimiter, then the default category is used. The default category is [code]"Custom"[/code]. Prints an error if given [param id] is already present.
[codeblocks]
[gdscript]
func _ready():
	var monitor_value = Callable(self, "get_monitor_value")

	# Adds monitor with name "MyName" to category "MyCategory".
	Performance.add_custom_monitor("MyCategory/MyMonitor", monitor_value)

	# Adds monitor with name "MyName" to category "Custom".
	# Note: "MyCategory/MyMonitor" and "MyMonitor" have same name but different IDs, so the code is valid.
	Performance.add_custom_monitor("MyMonitor", monitor_value)

	# Adds monitor with name "MyName" to category "Custom".
	# Note: "MyMonitor" and "Custom/MyMonitor" have same name and same category but different IDs, so the code is valid.
	Performance.add_custom_monitor("Custom/MyMonitor", monitor_value)

	# Adds monitor with name "MyCategoryOne/MyCategoryTwo/MyMonitor" to category "Custom".
	Performance.add_custom_monitor("MyCategoryOne/MyCategoryTwo/MyMonitor", monitor_value)

func get_monitor_value():
	return randi() % 25
[/gdscript]
[csharp]
public override void _Ready()
{
	var monitorValue = new Callable(this, MethodName.GetMonitorValue);

	// Adds monitor with name "MyName" to category "MyCategory".
	Performance.AddCustomMonitor("MyCategory/MyMonitor", monitorValue);
	// Adds monitor with name "MyName" to category "Custom".
	// Note: "MyCategory/MyMonitor" and "MyMonitor" have same name but different ids so the code is valid.
	Performance.AddCustomMonitor("MyMonitor", monitorValue);

	// Adds monitor with name "MyName" to category "Custom".
	// Note: "MyMonitor" and "Custom/MyMonitor" have same name and same category but different ids so the code is valid.
	Performance.AddCustomMonitor("Custom/MyMonitor", monitorValue);

	// Adds monitor with name "MyCategoryOne/MyCategoryTwo/MyMonitor" to category "Custom".
	Performance.AddCustomMonitor("MyCategoryOne/MyCategoryTwo/MyMonitor", monitorValue);
}

public int GetMonitorValue()
{
	return GD.Randi() % 25;
}
[/csharp]
[/codeblocks]
The debugger calls the callable to get the value of custom monitor. The callable must return a zero or positive integer or floating-point number.
Callables are called with arguments supplied in argument array.

### id :: StringName

### callable :: Callable

### arguments :: Array

### type :: int

## get_custom_monitor :: func Performance.get_custom_monitor(id: StringName) -> Variant
Returns the value of custom monitor with given [param id]. The callable is called to get the value of custom monitor. See also [method has_custom_monitor]. Prints an error if the given [param id] is absent.

### id :: StringName

## get_custom_monitor_names :: func Performance.get_custom_monitor_names() -> StringName[]
Returns the names of active custom monitors in an [Array].

## get_custom_monitor_types :: func Performance.get_custom_monitor_types() -> PackedInt32Array
Returns the [enum MonitorType] values of active custom monitors in an [Array].

## get_monitor :: func Performance.get_monitor(monitor: int) -> float
Returns the value of one of the available built-in monitors. You should provide one of the [enum Monitor] constants as the argument, like this:
[codeblocks]
[gdscript]
print(Performance.get_monitor(Performance.TIME_FPS)) # Prints the FPS to the console.
[/gdscript]
[csharp]
GD.Print(Performance.GetMonitor(Performance.Monitor.TimeFps)); // Prints the FPS to the console.
[/csharp]
[/codeblocks]
See [method get_custom_monitor] to query custom performance monitors' values.

### monitor :: int

## get_monitor_modification_time :: func Performance.get_monitor_modification_time() -> int
Returns the last tick in which custom monitor was added/removed (in microseconds since the engine started). This is set to [method Time.get_ticks_usec] when the monitor is updated.

## has_custom_monitor :: func Performance.has_custom_monitor(id: StringName) -> bool
Returns [code]true[/code] if custom monitor with the given [param id] is present, [code]false[/code] otherwise.

### id :: StringName

## remove_custom_monitor :: func Performance.remove_custom_monitor(id: StringName) -> void
Removes the custom monitor with given [param id]. Prints an error if the given [param id] is already absent.

### id :: StringName
