# OpenXRSpatialCapabilityConfigurationAnchor :: <Native> class OpenXRSpatialCapabilityConfigurationAnchor extends OpenXRSpatialCapabilityConfigurationBaseHeader
Configuration header for spatial anchors.
Configuration header for spatial anchors. Pass this to [method OpenXRSpatialEntityExtension.create_spatial_context] to create a spatial context with spatial anchor capabilities.

## get_enabled_components :: func OpenXRSpatialCapabilityConfigurationAnchor.get_enabled_components() -> PackedInt64Array
Returns the components enabled by this configuration.
[b]Note:[/b] Only valid after this configuration was used to create a spatial context.
