# ResourceImporterLayeredTexture :: <Native> class ResourceImporterLayeredTexture extends ResourceImporter
Imports a 3-dimensional texture ([Texture3D]), a [Texture2DArray], a [Cubemap] or a [CubemapArray].
This imports a 3-dimensional texture, which can then be used in custom shaders, as a [FogMaterial] density map or as a [GPUParticlesAttractorVectorField3D]. See also [ResourceImporterTexture] and [ResourceImporterTextureAtlas].

## compress/channel_pack :: var ResourceImporterLayeredTexture.compress/channel_pack: int
Controls how color channels should be used in the imported texture.
[b]sRGB Friendly:[/b], prevents the R and RG color formats from being used, as they do not support nonlinear sRGB encoding.
[b]Optimized:[/b], allows the RG color format to be used if the texture does not use the blue channel. This reduces memory usage if the texture's blue channel can be discarded (all pixels must have a blue value of [code]0[/code]).
[b]Normal Map (RG Channels):[/b] This forces all layers from the texture to be imported with the RG color format, with only the red and green channels preserved. RGTC (Red-Green Texture Compression) compression is able to preserve its detail much better, while using the same amount of memory as a standard RGBA VRAM-compressed texture. This only has an effect on textures with the VRAM Compressed or Basis Universal compression modes. This mode is only available in layered textures ([Cubemap], [CubemapArray], [Texture2DArray] and [Texture3D]).

## compress/hdr_compression :: var ResourceImporterLayeredTexture.compress/hdr_compression: int
Controls how VRAM compression should be performed for HDR images.
[b]Disabled:[/b] Never use VRAM compression for HDR textures, regardless of whether they're opaque or transparent. Instead, the texture is converted to RGBE9995 (9-bits per channel + 5-bit exponent = 32 bits per pixel) to reduce memory usage compared to a half-float or single-precision float image format.
[b]Opaque Only:[/b] Only uses VRAM compression for opaque HDR textures. This is due to a limitation of HDR formats, as there is no VRAM-compressed HDR format that supports transparency at the same time.
[b]Always:[/b] Force VRAM compression even for HDR textures with an alpha channel. To perform this, the alpha channel is discarded on import.
[b]Note:[/b] Only effective on Radiance HDR ([code].hdr[/code]) and OpenEXR ([code].exr[/code]) images.

## compress/high_quality :: var ResourceImporterLayeredTexture.compress/high_quality: bool
If [code]true[/code], uses BPTC compression on desktop platforms and ASTC compression on mobile platforms. When using BPTC, BC7 is used for SDR textures and BC6H is used for HDR textures.
If [code]false[/code], uses the faster but lower-quality S3TC compression on desktop platforms and ETC2 on mobile/web platforms. When using S3TC, DXT1 (BC1) is used for opaque textures and DXT5 (BC3) is used for transparent or normal map (RGTC) textures.
BPTC and ASTC support VRAM compression for HDR textures, but S3TC and ETC2 do not (see [member compress/hdr_compression]).

## compress/lossy_quality :: var ResourceImporterLayeredTexture.compress/lossy_quality: float
The quality to use when using the [b]Lossy[/b] compression mode. Higher values result in better quality, at the cost of larger file sizes. Lossy quality does not affect memory usage of the imported texture, only its file size on disk.

## compress/mode :: var ResourceImporterLayeredTexture.compress/mode: int
The compression mode to use. Each compression mode provides a different tradeoff:
[b]Lossless[/b]: Original quality, high memory usage, high size on disk, fast import.
[b]Lossy:[/b] Reduced quality, high memory usage, low size on disk, fast import.
[b]VRAM Compressed:[/b] Reduced quality, low memory usage, low size on disk, slowest import. Only use for textures in 3D scenes, not for 2D elements.
[b]VRAM Uncompressed:[/b] Original quality, high memory usage, highest size on disk, fastest import.
[b]Basis Universal:[/b] Reduced quality, low memory usage, lowest size on disk, slow import. Only use for textures in 3D scenes, not for 2D elements.
See [url=https://docs.godotengine.org/en/4.7/tutorials/assets_pipeline/importing_images.html#compress-mode]Compress mode[/url] in the manual for more details.

## compress/rdo_quality_loss :: var ResourceImporterLayeredTexture.compress/rdo_quality_loss: float
If greater than or equal to [code]0.01[/code], enables Rate-Distortion Optimization (RDO) to reduce file size. Higher values result in smaller file sizes but lower quality.
[b]Note:[/b] Enabling RDO makes encoding times significantly longer, especially when the image is large.
See also [member ProjectSettings.rendering/textures/basis_universal/rdo_dict_size] and [member ProjectSettings.rendering/textures/basis_universal/zstd_supercompression_level] if you want to reduce the file size further.

## compress/uastc_level :: var ResourceImporterLayeredTexture.compress/uastc_level: int
The UASTC encoding level. Higher values result in better quality but make encoding times longer.

## mipmaps/generate :: var ResourceImporterLayeredTexture.mipmaps/generate: bool
If [code]true[/code], smaller versions of the texture are generated on import. For example, a 64×64 texture will generate 6 mipmaps (32×32, 16×16, 8×8, 4×4, 2×2, 1×1). This has several benefits:
- Textures will not become grainy in the distance (in 3D), or if scaled down due to [Camera2D] zoom or [CanvasItem] scale (in 2D).
- Performance will improve if the texture is displayed in the distance, since sampling smaller versions of the original texture is faster and requires less memory bandwidth.
The downside of mipmaps is that they increase memory usage by roughly 33% (for [Texture2DArray], [Cubemap] and [CubemapArray]) or 14% (for [Texture3D]).
It's recommended to enable mipmaps in 3D. However, in 2D, this should only be enabled if your project visibly benefits from having mipmaps enabled. If the camera never zooms out significantly, there won't be a benefit to enabling mipmaps but memory usage will increase.

## mipmaps/limit :: var ResourceImporterLayeredTexture.mipmaps/limit: int
Unimplemented. This currently has no effect when changed.

## slices/arrangement :: var ResourceImporterLayeredTexture.slices/arrangement: int
Controls how the cubemap's texture is internally laid out. When using high-resolution cubemaps, [b]2×3[/b] and [b]3×2[/b] are less prone to exceeding hardware texture size limits compared to [b]1×6[/b] and [b]6×1[/b].
