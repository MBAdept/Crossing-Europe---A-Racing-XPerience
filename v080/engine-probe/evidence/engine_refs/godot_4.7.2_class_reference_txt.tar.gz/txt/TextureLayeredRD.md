# TextureLayeredRD :: <Native> class TextureLayeredRD extends TextureLayered
Abstract base class for layered texture RD types.
Base class for [Texture2DArrayRD], [TextureCubemapRD] and [TextureCubemapArrayRD]. Cannot be used directly, but contains all the functions necessary for accessing the derived resource types.
[b]Note:[/b] [TextureLayeredRD] is intended for low-level usage with [RenderingDevice]. For most use cases, use [TextureLayered] instead.

## texture_rd_rid :: var TextureLayeredRD.texture_rd_rid: RID
The RID of the texture object created on the [RenderingDevice].
