# EditorToaster :: <Native> class EditorToaster extends HBoxContainer
Manages toast notifications within the editor.
This object manages the functionality and display of toast notifications within the editor, ensuring immediate and informative alerts are presented to the user.
[b]Note:[/b] This class shouldn't be instantiated directly. Instead, access the singleton using [method EditorInterface.get_editor_toaster].

## SEVERITY_INFO :: const EditorToaster.SEVERITY_INFO: Severity = 0
Toast will display with an INFO severity.

## SEVERITY_WARNING :: const EditorToaster.SEVERITY_WARNING: Severity = 1
Toast will display with a WARNING severity and have a corresponding color.

## SEVERITY_ERROR :: const EditorToaster.SEVERITY_ERROR: Severity = 2
Toast will display with an ERROR severity and have a corresponding color.

## push_toast :: func EditorToaster.push_toast(message: String, severity: int = 0, tooltip: String = "") -> void
Pushes a toast notification to the editor for display.

### message :: String

### severity :: int

### tooltip :: String
