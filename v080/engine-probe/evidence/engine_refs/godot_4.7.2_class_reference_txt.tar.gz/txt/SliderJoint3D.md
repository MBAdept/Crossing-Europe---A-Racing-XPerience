# SliderJoint3D :: <Native> class SliderJoint3D extends Joint3D
A physics joint that restricts the movement of a 3D physics body along an axis relative to another physics body.
A physics joint that restricts the movement of a 3D physics body along an axis relative to another physics body. For example, Body A could be a [StaticBody3D] representing a piston base, while Body B could be a [RigidBody3D] representing the piston head, moving up and down.

## PARAM_LINEAR_LIMIT_UPPER :: const SliderJoint3D.PARAM_LINEAR_LIMIT_UPPER: Param = 0
Constant for accessing [member linear_limit/upper_distance]. The maximum difference between the pivot points on their X axis before damping happens.

## PARAM_LINEAR_LIMIT_LOWER :: const SliderJoint3D.PARAM_LINEAR_LIMIT_LOWER: Param = 1
Constant for accessing [member linear_limit/lower_distance]. The minimum difference between the pivot points on their X axis before damping happens.

## PARAM_LINEAR_LIMIT_SOFTNESS :: const SliderJoint3D.PARAM_LINEAR_LIMIT_SOFTNESS: Param = 2
Constant for accessing [member linear_limit/softness]. A factor applied to the movement across the slider axis once the limits get surpassed. The lower, the slower the movement.

## PARAM_LINEAR_LIMIT_RESTITUTION :: const SliderJoint3D.PARAM_LINEAR_LIMIT_RESTITUTION: Param = 3
Constant for accessing [member linear_limit/restitution]. The amount of restitution once the limits are surpassed. The lower, the more velocity-energy gets lost.

## PARAM_LINEAR_LIMIT_DAMPING :: const SliderJoint3D.PARAM_LINEAR_LIMIT_DAMPING: Param = 4
Constant for accessing [member linear_limit/damping]. The amount of damping once the slider limits are surpassed.

## PARAM_LINEAR_MOTION_SOFTNESS :: const SliderJoint3D.PARAM_LINEAR_MOTION_SOFTNESS: Param = 5
Constant for accessing [member linear_motion/softness]. A factor applied to the movement across the slider axis as long as the slider is in the limits. The lower, the slower the movement.

## PARAM_LINEAR_MOTION_RESTITUTION :: const SliderJoint3D.PARAM_LINEAR_MOTION_RESTITUTION: Param = 6
Constant for accessing [member linear_motion/restitution]. The amount of restitution inside the slider limits.

## PARAM_LINEAR_MOTION_DAMPING :: const SliderJoint3D.PARAM_LINEAR_MOTION_DAMPING: Param = 7
Constant for accessing [member linear_motion/damping]. The amount of damping inside the slider limits.

## PARAM_LINEAR_ORTHOGONAL_SOFTNESS :: const SliderJoint3D.PARAM_LINEAR_ORTHOGONAL_SOFTNESS: Param = 8
Constant for accessing [member linear_ortho/softness]. A factor applied to the movement across axes orthogonal to the slider.

## PARAM_LINEAR_ORTHOGONAL_RESTITUTION :: const SliderJoint3D.PARAM_LINEAR_ORTHOGONAL_RESTITUTION: Param = 9
Constant for accessing [member linear_motion/restitution]. The amount of restitution when movement is across axes orthogonal to the slider.

## PARAM_LINEAR_ORTHOGONAL_DAMPING :: const SliderJoint3D.PARAM_LINEAR_ORTHOGONAL_DAMPING: Param = 10
Constant for accessing [member linear_motion/damping]. The amount of damping when movement is across axes orthogonal to the slider.

## PARAM_ANGULAR_LIMIT_UPPER :: const SliderJoint3D.PARAM_ANGULAR_LIMIT_UPPER: Param = 11
Constant for accessing [member angular_limit/upper_angle]. The upper limit of rotation in the slider.

## PARAM_ANGULAR_LIMIT_LOWER :: const SliderJoint3D.PARAM_ANGULAR_LIMIT_LOWER: Param = 12
Constant for accessing [member angular_limit/lower_angle]. The lower limit of rotation in the slider.

## PARAM_ANGULAR_LIMIT_SOFTNESS :: const SliderJoint3D.PARAM_ANGULAR_LIMIT_SOFTNESS: Param = 13
Constant for accessing [member angular_limit/softness]. A factor applied to the all rotation once the limit is surpassed.

## PARAM_ANGULAR_LIMIT_RESTITUTION :: const SliderJoint3D.PARAM_ANGULAR_LIMIT_RESTITUTION: Param = 14
Constant for accessing [member angular_limit/restitution]. The amount of restitution of the rotation when the limit is surpassed.

## PARAM_ANGULAR_LIMIT_DAMPING :: const SliderJoint3D.PARAM_ANGULAR_LIMIT_DAMPING: Param = 15
Constant for accessing [member angular_limit/damping]. The amount of damping of the rotation when the limit is surpassed.

## PARAM_ANGULAR_MOTION_SOFTNESS :: const SliderJoint3D.PARAM_ANGULAR_MOTION_SOFTNESS: Param = 16
Constant for accessing [member angular_motion/softness]. A factor applied to the all rotation in the limits.

## PARAM_ANGULAR_MOTION_RESTITUTION :: const SliderJoint3D.PARAM_ANGULAR_MOTION_RESTITUTION: Param = 17
Constant for accessing [member angular_motion/restitution]. The amount of restitution of the rotation in the limits.

## PARAM_ANGULAR_MOTION_DAMPING :: const SliderJoint3D.PARAM_ANGULAR_MOTION_DAMPING: Param = 18
Constant for accessing [member angular_motion/damping]. The amount of damping of the rotation in the limits.

## PARAM_ANGULAR_ORTHOGONAL_SOFTNESS :: const SliderJoint3D.PARAM_ANGULAR_ORTHOGONAL_SOFTNESS: Param = 19
Constant for accessing [member angular_ortho/softness]. A factor applied to the all rotation across axes orthogonal to the slider.

## PARAM_ANGULAR_ORTHOGONAL_RESTITUTION :: const SliderJoint3D.PARAM_ANGULAR_ORTHOGONAL_RESTITUTION: Param = 20
Constant for accessing [member angular_ortho/restitution]. The amount of restitution of the rotation across axes orthogonal to the slider.

## PARAM_ANGULAR_ORTHOGONAL_DAMPING :: const SliderJoint3D.PARAM_ANGULAR_ORTHOGONAL_DAMPING: Param = 21
Constant for accessing [member angular_ortho/damping]. The amount of damping of the rotation across axes orthogonal to the slider.

## PARAM_MAX :: const SliderJoint3D.PARAM_MAX: Param = 22
Represents the size of the [enum Param] enum.

## angular_limit/damping :: var SliderJoint3D.angular_limit/damping: float
The amount of damping of the rotation when the limit is surpassed.
A lower damping value allows a rotation initiated by body A to travel to body B slower.

## angular_limit/lower_angle :: var SliderJoint3D.angular_limit/lower_angle: float
The lower limit of rotation in the slider.

## angular_limit/restitution :: var SliderJoint3D.angular_limit/restitution: float
The amount of restitution of the rotation when the limit is surpassed.
Does not affect damping.

## angular_limit/softness :: var SliderJoint3D.angular_limit/softness: float
A factor applied to the all rotation once the limit is surpassed.
Makes all rotation slower when between 0 and 1.

## angular_limit/upper_angle :: var SliderJoint3D.angular_limit/upper_angle: float
The upper limit of rotation in the slider.

## angular_motion/damping :: var SliderJoint3D.angular_motion/damping: float
The amount of damping of the rotation in the limits.

## angular_motion/restitution :: var SliderJoint3D.angular_motion/restitution: float
The amount of restitution of the rotation in the limits.

## angular_motion/softness :: var SliderJoint3D.angular_motion/softness: float
A factor applied to the all rotation in the limits.

## angular_ortho/damping :: var SliderJoint3D.angular_ortho/damping: float
The amount of damping of the rotation across axes orthogonal to the slider.

## angular_ortho/restitution :: var SliderJoint3D.angular_ortho/restitution: float
The amount of restitution of the rotation across axes orthogonal to the slider.

## angular_ortho/softness :: var SliderJoint3D.angular_ortho/softness: float
A factor applied to the all rotation across axes orthogonal to the slider.

## linear_limit/damping :: var SliderJoint3D.linear_limit/damping: float
The amount of damping that happens once the limit defined by [member linear_limit/lower_distance] and [member linear_limit/upper_distance] is surpassed.

## linear_limit/lower_distance :: var SliderJoint3D.linear_limit/lower_distance: float
The minimum difference between the pivot points on their X axis before damping happens.

## linear_limit/restitution :: var SliderJoint3D.linear_limit/restitution: float
The amount of restitution once the limits are surpassed. The lower, the more velocity-energy gets lost.

## linear_limit/softness :: var SliderJoint3D.linear_limit/softness: float
A factor applied to the movement across the slider axis once the limits get surpassed. The lower, the slower the movement.

## linear_limit/upper_distance :: var SliderJoint3D.linear_limit/upper_distance: float
The maximum difference between the pivot points on their X axis before damping happens.

## linear_motion/damping :: var SliderJoint3D.linear_motion/damping: float
The amount of damping inside the slider limits.

## linear_motion/restitution :: var SliderJoint3D.linear_motion/restitution: float
The amount of restitution inside the slider limits.

## linear_motion/softness :: var SliderJoint3D.linear_motion/softness: float
A factor applied to the movement across the slider axis as long as the slider is in the limits. The lower, the slower the movement.

## linear_ortho/damping :: var SliderJoint3D.linear_ortho/damping: float
The amount of damping when movement is across axes orthogonal to the slider.

## linear_ortho/restitution :: var SliderJoint3D.linear_ortho/restitution: float
The amount of restitution when movement is across axes orthogonal to the slider.

## linear_ortho/softness :: var SliderJoint3D.linear_ortho/softness: float
A factor applied to the movement across axes orthogonal to the slider.

## get_param :: func SliderJoint3D.get_param(param: int) -> float
Returns the value of the given parameter.

### param :: int

## set_param :: func SliderJoint3D.set_param(param: int, value: float) -> void
Assigns [param value] to the given parameter.

### param :: int

### value :: float
