# StreamPeerSocket :: <Native> class StreamPeerSocket extends StreamPeer
Abstract base class for interacting with socket streams.
StreamPeerSocket is an abstract base class that defines common behavior for socket-based streams.

## STATUS_NONE :: const StreamPeerSocket.STATUS_NONE: Status = 0
The initial status of the [StreamPeerSocket]. This is also the status after disconnecting.

## STATUS_CONNECTING :: const StreamPeerSocket.STATUS_CONNECTING: Status = 1
A status representing a [StreamPeerSocket] that is connecting to a host.

## STATUS_CONNECTED :: const StreamPeerSocket.STATUS_CONNECTED: Status = 2
A status representing a [StreamPeerSocket] that is connected to a host.

## STATUS_ERROR :: const StreamPeerSocket.STATUS_ERROR: Status = 3
A status representing a [StreamPeerSocket] in error state.

## disconnect_from_host :: func StreamPeerSocket.disconnect_from_host() -> void
Disconnects from host.

## get_status :: func StreamPeerSocket.get_status() -> int
Returns the status of the connection.

## poll :: func StreamPeerSocket.poll() -> int
Polls the socket, updating its state. See [method get_status].
