# OptimizedTranslation :: <Native> class OptimizedTranslation extends Translation
An optimized translation.
An optimized translation. Uses real-time compressed translations, which results in very small dictionaries.
This class does not store the untranslated strings for optimization purposes. Therefore, [method Translation.get_message_list] always returns an empty array, and [method Translation.get_message_count] always returns [code]0[/code].

## generate :: func OptimizedTranslation.generate(from: Translation) -> bool
Generates and sets an optimized translation from the given [Translation] resource. Returns [code]true[/code] if successful.
[b]Note:[/b] Messages in [param from] should not use context or plural forms.
[b]Note:[/b] This method is intended to be used in the editor. It does nothing when called from an exported project.

### from :: Translation
