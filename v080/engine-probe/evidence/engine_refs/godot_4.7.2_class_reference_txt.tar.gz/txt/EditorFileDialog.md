# EditorFileDialog :: <Native> class EditorFileDialog extends FileDialog
A modified version of [FileDialog] used by the editor.
[EditorFileDialog] is a [FileDialog] tweaked to work in the editor. It automatically handles favorite and recent directory lists, and synchronizes some properties with their corresponding editor settings.
[EditorFileDialog] will automatically show a native dialog based on the [member EditorSettings.interface/editor/appearance/use_native_file_dialogs] editor setting and ignores [member FileDialog.use_native_dialog].
[b]Note:[/b] [EditorFileDialog] is invisible by default. To make it visible, call one of the [code]popup_*[/code] methods from [Window] on the node, such as [method Window.popup_centered_clamped].
[b]Note:[/b] On Linux and macOS, sandboxed apps always use native dialogs to access the host file system.

## disable_overwrite_warning :: var EditorFileDialog.disable_overwrite_warning: bool
If [code]true[/code], the [EditorFileDialog] will not warn the user before overwriting files.

## add_side_menu :: func EditorFileDialog.add_side_menu(menu: Control, title: String = "") -> void
This method is kept for compatibility and does nothing. As an alternative, you can display another dialog after showing the file dialog.

### menu :: Control

### title :: String
