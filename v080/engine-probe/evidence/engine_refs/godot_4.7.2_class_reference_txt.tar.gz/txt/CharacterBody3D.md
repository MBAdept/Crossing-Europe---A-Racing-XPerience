# CharacterBody3D :: <Native> class CharacterBody3D extends PhysicsBody3D
A 3D physics body specialized for characters moved by script.
[CharacterBody3D] is a specialized class for physics bodies that are meant to be user-controlled. They are not affected by physics at all, but they affect other physics bodies in their path. They are mainly used to provide high-level API to move objects with wall and slope detection ([method move_and_slide] method) in addition to the general collision detection provided by [method PhysicsBody3D.move_and_collide]. This makes it useful for highly configurable physics bodies that must move in specific ways and collide with the world, as is often the case with user-controlled characters.
For game objects that don't require complex movement or collision detection, such as moving platforms, [AnimatableBody3D] is simpler to configure.

## MOTION_MODE_GROUNDED :: const CharacterBody3D.MOTION_MODE_GROUNDED: MotionMode = 0
Apply when notions of walls, ceiling and floor are relevant. In this mode the body motion will react to slopes (acceleration/slowdown). This mode is suitable for grounded games like platformers.

## MOTION_MODE_FLOATING :: const CharacterBody3D.MOTION_MODE_FLOATING: MotionMode = 1
Apply when there is no notion of floor or ceiling. All collisions will be reported as [code]on_wall[/code]. In this mode, when you slide, the speed will always be constant. This mode is suitable for games without ground like space games.

## PLATFORM_ON_LEAVE_ADD_VELOCITY :: const CharacterBody3D.PLATFORM_ON_LEAVE_ADD_VELOCITY: PlatformOnLeave = 0
Add the last platform velocity to the [member velocity] when you leave a moving platform.

## PLATFORM_ON_LEAVE_ADD_UPWARD_VELOCITY :: const CharacterBody3D.PLATFORM_ON_LEAVE_ADD_UPWARD_VELOCITY: PlatformOnLeave = 1
Add the last platform velocity to the [member velocity] when you leave a moving platform, but any downward motion is ignored. It's useful to keep full jump height even when the platform is moving down.

## PLATFORM_ON_LEAVE_DO_NOTHING :: const CharacterBody3D.PLATFORM_ON_LEAVE_DO_NOTHING: PlatformOnLeave = 2
Do nothing when leaving a platform.

## floor_block_on_wall :: var CharacterBody3D.floor_block_on_wall: bool
If [code]true[/code], the body will be able to move on the floor only. This option avoids to be able to walk on walls, it will however allow to slide down along them.

## floor_constant_speed :: var CharacterBody3D.floor_constant_speed: bool
If [code]false[/code] (by default), the body will move faster on downward slopes and slower on upward slopes.
If [code]true[/code], the body will always move at the same speed on the ground no matter the slope. Note that you need to use [member floor_snap_length] to stick along a downward slope at constant speed.

## floor_max_angle :: var CharacterBody3D.floor_max_angle: float
Maximum angle (in radians) where a slope is still considered a floor (or a ceiling), rather than a wall, when calling [method move_and_slide]. The default value equals 45 degrees.

## floor_snap_length :: var CharacterBody3D.floor_snap_length: float
Sets a snapping distance. When set to a value different from [code]0.0[/code], the body is kept attached to slopes when calling [method move_and_slide]. The snapping vector is determined by the given distance along the opposite direction of the [member up_direction].
As long as the snapping vector is in contact with the ground and the body moves against [member up_direction], the body will remain attached to the surface. Snapping is not applied if the body moves along [member up_direction], meaning it contains vertical rising velocity, so it will be able to detach from the ground when jumping or when the body is pushed up by something. If you want to apply a snap without taking into account the velocity, use [method apply_floor_snap].

## floor_stop_on_slope :: var CharacterBody3D.floor_stop_on_slope: bool
If [code]true[/code], the body will not slide on slopes when calling [method move_and_slide] when the body is standing still.
If [code]false[/code], the body will slide on floor's slopes when [member velocity] applies a downward force.

## max_slides :: var CharacterBody3D.max_slides: int
Maximum number of times the body can change direction before it stops when calling [method move_and_slide]. Must be greater than zero.

## motion_mode :: var CharacterBody3D.motion_mode: CharacterBody3D.MotionMode
Sets the motion mode which defines the behavior of [method move_and_slide].

## platform_floor_layers :: var CharacterBody3D.platform_floor_layers: int
Collision layers that will be included for detecting floor bodies that will act as moving platforms to be followed by the [CharacterBody3D]. By default, all floor bodies are detected and propagate their velocity.

## platform_on_leave :: var CharacterBody3D.platform_on_leave: CharacterBody3D.PlatformOnLeave
Sets the behavior to apply when you leave a moving platform. By default, to be physically accurate, when you leave the last platform velocity is applied.

## platform_wall_layers :: var CharacterBody3D.platform_wall_layers: int
Collision layers that will be included for detecting wall bodies that will act as moving platforms to be followed by the [CharacterBody3D]. By default, all wall bodies are ignored.

## safe_margin :: var CharacterBody3D.safe_margin: float
Extra margin used for collision recovery when calling [method move_and_slide].
If the body is at least this close to another body, it will consider them to be colliding and will be pushed away before performing the actual motion.
A higher value means it's more flexible for detecting collision, which helps with consistently detecting walls and floors.
A lower value forces the collision algorithm to use more exact detection, so it can be used in cases that specifically require precision, e.g at very low scale to avoid visible jittering, or for stability with a stack of character bodies.

## slide_on_ceiling :: var CharacterBody3D.slide_on_ceiling: bool
If [code]true[/code], during a jump against the ceiling, the body will slide, if [code]false[/code] it will be stopped and will fall vertically.

## up_direction :: var CharacterBody3D.up_direction: Vector3
Vector pointing upwards, used to determine what is a wall and what is a floor (or a ceiling) when calling [method move_and_slide]. Defaults to [constant Vector3.UP]. As the vector will be normalized it can't be equal to [constant Vector3.ZERO], if you want all collisions to be reported as walls, consider using [constant MOTION_MODE_FLOATING] as [member motion_mode].

## velocity :: var CharacterBody3D.velocity: Vector3
Current velocity vector (typically meters per second), used and modified during calls to [method move_and_slide].
[b]Note:[/b] A common mistake is setting this property to the desired velocity multiplied by [code]delta[/code], which produces a motion vector (typically in meters).

## wall_min_slide_angle :: var CharacterBody3D.wall_min_slide_angle: float
Minimum angle (in radians) where the body is allowed to slide when it encounters a wall. The default value equals 15 degrees. When [member motion_mode] is [constant MOTION_MODE_GROUNDED], it only affects movement if [member floor_block_on_wall] is [code]true[/code].

## apply_floor_snap :: func CharacterBody3D.apply_floor_snap() -> void
Allows to manually apply a snap to the floor regardless of the body's velocity. This function does nothing when [method is_on_floor] returns [code]true[/code].

## get_floor_angle :: func CharacterBody3D.get_floor_angle(up_direction: Vector3 = Vector3(0, 1, 0)) -> float
Returns the floor's collision angle at the last collision point according to [param up_direction], which is [constant Vector3.UP] by default. This value is always positive and only valid after calling [method move_and_slide] and when [method is_on_floor] returns [code]true[/code].

### up_direction :: Vector3

## get_floor_normal :: func CharacterBody3D.get_floor_normal() -> Vector3
Returns the collision normal of the floor at the last collision point. Only valid after calling [method move_and_slide] and when [method is_on_floor] returns [code]true[/code].
[b]Warning:[/b] The collision normal is not always the same as the surface normal.

## get_last_motion :: func CharacterBody3D.get_last_motion() -> Vector3
Returns the last motion applied to the [CharacterBody3D] during the last call to [method move_and_slide]. The movement can be split into multiple motions when sliding occurs, and this method return the last one, which is useful to retrieve the current direction of the movement.

## get_last_slide_collision :: func CharacterBody3D.get_last_slide_collision() -> KinematicCollision3D
Returns a [KinematicCollision3D] if a collision occurred. The returned value contains information about the latest collision that occurred during the last call to [method move_and_slide]. Returns [code]null[/code] if no collision occurred. See also [method get_slide_collision].

## get_platform_angular_velocity :: func CharacterBody3D.get_platform_angular_velocity() -> Vector3
Returns the angular velocity of the platform at the last collision point. Only valid after calling [method move_and_slide].

## get_platform_velocity :: func CharacterBody3D.get_platform_velocity() -> Vector3
Returns the linear velocity of the platform at the last collision point. Only valid after calling [method move_and_slide].

## get_position_delta :: func CharacterBody3D.get_position_delta() -> Vector3
Returns the travel (position delta) that occurred during the last call to [method move_and_slide].

## get_real_velocity :: func CharacterBody3D.get_real_velocity() -> Vector3
Returns the current real velocity since the last call to [method move_and_slide]. For example, when you climb a slope, you will move diagonally even though the velocity is horizontal. This method returns the diagonal movement, as opposed to [member velocity] which returns the requested velocity.

## get_slide_collision :: func CharacterBody3D.get_slide_collision(slide_idx: int) -> KinematicCollision3D
Returns a [KinematicCollision3D], which contains information about a collision that occurred during the last call to [method move_and_slide]. Since the body can collide several times in a single call to [method move_and_slide], you must specify the index of the collision in the range 0 to ([method get_slide_collision_count] - 1). See also [method get_last_slide_collision].

### slide_idx :: int

## get_slide_collision_count :: func CharacterBody3D.get_slide_collision_count() -> int
Returns the number of times the body collided and changed direction during the last call to [method move_and_slide].

## get_wall_normal :: func CharacterBody3D.get_wall_normal() -> Vector3
Returns the collision normal of the wall at the last collision point. Only valid after calling [method move_and_slide] and when [method is_on_wall] returns [code]true[/code].
[b]Warning:[/b] The collision normal is not always the same as the surface normal.

## is_on_ceiling :: func CharacterBody3D.is_on_ceiling() -> bool
Returns [code]true[/code] if the body collided with the ceiling on the last call of [method move_and_slide]. Otherwise, returns [code]false[/code]. The [member up_direction] and [member floor_max_angle] are used to determine whether a surface is "ceiling" or not.

## is_on_ceiling_only :: func CharacterBody3D.is_on_ceiling_only() -> bool
Returns [code]true[/code] if the body collided only with the ceiling on the last call of [method move_and_slide]. Otherwise, returns [code]false[/code]. The [member up_direction] and [member floor_max_angle] are used to determine whether a surface is "ceiling" or not.

## is_on_floor :: func CharacterBody3D.is_on_floor() -> bool
Returns [code]true[/code] if the body collided with the floor on the last call of [method move_and_slide]. Otherwise, returns [code]false[/code]. The [member up_direction] and [member floor_max_angle] are used to determine whether a surface is "floor" or not.

## is_on_floor_only :: func CharacterBody3D.is_on_floor_only() -> bool
Returns [code]true[/code] if the body collided only with the floor on the last call of [method move_and_slide]. Otherwise, returns [code]false[/code]. The [member up_direction] and [member floor_max_angle] are used to determine whether a surface is "floor" or not.

## is_on_wall :: func CharacterBody3D.is_on_wall() -> bool
Returns [code]true[/code] if the body collided with a wall on the last call of [method move_and_slide]. Otherwise, returns [code]false[/code]. The [member up_direction] and [member floor_max_angle] are used to determine whether a surface is "wall" or not.

## is_on_wall_only :: func CharacterBody3D.is_on_wall_only() -> bool
Returns [code]true[/code] if the body collided only with a wall on the last call of [method move_and_slide]. Otherwise, returns [code]false[/code]. The [member up_direction] and [member floor_max_angle] are used to determine whether a surface is "wall" or not.

## move_and_slide :: func CharacterBody3D.move_and_slide() -> bool
Moves the body based on [member velocity]. If the body collides with another, it will slide along the other body rather than stop immediately. If the other body is a [CharacterBody3D] or [RigidBody3D], it will also be affected by the motion of the other body. You can use this to make moving and rotating platforms, or to make nodes push other nodes.
This method should be used in [method Node._physics_process] (or in a method called by [method Node._physics_process]), as it uses the physics step's [code]delta[/code] value automatically in calculations. Otherwise, the simulation will run at an incorrect speed.
Modifies [member velocity] if a slide collision occurred. To get the latest collision call [method get_last_slide_collision], for more detailed information about collisions that occurred, use [method get_slide_collision].
When the body touches a moving platform, the platform's velocity is automatically added to the body motion. If a collision occurs due to the platform's motion, it will always be first in the slide collisions.
Returns [code]true[/code] if the body collided, otherwise, returns [code]false[/code].
