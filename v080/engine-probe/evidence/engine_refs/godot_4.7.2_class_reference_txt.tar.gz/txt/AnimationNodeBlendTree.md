# AnimationNodeBlendTree :: <Native> class AnimationNodeBlendTree extends AnimationRootNode
A sub-tree of many type [AnimationNode]s used for complex animations. Used by [AnimationTree].
This animation node may contain a sub-tree of any other type animation nodes, such as [AnimationNodeTransition], [AnimationNodeBlend2], [AnimationNodeBlend3], [AnimationNodeOneShot], etc. This is one of the most commonly used animation node roots.
An [AnimationNodeOutput] node named [code]output[/code] is created by default.

## CONNECTION_OK :: const AnimationNodeBlendTree.CONNECTION_OK = 0
The connection was successful.

## CONNECTION_ERROR_NO_INPUT :: const AnimationNodeBlendTree.CONNECTION_ERROR_NO_INPUT = 1
The input node is [code]null[/code].

## CONNECTION_ERROR_NO_INPUT_INDEX :: const AnimationNodeBlendTree.CONNECTION_ERROR_NO_INPUT_INDEX = 2
The specified input port is out of range.

## CONNECTION_ERROR_NO_OUTPUT :: const AnimationNodeBlendTree.CONNECTION_ERROR_NO_OUTPUT = 3
The output node is [code]null[/code].

## CONNECTION_ERROR_SAME_NODE :: const AnimationNodeBlendTree.CONNECTION_ERROR_SAME_NODE = 4
Input and output nodes are the same.

## CONNECTION_ERROR_CONNECTION_EXISTS :: const AnimationNodeBlendTree.CONNECTION_ERROR_CONNECTION_EXISTS = 5
The specified connection already exists.

## graph_offset :: var AnimationNodeBlendTree.graph_offset: Vector2
The global offset of all sub animation nodes.

## add_node :: func AnimationNodeBlendTree.add_node(name: StringName, node: AnimationNode, position: Vector2 = Vector2(0, 0)) -> void
Adds an [AnimationNode] at the given [param position]. The [param name] is used to identify the created sub animation node later.

### name :: StringName

### node :: AnimationNode

### position :: Vector2

## connect_node :: func AnimationNodeBlendTree.connect_node(input_node: StringName, input_index: int, output_node: StringName) -> void
Connects the output of an [AnimationNode] as input for another [AnimationNode], at the input port specified by [param input_index].

### input_node :: StringName

### input_index :: int

### output_node :: StringName

## disconnect_node :: func AnimationNodeBlendTree.disconnect_node(input_node: StringName, input_index: int) -> void
Disconnects the animation node connected to the specified input.

### input_node :: StringName

### input_index :: int

## get_node :: func AnimationNodeBlendTree.get_node(name: StringName) -> AnimationNode
Returns the sub animation node with the specified [param name].

### name :: StringName

## get_node_list :: func AnimationNodeBlendTree.get_node_list() -> StringName[]
Returns a list containing the names of all sub animation nodes in this blend tree.

## get_node_position :: func AnimationNodeBlendTree.get_node_position(name: StringName) -> Vector2
Returns the position of the sub animation node with the specified [param name].

### name :: StringName

## has_node :: func AnimationNodeBlendTree.has_node(name: StringName) -> bool
Returns [code]true[/code] if a sub animation node with specified [param name] exists.

### name :: StringName

## remove_node :: func AnimationNodeBlendTree.remove_node(name: StringName) -> void
Removes a sub animation node.

### name :: StringName

## rename_node :: func AnimationNodeBlendTree.rename_node(name: StringName, new_name: StringName) -> void
Changes the name of a sub animation node.

### name :: StringName

### new_name :: StringName

## set_node_position :: func AnimationNodeBlendTree.set_node_position(name: StringName, position: Vector2) -> void
Modifies the position of a sub animation node.

### name :: StringName

### position :: Vector2

## node_changed :: func AnimationNodeBlendTree.node_changed(node_name: StringName) -> void
Emitted when the input port information is changed.

### node_name :: StringName
