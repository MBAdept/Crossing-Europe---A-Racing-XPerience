# VisualShaderNodeTexture3DParameter :: <Native> class VisualShaderNodeTexture3DParameter extends VisualShaderNodeTextureParameter
Provides a 3D texture parameter within the visual shader graph.
Translated to [code]uniform sampler3D[/code] in the shader language.
