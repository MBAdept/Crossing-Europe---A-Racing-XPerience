# PhysicsDirectSpaceState3DExtension :: <Native> class PhysicsDirectSpaceState3DExtension extends PhysicsDirectSpaceState3D
Provides virtual methods that can be overridden to create custom [PhysicsDirectSpaceState3D] implementations.
This class extends [PhysicsDirectSpaceState3D] by providing additional virtual methods that can be overridden. When these methods are overridden, they will be called instead of the internal methods of the physics server.
Intended for use with GDExtension to create custom implementations of [PhysicsDirectSpaceState3D].

## _cast_motion :: func PhysicsDirectSpaceState3DExtension._cast_motion(shape_rid: RID, transform: Transform3D, motion: Vector3, margin: float, collision_mask: int, collide_with_bodies: bool, collide_with_areas: bool, r_closest_safe: float*, r_closest_unsafe: float*, r_info: PhysicsServer3DExtensionShapeRestInfo*) -> bool

### shape_rid :: RID

### transform :: Transform3D

### motion :: Vector3

### margin :: float

### collision_mask :: int

### collide_with_bodies :: bool

### collide_with_areas :: bool

### r_closest_safe :: float*

### r_closest_unsafe :: float*

### r_info :: PhysicsServer3DExtensionShapeRestInfo*

## _collide_shape :: func PhysicsDirectSpaceState3DExtension._collide_shape(shape_rid: RID, transform: Transform3D, motion: Vector3, margin: float, collision_mask: int, collide_with_bodies: bool, collide_with_areas: bool, r_results: void*, max_results: int, r_result_count: int32_t*) -> bool

### shape_rid :: RID

### transform :: Transform3D

### motion :: Vector3

### margin :: float

### collision_mask :: int

### collide_with_bodies :: bool

### collide_with_areas :: bool

### r_results :: void*

### max_results :: int

### r_result_count :: int32_t*

## _get_closest_point_to_object_volume :: func PhysicsDirectSpaceState3DExtension._get_closest_point_to_object_volume(object: RID, point: Vector3) -> Vector3

### object :: RID

### point :: Vector3

## _intersect_point :: func PhysicsDirectSpaceState3DExtension._intersect_point(position: Vector3, collision_mask: int, collide_with_bodies: bool, collide_with_areas: bool, r_results: PhysicsServer3DExtensionShapeResult*, max_results: int) -> int

### position :: Vector3

### collision_mask :: int

### collide_with_bodies :: bool

### collide_with_areas :: bool

### r_results :: PhysicsServer3DExtensionShapeResult*

### max_results :: int

## _intersect_ray :: func PhysicsDirectSpaceState3DExtension._intersect_ray(from: Vector3, to: Vector3, collision_mask: int, collide_with_bodies: bool, collide_with_areas: bool, hit_from_inside: bool, hit_back_faces: bool, pick_ray: bool, r_result: PhysicsServer3DExtensionRayResult*) -> bool

### from :: Vector3

### to :: Vector3

### collision_mask :: int

### collide_with_bodies :: bool

### collide_with_areas :: bool

### hit_from_inside :: bool

### hit_back_faces :: bool

### pick_ray :: bool

### r_result :: PhysicsServer3DExtensionRayResult*

## _intersect_shape :: func PhysicsDirectSpaceState3DExtension._intersect_shape(shape_rid: RID, transform: Transform3D, motion: Vector3, margin: float, collision_mask: int, collide_with_bodies: bool, collide_with_areas: bool, r_result_count: PhysicsServer3DExtensionShapeResult*, max_results: int) -> int

### shape_rid :: RID

### transform :: Transform3D

### motion :: Vector3

### margin :: float

### collision_mask :: int

### collide_with_bodies :: bool

### collide_with_areas :: bool

### r_result_count :: PhysicsServer3DExtensionShapeResult*

### max_results :: int

## _rest_info :: func PhysicsDirectSpaceState3DExtension._rest_info(shape_rid: RID, transform: Transform3D, motion: Vector3, margin: float, collision_mask: int, collide_with_bodies: bool, collide_with_areas: bool, r_rest_info: PhysicsServer3DExtensionShapeRestInfo*) -> bool

### shape_rid :: RID

### transform :: Transform3D

### motion :: Vector3

### margin :: float

### collision_mask :: int

### collide_with_bodies :: bool

### collide_with_areas :: bool

### r_rest_info :: PhysicsServer3DExtensionShapeRestInfo*

## is_body_excluded_from_query :: func PhysicsDirectSpaceState3DExtension.is_body_excluded_from_query(body: RID) -> bool

### body :: RID
