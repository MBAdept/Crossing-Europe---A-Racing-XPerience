# GLTFPhysicsBody :: <Native> class GLTFPhysicsBody extends Resource
Represents a glTF physics body.
Represents a physics body as an intermediary between the [code]OMI_physics_body[/code] glTF data and Godot's nodes, and it's abstracted in a way that allows adding support for different glTF physics extensions in the future.

## angular_velocity :: var GLTFPhysicsBody.angular_velocity: Vector3
The angular velocity of the physics body, in radians per second. This is only used when the body type is "rigid" or "vehicle".

## body_type :: var GLTFPhysicsBody.body_type: String
The type of the body.
When importing, this controls what type of [CollisionObject3D] node Godot should generate. Valid values are [code]"static"[/code], [code]"animatable"[/code], [code]"character"[/code], [code]"rigid"[/code], [code]"vehicle"[/code], and [code]"trigger"[/code].
When exporting, this will be squashed down to one of [code]"static"[/code], [code]"kinematic"[/code], or [code]"dynamic"[/code] motion types, or the [code]"trigger"[/code] property.

## center_of_mass :: var GLTFPhysicsBody.center_of_mass: Vector3
The center of mass of the body, in meters. This is in local space relative to the body. By default, the center of the mass is the body's origin.

## inertia_diagonal :: var GLTFPhysicsBody.inertia_diagonal: Vector3
The inertia strength of the physics body, in kilogram meter squared (kg⋅m²). This represents the inertia around the principle axes, the diagonal of the inertia tensor matrix. This is only used when the body type is "rigid" or "vehicle".
When converted to a Godot [RigidBody3D] node, if this value is zero, then the inertia will be calculated automatically.

## inertia_orientation :: var GLTFPhysicsBody.inertia_orientation: Quaternion
The inertia orientation of the physics body. This defines the rotation of the inertia's principle axes relative to the object's local axes. This is only used when the body type is "rigid" or "vehicle" and [member inertia_diagonal] is set to a non-zero value.

## inertia_tensor :: var GLTFPhysicsBody.inertia_tensor: Basis
The inertia tensor of the physics body, in kilogram meter squared (kg⋅m²). This is only used when the body type is "rigid" or "vehicle".
When converted to a Godot [RigidBody3D] node, if this value is zero, then the inertia will be calculated automatically.

## linear_velocity :: var GLTFPhysicsBody.linear_velocity: Vector3
The linear velocity of the physics body, in meters per second. This is only used when the body type is "rigid" or "vehicle".

## mass :: var GLTFPhysicsBody.mass: float
The mass of the physics body, in kilograms. This is only used when the body type is "rigid" or "vehicle".

## from_dictionary :: func GLTFPhysicsBody.from_dictionary(dictionary: Dictionary) -> GLTFPhysicsBody
Creates a new GLTFPhysicsBody instance by parsing the given [Dictionary] in the [code]OMI_physics_body[/code] glTF extension format.

### dictionary :: Dictionary

## from_node :: func GLTFPhysicsBody.from_node(body_node: CollisionObject3D) -> GLTFPhysicsBody
Creates a new GLTFPhysicsBody instance from the given Godot [CollisionObject3D] node.

### body_node :: CollisionObject3D

## to_dictionary :: func GLTFPhysicsBody.to_dictionary() -> Dictionary
Serializes this GLTFPhysicsBody instance into a [Dictionary]. It will be in the format expected by the [code]OMI_physics_body[/code] glTF extension.

## to_node :: func GLTFPhysicsBody.to_node() -> CollisionObject3D
Converts this GLTFPhysicsBody instance into a Godot [CollisionObject3D] node.
