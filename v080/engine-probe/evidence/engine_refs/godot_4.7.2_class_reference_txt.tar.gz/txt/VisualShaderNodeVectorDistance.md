# VisualShaderNodeVectorDistance :: <Native> class VisualShaderNodeVectorDistance extends VisualShaderNodeVectorBase
Returns the distance between two points. To be used within the visual shader graph.
Calculates distance from point represented by vector [code]p0[/code] to vector [code]p1[/code].
Translated to [code]distance(p0, p1)[/code] in the shader language.
