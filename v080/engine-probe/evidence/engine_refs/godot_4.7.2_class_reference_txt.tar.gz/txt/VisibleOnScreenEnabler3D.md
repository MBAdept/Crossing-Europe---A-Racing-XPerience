# VisibleOnScreenEnabler3D :: <Native> class VisibleOnScreenEnabler3D extends VisibleOnScreenNotifier3D
A box-shaped region of 3D space that, when visible on screen, enables a target node.
[VisibleOnScreenEnabler3D] contains a box-shaped region of 3D space and a target node. The target node will be automatically enabled (via its [member Node.process_mode] property) when any part of this region becomes visible on the screen, and automatically disabled otherwise. This can for example be used to activate enemies only when the player approaches them.
See [VisibleOnScreenNotifier3D] if you only want to be notified when the region is visible on screen.
[b]Note:[/b] [VisibleOnScreenEnabler3D] uses an approximate heuristic that doesn't take walls and other occlusion into account, unless occlusion culling is used. It also won't function unless [member Node3D.visible] is set to [code]true[/code].

## ENABLE_MODE_INHERIT :: const VisibleOnScreenEnabler3D.ENABLE_MODE_INHERIT: EnableMode = 0
Corresponds to [constant Node.PROCESS_MODE_INHERIT].

## ENABLE_MODE_ALWAYS :: const VisibleOnScreenEnabler3D.ENABLE_MODE_ALWAYS: EnableMode = 1
Corresponds to [constant Node.PROCESS_MODE_ALWAYS].

## ENABLE_MODE_WHEN_PAUSED :: const VisibleOnScreenEnabler3D.ENABLE_MODE_WHEN_PAUSED: EnableMode = 2
Corresponds to [constant Node.PROCESS_MODE_WHEN_PAUSED].

## enable_mode :: var VisibleOnScreenEnabler3D.enable_mode: VisibleOnScreenEnabler3D.EnableMode
Determines how the target node is enabled. Corresponds to [enum Node.ProcessMode]. When the node is disabled, it always uses [constant Node.PROCESS_MODE_DISABLED].

## enable_node_path :: var VisibleOnScreenEnabler3D.enable_node_path: NodePath
The path to the target node, relative to the [VisibleOnScreenEnabler3D]. The target node is cached; it's only assigned when setting this property (if the [VisibleOnScreenEnabler3D] is inside the scene tree) and every time the [VisibleOnScreenEnabler3D] enters the scene tree. If the path is empty, no node will be affected. If the path is invalid, an error is also generated.
