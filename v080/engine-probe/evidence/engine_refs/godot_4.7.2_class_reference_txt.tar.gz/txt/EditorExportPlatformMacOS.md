# EditorExportPlatformMacOS :: <Native> class EditorExportPlatformMacOS extends EditorExportPlatform
Exporter for macOS.

## application/additional_plist_content :: var EditorExportPlatformMacOS.application/additional_plist_content: String
Additional data added to the root [code]<dict>[/code] section of the [url=https://developer.apple.com/documentation/bundleresources/information_property_list]Info.plist[/url] file. The value should be an XML section with pairs of key-value elements, e.g.:
[codeblock lang=text]
<key>key_name</key>
<string>value</string>
[/codeblock]

## application/app_category :: var EditorExportPlatformMacOS.application/app_category: String
Application category for the App Store.

## application/bundle_identifier :: var EditorExportPlatformMacOS.application/bundle_identifier: String
Unique application identifier in a reverse-DNS format, can only contain alphanumeric characters ([code]A-Z[/code], [code]a-z[/code], and [code]0-9[/code]), hyphens ([code]-[/code]), and periods ([code].[/code]).

## application/copyright :: var EditorExportPlatformMacOS.application/copyright: String
Copyright notice for the bundle visible to the user (in English).

## application/copyright_localized :: var EditorExportPlatformMacOS.application/copyright_localized: Dictionary
Copyright notice for the bundle visible to the user (localized).

## application/export_angle :: var EditorExportPlatformMacOS.application/export_angle: int
If set to [code]1[/code], ANGLE libraries are exported with the exported application. If set to [code]0[/code], ANGLE libraries are exported only if [member ProjectSettings.rendering/gl_compatibility/driver] is set to [code]"opengl3_angle"[/code].

## application/icon :: var EditorExportPlatformMacOS.application/icon: String
Application icon file. If left empty, it will fallback to [member ProjectSettings.application/config/macos_native_icon], and then to [member ProjectSettings.application/config/icon].

## application/icon_interpolation :: var EditorExportPlatformMacOS.application/icon_interpolation: int
Interpolation method used to resize application icon.

## application/liquid_glass_icon :: var EditorExportPlatformMacOS.application/liquid_glass_icon: String
macOS 26 Liquid Glass icon source file. Use [url=https://developer.apple.com/icon-composer/]Icon Composer[/url] to create Liquid Glass icons.
[b]Note:[/b] Supported when exporting from macOS only, Xcode 26+ required.
[b]Note:[/b] Liquid Glass icons are supported on macOS 26 only, use [member application/icon] to set the icon for older macOS versions.

## application/min_macos_version_arm64 :: var EditorExportPlatformMacOS.application/min_macos_version_arm64: String
Minimum version of macOS required for this application to run on Apple Silicon Macs, in the [code]major.minor.patch[/code] or [code]major.minor[/code] format, can only contain numeric characters ([code]0-9[/code]) and periods ([code].[/code]).

## application/min_macos_version_x86_64 :: var EditorExportPlatformMacOS.application/min_macos_version_x86_64: String
Minimum version of macOS required for this application to run on Intel Macs, in the [code]major.minor.patch[/code] or [code]major.minor[/code] format, can only contain numeric characters ([code]0-9[/code]) and periods ([code].[/code]).

## application/short_version :: var EditorExportPlatformMacOS.application/short_version: String
Application version visible to the user. Can only contain numeric characters ([code]0-9[/code]) and periods ([code].[/code]). Falls back to [member ProjectSettings.application/config/version] if left empty.
[b]Note:[/b] This value is used for the [i]Identity > Version[/i] value in the generated Xcode project.

## application/signature :: var EditorExportPlatformMacOS.application/signature: String
A four-character creator code that is specific to the bundle. Optional.

## application/version :: var EditorExportPlatformMacOS.application/version: String
Machine-readable application version in the [code]major.minor.patch[/code] format. Can only contain numeric characters ([code]0-9[/code]) and periods ([code].[/code]). This must be incremented with every new release pushed to the App Store. Falls back to [member ProjectSettings.application/config/version] if left empty.
[b]Note:[/b] This value is used for the [i]Identity > Build[/i] value in the generated Xcode project.

## binary_format/architecture :: var EditorExportPlatformMacOS.binary_format/architecture: String
Application executable architecture.
Supported architectures: [code]x86_64[/code], [code]arm64[/code], and [code]universal[/code] ([code]x86_64 + arm64[/code]).
Official export templates include [code]universal[/code] binaries only.

## codesign/apple_team_id :: var EditorExportPlatformMacOS.codesign/apple_team_id: String
Apple Team ID, unique 10-character string. To locate your Team ID check "Membership details" section in your Apple developer account dashboard, or "Organizational Unit" of your code signing certificate. See [url=https://developer.apple.com/help/account/manage-your-team/locate-your-team-id]Locate your Team ID[/url].

## codesign/certificate_file :: var EditorExportPlatformMacOS.codesign/certificate_file: String
PKCS #12 certificate file used to sign [code].app[/code] bundle.
Can be overridden with the environment variable [code]GODOT_MACOS_CODESIGN_CERTIFICATE_FILE[/code].

## codesign/certificate_password :: var EditorExportPlatformMacOS.codesign/certificate_password: String
Password for the certificate file used to sign [code].app[/code] bundle.
Can be overridden with the environment variable [code]GODOT_MACOS_CODESIGN_CERTIFICATE_PASSWORD[/code].

## codesign/codesign :: var EditorExportPlatformMacOS.codesign/codesign: int
Tool to use for code signing.

## codesign/custom_options :: var EditorExportPlatformMacOS.codesign/custom_options: PackedStringArray
Array of the additional command line arguments passed to the code signing tool.

## codesign/entitlements/additional :: var EditorExportPlatformMacOS.codesign/entitlements/additional: String
Additional data added to the root [code]<dict>[/code] section of the [url=https://developer.apple.com/documentation/bundleresources/entitlements].entitlements[/url] file. The value should be an XML section with pairs of key-value elements, for example:
[codeblock lang=text]
<key>key_name</key>
<string>value</string>
[/codeblock]

## codesign/entitlements/address_book :: var EditorExportPlatformMacOS.codesign/entitlements/address_book: bool
Enable to allow access to contacts in the user's address book, if it's enabled you should also provide usage message in the [member privacy/address_book_usage_description] option. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_personal-information_addressbook]com.apple.security.personal-information.addressbook[/url].

## codesign/entitlements/allow_dyld_environment_variables :: var EditorExportPlatformMacOS.codesign/entitlements/allow_dyld_environment_variables: bool
Allows app to use dynamic linker environment variables to inject code. If you are using add-ons with dynamic or self-modifying native code, enable them according to the add-on documentation. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_cs_allow-dyld-environment-variables]com.apple.security.cs.allow-dyld-environment-variables[/url].

## codesign/entitlements/allow_jit_code_execution :: var EditorExportPlatformMacOS.codesign/entitlements/allow_jit_code_execution: bool
Allows creating writable and executable memory for JIT code. If you are using add-ons with dynamic or self-modifying native code, enable them according to the add-on documentation. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_cs_allow-jit]com.apple.security.cs.allow-jit[/url].

## codesign/entitlements/allow_unsigned_executable_memory :: var EditorExportPlatformMacOS.codesign/entitlements/allow_unsigned_executable_memory: bool
Allows creating writable and executable memory without JIT restrictions. If you are using add-ons with dynamic or self-modifying native code, enable them according to the add-on documentation. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_cs_allow-unsigned-executable-memory]com.apple.security.cs.allow-unsigned-executable-memory[/url].

## codesign/entitlements/app_sandbox/device_bluetooth :: var EditorExportPlatformMacOS.codesign/entitlements/app_sandbox/device_bluetooth: bool
Enable to allow app to interact with Bluetooth devices. This entitlement is required to use wireless controllers. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_device_bluetooth]com.apple.security.device.bluetooth[/url].

## codesign/entitlements/app_sandbox/device_usb :: var EditorExportPlatformMacOS.codesign/entitlements/app_sandbox/device_usb: bool
Enable to allow app to interact with USB devices. This entitlement is required to use wired controllers. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_device_usb]com.apple.security.device.usb[/url].

## codesign/entitlements/app_sandbox/enabled :: var EditorExportPlatformMacOS.codesign/entitlements/app_sandbox/enabled: bool
Enables App Sandbox. The App Sandbox restricts access to user data, networking, and devices. Sandboxed apps can't access most of the file system, can't use custom file dialogs and execute binaries outside the .app bundle. See [url=https://developer.apple.com/documentation/security/app_sandbox]App Sandbox[/url].
[b]Note:[/b] To distribute an app through the App Store, you must enable the App Sandbox.

## codesign/entitlements/app_sandbox/files_downloads :: var EditorExportPlatformMacOS.codesign/entitlements/app_sandbox/files_downloads: int
Allows read or write access to the user's "Downloads" folder. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_files_downloads_read-write]com.apple.security.files.downloads.read-write[/url].

## codesign/entitlements/app_sandbox/files_movies :: var EditorExportPlatformMacOS.codesign/entitlements/app_sandbox/files_movies: int
Allows read or write access to the user's "Movies" folder. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_assets_movies_read-write]com.apple.security.files.movies.read-write[/url].

## codesign/entitlements/app_sandbox/files_music :: var EditorExportPlatformMacOS.codesign/entitlements/app_sandbox/files_music: int
Allows read or write access to the user's "Music" folder. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_assets_music_read-write]com.apple.security.files.music.read-write[/url].

## codesign/entitlements/app_sandbox/files_pictures :: var EditorExportPlatformMacOS.codesign/entitlements/app_sandbox/files_pictures: int
Allows read or write access to the user's "Pictures" folder. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_assets_pictures_read-write]com.apple.security.files.pictures.read-write[/url].

## codesign/entitlements/app_sandbox/files_user_selected :: var EditorExportPlatformMacOS.codesign/entitlements/app_sandbox/files_user_selected: int
Allows read or write access to the locations the user has selected using a native file dialog. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_files_user-selected_read-write]com.apple.security.files.user-selected.read-write[/url].

## codesign/entitlements/app_sandbox/helper_executables :: var EditorExportPlatformMacOS.codesign/entitlements/app_sandbox/helper_executables: Array
List of helper executables to embedded to the app bundle. Sandboxed app are limited to execute only these executable. See [url=https://developer.apple.com/documentation/xcode/embedding-a-helper-tool-in-a-sandboxed-app]Embedding a command-line tool in a sandboxed app[/url].

## codesign/entitlements/app_sandbox/network_client :: var EditorExportPlatformMacOS.codesign/entitlements/app_sandbox/network_client: bool
Enable to allow app to establish outgoing network connections. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_network_client]com.apple.security.network.client[/url].

## codesign/entitlements/app_sandbox/network_server :: var EditorExportPlatformMacOS.codesign/entitlements/app_sandbox/network_server: bool
Enable to allow app to listen for incoming network connections. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_network_server]com.apple.security.network.server[/url].

## codesign/entitlements/apple_events :: var EditorExportPlatformMacOS.codesign/entitlements/apple_events: bool
Enable to allow app to send Apple events to other apps. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_automation_apple-events]com.apple.security.automation.apple-events[/url].

## codesign/entitlements/audio_input :: var EditorExportPlatformMacOS.codesign/entitlements/audio_input: bool
Enable if you need to use the microphone or other audio input sources, if it's enabled you should also provide usage message in the [member privacy/microphone_usage_description] option. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_device_audio-input]com.apple.security.device.audio-input[/url].

## codesign/entitlements/calendars :: var EditorExportPlatformMacOS.codesign/entitlements/calendars: bool
Enable to allow access to the user's calendar, if it's enabled you should also provide usage message in the [member privacy/calendar_usage_description] option. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_personal-information_calendars]com.apple.security.personal-information.calendars[/url].

## codesign/entitlements/camera :: var EditorExportPlatformMacOS.codesign/entitlements/camera: bool
Enable if you need to use the camera, if it's enabled you should also provide usage message in the [member privacy/camera_usage_description] option. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_device_camera]com.apple.security.device.camera[/url].

## codesign/entitlements/custom_file :: var EditorExportPlatformMacOS.codesign/entitlements/custom_file: String
Custom entitlements [code].plist[/code] file, if specified the rest of entitlements in the export config are ignored.

## codesign/entitlements/debugging :: var EditorExportPlatformMacOS.codesign/entitlements/debugging: bool
You can temporarily enable this entitlement to use native debugger (GDB, LLDB) with the exported app. This entitlement should be disabled for production export. See [url=https://developer.apple.com/documentation/xcode/embedding-a-helper-tool-in-a-sandboxed-app]Embedding a command-line tool in a sandboxed app[/url].

## codesign/entitlements/disable_library_validation :: var EditorExportPlatformMacOS.codesign/entitlements/disable_library_validation: bool
Allows app to load arbitrary libraries and frameworks (not signed with the same Team ID as the main executable or by Apple). Enable it if you are using GDExtension add-ons or ad-hoc signing, or want to support user-provided external add-ons. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_cs_disable-library-validation]com.apple.security.cs.disable-library-validation[/url].

## codesign/entitlements/location :: var EditorExportPlatformMacOS.codesign/entitlements/location: bool
Enable if you need to use location information from Location Services, if it's enabled you should also provide usage message in the [member privacy/location_usage_description] option. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_personal-information_location]com.apple.security.personal-information.location[/url].

## codesign/entitlements/photos_library :: var EditorExportPlatformMacOS.codesign/entitlements/photos_library: bool
Enable to allow access to the user's Photos library, if it's enabled you should also provide usage message in the [member privacy/photos_library_usage_description] option. See [url=https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_security_personal-information_photos-library]com.apple.security.personal-information.photos-library[/url].

## codesign/identity :: var EditorExportPlatformMacOS.codesign/identity: String
The "Full Name", "Common Name" or SHA-1 hash of the signing identity used to sign [code].app[/code] bundle.

## codesign/installer_identity :: var EditorExportPlatformMacOS.codesign/installer_identity: String
The "Full Name", "Common Name" or SHA-1 hash of the signing identity used to sign [code].pkg[/code] installer package for App Store distribution, use [code]3rd Party Mac Developer Installer: Name.[/code] identity.

## codesign/provisioning_profile :: var EditorExportPlatformMacOS.codesign/provisioning_profile: String
Provisioning profile file downloaded from Apple developer account dashboard. See [url=https://developer.apple.com/help/account/manage-profiles/edit-download-or-delete-profiles]Edit, download, or delete provisioning profiles[/url].
Can be overridden with the environment variable [code]GODOT_MACOS_CODESIGN_PROVISIONING_PROFILE[/code].

## custom_template/debug :: var EditorExportPlatformMacOS.custom_template/debug: String
Path to the custom export template. If left empty, default template is used.

## custom_template/release :: var EditorExportPlatformMacOS.custom_template/release: String
Path to the custom export template. If left empty, default template is used.

## debug/export_console_wrapper :: var EditorExportPlatformMacOS.debug/export_console_wrapper: int
If enabled, a wrapper that can be used to run the application with console output is created alongside the exported application.

## display/high_res :: var EditorExportPlatformMacOS.display/high_res: bool
If [code]true[/code], the application is rendered at native display resolution, otherwise it is always rendered at loDPI resolution and upscaled by OS when required.

## export/distribution_type :: var EditorExportPlatformMacOS.export/distribution_type: int
Application distribution target.

## notarization/api_key :: var EditorExportPlatformMacOS.notarization/api_key: String
Apple App Store Connect API issuer key file.
Can be overridden with the environment variable [code]GODOT_MACOS_NOTARIZATION_API_KEY[/code].

## notarization/api_key_id :: var EditorExportPlatformMacOS.notarization/api_key_id: String
Apple App Store Connect API issuer key ID.
Can be overridden with the environment variable [code]GODOT_MACOS_NOTARIZATION_API_KEY_ID[/code].

## notarization/api_uuid :: var EditorExportPlatformMacOS.notarization/api_uuid: String
Apple App Store Connect API issuer UUID.
Can be overridden with the environment variable [code]GODOT_MACOS_NOTARIZATION_API_UUID[/code].

## notarization/apple_id_name :: var EditorExportPlatformMacOS.notarization/apple_id_name: String
Apple ID account name (email address).
Can be overridden with the environment variable [code]GODOT_MACOS_NOTARIZATION_APPLE_ID_NAME[/code].

## notarization/apple_id_password :: var EditorExportPlatformMacOS.notarization/apple_id_password: String
Apple ID app-specific password.
Can be overridden with the environment variable [code]GODOT_MACOS_NOTARIZATION_APPLE_ID_PASSWORD[/code].

## notarization/notarization :: var EditorExportPlatformMacOS.notarization/notarization: int
Tool to use for notarization.

## privacy/address_book_usage_description :: var EditorExportPlatformMacOS.privacy/address_book_usage_description: String
A message displayed when requesting access to the user's contacts (in English).

## privacy/address_book_usage_description_localized :: var EditorExportPlatformMacOS.privacy/address_book_usage_description_localized: Dictionary
A message displayed when requesting access to the user's contacts (localized).

## privacy/calendar_usage_description :: var EditorExportPlatformMacOS.privacy/calendar_usage_description: String
A message displayed when requesting access to the user's calendar data (in English).

## privacy/calendar_usage_description_localized :: var EditorExportPlatformMacOS.privacy/calendar_usage_description_localized: Dictionary
A message displayed when requesting access to the user's calendar data (localized).

## privacy/camera_usage_description :: var EditorExportPlatformMacOS.privacy/camera_usage_description: String
A message displayed when requesting access to the device's camera (in English).

## privacy/camera_usage_description_localized :: var EditorExportPlatformMacOS.privacy/camera_usage_description_localized: Dictionary
A message displayed when requesting access to the device's camera (localized).

## privacy/collected_data/advertising_data/collected :: var EditorExportPlatformMacOS.privacy/collected_data/advertising_data/collected: bool
Indicates whether your app collects advertising data.

## privacy/collected_data/advertising_data/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/advertising_data/collection_purposes: int
The reasons your app collects advertising data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/advertising_data/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/advertising_data/linked_to_user: bool
Indicates whether your app links advertising data to the user's identity.

## privacy/collected_data/advertising_data/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/advertising_data/used_for_tracking: bool
Indicates whether your app uses advertising data for tracking.

## privacy/collected_data/audio_data/collected :: var EditorExportPlatformMacOS.privacy/collected_data/audio_data/collected: bool
Indicates whether your app collects audio data.

## privacy/collected_data/audio_data/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/audio_data/collection_purposes: int
The reasons your app collects audio data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/audio_data/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/audio_data/linked_to_user: bool
Indicates whether your app links audio data to the user's identity.

## privacy/collected_data/audio_data/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/audio_data/used_for_tracking: bool
Indicates whether your app uses audio data for tracking.

## privacy/collected_data/browsing_history/collected :: var EditorExportPlatformMacOS.privacy/collected_data/browsing_history/collected: bool
Indicates whether your app collects browsing history.

## privacy/collected_data/browsing_history/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/browsing_history/collection_purposes: int
The reasons your app collects browsing history. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/browsing_history/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/browsing_history/linked_to_user: bool
Indicates whether your app links browsing history to the user's identity.

## privacy/collected_data/browsing_history/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/browsing_history/used_for_tracking: bool
Indicates whether your app uses browsing history for tracking.

## privacy/collected_data/coarse_location/collected :: var EditorExportPlatformMacOS.privacy/collected_data/coarse_location/collected: bool
Indicates whether your app collects coarse location data.

## privacy/collected_data/coarse_location/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/coarse_location/collection_purposes: int
The reasons your app collects coarse location data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/coarse_location/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/coarse_location/linked_to_user: bool
Indicates whether your app links coarse location data to the user's identity.

## privacy/collected_data/coarse_location/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/coarse_location/used_for_tracking: bool
Indicates whether your app uses coarse location data for tracking.

## privacy/collected_data/contacts/collected :: var EditorExportPlatformMacOS.privacy/collected_data/contacts/collected: bool
Indicates whether your app collects contacts.

## privacy/collected_data/contacts/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/contacts/collection_purposes: int
The reasons your app collects contacts. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/contacts/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/contacts/linked_to_user: bool
Indicates whether your app links contacts to the user's identity.

## privacy/collected_data/contacts/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/contacts/used_for_tracking: bool
Indicates whether your app uses contacts for tracking.

## privacy/collected_data/crash_data/collected :: var EditorExportPlatformMacOS.privacy/collected_data/crash_data/collected: bool
Indicates whether your app collects crash data.

## privacy/collected_data/crash_data/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/crash_data/collection_purposes: int
The reasons your app collects crash data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/crash_data/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/crash_data/linked_to_user: bool
Indicates whether your app links crash data to the user's identity.

## privacy/collected_data/crash_data/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/crash_data/used_for_tracking: bool
Indicates whether your app uses crash data for tracking.

## privacy/collected_data/credit_info/collected :: var EditorExportPlatformMacOS.privacy/collected_data/credit_info/collected: bool
Indicates whether your app collects credit information.

## privacy/collected_data/credit_info/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/credit_info/collection_purposes: int
The reasons your app collects credit information. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/credit_info/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/credit_info/linked_to_user: bool
Indicates whether your app links credit information to the user's identity.

## privacy/collected_data/credit_info/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/credit_info/used_for_tracking: bool
Indicates whether your app uses credit information for tracking.

## privacy/collected_data/customer_support/collected :: var EditorExportPlatformMacOS.privacy/collected_data/customer_support/collected: bool
Indicates whether your app collects customer support data.

## privacy/collected_data/customer_support/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/customer_support/collection_purposes: int
The reasons your app collects customer support data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/customer_support/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/customer_support/linked_to_user: bool
Indicates whether your app links customer support data to the user's identity.

## privacy/collected_data/customer_support/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/customer_support/used_for_tracking: bool
Indicates whether your app uses customer support data for tracking.

## privacy/collected_data/device_id/collected :: var EditorExportPlatformMacOS.privacy/collected_data/device_id/collected: bool
Indicates whether your app collects device IDs.

## privacy/collected_data/device_id/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/device_id/collection_purposes: int
The reasons your app collects device IDs. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/device_id/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/device_id/linked_to_user: bool
Indicates whether your app links device IDs to the user's identity.

## privacy/collected_data/device_id/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/device_id/used_for_tracking: bool
Indicates whether your app uses device IDs for tracking.

## privacy/collected_data/email_address/collected :: var EditorExportPlatformMacOS.privacy/collected_data/email_address/collected: bool
Indicates whether your app collects email address.

## privacy/collected_data/email_address/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/email_address/collection_purposes: int
The reasons your app collects email address. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/email_address/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/email_address/linked_to_user: bool
Indicates whether your app links email address to the user's identity.

## privacy/collected_data/email_address/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/email_address/used_for_tracking: bool
Indicates whether your app uses email address for tracking.

## privacy/collected_data/emails_or_text_messages/collected :: var EditorExportPlatformMacOS.privacy/collected_data/emails_or_text_messages/collected: bool
Indicates whether your app collects emails or text messages.

## privacy/collected_data/emails_or_text_messages/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/emails_or_text_messages/collection_purposes: int
The reasons your app collects emails or text messages. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/emails_or_text_messages/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/emails_or_text_messages/linked_to_user: bool
Indicates whether your app links emails or text messages to the user's identity.

## privacy/collected_data/emails_or_text_messages/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/emails_or_text_messages/used_for_tracking: bool
Indicates whether your app uses emails or text messages for tracking.

## privacy/collected_data/environment_scanning/collected :: var EditorExportPlatformMacOS.privacy/collected_data/environment_scanning/collected: bool
Indicates whether your app collects environment scanning data.

## privacy/collected_data/environment_scanning/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/environment_scanning/collection_purposes: int
The reasons your app collects environment scanning data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/environment_scanning/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/environment_scanning/linked_to_user: bool
Indicates whether your app links environment scanning data to the user's identity.

## privacy/collected_data/environment_scanning/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/environment_scanning/used_for_tracking: bool
Indicates whether your app uses environment scanning data for tracking.

## privacy/collected_data/fitness/collected :: var EditorExportPlatformMacOS.privacy/collected_data/fitness/collected: bool
Indicates whether your app collects fitness and exercise data.

## privacy/collected_data/fitness/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/fitness/collection_purposes: int
The reasons your app collects fitness and exercise data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/fitness/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/fitness/linked_to_user: bool
Indicates whether your app links fitness and exercise data to the user's identity.

## privacy/collected_data/fitness/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/fitness/used_for_tracking: bool
Indicates whether your app uses fitness and exercise data for tracking.

## privacy/collected_data/gameplay_content/collected :: var EditorExportPlatformMacOS.privacy/collected_data/gameplay_content/collected: bool
Indicates whether your app collects gameplay content.

## privacy/collected_data/gameplay_content/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/gameplay_content/collection_purposes: int
The reasons your app collects gameplay content. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/gameplay_content/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/gameplay_content/linked_to_user: bool
Indicates whether your app links gameplay content to the user's identity.

## privacy/collected_data/gameplay_content/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/gameplay_content/used_for_tracking: bool
Indicates whether your app uses gameplay content for tracking.

## privacy/collected_data/hands/collected :: var EditorExportPlatformMacOS.privacy/collected_data/hands/collected: bool
Indicates whether your app collects user's hand structure and hand movements.

## privacy/collected_data/hands/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/hands/collection_purposes: int
The reasons your app collects user's hand structure and hand movements. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/hands/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/hands/linked_to_user: bool
Indicates whether your app links user's hand structure and hand movements to the user's identity.

## privacy/collected_data/hands/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/hands/used_for_tracking: bool
Indicates whether your app uses user's hand structure and hand movements for tracking.

## privacy/collected_data/head/collected :: var EditorExportPlatformMacOS.privacy/collected_data/head/collected: bool
Indicates whether your app collects user's head movement.

## privacy/collected_data/head/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/head/collection_purposes: int
The reasons your app collects user's head movement. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/head/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/head/linked_to_user: bool
Indicates whether your app links user's head movement to the user's identity.

## privacy/collected_data/head/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/head/used_for_tracking: bool
Indicates whether your app uses user's head movement for tracking.

## privacy/collected_data/health/collected :: var EditorExportPlatformMacOS.privacy/collected_data/health/collected: bool
Indicates whether your app collects health and medical data.

## privacy/collected_data/health/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/health/collection_purposes: int
The reasons your app collects health and medical data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/health/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/health/linked_to_user: bool
Indicates whether your app links health and medical data to the user's identity.

## privacy/collected_data/health/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/health/used_for_tracking: bool
Indicates whether your app uses health and medical data for tracking.

## privacy/collected_data/name/collected :: var EditorExportPlatformMacOS.privacy/collected_data/name/collected: bool
Indicates whether your app collects user's name.

## privacy/collected_data/name/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/name/collection_purposes: int
The reasons your app collects user's name. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/name/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/name/linked_to_user: bool
Indicates whether your app links user's name to the user's identity.

## privacy/collected_data/name/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/name/used_for_tracking: bool
Indicates whether your app uses user's name for tracking.

## privacy/collected_data/other_contact_info/collected :: var EditorExportPlatformMacOS.privacy/collected_data/other_contact_info/collected: bool
Indicates whether your app collects any other contact information.

## privacy/collected_data/other_contact_info/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/other_contact_info/collection_purposes: int
The reasons your app collects any other contact information. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_contact_info/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/other_contact_info/linked_to_user: bool
Indicates whether your app links any other contact information to the user's identity.

## privacy/collected_data/other_contact_info/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/other_contact_info/used_for_tracking: bool
Indicates whether your app uses any other contact information for tracking.

## privacy/collected_data/other_data_types/collected :: var EditorExportPlatformMacOS.privacy/collected_data/other_data_types/collected: bool
Indicates whether your app collects any other data.

## privacy/collected_data/other_data_types/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/other_data_types/collection_purposes: int
The reasons your app collects any other data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_data_types/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/other_data_types/linked_to_user: bool
Indicates whether your app links any other data to the user's identity.

## privacy/collected_data/other_data_types/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/other_data_types/used_for_tracking: bool
Indicates whether your app uses any other data for tracking.

## privacy/collected_data/other_diagnostic_data/collected :: var EditorExportPlatformMacOS.privacy/collected_data/other_diagnostic_data/collected: bool
Indicates whether your app collects any other diagnostic data.

## privacy/collected_data/other_diagnostic_data/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/other_diagnostic_data/collection_purposes: int
The reasons your app collects any other diagnostic data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_diagnostic_data/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/other_diagnostic_data/linked_to_user: bool
Indicates whether your app links any other diagnostic data to the user's identity.

## privacy/collected_data/other_diagnostic_data/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/other_diagnostic_data/used_for_tracking: bool
Indicates whether your app uses any other diagnostic data for tracking.

## privacy/collected_data/other_financial_info/collected :: var EditorExportPlatformMacOS.privacy/collected_data/other_financial_info/collected: bool
Indicates whether your app collects any other financial information.

## privacy/collected_data/other_financial_info/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/other_financial_info/collection_purposes: int
The reasons your app collects any other financial information. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_financial_info/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/other_financial_info/linked_to_user: bool
Indicates whether your app links any other financial information to the user's identity.

## privacy/collected_data/other_financial_info/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/other_financial_info/used_for_tracking: bool
Indicates whether your app uses any other financial information for tracking.

## privacy/collected_data/other_usage_data/collected :: var EditorExportPlatformMacOS.privacy/collected_data/other_usage_data/collected: bool
Indicates whether your app collects any other usage data.

## privacy/collected_data/other_usage_data/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/other_usage_data/collection_purposes: int
The reasons your app collects any other usage data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_usage_data/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/other_usage_data/linked_to_user: bool
Indicates whether your app links any other usage data to the user's identity.

## privacy/collected_data/other_usage_data/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/other_usage_data/used_for_tracking: bool
Indicates whether your app uses any other usage data for tracking.

## privacy/collected_data/other_user_content/collected :: var EditorExportPlatformMacOS.privacy/collected_data/other_user_content/collected: bool
Indicates whether your app collects any other user generated content.

## privacy/collected_data/other_user_content/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/other_user_content/collection_purposes: int
The reasons your app collects any other user generated content. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/other_user_content/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/other_user_content/linked_to_user: bool
Indicates whether your app links any other user generated content to the user's identity.

## privacy/collected_data/other_user_content/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/other_user_content/used_for_tracking: bool
Indicates whether your app uses any other user generated content for tracking.

## privacy/collected_data/payment_info/collected :: var EditorExportPlatformMacOS.privacy/collected_data/payment_info/collected: bool
Indicates whether your app collects payment information.

## privacy/collected_data/payment_info/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/payment_info/collection_purposes: int
The reasons your app collects payment information. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/payment_info/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/payment_info/linked_to_user: bool
Indicates whether your app links payment information to the user's identity.

## privacy/collected_data/payment_info/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/payment_info/used_for_tracking: bool
Indicates whether your app uses payment information for tracking.

## privacy/collected_data/performance_data/collected :: var EditorExportPlatformMacOS.privacy/collected_data/performance_data/collected: bool
Indicates whether your app collects performance data.

## privacy/collected_data/performance_data/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/performance_data/collection_purposes: int
The reasons your app collects performance data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/performance_data/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/performance_data/linked_to_user: bool
Indicates whether your app links performance data to the user's identity.

## privacy/collected_data/performance_data/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/performance_data/used_for_tracking: bool
Indicates whether your app uses performance data for tracking.

## privacy/collected_data/phone_number/collected :: var EditorExportPlatformMacOS.privacy/collected_data/phone_number/collected: bool
Indicates whether your app collects phone number.

## privacy/collected_data/phone_number/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/phone_number/collection_purposes: int
The reasons your app collects phone number. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/phone_number/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/phone_number/linked_to_user: bool
Indicates whether your app links phone number to the user's identity.

## privacy/collected_data/phone_number/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/phone_number/used_for_tracking: bool
Indicates whether your app uses phone number for tracking.

## privacy/collected_data/photos_or_videos/collected :: var EditorExportPlatformMacOS.privacy/collected_data/photos_or_videos/collected: bool
Indicates whether your app collects photos or videos.

## privacy/collected_data/photos_or_videos/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/photos_or_videos/collection_purposes: int
The reasons your app collects photos or videos. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/photos_or_videos/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/photos_or_videos/linked_to_user: bool
Indicates whether your app links photos or videos to the user's identity.

## privacy/collected_data/photos_or_videos/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/photos_or_videos/used_for_tracking: bool
Indicates whether your app uses photos or videos for tracking.

## privacy/collected_data/physical_address/collected :: var EditorExportPlatformMacOS.privacy/collected_data/physical_address/collected: bool
Indicates whether your app collects physical address.

## privacy/collected_data/physical_address/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/physical_address/collection_purposes: int
The reasons your app collects physical address. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/physical_address/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/physical_address/linked_to_user: bool
Indicates whether your app links physical address to the user's identity.

## privacy/collected_data/physical_address/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/physical_address/used_for_tracking: bool
Indicates whether your app uses physical address for tracking.

## privacy/collected_data/precise_location/collected :: var EditorExportPlatformMacOS.privacy/collected_data/precise_location/collected: bool
Indicates whether your app collects precise location data.

## privacy/collected_data/precise_location/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/precise_location/collection_purposes: int
The reasons your app collects precise location data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/precise_location/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/precise_location/linked_to_user: bool
Indicates whether your app links precise location data to the user's identity.

## privacy/collected_data/precise_location/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/precise_location/used_for_tracking: bool
Indicates whether your app uses precise location data for tracking.

## privacy/collected_data/product_interaction/collected :: var EditorExportPlatformMacOS.privacy/collected_data/product_interaction/collected: bool
Indicates whether your app collects product interaction data.

## privacy/collected_data/product_interaction/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/product_interaction/collection_purposes: int
The reasons your app collects product interaction data. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/product_interaction/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/product_interaction/linked_to_user: bool
Indicates whether your app links product interaction data to the user's identity.

## privacy/collected_data/product_interaction/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/product_interaction/used_for_tracking: bool
Indicates whether your app uses product interaction data for tracking.

## privacy/collected_data/purchase_history/collected :: var EditorExportPlatformMacOS.privacy/collected_data/purchase_history/collected: bool
Indicates whether your app collects purchase history.

## privacy/collected_data/purchase_history/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/purchase_history/collection_purposes: int
The reasons your app collects purchase history. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/purchase_history/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/purchase_history/linked_to_user: bool
Indicates whether your app links purchase history to the user's identity.

## privacy/collected_data/purchase_history/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/purchase_history/used_for_tracking: bool
Indicates whether your app uses purchase history for tracking.

## privacy/collected_data/search_history/collected :: var EditorExportPlatformMacOS.privacy/collected_data/search_history/collected: bool
Indicates whether your app collects search history.

## privacy/collected_data/search_history/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/search_history/collection_purposes: int
The reasons your app collects search history. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/search_history/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/search_history/linked_to_user: bool
Indicates whether your app links search history to the user's identity.

## privacy/collected_data/search_history/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/search_history/used_for_tracking: bool
Indicates whether your app uses search history for tracking.

## privacy/collected_data/sensitive_info/collected :: var EditorExportPlatformMacOS.privacy/collected_data/sensitive_info/collected: bool
Indicates whether your app collects sensitive user information.

## privacy/collected_data/sensitive_info/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/sensitive_info/collection_purposes: int
The reasons your app collects sensitive user information. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/sensitive_info/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/sensitive_info/linked_to_user: bool
Indicates whether your app links sensitive user information to the user's identity.

## privacy/collected_data/sensitive_info/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/sensitive_info/used_for_tracking: bool
Indicates whether your app uses sensitive user information for tracking.

## privacy/collected_data/user_id/collected :: var EditorExportPlatformMacOS.privacy/collected_data/user_id/collected: bool
Indicates whether your app collects user IDs.

## privacy/collected_data/user_id/collection_purposes :: var EditorExportPlatformMacOS.privacy/collected_data/user_id/collection_purposes: int
The reasons your app collects user IDs. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_data_use_in_privacy_manifests]Describing data use in privacy manifests[/url].

## privacy/collected_data/user_id/linked_to_user :: var EditorExportPlatformMacOS.privacy/collected_data/user_id/linked_to_user: bool
Indicates whether your app links user IDs to the user's identity.

## privacy/collected_data/user_id/used_for_tracking :: var EditorExportPlatformMacOS.privacy/collected_data/user_id/used_for_tracking: bool
Indicates whether your app uses user IDs for tracking.

## privacy/desktop_folder_usage_description :: var EditorExportPlatformMacOS.privacy/desktop_folder_usage_description: String
A message displayed when requesting access to the user's "Desktop" folder (in English).

## privacy/desktop_folder_usage_description_localized :: var EditorExportPlatformMacOS.privacy/desktop_folder_usage_description_localized: Dictionary
A message displayed when requesting access to the user's "Desktop" folder (localized).

## privacy/documents_folder_usage_description :: var EditorExportPlatformMacOS.privacy/documents_folder_usage_description: String
A message displayed when requesting access to the user's "Documents" folder (in English).

## privacy/documents_folder_usage_description_localized :: var EditorExportPlatformMacOS.privacy/documents_folder_usage_description_localized: Dictionary
A message displayed when requesting access to the user's "Documents" folder (localized).

## privacy/downloads_folder_usage_description :: var EditorExportPlatformMacOS.privacy/downloads_folder_usage_description: String
A message displayed when requesting access to the user's "Downloads" folder (in English).

## privacy/downloads_folder_usage_description_localized :: var EditorExportPlatformMacOS.privacy/downloads_folder_usage_description_localized: Dictionary
A message displayed when requesting access to the user's "Downloads" folder (localized).

## privacy/location_usage_description :: var EditorExportPlatformMacOS.privacy/location_usage_description: String
A message displayed when requesting access to the user's location information (in English).

## privacy/location_usage_description_localized :: var EditorExportPlatformMacOS.privacy/location_usage_description_localized: Dictionary
A message displayed when requesting access to the user's location information (localized).

## privacy/microphone_usage_description :: var EditorExportPlatformMacOS.privacy/microphone_usage_description: String
A message displayed when requesting access to the device's microphone (in English).

## privacy/microphone_usage_description_localized :: var EditorExportPlatformMacOS.privacy/microphone_usage_description_localized: Dictionary
A message displayed when requesting access to the device's microphone (localized).

## privacy/network_volumes_usage_description :: var EditorExportPlatformMacOS.privacy/network_volumes_usage_description: String
A message displayed when requesting access to the user's network drives (in English).

## privacy/network_volumes_usage_description_localized :: var EditorExportPlatformMacOS.privacy/network_volumes_usage_description_localized: Dictionary
A message displayed when requesting access to the user's network drives (localized).

## privacy/photos_library_usage_description :: var EditorExportPlatformMacOS.privacy/photos_library_usage_description: String
A message displayed when requesting access to the user's photo library (in English).

## privacy/photos_library_usage_description_localized :: var EditorExportPlatformMacOS.privacy/photos_library_usage_description_localized: Dictionary
A message displayed when requesting access to the user's photo library (localized).

## privacy/removable_volumes_usage_description :: var EditorExportPlatformMacOS.privacy/removable_volumes_usage_description: String
A message displayed when requesting access to the user's removable drives (in English).

## privacy/removable_volumes_usage_description_localized :: var EditorExportPlatformMacOS.privacy/removable_volumes_usage_description_localized: Dictionary
A message displayed when requesting access to the user's removable drives (localized).

## privacy/tracking_domains :: var EditorExportPlatformMacOS.privacy/tracking_domains: PackedStringArray
The list of internet domains your app connects to that engage in tracking. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files]Privacy manifest files[/url].

## privacy/tracking_enabled :: var EditorExportPlatformMacOS.privacy/tracking_enabled: bool
Indicates whether your app uses data for tracking. See [url=https://developer.apple.com/documentation/bundleresources/privacy_manifest_files]Privacy manifest files[/url].

## shader_baker/enabled :: var EditorExportPlatformMacOS.shader_baker/enabled: bool
If [code]true[/code], shaders will be compiled and embedded in the application. This option is only supported when using the Forward+ or Mobile renderers.
[b]Note:[/b] When exporting as a dedicated server, the shader baker is always disabled since no rendering is performed.

## ssh_remote_deploy/cleanup_script :: var EditorExportPlatformMacOS.ssh_remote_deploy/cleanup_script: String
Script code to execute on the remote host when app is finished.
The following variables can be used in the script:
- [code]{temp_dir}[/code] - Path of temporary folder on the remote, used to upload app and scripts to.
- [code]{archive_name}[/code] - Name of the ZIP containing uploaded application.
- [code]{exe_name}[/code] - Name of application executable.
- [code]{cmd_args}[/code] - Array of the command line argument for the application.

## ssh_remote_deploy/enabled :: var EditorExportPlatformMacOS.ssh_remote_deploy/enabled: bool
Enables remote deploy using SSH/SCP.

## ssh_remote_deploy/extra_args_scp :: var EditorExportPlatformMacOS.ssh_remote_deploy/extra_args_scp: String
Array of the additional command line arguments passed to the SCP.

## ssh_remote_deploy/extra_args_ssh :: var EditorExportPlatformMacOS.ssh_remote_deploy/extra_args_ssh: String
Array of the additional command line arguments passed to the SSH.

## ssh_remote_deploy/host :: var EditorExportPlatformMacOS.ssh_remote_deploy/host: String
Remote host SSH user name and address, in [code]user@address[/code] format.

## ssh_remote_deploy/port :: var EditorExportPlatformMacOS.ssh_remote_deploy/port: String
Remote host SSH port number.

## ssh_remote_deploy/run_script :: var EditorExportPlatformMacOS.ssh_remote_deploy/run_script: String
Script code to execute on the remote host when running the app.
The following variables can be used in the script:
- [code]{temp_dir}[/code] - Path of temporary folder on the remote, used to upload app and scripts to.
- [code]{archive_name}[/code] - Name of the ZIP containing uploaded application.
- [code]{exe_name}[/code] - Name of application executable.
- [code]{cmd_args}[/code] - Array of the command line argument for the application.

## xcode/platform_build :: var EditorExportPlatformMacOS.xcode/platform_build: String
macOS build number used to build application executable.

## xcode/sdk_build :: var EditorExportPlatformMacOS.xcode/sdk_build: String
macOS SDK build number used to build application executable.

## xcode/sdk_name :: var EditorExportPlatformMacOS.xcode/sdk_name: String
macOS SDK name used to build application executable.

## xcode/sdk_version :: var EditorExportPlatformMacOS.xcode/sdk_version: String
macOS SDK version used to build application executable in the [code]major.minor[/code] format.

## xcode/xcode_build :: var EditorExportPlatformMacOS.xcode/xcode_build: String
Xcode build number used to build application executable.

## xcode/xcode_version :: var EditorExportPlatformMacOS.xcode/xcode_version: String
Xcode version used to build application executable.
