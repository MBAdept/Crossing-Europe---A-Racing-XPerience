# AudioEffectSpectrumAnalyzerInstance :: <Native> class AudioEffectSpectrumAnalyzerInstance extends AudioEffectInstance
Queryable instance of an [AudioEffectSpectrumAnalyzer].
The runtime part of an [AudioEffectSpectrumAnalyzer], which can be used to query the magnitude of a frequency range on its host bus.
An instance of this class can be obtained with [method AudioServer.get_bus_effect_instance].

## MAGNITUDE_AVERAGE :: const AudioEffectSpectrumAnalyzerInstance.MAGNITUDE_AVERAGE: MagnitudeMode = 0
Use the average value across the frequency range as magnitude.

## MAGNITUDE_MAX :: const AudioEffectSpectrumAnalyzerInstance.MAGNITUDE_MAX: MagnitudeMode = 1
Use the maximum value of the frequency range as magnitude.

## get_magnitude_for_frequency_range :: func AudioEffectSpectrumAnalyzerInstance.get_magnitude_for_frequency_range(from_hz: float, to_hz: float, mode: int = 1) -> Vector2
Returns the magnitude of the frequencies from [param from_hz] to [param to_hz] in linear energy as a Vector2. The [code]x[/code] component of the return value represents the left stereo channel, and [code]y[/code] represents the right channel.
[param mode] determines how the frequency range will be processed.

### from_hz :: float

### to_hz :: float

### mode :: int
