# GraphElement :: <Native> class GraphElement extends Container
A container that represents a basic element that can be placed inside a [GraphEdit] control.
[GraphElement] allows to create custom elements for a [GraphEdit] graph. By default such elements can be selected, resized, and repositioned, but they cannot be connected. For a graph element that allows for connections see [GraphNode].

## draggable :: var GraphElement.draggable: bool
If [code]true[/code], the user can drag the GraphElement.

## position_offset :: var GraphElement.position_offset: Vector2
The offset of the GraphElement, relative to the scroll offset of the [GraphEdit].

## resizable :: var GraphElement.resizable: bool
If [code]true[/code], the user can resize the GraphElement.
[b]Note:[/b] Dragging the handle will only emit the [signal resize_request] and [signal resize_end] signals, the GraphElement needs to be resized manually.

## scaling_menus :: var GraphElement.scaling_menus: bool
If [code]true[/code], [PopupMenu]s that are descendants of the GraphElement are scaled with the [GraphEdit] zoom.

## selectable :: var GraphElement.selectable: bool
If [code]true[/code], the user can select the GraphElement.

## selected :: var GraphElement.selected: bool
If [code]true[/code], the GraphElement is selected.

## resizer :: <Theme> var GraphElement.resizer: Texture2D
The icon used for the resizer, visible when [member resizable] is enabled.

## delete_request :: func GraphElement.delete_request() -> void
Emitted when removing the GraphElement is requested.

## dragged :: func GraphElement.dragged(from: Vector2, to: Vector2) -> void
Emitted when the GraphElement is dragged.

### from :: Vector2

### to :: Vector2

## node_deselected :: func GraphElement.node_deselected() -> void
Emitted when the GraphElement is deselected.

## node_selected :: func GraphElement.node_selected() -> void
Emitted when the GraphElement is selected.

## position_offset_changed :: func GraphElement.position_offset_changed() -> void
Emitted when the GraphElement is moved.

## raise_request :: func GraphElement.raise_request() -> void
Emitted when displaying the GraphElement over other ones is requested. Happens on focusing (clicking into) the GraphElement.

## resize_end :: func GraphElement.resize_end(new_size: Vector2) -> void
Emitted when releasing the mouse button after dragging the resizer handle (see [member resizable]).

### new_size :: Vector2

## resize_request :: func GraphElement.resize_request(new_size: Vector2) -> void
Emitted when resizing the GraphElement is requested. Happens on dragging the resizer handle (see [member resizable]).

### new_size :: Vector2
