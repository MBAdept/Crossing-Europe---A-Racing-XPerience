# InputEventWithModifiers :: <Native> class InputEventWithModifiers extends InputEventFromWindow
Abstract base class for input events affected by modifier keys like [kbd]Shift[/kbd] and [kbd]Alt[/kbd].
Stores information about mouse, keyboard, and touch gesture input events. This includes information about which modifier keys are pressed, such as [kbd]Shift[/kbd] or [kbd]Alt[/kbd]. See [method Node._input].
[b]Note:[/b] Modifier keys are considered modifiers only when used in combination with another key. As a result, their corresponding member variables, such as [member ctrl_pressed], will return [code]false[/code] if the key is pressed on its own.

## alt_pressed :: var InputEventWithModifiers.alt_pressed: bool
State of the [kbd]Alt[/kbd] modifier.

## command_or_control_autoremap :: var InputEventWithModifiers.command_or_control_autoremap: bool
Automatically use [kbd]Meta[/kbd] ([kbd]Cmd[/kbd]) on macOS and [kbd]Ctrl[/kbd] on other platforms. If [code]true[/code], [member ctrl_pressed] and [member meta_pressed] cannot be set.

## ctrl_pressed :: var InputEventWithModifiers.ctrl_pressed: bool
State of the [kbd]Ctrl[/kbd] modifier.

## device :: var InputEventWithModifiers.device: int

## meta_pressed :: var InputEventWithModifiers.meta_pressed: bool
State of the [kbd]Meta[/kbd] modifier. On Windows and Linux, this represents the Windows key (sometimes called "meta" or "super" on Linux). On macOS, this represents the Command key.

## shift_pressed :: var InputEventWithModifiers.shift_pressed: bool
State of the [kbd]Shift[/kbd] modifier.

## get_modifiers_mask :: func InputEventWithModifiers.get_modifiers_mask() -> int
Returns the keycode combination of modifier keys.

## is_command_or_control_pressed :: func InputEventWithModifiers.is_command_or_control_pressed() -> bool
On macOS, returns [code]true[/code] if [kbd]Meta[/kbd] ([kbd]Cmd[/kbd]) is pressed.
On other platforms, returns [code]true[/code] if [kbd]Ctrl[/kbd] is pressed.
