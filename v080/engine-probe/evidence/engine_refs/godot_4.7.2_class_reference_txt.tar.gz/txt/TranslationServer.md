# TranslationServer :: <Native> class TranslationServer extends Object
The server responsible for language translations.
The translation server is the API backend that manages all language translations.
Translations are stored in [TranslationDomain]s, which can be accessed by name. The most commonly used translation domain is the main translation domain. It always exists and can be accessed using an empty [StringName]. The translation server provides wrapper methods for accessing the main translation domain directly, without having to fetch the translation domain first. Custom translation domains are mainly for advanced usages like editor plugins. Names starting with [code]godot.[/code] are reserved for engine internals.

## pseudolocalization_enabled :: var TranslationServer.pseudolocalization_enabled: bool
If [code]true[/code], enables the use of pseudolocalization on the main translation domain. See [member ProjectSettings.internationalization/pseudolocalization/use_pseudolocalization] for details.

## add_translation :: func TranslationServer.add_translation(translation: Translation) -> void
Adds a translation to the main translation domain.

### translation :: Translation

## clear :: func TranslationServer.clear() -> void
Removes all translations from the main translation domain.

## compare_locales :: func TranslationServer.compare_locales(locale_a: String, locale_b: String) -> int
Compares two locales and returns a similarity score between [code]0[/code] (no match) and [code]10[/code] (full match).

### locale_a :: String

### locale_b :: String

## find_translations :: func TranslationServer.find_translations(locale: String, exact: bool) -> Translation[]
Returns the [Translation] instances in the main translation domain that match [param locale] (see [method compare_locales]). If [param exact] is [code]true[/code], only instances whose locale exactly equals [param locale] will be returned.

### locale :: String

### exact :: bool

## format_number :: func TranslationServer.format_number(number: String, locale: String) -> String
Converts a number from Western Arabic (0..9) to the numeral system used in the given [param locale].

### number :: String

### locale :: String

## get_all_countries :: func TranslationServer.get_all_countries() -> PackedStringArray
Returns an array of known country codes.

## get_all_languages :: func TranslationServer.get_all_languages() -> PackedStringArray
Returns array of known language codes.

## get_all_scripts :: func TranslationServer.get_all_scripts() -> PackedStringArray
Returns an array of known script codes.

## get_country_name :: func TranslationServer.get_country_name(country: String) -> String
Returns a readable country name for the [param country] code.

### country :: String

## get_language_name :: func TranslationServer.get_language_name(language: String) -> String
Returns a readable language name for the [param language] code.

### language :: String

## get_loaded_locales :: func TranslationServer.get_loaded_locales() -> PackedStringArray
Returns an array of all loaded locales of the project.

## get_locale :: func TranslationServer.get_locale() -> String
Returns the current locale of the project.
See also [method OS.get_locale] and [method OS.get_locale_language] to query the locale of the user system.

## get_locale_name :: func TranslationServer.get_locale_name(locale: String) -> String
Returns a locale's language and its variant (e.g. [code]"en_US"[/code] would return [code]"English (United States)"[/code]).

### locale :: String

## get_or_add_domain :: func TranslationServer.get_or_add_domain(domain: StringName) -> TranslationDomain
Returns the translation domain with the specified name. An empty translation domain will be created and added if it does not exist.

### domain :: StringName

## get_percent_sign :: func TranslationServer.get_percent_sign(locale: String) -> String
Returns the percent sign used in the given [param locale].

### locale :: String

## get_plural_rules :: func TranslationServer.get_plural_rules(locale: String) -> String
Returns the default plural rules for the [param locale].

### locale :: String

## get_script_name :: func TranslationServer.get_script_name(script: String) -> String
Returns a readable script name for the [param script] code.

### script :: String

## get_tool_locale :: func TranslationServer.get_tool_locale() -> String
Returns the current locale of the editor.
[b]Note:[/b] When called from an exported project returns the same value as [method get_locale].

## get_translation_object :: func TranslationServer.get_translation_object(locale: String) -> Translation
Returns the [Translation] instance that best matches [param locale] in the main translation domain. Returns [code]null[/code] if there are no matches.

### locale :: String

## get_translations :: func TranslationServer.get_translations() -> Translation[]
Returns all available [Translation] instances in the main translation domain as added by [method add_translation].

## has_domain :: func TranslationServer.has_domain(domain: StringName) -> bool
Returns [code]true[/code] if a translation domain with the specified name exists.

### domain :: StringName

## has_translation :: func TranslationServer.has_translation(translation: Translation) -> bool
Returns [code]true[/code] if the main translation domain contains the given [param translation].

### translation :: Translation

## has_translation_for_locale :: func TranslationServer.has_translation_for_locale(locale: String, exact: bool) -> bool
Returns [code]true[/code] if there are any [Translation] instances in the main translation domain that match [param locale] (see [method compare_locales]). If [param exact] is [code]true[/code], only instances whose locale exactly equals [param locale] are considered.

### locale :: String

### exact :: bool

## parse_number :: func TranslationServer.parse_number(number: String, locale: String) -> String
Converts [param number] from the numeral system used in the given [param locale] to Western Arabic (0..9).

### number :: String

### locale :: String

## pseudolocalize :: func TranslationServer.pseudolocalize(message: StringName) -> StringName
Returns the pseudolocalized string based on the [param message] passed in.
[b]Note:[/b] This method always uses the main translation domain.

### message :: StringName

## reload_pseudolocalization :: func TranslationServer.reload_pseudolocalization() -> void
Reparses the pseudolocalization options and reloads the translation for the main translation domain.

## remove_domain :: func TranslationServer.remove_domain(domain: StringName) -> void
Removes the translation domain with the specified name.
[b]Note:[/b] Trying to remove the main translation domain is an error.

### domain :: StringName

## remove_translation :: func TranslationServer.remove_translation(translation: Translation) -> void
Removes the given translation from the main translation domain.

### translation :: Translation

## set_locale :: func TranslationServer.set_locale(locale: String) -> void
Sets the locale of the project. The [param locale] string will be standardized to match known locales (e.g. [code]en-US[/code] would be matched to [code]en_US[/code]).
If translations have been loaded beforehand for the new locale, they will be applied.

### locale :: String

## standardize_locale :: func TranslationServer.standardize_locale(locale: String, add_defaults: bool = false) -> String
Returns a [param locale] string standardized to match known locales (e.g. [code]en-US[/code] would be matched to [code]en_US[/code]). If [param add_defaults] is [code]true[/code], the locale may have a default script or country added.

### locale :: String

### add_defaults :: bool

## translate :: func TranslationServer.translate(message: StringName, context: StringName = &"") -> StringName
Returns the current locale's translation for the given message and context.
[b]Note:[/b] This method always uses the main translation domain.

### message :: StringName

### context :: StringName

## translate_plural :: func TranslationServer.translate_plural(message: StringName, plural_message: StringName, n: int, context: StringName = &"") -> StringName
Returns the current locale's translation for the given message, plural message and context.
The number [param n] is the number or quantity of the plural object. It will be used to guide the translation system to fetch the correct plural form for the selected language.
[b]Note:[/b] This method always uses the main translation domain.

### message :: StringName

### plural_message :: StringName

### n :: int

### context :: StringName
