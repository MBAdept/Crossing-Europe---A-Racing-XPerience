# AudioStreamGeneratorPlayback :: <Native> class AudioStreamGeneratorPlayback extends AudioStreamPlaybackResampled
Plays back audio generated using [AudioStreamGenerator].
This class is meant to be used with [AudioStreamGenerator] to play back the generated audio in real-time.

## can_push_buffer :: func AudioStreamGeneratorPlayback.can_push_buffer(amount: int) -> bool
Returns [code]true[/code] if a buffer of the size [param amount] can be pushed to the audio sample data buffer without overflowing it, [code]false[/code] otherwise.

### amount :: int

## clear_buffer :: func AudioStreamGeneratorPlayback.clear_buffer() -> void
Clears the audio sample data buffer.

## get_frames_available :: func AudioStreamGeneratorPlayback.get_frames_available() -> int
Returns the number of frames that can be pushed to the audio sample data buffer without overflowing it. If the result is [code]0[/code], the buffer is full.

## get_skips :: func AudioStreamGeneratorPlayback.get_skips() -> int
Returns the number of times the playback skipped due to a buffer underrun in the audio sample data. This value is reset at the start of the playback.

## push_buffer :: func AudioStreamGeneratorPlayback.push_buffer(frames: PackedVector2Array) -> bool
Pushes several audio data frames to the buffer. This is usually more efficient than [method push_frame] in C# and compiled languages via GDExtension, but [method push_buffer] may be [i]less[/i] efficient in GDScript.

### frames :: PackedVector2Array

## push_frame :: func AudioStreamGeneratorPlayback.push_frame(frame: Vector2) -> bool
Pushes a single audio data frame to the buffer. This is usually less efficient than [method push_buffer] in C# and compiled languages via GDExtension, but [method push_frame] may be [i]more[/i] efficient in GDScript.

### frame :: Vector2
