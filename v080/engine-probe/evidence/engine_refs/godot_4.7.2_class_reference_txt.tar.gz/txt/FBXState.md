# FBXState :: <Native> class FBXState extends GLTFState
The FBXState handles the state data imported from FBX files.

## allow_geometry_helper_nodes :: var FBXState.allow_geometry_helper_nodes: bool
If [code]true[/code], the import process used auxiliary nodes called geometry helper nodes. These nodes help preserve the pivots and transformations of the original 3D model during import.
