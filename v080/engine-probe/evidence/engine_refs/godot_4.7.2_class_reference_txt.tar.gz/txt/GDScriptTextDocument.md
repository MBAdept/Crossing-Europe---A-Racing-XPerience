# GDScriptTextDocument :: <Native> class GDScriptTextDocument extends RefCounted
Document related language server functionality.
Provides language server functionality related to documents.

## codeLens :: func GDScriptTextDocument.codeLens(params: Dictionary) -> Array

### params :: Dictionary

## colorPresentation :: func GDScriptTextDocument.colorPresentation(params: Dictionary) -> Array

### params :: Dictionary

## completion :: func GDScriptTextDocument.completion(params: Dictionary) -> Array

### params :: Dictionary

## declaration :: func GDScriptTextDocument.declaration(params: Dictionary) -> Variant

### params :: Dictionary

## definition :: func GDScriptTextDocument.definition(params: Dictionary) -> Array

### params :: Dictionary

## didChange :: func GDScriptTextDocument.didChange(params: Variant) -> void

### params :: Variant

## didClose :: func GDScriptTextDocument.didClose(params: Variant) -> void

### params :: Variant

## didOpen :: func GDScriptTextDocument.didOpen(params: Variant) -> void

### params :: Variant

## didSave :: func GDScriptTextDocument.didSave(params: Variant) -> void

### params :: Variant

## documentLink :: func GDScriptTextDocument.documentLink(params: Dictionary) -> Array

### params :: Dictionary

## documentSymbol :: func GDScriptTextDocument.documentSymbol(params: Dictionary) -> Array

### params :: Dictionary

## foldingRange :: func GDScriptTextDocument.foldingRange(params: Dictionary) -> Array

### params :: Dictionary

## hover :: func GDScriptTextDocument.hover(params: Dictionary) -> Variant

### params :: Dictionary

## nativeSymbol :: func GDScriptTextDocument.nativeSymbol(params: Dictionary) -> Variant

### params :: Dictionary

## prepareRename :: func GDScriptTextDocument.prepareRename(params: Dictionary) -> Variant

### params :: Dictionary

## references :: func GDScriptTextDocument.references(params: Dictionary) -> Array

### params :: Dictionary

## rename :: func GDScriptTextDocument.rename(params: Dictionary) -> Dictionary

### params :: Dictionary

## resolve :: func GDScriptTextDocument.resolve(params: Dictionary) -> Dictionary

### params :: Dictionary

## show_native_symbol_in_editor :: func GDScriptTextDocument.show_native_symbol_in_editor(symbol_id: String) -> void

### symbol_id :: String

## signatureHelp :: func GDScriptTextDocument.signatureHelp(params: Dictionary) -> Variant

### params :: Dictionary

## willSaveWaitUntil :: func GDScriptTextDocument.willSaveWaitUntil(params: Variant) -> void

### params :: Variant
