# GDExtension :: <Native> class GDExtension extends Resource
A native library for GDExtension.
The [GDExtension] resource type represents a [url=https://en.wikipedia.org/wiki/Shared_library]shared library[/url] which can expand the functionality of the engine. The [GDExtensionManager] singleton is responsible for loading, reloading, and unloading [GDExtension] resources.
[b]Note:[/b] GDExtension itself is not a scripting language and has no relation to [GDScript] resources.

## INITIALIZATION_LEVEL_CORE :: const GDExtension.INITIALIZATION_LEVEL_CORE: InitializationLevel = 0
The library is initialized at the same time as the core features of the engine.

## INITIALIZATION_LEVEL_SERVERS :: const GDExtension.INITIALIZATION_LEVEL_SERVERS: InitializationLevel = 1
The library is initialized at the same time as the engine's servers (such as [RenderingServer] or [PhysicsServer3D]).

## INITIALIZATION_LEVEL_SCENE :: const GDExtension.INITIALIZATION_LEVEL_SCENE: InitializationLevel = 2
The library is initialized at the same time as the engine's scene-related classes.

## INITIALIZATION_LEVEL_EDITOR :: const GDExtension.INITIALIZATION_LEVEL_EDITOR: InitializationLevel = 3
The library is initialized at the same time as the engine's editor classes. Only happens when loading the GDExtension in the editor.

## get_minimum_library_initialization_level :: func GDExtension.get_minimum_library_initialization_level() -> int
Returns the lowest level required for this extension to be properly initialized (see the [enum InitializationLevel] enum).

## is_library_open :: func GDExtension.is_library_open() -> bool
Returns [code]true[/code] if this extension's library has been opened.
