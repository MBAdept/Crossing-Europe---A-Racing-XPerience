# AnimatedSprite2D :: <Native> class AnimatedSprite2D extends Node2D
Sprite node that contains multiple textures as frames to play for animation.
[AnimatedSprite2D] is similar to the [Sprite2D] node, except it carries multiple textures as animation frames. Animations are created using a [SpriteFrames] resource, which allows you to import image files (or a folder containing said files) to provide the animation frames for the sprite. The [SpriteFrames] resource can be configured in the editor via the SpriteFrames bottom panel.

## animation :: var AnimatedSprite2D.animation: StringName
The current animation from the [member sprite_frames] resource. If this value is changed, the [member frame] counter and the [member frame_progress] are reset.

## autoplay :: var AnimatedSprite2D.autoplay: String
The key of the animation to play when the scene loads.

## centered :: var AnimatedSprite2D.centered: bool
If [code]true[/code], texture will be centered.
[b]Note:[/b] For games with a pixel art aesthetic, textures may appear deformed when centered. This is caused by their position being between pixels. To prevent this, set this property to [code]false[/code], or consider enabling [member ProjectSettings.rendering/2d/snap/snap_2d_vertices_to_pixel] and [member ProjectSettings.rendering/2d/snap/snap_2d_transforms_to_pixel].

## flip_h :: var AnimatedSprite2D.flip_h: bool
If [code]true[/code], texture is flipped horizontally.

## flip_v :: var AnimatedSprite2D.flip_v: bool
If [code]true[/code], texture is flipped vertically.

## frame :: var AnimatedSprite2D.frame: int
The displayed animation frame's index. Setting this property also resets [member frame_progress]. If this is not desired, use [method set_frame_and_progress].

## frame_progress :: var AnimatedSprite2D.frame_progress: float
The progress value between [code]0.0[/code] and [code]1.0[/code] until the current frame transitions to the next frame. If the animation is playing backwards, the value transitions from [code]1.0[/code] to [code]0.0[/code].

## offset :: var AnimatedSprite2D.offset: Vector2
The texture's drawing offset.

## speed_scale :: var AnimatedSprite2D.speed_scale: float
The speed scaling ratio. For example, if this value is [code]1[/code], then the animation plays at normal speed. If it's [code]0.5[/code], then it plays at half speed. If it's [code]2[/code], then it plays at double speed.
If set to a negative value, the animation is played in reverse. If set to [code]0[/code], the animation will not advance.

## sprite_frames :: var AnimatedSprite2D.sprite_frames: SpriteFrames
The [SpriteFrames] resource containing the animation(s). Allows you the option to load, edit, clear, make unique and save the states of the [SpriteFrames] resource.

## get_playing_speed :: func AnimatedSprite2D.get_playing_speed() -> float
Returns the actual playing speed of current animation or [code]0[/code] if not playing. This speed is the [member speed_scale] property multiplied by [code]custom_speed[/code] argument specified when calling the [method play] method.
Returns a negative value if the current animation is playing backwards.

## is_playing :: func AnimatedSprite2D.is_playing() -> bool
Returns [code]true[/code] if an animation is currently playing (even if [member speed_scale] and/or [code]custom_speed[/code] are [code]0[/code]).

## pause :: func AnimatedSprite2D.pause() -> void
Pauses the currently playing animation. The [member frame] and [member frame_progress] will be kept and calling [method play] or [method play_backwards] without arguments will resume the animation from the current playback position.
See also [method stop].

## play :: func AnimatedSprite2D.play(name: StringName = &"", custom_speed: float = 1.0, from_end: bool = false) -> void
Plays the animation with key [param name]. If [param custom_speed] is negative and [param from_end] is [code]true[/code], the animation will play backwards (which is equivalent to calling [method play_backwards]).
If this method is called with that same animation [param name], or with no [param name] parameter, the assigned animation will resume playing if it was paused.

### name :: StringName

### custom_speed :: float

### from_end :: bool

## play_backwards :: func AnimatedSprite2D.play_backwards(name: StringName = &"") -> void
Plays the animation with key [param name] in reverse.
This method is a shorthand for [method play] with [code]custom_speed = -1.0[/code] and [code]from_end = true[/code], so see its description for more information.

### name :: StringName

## set_frame_and_progress :: func AnimatedSprite2D.set_frame_and_progress(frame: int, progress: float) -> void
Sets [member frame] and [member frame_progress] to the given values. Unlike setting [member frame], this method does not reset the [member frame_progress] to [code]0.0[/code] implicitly.
[b]Example:[/b] Change the animation while keeping the same [member frame] and [member frame_progress]:
[codeblocks]
[gdscript]
var current_frame = animated_sprite.get_frame()
var current_progress = animated_sprite.get_frame_progress()
animated_sprite.play("walk_another_skin")
animated_sprite.set_frame_and_progress(current_frame, current_progress)
[/gdscript]
[/codeblocks]

### frame :: int

### progress :: float

## stop :: func AnimatedSprite2D.stop() -> void
Stops the currently playing animation. The animation position is reset to [code]0[/code] and the [code]custom_speed[/code] is reset to [code]1.0[/code]. See also [method pause].

## animation_changed :: func AnimatedSprite2D.animation_changed() -> void
Emitted when [member animation] changes.

## animation_finished :: func AnimatedSprite2D.animation_finished() -> void
Emitted when the animation reaches the end, or the start if it is played in reverse. When the animation finishes, it pauses the playback.
[b]Note:[/b] This signal is not emitted if an animation is looping.

## animation_looped :: func AnimatedSprite2D.animation_looped() -> void
Emitted when the animation loops.

## frame_changed :: func AnimatedSprite2D.frame_changed() -> void
Emitted when [member frame] changes.

## sprite_frames_changed :: func AnimatedSprite2D.sprite_frames_changed() -> void
Emitted when [member sprite_frames] changes.
