# AudioStreamPlayer2D :: <Native> class AudioStreamPlayer2D extends Node2D
Plays positional sound in 2D space.
Plays audio that is attenuated with distance to the listener.
By default, audio is heard from the screen center. This can be changed by adding an [AudioListener2D] node to the scene and enabling it by calling [method AudioListener2D.make_current] on it.
See also [AudioStreamPlayer] to play a sound non-positionally.
[b]Note:[/b] Hiding an [AudioStreamPlayer2D] node does not disable its audio output. To temporarily disable an [AudioStreamPlayer2D]'s audio output, set [member volume_db] to a very low value like [code]-100[/code] (which isn't audible to human hearing).

## area_mask :: var AudioStreamPlayer2D.area_mask: int
Determines which [Area2D] layers affect the sound for reverb and audio bus effects. Areas can be used to redirect [AudioStream]s so that they play in a certain audio bus. An example of how you might use this is making a "water" area so that sounds played in the water are redirected through an audio bus to make them sound like they are being played underwater.

## attenuation :: var AudioStreamPlayer2D.attenuation: float
The volume is attenuated over distance with this as an exponent.

## autoplay :: var AudioStreamPlayer2D.autoplay: bool
If [code]true[/code], audio plays when added to scene tree.

## bus :: var AudioStreamPlayer2D.bus: StringName
Bus on which this audio is playing.
[b]Note:[/b] When setting this property, keep in mind that no validation is performed to see if the given name matches an existing bus. This is because audio bus layouts might be loaded after this property is set. If this given name can't be resolved at runtime, it will fall back to [code]"Master"[/code].

## max_distance :: var AudioStreamPlayer2D.max_distance: float
Maximum distance from which audio is still hearable.

## max_polyphony :: var AudioStreamPlayer2D.max_polyphony: int
The maximum number of sounds this node can play at the same time. Playing additional sounds after this value is reached will cut off the oldest sounds.

## panning_strength :: var AudioStreamPlayer2D.panning_strength: float
Scales the panning strength for this node by multiplying the base [member ProjectSettings.audio/general/2d_panning_strength] with this factor. Higher values will pan audio from left to right more dramatically than lower values.

## pitch_scale :: var AudioStreamPlayer2D.pitch_scale: float
The pitch and the tempo of the audio, as a multiplier of the audio sample's sample rate.

## playback_type :: var AudioStreamPlayer2D.playback_type: AudioServer.PlaybackType
The playback type of the stream player. If set other than to the default value, it will force that playback type.

## playing :: var AudioStreamPlayer2D.playing: bool
If [code]true[/code], audio is playing or is queued to be played (see [method play]).

## stream :: var AudioStreamPlayer2D.stream: AudioStream
The [AudioStream] object to be played.

## stream_paused :: var AudioStreamPlayer2D.stream_paused: bool
If [code]true[/code], the playback is paused. You can resume it by setting [member stream_paused] to [code]false[/code].

## volume_db :: var AudioStreamPlayer2D.volume_db: float
Base volume before attenuation, in decibels.

## volume_linear :: var AudioStreamPlayer2D.volume_linear: float
Base volume before attenuation, as a linear value.
[b]Note:[/b] This member modifies [member volume_db] for convenience. The returned value is equivalent to the result of [method @GlobalScope.db_to_linear] on [member volume_db]. Setting this member is equivalent to setting [member volume_db] to the result of [method @GlobalScope.linear_to_db] on a value.

## get_playback_position :: func AudioStreamPlayer2D.get_playback_position() -> float
Returns the position in the [AudioStream].

## get_stream_playback :: func AudioStreamPlayer2D.get_stream_playback() -> AudioStreamPlayback
Returns the [AudioStreamPlayback] object associated with this [AudioStreamPlayer2D].

## has_stream_playback :: func AudioStreamPlayer2D.has_stream_playback() -> bool
Returns whether the [AudioStreamPlayer] can return the [AudioStreamPlayback] object or not.

## play :: func AudioStreamPlayer2D.play(from_position: float = 0.0) -> void
Queues the audio to play on the next physics frame, from the given position [param from_position], in seconds.

### from_position :: float

## seek :: func AudioStreamPlayer2D.seek(to_position: float) -> void
Sets the position from which audio will be played, in seconds.

### to_position :: float

## stop :: func AudioStreamPlayer2D.stop() -> void
Stops the audio.

## finished :: func AudioStreamPlayer2D.finished() -> void
Emitted when the audio stops playing.
