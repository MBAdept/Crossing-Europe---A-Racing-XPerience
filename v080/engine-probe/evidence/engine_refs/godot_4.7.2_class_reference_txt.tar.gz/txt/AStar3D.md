# AStar3D :: <Native> class AStar3D extends RefCounted
An implementation of A* for finding the shortest path between two vertices on a connected graph in 3D space.
A* (A star) is a computer algorithm used in pathfinding and graph traversal, the process of plotting short paths among vertices (points), passing through a given set of edges (segments). It enjoys widespread use due to its performance and accuracy. Godot's A* implementation uses points in 3D space and Euclidean distances by default.
You must add points manually with [method add_point] and create segments manually with [method connect_points]. Once done, you can test if there is a path between two points with the [method are_points_connected] function, get a path containing indices by [method get_id_path], or one containing actual coordinates with [method get_point_path].
It is also possible to use non-Euclidean distances. To do so, create a script that extends [AStar3D] and override the methods [method _compute_cost] and [method _estimate_cost]. Both should take two point IDs and return the distance between the corresponding points.
[b]Example:[/b] Use Manhattan distance instead of Euclidean distance:
[codeblocks]
[gdscript]
class_name MyAStar3D
extends AStar3D

func _compute_cost(u, v):
	var u_pos = get_point_position(u)
	var v_pos = get_point_position(v)
	return abs(u_pos.x - v_pos.x) + abs(u_pos.y - v_pos.y) + abs(u_pos.z - v_pos.z)

func _estimate_cost(u, v):
	var u_pos = get_point_position(u)
	var v_pos = get_point_position(v)
	return abs(u_pos.x - v_pos.x) + abs(u_pos.y - v_pos.y) + abs(u_pos.z - v_pos.z)
[/gdscript]
[csharp]
using Godot;

[GlobalClass]
public partial class MyAStar3D : AStar3D
{
	public override float _ComputeCost(long fromId, long toId)
	{
		Vector3 fromPoint = GetPointPosition(fromId);
		Vector3 toPoint = GetPointPosition(toId);

		return Mathf.Abs(fromPoint.X - toPoint.X) + Mathf.Abs(fromPoint.Y - toPoint.Y) + Mathf.Abs(fromPoint.Z - toPoint.Z);
	}

	public override float _EstimateCost(long fromId, long toId)
	{
		Vector3 fromPoint = GetPointPosition(fromId);
		Vector3 toPoint = GetPointPosition(toId);
		return Mathf.Abs(fromPoint.X - toPoint.X) + Mathf.Abs(fromPoint.Y - toPoint.Y) + Mathf.Abs(fromPoint.Z - toPoint.Z);
	}
}
[/csharp]
[/codeblocks]
[method _estimate_cost] should return a lower bound of the distance, i.e. [code]_estimate_cost(u, v) <= _compute_cost(u, v)[/code]. This serves as a hint to the algorithm because the custom [method _compute_cost] might be computation-heavy. If this is not the case, make [method _estimate_cost] return the same value as [method _compute_cost] to provide the algorithm with the most accurate information.
If the default [method _estimate_cost] and [method _compute_cost] methods are used, or if the supplied [method _estimate_cost] method returns a lower bound of the cost, then the paths returned by A* will be the lowest-cost paths. Here, the cost of a path equals the sum of the [method _compute_cost] results of all segments in the path multiplied by the [code]weight_scale[/code]s of the endpoints of the respective segments. If the default methods are used and the [code]weight_scale[/code]s of all points are set to [code]1.0[/code], then this equals the sum of Euclidean distances of all segments in the path.

## neighbor_filter_enabled :: var AStar3D.neighbor_filter_enabled: bool
If [code]true[/code] enables the filtering of neighbors via [method _filter_neighbor].

## _compute_cost :: func AStar3D._compute_cost(from_id: int, to_id: int) -> float
Called when computing the cost between two connected points.
Note that this function is hidden in the default [AStar3D] class.

### from_id :: int

### to_id :: int

## _estimate_cost :: func AStar3D._estimate_cost(from_id: int, end_id: int) -> float
Called when estimating the cost between a point and the path's ending point.
Note that this function is hidden in the default [AStar3D] class.

### from_id :: int

### end_id :: int

## _filter_neighbor :: func AStar3D._filter_neighbor(from_id: int, neighbor_id: int) -> bool
Called when neighboring point enters processing and if [member neighbor_filter_enabled] is [code]true[/code]. If [code]true[/code] is returned the point will not be processed.
Note that this function is hidden in the default [AStar3D] class.

### from_id :: int

### neighbor_id :: int

## add_point :: func AStar3D.add_point(id: int, position: Vector3, weight_scale: float = 1.0) -> void
Adds a new point at the given position with the given identifier. The [param id] must be 0 or larger, and the [param weight_scale] must be 0.0 or greater.
The [param weight_scale] is multiplied by the result of [method _compute_cost] when determining the overall cost of traveling across a segment from a neighboring point to this point. Thus, all else being equal, the algorithm prefers points with lower [param weight_scale]s to form a path.
[codeblocks]
[gdscript]
var astar = AStar3D.new()
astar.add_point(1, Vector3(1, 0, 0), 4) # Adds the point (1, 0, 0) with weight_scale 4 and id 1
[/gdscript]
[csharp]
var astar = new AStar3D();
astar.AddPoint(1, new Vector3(1, 0, 0), 4); // Adds the point (1, 0, 0) with weight_scale 4 and id 1
[/csharp]
[/codeblocks]
If there already exists a point for the given [param id], its position and weight scale are updated to the given values.

### id :: int

### position :: Vector3

### weight_scale :: float

## are_points_connected :: func AStar3D.are_points_connected(id: int, to_id: int, bidirectional: bool = true) -> bool
Returns whether the two given points are directly connected by a segment. If [param bidirectional] is [code]false[/code], returns whether movement from [param id] to [param to_id] is possible through this segment.

### id :: int

### to_id :: int

### bidirectional :: bool

## clear :: func AStar3D.clear() -> void
Clears all the points and segments.

## connect_points :: func AStar3D.connect_points(id: int, to_id: int, bidirectional: bool = true) -> void
Creates a segment between the given points. If [param bidirectional] is [code]false[/code], only movement from [param id] to [param to_id] is allowed, not the reverse direction.
[codeblocks]
[gdscript]
var astar = AStar3D.new()
astar.add_point(1, Vector3(1, 1, 0))
astar.add_point(2, Vector3(0, 5, 0))
astar.connect_points(1, 2, false)
[/gdscript]
[csharp]
var astar = new AStar3D();
astar.AddPoint(1, new Vector3(1, 1, 0));
astar.AddPoint(2, new Vector3(0, 5, 0));
astar.ConnectPoints(1, 2, false);
[/csharp]
[/codeblocks]

### id :: int

### to_id :: int

### bidirectional :: bool

## disconnect_points :: func AStar3D.disconnect_points(id: int, to_id: int, bidirectional: bool = true) -> void
Deletes the segment between the given points. If [param bidirectional] is [code]false[/code], only movement from [param id] to [param to_id] is prevented, and a unidirectional segment possibly remains.

### id :: int

### to_id :: int

### bidirectional :: bool

## get_available_point_id :: func AStar3D.get_available_point_id() -> int
Returns the next available point ID with no point associated to it.

## get_closest_point :: func AStar3D.get_closest_point(to_position: Vector3, include_disabled: bool = false) -> int
Returns the ID of the closest point to [param to_position], optionally taking disabled points into account. Returns [code]-1[/code] if there are no points in the points pool.
[b]Note:[/b] If several points are the closest to [param to_position], the one with the smallest ID will be returned, ensuring a deterministic result.

### to_position :: Vector3

### include_disabled :: bool

## get_closest_position_in_segment :: func AStar3D.get_closest_position_in_segment(to_position: Vector3) -> Vector3
Returns the closest position to [param to_position] that resides inside a segment between two connected points.
[codeblocks]
[gdscript]
var astar = AStar3D.new()
astar.add_point(1, Vector3(0, 0, 0))
astar.add_point(2, Vector3(0, 5, 0))
astar.connect_points(1, 2)
var res = astar.get_closest_position_in_segment(Vector3(3, 3, 0)) # Returns (0, 3, 0)
[/gdscript]
[csharp]
var astar = new AStar3D();
astar.AddPoint(1, new Vector3(0, 0, 0));
astar.AddPoint(2, new Vector3(0, 5, 0));
astar.ConnectPoints(1, 2);
Vector3 res = astar.GetClosestPositionInSegment(new Vector3(3, 3, 0)); // Returns (0, 3, 0)
[/csharp]
[/codeblocks]
The result is in the segment that goes from [code]y = 0[/code] to [code]y = 5[/code]. It's the closest position in the segment to the given point.

### to_position :: Vector3

## get_id_path :: func AStar3D.get_id_path(from_id: int, to_id: int, allow_partial_path: bool = false) -> PackedInt64Array
Returns an array with the IDs of the points that form the path found by AStar3D between the given points. The array is ordered from the starting point to the ending point of the path.
If [param from_id] point is disabled, returns an empty array (even if [code]from_id == to_id[/code]).
If [param from_id] point is not disabled, there is no valid path to the target, and [param allow_partial_path] is [code]true[/code], returns a path to the point closest to the target that can be reached.
[b]Note:[/b] When [param allow_partial_path] is [code]true[/code] and [param to_id] is disabled the search may take an unusually long time to finish.
[codeblocks]
[gdscript]
var astar = AStar3D.new()
astar.add_point(1, Vector3(0, 0, 0))
astar.add_point(2, Vector3(0, 1, 0), 1) # Default weight is 1
astar.add_point(3, Vector3(1, 1, 0))
astar.add_point(4, Vector3(2, 0, 0))

astar.connect_points(1, 2, false)
astar.connect_points(2, 3, false)
astar.connect_points(4, 3, false)
astar.connect_points(1, 4, false)

var res = astar.get_id_path(1, 3) # Returns [1, 2, 3]
[/gdscript]
[csharp]
var astar = new AStar3D();
astar.AddPoint(1, new Vector3(0, 0, 0));
astar.AddPoint(2, new Vector3(0, 1, 0), 1); // Default weight is 1
astar.AddPoint(3, new Vector3(1, 1, 0));
astar.AddPoint(4, new Vector3(2, 0, 0));
astar.ConnectPoints(1, 2, false);
astar.ConnectPoints(2, 3, false);
astar.ConnectPoints(4, 3, false);
astar.ConnectPoints(1, 4, false);
long[] res = astar.GetIdPath(1, 3); // Returns [1, 2, 3]
[/csharp]
[/codeblocks]
If you change the 2nd point's weight to 3, then the result will be [code][1, 4, 3][/code] instead, because now even though the distance is longer, it's "easier" to get through point 4 than through point 2.

### from_id :: int

### to_id :: int

### allow_partial_path :: bool

## get_point_capacity :: func AStar3D.get_point_capacity() -> int
Returns the capacity of the structure backing the points, useful in conjunction with [method reserve_space].

## get_point_connections :: func AStar3D.get_point_connections(id: int) -> PackedInt64Array
Returns an array with the IDs of the points that form the connection with the given point.
[codeblocks]
[gdscript]
var astar = AStar3D.new()
astar.add_point(1, Vector3(0, 0, 0))
astar.add_point(2, Vector3(0, 1, 0))
astar.add_point(3, Vector3(1, 1, 0))
astar.add_point(4, Vector3(2, 0, 0))

astar.connect_points(1, 2, true)
astar.connect_points(1, 3, true)

var neighbors = astar.get_point_connections(1) # Returns [2, 3]
[/gdscript]
[csharp]
var astar = new AStar3D();
astar.AddPoint(1, new Vector3(0, 0, 0));
astar.AddPoint(2, new Vector3(0, 1, 0));
astar.AddPoint(3, new Vector3(1, 1, 0));
astar.AddPoint(4, new Vector3(2, 0, 0));
astar.ConnectPoints(1, 2, true);
astar.ConnectPoints(1, 3, true);

long[] neighbors = astar.GetPointConnections(1); // Returns [2, 3]
[/csharp]
[/codeblocks]

### id :: int

## get_point_count :: func AStar3D.get_point_count() -> int
Returns the number of points currently in the points pool.

## get_point_ids :: func AStar3D.get_point_ids() -> PackedInt64Array
Returns an array of all point IDs.

## get_point_path :: func AStar3D.get_point_path(from_id: int, to_id: int, allow_partial_path: bool = false) -> PackedVector3Array
Returns an array with the points that are in the path found by AStar3D between the given points. The array is ordered from the starting point to the ending point of the path.
If [param from_id] point is disabled, returns an empty array (even if [code]from_id == to_id[/code]).
If [param from_id] point is not disabled, there is no valid path to the target, and [param allow_partial_path] is [code]true[/code], returns a path to the point closest to the target that can be reached.
[b]Note:[/b] This method is not thread-safe; it can only be used from a single [Thread] at a given time. Consider using [Mutex] to ensure exclusive access to one thread to avoid race conditions.
Additionally, when [param allow_partial_path] is [code]true[/code] and [param to_id] is disabled the search may take an unusually long time to finish.

### from_id :: int

### to_id :: int

### allow_partial_path :: bool

## get_point_position :: func AStar3D.get_point_position(id: int) -> Vector3
Returns the position of the point associated with the given [param id].

### id :: int

## get_point_weight_scale :: func AStar3D.get_point_weight_scale(id: int) -> float
Returns the weight scale of the point associated with the given [param id].

### id :: int

## has_point :: func AStar3D.has_point(id: int) -> bool
Returns whether a point associated with the given [param id] exists.

### id :: int

## is_point_disabled :: func AStar3D.is_point_disabled(id: int) -> bool
Returns whether a point is disabled or not for pathfinding. By default, all points are enabled.

### id :: int

## remove_point :: func AStar3D.remove_point(id: int) -> void
Removes the point associated with the given [param id] from the points pool.

### id :: int

## reserve_space :: func AStar3D.reserve_space(num_nodes: int) -> void
Reserves space internally for [param num_nodes] points. Useful if you're adding a known large number of points at once, such as points on a grid.

### num_nodes :: int

## set_point_disabled :: func AStar3D.set_point_disabled(id: int, disabled: bool = true) -> void
Disables or enables the specified point for pathfinding. Useful for making a temporary obstacle.

### id :: int

### disabled :: bool

## set_point_position :: func AStar3D.set_point_position(id: int, position: Vector3) -> void
Sets the [param position] for the point with the given [param id].

### id :: int

### position :: Vector3

## set_point_weight_scale :: func AStar3D.set_point_weight_scale(id: int, weight_scale: float) -> void
Sets the [param weight_scale] for the point with the given [param id]. The [param weight_scale] is multiplied by the result of [method _compute_cost] when determining the overall cost of traveling across a segment from a neighboring point to this point.

### id :: int

### weight_scale :: float
