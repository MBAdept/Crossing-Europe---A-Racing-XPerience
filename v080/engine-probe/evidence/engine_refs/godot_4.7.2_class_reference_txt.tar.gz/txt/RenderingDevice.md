# RenderingDevice :: <Native> class RenderingDevice extends Object
Abstraction for working with modern low-level graphics APIs.
[RenderingDevice] is an abstraction for working with modern low-level graphics APIs such as Vulkan. Compared to [RenderingServer] (which works with Godot's own rendering subsystems), [RenderingDevice] is much lower-level and allows working more directly with the underlying graphics APIs. [RenderingDevice] is used in Godot to provide support for several modern low-level graphics APIs while reducing the amount of code duplication required. [RenderingDevice] can also be used in your own projects to perform things that are not exposed by [RenderingServer] or high-level nodes, such as using compute shaders.
On startup, Godot creates a global [RenderingDevice] which can be retrieved using [method RenderingServer.get_rendering_device]. This global [RenderingDevice] performs drawing to the screen.
[b]Local RenderingDevices:[/b] Using [method RenderingServer.create_local_rendering_device], you can create "secondary" rendering devices to perform drawing and GPU compute operations on separate threads.
[b]Note:[/b] [RenderingDevice] assumes intermediate knowledge of modern graphics APIs such as Vulkan, Direct3D 12, Metal or WebGPU. These graphics APIs are lower-level than OpenGL or Direct3D 11, requiring you to perform what was previously done by the graphics driver itself. If you have difficulty understanding the concepts used in this class, follow the [url=https://vulkan-tutorial.com/]Vulkan Tutorial[/url] or [url=https://vkguide.dev/]Vulkan Guide[/url]. It's recommended to have existing modern OpenGL or Direct3D 11 knowledge before attempting to learn a low-level graphics API.
[b]Note:[/b] [RenderingDevice] is not available when running in headless mode or when using the Compatibility rendering method.

## DEVICE_TYPE_OTHER :: const RenderingDevice.DEVICE_TYPE_OTHER: DeviceType = 0
Rendering device type does not match any of the other enum values or is unknown.

## DEVICE_TYPE_INTEGRATED_GPU :: const RenderingDevice.DEVICE_TYPE_INTEGRATED_GPU: DeviceType = 1
Rendering device is an integrated GPU, which is typically [i](but not always)[/i] slower than dedicated GPUs ([constant DEVICE_TYPE_DISCRETE_GPU]). On Android and iOS, the rendering device type is always considered to be [constant DEVICE_TYPE_INTEGRATED_GPU].

## DEVICE_TYPE_DISCRETE_GPU :: const RenderingDevice.DEVICE_TYPE_DISCRETE_GPU: DeviceType = 2
Rendering device is a dedicated GPU, which is typically [i](but not always)[/i] faster than integrated GPUs ([constant DEVICE_TYPE_INTEGRATED_GPU]).

## DEVICE_TYPE_VIRTUAL_GPU :: const RenderingDevice.DEVICE_TYPE_VIRTUAL_GPU: DeviceType = 3
Rendering device is an emulated GPU in a virtual environment. This is typically much slower than the host GPU, which means the expected performance level on a dedicated GPU will be roughly equivalent to [constant DEVICE_TYPE_INTEGRATED_GPU]. Virtual machine GPU passthrough (such as VFIO) will not report the device type as [constant DEVICE_TYPE_VIRTUAL_GPU]. Instead, the host GPU's device type will be reported as if the GPU was not emulated.

## DEVICE_TYPE_CPU :: const RenderingDevice.DEVICE_TYPE_CPU: DeviceType = 4
Rendering device is provided by software emulation (such as Lavapipe or [url=https://github.com/google/swiftshader]SwiftShader[/url]). This is the slowest kind of rendering device available; it's typically much slower than [constant DEVICE_TYPE_INTEGRATED_GPU].

## DEVICE_TYPE_MAX :: const RenderingDevice.DEVICE_TYPE_MAX: DeviceType = 5
Represents the size of the [enum DeviceType] enum.

## DRIVER_RESOURCE_LOGICAL_DEVICE :: const RenderingDevice.DRIVER_RESOURCE_LOGICAL_DEVICE: DriverResource = 0
Specific device object based on a physical device ([code]rid[/code] parameter is ignored).
- Vulkan: Vulkan device driver resource ([code]VkDevice[/code]).
- D3D12: D3D12 device driver resource ([code]ID3D12Device[/code]).
- Metal: Metal device driver resource ([code]MTLDevice[/code]).

## DRIVER_RESOURCE_PHYSICAL_DEVICE :: const RenderingDevice.DRIVER_RESOURCE_PHYSICAL_DEVICE: DriverResource = 1
Physical device the specific logical device is based on ([code]rid[/code] parameter is ignored).
- Vulkan: [code]VkPhysicalDevice[/code].
- D3D12: [code]IDXGIAdapter[/code].

## DRIVER_RESOURCE_TOPMOST_OBJECT :: const RenderingDevice.DRIVER_RESOURCE_TOPMOST_OBJECT: DriverResource = 2
Top-most graphics API entry object ([code]rid[/code] parameter is ignored).
- Vulkan: [code]VkInstance[/code].

## DRIVER_RESOURCE_COMMAND_QUEUE :: const RenderingDevice.DRIVER_RESOURCE_COMMAND_QUEUE: DriverResource = 3
The main graphics-compute command queue ([code]rid[/code] parameter is ignored).
- Vulkan: [code]VkQueue[/code].
- D3D12: [code]ID3D12CommandQueue[/code].
- Metal: [code]MTLCommandQueue[/code].

## DRIVER_RESOURCE_QUEUE_FAMILY :: const RenderingDevice.DRIVER_RESOURCE_QUEUE_FAMILY: DriverResource = 4
The specific family the main queue belongs to ([code]rid[/code] parameter is ignored).
- Vulkan: The queue family index, a [code]uint32_t[/code].

## DRIVER_RESOURCE_TEXTURE :: const RenderingDevice.DRIVER_RESOURCE_TEXTURE: DriverResource = 5
- Vulkan: [code]VkImage[/code].
- D3D12: [code]ID3D12Resource[/code].

## DRIVER_RESOURCE_TEXTURE_VIEW :: const RenderingDevice.DRIVER_RESOURCE_TEXTURE_VIEW: DriverResource = 6
The view of an owned or shared texture.
- Vulkan: [code]VkImageView[/code].
- D3D12: [code]ID3D12Resource[/code].

## DRIVER_RESOURCE_TEXTURE_DATA_FORMAT :: const RenderingDevice.DRIVER_RESOURCE_TEXTURE_DATA_FORMAT: DriverResource = 7
The native id of the data format of the texture.
- Vulkan: [code]VkFormat[/code].
- D3D12: [code]DXGI_FORMAT[/code].

## DRIVER_RESOURCE_SAMPLER :: const RenderingDevice.DRIVER_RESOURCE_SAMPLER: DriverResource = 8
- Vulkan: [code]VkSampler[/code].

## DRIVER_RESOURCE_UNIFORM_SET :: const RenderingDevice.DRIVER_RESOURCE_UNIFORM_SET: DriverResource = 9
- Vulkan: [code]VkDescriptorSet[/code].

## DRIVER_RESOURCE_BUFFER :: const RenderingDevice.DRIVER_RESOURCE_BUFFER: DriverResource = 10
Buffer of any kind of (storage, vertex, etc.).
- Vulkan: [code]VkBuffer[/code].
- D3D12: [code]ID3D12Resource[/code].

## DRIVER_RESOURCE_COMPUTE_PIPELINE :: const RenderingDevice.DRIVER_RESOURCE_COMPUTE_PIPELINE: DriverResource = 11
- Vulkan: [code]VkPipeline[/code].
- Metal: [code]MTLComputePipelineState[/code].

## DRIVER_RESOURCE_RENDER_PIPELINE :: const RenderingDevice.DRIVER_RESOURCE_RENDER_PIPELINE: DriverResource = 12
- Vulkan: [code]VkPipeline[/code].
- Metal: [code]MTLRenderPipelineState[/code].

## DRIVER_RESOURCE_VULKAN_DEVICE :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_DEVICE: DriverResource = 0

## DRIVER_RESOURCE_VULKAN_PHYSICAL_DEVICE :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_PHYSICAL_DEVICE: DriverResource = 1

## DRIVER_RESOURCE_VULKAN_INSTANCE :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_INSTANCE: DriverResource = 2

## DRIVER_RESOURCE_VULKAN_QUEUE :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_QUEUE: DriverResource = 3

## DRIVER_RESOURCE_VULKAN_QUEUE_FAMILY_INDEX :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_QUEUE_FAMILY_INDEX: DriverResource = 4

## DRIVER_RESOURCE_VULKAN_IMAGE :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_IMAGE: DriverResource = 5

## DRIVER_RESOURCE_VULKAN_IMAGE_VIEW :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_IMAGE_VIEW: DriverResource = 6

## DRIVER_RESOURCE_VULKAN_IMAGE_NATIVE_TEXTURE_FORMAT :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_IMAGE_NATIVE_TEXTURE_FORMAT: DriverResource = 7

## DRIVER_RESOURCE_VULKAN_SAMPLER :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_SAMPLER: DriverResource = 8

## DRIVER_RESOURCE_VULKAN_DESCRIPTOR_SET :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_DESCRIPTOR_SET: DriverResource = 9

## DRIVER_RESOURCE_VULKAN_BUFFER :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_BUFFER: DriverResource = 10

## DRIVER_RESOURCE_VULKAN_COMPUTE_PIPELINE :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_COMPUTE_PIPELINE: DriverResource = 11

## DRIVER_RESOURCE_VULKAN_RENDER_PIPELINE :: const RenderingDevice.DRIVER_RESOURCE_VULKAN_RENDER_PIPELINE: DriverResource = 12

## DATA_FORMAT_R4G4_UNORM_PACK8 :: const RenderingDevice.DATA_FORMAT_R4G4_UNORM_PACK8: DataFormat = 0
4-bit-per-channel red/green channel data format, packed into 8 bits. Values are in the [code][0.0, 1.0][/code] range.
[b]Note:[/b] More information on all data formats can be found on the [url=https://registry.khronos.org/vulkan/specs/1.1/html/vkspec.html#_identification_of_formats]Identification of formats[/url] section of the Vulkan specification, as well as the [url=https://registry.khronos.org/vulkan/specs/1.3-extensions/man/html/VkFormat.html]VkFormat[/url] enum.

## DATA_FORMAT_R4G4B4A4_UNORM_PACK16 :: const RenderingDevice.DATA_FORMAT_R4G4B4A4_UNORM_PACK16: DataFormat = 1
4-bit-per-channel red/green/blue/alpha channel data format, packed into 16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_B4G4R4A4_UNORM_PACK16 :: const RenderingDevice.DATA_FORMAT_B4G4R4A4_UNORM_PACK16: DataFormat = 2
4-bit-per-channel blue/green/red/alpha channel data format, packed into 16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R5G6B5_UNORM_PACK16 :: const RenderingDevice.DATA_FORMAT_R5G6B5_UNORM_PACK16: DataFormat = 3
Red/green/blue channel data format with 5 bits of red, 6 bits of green and 5 bits of blue, packed into 16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_B5G6R5_UNORM_PACK16 :: const RenderingDevice.DATA_FORMAT_B5G6R5_UNORM_PACK16: DataFormat = 4
Blue/green/red channel data format with 5 bits of blue, 6 bits of green and 5 bits of red, packed into 16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R5G5B5A1_UNORM_PACK16 :: const RenderingDevice.DATA_FORMAT_R5G5B5A1_UNORM_PACK16: DataFormat = 5
Red/green/blue/alpha channel data format with 5 bits of red, 6 bits of green, 5 bits of blue and 1 bit of alpha, packed into 16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_B5G5R5A1_UNORM_PACK16 :: const RenderingDevice.DATA_FORMAT_B5G5R5A1_UNORM_PACK16: DataFormat = 6
Blue/green/red/alpha channel data format with 5 bits of blue, 6 bits of green, 5 bits of red and 1 bit of alpha, packed into 16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_A1R5G5B5_UNORM_PACK16 :: const RenderingDevice.DATA_FORMAT_A1R5G5B5_UNORM_PACK16: DataFormat = 7
Alpha/red/green/blue channel data format with 1 bit of alpha, 5 bits of red, 6 bits of green and 5 bits of blue, packed into 16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R8_UNORM :: const RenderingDevice.DATA_FORMAT_R8_UNORM: DataFormat = 8
8-bit-per-channel unsigned floating-point red channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R8_SNORM :: const RenderingDevice.DATA_FORMAT_R8_SNORM: DataFormat = 9
8-bit-per-channel signed floating-point red channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_R8_USCALED :: const RenderingDevice.DATA_FORMAT_R8_USCALED: DataFormat = 10
8-bit-per-channel unsigned floating-point red channel data format with scaled value (value is converted from integer to float). Values are in the [code][0.0, 255.0][/code] range.

## DATA_FORMAT_R8_SSCALED :: const RenderingDevice.DATA_FORMAT_R8_SSCALED: DataFormat = 11
8-bit-per-channel signed floating-point red channel data format with scaled value (value is converted from integer to float). Values are in the [code][-127.0, 127.0][/code] range.

## DATA_FORMAT_R8_UINT :: const RenderingDevice.DATA_FORMAT_R8_UINT: DataFormat = 12
8-bit-per-channel unsigned integer red channel data format. Values are in the [code][0, 255][/code] range.

## DATA_FORMAT_R8_SINT :: const RenderingDevice.DATA_FORMAT_R8_SINT: DataFormat = 13
8-bit-per-channel signed integer red channel data format. Values are in the [code][-127, 127][/code] range.

## DATA_FORMAT_R8_SRGB :: const RenderingDevice.DATA_FORMAT_R8_SRGB: DataFormat = 14
8-bit-per-channel unsigned floating-point red channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R8G8_UNORM :: const RenderingDevice.DATA_FORMAT_R8G8_UNORM: DataFormat = 15
8-bit-per-channel unsigned floating-point red/green channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R8G8_SNORM :: const RenderingDevice.DATA_FORMAT_R8G8_SNORM: DataFormat = 16
8-bit-per-channel signed floating-point red/green channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_R8G8_USCALED :: const RenderingDevice.DATA_FORMAT_R8G8_USCALED: DataFormat = 17
8-bit-per-channel unsigned floating-point red/green channel data format with scaled value (value is converted from integer to float). Values are in the [code][0.0, 255.0][/code] range.

## DATA_FORMAT_R8G8_SSCALED :: const RenderingDevice.DATA_FORMAT_R8G8_SSCALED: DataFormat = 18
8-bit-per-channel signed floating-point red/green channel data format with scaled value (value is converted from integer to float). Values are in the [code][-127.0, 127.0][/code] range.

## DATA_FORMAT_R8G8_UINT :: const RenderingDevice.DATA_FORMAT_R8G8_UINT: DataFormat = 19
8-bit-per-channel unsigned integer red/green channel data format. Values are in the [code][0, 255][/code] range.

## DATA_FORMAT_R8G8_SINT :: const RenderingDevice.DATA_FORMAT_R8G8_SINT: DataFormat = 20
8-bit-per-channel signed integer red/green channel data format. Values are in the [code][-127, 127][/code] range.

## DATA_FORMAT_R8G8_SRGB :: const RenderingDevice.DATA_FORMAT_R8G8_SRGB: DataFormat = 21
8-bit-per-channel unsigned floating-point red/green channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R8G8B8_UNORM :: const RenderingDevice.DATA_FORMAT_R8G8B8_UNORM: DataFormat = 22
8-bit-per-channel unsigned floating-point red/green/blue channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R8G8B8_SNORM :: const RenderingDevice.DATA_FORMAT_R8G8B8_SNORM: DataFormat = 23
8-bit-per-channel signed floating-point red/green/blue channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_R8G8B8_USCALED :: const RenderingDevice.DATA_FORMAT_R8G8B8_USCALED: DataFormat = 24
8-bit-per-channel unsigned floating-point red/green/blue channel data format with scaled value (value is converted from integer to float). Values are in the [code][0.0, 255.0][/code] range.

## DATA_FORMAT_R8G8B8_SSCALED :: const RenderingDevice.DATA_FORMAT_R8G8B8_SSCALED: DataFormat = 25
8-bit-per-channel signed floating-point red/green/blue channel data format with scaled value (value is converted from integer to float). Values are in the [code][-127.0, 127.0][/code] range.

## DATA_FORMAT_R8G8B8_UINT :: const RenderingDevice.DATA_FORMAT_R8G8B8_UINT: DataFormat = 26
8-bit-per-channel unsigned integer red/green/blue channel data format. Values are in the [code][0, 255][/code] range.

## DATA_FORMAT_R8G8B8_SINT :: const RenderingDevice.DATA_FORMAT_R8G8B8_SINT: DataFormat = 27
8-bit-per-channel signed integer red/green/blue channel data format. Values are in the [code][-127, 127][/code] range.

## DATA_FORMAT_R8G8B8_SRGB :: const RenderingDevice.DATA_FORMAT_R8G8B8_SRGB: DataFormat = 28
8-bit-per-channel unsigned floating-point red/green/blue channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_B8G8R8_UNORM :: const RenderingDevice.DATA_FORMAT_B8G8R8_UNORM: DataFormat = 29
8-bit-per-channel unsigned floating-point blue/green/red channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_B8G8R8_SNORM :: const RenderingDevice.DATA_FORMAT_B8G8R8_SNORM: DataFormat = 30
8-bit-per-channel signed floating-point blue/green/red channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_B8G8R8_USCALED :: const RenderingDevice.DATA_FORMAT_B8G8R8_USCALED: DataFormat = 31
8-bit-per-channel unsigned floating-point blue/green/red channel data format with scaled value (value is converted from integer to float). Values are in the [code][0.0, 255.0][/code] range.

## DATA_FORMAT_B8G8R8_SSCALED :: const RenderingDevice.DATA_FORMAT_B8G8R8_SSCALED: DataFormat = 32
8-bit-per-channel signed floating-point blue/green/red channel data format with scaled value (value is converted from integer to float). Values are in the [code][-127.0, 127.0][/code] range.

## DATA_FORMAT_B8G8R8_UINT :: const RenderingDevice.DATA_FORMAT_B8G8R8_UINT: DataFormat = 33
8-bit-per-channel unsigned integer blue/green/red channel data format. Values are in the [code][0, 255][/code] range.

## DATA_FORMAT_B8G8R8_SINT :: const RenderingDevice.DATA_FORMAT_B8G8R8_SINT: DataFormat = 34
8-bit-per-channel signed integer blue/green/red channel data format. Values are in the [code][-127, 127][/code] range.

## DATA_FORMAT_B8G8R8_SRGB :: const RenderingDevice.DATA_FORMAT_B8G8R8_SRGB: DataFormat = 35
8-bit-per-channel unsigned floating-point blue/green/red data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R8G8B8A8_UNORM :: const RenderingDevice.DATA_FORMAT_R8G8B8A8_UNORM: DataFormat = 36
8-bit-per-channel unsigned floating-point red/green/blue/alpha channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R8G8B8A8_SNORM :: const RenderingDevice.DATA_FORMAT_R8G8B8A8_SNORM: DataFormat = 37
8-bit-per-channel signed floating-point red/green/blue/alpha channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_R8G8B8A8_USCALED :: const RenderingDevice.DATA_FORMAT_R8G8B8A8_USCALED: DataFormat = 38
8-bit-per-channel unsigned floating-point red/green/blue/alpha channel data format with scaled value (value is converted from integer to float). Values are in the [code][0.0, 255.0][/code] range.

## DATA_FORMAT_R8G8B8A8_SSCALED :: const RenderingDevice.DATA_FORMAT_R8G8B8A8_SSCALED: DataFormat = 39
8-bit-per-channel signed floating-point red/green/blue/alpha channel data format with scaled value (value is converted from integer to float). Values are in the [code][-127.0, 127.0][/code] range.

## DATA_FORMAT_R8G8B8A8_UINT :: const RenderingDevice.DATA_FORMAT_R8G8B8A8_UINT: DataFormat = 40
8-bit-per-channel unsigned integer red/green/blue/alpha channel data format. Values are in the [code][0, 255][/code] range.

## DATA_FORMAT_R8G8B8A8_SINT :: const RenderingDevice.DATA_FORMAT_R8G8B8A8_SINT: DataFormat = 41
8-bit-per-channel signed integer red/green/blue/alpha channel data format. Values are in the [code][-127, 127][/code] range.

## DATA_FORMAT_R8G8B8A8_SRGB :: const RenderingDevice.DATA_FORMAT_R8G8B8A8_SRGB: DataFormat = 42
8-bit-per-channel unsigned floating-point red/green/blue/alpha channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_B8G8R8A8_UNORM :: const RenderingDevice.DATA_FORMAT_B8G8R8A8_UNORM: DataFormat = 43
8-bit-per-channel unsigned floating-point blue/green/red/alpha channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_B8G8R8A8_SNORM :: const RenderingDevice.DATA_FORMAT_B8G8R8A8_SNORM: DataFormat = 44
8-bit-per-channel signed floating-point blue/green/red/alpha channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_B8G8R8A8_USCALED :: const RenderingDevice.DATA_FORMAT_B8G8R8A8_USCALED: DataFormat = 45
8-bit-per-channel unsigned floating-point blue/green/red/alpha channel data format with scaled value (value is converted from integer to float). Values are in the [code][0.0, 255.0][/code] range.

## DATA_FORMAT_B8G8R8A8_SSCALED :: const RenderingDevice.DATA_FORMAT_B8G8R8A8_SSCALED: DataFormat = 46
8-bit-per-channel signed floating-point blue/green/red/alpha channel data format with scaled value (value is converted from integer to float). Values are in the [code][-127.0, 127.0][/code] range.

## DATA_FORMAT_B8G8R8A8_UINT :: const RenderingDevice.DATA_FORMAT_B8G8R8A8_UINT: DataFormat = 47
8-bit-per-channel unsigned integer blue/green/red/alpha channel data format. Values are in the [code][0, 255][/code] range.

## DATA_FORMAT_B8G8R8A8_SINT :: const RenderingDevice.DATA_FORMAT_B8G8R8A8_SINT: DataFormat = 48
8-bit-per-channel signed integer blue/green/red/alpha channel data format. Values are in the [code][-127, 127][/code] range.

## DATA_FORMAT_B8G8R8A8_SRGB :: const RenderingDevice.DATA_FORMAT_B8G8R8A8_SRGB: DataFormat = 49
8-bit-per-channel unsigned floating-point blue/green/red/alpha channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_A8B8G8R8_UNORM_PACK32 :: const RenderingDevice.DATA_FORMAT_A8B8G8R8_UNORM_PACK32: DataFormat = 50
8-bit-per-channel unsigned floating-point alpha/red/green/blue channel data format with normalized value, packed in 32 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_A8B8G8R8_SNORM_PACK32 :: const RenderingDevice.DATA_FORMAT_A8B8G8R8_SNORM_PACK32: DataFormat = 51
8-bit-per-channel signed floating-point alpha/red/green/blue channel data format with normalized value, packed in 32 bits. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_A8B8G8R8_USCALED_PACK32 :: const RenderingDevice.DATA_FORMAT_A8B8G8R8_USCALED_PACK32: DataFormat = 52
8-bit-per-channel unsigned floating-point alpha/red/green/blue channel data format with scaled value (value is converted from integer to float), packed in 32 bits. Values are in the [code][0.0, 255.0][/code] range.

## DATA_FORMAT_A8B8G8R8_SSCALED_PACK32 :: const RenderingDevice.DATA_FORMAT_A8B8G8R8_SSCALED_PACK32: DataFormat = 53
8-bit-per-channel signed floating-point alpha/red/green/blue channel data format with scaled value (value is converted from integer to float), packed in 32 bits. Values are in the [code][-127.0, 127.0][/code] range.

## DATA_FORMAT_A8B8G8R8_UINT_PACK32 :: const RenderingDevice.DATA_FORMAT_A8B8G8R8_UINT_PACK32: DataFormat = 54
8-bit-per-channel unsigned integer alpha/red/green/blue channel data format, packed in 32 bits. Values are in the [code][0, 255][/code] range.

## DATA_FORMAT_A8B8G8R8_SINT_PACK32 :: const RenderingDevice.DATA_FORMAT_A8B8G8R8_SINT_PACK32: DataFormat = 55
8-bit-per-channel signed integer alpha/red/green/blue channel data format, packed in 32 bits. Values are in the [code][-127, 127][/code] range.

## DATA_FORMAT_A8B8G8R8_SRGB_PACK32 :: const RenderingDevice.DATA_FORMAT_A8B8G8R8_SRGB_PACK32: DataFormat = 56
8-bit-per-channel unsigned floating-point alpha/red/green/blue channel data format with normalized value and nonlinear sRGB encoding, packed in 32 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_A2R10G10B10_UNORM_PACK32 :: const RenderingDevice.DATA_FORMAT_A2R10G10B10_UNORM_PACK32: DataFormat = 57
Unsigned floating-point alpha/red/green/blue channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of red, 10 bits of green and 10 bits of blue. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_A2R10G10B10_SNORM_PACK32 :: const RenderingDevice.DATA_FORMAT_A2R10G10B10_SNORM_PACK32: DataFormat = 58
Signed floating-point alpha/red/green/blue channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of red, 10 bits of green and 10 bits of blue. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_A2R10G10B10_USCALED_PACK32 :: const RenderingDevice.DATA_FORMAT_A2R10G10B10_USCALED_PACK32: DataFormat = 59
Unsigned floating-point alpha/red/green/blue channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of red, 10 bits of green and 10 bits of blue. Values are in the [code][0.0, 1023.0][/code] range for red/green/blue and [code][0.0, 3.0][/code] for alpha.

## DATA_FORMAT_A2R10G10B10_SSCALED_PACK32 :: const RenderingDevice.DATA_FORMAT_A2R10G10B10_SSCALED_PACK32: DataFormat = 60
Signed floating-point alpha/red/green/blue channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of red, 10 bits of green and 10 bits of blue. Values are in the [code][-511.0, 511.0][/code] range for red/green/blue and [code][-1.0, 1.0][/code] for alpha.

## DATA_FORMAT_A2R10G10B10_UINT_PACK32 :: const RenderingDevice.DATA_FORMAT_A2R10G10B10_UINT_PACK32: DataFormat = 61
Unsigned integer alpha/red/green/blue channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of red, 10 bits of green and 10 bits of blue. Values are in the [code][0, 1023][/code] range for red/green/blue and [code][0, 3][/code] for alpha.

## DATA_FORMAT_A2R10G10B10_SINT_PACK32 :: const RenderingDevice.DATA_FORMAT_A2R10G10B10_SINT_PACK32: DataFormat = 62
Signed integer alpha/red/green/blue channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of red, 10 bits of green and 10 bits of blue. Values are in the [code][-511, 511][/code] range for red/green/blue and [code][-1, 1][/code] for alpha.

## DATA_FORMAT_A2B10G10R10_UNORM_PACK32 :: const RenderingDevice.DATA_FORMAT_A2B10G10R10_UNORM_PACK32: DataFormat = 63
Unsigned floating-point alpha/blue/green/red channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of blue, 10 bits of green and 10 bits of red. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_A2B10G10R10_SNORM_PACK32 :: const RenderingDevice.DATA_FORMAT_A2B10G10R10_SNORM_PACK32: DataFormat = 64
Signed floating-point alpha/blue/green/red channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of blue, 10 bits of green and 10 bits of red. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_A2B10G10R10_USCALED_PACK32 :: const RenderingDevice.DATA_FORMAT_A2B10G10R10_USCALED_PACK32: DataFormat = 65
Unsigned floating-point alpha/blue/green/red channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of blue, 10 bits of green and 10 bits of red. Values are in the [code][0.0, 1023.0][/code] range for blue/green/red and [code][0.0, 3.0][/code] for alpha.

## DATA_FORMAT_A2B10G10R10_SSCALED_PACK32 :: const RenderingDevice.DATA_FORMAT_A2B10G10R10_SSCALED_PACK32: DataFormat = 66
Signed floating-point alpha/blue/green/red channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of blue, 10 bits of green and 10 bits of red. Values are in the [code][-511.0, 511.0][/code] range for blue/green/red and [code][-1.0, 1.0][/code] for alpha.

## DATA_FORMAT_A2B10G10R10_UINT_PACK32 :: const RenderingDevice.DATA_FORMAT_A2B10G10R10_UINT_PACK32: DataFormat = 67
Unsigned integer alpha/blue/green/red channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of blue, 10 bits of green and 10 bits of red. Values are in the [code][0, 1023][/code] range for blue/green/red and [code][0, 3][/code] for alpha.

## DATA_FORMAT_A2B10G10R10_SINT_PACK32 :: const RenderingDevice.DATA_FORMAT_A2B10G10R10_SINT_PACK32: DataFormat = 68
Signed integer alpha/blue/green/red channel data format with normalized value, packed in 32 bits. Format contains 2 bits of alpha, 10 bits of blue, 10 bits of green and 10 bits of red. Values are in the [code][-511, 511][/code] range for blue/green/red and [code][-1, 1][/code] for alpha.

## DATA_FORMAT_R16_UNORM :: const RenderingDevice.DATA_FORMAT_R16_UNORM: DataFormat = 69
16-bit-per-channel unsigned floating-point red channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R16_SNORM :: const RenderingDevice.DATA_FORMAT_R16_SNORM: DataFormat = 70
16-bit-per-channel signed floating-point red channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_R16_USCALED :: const RenderingDevice.DATA_FORMAT_R16_USCALED: DataFormat = 71
16-bit-per-channel unsigned floating-point red channel data format with scaled value (value is converted from integer to float). Values are in the [code][0.0, 65535.0][/code] range.

## DATA_FORMAT_R16_SSCALED :: const RenderingDevice.DATA_FORMAT_R16_SSCALED: DataFormat = 72
16-bit-per-channel signed floating-point red channel data format with scaled value (value is converted from integer to float). Values are in the [code][-32767.0, 32767.0][/code] range.

## DATA_FORMAT_R16_UINT :: const RenderingDevice.DATA_FORMAT_R16_UINT: DataFormat = 73
16-bit-per-channel unsigned integer red channel data format. Values are in the [code][0.0, 65535][/code] range.

## DATA_FORMAT_R16_SINT :: const RenderingDevice.DATA_FORMAT_R16_SINT: DataFormat = 74
16-bit-per-channel signed integer red channel data format. Values are in the [code][-32767, 32767][/code] range.

## DATA_FORMAT_R16_SFLOAT :: const RenderingDevice.DATA_FORMAT_R16_SFLOAT: DataFormat = 75
16-bit-per-channel signed floating-point red channel data format with the value stored as-is.

## DATA_FORMAT_R16G16_UNORM :: const RenderingDevice.DATA_FORMAT_R16G16_UNORM: DataFormat = 76
16-bit-per-channel unsigned floating-point red/green channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R16G16_SNORM :: const RenderingDevice.DATA_FORMAT_R16G16_SNORM: DataFormat = 77
16-bit-per-channel signed floating-point red/green channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_R16G16_USCALED :: const RenderingDevice.DATA_FORMAT_R16G16_USCALED: DataFormat = 78
16-bit-per-channel unsigned floating-point red/green channel data format with scaled value (value is converted from integer to float). Values are in the [code][0.0, 65535.0][/code] range.

## DATA_FORMAT_R16G16_SSCALED :: const RenderingDevice.DATA_FORMAT_R16G16_SSCALED: DataFormat = 79
16-bit-per-channel signed floating-point red/green channel data format with scaled value (value is converted from integer to float). Values are in the [code][-32767.0, 32767.0][/code] range.

## DATA_FORMAT_R16G16_UINT :: const RenderingDevice.DATA_FORMAT_R16G16_UINT: DataFormat = 80
16-bit-per-channel unsigned integer red/green channel data format. Values are in the [code][0.0, 65535][/code] range.

## DATA_FORMAT_R16G16_SINT :: const RenderingDevice.DATA_FORMAT_R16G16_SINT: DataFormat = 81
16-bit-per-channel signed integer red/green channel data format. Values are in the [code][-32767, 32767][/code] range.

## DATA_FORMAT_R16G16_SFLOAT :: const RenderingDevice.DATA_FORMAT_R16G16_SFLOAT: DataFormat = 82
16-bit-per-channel signed floating-point red/green channel data format with the value stored as-is.

## DATA_FORMAT_R16G16B16_UNORM :: const RenderingDevice.DATA_FORMAT_R16G16B16_UNORM: DataFormat = 83
16-bit-per-channel unsigned floating-point red/green/blue channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R16G16B16_SNORM :: const RenderingDevice.DATA_FORMAT_R16G16B16_SNORM: DataFormat = 84
16-bit-per-channel signed floating-point red/green/blue channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_R16G16B16_USCALED :: const RenderingDevice.DATA_FORMAT_R16G16B16_USCALED: DataFormat = 85
16-bit-per-channel unsigned floating-point red/green/blue channel data format with scaled value (value is converted from integer to float). Values are in the [code][0.0, 65535.0][/code] range.

## DATA_FORMAT_R16G16B16_SSCALED :: const RenderingDevice.DATA_FORMAT_R16G16B16_SSCALED: DataFormat = 86
16-bit-per-channel signed floating-point red/green/blue channel data format with scaled value (value is converted from integer to float). Values are in the [code][-32767.0, 32767.0][/code] range.

## DATA_FORMAT_R16G16B16_UINT :: const RenderingDevice.DATA_FORMAT_R16G16B16_UINT: DataFormat = 87
16-bit-per-channel unsigned integer red/green/blue channel data format. Values are in the [code][0.0, 65535][/code] range.

## DATA_FORMAT_R16G16B16_SINT :: const RenderingDevice.DATA_FORMAT_R16G16B16_SINT: DataFormat = 88
16-bit-per-channel signed integer red/green/blue channel data format. Values are in the [code][-32767, 32767][/code] range.

## DATA_FORMAT_R16G16B16_SFLOAT :: const RenderingDevice.DATA_FORMAT_R16G16B16_SFLOAT: DataFormat = 89
16-bit-per-channel signed floating-point red/green/blue channel data format with the value stored as-is.

## DATA_FORMAT_R16G16B16A16_UNORM :: const RenderingDevice.DATA_FORMAT_R16G16B16A16_UNORM: DataFormat = 90
16-bit-per-channel unsigned floating-point red/green/blue/alpha channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R16G16B16A16_SNORM :: const RenderingDevice.DATA_FORMAT_R16G16B16A16_SNORM: DataFormat = 91
16-bit-per-channel signed floating-point red/green/blue/alpha channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range.

## DATA_FORMAT_R16G16B16A16_USCALED :: const RenderingDevice.DATA_FORMAT_R16G16B16A16_USCALED: DataFormat = 92
16-bit-per-channel unsigned floating-point red/green/blue/alpha channel data format with scaled value (value is converted from integer to float). Values are in the [code][0.0, 65535.0][/code] range.

## DATA_FORMAT_R16G16B16A16_SSCALED :: const RenderingDevice.DATA_FORMAT_R16G16B16A16_SSCALED: DataFormat = 93
16-bit-per-channel signed floating-point red/green/blue/alpha channel data format with scaled value (value is converted from integer to float). Values are in the [code][-32767.0, 32767.0][/code] range.

## DATA_FORMAT_R16G16B16A16_UINT :: const RenderingDevice.DATA_FORMAT_R16G16B16A16_UINT: DataFormat = 94
16-bit-per-channel unsigned integer red/green/blue/alpha channel data format. Values are in the [code][0.0, 65535][/code] range.

## DATA_FORMAT_R16G16B16A16_SINT :: const RenderingDevice.DATA_FORMAT_R16G16B16A16_SINT: DataFormat = 95
16-bit-per-channel signed integer red/green/blue/alpha channel data format. Values are in the [code][-32767, 32767][/code] range.

## DATA_FORMAT_R16G16B16A16_SFLOAT :: const RenderingDevice.DATA_FORMAT_R16G16B16A16_SFLOAT: DataFormat = 96
16-bit-per-channel signed floating-point red/green/blue/alpha channel data format with the value stored as-is.

## DATA_FORMAT_R32_UINT :: const RenderingDevice.DATA_FORMAT_R32_UINT: DataFormat = 97
32-bit-per-channel unsigned integer red channel data format. Values are in the [code][0, 2^32 - 1][/code] range.

## DATA_FORMAT_R32_SINT :: const RenderingDevice.DATA_FORMAT_R32_SINT: DataFormat = 98
32-bit-per-channel signed integer red channel data format. Values are in the [code][2^31 + 1, 2^31 - 1][/code] range.

## DATA_FORMAT_R32_SFLOAT :: const RenderingDevice.DATA_FORMAT_R32_SFLOAT: DataFormat = 99
32-bit-per-channel signed floating-point red channel data format with the value stored as-is.

## DATA_FORMAT_R32G32_UINT :: const RenderingDevice.DATA_FORMAT_R32G32_UINT: DataFormat = 100
32-bit-per-channel unsigned integer red/green channel data format. Values are in the [code][0, 2^32 - 1][/code] range.

## DATA_FORMAT_R32G32_SINT :: const RenderingDevice.DATA_FORMAT_R32G32_SINT: DataFormat = 101
32-bit-per-channel signed integer red/green channel data format. Values are in the [code][2^31 + 1, 2^31 - 1][/code] range.

## DATA_FORMAT_R32G32_SFLOAT :: const RenderingDevice.DATA_FORMAT_R32G32_SFLOAT: DataFormat = 102
32-bit-per-channel signed floating-point red/green channel data format with the value stored as-is.

## DATA_FORMAT_R32G32B32_UINT :: const RenderingDevice.DATA_FORMAT_R32G32B32_UINT: DataFormat = 103
32-bit-per-channel unsigned integer red/green/blue channel data format. Values are in the [code][0, 2^32 - 1][/code] range.

## DATA_FORMAT_R32G32B32_SINT :: const RenderingDevice.DATA_FORMAT_R32G32B32_SINT: DataFormat = 104
32-bit-per-channel signed integer red/green/blue channel data format. Values are in the [code][2^31 + 1, 2^31 - 1][/code] range.

## DATA_FORMAT_R32G32B32_SFLOAT :: const RenderingDevice.DATA_FORMAT_R32G32B32_SFLOAT: DataFormat = 105
32-bit-per-channel signed floating-point red/green/blue channel data format with the value stored as-is.

## DATA_FORMAT_R32G32B32A32_UINT :: const RenderingDevice.DATA_FORMAT_R32G32B32A32_UINT: DataFormat = 106
32-bit-per-channel unsigned integer red/green/blue/alpha channel data format. Values are in the [code][0, 2^32 - 1][/code] range.

## DATA_FORMAT_R32G32B32A32_SINT :: const RenderingDevice.DATA_FORMAT_R32G32B32A32_SINT: DataFormat = 107
32-bit-per-channel signed integer red/green/blue/alpha channel data format. Values are in the [code][2^31 + 1, 2^31 - 1][/code] range.

## DATA_FORMAT_R32G32B32A32_SFLOAT :: const RenderingDevice.DATA_FORMAT_R32G32B32A32_SFLOAT: DataFormat = 108
32-bit-per-channel signed floating-point red/green/blue/alpha channel data format with the value stored as-is.

## DATA_FORMAT_R64_UINT :: const RenderingDevice.DATA_FORMAT_R64_UINT: DataFormat = 109
64-bit-per-channel unsigned integer red channel data format. Values are in the [code][0, 2^64 - 1][/code] range.

## DATA_FORMAT_R64_SINT :: const RenderingDevice.DATA_FORMAT_R64_SINT: DataFormat = 110
64-bit-per-channel signed integer red channel data format. Values are in the [code][2^63 + 1, 2^63 - 1][/code] range.

## DATA_FORMAT_R64_SFLOAT :: const RenderingDevice.DATA_FORMAT_R64_SFLOAT: DataFormat = 111
64-bit-per-channel signed floating-point red channel data format with the value stored as-is.

## DATA_FORMAT_R64G64_UINT :: const RenderingDevice.DATA_FORMAT_R64G64_UINT: DataFormat = 112
64-bit-per-channel unsigned integer red/green channel data format. Values are in the [code][0, 2^64 - 1][/code] range.

## DATA_FORMAT_R64G64_SINT :: const RenderingDevice.DATA_FORMAT_R64G64_SINT: DataFormat = 113
64-bit-per-channel signed integer red/green channel data format. Values are in the [code][2^63 + 1, 2^63 - 1][/code] range.

## DATA_FORMAT_R64G64_SFLOAT :: const RenderingDevice.DATA_FORMAT_R64G64_SFLOAT: DataFormat = 114
64-bit-per-channel signed floating-point red/green channel data format with the value stored as-is.

## DATA_FORMAT_R64G64B64_UINT :: const RenderingDevice.DATA_FORMAT_R64G64B64_UINT: DataFormat = 115
64-bit-per-channel unsigned integer red/green/blue channel data format. Values are in the [code][0, 2^64 - 1][/code] range.

## DATA_FORMAT_R64G64B64_SINT :: const RenderingDevice.DATA_FORMAT_R64G64B64_SINT: DataFormat = 116
64-bit-per-channel signed integer red/green/blue channel data format. Values are in the [code][2^63 + 1, 2^63 - 1][/code] range.

## DATA_FORMAT_R64G64B64_SFLOAT :: const RenderingDevice.DATA_FORMAT_R64G64B64_SFLOAT: DataFormat = 117
64-bit-per-channel signed floating-point red/green/blue channel data format with the value stored as-is.

## DATA_FORMAT_R64G64B64A64_UINT :: const RenderingDevice.DATA_FORMAT_R64G64B64A64_UINT: DataFormat = 118
64-bit-per-channel unsigned integer red/green/blue/alpha channel data format. Values are in the [code][0, 2^64 - 1][/code] range.

## DATA_FORMAT_R64G64B64A64_SINT :: const RenderingDevice.DATA_FORMAT_R64G64B64A64_SINT: DataFormat = 119
64-bit-per-channel signed integer red/green/blue/alpha channel data format. Values are in the [code][2^63 + 1, 2^63 - 1][/code] range.

## DATA_FORMAT_R64G64B64A64_SFLOAT :: const RenderingDevice.DATA_FORMAT_R64G64B64A64_SFLOAT: DataFormat = 120
64-bit-per-channel signed floating-point red/green/blue/alpha channel data format with the value stored as-is.

## DATA_FORMAT_B10G11R11_UFLOAT_PACK32 :: const RenderingDevice.DATA_FORMAT_B10G11R11_UFLOAT_PACK32: DataFormat = 121
Unsigned floating-point blue/green/red data format with the value stored as-is, packed in 32 bits. The format's precision is 10 bits of blue channel, 11 bits of green channel and 11 bits of red channel.

## DATA_FORMAT_E5B9G9R9_UFLOAT_PACK32 :: const RenderingDevice.DATA_FORMAT_E5B9G9R9_UFLOAT_PACK32: DataFormat = 122
Unsigned floating-point exposure/blue/green/red data format with the value stored as-is, packed in 32 bits. The format's precision is 5 bits of exposure, 9 bits of blue channel, 9 bits of green channel and 9 bits of red channel.

## DATA_FORMAT_D16_UNORM :: const RenderingDevice.DATA_FORMAT_D16_UNORM: DataFormat = 123
16-bit unsigned floating-point depth data format with normalized value. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_X8_D24_UNORM_PACK32 :: const RenderingDevice.DATA_FORMAT_X8_D24_UNORM_PACK32: DataFormat = 124
24-bit unsigned floating-point depth data format with normalized value, plus 8 unused bits, packed in 32 bits. Values for depth are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_D32_SFLOAT :: const RenderingDevice.DATA_FORMAT_D32_SFLOAT: DataFormat = 125
32-bit signed floating-point depth data format with the value stored as-is.

## DATA_FORMAT_S8_UINT :: const RenderingDevice.DATA_FORMAT_S8_UINT: DataFormat = 126
8-bit unsigned integer stencil data format.

## DATA_FORMAT_D16_UNORM_S8_UINT :: const RenderingDevice.DATA_FORMAT_D16_UNORM_S8_UINT: DataFormat = 127
16-bit unsigned floating-point depth data format with normalized value, plus 8 bits of stencil in unsigned integer format. Values for depth are in the [code][0.0, 1.0][/code] range. Values for stencil are in the [code][0, 255][/code] range.

## DATA_FORMAT_D24_UNORM_S8_UINT :: const RenderingDevice.DATA_FORMAT_D24_UNORM_S8_UINT: DataFormat = 128
24-bit unsigned floating-point depth data format with normalized value, plus 8 bits of stencil in unsigned integer format. Values for depth are in the [code][0.0, 1.0][/code] range. Values for stencil are in the [code][0, 255][/code] range.

## DATA_FORMAT_D32_SFLOAT_S8_UINT :: const RenderingDevice.DATA_FORMAT_D32_SFLOAT_S8_UINT: DataFormat = 129
32-bit signed floating-point depth data format with the value stored as-is, plus 8 bits of stencil in unsigned integer format. Values for stencil are in the [code][0, 255][/code] range.

## DATA_FORMAT_BC1_RGB_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_BC1_RGB_UNORM_BLOCK: DataFormat = 130
VRAM-compressed unsigned red/green/blue channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. The format's precision is 5 bits of red channel, 6 bits of green channel and 5 bits of blue channel. Using BC1 texture compression (also known as S3TC DXT1).

## DATA_FORMAT_BC1_RGB_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_BC1_RGB_SRGB_BLOCK: DataFormat = 131
VRAM-compressed unsigned red/green/blue channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range. The format's precision is 5 bits of red channel, 6 bits of green channel, and 5 bits of blue channel. Using BC1 texture compression (also known as S3TC DXT1).

## DATA_FORMAT_BC1_RGBA_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_BC1_RGBA_UNORM_BLOCK: DataFormat = 132
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. The format's precision is 5 bits of red channel, 6 bits of green channel, 5 bits of blue channel and 1 bit of alpha channel. Using BC1 texture compression (also known as S3TC DXT1).

## DATA_FORMAT_BC1_RGBA_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_BC1_RGBA_SRGB_BLOCK: DataFormat = 133
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range. The format's precision is 5 bits of red channel, 6 bits of green channel, 5 bits of blue channel, and 1 bit of alpha channel. Using BC1 texture compression (also known as S3TC DXT1).

## DATA_FORMAT_BC2_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_BC2_UNORM_BLOCK: DataFormat = 134
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. The format's precision is 5 bits of red channel, 6 bits of green channel, 5 bits of blue channel and 4 bits of alpha channel. Using BC2 texture compression (also known as S3TC DXT3).

## DATA_FORMAT_BC2_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_BC2_SRGB_BLOCK: DataFormat = 135
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range. The format's precision is 5 bits of red channel, 6 bits of green channel, 5 bits of blue channel, and 4 bits of alpha channel. Using BC2 texture compression (also known as S3TC DXT3).

## DATA_FORMAT_BC3_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_BC3_UNORM_BLOCK: DataFormat = 136
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. The format's precision is 5 bits of red channel, 6 bits of green channel, 5 bits of blue channel and 8 bits of alpha channel. Using BC3 texture compression (also known as S3TC DXT5).

## DATA_FORMAT_BC3_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_BC3_SRGB_BLOCK: DataFormat = 137
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range. The format's precision is 5 bits of red channel, 6 bits of green channel, 5 bits of blue channel, and 8 bits of alpha channel. Using BC3 texture compression (also known as S3TC DXT5).

## DATA_FORMAT_BC4_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_BC4_UNORM_BLOCK: DataFormat = 138
VRAM-compressed unsigned red channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. The format's precision is 8 bits of red channel. Using BC4 texture compression.

## DATA_FORMAT_BC4_SNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_BC4_SNORM_BLOCK: DataFormat = 139
VRAM-compressed signed red channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range. The format's precision is 8 bits of red channel. Using BC4 texture compression.

## DATA_FORMAT_BC5_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_BC5_UNORM_BLOCK: DataFormat = 140
VRAM-compressed unsigned red/green channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. The format's precision is 8 bits of red channel and 8 bits of green channel. Using BC5 texture compression (also known as S3TC RGTC).

## DATA_FORMAT_BC5_SNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_BC5_SNORM_BLOCK: DataFormat = 141
VRAM-compressed signed red/green channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range. The format's precision is 8 bits of red channel and 8 bits of green channel. Using BC5 texture compression (also known as S3TC RGTC).

## DATA_FORMAT_BC6H_UFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_BC6H_UFLOAT_BLOCK: DataFormat = 142
VRAM-compressed unsigned red/green/blue channel data format with the floating-point value stored as-is. The format's precision is between 10 and 13 bits for the red/green/blue channels. Using BC6H texture compression (also known as BPTC HDR).

## DATA_FORMAT_BC6H_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_BC6H_SFLOAT_BLOCK: DataFormat = 143
VRAM-compressed signed red/green/blue channel data format with the floating-point value stored as-is. The format's precision is between 10 and 13 bits for the red/green/blue channels. Using BC6H texture compression (also known as BPTC HDR).

## DATA_FORMAT_BC7_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_BC7_UNORM_BLOCK: DataFormat = 144
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. The format's precision is between 4 and 7 bits for the red/green/blue channels and between 0 and 8 bits for the alpha channel. Also known as BPTC LDR.

## DATA_FORMAT_BC7_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_BC7_SRGB_BLOCK: DataFormat = 145
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range. The format's precision is between 4 and 7 bits for the red/green/blue channels and between 0 and 8 bits for the alpha channel. Also known as BPTC LDR.

## DATA_FORMAT_ETC2_R8G8B8_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ETC2_R8G8B8_UNORM_BLOCK: DataFormat = 146
VRAM-compressed unsigned red/green/blue channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. Using ETC2 texture compression.

## DATA_FORMAT_ETC2_R8G8B8_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ETC2_R8G8B8_SRGB_BLOCK: DataFormat = 147
VRAM-compressed unsigned red/green/blue channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range. Using ETC2 texture compression.

## DATA_FORMAT_ETC2_R8G8B8A1_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ETC2_R8G8B8A1_UNORM_BLOCK: DataFormat = 148
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. Red/green/blue use 8 bit of precision each, with alpha using 1 bit of precision. Using ETC2 texture compression.

## DATA_FORMAT_ETC2_R8G8B8A1_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ETC2_R8G8B8A1_SRGB_BLOCK: DataFormat = 149
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range. Red/green/blue use 8 bit of precision each, with alpha using 1 bit of precision. Using ETC2 texture compression.

## DATA_FORMAT_ETC2_R8G8B8A8_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ETC2_R8G8B8A8_UNORM_BLOCK: DataFormat = 150
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. Red/green/blue use 8 bits of precision each, with alpha using 8 bits of precision. Using ETC2 texture compression.

## DATA_FORMAT_ETC2_R8G8B8A8_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ETC2_R8G8B8A8_SRGB_BLOCK: DataFormat = 151
VRAM-compressed unsigned red/green/blue/alpha channel data format with normalized value and nonlinear sRGB encoding. Values are in the [code][0.0, 1.0][/code] range. Red/green/blue use 8 bits of precision each, with alpha using 8 bits of precision. Using ETC2 texture compression.

## DATA_FORMAT_EAC_R11_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_EAC_R11_UNORM_BLOCK: DataFormat = 152
11-bit VRAM-compressed unsigned red channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. Using ETC2 texture compression.

## DATA_FORMAT_EAC_R11_SNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_EAC_R11_SNORM_BLOCK: DataFormat = 153
11-bit VRAM-compressed signed red channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range. Using ETC2 texture compression.

## DATA_FORMAT_EAC_R11G11_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_EAC_R11G11_UNORM_BLOCK: DataFormat = 154
11-bit VRAM-compressed unsigned red/green channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. Using ETC2 texture compression.

## DATA_FORMAT_EAC_R11G11_SNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_EAC_R11G11_SNORM_BLOCK: DataFormat = 155
11-bit VRAM-compressed signed red/green channel data format with normalized value. Values are in the [code][-1.0, 1.0][/code] range. Using ETC2 texture compression.

## DATA_FORMAT_ASTC_4x4_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_4x4_UNORM_BLOCK: DataFormat = 156
VRAM-compressed unsigned floating-point data format with normalized value, packed in 4×4 blocks (highest quality). Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_4x4_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_4x4_SRGB_BLOCK: DataFormat = 157
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 4×4 blocks (highest quality). Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_5x4_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_5x4_UNORM_BLOCK: DataFormat = 158
VRAM-compressed unsigned floating-point data format with normalized value, packed in 5×4 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_5x4_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_5x4_SRGB_BLOCK: DataFormat = 159
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 5×4 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_5x5_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_5x5_UNORM_BLOCK: DataFormat = 160
VRAM-compressed unsigned floating-point data format with normalized value, packed in 5×5 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_5x5_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_5x5_SRGB_BLOCK: DataFormat = 161
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 5×5 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_6x5_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_6x5_UNORM_BLOCK: DataFormat = 162
VRAM-compressed unsigned floating-point data format with normalized value, packed in 6×5 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_6x5_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_6x5_SRGB_BLOCK: DataFormat = 163
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 6×5 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_6x6_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_6x6_UNORM_BLOCK: DataFormat = 164
VRAM-compressed unsigned floating-point data format with normalized value, packed in 6×6 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_6x6_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_6x6_SRGB_BLOCK: DataFormat = 165
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 6×6 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_8x5_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_8x5_UNORM_BLOCK: DataFormat = 166
VRAM-compressed unsigned floating-point data format with normalized value, packed in 8×5 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_8x5_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_8x5_SRGB_BLOCK: DataFormat = 167
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 8×5 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_8x6_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_8x6_UNORM_BLOCK: DataFormat = 168
VRAM-compressed unsigned floating-point data format with normalized value, packed in 8×6 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_8x6_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_8x6_SRGB_BLOCK: DataFormat = 169
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 8×6 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_8x8_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_8x8_UNORM_BLOCK: DataFormat = 170
VRAM-compressed unsigned floating-point data format with normalized value, packed in 8×8 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_8x8_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_8x8_SRGB_BLOCK: DataFormat = 171
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 8×8 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_10x5_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x5_UNORM_BLOCK: DataFormat = 172
VRAM-compressed unsigned floating-point data format with normalized value, packed in 10×5 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_10x5_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x5_SRGB_BLOCK: DataFormat = 173
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 10×5 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_10x6_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x6_UNORM_BLOCK: DataFormat = 174
VRAM-compressed unsigned floating-point data format with normalized value, packed in 10×6 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_10x6_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x6_SRGB_BLOCK: DataFormat = 175
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 10×6 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_10x8_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x8_UNORM_BLOCK: DataFormat = 176
VRAM-compressed unsigned floating-point data format with normalized value, packed in 10×8 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_10x8_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x8_SRGB_BLOCK: DataFormat = 177
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 10×8 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_10x10_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x10_UNORM_BLOCK: DataFormat = 178
VRAM-compressed unsigned floating-point data format with normalized value, packed in 10×10 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_10x10_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x10_SRGB_BLOCK: DataFormat = 179
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 10×10 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_12x10_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_12x10_UNORM_BLOCK: DataFormat = 180
VRAM-compressed unsigned floating-point data format with normalized value, packed in 12×10 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_12x10_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_12x10_SRGB_BLOCK: DataFormat = 181
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 12×10 blocks. Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_12x12_UNORM_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_12x12_UNORM_BLOCK: DataFormat = 182
VRAM-compressed unsigned floating-point data format with normalized value, packed in 12 blocks (lowest quality). Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_ASTC_12x12_SRGB_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_12x12_SRGB_BLOCK: DataFormat = 183
VRAM-compressed unsigned floating-point data format with normalized value and nonlinear sRGB encoding, packed in 12 blocks (lowest quality). Values are in the [code][0.0, 1.0][/code] range. Using ASTC compression.

## DATA_FORMAT_G8B8G8R8_422_UNORM :: const RenderingDevice.DATA_FORMAT_G8B8G8R8_422_UNORM: DataFormat = 184
8-bit-per-channel unsigned floating-point green/blue/red channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_B8G8R8G8_422_UNORM :: const RenderingDevice.DATA_FORMAT_B8G8R8G8_422_UNORM: DataFormat = 185
8-bit-per-channel unsigned floating-point blue/green/red channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G8_B8_R8_3PLANE_420_UNORM :: const RenderingDevice.DATA_FORMAT_G8_B8_R8_3PLANE_420_UNORM: DataFormat = 186
8-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, stored across 3 separate planes (green + blue + red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal and vertical resolution (i.e. 2×2 adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G8_B8R8_2PLANE_420_UNORM :: const RenderingDevice.DATA_FORMAT_G8_B8R8_2PLANE_420_UNORM: DataFormat = 187
8-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, stored across 2 separate planes (green + blue/red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal and vertical resolution (i.e. 2×2 adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G8_B8_R8_3PLANE_422_UNORM :: const RenderingDevice.DATA_FORMAT_G8_B8_R8_3PLANE_422_UNORM: DataFormat = 188
8-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, stored across 2 separate planes (green + blue + red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G8_B8R8_2PLANE_422_UNORM :: const RenderingDevice.DATA_FORMAT_G8_B8R8_2PLANE_422_UNORM: DataFormat = 189
8-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, stored across 2 separate planes (green + blue/red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G8_B8_R8_3PLANE_444_UNORM :: const RenderingDevice.DATA_FORMAT_G8_B8_R8_3PLANE_444_UNORM: DataFormat = 190
8-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, stored across 3 separate planes. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R10X6_UNORM_PACK16 :: const RenderingDevice.DATA_FORMAT_R10X6_UNORM_PACK16: DataFormat = 191
10-bit-per-channel unsigned floating-point red channel data with normalized value, plus 6 unused bits, packed in 16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R10X6G10X6_UNORM_2PACK16 :: const RenderingDevice.DATA_FORMAT_R10X6G10X6_UNORM_2PACK16: DataFormat = 192
10-bit-per-channel unsigned floating-point red/green channel data with normalized value, plus 6 unused bits after each channel, packed in 2×16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R10X6G10X6B10X6A10X6_UNORM_4PACK16 :: const RenderingDevice.DATA_FORMAT_R10X6G10X6B10X6A10X6_UNORM_4PACK16: DataFormat = 193
10-bit-per-channel unsigned floating-point red/green/blue/alpha channel data with normalized value, plus 6 unused bits after each channel, packed in 4×16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_G10X6B10X6G10X6R10X6_422_UNORM_4PACK16 :: const RenderingDevice.DATA_FORMAT_G10X6B10X6G10X6R10X6_422_UNORM_4PACK16: DataFormat = 194
10-bit-per-channel unsigned floating-point green/blue/green/red channel data with normalized value, plus 6 unused bits after each channel, packed in 4×16 bits. Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel). The green channel is listed twice, but contains different values to allow it to be represented at full resolution.

## DATA_FORMAT_B10X6G10X6R10X6G10X6_422_UNORM_4PACK16 :: const RenderingDevice.DATA_FORMAT_B10X6G10X6R10X6G10X6_422_UNORM_4PACK16: DataFormat = 195
10-bit-per-channel unsigned floating-point blue/green/red/green channel data with normalized value, plus 6 unused bits after each channel, packed in 4×16 bits. Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel). The green channel is listed twice, but contains different values to allow it to be represented at full resolution.

## DATA_FORMAT_G10X6_B10X6_R10X6_3PLANE_420_UNORM_3PACK16 :: const RenderingDevice.DATA_FORMAT_G10X6_B10X6_R10X6_3PLANE_420_UNORM_3PACK16: DataFormat = 196
10-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Packed in 3×16 bits and stored across 2 separate planes (green + blue + red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal and vertical resolution (i.e. 2×2 adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G10X6_B10X6R10X6_2PLANE_420_UNORM_3PACK16 :: const RenderingDevice.DATA_FORMAT_G10X6_B10X6R10X6_2PLANE_420_UNORM_3PACK16: DataFormat = 197
10-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Packed in 3×16 bits and stored across 2 separate planes (green + blue/red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal and vertical resolution (i.e. 2×2 adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G10X6_B10X6_R10X6_3PLANE_422_UNORM_3PACK16 :: const RenderingDevice.DATA_FORMAT_G10X6_B10X6_R10X6_3PLANE_422_UNORM_3PACK16: DataFormat = 198
10-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Packed in 3×16 bits and stored across 3 separate planes (green + blue + red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G10X6_B10X6R10X6_2PLANE_422_UNORM_3PACK16 :: const RenderingDevice.DATA_FORMAT_G10X6_B10X6R10X6_2PLANE_422_UNORM_3PACK16: DataFormat = 199
10-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Packed in 3×16 bits and stored across 3 separate planes (green + blue/red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G10X6_B10X6_R10X6_3PLANE_444_UNORM_3PACK16 :: const RenderingDevice.DATA_FORMAT_G10X6_B10X6_R10X6_3PLANE_444_UNORM_3PACK16: DataFormat = 200
10-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Packed in 3×16 bits and stored across 3 separate planes (green + blue + red). Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R12X4_UNORM_PACK16 :: const RenderingDevice.DATA_FORMAT_R12X4_UNORM_PACK16: DataFormat = 201
12-bit-per-channel unsigned floating-point red channel data with normalized value, plus 6 unused bits, packed in 16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R12X4G12X4_UNORM_2PACK16 :: const RenderingDevice.DATA_FORMAT_R12X4G12X4_UNORM_2PACK16: DataFormat = 202
12-bit-per-channel unsigned floating-point red/green channel data with normalized value, plus 6 unused bits after each channel, packed in 2×16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_R12X4G12X4B12X4A12X4_UNORM_4PACK16 :: const RenderingDevice.DATA_FORMAT_R12X4G12X4B12X4A12X4_UNORM_4PACK16: DataFormat = 203
12-bit-per-channel unsigned floating-point red/green/blue/alpha channel data with normalized value, plus 6 unused bits after each channel, packed in 4×16 bits. Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_G12X4B12X4G12X4R12X4_422_UNORM_4PACK16 :: const RenderingDevice.DATA_FORMAT_G12X4B12X4G12X4R12X4_422_UNORM_4PACK16: DataFormat = 204
12-bit-per-channel unsigned floating-point green/blue/green/red channel data with normalized value, plus 6 unused bits after each channel, packed in 4×16 bits. Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel). The green channel is listed twice, but contains different values to allow it to be represented at full resolution.

## DATA_FORMAT_B12X4G12X4R12X4G12X4_422_UNORM_4PACK16 :: const RenderingDevice.DATA_FORMAT_B12X4G12X4R12X4G12X4_422_UNORM_4PACK16: DataFormat = 205
12-bit-per-channel unsigned floating-point blue/green/red/green channel data with normalized value, plus 6 unused bits after each channel, packed in 4×16 bits. Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel). The green channel is listed twice, but contains different values to allow it to be represented at full resolution.

## DATA_FORMAT_G12X4_B12X4_R12X4_3PLANE_420_UNORM_3PACK16 :: const RenderingDevice.DATA_FORMAT_G12X4_B12X4_R12X4_3PLANE_420_UNORM_3PACK16: DataFormat = 206
12-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Packed in 3×16 bits and stored across 2 separate planes (green + blue + red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal and vertical resolution (i.e. 2×2 adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G12X4_B12X4R12X4_2PLANE_420_UNORM_3PACK16 :: const RenderingDevice.DATA_FORMAT_G12X4_B12X4R12X4_2PLANE_420_UNORM_3PACK16: DataFormat = 207
12-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Packed in 3×16 bits and stored across 2 separate planes (green + blue/red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal and vertical resolution (i.e. 2×2 adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G12X4_B12X4_R12X4_3PLANE_422_UNORM_3PACK16 :: const RenderingDevice.DATA_FORMAT_G12X4_B12X4_R12X4_3PLANE_422_UNORM_3PACK16: DataFormat = 208
12-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Packed in 3×16 bits and stored across 3 separate planes (green + blue + red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G12X4_B12X4R12X4_2PLANE_422_UNORM_3PACK16 :: const RenderingDevice.DATA_FORMAT_G12X4_B12X4R12X4_2PLANE_422_UNORM_3PACK16: DataFormat = 209
12-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Packed in 3×16 bits and stored across 3 separate planes (green + blue/red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G12X4_B12X4_R12X4_3PLANE_444_UNORM_3PACK16 :: const RenderingDevice.DATA_FORMAT_G12X4_B12X4_R12X4_3PLANE_444_UNORM_3PACK16: DataFormat = 210
12-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Packed in 3×16 bits and stored across 3 separate planes (green + blue + red). Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_G16B16G16R16_422_UNORM :: const RenderingDevice.DATA_FORMAT_G16B16G16R16_422_UNORM: DataFormat = 211
16-bit-per-channel unsigned floating-point green/blue/red channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_B16G16R16G16_422_UNORM :: const RenderingDevice.DATA_FORMAT_B16G16R16G16_422_UNORM: DataFormat = 212
16-bit-per-channel unsigned floating-point blue/green/red channel data format with normalized value. Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G16_B16_R16_3PLANE_420_UNORM :: const RenderingDevice.DATA_FORMAT_G16_B16_R16_3PLANE_420_UNORM: DataFormat = 213
16-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Stored across 2 separate planes (green + blue + red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal and vertical resolution (i.e. 2×2 adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G16_B16R16_2PLANE_420_UNORM :: const RenderingDevice.DATA_FORMAT_G16_B16R16_2PLANE_420_UNORM: DataFormat = 214
16-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Stored across 2 separate planes (green + blue/red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal and vertical resolution (i.e. 2×2 adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G16_B16_R16_3PLANE_422_UNORM :: const RenderingDevice.DATA_FORMAT_G16_B16_R16_3PLANE_422_UNORM: DataFormat = 215
16-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Stored across 3 separate planes (green + blue + red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G16_B16R16_2PLANE_422_UNORM :: const RenderingDevice.DATA_FORMAT_G16_B16R16_2PLANE_422_UNORM: DataFormat = 216
16-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Stored across 3 separate planes (green + blue/red). Values are in the [code][0.0, 1.0][/code] range. Blue and red channel data is stored at halved horizontal resolution (i.e. 2 horizontally adjacent pixels will share the same value for the blue/red channel).

## DATA_FORMAT_G16_B16_R16_3PLANE_444_UNORM :: const RenderingDevice.DATA_FORMAT_G16_B16_R16_3PLANE_444_UNORM: DataFormat = 217
16-bit-per-channel unsigned floating-point green/blue/red channel data with normalized value, plus 6 unused bits after each channel. Stored across 3 separate planes (green + blue + red). Values are in the [code][0.0, 1.0][/code] range.

## DATA_FORMAT_ASTC_4x4_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_4x4_SFLOAT_BLOCK: DataFormat = 218

## DATA_FORMAT_ASTC_5x4_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_5x4_SFLOAT_BLOCK: DataFormat = 219

## DATA_FORMAT_ASTC_5x5_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_5x5_SFLOAT_BLOCK: DataFormat = 220

## DATA_FORMAT_ASTC_6x5_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_6x5_SFLOAT_BLOCK: DataFormat = 221

## DATA_FORMAT_ASTC_6x6_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_6x6_SFLOAT_BLOCK: DataFormat = 222

## DATA_FORMAT_ASTC_8x5_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_8x5_SFLOAT_BLOCK: DataFormat = 223

## DATA_FORMAT_ASTC_8x6_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_8x6_SFLOAT_BLOCK: DataFormat = 224

## DATA_FORMAT_ASTC_8x8_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_8x8_SFLOAT_BLOCK: DataFormat = 225

## DATA_FORMAT_ASTC_10x5_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x5_SFLOAT_BLOCK: DataFormat = 226

## DATA_FORMAT_ASTC_10x6_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x6_SFLOAT_BLOCK: DataFormat = 227

## DATA_FORMAT_ASTC_10x8_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x8_SFLOAT_BLOCK: DataFormat = 228

## DATA_FORMAT_ASTC_10x10_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_10x10_SFLOAT_BLOCK: DataFormat = 229

## DATA_FORMAT_ASTC_12x10_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_12x10_SFLOAT_BLOCK: DataFormat = 230

## DATA_FORMAT_ASTC_12x12_SFLOAT_BLOCK :: const RenderingDevice.DATA_FORMAT_ASTC_12x12_SFLOAT_BLOCK: DataFormat = 231

## DATA_FORMAT_MAX :: const RenderingDevice.DATA_FORMAT_MAX: DataFormat = 232
Represents the size of the [enum DataFormat] enum.

## BARRIER_MASK_VERTEX :: const RenderingDevice.BARRIER_MASK_VERTEX: BarrierMask = 1
Vertex shader barrier mask.

## BARRIER_MASK_FRAGMENT :: const RenderingDevice.BARRIER_MASK_FRAGMENT: BarrierMask = 8
Fragment shader barrier mask.

## BARRIER_MASK_COMPUTE :: const RenderingDevice.BARRIER_MASK_COMPUTE: BarrierMask = 2
Compute barrier mask.

## BARRIER_MASK_TRANSFER :: const RenderingDevice.BARRIER_MASK_TRANSFER: BarrierMask = 4
Transfer barrier mask.

## BARRIER_MASK_RASTER :: const RenderingDevice.BARRIER_MASK_RASTER: BarrierMask = 9
Raster barrier mask (vertex and fragment). Equivalent to [code]BARRIER_MASK_VERTEX | BARRIER_MASK_FRAGMENT[/code].

## BARRIER_MASK_ALL_BARRIERS :: const RenderingDevice.BARRIER_MASK_ALL_BARRIERS: BarrierMask = 32767
Barrier mask for all types (vertex, fragment, compute, transfer).

## BARRIER_MASK_NO_BARRIER :: const RenderingDevice.BARRIER_MASK_NO_BARRIER: BarrierMask = 32768
No barrier for any type.

## TEXTURE_TYPE_1D :: const RenderingDevice.TEXTURE_TYPE_1D: TextureType = 0
1-dimensional texture.

## TEXTURE_TYPE_2D :: const RenderingDevice.TEXTURE_TYPE_2D: TextureType = 1
2-dimensional texture.

## TEXTURE_TYPE_3D :: const RenderingDevice.TEXTURE_TYPE_3D: TextureType = 2
3-dimensional texture.

## TEXTURE_TYPE_CUBE :: const RenderingDevice.TEXTURE_TYPE_CUBE: TextureType = 3
[Cubemap] texture.

## TEXTURE_TYPE_1D_ARRAY :: const RenderingDevice.TEXTURE_TYPE_1D_ARRAY: TextureType = 4
Array of 1-dimensional textures.

## TEXTURE_TYPE_2D_ARRAY :: const RenderingDevice.TEXTURE_TYPE_2D_ARRAY: TextureType = 5
Array of 2-dimensional textures.

## TEXTURE_TYPE_CUBE_ARRAY :: const RenderingDevice.TEXTURE_TYPE_CUBE_ARRAY: TextureType = 6
Array of [Cubemap] textures.

## TEXTURE_TYPE_MAX :: const RenderingDevice.TEXTURE_TYPE_MAX: TextureType = 7
Represents the size of the [enum TextureType] enum.

## TEXTURE_SAMPLES_1 :: const RenderingDevice.TEXTURE_SAMPLES_1: TextureSamples = 0
Perform 1 texture sample (this is the fastest but lowest-quality for antialiasing).

## TEXTURE_SAMPLES_2 :: const RenderingDevice.TEXTURE_SAMPLES_2: TextureSamples = 1
Perform 2 texture samples.

## TEXTURE_SAMPLES_4 :: const RenderingDevice.TEXTURE_SAMPLES_4: TextureSamples = 2
Perform 4 texture samples.

## TEXTURE_SAMPLES_8 :: const RenderingDevice.TEXTURE_SAMPLES_8: TextureSamples = 3
Perform 8 texture samples. Not supported on mobile GPUs (including Apple Silicon).

## TEXTURE_SAMPLES_16 :: const RenderingDevice.TEXTURE_SAMPLES_16: TextureSamples = 4
Perform 16 texture samples. Not supported on mobile GPUs and many desktop GPUs.

## TEXTURE_SAMPLES_32 :: const RenderingDevice.TEXTURE_SAMPLES_32: TextureSamples = 5
Perform 32 texture samples. Not supported on most GPUs.

## TEXTURE_SAMPLES_64 :: const RenderingDevice.TEXTURE_SAMPLES_64: TextureSamples = 6
Perform 64 texture samples (this is the slowest but highest-quality for antialiasing). Not supported on most GPUs.

## TEXTURE_SAMPLES_MAX :: const RenderingDevice.TEXTURE_SAMPLES_MAX: TextureSamples = 7
Represents the size of the [enum TextureSamples] enum.

## TEXTURE_USAGE_SAMPLING_BIT :: const RenderingDevice.TEXTURE_USAGE_SAMPLING_BIT: TextureUsageBits = 1
Texture can be sampled.

## TEXTURE_USAGE_COLOR_ATTACHMENT_BIT :: const RenderingDevice.TEXTURE_USAGE_COLOR_ATTACHMENT_BIT: TextureUsageBits = 2
Texture can be used as a color attachment in a framebuffer.

## TEXTURE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT :: const RenderingDevice.TEXTURE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT: TextureUsageBits = 4
Texture can be used as a depth/stencil attachment in a framebuffer.

## TEXTURE_USAGE_DEPTH_RESOLVE_ATTACHMENT_BIT :: const RenderingDevice.TEXTURE_USAGE_DEPTH_RESOLVE_ATTACHMENT_BIT: TextureUsageBits = 4096
Texture can be used as a depth/stencil resolve attachment in a framebuffer.

## TEXTURE_USAGE_STORAGE_BIT :: const RenderingDevice.TEXTURE_USAGE_STORAGE_BIT: TextureUsageBits = 8
Texture can be used as a [url=https://registry.khronos.org/vulkan/specs/1.3-extensions/html/vkspec.html#descriptorsets-storageimage]storage image[/url].

## TEXTURE_USAGE_STORAGE_ATOMIC_BIT :: const RenderingDevice.TEXTURE_USAGE_STORAGE_ATOMIC_BIT: TextureUsageBits = 16
Texture can be used as a [url=https://registry.khronos.org/vulkan/specs/1.3-extensions/html/vkspec.html#descriptorsets-storageimage]storage image[/url] with support for atomic operations.

## TEXTURE_USAGE_CPU_READ_BIT :: const RenderingDevice.TEXTURE_USAGE_CPU_READ_BIT: TextureUsageBits = 32
Texture can be read back on the CPU using [method texture_get_data] faster than without this bit, since it is always kept in the system memory.

## TEXTURE_USAGE_CAN_UPDATE_BIT :: const RenderingDevice.TEXTURE_USAGE_CAN_UPDATE_BIT: TextureUsageBits = 64
Texture can be updated using [method texture_update].

## TEXTURE_USAGE_CAN_COPY_FROM_BIT :: const RenderingDevice.TEXTURE_USAGE_CAN_COPY_FROM_BIT: TextureUsageBits = 128
Texture can be a source for [method texture_copy].

## TEXTURE_USAGE_CAN_COPY_TO_BIT :: const RenderingDevice.TEXTURE_USAGE_CAN_COPY_TO_BIT: TextureUsageBits = 256
Texture can be a destination for [method texture_copy].

## TEXTURE_USAGE_INPUT_ATTACHMENT_BIT :: const RenderingDevice.TEXTURE_USAGE_INPUT_ATTACHMENT_BIT: TextureUsageBits = 512
Texture can be used as a [url=https://registry.khronos.org/vulkan/specs/1.3-extensions/html/vkspec.html#descriptorsets-inputattachment]input attachment[/url] in a framebuffer.

## TEXTURE_SWIZZLE_IDENTITY :: const RenderingDevice.TEXTURE_SWIZZLE_IDENTITY: TextureSwizzle = 0
Return the sampled value as-is.

## TEXTURE_SWIZZLE_ZERO :: const RenderingDevice.TEXTURE_SWIZZLE_ZERO: TextureSwizzle = 1
Always return [code]0.0[/code] when sampling.

## TEXTURE_SWIZZLE_ONE :: const RenderingDevice.TEXTURE_SWIZZLE_ONE: TextureSwizzle = 2
Always return [code]1.0[/code] when sampling.

## TEXTURE_SWIZZLE_R :: const RenderingDevice.TEXTURE_SWIZZLE_R: TextureSwizzle = 3
Sample the red color channel.

## TEXTURE_SWIZZLE_G :: const RenderingDevice.TEXTURE_SWIZZLE_G: TextureSwizzle = 4
Sample the green color channel.

## TEXTURE_SWIZZLE_B :: const RenderingDevice.TEXTURE_SWIZZLE_B: TextureSwizzle = 5
Sample the blue color channel.

## TEXTURE_SWIZZLE_A :: const RenderingDevice.TEXTURE_SWIZZLE_A: TextureSwizzle = 6
Sample the alpha channel.

## TEXTURE_SWIZZLE_MAX :: const RenderingDevice.TEXTURE_SWIZZLE_MAX: TextureSwizzle = 7
Represents the size of the [enum TextureSwizzle] enum.

## TEXTURE_SLICE_2D :: const RenderingDevice.TEXTURE_SLICE_2D: TextureSliceType = 0
2-dimensional texture slice.

## TEXTURE_SLICE_CUBEMAP :: const RenderingDevice.TEXTURE_SLICE_CUBEMAP: TextureSliceType = 1
Cubemap texture slice.

## TEXTURE_SLICE_3D :: const RenderingDevice.TEXTURE_SLICE_3D: TextureSliceType = 2
3-dimensional texture slice.

## SAMPLER_FILTER_NEAREST :: const RenderingDevice.SAMPLER_FILTER_NEAREST: SamplerFilter = 0
Nearest-neighbor sampler filtering. Sampling at higher resolutions than the source will result in a pixelated look.

## SAMPLER_FILTER_LINEAR :: const RenderingDevice.SAMPLER_FILTER_LINEAR: SamplerFilter = 1
Bilinear sampler filtering. Sampling at higher resolutions than the source will result in a blurry look.

## SAMPLER_REPEAT_MODE_REPEAT :: const RenderingDevice.SAMPLER_REPEAT_MODE_REPEAT: SamplerRepeatMode = 0
Sample with repeating enabled.

## SAMPLER_REPEAT_MODE_MIRRORED_REPEAT :: const RenderingDevice.SAMPLER_REPEAT_MODE_MIRRORED_REPEAT: SamplerRepeatMode = 1
Sample with mirrored repeating enabled. When sampling outside the [code][0.0, 1.0][/code] range, return a mirrored version of the sampler. This mirrored version is mirrored again if sampling further away, with the pattern repeating indefinitely.

## SAMPLER_REPEAT_MODE_CLAMP_TO_EDGE :: const RenderingDevice.SAMPLER_REPEAT_MODE_CLAMP_TO_EDGE: SamplerRepeatMode = 2
Sample with repeating disabled. When sampling outside the [code][0.0, 1.0][/code] range, return the color of the last pixel on the edge.

## SAMPLER_REPEAT_MODE_CLAMP_TO_BORDER :: const RenderingDevice.SAMPLER_REPEAT_MODE_CLAMP_TO_BORDER: SamplerRepeatMode = 3
Sample with repeating disabled. When sampling outside the [code][0.0, 1.0][/code] range, return the specified [member RDSamplerState.border_color].

## SAMPLER_REPEAT_MODE_MIRROR_CLAMP_TO_EDGE :: const RenderingDevice.SAMPLER_REPEAT_MODE_MIRROR_CLAMP_TO_EDGE: SamplerRepeatMode = 4
Sample with mirrored repeating enabled, but only once. When sampling in the [code][-1.0, 0.0][/code] range, return a mirrored version of the sampler. When sampling outside the [code][-1.0, 1.0][/code] range, return the color of the last pixel on the edge.

## SAMPLER_REPEAT_MODE_MAX :: const RenderingDevice.SAMPLER_REPEAT_MODE_MAX: SamplerRepeatMode = 5
Represents the size of the [enum SamplerRepeatMode] enum.

## SAMPLER_BORDER_COLOR_FLOAT_TRANSPARENT_BLACK :: const RenderingDevice.SAMPLER_BORDER_COLOR_FLOAT_TRANSPARENT_BLACK: SamplerBorderColor = 0
Return a floating-point transparent black color when sampling outside the [code][0.0, 1.0][/code] range. Only effective if the sampler repeat mode is [constant SAMPLER_REPEAT_MODE_CLAMP_TO_BORDER].

## SAMPLER_BORDER_COLOR_INT_TRANSPARENT_BLACK :: const RenderingDevice.SAMPLER_BORDER_COLOR_INT_TRANSPARENT_BLACK: SamplerBorderColor = 1
Return an integer transparent black color when sampling outside the [code][0.0, 1.0][/code] range. Only effective if the sampler repeat mode is [constant SAMPLER_REPEAT_MODE_CLAMP_TO_BORDER].

## SAMPLER_BORDER_COLOR_FLOAT_OPAQUE_BLACK :: const RenderingDevice.SAMPLER_BORDER_COLOR_FLOAT_OPAQUE_BLACK: SamplerBorderColor = 2
Return a floating-point opaque black color when sampling outside the [code][0.0, 1.0][/code] range. Only effective if the sampler repeat mode is [constant SAMPLER_REPEAT_MODE_CLAMP_TO_BORDER].

## SAMPLER_BORDER_COLOR_INT_OPAQUE_BLACK :: const RenderingDevice.SAMPLER_BORDER_COLOR_INT_OPAQUE_BLACK: SamplerBorderColor = 3
Return an integer opaque black color when sampling outside the [code][0.0, 1.0][/code] range. Only effective if the sampler repeat mode is [constant SAMPLER_REPEAT_MODE_CLAMP_TO_BORDER].

## SAMPLER_BORDER_COLOR_FLOAT_OPAQUE_WHITE :: const RenderingDevice.SAMPLER_BORDER_COLOR_FLOAT_OPAQUE_WHITE: SamplerBorderColor = 4
Return a floating-point opaque white color when sampling outside the [code][0.0, 1.0][/code] range. Only effective if the sampler repeat mode is [constant SAMPLER_REPEAT_MODE_CLAMP_TO_BORDER].

## SAMPLER_BORDER_COLOR_INT_OPAQUE_WHITE :: const RenderingDevice.SAMPLER_BORDER_COLOR_INT_OPAQUE_WHITE: SamplerBorderColor = 5
Return an integer opaque white color when sampling outside the [code][0.0, 1.0][/code] range. Only effective if the sampler repeat mode is [constant SAMPLER_REPEAT_MODE_CLAMP_TO_BORDER].

## SAMPLER_BORDER_COLOR_MAX :: const RenderingDevice.SAMPLER_BORDER_COLOR_MAX: SamplerBorderColor = 6
Represents the size of the [enum SamplerBorderColor] enum.

## VERTEX_FREQUENCY_VERTEX :: const RenderingDevice.VERTEX_FREQUENCY_VERTEX: VertexFrequency = 0
Vertex attribute addressing is a function of the vertex. This is used to specify the rate at which vertex attributes are pulled from buffers.

## VERTEX_FREQUENCY_INSTANCE :: const RenderingDevice.VERTEX_FREQUENCY_INSTANCE: VertexFrequency = 1
Vertex attribute addressing is a function of the instance index. This is used to specify the rate at which vertex attributes are pulled from buffers.

## INDEX_BUFFER_FORMAT_UINT16 :: const RenderingDevice.INDEX_BUFFER_FORMAT_UINT16: IndexBufferFormat = 0
Index buffer in 16-bit unsigned integer format. This limits the maximum index that can be specified to [code]65535[/code].

## INDEX_BUFFER_FORMAT_UINT32 :: const RenderingDevice.INDEX_BUFFER_FORMAT_UINT32: IndexBufferFormat = 1
Index buffer in 32-bit unsigned integer format. This limits the maximum index that can be specified to [code]4294967295[/code].

## STORAGE_BUFFER_USAGE_DISPATCH_INDIRECT :: const RenderingDevice.STORAGE_BUFFER_USAGE_DISPATCH_INDIRECT: StorageBufferUsage = 1

## BUFFER_CREATION_DEVICE_ADDRESS_BIT :: const RenderingDevice.BUFFER_CREATION_DEVICE_ADDRESS_BIT: BufferCreationBits = 1
Optionally, set this flag if you wish to use [method buffer_get_device_address] functionality. You must first check the GPU supports it:
[codeblocks]
[gdscript]
rd = RenderingServer.get_rendering_device()

if rd.has_feature(RenderingDevice.SUPPORTS_BUFFER_DEVICE_ADDRESS):
	storage_buffer = rd.storage_buffer_create(bytes.size(), bytes, RenderingDevice.STORAGE_BUFFER_USAGE_SHADER_DEVICE_ADDRESS)
	storage_buffer_address = rd.buffer_get_device_address(storage_buffer)
[/gdscript]
[/codeblocks]

## BUFFER_CREATION_AS_STORAGE_BIT :: const RenderingDevice.BUFFER_CREATION_AS_STORAGE_BIT: BufferCreationBits = 2
Set this flag so that it is created as storage. This is useful if Compute Shaders need access (for reading or writing) to the buffer, e.g. skeletal animations are processed in Compute Shaders which need access to vertex buffers, to be later consumed by vertex shaders as part of the regular rasterization pipeline.

## BUFFER_CREATION_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT :: const RenderingDevice.BUFFER_CREATION_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT: BufferCreationBits = 8
Allows usage of this buffer as input data for an acceleration structure build operation. You must first check that the GPU supports it:
[codeblocks]
[gdscript]
rd = RenderingServer.get_rendering_device()

if rd.has_feature(RenderingDevice.SUPPORTS_RAYTRACING_PIPELINE):
    storage_buffer = rd.storage_buffer_create(bytes.size(), bytes, RenderingDevice.BUFFER_CREATION_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT)
[/gdscript]
[/codeblocks]

## ACCELERATION_STRUCTURE_ALLOW_UPDATE_BIT :: const RenderingDevice.ACCELERATION_STRUCTURE_ALLOW_UPDATE_BIT: AccelerationStructureFlagBits = 1
Allows the acceleration structure to be updated after it has been built.

## ACCELERATION_STRUCTURE_ALLOW_COMPACTION_BIT :: const RenderingDevice.ACCELERATION_STRUCTURE_ALLOW_COMPACTION_BIT: AccelerationStructureFlagBits = 2
Allows the acceleration structure to be compacted to reduce memory usage after it has been built.

## ACCELERATION_STRUCTURE_PREFER_FAST_TRACE_BIT :: const RenderingDevice.ACCELERATION_STRUCTURE_PREFER_FAST_TRACE_BIT: AccelerationStructureFlagBits = 4
Prioritizes ray traversal performance over build performance when building the acceleration structure.

## ACCELERATION_STRUCTURE_PREFER_FAST_BUILD_BIT :: const RenderingDevice.ACCELERATION_STRUCTURE_PREFER_FAST_BUILD_BIT: AccelerationStructureFlagBits = 8
Prioritizes build performance over ray traversal performance when building the acceleration structure.

## ACCELERATION_STRUCTURE_LOW_MEMORY_BIT :: const RenderingDevice.ACCELERATION_STRUCTURE_LOW_MEMORY_BIT: AccelerationStructureFlagBits = 16
Reduces the memory usage of the acceleration structure, potentially at the cost of reduced ray traversal performance.

## ACCELERATION_STRUCTURE_GEOMETRY_OPAQUE_BIT :: const RenderingDevice.ACCELERATION_STRUCTURE_GEOMETRY_OPAQUE_BIT: AccelerationStructureGeometryFlagBits = 1
An opaque geometry does not invoke the any hit shaders.

## ACCELERATION_STRUCTURE_GEOMETRY_NO_DUPLICATE_ANY_HIT_INVOCATION_BIT :: const RenderingDevice.ACCELERATION_STRUCTURE_GEOMETRY_NO_DUPLICATE_ANY_HIT_INVOCATION_BIT: AccelerationStructureGeometryFlagBits = 2
This geometry only calls the any hit shader a single time for each primitive.

## ACCELERATION_STRUCTURE_INSTANCE_TRIANGLE_FACING_CULL_DISABLE_BIT :: const RenderingDevice.ACCELERATION_STRUCTURE_INSTANCE_TRIANGLE_FACING_CULL_DISABLE_BIT: AccelerationStructureInstanceFlagBits = 1
Disables triangle face culling for this instance during ray traversal.

## ACCELERATION_STRUCTURE_INSTANCE_TRIANGLE_FLIP_FACING_BIT :: const RenderingDevice.ACCELERATION_STRUCTURE_INSTANCE_TRIANGLE_FLIP_FACING_BIT: AccelerationStructureInstanceFlagBits = 2
Flips the triangle facing direction for this instance during ray traversal.

## ACCELERATION_STRUCTURE_INSTANCE_FORCE_OPAQUE_BIT :: const RenderingDevice.ACCELERATION_STRUCTURE_INSTANCE_FORCE_OPAQUE_BIT: AccelerationStructureInstanceFlagBits = 4
Forces all geometries in this instance to be treated as opaque, preventing any hit shaders from being invoked.

## ACCELERATION_STRUCTURE_INSTANCE_FORCE_NO_OPAQUE_BIT :: const RenderingDevice.ACCELERATION_STRUCTURE_INSTANCE_FORCE_NO_OPAQUE_BIT: AccelerationStructureInstanceFlagBits = 8
Forces all geometries in this instance to be treated as non-opaque, allowing any hit shaders to be invoked.

## UNIFORM_TYPE_SAMPLER :: const RenderingDevice.UNIFORM_TYPE_SAMPLER: UniformType = 0
Sampler uniform.

## UNIFORM_TYPE_SAMPLER_WITH_TEXTURE :: const RenderingDevice.UNIFORM_TYPE_SAMPLER_WITH_TEXTURE: UniformType = 1
Sampler uniform with a texture.

## UNIFORM_TYPE_TEXTURE :: const RenderingDevice.UNIFORM_TYPE_TEXTURE: UniformType = 2
Texture uniform.

## UNIFORM_TYPE_IMAGE :: const RenderingDevice.UNIFORM_TYPE_IMAGE: UniformType = 3
Image uniform.

## UNIFORM_TYPE_TEXTURE_BUFFER :: const RenderingDevice.UNIFORM_TYPE_TEXTURE_BUFFER: UniformType = 4
Texture buffer uniform.

## UNIFORM_TYPE_SAMPLER_WITH_TEXTURE_BUFFER :: const RenderingDevice.UNIFORM_TYPE_SAMPLER_WITH_TEXTURE_BUFFER: UniformType = 5
Sampler uniform with a texture buffer.

## UNIFORM_TYPE_IMAGE_BUFFER :: const RenderingDevice.UNIFORM_TYPE_IMAGE_BUFFER: UniformType = 6
Image buffer uniform.

## UNIFORM_TYPE_UNIFORM_BUFFER :: const RenderingDevice.UNIFORM_TYPE_UNIFORM_BUFFER: UniformType = 7
Uniform buffer uniform.

## UNIFORM_TYPE_STORAGE_BUFFER :: const RenderingDevice.UNIFORM_TYPE_STORAGE_BUFFER: UniformType = 8
[url=https://vkguide.dev/docs/chapter-4/storage_buffers/]Storage buffer[/url] uniform.

## UNIFORM_TYPE_INPUT_ATTACHMENT :: const RenderingDevice.UNIFORM_TYPE_INPUT_ATTACHMENT: UniformType = 9
Input attachment uniform.

## UNIFORM_TYPE_UNIFORM_BUFFER_DYNAMIC :: const RenderingDevice.UNIFORM_TYPE_UNIFORM_BUFFER_DYNAMIC: UniformType = 10
Same as UNIFORM_TYPE_UNIFORM_BUFFER but for buffers created with BUFFER_CREATION_DYNAMIC_PERSISTENT_BIT.
[b]Note:[/b] This flag is not available to GD users due to being too dangerous (i.e. wrong usage can result in visual glitches).
It's exposed in case GD users receive a buffer created with such flag from Godot.

## UNIFORM_TYPE_STORAGE_BUFFER_DYNAMIC :: const RenderingDevice.UNIFORM_TYPE_STORAGE_BUFFER_DYNAMIC: UniformType = 11
Same as UNIFORM_TYPE_STORAGE_BUFFER but for buffers created with BUFFER_CREATION_DYNAMIC_PERSISTENT_BIT.
[b]Note:[/b] This flag is not available to GD users due to being too dangerous (i.e. wrong usage can result in visual glitches).
It's exposed in case GD users receive a buffer created with such flag from Godot.

## UNIFORM_TYPE_ACCELERATION_STRUCTURE :: const RenderingDevice.UNIFORM_TYPE_ACCELERATION_STRUCTURE: UniformType = 12
Acceleration structure uniform.

## UNIFORM_TYPE_MAX :: const RenderingDevice.UNIFORM_TYPE_MAX: UniformType = 13
Represents the size of the [enum UniformType] enum.

## RENDER_PRIMITIVE_POINTS :: const RenderingDevice.RENDER_PRIMITIVE_POINTS: RenderPrimitive = 0
Point rendering primitive (with constant size, regardless of distance from camera).

## RENDER_PRIMITIVE_LINES :: const RenderingDevice.RENDER_PRIMITIVE_LINES: RenderPrimitive = 1
Line list rendering primitive. Lines are drawn separated from each other.

## RENDER_PRIMITIVE_LINES_WITH_ADJACENCY :: const RenderingDevice.RENDER_PRIMITIVE_LINES_WITH_ADJACENCY: RenderPrimitive = 2
[url=https://registry.khronos.org/vulkan/specs/1.3-extensions/html/vkspec.html#drawing-line-lists-with-adjacency]Line list rendering primitive with adjacency.[/url]
[b]Note:[/b] Adjacency is only useful with geometry shaders, which Godot does not expose.

## RENDER_PRIMITIVE_LINESTRIPS :: const RenderingDevice.RENDER_PRIMITIVE_LINESTRIPS: RenderPrimitive = 3
Line strip rendering primitive. Lines drawn are connected to the previous vertex.

## RENDER_PRIMITIVE_LINESTRIPS_WITH_ADJACENCY :: const RenderingDevice.RENDER_PRIMITIVE_LINESTRIPS_WITH_ADJACENCY: RenderPrimitive = 4
[url=https://registry.khronos.org/vulkan/specs/1.3-extensions/html/vkspec.html#drawing-line-strips-with-adjacency]Line strip rendering primitive with adjacency.[/url]
[b]Note:[/b] Adjacency is only useful with geometry shaders, which Godot does not expose.

## RENDER_PRIMITIVE_TRIANGLES :: const RenderingDevice.RENDER_PRIMITIVE_TRIANGLES: RenderPrimitive = 5
Triangle list rendering primitive. Triangles are drawn separated from each other.

## RENDER_PRIMITIVE_TRIANGLES_WITH_ADJACENCY :: const RenderingDevice.RENDER_PRIMITIVE_TRIANGLES_WITH_ADJACENCY: RenderPrimitive = 6
[url=https://registry.khronos.org/vulkan/specs/1.3-extensions/html/vkspec.html#drawing-triangle-lists-with-adjacency]Triangle list rendering primitive with adjacency.[/url]
[b]Note:[/b] Adjacency is only useful with geometry shaders, which Godot does not expose.

## RENDER_PRIMITIVE_TRIANGLE_STRIPS :: const RenderingDevice.RENDER_PRIMITIVE_TRIANGLE_STRIPS: RenderPrimitive = 7
Triangle strip rendering primitive. Triangles drawn are connected to the previous triangle.

## RENDER_PRIMITIVE_TRIANGLE_STRIPS_WITH_AJACENCY :: const RenderingDevice.RENDER_PRIMITIVE_TRIANGLE_STRIPS_WITH_AJACENCY: RenderPrimitive = 8
[url=https://registry.khronos.org/vulkan/specs/1.3-extensions/html/vkspec.html#drawing-triangle-strips-with-adjacency]Triangle strip rendering primitive with adjacency.[/url]
[b]Note:[/b] Adjacency is only useful with geometry shaders, which Godot does not expose.

## RENDER_PRIMITIVE_TRIANGLE_STRIPS_WITH_RESTART_INDEX :: const RenderingDevice.RENDER_PRIMITIVE_TRIANGLE_STRIPS_WITH_RESTART_INDEX: RenderPrimitive = 9
Triangle strip rendering primitive with [i]primitive restart[/i] enabled. Triangles drawn are connected to the previous triangle, but a primitive restart index can be specified before drawing to create a second triangle strip after the specified index.
[b]Note:[/b] Only compatible with indexed draws.

## RENDER_PRIMITIVE_TESSELATION_PATCH :: const RenderingDevice.RENDER_PRIMITIVE_TESSELATION_PATCH: RenderPrimitive = 10
Tessellation patch rendering primitive. Only useful with tessellation shaders, which can be used to deform these patches.

## RENDER_PRIMITIVE_MAX :: const RenderingDevice.RENDER_PRIMITIVE_MAX: RenderPrimitive = 11
Represents the size of the [enum RenderPrimitive] enum.

## POLYGON_CULL_DISABLED :: const RenderingDevice.POLYGON_CULL_DISABLED: PolygonCullMode = 0
Do not use polygon front face or backface culling.

## POLYGON_CULL_FRONT :: const RenderingDevice.POLYGON_CULL_FRONT: PolygonCullMode = 1
Use polygon frontface culling (faces pointing towards the camera are hidden).

## POLYGON_CULL_BACK :: const RenderingDevice.POLYGON_CULL_BACK: PolygonCullMode = 2
Use polygon backface culling (faces pointing away from the camera are hidden).

## POLYGON_FRONT_FACE_CLOCKWISE :: const RenderingDevice.POLYGON_FRONT_FACE_CLOCKWISE: PolygonFrontFace = 0
Clockwise winding order to determine which face of a polygon is its front face.

## POLYGON_FRONT_FACE_COUNTER_CLOCKWISE :: const RenderingDevice.POLYGON_FRONT_FACE_COUNTER_CLOCKWISE: PolygonFrontFace = 1
Counter-clockwise winding order to determine which face of a polygon is its front face.

## STENCIL_OP_KEEP :: const RenderingDevice.STENCIL_OP_KEEP: StencilOperation = 0
Keep the current stencil value.

## STENCIL_OP_ZERO :: const RenderingDevice.STENCIL_OP_ZERO: StencilOperation = 1
Set the stencil value to [code]0[/code].

## STENCIL_OP_REPLACE :: const RenderingDevice.STENCIL_OP_REPLACE: StencilOperation = 2
Replace the existing stencil value with the new one.

## STENCIL_OP_INCREMENT_AND_CLAMP :: const RenderingDevice.STENCIL_OP_INCREMENT_AND_CLAMP: StencilOperation = 3
Increment the existing stencil value and clamp to the maximum representable unsigned value if reached. Stencil bits are considered as an unsigned integer.

## STENCIL_OP_DECREMENT_AND_CLAMP :: const RenderingDevice.STENCIL_OP_DECREMENT_AND_CLAMP: StencilOperation = 4
Decrement the existing stencil value and clamp to the minimum value if reached. Stencil bits are considered as an unsigned integer.

## STENCIL_OP_INVERT :: const RenderingDevice.STENCIL_OP_INVERT: StencilOperation = 5
Bitwise-invert the existing stencil value.

## STENCIL_OP_INCREMENT_AND_WRAP :: const RenderingDevice.STENCIL_OP_INCREMENT_AND_WRAP: StencilOperation = 6
Increment the stencil value and wrap around to [code]0[/code] if reaching the maximum representable unsigned. Stencil bits are considered as an unsigned integer.

## STENCIL_OP_DECREMENT_AND_WRAP :: const RenderingDevice.STENCIL_OP_DECREMENT_AND_WRAP: StencilOperation = 7
Decrement the stencil value and wrap around to the maximum representable unsigned if reaching the minimum. Stencil bits are considered as an unsigned integer.

## STENCIL_OP_MAX :: const RenderingDevice.STENCIL_OP_MAX: StencilOperation = 8
Represents the size of the [enum StencilOperation] enum.

## COMPARE_OP_NEVER :: const RenderingDevice.COMPARE_OP_NEVER: CompareOperator = 0
"Never" comparison (opposite of [constant COMPARE_OP_ALWAYS]).

## COMPARE_OP_LESS :: const RenderingDevice.COMPARE_OP_LESS: CompareOperator = 1
"Less than" comparison.

## COMPARE_OP_EQUAL :: const RenderingDevice.COMPARE_OP_EQUAL: CompareOperator = 2
"Equal" comparison.

## COMPARE_OP_LESS_OR_EQUAL :: const RenderingDevice.COMPARE_OP_LESS_OR_EQUAL: CompareOperator = 3
"Less than or equal" comparison.

## COMPARE_OP_GREATER :: const RenderingDevice.COMPARE_OP_GREATER: CompareOperator = 4
"Greater than" comparison.

## COMPARE_OP_NOT_EQUAL :: const RenderingDevice.COMPARE_OP_NOT_EQUAL: CompareOperator = 5
"Not equal" comparison.

## COMPARE_OP_GREATER_OR_EQUAL :: const RenderingDevice.COMPARE_OP_GREATER_OR_EQUAL: CompareOperator = 6
"Greater than or equal" comparison.

## COMPARE_OP_ALWAYS :: const RenderingDevice.COMPARE_OP_ALWAYS: CompareOperator = 7
"Always" comparison (opposite of [constant COMPARE_OP_NEVER]).

## COMPARE_OP_MAX :: const RenderingDevice.COMPARE_OP_MAX: CompareOperator = 8
Represents the size of the [enum CompareOperator] enum.

## LOGIC_OP_CLEAR :: const RenderingDevice.LOGIC_OP_CLEAR: LogicOperation = 0
Clear logic operation (result is always [code]0[/code]). See also [constant LOGIC_OP_SET].

## LOGIC_OP_AND :: const RenderingDevice.LOGIC_OP_AND: LogicOperation = 1
AND logic operation.

## LOGIC_OP_AND_REVERSE :: const RenderingDevice.LOGIC_OP_AND_REVERSE: LogicOperation = 2
AND logic operation with the [i]destination[/i] operand being inverted. See also [constant LOGIC_OP_AND_INVERTED].

## LOGIC_OP_COPY :: const RenderingDevice.LOGIC_OP_COPY: LogicOperation = 3
Copy logic operation (keeps the [i]source[/i] value as-is). See also [constant LOGIC_OP_COPY_INVERTED] and [constant LOGIC_OP_NO_OP].

## LOGIC_OP_AND_INVERTED :: const RenderingDevice.LOGIC_OP_AND_INVERTED: LogicOperation = 4
AND logic operation with the [i]source[/i] operand being inverted. See also [constant LOGIC_OP_AND_REVERSE].

## LOGIC_OP_NO_OP :: const RenderingDevice.LOGIC_OP_NO_OP: LogicOperation = 5
No-op logic operation (keeps the [i]destination[/i] value as-is). See also [constant LOGIC_OP_COPY].

## LOGIC_OP_XOR :: const RenderingDevice.LOGIC_OP_XOR: LogicOperation = 6
Exclusive or (XOR) logic operation.

## LOGIC_OP_OR :: const RenderingDevice.LOGIC_OP_OR: LogicOperation = 7
OR logic operation.

## LOGIC_OP_NOR :: const RenderingDevice.LOGIC_OP_NOR: LogicOperation = 8
Not-OR (NOR) logic operation.

## LOGIC_OP_EQUIVALENT :: const RenderingDevice.LOGIC_OP_EQUIVALENT: LogicOperation = 9
Not-XOR (XNOR) logic operation.

## LOGIC_OP_INVERT :: const RenderingDevice.LOGIC_OP_INVERT: LogicOperation = 10
Invert logic operation.

## LOGIC_OP_OR_REVERSE :: const RenderingDevice.LOGIC_OP_OR_REVERSE: LogicOperation = 11
OR logic operation with the [i]destination[/i] operand being inverted. See also [constant LOGIC_OP_OR_REVERSE].

## LOGIC_OP_COPY_INVERTED :: const RenderingDevice.LOGIC_OP_COPY_INVERTED: LogicOperation = 12
NOT logic operation (inverts the value). See also [constant LOGIC_OP_COPY].

## LOGIC_OP_OR_INVERTED :: const RenderingDevice.LOGIC_OP_OR_INVERTED: LogicOperation = 13
OR logic operation with the [i]source[/i] operand being inverted. See also [constant LOGIC_OP_OR_REVERSE].

## LOGIC_OP_NAND :: const RenderingDevice.LOGIC_OP_NAND: LogicOperation = 14
Not-AND (NAND) logic operation.

## LOGIC_OP_SET :: const RenderingDevice.LOGIC_OP_SET: LogicOperation = 15
SET logic operation (result is always [code]1[/code]). See also [constant LOGIC_OP_CLEAR].

## LOGIC_OP_MAX :: const RenderingDevice.LOGIC_OP_MAX: LogicOperation = 16
Represents the size of the [enum LogicOperation] enum.

## BLEND_FACTOR_ZERO :: const RenderingDevice.BLEND_FACTOR_ZERO: BlendFactor = 0
Constant [code]0.0[/code] blend factor.

## BLEND_FACTOR_ONE :: const RenderingDevice.BLEND_FACTOR_ONE: BlendFactor = 1
Constant [code]1.0[/code] blend factor.

## BLEND_FACTOR_SRC_COLOR :: const RenderingDevice.BLEND_FACTOR_SRC_COLOR: BlendFactor = 2
Color blend factor is [code]source color[/code]. Alpha blend factor is [code]source alpha[/code].

## BLEND_FACTOR_ONE_MINUS_SRC_COLOR :: const RenderingDevice.BLEND_FACTOR_ONE_MINUS_SRC_COLOR: BlendFactor = 3
Color blend factor is [code]1.0 - source color[/code]. Alpha blend factor is [code]1.0 - source alpha[/code].

## BLEND_FACTOR_DST_COLOR :: const RenderingDevice.BLEND_FACTOR_DST_COLOR: BlendFactor = 4
Color blend factor is [code]destination color[/code]. Alpha blend factor is [code]destination alpha[/code].

## BLEND_FACTOR_ONE_MINUS_DST_COLOR :: const RenderingDevice.BLEND_FACTOR_ONE_MINUS_DST_COLOR: BlendFactor = 5
Color blend factor is [code]1.0 - destination color[/code]. Alpha blend factor is [code]1.0 - destination alpha[/code].

## BLEND_FACTOR_SRC_ALPHA :: const RenderingDevice.BLEND_FACTOR_SRC_ALPHA: BlendFactor = 6
Color and alpha blend factor is [code]source alpha[/code].

## BLEND_FACTOR_ONE_MINUS_SRC_ALPHA :: const RenderingDevice.BLEND_FACTOR_ONE_MINUS_SRC_ALPHA: BlendFactor = 7
Color and alpha blend factor is [code]1.0 - source alpha[/code].

## BLEND_FACTOR_DST_ALPHA :: const RenderingDevice.BLEND_FACTOR_DST_ALPHA: BlendFactor = 8
Color and alpha blend factor is [code]destination alpha[/code].

## BLEND_FACTOR_ONE_MINUS_DST_ALPHA :: const RenderingDevice.BLEND_FACTOR_ONE_MINUS_DST_ALPHA: BlendFactor = 9
Color and alpha blend factor is [code]1.0 - destination alpha[/code].

## BLEND_FACTOR_CONSTANT_COLOR :: const RenderingDevice.BLEND_FACTOR_CONSTANT_COLOR: BlendFactor = 10
Color blend factor is [code]blend constant color[/code]. Alpha blend factor is [code]blend constant alpha[/code] (see [method draw_list_set_blend_constants]).

## BLEND_FACTOR_ONE_MINUS_CONSTANT_COLOR :: const RenderingDevice.BLEND_FACTOR_ONE_MINUS_CONSTANT_COLOR: BlendFactor = 11
Color blend factor is [code]1.0 - blend constant color[/code]. Alpha blend factor is [code]1.0 - blend constant alpha[/code] (see [method draw_list_set_blend_constants]).

## BLEND_FACTOR_CONSTANT_ALPHA :: const RenderingDevice.BLEND_FACTOR_CONSTANT_ALPHA: BlendFactor = 12
Color and alpha blend factor is [code]blend constant alpha[/code] (see [method draw_list_set_blend_constants]).

## BLEND_FACTOR_ONE_MINUS_CONSTANT_ALPHA :: const RenderingDevice.BLEND_FACTOR_ONE_MINUS_CONSTANT_ALPHA: BlendFactor = 13
Color and alpha blend factor is [code]1.0 - blend constant alpha[/code] (see [method draw_list_set_blend_constants]).

## BLEND_FACTOR_SRC_ALPHA_SATURATE :: const RenderingDevice.BLEND_FACTOR_SRC_ALPHA_SATURATE: BlendFactor = 14
Color blend factor is [code]min(source alpha, 1.0 - destination alpha)[/code]. Alpha blend factor is [code]1.0[/code].

## BLEND_FACTOR_SRC1_COLOR :: const RenderingDevice.BLEND_FACTOR_SRC1_COLOR: BlendFactor = 15
Color blend factor is [code]second source color[/code]. Alpha blend factor is [code]second source alpha[/code]. Only relevant for dual-source blending.

## BLEND_FACTOR_ONE_MINUS_SRC1_COLOR :: const RenderingDevice.BLEND_FACTOR_ONE_MINUS_SRC1_COLOR: BlendFactor = 16
Color blend factor is [code]1.0 - second source color[/code]. Alpha blend factor is [code]1.0 - second source alpha[/code]. Only relevant for dual-source blending.

## BLEND_FACTOR_SRC1_ALPHA :: const RenderingDevice.BLEND_FACTOR_SRC1_ALPHA: BlendFactor = 17
Color and alpha blend factor is [code]second source alpha[/code]. Only relevant for dual-source blending.

## BLEND_FACTOR_ONE_MINUS_SRC1_ALPHA :: const RenderingDevice.BLEND_FACTOR_ONE_MINUS_SRC1_ALPHA: BlendFactor = 18
Color and alpha blend factor is [code]1.0 - second source alpha[/code]. Only relevant for dual-source blending.

## BLEND_FACTOR_MAX :: const RenderingDevice.BLEND_FACTOR_MAX: BlendFactor = 19
Represents the size of the [enum BlendFactor] enum.

## BLEND_OP_ADD :: const RenderingDevice.BLEND_OP_ADD: BlendOperation = 0
Additive blending operation ([code]source + destination[/code]).

## BLEND_OP_SUBTRACT :: const RenderingDevice.BLEND_OP_SUBTRACT: BlendOperation = 1
Subtractive blending operation ([code]source - destination[/code]).

## BLEND_OP_REVERSE_SUBTRACT :: const RenderingDevice.BLEND_OP_REVERSE_SUBTRACT: BlendOperation = 2
Reverse subtractive blending operation ([code]destination - source[/code]).

## BLEND_OP_MINIMUM :: const RenderingDevice.BLEND_OP_MINIMUM: BlendOperation = 3
Minimum blending operation (keep the lowest value of the two).

## BLEND_OP_MAXIMUM :: const RenderingDevice.BLEND_OP_MAXIMUM: BlendOperation = 4
Maximum blending operation (keep the highest value of the two).

## BLEND_OP_MAX :: const RenderingDevice.BLEND_OP_MAX: BlendOperation = 5
Represents the size of the [enum BlendOperation] enum.

## DYNAMIC_STATE_LINE_WIDTH :: const RenderingDevice.DYNAMIC_STATE_LINE_WIDTH: PipelineDynamicStateFlags = 1
Allows dynamically changing the width of rendering lines.

## DYNAMIC_STATE_DEPTH_BIAS :: const RenderingDevice.DYNAMIC_STATE_DEPTH_BIAS: PipelineDynamicStateFlags = 2
Allows dynamically changing the depth bias.

## DYNAMIC_STATE_BLEND_CONSTANTS :: const RenderingDevice.DYNAMIC_STATE_BLEND_CONSTANTS: PipelineDynamicStateFlags = 4

## DYNAMIC_STATE_DEPTH_BOUNDS :: const RenderingDevice.DYNAMIC_STATE_DEPTH_BOUNDS: PipelineDynamicStateFlags = 8

## DYNAMIC_STATE_STENCIL_COMPARE_MASK :: const RenderingDevice.DYNAMIC_STATE_STENCIL_COMPARE_MASK: PipelineDynamicStateFlags = 16

## DYNAMIC_STATE_STENCIL_WRITE_MASK :: const RenderingDevice.DYNAMIC_STATE_STENCIL_WRITE_MASK: PipelineDynamicStateFlags = 32

## DYNAMIC_STATE_STENCIL_REFERENCE :: const RenderingDevice.DYNAMIC_STATE_STENCIL_REFERENCE: PipelineDynamicStateFlags = 64

## INITIAL_ACTION_LOAD :: const RenderingDevice.INITIAL_ACTION_LOAD: InitialAction = 0
Load the previous contents of the framebuffer.

## INITIAL_ACTION_CLEAR :: const RenderingDevice.INITIAL_ACTION_CLEAR: InitialAction = 1
Clear the whole framebuffer or its specified region.

## INITIAL_ACTION_DISCARD :: const RenderingDevice.INITIAL_ACTION_DISCARD: InitialAction = 2
Ignore the previous contents of the framebuffer. This is the fastest option if you'll overwrite all of the pixels and don't need to read any of them.

## INITIAL_ACTION_MAX :: const RenderingDevice.INITIAL_ACTION_MAX: InitialAction = 3
Represents the size of the [enum InitialAction] enum.

## INITIAL_ACTION_CLEAR_REGION :: const RenderingDevice.INITIAL_ACTION_CLEAR_REGION: InitialAction = 1

## INITIAL_ACTION_CLEAR_REGION_CONTINUE :: const RenderingDevice.INITIAL_ACTION_CLEAR_REGION_CONTINUE: InitialAction = 1

## INITIAL_ACTION_KEEP :: const RenderingDevice.INITIAL_ACTION_KEEP: InitialAction = 0

## INITIAL_ACTION_DROP :: const RenderingDevice.INITIAL_ACTION_DROP: InitialAction = 2

## INITIAL_ACTION_CONTINUE :: const RenderingDevice.INITIAL_ACTION_CONTINUE: InitialAction = 0

## FINAL_ACTION_STORE :: const RenderingDevice.FINAL_ACTION_STORE: FinalAction = 0
Store the result of the draw list in the framebuffer. This is generally what you want to do.

## FINAL_ACTION_DISCARD :: const RenderingDevice.FINAL_ACTION_DISCARD: FinalAction = 1
Discard the contents of the framebuffer. This is the fastest option if you don't need to use the results of the draw list.

## FINAL_ACTION_MAX :: const RenderingDevice.FINAL_ACTION_MAX: FinalAction = 2
Represents the size of the [enum FinalAction] enum.

## FINAL_ACTION_READ :: const RenderingDevice.FINAL_ACTION_READ: FinalAction = 0

## FINAL_ACTION_CONTINUE :: const RenderingDevice.FINAL_ACTION_CONTINUE: FinalAction = 0

## SHADER_STAGE_VERTEX :: const RenderingDevice.SHADER_STAGE_VERTEX: ShaderStage = 0
Vertex shader stage. This can be used to manipulate vertices from a shader (but not create new vertices).

## SHADER_STAGE_FRAGMENT :: const RenderingDevice.SHADER_STAGE_FRAGMENT: ShaderStage = 1
Fragment shader stage (called "pixel shader" in Direct3D). This can be used to manipulate pixels from a shader.

## SHADER_STAGE_TESSELATION_CONTROL :: const RenderingDevice.SHADER_STAGE_TESSELATION_CONTROL: ShaderStage = 2
Tessellation control shader stage. This can be used to create additional geometry from a shader.

## SHADER_STAGE_TESSELATION_EVALUATION :: const RenderingDevice.SHADER_STAGE_TESSELATION_EVALUATION: ShaderStage = 3
Tessellation evaluation shader stage. This can be used to create additional geometry from a shader.

## SHADER_STAGE_COMPUTE :: const RenderingDevice.SHADER_STAGE_COMPUTE: ShaderStage = 4
Compute shader stage. This can be used to run arbitrary computing tasks in a shader, performing them on the GPU instead of the CPU.

## SHADER_STAGE_RAYGEN :: const RenderingDevice.SHADER_STAGE_RAYGEN: ShaderStage = 5
Ray generation shader stage. This can be used to generate primary rays.

## SHADER_STAGE_ANY_HIT :: const RenderingDevice.SHADER_STAGE_ANY_HIT: ShaderStage = 6
Any hit shader stage. Invoked when ray intersections are not opaque. This can be used to specify what happens when a ray hits any of the geometry in the scene.

## SHADER_STAGE_CLOSEST_HIT :: const RenderingDevice.SHADER_STAGE_CLOSEST_HIT: ShaderStage = 7
Closest hit shader stage. This can be used to specify what happens when a ray hits the closest geometry in the scene.

## SHADER_STAGE_MISS :: const RenderingDevice.SHADER_STAGE_MISS: ShaderStage = 8
Miss shader stage. This can be used to specify what happens if a ray does not hit anything in the scene.

## SHADER_STAGE_INTERSECTION :: const RenderingDevice.SHADER_STAGE_INTERSECTION: ShaderStage = 9
Intersection shader stage. The intersection shader for triangles is built-in. This can be used to compute ray intersections with primitives that are not triangles.

## SHADER_STAGE_MAX :: const RenderingDevice.SHADER_STAGE_MAX: ShaderStage = 10
Represents the size of the [enum ShaderStage] enum.

## SHADER_STAGE_VERTEX_BIT :: const RenderingDevice.SHADER_STAGE_VERTEX_BIT: ShaderStage = 1
Vertex shader stage bit (see also [constant SHADER_STAGE_VERTEX]).

## SHADER_STAGE_FRAGMENT_BIT :: const RenderingDevice.SHADER_STAGE_FRAGMENT_BIT: ShaderStage = 2
Fragment shader stage bit (see also [constant SHADER_STAGE_FRAGMENT]).

## SHADER_STAGE_TESSELATION_CONTROL_BIT :: const RenderingDevice.SHADER_STAGE_TESSELATION_CONTROL_BIT: ShaderStage = 4
Tessellation control shader stage bit (see also [constant SHADER_STAGE_TESSELATION_CONTROL]).

## SHADER_STAGE_TESSELATION_EVALUATION_BIT :: const RenderingDevice.SHADER_STAGE_TESSELATION_EVALUATION_BIT: ShaderStage = 8
Tessellation evaluation shader stage bit (see also [constant SHADER_STAGE_TESSELATION_EVALUATION]).

## SHADER_STAGE_COMPUTE_BIT :: const RenderingDevice.SHADER_STAGE_COMPUTE_BIT: ShaderStage = 16
Compute shader stage bit (see also [constant SHADER_STAGE_COMPUTE]).

## SHADER_STAGE_RAYGEN_BIT :: const RenderingDevice.SHADER_STAGE_RAYGEN_BIT: ShaderStage = 32
Ray generation shader stage bit (see also [constant SHADER_STAGE_RAYGEN]).

## SHADER_STAGE_ANY_HIT_BIT :: const RenderingDevice.SHADER_STAGE_ANY_HIT_BIT: ShaderStage = 64
Any hit shader stage bit (see also [constant SHADER_STAGE_ANY_HIT]).

## SHADER_STAGE_CLOSEST_HIT_BIT :: const RenderingDevice.SHADER_STAGE_CLOSEST_HIT_BIT: ShaderStage = 128
Closest hit shader stage bit (see also [constant SHADER_STAGE_CLOSEST_HIT]).

## SHADER_STAGE_MISS_BIT :: const RenderingDevice.SHADER_STAGE_MISS_BIT: ShaderStage = 256
Miss shader stage bit (see also [constant SHADER_STAGE_MISS]).

## SHADER_STAGE_INTERSECTION_BIT :: const RenderingDevice.SHADER_STAGE_INTERSECTION_BIT: ShaderStage = 512
Intersection shader stage bit (see also [constant SHADER_STAGE_INTERSECTION]).

## SHADER_LANGUAGE_GLSL :: const RenderingDevice.SHADER_LANGUAGE_GLSL: ShaderLanguage = 0
Khronos' GLSL shading language (used natively by OpenGL and Vulkan). This is the language used for core Godot shaders.

## SHADER_LANGUAGE_HLSL :: const RenderingDevice.SHADER_LANGUAGE_HLSL: ShaderLanguage = 1
Microsoft's High-Level Shading Language (used natively by Direct3D, but can also be used in Vulkan).

## PIPELINE_SPECIALIZATION_CONSTANT_TYPE_BOOL :: const RenderingDevice.PIPELINE_SPECIALIZATION_CONSTANT_TYPE_BOOL: PipelineSpecializationConstantType = 0
Boolean specialization constant.

## PIPELINE_SPECIALIZATION_CONSTANT_TYPE_INT :: const RenderingDevice.PIPELINE_SPECIALIZATION_CONSTANT_TYPE_INT: PipelineSpecializationConstantType = 1
Integer specialization constant.

## PIPELINE_SPECIALIZATION_CONSTANT_TYPE_FLOAT :: const RenderingDevice.PIPELINE_SPECIALIZATION_CONSTANT_TYPE_FLOAT: PipelineSpecializationConstantType = 2
Floating-point specialization constant.

## SUPPORTS_METALFX_SPATIAL :: const RenderingDevice.SUPPORTS_METALFX_SPATIAL: Features = 3
Support for MetalFX spatial upscaling.

## SUPPORTS_METALFX_TEMPORAL :: const RenderingDevice.SUPPORTS_METALFX_TEMPORAL: Features = 4
Support for MetalFX temporal upscaling.

## SUPPORTS_BUFFER_DEVICE_ADDRESS :: const RenderingDevice.SUPPORTS_BUFFER_DEVICE_ADDRESS: Features = 6
Features support for buffer device address extension.

## SUPPORTS_IMAGE_ATOMIC_32_BIT :: const RenderingDevice.SUPPORTS_IMAGE_ATOMIC_32_BIT: Features = 7
Support for 32-bit image atomic operations.

## SUPPORTS_RAY_QUERY :: const RenderingDevice.SUPPORTS_RAY_QUERY: Features = 11
Support for ray query extension.

[b]Note:[/b] This is currently only supported when using Vulkan. This is not supported on macOS and iOS (even on hardware supporting raytracing) due to MoltenVK limitations.

## SUPPORTS_RAYTRACING_PIPELINE :: const RenderingDevice.SUPPORTS_RAYTRACING_PIPELINE: Features = 12
Support for raytracing pipeline extension.

[b]Note:[/b] This is currently only supported when using Vulkan. This is not supported on macOS and iOS (even on hardware supporting raytracing) due to MoltenVK limitations.

## SUPPORTS_HDR_OUTPUT :: const RenderingDevice.SUPPORTS_HDR_OUTPUT: Features = 13
Support for high dynamic range (HDR) output.

## LIMIT_MAX_BOUND_UNIFORM_SETS :: const RenderingDevice.LIMIT_MAX_BOUND_UNIFORM_SETS: Limit = 0
Maximum number of uniform sets that can be bound at a given time.

## LIMIT_MAX_FRAMEBUFFER_COLOR_ATTACHMENTS :: const RenderingDevice.LIMIT_MAX_FRAMEBUFFER_COLOR_ATTACHMENTS: Limit = 1
Maximum number of color framebuffer attachments that can be used at a given time.

## LIMIT_MAX_TEXTURES_PER_UNIFORM_SET :: const RenderingDevice.LIMIT_MAX_TEXTURES_PER_UNIFORM_SET: Limit = 2
Maximum number of textures that can be used per uniform set.

## LIMIT_MAX_SAMPLERS_PER_UNIFORM_SET :: const RenderingDevice.LIMIT_MAX_SAMPLERS_PER_UNIFORM_SET: Limit = 3
Maximum number of samplers that can be used per uniform set.

## LIMIT_MAX_STORAGE_BUFFERS_PER_UNIFORM_SET :: const RenderingDevice.LIMIT_MAX_STORAGE_BUFFERS_PER_UNIFORM_SET: Limit = 4
Maximum number of [url=https://vkguide.dev/docs/chapter-4/storage_buffers/]storage buffers[/url] per uniform set.

## LIMIT_MAX_STORAGE_IMAGES_PER_UNIFORM_SET :: const RenderingDevice.LIMIT_MAX_STORAGE_IMAGES_PER_UNIFORM_SET: Limit = 5
Maximum number of storage images per uniform set.

## LIMIT_MAX_UNIFORM_BUFFERS_PER_UNIFORM_SET :: const RenderingDevice.LIMIT_MAX_UNIFORM_BUFFERS_PER_UNIFORM_SET: Limit = 6
Maximum number of uniform buffers per uniform set.

## LIMIT_MAX_DRAW_INDEXED_INDEX :: const RenderingDevice.LIMIT_MAX_DRAW_INDEXED_INDEX: Limit = 7
Maximum index for an indexed draw command.

## LIMIT_MAX_FRAMEBUFFER_HEIGHT :: const RenderingDevice.LIMIT_MAX_FRAMEBUFFER_HEIGHT: Limit = 8
Maximum height of a framebuffer (in pixels).

## LIMIT_MAX_FRAMEBUFFER_WIDTH :: const RenderingDevice.LIMIT_MAX_FRAMEBUFFER_WIDTH: Limit = 9
Maximum width of a framebuffer (in pixels).

## LIMIT_MAX_TEXTURE_ARRAY_LAYERS :: const RenderingDevice.LIMIT_MAX_TEXTURE_ARRAY_LAYERS: Limit = 10
Maximum number of texture array layers.

## LIMIT_MAX_TEXTURE_SIZE_1D :: const RenderingDevice.LIMIT_MAX_TEXTURE_SIZE_1D: Limit = 11
Maximum supported 1-dimensional texture size (in pixels on a single axis).

## LIMIT_MAX_TEXTURE_SIZE_2D :: const RenderingDevice.LIMIT_MAX_TEXTURE_SIZE_2D: Limit = 12
Maximum supported 2-dimensional texture size (in pixels on a single axis).

## LIMIT_MAX_TEXTURE_SIZE_3D :: const RenderingDevice.LIMIT_MAX_TEXTURE_SIZE_3D: Limit = 13
Maximum supported 3-dimensional texture size (in pixels on a single axis).

## LIMIT_MAX_TEXTURE_SIZE_CUBE :: const RenderingDevice.LIMIT_MAX_TEXTURE_SIZE_CUBE: Limit = 14
Maximum supported cubemap texture size (in pixels on a single axis of a single face).

## LIMIT_MAX_TEXTURES_PER_SHADER_STAGE :: const RenderingDevice.LIMIT_MAX_TEXTURES_PER_SHADER_STAGE: Limit = 15
Maximum number of textures per shader stage.

## LIMIT_MAX_SAMPLERS_PER_SHADER_STAGE :: const RenderingDevice.LIMIT_MAX_SAMPLERS_PER_SHADER_STAGE: Limit = 16
Maximum number of samplers per shader stage.

## LIMIT_MAX_STORAGE_BUFFERS_PER_SHADER_STAGE :: const RenderingDevice.LIMIT_MAX_STORAGE_BUFFERS_PER_SHADER_STAGE: Limit = 17
Maximum number of [url=https://vkguide.dev/docs/chapter-4/storage_buffers/]storage buffers[/url] per shader stage.

## LIMIT_MAX_STORAGE_IMAGES_PER_SHADER_STAGE :: const RenderingDevice.LIMIT_MAX_STORAGE_IMAGES_PER_SHADER_STAGE: Limit = 18
Maximum number of storage images per shader stage.

## LIMIT_MAX_UNIFORM_BUFFERS_PER_SHADER_STAGE :: const RenderingDevice.LIMIT_MAX_UNIFORM_BUFFERS_PER_SHADER_STAGE: Limit = 19
Maximum number of uniform buffers per uniform set.

## LIMIT_MAX_PUSH_CONSTANT_SIZE :: const RenderingDevice.LIMIT_MAX_PUSH_CONSTANT_SIZE: Limit = 20
Maximum size of a push constant. A lot of devices are limited to 128 bytes, so try to avoid exceeding 128 bytes in push constants to ensure compatibility even if your GPU is reporting a higher value.

## LIMIT_MAX_UNIFORM_BUFFER_SIZE :: const RenderingDevice.LIMIT_MAX_UNIFORM_BUFFER_SIZE: Limit = 21
Maximum size of a uniform buffer.

## LIMIT_MAX_VERTEX_INPUT_ATTRIBUTE_OFFSET :: const RenderingDevice.LIMIT_MAX_VERTEX_INPUT_ATTRIBUTE_OFFSET: Limit = 22
Maximum vertex input attribute offset.

## LIMIT_MAX_VERTEX_INPUT_ATTRIBUTES :: const RenderingDevice.LIMIT_MAX_VERTEX_INPUT_ATTRIBUTES: Limit = 23
Maximum number of vertex input attributes.

## LIMIT_MAX_VERTEX_INPUT_BINDINGS :: const RenderingDevice.LIMIT_MAX_VERTEX_INPUT_BINDINGS: Limit = 24
Maximum number of vertex input bindings.

## LIMIT_MAX_VERTEX_INPUT_BINDING_STRIDE :: const RenderingDevice.LIMIT_MAX_VERTEX_INPUT_BINDING_STRIDE: Limit = 25
Maximum vertex input binding stride.

## LIMIT_MIN_UNIFORM_BUFFER_OFFSET_ALIGNMENT :: const RenderingDevice.LIMIT_MIN_UNIFORM_BUFFER_OFFSET_ALIGNMENT: Limit = 26
Minimum uniform buffer offset alignment.

## LIMIT_MAX_COMPUTE_SHARED_MEMORY_SIZE :: const RenderingDevice.LIMIT_MAX_COMPUTE_SHARED_MEMORY_SIZE: Limit = 27
Maximum shared memory size for compute shaders.

## LIMIT_MAX_COMPUTE_WORKGROUP_COUNT_X :: const RenderingDevice.LIMIT_MAX_COMPUTE_WORKGROUP_COUNT_X: Limit = 28
Maximum number of workgroups for compute shaders on the X axis.

## LIMIT_MAX_COMPUTE_WORKGROUP_COUNT_Y :: const RenderingDevice.LIMIT_MAX_COMPUTE_WORKGROUP_COUNT_Y: Limit = 29
Maximum number of workgroups for compute shaders on the Y axis.

## LIMIT_MAX_COMPUTE_WORKGROUP_COUNT_Z :: const RenderingDevice.LIMIT_MAX_COMPUTE_WORKGROUP_COUNT_Z: Limit = 30
Maximum number of workgroups for compute shaders on the Z axis.

## LIMIT_MAX_COMPUTE_WORKGROUP_INVOCATIONS :: const RenderingDevice.LIMIT_MAX_COMPUTE_WORKGROUP_INVOCATIONS: Limit = 31
Maximum number of workgroup invocations for compute shaders.

## LIMIT_MAX_COMPUTE_WORKGROUP_SIZE_X :: const RenderingDevice.LIMIT_MAX_COMPUTE_WORKGROUP_SIZE_X: Limit = 32
Maximum workgroup size for compute shaders on the X axis.

## LIMIT_MAX_COMPUTE_WORKGROUP_SIZE_Y :: const RenderingDevice.LIMIT_MAX_COMPUTE_WORKGROUP_SIZE_Y: Limit = 33
Maximum workgroup size for compute shaders on the Y axis.

## LIMIT_MAX_COMPUTE_WORKGROUP_SIZE_Z :: const RenderingDevice.LIMIT_MAX_COMPUTE_WORKGROUP_SIZE_Z: Limit = 34
Maximum workgroup size for compute shaders on the Z axis.

## LIMIT_MAX_VIEWPORT_DIMENSIONS_X :: const RenderingDevice.LIMIT_MAX_VIEWPORT_DIMENSIONS_X: Limit = 35
Maximum viewport width (in pixels).

## LIMIT_MAX_VIEWPORT_DIMENSIONS_Y :: const RenderingDevice.LIMIT_MAX_VIEWPORT_DIMENSIONS_Y: Limit = 36
Maximum viewport height (in pixels).

## LIMIT_METALFX_TEMPORAL_SCALER_MIN_SCALE :: const RenderingDevice.LIMIT_METALFX_TEMPORAL_SCALER_MIN_SCALE: Limit = 46
Returns the smallest value for [member ProjectSettings.rendering/scaling_3d/scale] when using the MetalFX temporal upscaler.
[b]Note:[/b] The returned value is multiplied by a factor of [code]1000000[/code] to preserve 6 digits of precision. It must be divided by [code]1000000.0[/code] to convert the value to a floating point number.

## LIMIT_METALFX_TEMPORAL_SCALER_MAX_SCALE :: const RenderingDevice.LIMIT_METALFX_TEMPORAL_SCALER_MAX_SCALE: Limit = 47
Returns the largest value for [member ProjectSettings.rendering/scaling_3d/scale] when using the MetalFX temporal upscaler.
[b]Note:[/b] The returned value is multiplied by a factor of [code]1000000[/code] to preserve 6 digits of precision. It must be divided by [code]1000000.0[/code] to convert the value to a floating point number.

## MEMORY_TEXTURES :: const RenderingDevice.MEMORY_TEXTURES: MemoryType = 0
Memory taken by textures.

## MEMORY_BUFFERS :: const RenderingDevice.MEMORY_BUFFERS: MemoryType = 1
Memory taken by buffers.

## MEMORY_TOTAL :: const RenderingDevice.MEMORY_TOTAL: MemoryType = 2
Total memory taken. This is greater than the sum of [constant MEMORY_TEXTURES] and [constant MEMORY_BUFFERS], as it also includes miscellaneous memory usage.

## INVALID_ID :: const RenderingDevice.INVALID_ID = -1
Returned by functions that return an ID if a value is invalid.

## INVALID_FORMAT_ID :: const RenderingDevice.INVALID_FORMAT_ID = -1
Returned by functions that return a format ID if a value is invalid.

## NONE :: const RenderingDevice.NONE: BreadcrumbMarker = 0
No breadcrumb marker will be added.

## REFLECTION_PROBES :: const RenderingDevice.REFLECTION_PROBES: BreadcrumbMarker = 65536
During a GPU crash in dev or debug mode, Godot's error message will include [code]"REFLECTION_PROBES"[/code] for added context as to when the crash occurred.

## SKY_PASS :: const RenderingDevice.SKY_PASS: BreadcrumbMarker = 131072
During a GPU crash in dev or debug mode, Godot's error message will include [code]"SKY_PASS"[/code] for added context as to when the crash occurred.

## LIGHTMAPPER_PASS :: const RenderingDevice.LIGHTMAPPER_PASS: BreadcrumbMarker = 196608
During a GPU crash in dev or debug mode, Godot's error message will include [code]"LIGHTMAPPER_PASS"[/code] for added context as to when the crash occurred.

## SHADOW_PASS_DIRECTIONAL :: const RenderingDevice.SHADOW_PASS_DIRECTIONAL: BreadcrumbMarker = 262144
During a GPU crash in dev or debug mode, Godot's error message will include [code]"SHADOW_PASS_DIRECTIONAL"[/code] for added context as to when the crash occurred.

## SHADOW_PASS_CUBE :: const RenderingDevice.SHADOW_PASS_CUBE: BreadcrumbMarker = 327680
During a GPU crash in dev or debug mode, Godot's error message will include [code]"SHADOW_PASS_CUBE"[/code] for added context as to when the crash occurred.

## OPAQUE_PASS :: const RenderingDevice.OPAQUE_PASS: BreadcrumbMarker = 393216
During a GPU crash in dev or debug mode, Godot's error message will include [code]"OPAQUE_PASS"[/code] for added context as to when the crash occurred.

## ALPHA_PASS :: const RenderingDevice.ALPHA_PASS: BreadcrumbMarker = 458752
During a GPU crash in dev or debug mode, Godot's error message will include [code]"ALPHA_PASS"[/code] for added context as to when the crash occurred.

## TRANSPARENT_PASS :: const RenderingDevice.TRANSPARENT_PASS: BreadcrumbMarker = 524288
During a GPU crash in dev or debug mode, Godot's error message will include [code]"TRANSPARENT_PASS"[/code] for added context as to when the crash occurred.

## POST_PROCESSING_PASS :: const RenderingDevice.POST_PROCESSING_PASS: BreadcrumbMarker = 589824
During a GPU crash in dev or debug mode, Godot's error message will include [code]"POST_PROCESSING_PASS"[/code] for added context as to when the crash occurred.

## BLIT_PASS :: const RenderingDevice.BLIT_PASS: BreadcrumbMarker = 655360
During a GPU crash in dev or debug mode, Godot's error message will include [code]"BLIT_PASS"[/code] for added context as to when the crash occurred.

## UI_PASS :: const RenderingDevice.UI_PASS: BreadcrumbMarker = 720896
During a GPU crash in dev or debug mode, Godot's error message will include [code]"UI_PASS"[/code] for added context as to when the crash occurred.

## DEBUG_PASS :: const RenderingDevice.DEBUG_PASS: BreadcrumbMarker = 786432
During a GPU crash in dev or debug mode, Godot's error message will include [code]"DEBUG_PASS"[/code] for added context as to when the crash occurred.

## DRAW_DEFAULT_ALL :: const RenderingDevice.DRAW_DEFAULT_ALL: DrawFlags = 0
Do not clear or ignore any attachments.

## DRAW_CLEAR_COLOR_0 :: const RenderingDevice.DRAW_CLEAR_COLOR_0: DrawFlags = 1
Clear the first color attachment.

## DRAW_CLEAR_COLOR_1 :: const RenderingDevice.DRAW_CLEAR_COLOR_1: DrawFlags = 2
Clear the second color attachment.

## DRAW_CLEAR_COLOR_2 :: const RenderingDevice.DRAW_CLEAR_COLOR_2: DrawFlags = 4
Clear the third color attachment.

## DRAW_CLEAR_COLOR_3 :: const RenderingDevice.DRAW_CLEAR_COLOR_3: DrawFlags = 8
Clear the fourth color attachment.

## DRAW_CLEAR_COLOR_4 :: const RenderingDevice.DRAW_CLEAR_COLOR_4: DrawFlags = 16
Clear the fifth color attachment.

## DRAW_CLEAR_COLOR_5 :: const RenderingDevice.DRAW_CLEAR_COLOR_5: DrawFlags = 32
Clear the sixth color attachment.

## DRAW_CLEAR_COLOR_6 :: const RenderingDevice.DRAW_CLEAR_COLOR_6: DrawFlags = 64
Clear the seventh color attachment.

## DRAW_CLEAR_COLOR_7 :: const RenderingDevice.DRAW_CLEAR_COLOR_7: DrawFlags = 128
Clear the eighth color attachment.

## DRAW_CLEAR_COLOR_MASK :: const RenderingDevice.DRAW_CLEAR_COLOR_MASK: DrawFlags = 255
Mask for clearing all color attachments.

## DRAW_CLEAR_COLOR_ALL :: const RenderingDevice.DRAW_CLEAR_COLOR_ALL: DrawFlags = 255
Clear all color attachments.

## DRAW_IGNORE_COLOR_0 :: const RenderingDevice.DRAW_IGNORE_COLOR_0: DrawFlags = 256
Ignore the previous contents of the first color attachment.

## DRAW_IGNORE_COLOR_1 :: const RenderingDevice.DRAW_IGNORE_COLOR_1: DrawFlags = 512
Ignore the previous contents of the second color attachment.

## DRAW_IGNORE_COLOR_2 :: const RenderingDevice.DRAW_IGNORE_COLOR_2: DrawFlags = 1024
Ignore the previous contents of the third color attachment.

## DRAW_IGNORE_COLOR_3 :: const RenderingDevice.DRAW_IGNORE_COLOR_3: DrawFlags = 2048
Ignore the previous contents of the fourth color attachment.

## DRAW_IGNORE_COLOR_4 :: const RenderingDevice.DRAW_IGNORE_COLOR_4: DrawFlags = 4096
Ignore the previous contents of the fifth color attachment.

## DRAW_IGNORE_COLOR_5 :: const RenderingDevice.DRAW_IGNORE_COLOR_5: DrawFlags = 8192
Ignore the previous contents of the sixth color attachment.

## DRAW_IGNORE_COLOR_6 :: const RenderingDevice.DRAW_IGNORE_COLOR_6: DrawFlags = 16384
Ignore the previous contents of the seventh color attachment.

## DRAW_IGNORE_COLOR_7 :: const RenderingDevice.DRAW_IGNORE_COLOR_7: DrawFlags = 32768
Ignore the previous contents of the eighth color attachment.

## DRAW_IGNORE_COLOR_MASK :: const RenderingDevice.DRAW_IGNORE_COLOR_MASK: DrawFlags = 65280
Mask for ignoring all the previous contents of the color attachments.

## DRAW_IGNORE_COLOR_ALL :: const RenderingDevice.DRAW_IGNORE_COLOR_ALL: DrawFlags = 65280
Ignore the previous contents of all color attachments.

## DRAW_CLEAR_DEPTH :: const RenderingDevice.DRAW_CLEAR_DEPTH: DrawFlags = 65536
Clear the depth attachment.

## DRAW_IGNORE_DEPTH :: const RenderingDevice.DRAW_IGNORE_DEPTH: DrawFlags = 131072
Ignore the previous contents of the depth attachment.

## DRAW_CLEAR_STENCIL :: const RenderingDevice.DRAW_CLEAR_STENCIL: DrawFlags = 262144
Clear the stencil attachment.

## DRAW_IGNORE_STENCIL :: const RenderingDevice.DRAW_IGNORE_STENCIL: DrawFlags = 524288
Ignore the previous contents of the stencil attachment.

## DRAW_CLEAR_ALL :: const RenderingDevice.DRAW_CLEAR_ALL: DrawFlags = 327935
Clear all attachments.

## DRAW_IGNORE_ALL :: const RenderingDevice.DRAW_IGNORE_ALL: DrawFlags = 720640
Ignore the previous contents of all attachments.

## barrier :: func RenderingDevice.barrier(from: int = 32767, to: int = 32767) -> void
This method does nothing.

### from :: int

### to :: int

## blas_build :: func RenderingDevice.blas_build(blas: RID) -> int
Builds the [param blas].

### blas :: RID

## blas_create :: func RenderingDevice.blas_create(geometries: RDAccelerationStructureGeometry[], flags: int) -> RID
Creates a new Bottom-Level Acceleration Structure (BLAS). It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.

### geometries :: RDAccelerationStructureGeometry[]

### flags :: int

## buffer_clear :: func RenderingDevice.buffer_clear(buffer: RID, offset: int, size_bytes: int) -> int
Clears the contents of the [param buffer], clearing [param size_bytes] bytes, starting at [param offset].
Prints an error if:
- the size isn't a multiple of four
- the region specified by [param offset] + [param size_bytes] exceeds the buffer
- a draw list is currently active (created by [method draw_list_begin])
- a compute list is currently active (created by [method compute_list_begin])

### buffer :: RID

### offset :: int

### size_bytes :: int

## buffer_copy :: func RenderingDevice.buffer_copy(src_buffer: RID, dst_buffer: RID, src_offset: int, dst_offset: int, size: int) -> int
Copies [param size] bytes from the [param src_buffer] at [param src_offset] into [param dst_buffer] at [param dst_offset].
Prints an error if:
- [param size] exceeds the size of either [param src_buffer] or [param dst_buffer] at their corresponding offsets
- a draw list is currently active (created by [method draw_list_begin])
- a compute list is currently active (created by [method compute_list_begin])

### src_buffer :: RID

### dst_buffer :: RID

### src_offset :: int

### dst_offset :: int

### size :: int

## buffer_get_data :: func RenderingDevice.buffer_get_data(buffer: RID, offset_bytes: int = 0, size_bytes: int = 0) -> PackedByteArray
Returns a copy of the data of the specified [param buffer], optionally [param offset_bytes] and [param size_bytes] can be set to copy only a portion of the buffer.
[b]Note:[/b] This method will block the GPU from working until the data is retrieved. Refer to [method buffer_get_data_async] for an alternative that returns the data in more performant way.

### buffer :: RID

### offset_bytes :: int

### size_bytes :: int

## buffer_get_data_async :: func RenderingDevice.buffer_get_data_async(buffer: RID, callback: Callable, offset_bytes: int = 0, size_bytes: int = 0) -> int
Asynchronous version of [method buffer_get_data]. RenderingDevice will call [param callback] in a certain amount of frames with the data the buffer had at the time of the request.
[b]Note:[/b] At the moment, the delay corresponds to the amount of frames specified by [member ProjectSettings.rendering/rendering_device/vsync/frame_queue_size].
[b]Note:[/b] Downloading large buffers can have a prohibitive cost for real-time even when using the asynchronous method due to hardware bandwidth limitations. When dealing with large resources, you can adjust settings such as [member ProjectSettings.rendering/rendering_device/staging_buffer/block_size_kb] to improve the transfer speed at the cost of extra memory.
[codeblock]
func _buffer_get_data_callback(array):
	value = array.decode_u32(0)

...

rd.buffer_get_data_async(buffer, _buffer_get_data_callback)
[/codeblock]

### buffer :: RID

### callback :: Callable

### offset_bytes :: int

### size_bytes :: int

## buffer_get_device_address :: func RenderingDevice.buffer_get_device_address(buffer: RID) -> int
Returns the address of the given [param buffer] which can be passed to shaders in any way to access underlying data. Buffer must have been created with this feature enabled.
[b]Note:[/b] You must check that the GPU supports this functionality by calling [method has_feature] with [constant SUPPORTS_BUFFER_DEVICE_ADDRESS] as a parameter.

### buffer :: RID

## buffer_update :: func RenderingDevice.buffer_update(buffer: RID, offset: int, size_bytes: int, data: PackedByteArray) -> int
Updates a region of [param size_bytes] bytes, starting at [param offset], in the buffer, with the specified [param data].
Prints an error if:
- the region specified by [param offset] + [param size_bytes] exceeds the buffer
- a draw list is currently active (created by [method draw_list_begin])
- a compute list is currently active (created by [method compute_list_begin])

### buffer :: RID

### offset :: int

### size_bytes :: int

### data :: PackedByteArray

## capture_timestamp :: func RenderingDevice.capture_timestamp(name: String) -> void
Creates a timestamp marker with the specified [param name]. This is used for performance reporting with the [method get_captured_timestamp_cpu_time], [method get_captured_timestamp_gpu_time] and [method get_captured_timestamp_name] methods.

### name :: String

## compute_list_add_barrier :: func RenderingDevice.compute_list_add_barrier(compute_list: int) -> void
Raises a Vulkan compute barrier in the specified [param compute_list].

### compute_list :: int

## compute_list_begin :: func RenderingDevice.compute_list_begin() -> int
Starts a list of compute commands created with the [code]compute_*[/code] methods. The returned value should be passed to other [code]compute_list_*[/code] functions.
Multiple compute lists cannot be created at the same time; you must finish the previous compute list first using [method compute_list_end].
A simple compute operation might look like this (code is not a complete example):
[codeblock]
var rd = RenderingDevice.new()
var compute_list = rd.compute_list_begin()

rd.compute_list_bind_compute_pipeline(compute_list, compute_shader_dilate_pipeline)
rd.compute_list_bind_uniform_set(compute_list, compute_base_uniform_set, 0)
rd.compute_list_bind_uniform_set(compute_list, dilate_uniform_set, 1)

for i in atlas_slices:
	rd.compute_list_set_push_constant(compute_list, push_constant, push_constant.size())
	rd.compute_list_dispatch(compute_list, group_size.x, group_size.y, group_size.z)
	# No barrier, let them run all together.

rd.compute_list_end()
[/codeblock]

## compute_list_bind_compute_pipeline :: func RenderingDevice.compute_list_bind_compute_pipeline(compute_list: int, compute_pipeline: RID) -> void
Tells the GPU what compute pipeline to use when processing the compute list. If the shader has changed since the last time this function was called, Godot will unbind all descriptor sets and will re-bind them inside [method compute_list_dispatch].

### compute_list :: int

### compute_pipeline :: RID

## compute_list_bind_uniform_set :: func RenderingDevice.compute_list_bind_uniform_set(compute_list: int, uniform_set: RID, set_index: int) -> void
Binds the [param uniform_set] to this [param compute_list]. Godot ensures that all textures in the uniform set have the correct Vulkan access masks. If Godot had to change access masks of textures, it will raise a Vulkan image memory barrier.

### compute_list :: int

### uniform_set :: RID

### set_index :: int

## compute_list_dispatch :: func RenderingDevice.compute_list_dispatch(compute_list: int, x_groups: int, y_groups: int, z_groups: int) -> void
Submits the compute list for processing on the GPU. This is the compute equivalent to [method draw_list_draw].

### compute_list :: int

### x_groups :: int

### y_groups :: int

### z_groups :: int

## compute_list_dispatch_indirect :: func RenderingDevice.compute_list_dispatch_indirect(compute_list: int, buffer: RID, offset: int) -> void
Submits the compute list for processing on the GPU with the given group counts stored in the [param buffer] at [param offset]. Buffer must have been created with [constant STORAGE_BUFFER_USAGE_DISPATCH_INDIRECT] flag.

### compute_list :: int

### buffer :: RID

### offset :: int

## compute_list_end :: func RenderingDevice.compute_list_end() -> void
Finishes a list of compute commands created with the [code]compute_*[/code] methods.

## compute_list_set_push_constant :: func RenderingDevice.compute_list_set_push_constant(compute_list: int, buffer: PackedByteArray, size_bytes: int) -> void
Sets the push constant data to [param buffer] for the specified [param compute_list]. The shader determines how this binary data is used. The buffer's size in bytes must also be specified in [param size_bytes] (this can be obtained by calling the [method PackedByteArray.size] method on the passed [param buffer]).

### compute_list :: int

### buffer :: PackedByteArray

### size_bytes :: int

## compute_pipeline_create :: func RenderingDevice.compute_pipeline_create(shader: RID, specialization_constants: RDPipelineSpecializationConstant[] = []) -> RID
Creates a new compute pipeline. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.
This will be freed automatically when the [param shader] is freed.

### shader :: RID

### specialization_constants :: RDPipelineSpecializationConstant[]

## compute_pipeline_is_valid :: func RenderingDevice.compute_pipeline_is_valid(compute_pipeline: RID) -> bool
Returns [code]true[/code] if the compute pipeline specified by the [param compute_pipeline] RID is valid, [code]false[/code] otherwise.

### compute_pipeline :: RID

## create_local_device :: func RenderingDevice.create_local_device() -> RenderingDevice
Create a new local [RenderingDevice]. This is most useful for performing compute operations on the GPU independently from the rest of the engine.

## draw_command_begin_label :: func RenderingDevice.draw_command_begin_label(name: String, color: Color) -> void
Create a command buffer debug label region that can be displayed in third-party tools such as [url=https://renderdoc.org/]RenderDoc[/url]. All regions must be ended with a [method draw_command_end_label] call. When viewed from the linear series of submissions to a single queue, calls to [method draw_command_begin_label] and [method draw_command_end_label] must be matched and balanced.
The [code]VK_EXT_DEBUG_UTILS_EXTENSION_NAME[/code] Vulkan extension must be available and enabled for command buffer debug label region to work. See also [method draw_command_end_label].

### name :: String

### color :: Color

## draw_command_end_label :: func RenderingDevice.draw_command_end_label() -> void
Ends the command buffer debug label region started by a [method draw_command_begin_label] call.

## draw_command_insert_label :: func RenderingDevice.draw_command_insert_label(name: String, color: Color) -> void
This method does nothing.

### name :: String

### color :: Color

## draw_list_begin :: func RenderingDevice.draw_list_begin(framebuffer: RID, draw_flags: int = 0, clear_color_values: PackedColorArray = PackedColorArray(), clear_depth_value: float = 1.0, clear_stencil_value: int = 0, region: Rect2 = Rect2(0, 0, 0, 0), breadcrumb: int = 0) -> int
Starts a list of raster drawing commands created with the [code]draw_*[/code] methods. The returned value should be passed to other [code]draw_list_*[/code] functions.
Multiple draw lists cannot be created at the same time; you must finish the previous draw list first using [method draw_list_end].
A simple drawing operation might look like this (code is not a complete example):
[codeblock]
var rd = RenderingDevice.new()
var clear_colors = PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0), Color(0, 0, 0, 0)])
var draw_list = rd.draw_list_begin(framebuffers[i], RenderingDevice.CLEAR_COLOR_ALL, clear_colors, true, 1.0f, true, 0, Rect2(), RenderingDevice.OPAQUE_PASS)

# Draw opaque.
rd.draw_list_bind_render_pipeline(draw_list, raster_pipeline)
rd.draw_list_bind_uniform_set(draw_list, raster_base_uniform, 0)
rd.draw_list_set_push_constant(draw_list, raster_push_constant, raster_push_constant.size())
rd.draw_list_draw(draw_list, false, 1, slice_triangle_count[i] * 3)
# Draw wire.
rd.draw_list_bind_render_pipeline(draw_list, raster_pipeline_wire)
rd.draw_list_bind_uniform_set(draw_list, raster_base_uniform, 0)
rd.draw_list_set_push_constant(draw_list, raster_push_constant, raster_push_constant.size())
rd.draw_list_draw(draw_list, false, 1, slice_triangle_count[i] * 3)

rd.draw_list_end()
[/codeblock]
The [param draw_flags] indicates if the texture attachments of the framebuffer should be cleared or ignored. Only one of the two flags can be used for each individual attachment. Ignoring an attachment means that any contents that existed before the draw list will be completely discarded, reducing the memory bandwidth used by the render pass but producing garbage results if the pixels aren't replaced. The default behavior allows the engine to figure out the right operation to use if the texture is discardable, which can result in increased performance. See [RDTextureFormat] or [method texture_set_discardable].
The [param breadcrumb] parameter can be an arbitrary 32-bit integer that is useful to diagnose GPU crashes. If Godot is built in dev or debug mode; when the GPU crashes Godot will dump all shaders that were being executed at the time of the crash and the breadcrumb is useful to diagnose what passes did those shaders belong to.
It does not affect rendering behavior and can be set to 0. It is recommended to use [enum BreadcrumbMarker] enumerations for consistency but it's not required. It is also possible to use bitwise operations to add extra data. e.g.
[codeblock]
rd.draw_list_begin(fb[i], RenderingDevice.CLEAR_COLOR_ALL, clear_colors, true, 1.0f, true, 0, Rect2(), RenderingDevice.OPAQUE_PASS | 5)
[/codeblock]

### framebuffer :: RID

### draw_flags :: int

### clear_color_values :: PackedColorArray

### clear_depth_value :: float

### clear_stencil_value :: int

### region :: Rect2

### breadcrumb :: int

## draw_list_begin_for_screen :: func RenderingDevice.draw_list_begin_for_screen(screen: int = 0, clear_color: Color = Color(0, 0, 0, 1)) -> int
High-level variant of [method draw_list_begin], with the parameters automatically being adjusted for drawing onto the window specified by the [param screen] ID.
[b]Note:[/b] Cannot be used with local RenderingDevices, as these don't have a screen. If called on a local RenderingDevice, [method draw_list_begin_for_screen] returns [constant INVALID_ID].

### screen :: int

### clear_color :: Color

## draw_list_begin_split :: func RenderingDevice.draw_list_begin_split(framebuffer: RID, splits: int, initial_color_action: int, final_color_action: int, initial_depth_action: int, final_depth_action: int, clear_color_values: PackedColorArray = PackedColorArray(), clear_depth: float = 1.0, clear_stencil: int = 0, region: Rect2 = Rect2(0, 0, 0, 0), storage_textures: RID[] = []) -> PackedInt64Array
This method does nothing and always returns an empty [PackedInt64Array].

### framebuffer :: RID

### splits :: int

### initial_color_action :: int

### final_color_action :: int

### initial_depth_action :: int

### final_depth_action :: int

### clear_color_values :: PackedColorArray

### clear_depth :: float

### clear_stencil :: int

### region :: Rect2

### storage_textures :: RID[]

## draw_list_bind_index_array :: func RenderingDevice.draw_list_bind_index_array(draw_list: int, index_array: RID) -> void
Binds [param index_array] to the specified [param draw_list].

### draw_list :: int

### index_array :: RID

## draw_list_bind_render_pipeline :: func RenderingDevice.draw_list_bind_render_pipeline(draw_list: int, render_pipeline: RID) -> void
Binds [param render_pipeline] to the specified [param draw_list].

### draw_list :: int

### render_pipeline :: RID

## draw_list_bind_uniform_set :: func RenderingDevice.draw_list_bind_uniform_set(draw_list: int, uniform_set: RID, set_index: int) -> void
Binds [param uniform_set] to the specified [param draw_list]. A [param set_index] must also be specified, which is an identifier starting from [code]0[/code] that must match the one expected by the draw list.

### draw_list :: int

### uniform_set :: RID

### set_index :: int

## draw_list_bind_vertex_array :: func RenderingDevice.draw_list_bind_vertex_array(draw_list: int, vertex_array: RID) -> void
Binds [param vertex_array] to the specified [param draw_list].

### draw_list :: int

### vertex_array :: RID

## draw_list_bind_vertex_buffers_format :: func RenderingDevice.draw_list_bind_vertex_buffers_format(draw_list: int, vertex_format: int, vertex_count: int, vertex_buffers: RID[], offsets: PackedInt64Array = PackedInt64Array()) -> void
Binds a set of [param vertex_buffers] directly to the specified [param draw_list] using [param vertex_format] without creating a vertex array RID. Provide the number of vertices in [param vertex_count]; optional per-buffer byte [param offsets] may also be supplied.

### draw_list :: int

### vertex_format :: int

### vertex_count :: int

### vertex_buffers :: RID[]

### offsets :: PackedInt64Array

## draw_list_disable_scissor :: func RenderingDevice.draw_list_disable_scissor(draw_list: int) -> void
Removes and disables the scissor rectangle for the specified [param draw_list]. See also [method draw_list_enable_scissor].

### draw_list :: int

## draw_list_draw :: func RenderingDevice.draw_list_draw(draw_list: int, use_indices: bool, instances: int, procedural_vertex_count: int = 0) -> void
Submits [param draw_list] for rendering on the GPU. This is the raster equivalent to [method compute_list_dispatch].

### draw_list :: int

### use_indices :: bool

### instances :: int

### procedural_vertex_count :: int

## draw_list_draw_indirect :: func RenderingDevice.draw_list_draw_indirect(draw_list: int, use_indices: bool, buffer: RID, offset: int = 0, draw_count: int = 1, stride: int = 0) -> void
Submits [param draw_list] for rendering on the GPU with the given parameters stored in the [param buffer] at [param offset]. Parameters being integers: vertex count, instance count, first vertex, first instance. And when using indices: index count, instance count, first index, vertex offset, first instance. Buffer must have been created with [constant STORAGE_BUFFER_USAGE_DISPATCH_INDIRECT] flag.

### draw_list :: int

### use_indices :: bool

### buffer :: RID

### offset :: int

### draw_count :: int

### stride :: int

## draw_list_enable_scissor :: func RenderingDevice.draw_list_enable_scissor(draw_list: int, rect: Rect2 = Rect2(0, 0, 0, 0)) -> void
Creates a scissor rectangle and enables it for the specified [param draw_list]. Scissor rectangles are used for clipping by discarding fragments that fall outside a specified rectangular portion of the screen. See also [method draw_list_disable_scissor].
[b]Note:[/b] The specified [param rect] is automatically intersected with the screen's dimensions, which means it cannot exceed the screen's dimensions.

### draw_list :: int

### rect :: Rect2

## draw_list_end :: func RenderingDevice.draw_list_end() -> void
Finishes a list of raster drawing commands created with the [code]draw_*[/code] methods.

## draw_list_set_blend_constants :: func RenderingDevice.draw_list_set_blend_constants(draw_list: int, color: Color) -> void
Sets blend constants for the specified [param draw_list] to [param color]. Blend constants are used only if the graphics pipeline is created with [constant DYNAMIC_STATE_BLEND_CONSTANTS] flag set.

### draw_list :: int

### color :: Color

## draw_list_set_push_constant :: func RenderingDevice.draw_list_set_push_constant(draw_list: int, buffer: PackedByteArray, size_bytes: int) -> void
Sets the push constant data to [param buffer] for the specified [param draw_list]. The shader determines how this binary data is used. The buffer's size in bytes must also be specified in [param size_bytes] (this can be obtained by calling the [method PackedByteArray.size] method on the passed [param buffer]).

### draw_list :: int

### buffer :: PackedByteArray

### size_bytes :: int

## draw_list_switch_to_next_pass :: func RenderingDevice.draw_list_switch_to_next_pass() -> int
Switches to the next draw pass.

## draw_list_switch_to_next_pass_split :: func RenderingDevice.draw_list_switch_to_next_pass_split(splits: int) -> PackedInt64Array
This method does nothing and always returns an empty [PackedInt64Array].

### splits :: int

## framebuffer_create :: func RenderingDevice.framebuffer_create(textures: RID[], validate_with_format: int = -1, view_count: int = 1) -> RID
Creates a new framebuffer. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.
This will be freed automatically when any of the [param textures] is freed.

### textures :: RID[]

### validate_with_format :: int

### view_count :: int

## framebuffer_create_empty :: func RenderingDevice.framebuffer_create_empty(size: Vector2i, samples: int = 0, validate_with_format: int = -1) -> RID
Creates a new empty framebuffer. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.

### size :: Vector2i

### samples :: int

### validate_with_format :: int

## framebuffer_create_multipass :: func RenderingDevice.framebuffer_create_multipass(textures: RID[], passes: RDFramebufferPass[], validate_with_format: int = -1, view_count: int = 1) -> RID
Creates a new multipass framebuffer. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.
This will be freed automatically when any of the [param textures] is freed.

### textures :: RID[]

### passes :: RDFramebufferPass[]

### validate_with_format :: int

### view_count :: int

## framebuffer_format_create :: func RenderingDevice.framebuffer_format_create(attachments: RDAttachmentFormat[], view_count: int = 1) -> int
Creates a new framebuffer format with the specified [param attachments] and [param view_count]. Returns the new framebuffer's unique framebuffer format ID.
If [param view_count] is greater than or equal to [code]2[/code], enables multiview which is used for VR rendering. This requires support for the Vulkan multiview extension.

### attachments :: RDAttachmentFormat[]

### view_count :: int

## framebuffer_format_create_empty :: func RenderingDevice.framebuffer_format_create_empty(samples: int = 0) -> int
Creates a new empty framebuffer format with the specified number of [param samples] and returns its ID.

### samples :: int

## framebuffer_format_create_multipass :: func RenderingDevice.framebuffer_format_create_multipass(attachments: RDAttachmentFormat[], passes: RDFramebufferPass[], view_count: int = 1) -> int
Creates a multipass framebuffer format with the specified [param attachments], [param passes] and [param view_count] and returns its ID. If [param view_count] is greater than or equal to [code]2[/code], enables multiview which is used for VR rendering. This requires support for the Vulkan multiview extension.

### attachments :: RDAttachmentFormat[]

### passes :: RDFramebufferPass[]

### view_count :: int

## framebuffer_format_get_texture_samples :: func RenderingDevice.framebuffer_format_get_texture_samples(format: int, render_pass: int = 0) -> int
Returns the number of texture samples used for the given framebuffer [param format] ID (returned by [method framebuffer_get_format]).

### format :: int

### render_pass :: int

## framebuffer_get_format :: func RenderingDevice.framebuffer_get_format(framebuffer: RID) -> int
Returns the format ID of the framebuffer specified by the [param framebuffer] RID. This ID is guaranteed to be unique for the same formats and does not need to be freed.

### framebuffer :: RID

## framebuffer_is_valid :: func RenderingDevice.framebuffer_is_valid(framebuffer: RID) -> bool
Returns [code]true[/code] if the framebuffer specified by the [param framebuffer] RID is valid, [code]false[/code] otherwise.

### framebuffer :: RID

## free_rid :: func RenderingDevice.free_rid(rid: RID) -> void
Tries to free an object in the RenderingDevice. To avoid memory leaks, this should be called after using an object as memory management does not occur automatically when using RenderingDevice directly.

### rid :: RID

## full_barrier :: func RenderingDevice.full_barrier() -> void
This method does nothing.

## get_captured_timestamp_cpu_time :: func RenderingDevice.get_captured_timestamp_cpu_time(index: int) -> int
Returns the timestamp in CPU time for the rendering step specified by [param index] (in microseconds since the engine started). See also [method get_captured_timestamp_gpu_time] and [method capture_timestamp].

### index :: int

## get_captured_timestamp_gpu_time :: func RenderingDevice.get_captured_timestamp_gpu_time(index: int) -> int
Returns the timestamp in GPU time for the rendering step specified by [param index] (in microseconds since the engine started). See also [method get_captured_timestamp_cpu_time] and [method capture_timestamp].

### index :: int

## get_captured_timestamp_name :: func RenderingDevice.get_captured_timestamp_name(index: int) -> String
Returns the timestamp's name for the rendering step specified by [param index]. See also [method capture_timestamp].

### index :: int

## get_captured_timestamps_count :: func RenderingDevice.get_captured_timestamps_count() -> int
Returns the total number of timestamps (rendering steps) available for profiling.

## get_captured_timestamps_frame :: func RenderingDevice.get_captured_timestamps_frame() -> int
Returns the index of the last frame rendered that has rendering timestamps available for querying.

## get_device_allocation_count :: func RenderingDevice.get_device_allocation_count() -> int
Returns how many allocations the GPU has performed for internal driver structures.
This is only used by Vulkan in debug builds and can return 0 when this information is not tracked or unknown.

## get_device_allocs_by_object_type :: func RenderingDevice.get_device_allocs_by_object_type(type: int) -> int
Same as [method get_device_allocation_count] but filtered for a given object type.
The type argument must be in range [code][0; get_tracked_object_type_count - 1][/code]. If [method get_tracked_object_type_count] is 0, then type argument is ignored and always returns 0.
This is only used by Vulkan in debug builds and can return 0 when this information is not tracked or unknown.

### type :: int

## get_device_memory_by_object_type :: func RenderingDevice.get_device_memory_by_object_type(type: int) -> int
Same as [method get_device_total_memory] but filtered for a given object type.
The type argument must be in range [code][0; get_tracked_object_type_count - 1][/code]. If [method get_tracked_object_type_count] is 0, then type argument is ignored and always returns 0.
This is only used by Vulkan in debug builds and can return 0 when this information is not tracked or unknown.

### type :: int

## get_device_name :: func RenderingDevice.get_device_name() -> String
Returns the name of the video adapter (e.g. "GeForce GTX 1080/PCIe/SSE2"). Equivalent to [method RenderingServer.get_video_adapter_name]. See also [method get_device_vendor_name].

## get_device_pipeline_cache_uuid :: func RenderingDevice.get_device_pipeline_cache_uuid() -> String
Returns the universally unique identifier for the pipeline cache. This is used to cache shader files on disk, which avoids shader recompilations on subsequent engine runs. This UUID varies depending on the graphics card model, but also the driver version. Therefore, updating graphics drivers will invalidate the shader cache.

## get_device_total_memory :: func RenderingDevice.get_device_total_memory() -> int
Returns how much bytes the GPU is using.
This is only used by Vulkan in debug builds and can return 0 when this information is not tracked or unknown.

## get_device_vendor_name :: func RenderingDevice.get_device_vendor_name() -> String
Returns the vendor of the video adapter (e.g. "NVIDIA Corporation"). Equivalent to [method RenderingServer.get_video_adapter_vendor]. See also [method get_device_name].

## get_driver_allocation_count :: func RenderingDevice.get_driver_allocation_count() -> int
Returns how many allocations the GPU driver has performed for internal driver structures.
This is only used by Vulkan in debug builds and can return 0 when this information is not tracked or unknown.

## get_driver_allocs_by_object_type :: func RenderingDevice.get_driver_allocs_by_object_type(type: int) -> int
Same as [method get_driver_allocation_count] but filtered for a given object type.
The type argument must be in range [code][0; get_tracked_object_type_count - 1][/code]. If [method get_tracked_object_type_count] is 0, then type argument is ignored and always returns 0.
This is only used by Vulkan in debug builds and can return 0 when this information is not tracked or unknown.

### type :: int

## get_driver_and_device_memory_report :: func RenderingDevice.get_driver_and_device_memory_report() -> String
Returns string report in CSV format using the following methods:
- [method get_tracked_object_name]
- [method get_tracked_object_type_count]
- [method get_driver_total_memory]
- [method get_driver_allocation_count]
- [method get_driver_memory_by_object_type]
- [method get_driver_allocs_by_object_type]
- [method get_device_total_memory]
- [method get_device_allocation_count]
- [method get_device_memory_by_object_type]
- [method get_device_allocs_by_object_type]
This is only used by Vulkan in debug builds. Godot must also be started with the [code]--extra-gpu-memory-tracking[/code] [url=https://docs.godotengine.org/en/4.7/tutorials/editor/command_line_tutorial.html]command line argument[/url].

## get_driver_memory_by_object_type :: func RenderingDevice.get_driver_memory_by_object_type(type: int) -> int
Same as [method get_driver_total_memory] but filtered for a given object type.
The type argument must be in range [code][0; get_tracked_object_type_count - 1][/code]. If [method get_tracked_object_type_count] is 0, then type argument is ignored and always returns 0.
This is only used by Vulkan in debug builds and can return 0 when this information is not tracked or unknown.

### type :: int

## get_driver_resource :: func RenderingDevice.get_driver_resource(resource: int, rid: RID, index: int) -> int
Returns the unique identifier of the driver [param resource] for the specified [param rid]. Some driver resource types ignore the specified [param rid]. [param index] is always ignored but must be specified anyway.

### resource :: int

### rid :: RID

### index :: int

## get_driver_total_memory :: func RenderingDevice.get_driver_total_memory() -> int
Returns how much bytes the GPU driver is using for internal driver structures.
This is only used by Vulkan in debug builds and can return 0 when this information is not tracked or unknown.

## get_frame_delay :: func RenderingDevice.get_frame_delay() -> int
Returns the frame count kept by the graphics API. Higher values result in higher input lag, but with more consistent throughput. For the main [RenderingDevice], frames are cycled (usually 3 with triple-buffered V-Sync enabled). However, local [RenderingDevice]s only have 1 frame.

## get_memory_usage :: func RenderingDevice.get_memory_usage(type: int) -> int
Returns the memory usage in bytes corresponding to the given [param type]. When using Vulkan, these statistics are calculated by [url=https://github.com/GPUOpen-LibrariesAndSDKs/VulkanMemoryAllocator]Vulkan Memory Allocator[/url].

### type :: int

## get_perf_report :: func RenderingDevice.get_perf_report() -> String
Returns a string with a performance report from the past frame. Updates every frame.

## get_tracked_object_name :: func RenderingDevice.get_tracked_object_name(type_index: int) -> String
Returns the name of the type of object for the given [param type_index]. This value must be in range [code][0; get_tracked_object_type_count - 1][/code]. If [method get_tracked_object_type_count] is 0, then type argument is ignored and always returns the same string.
The return value is important because it gives meaning to the types passed to [method get_driver_memory_by_object_type], [method get_driver_allocs_by_object_type], [method get_device_memory_by_object_type], and [method get_device_allocs_by_object_type]. Examples of strings it can return (not exhaustive):
- DEVICE_MEMORY
- PIPELINE_CACHE
- SWAPCHAIN_KHR
- COMMAND_POOL
Thus if e.g. [code]get_tracked_object_name(5)[/code] returns "COMMAND_POOL", then [code]get_device_memory_by_object_type(5)[/code] returns the bytes used by the GPU for command pools.
This is only used by Vulkan in debug builds. Godot must also be started with the [code]--extra-gpu-memory-tracking[/code] [url=https://docs.godotengine.org/en/4.7/tutorials/editor/command_line_tutorial.html]command line argument[/url].

### type_index :: int

## get_tracked_object_type_count :: func RenderingDevice.get_tracked_object_type_count() -> int
Returns how many types of trackable objects there are.
This is only used by Vulkan in debug builds. Godot must also be started with the [code]--extra-gpu-memory-tracking[/code] [url=https://docs.godotengine.org/en/4.7/tutorials/editor/command_line_tutorial.html]command line argument[/url].

## has_feature :: func RenderingDevice.has_feature(feature: int) -> bool
Returns [code]true[/code] if the [param feature] is supported by the GPU.

### feature :: int

## hit_sbt_create :: func RenderingDevice.hit_sbt_create(raytracing_pipeline: RID, initial_hit_group_capacity: int) -> RID
Creates a new hit shader binding table (SBT). It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.
This will be freed automatically when the [param raytracing_pipeline] is freed.
The hit SBT resizes itself as needed. [param initial_hit_group_capacity] is used to allocate the initial backing memory.

### raytracing_pipeline :: RID

### initial_hit_group_capacity :: int

## hit_sbt_range_alloc :: func RenderingDevice.hit_sbt_range_alloc(hit_sbt: RID, hit_group_count: int) -> int
Allocates a contiguous range of SBT entries from [param hit_sbt].
The returned value should be assigned to [member RDAccelerationStructureInstance.hit_sbt_range].
During ray traversal, hit group index is computed as:
	(geometry index in [member RDAccelerationStructureInstance.blas])
	× (SBT stride used in [code]traceRayEXT[/code])
	+ (SBT offset used in [code]traceRayEXT[/code])
	+ (range offset)
[param hit_group_count] must be large enough to cover all SBT entries that may be indexed by this equation. This typically corresponds to:
	(geometry count in [member RDAccelerationStructureInstance.blas])
	× (SBT stride used in [code]traceRayEXT[/code])
The allocated range is uninitialized and must be filled using [method hit_sbt_range_update].

### hit_sbt :: RID

### hit_group_count :: int

## hit_sbt_range_free :: func RenderingDevice.hit_sbt_range_free(hit_sbt: RID, range: int) -> int
Frees a hit SBT range previously allocated with [method hit_sbt_range_alloc].
The range must not be in use by any acceleration structure after being freed.

### hit_sbt :: RID

### range :: int

## hit_sbt_range_update :: func RenderingDevice.hit_sbt_range_update(hit_sbt: RID, range: int, offset: int, hit_group_indices: PackedInt32Array) -> int
Updates the contents of a hit SBT range.
[param hit_group_indices] specifies indices into the hit group array provided in [method raytracing_pipeline_create].
The [param offset] parameter specifies where within the allocated range the writing begins. This allows partial updates of a range. However, the complete range must be fully initialized before it is used in a raytracing dispatch.

### hit_sbt :: RID

### range :: int

### offset :: int

### hit_group_indices :: PackedInt32Array

## hit_sbt_set_pipeline :: func RenderingDevice.hit_sbt_set_pipeline(hit_sbt: RID, raytracing_pipeline: RID) -> int
Sets a new [param raytracing_pipeline] for [param hit_sbt].
The new pipeline must be a superset of the previous one. Existing hit groups must keep the same order and new hit groups should be appended to the end. This preserves existing SBT entries.
The previous pipeline must remain valid during the call.

### hit_sbt :: RID

### raytracing_pipeline :: RID

## index_array_create :: func RenderingDevice.index_array_create(index_buffer: RID, index_offset: int, index_count: int) -> RID
Creates a new index array. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.
This will be freed automatically when the [param index_buffer] is freed.

### index_buffer :: RID

### index_offset :: int

### index_count :: int

## index_buffer_create :: func RenderingDevice.index_buffer_create(size_indices: int, format: int, data: PackedByteArray = PackedByteArray(), use_restart_indices: bool = false, creation_bits: int = 0) -> RID
Creates a new index buffer. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.

### size_indices :: int

### format :: int

### data :: PackedByteArray

### use_restart_indices :: bool

### creation_bits :: int

## limit_get :: func RenderingDevice.limit_get(limit: int) -> int
Returns the value of the specified [param limit]. This limit varies depending on the current graphics hardware (and sometimes the driver version). If the given limit is exceeded, rendering errors will occur.
Limits for various graphics hardware can be found in the [url=https://vulkan.gpuinfo.org/]Vulkan Hardware Database[/url].

### limit :: int

## raytracing_list_begin :: func RenderingDevice.raytracing_list_begin() -> int
Starts a list of raytracing commands. The returned value should be passed to other [code]raytracing_list_*[/code] functions.
Multiple raytracing lists cannot be created at the same time; you must finish the previous raytracing list first using [method raytracing_list_end].
A simple raytracing operation might look like this (code is not a complete example):
[codeblocks]
[gdscript]
var rd = RenderingDevice.new()
assert(rd.has_feature(RenderingDevice.SUPPORTS_RAYTRACING_PIPELINE))

# Create a BLAS for a mesh.
var geometry = RDAccelerationStructureGeometry.new()
geometry.flags = RenderingDevice.ACCELERATION_STRUCTURE_GEOMETRY_OPAQUE_BIT
geometry.vertex_buffer = vertex_buffer
geometry.vertex_stride = 12
geometry.vertex_format = RenderingDevice.DATA_FORMAT_R32G32B32_SFLOAT
geometry.vertex_count = 3
geometry.index_buffer = index_buffer
geometry.index_count = 3
geometries.push_back(geometry)

blas = rd.blas_create([geometry], 0)

# Create TLAS.
tlas = rd.tlas_create(1, 0)

# Build acceleration structures.
rd.blas_build(blas)

var instance = RDAccelerationStructureInstance.new()
instance.blas = blas

instance.hit_sbt_range = rd.hit_sbt_range_alloc(hit_sbt, 1)
rd.hit_sbt_range_update(hit_sbt, instance.hit_sbt_range, 0, [0])

rd.tlas_build(tlas, [instance])

var raylist = rd.raytracing_list_begin()

# Bind pipeline and uniforms.
rd.raytracing_list_bind_raytracing_pipeline(raylist, raytracing_pipeline)
rd.raytracing_list_bind_uniform_set(raylist, uniform_set, 0)

# Trace rays.
var width = get_viewport().size.x
var height = get_viewport().size.y
rd.raytracing_list_trace_rays(raylist, 0, hit_sbt, width, height, 1)

rd.raytracing_list_end()
[/gdscript]
[/codeblocks]

## raytracing_list_bind_raytracing_pipeline :: func RenderingDevice.raytracing_list_bind_raytracing_pipeline(raytracing_list: int, raytracing_pipeline: RID) -> void
Binds [param raytracing_pipeline] to the specified [param raytracing_list].

### raytracing_list :: int

### raytracing_pipeline :: RID

## raytracing_list_bind_uniform_set :: func RenderingDevice.raytracing_list_bind_uniform_set(raytracing_list: int, uniform_set: RID, set_index: int) -> void
Binds the [param uniform_set] to this [param raytracing_list].

### raytracing_list :: int

### uniform_set :: RID

### set_index :: int

## raytracing_list_end :: func RenderingDevice.raytracing_list_end() -> void
Finishes a list of raytracing commands created with the [code]raytracing_*[/code] methods.

## raytracing_list_set_push_constant :: func RenderingDevice.raytracing_list_set_push_constant(raytracing_list: int, buffer: PackedByteArray, size_bytes: int) -> void
Sets the push constant data to [param buffer] for the specified [param raytracing_list]. The shader determines how this binary data is used. The buffer's size in bytes must also be specified in [param size_bytes] (this can be obtained by calling the [method PackedByteArray.size] method on the passed [param buffer]).

### raytracing_list :: int

### buffer :: PackedByteArray

### size_bytes :: int

## raytracing_list_trace_rays :: func RenderingDevice.raytracing_list_trace_rays(raytracing_list: int, raygen_shader_index: int, hit_sbt: RID, width: int, height: int, depth: int) -> void
Initializes a raytracing dispatch for [param raytracing_list], launching [param width] × [param height] × [param depth] rays.
[param raygen_shader_index] selects the ray generation shader from the pipeline bound with [method raytracing_list_bind_raytracing_pipeline].
[param hit_sbt] must use the same pipeline bound to [param raytracing_list].

### raytracing_list :: int

### raygen_shader_index :: int

### hit_sbt :: RID

### width :: int

### height :: int

### depth :: int

## raytracing_pipeline_create :: func RenderingDevice.raytracing_pipeline_create(raygen_shaders: RDPipelineShader[], miss_shaders: RDPipelineShader[], hit_groups: RDHitGroup[], max_trace_recursion_depth: int) -> RID
Creates a new raytracing pipeline. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.
Each shader must provide the required stage. All stages must use compatible pipeline layouts. The pipeline selects the required stage from each shader.
Input order defines stable indices used by the API:
- [param raygen_shaders] is indexed in [method raytracing_list_trace_rays].
- [param miss_shaders] is indexed in [code]traceRayEXT[/code].
- [param hit_groups] is indexed in [method hit_sbt_range_update].

### raygen_shaders :: RDPipelineShader[]

### miss_shaders :: RDPipelineShader[]

### hit_groups :: RDHitGroup[]

### max_trace_recursion_depth :: int

## raytracing_pipeline_is_valid :: func RenderingDevice.raytracing_pipeline_is_valid(raytracing_pipeline: RID) -> bool
Returns [code]true[/code] if the raytracing pipeline specified by the [param raytracing_pipeline] RID is valid, [code]false[/code] otherwise.

### raytracing_pipeline :: RID

## render_pipeline_create :: func RenderingDevice.render_pipeline_create(shader: RID, framebuffer_format: int, vertex_format: int, primitive: int, rasterization_state: RDPipelineRasterizationState, multisample_state: RDPipelineMultisampleState, stencil_state: RDPipelineDepthStencilState, color_blend_state: RDPipelineColorBlendState, dynamic_state_flags: int = 0, for_render_pass: int = 0, specialization_constants: RDPipelineSpecializationConstant[] = []) -> RID
Creates a new render pipeline. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.
This will be freed automatically when the [param shader] is freed.

### shader :: RID

### framebuffer_format :: int

### vertex_format :: int

### primitive :: int

### rasterization_state :: RDPipelineRasterizationState

### multisample_state :: RDPipelineMultisampleState

### stencil_state :: RDPipelineDepthStencilState

### color_blend_state :: RDPipelineColorBlendState

### dynamic_state_flags :: int

### for_render_pass :: int

### specialization_constants :: RDPipelineSpecializationConstant[]

## render_pipeline_is_valid :: func RenderingDevice.render_pipeline_is_valid(render_pipeline: RID) -> bool
Returns [code]true[/code] if the render pipeline specified by the [param render_pipeline] RID is valid, [code]false[/code] otherwise.

### render_pipeline :: RID

## sampler_create :: func RenderingDevice.sampler_create(state: RDSamplerState) -> RID
Creates a new sampler. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.

### state :: RDSamplerState

## sampler_is_format_supported_for_filter :: func RenderingDevice.sampler_is_format_supported_for_filter(format: int, sampler_filter: int) -> bool
Returns [code]true[/code] if implementation supports using a texture of [param format] with the given [param sampler_filter].

### format :: int

### sampler_filter :: int

## screen_get_framebuffer_format :: func RenderingDevice.screen_get_framebuffer_format(screen: int = 0) -> int
Returns the framebuffer format of the given screen.
[b]Note:[/b] Only the main [RenderingDevice] returned by [method RenderingServer.get_rendering_device] has a format. If called on a local [RenderingDevice], this method prints an error and returns [constant INVALID_ID].

### screen :: int

## screen_get_height :: func RenderingDevice.screen_get_height(screen: int = 0) -> int
Returns the window height matching the graphics API context for the given window ID (in pixels). Despite the parameter being named [param screen], this returns the [i]window[/i] size. See also [method screen_get_width].
[b]Note:[/b] Only the main [RenderingDevice] returned by [method RenderingServer.get_rendering_device] has a height. If called on a local [RenderingDevice], this method prints an error and returns [constant INVALID_ID].

### screen :: int

## screen_get_width :: func RenderingDevice.screen_get_width(screen: int = 0) -> int
Returns the window width matching the graphics API context for the given window ID (in pixels). Despite the parameter being named [param screen], this returns the [i]window[/i] size. See also [method screen_get_height].
[b]Note:[/b] Only the main [RenderingDevice] returned by [method RenderingServer.get_rendering_device] has a width. If called on a local [RenderingDevice], this method prints an error and returns [constant INVALID_ID].

### screen :: int

## set_resource_name :: func RenderingDevice.set_resource_name(id: RID, name: String) -> void
Sets the resource name for [param id] to [param name]. This is used for debugging with third-party tools such as [url=https://renderdoc.org/]RenderDoc[/url].
The following types of resources can be named: texture, sampler, vertex buffer, index buffer, uniform buffer, texture buffer, storage buffer, uniform set buffer, shader, render pipeline and compute pipeline. Framebuffers cannot be named. Attempting to name an incompatible resource type will print an error.
[b]Note:[/b] Resource names are only set when the engine runs in verbose mode ([method OS.is_stdout_verbose] = [code]true[/code]), or when using an engine build compiled with the [code]dev_mode=yes[/code] SCons option. The graphics driver must also support the [code]VK_EXT_DEBUG_UTILS_EXTENSION_NAME[/code] Vulkan extension for named resources to work.

### id :: RID

### name :: String

## shader_compile_binary_from_spirv :: func RenderingDevice.shader_compile_binary_from_spirv(spirv_data: RDShaderSPIRV, name: String = "") -> PackedByteArray
Compiles a binary shader from [param spirv_data] and returns the compiled binary data as a [PackedByteArray]. This compiled shader is specific to the GPU model and driver version used; it will not work on different GPU models or even different driver versions. See also [method shader_compile_spirv_from_source].
[param name] is an optional human-readable name that can be given to the compiled shader for organizational purposes.

### spirv_data :: RDShaderSPIRV

### name :: String

## shader_compile_spirv_from_source :: func RenderingDevice.shader_compile_spirv_from_source(shader_source: RDShaderSource, allow_cache: bool = true) -> RDShaderSPIRV
Compiles a SPIR-V from the shader source code in [param shader_source] and returns the SPIR-V as an [RDShaderSPIRV]. This intermediate language shader is portable across different GPU models and driver versions, but cannot be run directly by GPUs until compiled into a binary shader using [method shader_compile_binary_from_spirv].
If [param allow_cache] is [code]true[/code], make use of the shader cache generated by Godot. This avoids a potentially lengthy shader compilation step if the shader is already in cache. If [param allow_cache] is [code]false[/code], Godot's shader cache is ignored and the shader will always be recompiled.

### shader_source :: RDShaderSource

### allow_cache :: bool

## shader_create_from_bytecode :: func RenderingDevice.shader_create_from_bytecode(binary_data: PackedByteArray, placeholder_rid: RID = RID()) -> RID
Creates a new shader instance from a binary compiled shader. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method. See also [method shader_compile_binary_from_spirv] and [method shader_create_from_spirv].

### binary_data :: PackedByteArray

### placeholder_rid :: RID

## shader_create_from_spirv :: func RenderingDevice.shader_create_from_spirv(spirv_data: RDShaderSPIRV, name: String = "") -> RID
Creates a new shader instance from SPIR-V intermediate code. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method. See also [method shader_compile_spirv_from_source] and [method shader_create_from_bytecode].

### spirv_data :: RDShaderSPIRV

### name :: String

## shader_create_placeholder :: func RenderingDevice.shader_create_placeholder() -> RID
Create a placeholder RID by allocating an RID without initializing it for use in [method shader_create_from_bytecode]. This allows you to create an RID for a shader and pass it around, but defer compiling the shader to a later time.

## shader_get_vertex_input_attribute_mask :: func RenderingDevice.shader_get_vertex_input_attribute_mask(shader: RID) -> int
Returns the internal vertex input mask. Internally, the vertex input mask is an unsigned integer consisting of the locations (specified in GLSL via. [code]layout(location = ...)[/code]) of the input variables (specified in GLSL by the [code]in[/code] keyword).

### shader :: RID

## storage_buffer_create :: func RenderingDevice.storage_buffer_create(size_bytes: int, data: PackedByteArray = PackedByteArray(), usage: int = 0, creation_bits: int = 0) -> RID
Creates a [url=https://vkguide.dev/docs/chapter-4/storage_buffers/]storage buffer[/url] with the specified [param data] and [param usage]. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.

### size_bytes :: int

### data :: PackedByteArray

### usage :: int

### creation_bits :: int

## submit :: func RenderingDevice.submit() -> void
Pushes the frame setup and draw command buffers then marks the local device as currently processing (which allows calling [method sync]).
[b]Note:[/b] Only available in local RenderingDevices.

## sync :: func RenderingDevice.sync() -> void
Forces a synchronization between the CPU and GPU, which may be required in certain cases. Only call this when needed, as CPU-GPU synchronization has a performance cost.
[b]Note:[/b] Only available in local RenderingDevices.
[b]Note:[/b] [method sync] can only be called after a [method submit].

## texture_buffer_create :: func RenderingDevice.texture_buffer_create(size_bytes: int, format: int, data: PackedByteArray = PackedByteArray()) -> RID
Creates a new texture buffer. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.

### size_bytes :: int

### format :: int

### data :: PackedByteArray

## texture_clear :: func RenderingDevice.texture_clear(texture: RID, color: Color, base_mipmap: int, mipmap_count: int, base_layer: int, layer_count: int) -> int
Clears the specified [param texture] by replacing all of its pixels with the specified [param color]. [param base_mipmap] and [param mipmap_count] determine which mipmaps of the texture are affected by this clear operation, while [param base_layer] and [param layer_count] determine which layers of a 3D texture (or texture array) are affected by this clear operation. For 2D textures (which only have one layer by design), [param base_layer] must be [code]0[/code] and [param layer_count] must be [code]1[/code].
[b]Note:[/b] [param texture] can't be cleared while a draw list that uses it as part of a framebuffer is being created. Ensure the draw list is finalized (and that the color/depth texture using it is not set to [constant FINAL_ACTION_CONTINUE]) to clear this texture.

### texture :: RID

### color :: Color

### base_mipmap :: int

### mipmap_count :: int

### base_layer :: int

### layer_count :: int

## texture_copy :: func RenderingDevice.texture_copy(from_texture: RID, to_texture: RID, from_pos: Vector3, to_pos: Vector3, size: Vector3, src_mipmap: int, dst_mipmap: int, src_layer: int, dst_layer: int) -> int
Copies the [param from_texture] to [param to_texture] with the specified [param from_pos], [param to_pos] and [param size] coordinates. For 2-dimensional textures, [param from_pos] and [param to_pos] must have a Z axis of [code]0[/code], and [param size] must have a Z axis of [code]1[/code]. Source and destination mipmaps/layers must also be specified, with these parameters being [code]0[/code] for textures without mipmaps or single-layer textures. Returns [constant @GlobalScope.OK] if the texture copy was successful or [constant @GlobalScope.ERR_INVALID_PARAMETER] otherwise.
[b]Note:[/b] [param from_texture] texture can't be copied while a draw list that uses it as part of a framebuffer is being created. Ensure the draw list is finalized (and that the color/depth texture using it is not set to [constant FINAL_ACTION_CONTINUE]) to copy this texture.
[b]Note:[/b] [param from_texture] texture requires the [constant TEXTURE_USAGE_CAN_COPY_FROM_BIT] to be retrieved.
[b]Note:[/b] [param to_texture] can't be copied while a draw list that uses it as part of a framebuffer is being created. Ensure the draw list is finalized (and that the color/depth texture using it is not set to [constant FINAL_ACTION_CONTINUE]) to copy this texture.
[b]Note:[/b] [param to_texture] requires the [constant TEXTURE_USAGE_CAN_COPY_TO_BIT] to be retrieved.
[b]Note:[/b] [param from_texture] and [param to_texture] must be of the same type (color or depth).

### from_texture :: RID

### to_texture :: RID

### from_pos :: Vector3

### to_pos :: Vector3

### size :: Vector3

### src_mipmap :: int

### dst_mipmap :: int

### src_layer :: int

### dst_layer :: int

## texture_create :: func RenderingDevice.texture_create(format: RDTextureFormat, view: RDTextureView, data: PackedByteArray[] = []) -> RID
Creates a new texture. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.
[b]Note:[/b] [param data] takes an [Array] of [PackedByteArray]s. For [constant TEXTURE_TYPE_1D], [constant TEXTURE_TYPE_2D], and [constant TEXTURE_TYPE_3D] types, this array should only have one element, a [PackedByteArray] containing all the data for the texture. For [code]_ARRAY[/code] and [code]_CUBE[/code] types, the length should be the same as the number of [member RDTextureFormat.array_layers] in [param format].
[b]Note:[/b] Not to be confused with [method RenderingServer.texture_2d_create], which creates the Godot-specific [Texture2D] resource as opposed to the graphics API's own texture type.

### format :: RDTextureFormat

### view :: RDTextureView

### data :: PackedByteArray[]

## texture_create_from_extension :: func RenderingDevice.texture_create_from_extension(type: int, format: int, samples: int, usage_flags: int, image: int, width: int, height: int, depth: int, layers: int, mipmaps: int = 1) -> RID
Returns an RID for an existing [param image] ([code]VkImage[/code]) with the given [param type], [param format], [param samples], [param usage_flags], [param width], [param height], [param depth], [param layers], and [param mipmaps]. This can be used to allow Godot to render onto foreign images.

### type :: int

### format :: int

### samples :: int

### usage_flags :: int

### image :: int

### width :: int

### height :: int

### depth :: int

### layers :: int

### mipmaps :: int

## texture_create_shared :: func RenderingDevice.texture_create_shared(view: RDTextureView, with_texture: RID) -> RID
Creates a shared texture using the specified [param view] and the texture information from [param with_texture].
This will be freed automatically when the [param with_texture] is freed.

### view :: RDTextureView

### with_texture :: RID

## texture_create_shared_from_slice :: func RenderingDevice.texture_create_shared_from_slice(view: RDTextureView, with_texture: RID, layer: int, mipmap: int, mipmaps: int = 1, slice_type: int = 0) -> RID
Creates a shared texture using the specified [param view] and the texture information from [param with_texture]'s [param layer] and [param mipmap]. The number of included mipmaps from the original texture can be controlled using the [param mipmaps] parameter. Only relevant for textures with multiple layers, such as 3D textures, texture arrays and cubemaps. For single-layer textures, use [method texture_create_shared].
For 2D textures (which only have one layer), [param layer] must be [code]0[/code].
[b]Note:[/b] Layer slicing is only supported for 2D texture arrays, not 3D textures or cubemaps.
This will be freed automatically when the [param with_texture] is freed.

### view :: RDTextureView

### with_texture :: RID

### layer :: int

### mipmap :: int

### mipmaps :: int

### slice_type :: int

## texture_get_data :: func RenderingDevice.texture_get_data(texture: RID, layer: int) -> PackedByteArray
Returns the [param texture] data for the specified [param layer] as raw binary data. For 2D textures (which only have one layer), [param layer] must be [code]0[/code].
[b]Note:[/b] [param texture] can't be retrieved while a draw list that uses it as part of a framebuffer is being created. Ensure the draw list is finalized (and that the color/depth texture using it is not set to [constant FINAL_ACTION_CONTINUE]) to retrieve this texture. Otherwise, an error is printed and an empty [PackedByteArray] is returned.
[b]Note:[/b] [param texture] requires the [constant TEXTURE_USAGE_CAN_COPY_FROM_BIT] to be retrieved. Otherwise, an error is printed and an empty [PackedByteArray] is returned.
[b]Note:[/b] This method will block the GPU from working until the data is retrieved. Refer to [method texture_get_data_async] for an alternative that returns the data in more performant way.

### texture :: RID

### layer :: int

## texture_get_data_async :: func RenderingDevice.texture_get_data_async(texture: RID, layer: int, callback: Callable) -> int
Asynchronous version of [method texture_get_data]. RenderingDevice will call [param callback] in a certain amount of frames with the data the texture had at the time of the request.
[b]Note:[/b] At the moment, the delay corresponds to the amount of frames specified by [member ProjectSettings.rendering/rendering_device/vsync/frame_queue_size].
[b]Note:[/b] Downloading large textures can have a prohibitive cost for real-time even when using the asynchronous method due to hardware bandwidth limitations. When dealing with large resources, you can adjust settings such as [member ProjectSettings.rendering/rendering_device/staging_buffer/texture_download_region_size_px] and [member ProjectSettings.rendering/rendering_device/staging_buffer/block_size_kb] to improve the transfer speed at the cost of extra memory.
[codeblock]
func _texture_get_data_callback(array):
	value = array.decode_u32(0)

...

rd.texture_get_data_async(texture, 0, _texture_get_data_callback)
[/codeblock]

### texture :: RID

### layer :: int

### callback :: Callable

## texture_get_format :: func RenderingDevice.texture_get_format(texture: RID) -> RDTextureFormat
Returns the data format used to create this texture.

### texture :: RID

## texture_get_native_handle :: func RenderingDevice.texture_get_native_handle(texture: RID) -> int
Returns the internal graphics handle for this texture object. For use when communicating with third-party APIs mostly with GDExtension.
[b]Note:[/b] This function returns a [code]uint64_t[/code] which internally maps to a [code]GLuint[/code] (OpenGL) or [code]VkImage[/code] (Vulkan).

### texture :: RID

## texture_is_discardable :: func RenderingDevice.texture_is_discardable(texture: RID) -> bool
Returns [code]true[/code] if the [param texture] is discardable, [code]false[/code] otherwise. See [RDTextureFormat] or [method texture_set_discardable].

### texture :: RID

## texture_is_format_supported_for_usage :: func RenderingDevice.texture_is_format_supported_for_usage(format: int, usage_flags: int) -> bool
Returns [code]true[/code] if the specified [param format] is supported for the given [param usage_flags], [code]false[/code] otherwise.

### format :: int

### usage_flags :: int

## texture_is_shared :: func RenderingDevice.texture_is_shared(texture: RID) -> bool
Returns [code]true[/code] if the [param texture] is shared, [code]false[/code] otherwise. See [RDTextureView].

### texture :: RID

## texture_is_valid :: func RenderingDevice.texture_is_valid(texture: RID) -> bool
Returns [code]true[/code] if the [param texture] is valid, [code]false[/code] otherwise.

### texture :: RID

## texture_resolve_multisample :: func RenderingDevice.texture_resolve_multisample(from_texture: RID, to_texture: RID) -> int
Resolves the [param from_texture] texture onto [param to_texture] with multisample antialiasing enabled. This must be used when rendering a framebuffer for MSAA to work. Returns [constant @GlobalScope.OK] if successful, [constant @GlobalScope.ERR_INVALID_PARAMETER] otherwise.
[b]Note:[/b] [param from_texture] and [param to_texture] textures must have the same dimension, format and type (color or depth).
[b]Note:[/b] [param from_texture] can't be copied while a draw list that uses it as part of a framebuffer is being created. Ensure the draw list is finalized (and that the color/depth texture using it is not set to [constant FINAL_ACTION_CONTINUE]) to resolve this texture.
[b]Note:[/b] [param from_texture] requires the [constant TEXTURE_USAGE_CAN_COPY_FROM_BIT] to be retrieved.
[b]Note:[/b] [param from_texture] must be multisampled and must also be 2D (or a slice of a 3D/cubemap texture).
[b]Note:[/b] [param to_texture] can't be copied while a draw list that uses it as part of a framebuffer is being created. Ensure the draw list is finalized (and that the color/depth texture using it is not set to [constant FINAL_ACTION_CONTINUE]) to resolve this texture.
[b]Note:[/b] [param to_texture] texture requires the [constant TEXTURE_USAGE_CAN_COPY_TO_BIT] to be retrieved.
[b]Note:[/b] [param to_texture] texture must [b]not[/b] be multisampled and must also be 2D (or a slice of a 3D/cubemap texture).

### from_texture :: RID

### to_texture :: RID

## texture_set_discardable :: func RenderingDevice.texture_set_discardable(texture: RID, discardable: bool) -> void
Updates the discardable property of [param texture].
If a texture is discardable, its contents do not need to be preserved between frames. This flag is only relevant when the texture is used as target in a draw list.
This information is used by [RenderingDevice] to figure out if a texture's contents can be discarded, eliminating unnecessary writes to memory and boosting performance.

### texture :: RID

### discardable :: bool

## texture_update :: func RenderingDevice.texture_update(texture: RID, layer: int, data: PackedByteArray) -> int
Updates texture data with new data, replacing the previous data in place. The updated texture data must have the same dimensions and format. For 2D textures (which only have one layer), [param layer] must be [code]0[/code]. Returns [constant @GlobalScope.OK] if the update was successful, [constant @GlobalScope.ERR_INVALID_PARAMETER] otherwise.
[b]Note:[/b] Updating textures is forbidden during creation of a draw or compute list.
[b]Note:[/b] The existing [param texture] can't be updated while a draw list that uses it as part of a framebuffer is being created. Ensure the draw list is finalized (and that the color/depth texture using it is not set to [constant FINAL_ACTION_CONTINUE]) to update this texture.
[b]Note:[/b] The existing [param texture] requires the [constant TEXTURE_USAGE_CAN_UPDATE_BIT] to be updatable.

### texture :: RID

### layer :: int

### data :: PackedByteArray

## tlas_build :: func RenderingDevice.tlas_build(tlas: RID, instances: RDAccelerationStructureInstance[]) -> int
Builds the [param tlas]. The contents of previous builds are discarded.
Any BLAS provided through the [member RDAccelerationStructureInstance.blas] member must already have been built using the [method blas_build] method.
The number of instances can be equal to or smaller than the maximum instance count provided in the [method tlas_create] method.
[b]Note:[/b] Freeing or rebuilding any of the provided BLASes after this method invalidates the TLAS and requires it to be rebuilt.

### tlas :: RID

### instances :: RDAccelerationStructureInstance[]

## tlas_create :: func RenderingDevice.tlas_create(max_instance_count: int, flags: int) -> RID
Creates a new Top-Level Acceleration Structure (TLAS). It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.

### max_instance_count :: int

### flags :: int

## uniform_buffer_create :: func RenderingDevice.uniform_buffer_create(size_bytes: int, data: PackedByteArray = PackedByteArray(), creation_bits: int = 0) -> RID
Creates a new uniform buffer. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.

### size_bytes :: int

### data :: PackedByteArray

### creation_bits :: int

## uniform_set_create :: func RenderingDevice.uniform_set_create(uniforms: RDUniform[], shader: RID, shader_set: int) -> RID
Creates a new uniform set. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.
This will be freed automatically when the [param shader] or any of the RIDs in the [param uniforms] is freed.

### uniforms :: RDUniform[]

### shader :: RID

### shader_set :: int

## uniform_set_is_valid :: func RenderingDevice.uniform_set_is_valid(uniform_set: RID) -> bool
Checks if the [param uniform_set] is valid, i.e. is owned.

### uniform_set :: RID

## vertex_array_create :: func RenderingDevice.vertex_array_create(vertex_count: int, vertex_format: int, src_buffers: RID[], offsets: PackedInt64Array = PackedInt64Array()) -> RID
Creates a vertex array based on the specified buffers. Optionally, [param offsets] (in bytes) may be defined for each buffer.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.
This will be freed automatically when any of the [param src_buffers] is freed.

### vertex_count :: int

### vertex_format :: int

### src_buffers :: RID[]

### offsets :: PackedInt64Array

## vertex_buffer_create :: func RenderingDevice.vertex_buffer_create(size_bytes: int, data: PackedByteArray = PackedByteArray(), creation_bits: int = 0) -> RID
Creates a new vertex buffer. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingDevice's [method free_rid] method.

### size_bytes :: int

### data :: PackedByteArray

### creation_bits :: int

## vertex_format_create :: func RenderingDevice.vertex_format_create(vertex_descriptions: RDVertexAttribute[]) -> int
Creates a new vertex format with the specified [param vertex_descriptions]. Returns a unique vertex format ID corresponding to the newly created vertex format.

### vertex_descriptions :: RDVertexAttribute[]
