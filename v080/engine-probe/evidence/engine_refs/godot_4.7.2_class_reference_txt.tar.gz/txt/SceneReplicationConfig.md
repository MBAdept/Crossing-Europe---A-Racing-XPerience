# SceneReplicationConfig :: <Native> class SceneReplicationConfig extends Resource
Configuration for properties to synchronize with a [MultiplayerSynchronizer].

## REPLICATION_MODE_NEVER :: const SceneReplicationConfig.REPLICATION_MODE_NEVER: ReplicationMode = 0
Do not keep the given property synchronized.

## REPLICATION_MODE_ALWAYS :: const SceneReplicationConfig.REPLICATION_MODE_ALWAYS: ReplicationMode = 1
Replicate the given property on process by constantly sending updates using unreliable transfer mode.

## REPLICATION_MODE_ON_CHANGE :: const SceneReplicationConfig.REPLICATION_MODE_ON_CHANGE: ReplicationMode = 2
Replicate the given property on process by sending updates using reliable transfer mode when its value changes.

## add_property :: func SceneReplicationConfig.add_property(path: NodePath, index: int = -1) -> void
Adds the property identified by the given [param path] to the list of the properties being synchronized, optionally passing an [param index].
[b]Note:[/b] For details on restrictions and limitations on property synchronization, see [MultiplayerSynchronizer].

### path :: NodePath

### index :: int

## get_properties :: func SceneReplicationConfig.get_properties() -> NodePath[]
Returns a list of synchronized property [NodePath]s.

## has_property :: func SceneReplicationConfig.has_property(path: NodePath) -> bool
Returns [code]true[/code] if the given [param path] is configured for synchronization.

### path :: NodePath

## property_get_index :: func SceneReplicationConfig.property_get_index(path: NodePath) -> int
Finds the index of the given [param path].

### path :: NodePath

## property_get_replication_mode :: func SceneReplicationConfig.property_get_replication_mode(path: NodePath) -> int
Returns the replication mode for the property identified by the given [param path].

### path :: NodePath

## property_get_spawn :: func SceneReplicationConfig.property_get_spawn(path: NodePath) -> bool
Returns [code]true[/code] if the property identified by the given [param path] is configured to be synchronized on spawn.

### path :: NodePath

## property_get_sync :: func SceneReplicationConfig.property_get_sync(path: NodePath) -> bool
Returns [code]true[/code] if the property identified by the given [param path] is configured to be synchronized on process.

### path :: NodePath

## property_get_watch :: func SceneReplicationConfig.property_get_watch(path: NodePath) -> bool
Returns [code]true[/code] if the property identified by the given [param path] is configured to be reliably synchronized when changes are detected on process.

### path :: NodePath

## property_set_replication_mode :: func SceneReplicationConfig.property_set_replication_mode(path: NodePath, mode: int) -> void
Sets the synchronization mode for the property identified by the given [param path].

### path :: NodePath

### mode :: int

## property_set_spawn :: func SceneReplicationConfig.property_set_spawn(path: NodePath, enabled: bool) -> void
Sets whether the property identified by the given [param path] is configured to be synchronized on spawn.

### path :: NodePath

### enabled :: bool

## property_set_sync :: func SceneReplicationConfig.property_set_sync(path: NodePath, enabled: bool) -> void
Sets whether the property identified by the given [param path] is configured to be synchronized on process.

### path :: NodePath

### enabled :: bool

## property_set_watch :: func SceneReplicationConfig.property_set_watch(path: NodePath, enabled: bool) -> void
Sets whether the property identified by the given [param path] is configured to be reliably synchronized when changes are detected on process.

### path :: NodePath

### enabled :: bool

## remove_property :: func SceneReplicationConfig.remove_property(path: NodePath) -> void
Removes the property identified by the given [param path] from the configuration.

### path :: NodePath
