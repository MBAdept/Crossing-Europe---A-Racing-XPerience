# CPUParticles2D :: <Native> class CPUParticles2D extends Node2D
A CPU-based 2D particle emitter.
CPU-based 2D particle node used to create a variety of particle systems and effects.
See also [GPUParticles2D], which provides the same functionality with hardware acceleration, but may not run on older devices.

## DRAW_ORDER_INDEX :: const CPUParticles2D.DRAW_ORDER_INDEX: DrawOrder = 0
Particles are drawn in the order emitted.

## DRAW_ORDER_LIFETIME :: const CPUParticles2D.DRAW_ORDER_LIFETIME: DrawOrder = 1
Particles are drawn in order of remaining lifetime. In other words, the particle with the highest lifetime is drawn at the front.

## PARAM_INITIAL_LINEAR_VELOCITY :: const CPUParticles2D.PARAM_INITIAL_LINEAR_VELOCITY: Parameter = 0
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set initial velocity properties.

## PARAM_ANGULAR_VELOCITY :: const CPUParticles2D.PARAM_ANGULAR_VELOCITY: Parameter = 1
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set angular velocity properties.

## PARAM_ORBIT_VELOCITY :: const CPUParticles2D.PARAM_ORBIT_VELOCITY: Parameter = 2
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set orbital velocity properties.

## PARAM_LINEAR_ACCEL :: const CPUParticles2D.PARAM_LINEAR_ACCEL: Parameter = 3
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set linear acceleration properties.

## PARAM_RADIAL_ACCEL :: const CPUParticles2D.PARAM_RADIAL_ACCEL: Parameter = 4
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set radial acceleration properties.

## PARAM_TANGENTIAL_ACCEL :: const CPUParticles2D.PARAM_TANGENTIAL_ACCEL: Parameter = 5
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set tangential acceleration properties.

## PARAM_DAMPING :: const CPUParticles2D.PARAM_DAMPING: Parameter = 6
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set damping properties.

## PARAM_ANGLE :: const CPUParticles2D.PARAM_ANGLE: Parameter = 7
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set angle properties.

## PARAM_SCALE :: const CPUParticles2D.PARAM_SCALE: Parameter = 8
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set scale properties.

## PARAM_HUE_VARIATION :: const CPUParticles2D.PARAM_HUE_VARIATION: Parameter = 9
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set hue variation properties.

## PARAM_ANIM_SPEED :: const CPUParticles2D.PARAM_ANIM_SPEED: Parameter = 10
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set animation speed properties.

## PARAM_ANIM_OFFSET :: const CPUParticles2D.PARAM_ANIM_OFFSET: Parameter = 11
Use with [method set_param_min], [method set_param_max], and [method set_param_curve] to set animation offset properties.

## PARAM_MAX :: const CPUParticles2D.PARAM_MAX: Parameter = 12
Represents the size of the [enum Parameter] enum.

## PARTICLE_FLAG_ALIGN_Y_TO_VELOCITY :: const CPUParticles2D.PARTICLE_FLAG_ALIGN_Y_TO_VELOCITY: ParticleFlags = 0
Use with [method set_particle_flag] to set [member particle_flag_align_y].

## PARTICLE_FLAG_ROTATE_Y :: const CPUParticles2D.PARTICLE_FLAG_ROTATE_Y: ParticleFlags = 1
Present for consistency with 3D particle nodes, not used in 2D.

## PARTICLE_FLAG_DISABLE_Z :: const CPUParticles2D.PARTICLE_FLAG_DISABLE_Z: ParticleFlags = 2
Present for consistency with 3D particle nodes, not used in 2D.

## PARTICLE_FLAG_MAX :: const CPUParticles2D.PARTICLE_FLAG_MAX: ParticleFlags = 3
Represents the size of the [enum ParticleFlags] enum.

## EMISSION_SHAPE_POINT :: const CPUParticles2D.EMISSION_SHAPE_POINT: EmissionShape = 0
All particles will be emitted from a single point.

## EMISSION_SHAPE_SPHERE :: const CPUParticles2D.EMISSION_SHAPE_SPHERE: EmissionShape = 1
Particles will be emitted in the volume of a sphere flattened to two dimensions.

## EMISSION_SHAPE_SPHERE_SURFACE :: const CPUParticles2D.EMISSION_SHAPE_SPHERE_SURFACE: EmissionShape = 2
Particles will be emitted on the surface of a sphere flattened to two dimensions.

## EMISSION_SHAPE_RECTANGLE :: const CPUParticles2D.EMISSION_SHAPE_RECTANGLE: EmissionShape = 3
Particles will be emitted in the area of a rectangle.

## EMISSION_SHAPE_POINTS :: const CPUParticles2D.EMISSION_SHAPE_POINTS: EmissionShape = 4
Particles will be emitted at a position chosen randomly among [member emission_points]. Particle color will be modulated by [member emission_colors].

## EMISSION_SHAPE_DIRECTED_POINTS :: const CPUParticles2D.EMISSION_SHAPE_DIRECTED_POINTS: EmissionShape = 5
Particles will be emitted at a position chosen randomly among [member emission_points]. Particle velocity and rotation will be set based on [member emission_normals]. Particle color will be modulated by [member emission_colors].

## EMISSION_SHAPE_RING :: const CPUParticles2D.EMISSION_SHAPE_RING: EmissionShape = 6
Particles will be emitted in the area of a ring parameterized by its outer and inner radius.

## EMISSION_SHAPE_MAX :: const CPUParticles2D.EMISSION_SHAPE_MAX: EmissionShape = 7
Represents the size of the [enum EmissionShape] enum.

## amount :: var CPUParticles2D.amount: int
Number of particles emitted in one emission cycle.

## angle_curve :: var CPUParticles2D.angle_curve: Curve
Each particle's rotation will be animated along this [Curve]. Should be a unit [Curve].

## angle_max :: var CPUParticles2D.angle_max: float
Maximum initial rotation applied to each particle, in degrees.

## angle_min :: var CPUParticles2D.angle_min: float
Minimum equivalent of [member angle_max].

## angular_velocity_curve :: var CPUParticles2D.angular_velocity_curve: Curve
Each particle's angular velocity will vary along this [Curve]. Should be a unit [Curve].

## angular_velocity_max :: var CPUParticles2D.angular_velocity_max: float
Maximum initial angular velocity (rotation speed) applied to each particle in [i]degrees[/i] per second.

## angular_velocity_min :: var CPUParticles2D.angular_velocity_min: float
Minimum equivalent of [member angular_velocity_max].

## anim_offset_curve :: var CPUParticles2D.anim_offset_curve: Curve
Each particle's animation offset will vary along this [Curve]. Should be a unit [Curve].

## anim_offset_max :: var CPUParticles2D.anim_offset_max: float
Maximum animation offset that corresponds to frame index in the texture. [code]0[/code] is the first frame, [code]1[/code] is the last one. See [member CanvasItemMaterial.particles_animation].

## anim_offset_min :: var CPUParticles2D.anim_offset_min: float
Minimum equivalent of [member anim_offset_max].

## anim_speed_curve :: var CPUParticles2D.anim_speed_curve: Curve
Each particle's animation speed will vary along this [Curve]. Should be a unit [Curve].

## anim_speed_max :: var CPUParticles2D.anim_speed_max: float
Maximum particle animation speed. Animation speed of [code]1[/code] means that the particles will make full [code]0[/code] to [code]1[/code] offset cycle during lifetime, [code]2[/code] means [code]2[/code] cycles etc.
With animation speed greater than [code]1[/code], remember to enable [member CanvasItemMaterial.particles_anim_loop] property if you want the animation to repeat.

## anim_speed_min :: var CPUParticles2D.anim_speed_min: float
Minimum equivalent of [member anim_speed_max].

## color :: var CPUParticles2D.color: Color
Each particle's initial color. If [member texture] is defined, it will be multiplied by this color.

## color_initial_ramp :: var CPUParticles2D.color_initial_ramp: Gradient
Each particle's initial color will vary along this [Gradient] (multiplied with [member color]).

## color_ramp :: var CPUParticles2D.color_ramp: Gradient
Each particle's color will vary along this [Gradient] over its lifetime (multiplied with [member color]).

## damping_curve :: var CPUParticles2D.damping_curve: Curve
Damping will vary along this [Curve]. Should be a unit [Curve].

## damping_max :: var CPUParticles2D.damping_max: float
The maximum rate at which particles lose velocity. For example value of [code]100[/code] means that the particle will go from [code]100[/code] velocity to [code]0[/code] in [code]1[/code] second.

## damping_min :: var CPUParticles2D.damping_min: float
Minimum equivalent of [member damping_max].

## direction :: var CPUParticles2D.direction: Vector2
Unit vector specifying the particles' emission direction.

## draw_order :: var CPUParticles2D.draw_order: CPUParticles2D.DrawOrder
Particle draw order.

## emission_colors :: var CPUParticles2D.emission_colors: PackedColorArray
Sets the [Color]s to modulate particles by when using [constant EMISSION_SHAPE_POINTS] or [constant EMISSION_SHAPE_DIRECTED_POINTS].

## emission_normals :: var CPUParticles2D.emission_normals: PackedVector2Array
Sets the direction the particles will be emitted in when using [constant EMISSION_SHAPE_DIRECTED_POINTS].

## emission_points :: var CPUParticles2D.emission_points: PackedVector2Array
Sets the initial positions to spawn particles when using [constant EMISSION_SHAPE_POINTS] or [constant EMISSION_SHAPE_DIRECTED_POINTS].

## emission_rect_extents :: var CPUParticles2D.emission_rect_extents: Vector2
The rectangle's extents if [member emission_shape] is set to [constant EMISSION_SHAPE_RECTANGLE].

## emission_ring_inner_radius :: var CPUParticles2D.emission_ring_inner_radius: float
The ring's inner radius if [member emission_shape] is set to [constant EMISSION_SHAPE_RING].

## emission_ring_radius :: var CPUParticles2D.emission_ring_radius: float
The ring's outer radius if [member emission_shape] is set to [constant EMISSION_SHAPE_RING].

## emission_shape :: var CPUParticles2D.emission_shape: CPUParticles2D.EmissionShape
Particles will be emitted inside this region.

## emission_sphere_radius :: var CPUParticles2D.emission_sphere_radius: float
The sphere's radius if [member emission_shape] is set to [constant EMISSION_SHAPE_SPHERE].

## emitting :: var CPUParticles2D.emitting: bool
If [code]true[/code], particles are being emitted. [member emitting] can be used to start and stop particles from emitting. However, if [member one_shot] is [code]true[/code] setting [member emitting] to [code]true[/code] will not restart the emission cycle until after all active particles finish processing. You can use the [signal finished] signal to be notified once all active particles finish processing.

## explosiveness :: var CPUParticles2D.explosiveness: float
How rapidly particles in an emission cycle are emitted. If greater than [code]0[/code], there will be a gap in emissions before the next cycle begins.

## fixed_fps :: var CPUParticles2D.fixed_fps: int
The particle system's frame rate is fixed to a value. For example, changing the value to 2 will make the particles render at 2 frames per second. Note this does not slow down the simulation of the particle system itself.

## fract_delta :: var CPUParticles2D.fract_delta: bool
If [code]true[/code], results in fractional delta calculation which has a smoother particles display effect.

## gravity :: var CPUParticles2D.gravity: Vector2
Gravity applied to every particle.

## hue_variation_curve :: var CPUParticles2D.hue_variation_curve: Curve
Each particle's hue will vary along this [Curve]. Should be a unit [Curve].

## hue_variation_max :: var CPUParticles2D.hue_variation_max: float
Maximum initial hue variation applied to each particle. It will shift the particle color's hue.

## hue_variation_min :: var CPUParticles2D.hue_variation_min: float
Minimum equivalent of [member hue_variation_max].

## initial_velocity_max :: var CPUParticles2D.initial_velocity_max: float
Maximum initial velocity magnitude for each particle. Direction comes from [member direction] and [member spread].

## initial_velocity_min :: var CPUParticles2D.initial_velocity_min: float
Minimum equivalent of [member initial_velocity_max].

## lifetime :: var CPUParticles2D.lifetime: float
Amount of time each particle will exist.

## lifetime_randomness :: var CPUParticles2D.lifetime_randomness: float
Particle lifetime randomness ratio.

## linear_accel_curve :: var CPUParticles2D.linear_accel_curve: Curve
Each particle's linear acceleration will vary along this [Curve]. Should be a unit [Curve].

## linear_accel_max :: var CPUParticles2D.linear_accel_max: float
Maximum linear acceleration applied to each particle in the direction of motion.

## linear_accel_min :: var CPUParticles2D.linear_accel_min: float
Minimum equivalent of [member linear_accel_max].

## local_coords :: var CPUParticles2D.local_coords: bool
If [code]true[/code], particles use the parent node's coordinate space (known as local coordinates). This will cause particles to move and rotate along the [CPUParticles2D] node (and its parents) when it is moved or rotated. If [code]false[/code], particles use global coordinates; they will not move or rotate along the [CPUParticles2D] node (and its parents) when it is moved or rotated.

## one_shot :: var CPUParticles2D.one_shot: bool
If [code]true[/code], only one emission cycle occurs. If set [code]true[/code] during a cycle, emission will stop at the cycle's end.

## orbit_velocity_curve :: var CPUParticles2D.orbit_velocity_curve: Curve
Each particle's orbital velocity will vary along this [Curve]. Should be a unit [Curve].

## orbit_velocity_max :: var CPUParticles2D.orbit_velocity_max: float
Maximum orbital velocity applied to each particle. Makes the particles circle around origin. Specified in number of full rotations around origin per second.

## orbit_velocity_min :: var CPUParticles2D.orbit_velocity_min: float
Minimum equivalent of [member orbit_velocity_max].

## particle_flag_align_y :: var CPUParticles2D.particle_flag_align_y: bool
Align Y axis of particle with the direction of its velocity.

## physics_interpolation_mode :: var CPUParticles2D.physics_interpolation_mode: Node.PhysicsInterpolationMode

## preprocess :: var CPUParticles2D.preprocess: float
Particle system starts as if it had already run for this many seconds.

## radial_accel_curve :: var CPUParticles2D.radial_accel_curve: Curve
Each particle's radial acceleration will vary along this [Curve]. Should be a unit [Curve].

## radial_accel_max :: var CPUParticles2D.radial_accel_max: float
Maximum radial acceleration applied to each particle. Makes particle accelerate away from the origin or towards it if negative.

## radial_accel_min :: var CPUParticles2D.radial_accel_min: float
Minimum equivalent of [member radial_accel_max].

## randomness :: var CPUParticles2D.randomness: float
Emission lifetime randomness ratio.

## scale_amount_curve :: var CPUParticles2D.scale_amount_curve: Curve
Each particle's scale will vary along this [Curve]. Should be a unit [Curve].

## scale_amount_max :: var CPUParticles2D.scale_amount_max: float
Maximum initial scale applied to each particle.

## scale_amount_min :: var CPUParticles2D.scale_amount_min: float
Minimum equivalent of [member scale_amount_max].

## scale_curve_x :: var CPUParticles2D.scale_curve_x: Curve
Each particle's horizontal scale will vary along this [Curve]. Should be a unit [Curve].
[member split_scale] must be enabled.

## scale_curve_y :: var CPUParticles2D.scale_curve_y: Curve
Each particle's vertical scale will vary along this [Curve]. Should be a unit [Curve].
[member split_scale] must be enabled.

## seed :: var CPUParticles2D.seed: int
Sets the random seed used by the particle system. Only effective if [member use_fixed_seed] is [code]true[/code].

## speed_scale :: var CPUParticles2D.speed_scale: float
Particle system's running speed scaling ratio. A value of [code]0[/code] can be used to pause the particles.

## split_scale :: var CPUParticles2D.split_scale: bool
If [code]true[/code], the scale curve will be split into x and y components. See [member scale_curve_x] and [member scale_curve_y].

## spread :: var CPUParticles2D.spread: float
Each particle's initial direction range from [code]+spread[/code] to [code]-spread[/code] degrees.

## tangential_accel_curve :: var CPUParticles2D.tangential_accel_curve: Curve
Each particle's tangential acceleration will vary along this [Curve]. Should be a unit [Curve].

## tangential_accel_max :: var CPUParticles2D.tangential_accel_max: float
Maximum tangential acceleration applied to each particle. Tangential acceleration is perpendicular to the particle's velocity giving the particles a swirling motion.

## tangential_accel_min :: var CPUParticles2D.tangential_accel_min: float
Minimum equivalent of [member tangential_accel_max].

## texture :: var CPUParticles2D.texture: Texture2D
Particle texture. If [code]null[/code], particles will be squares.

## use_fixed_seed :: var CPUParticles2D.use_fixed_seed: bool
If [code]true[/code], particles will use the same seed for every simulation using the seed defined in [member seed]. This is useful for situations where the visual outcome should be consistent across replays, for example when using Movie Maker mode.

## convert_from_particles :: func CPUParticles2D.convert_from_particles(particles: Node) -> void
Sets this node's properties to match a given [GPUParticles2D] node with an assigned [ParticleProcessMaterial].

### particles :: Node

## get_param_curve :: func CPUParticles2D.get_param_curve(param: int) -> Curve
Returns the [Curve] of the parameter specified by [enum Parameter].

### param :: int

## get_param_max :: func CPUParticles2D.get_param_max(param: int) -> float
Returns the maximum value range for the given parameter.

### param :: int

## get_param_min :: func CPUParticles2D.get_param_min(param: int) -> float
Returns the minimum value range for the given parameter.

### param :: int

## get_particle_flag :: func CPUParticles2D.get_particle_flag(particle_flag: int) -> bool
Returns the enabled state of the given particle flag.

### particle_flag :: int

## request_particles_process :: func CPUParticles2D.request_particles_process(process_time: float, process_time_residual: float = 0.0) -> void
Requests the particles to process for extra process time during a single frame.
[param process_time] defines the time that the particles will process while emitting is on. [param process_time_residual] defines the time that particles will process with emitting turned off for the simulation. When combined with [member speed_scale] set to [code]0.0[/code], this is useful to be able to seek a particle system timeline.

### process_time :: float

### process_time_residual :: float

## restart :: func CPUParticles2D.restart(keep_seed: bool = false) -> void
Restarts the particle emitter.
If [param keep_seed] is [code]true[/code], the current random seed will be preserved. Useful for seeking and playback.

### keep_seed :: bool

## set_param_curve :: func CPUParticles2D.set_param_curve(param: int, curve: Curve) -> void
Sets the [Curve] of the parameter specified by [enum Parameter]. Should be a unit [Curve].

### param :: int

### curve :: Curve

## set_param_max :: func CPUParticles2D.set_param_max(param: int, value: float) -> void
Sets the maximum value for the given parameter.

### param :: int

### value :: float

## set_param_min :: func CPUParticles2D.set_param_min(param: int, value: float) -> void
Sets the minimum value for the given parameter.

### param :: int

### value :: float

## set_particle_flag :: func CPUParticles2D.set_particle_flag(particle_flag: int, enable: bool) -> void
Enables or disables the given particle flag.

### particle_flag :: int

### enable :: bool

## finished :: func CPUParticles2D.finished() -> void
Emitted when all active particles have finished processing. When [member one_shot] is disabled, particles will process continuously, so this is never emitted.
