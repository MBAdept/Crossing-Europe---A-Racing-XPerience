# XRServer :: <Native> class XRServer extends Object
Server for AR and VR features.
The AR/VR server is the heart of our Advanced and Virtual Reality solution and handles all the processing.

## TRACKER_HEAD :: const XRServer.TRACKER_HEAD: TrackerType = 1
The tracker tracks the location of the player's head. This is usually a location centered between the player's eyes. Note that for handheld AR devices this can be the current location of the device.

## TRACKER_CONTROLLER :: const XRServer.TRACKER_CONTROLLER: TrackerType = 2
The tracker tracks the location of a controller.

## TRACKER_BASESTATION :: const XRServer.TRACKER_BASESTATION: TrackerType = 4
The tracker tracks the location of a base station.

## TRACKER_ANCHOR :: const XRServer.TRACKER_ANCHOR: TrackerType = 8
The tracker tracks the location and size of an AR anchor.

## TRACKER_HAND :: const XRServer.TRACKER_HAND: TrackerType = 16
The tracker tracks the location and joints of a hand.

## TRACKER_BODY :: const XRServer.TRACKER_BODY: TrackerType = 32
The tracker tracks the location and joints of a body.

## TRACKER_FACE :: const XRServer.TRACKER_FACE: TrackerType = 64
The tracker tracks the expressions of a face.

## TRACKER_ANY_KNOWN :: const XRServer.TRACKER_ANY_KNOWN: TrackerType = 127
Used internally to filter trackers of any known type.

## TRACKER_UNKNOWN :: const XRServer.TRACKER_UNKNOWN: TrackerType = 128
Used internally if we haven't set the tracker type yet.

## TRACKER_ANY :: const XRServer.TRACKER_ANY: TrackerType = 255
Used internally to select all trackers.

## RESET_FULL_ROTATION :: const XRServer.RESET_FULL_ROTATION: RotationMode = 0
Fully reset the orientation of the HMD. Regardless of what direction the user is looking to in the real world. The user will look dead ahead in the virtual world.

## RESET_BUT_KEEP_TILT :: const XRServer.RESET_BUT_KEEP_TILT: RotationMode = 1
Resets the orientation but keeps the tilt of the device. So if we're looking down, we keep looking down but heading will be reset.

## DONT_RESET_ROTATION :: const XRServer.DONT_RESET_ROTATION: RotationMode = 2
Does not reset the orientation of the HMD, only the position of the player gets centered.

## camera_locked_to_origin :: var XRServer.camera_locked_to_origin: bool
If set to [code]true[/code], the scene will be rendered as if the camera is locked to the [XROrigin3D].
[b]Note:[/b] This doesn't provide a very comfortable experience for users. This setting exists for doing benchmarking or automated testing, where you want to control what is rendered via code.

## primary_interface :: var XRServer.primary_interface: XRInterface
The primary [XRInterface] currently bound to the [XRServer].

## world_origin :: var XRServer.world_origin: Transform3D
The current origin of our tracking space in the virtual world. This is used by the renderer to properly position the camera with new tracking data.
[b]Note:[/b] This property is managed by the current [XROrigin3D] node. It is exposed for access from GDExtensions.

## world_scale :: var XRServer.world_scale: float
The scale of the game world compared to the real world. By default, most AR/VR platforms assume that 1 game unit corresponds to 1 real world meter.

## add_interface :: func XRServer.add_interface(interface: XRInterface) -> void
Registers an [XRInterface] object.

### interface :: XRInterface

## add_tracker :: func XRServer.add_tracker(tracker: XRTracker) -> void
Registers a new [XRTracker] that tracks a physical object.

### tracker :: XRTracker

## center_on_hmd :: func XRServer.center_on_hmd(rotation_mode: int, keep_height: bool) -> void
This is an important function to understand correctly. AR and VR platforms all handle positioning slightly differently.
For platforms that do not offer spatial tracking, our origin point [code](0, 0, 0)[/code] is the location of our HMD, but you have little control over the direction the player is facing in the real world.
For platforms that do offer spatial tracking, our origin point depends very much on the system. For OpenVR, our origin point is usually the center of the tracking space, on the ground. For other platforms, it's often the location of the tracking camera.
This method allows you to center your tracker on the location of the HMD. It will take the current location of the HMD and use that to adjust all your tracking data; in essence, realigning the real world to your player's current position in the game world.
For this method to produce usable results, tracking information must be available. This often takes a few frames after starting your game.
You should call this method after a few seconds have passed. For example, when the user requests a realignment of the display holding a designated button on a controller for a short period of time, or when implementing a teleport mechanism.

### rotation_mode :: int

### keep_height :: bool

## clear_reference_frame :: func XRServer.clear_reference_frame() -> void
Clears the reference frame that was set by previous calls to [method center_on_hmd].

## find_interface :: func XRServer.find_interface(name: String) -> XRInterface
Finds an interface by its [param name]. For example, if your project uses capabilities of an AR/VR platform, you can find the interface for that platform by name and initialize it.

### name :: String

## get_hmd_transform :: func XRServer.get_hmd_transform() -> Transform3D
Returns the primary interface's transformation.

## get_interface :: func XRServer.get_interface(idx: int) -> XRInterface
Returns the interface registered at the given [param idx] index in the list of interfaces.

### idx :: int

## get_interface_count :: func XRServer.get_interface_count() -> int
Returns the number of interfaces currently registered with the AR/VR server. If your project supports multiple AR/VR platforms, you can look through the available interface, and either present the user with a selection or simply try to initialize each interface and use the first one that returns [code]true[/code].

## get_interfaces :: func XRServer.get_interfaces() -> Dictionary[]
Returns a list of available interfaces the ID and name of each interface.

## get_reference_frame :: func XRServer.get_reference_frame() -> Transform3D
Returns the reference frame transform. Mostly used internally and exposed for GDExtension build interfaces.

## get_tracker :: func XRServer.get_tracker(tracker_name: StringName) -> XRTracker
Returns the positional tracker with the given [param tracker_name].

### tracker_name :: StringName

## get_trackers :: func XRServer.get_trackers(tracker_types: int) -> Dictionary
Returns a dictionary of trackers for [param tracker_types].

### tracker_types :: int

## remove_interface :: func XRServer.remove_interface(interface: XRInterface) -> void
Removes this [param interface].

### interface :: XRInterface

## remove_tracker :: func XRServer.remove_tracker(tracker: XRTracker) -> void
Removes this [param tracker].

### tracker :: XRTracker

## interface_added :: func XRServer.interface_added(interface_name: StringName) -> void
Emitted when a new interface has been added.

### interface_name :: StringName

## interface_removed :: func XRServer.interface_removed(interface_name: StringName) -> void
Emitted when an interface is removed.

### interface_name :: StringName

## reference_frame_changed :: func XRServer.reference_frame_changed() -> void
Emitted when the reference frame transform changes.

## tracker_added :: func XRServer.tracker_added(tracker_name: StringName, type: int) -> void
Emitted when a new tracker has been added. If you don't use a fixed number of controllers or if you're using [XRAnchor3D]s for an AR solution, it is important to react to this signal to add the appropriate [XRController3D] or [XRAnchor3D] nodes related to this new tracker.

### tracker_name :: StringName

### type :: int

## tracker_removed :: func XRServer.tracker_removed(tracker_name: StringName, type: int) -> void
Emitted when a tracker is removed. You should remove any [XRController3D] or [XRAnchor3D] points if applicable. This is not mandatory, the nodes simply become inactive and will be made active again when a new tracker becomes available (i.e. a new controller is switched on that takes the place of the previous one).

### tracker_name :: StringName

### type :: int

## tracker_updated :: func XRServer.tracker_updated(tracker_name: StringName, type: int) -> void
Emitted when an existing tracker has been updated. This can happen if the user switches controllers.

### tracker_name :: StringName

### type :: int

## world_origin_changed :: func XRServer.world_origin_changed() -> void
Emitted when the world origin transform changes.
