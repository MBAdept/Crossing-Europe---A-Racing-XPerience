# EditorSceneFormatImporter :: <Native> class EditorSceneFormatImporter extends RefCounted
Imports scenes from third-parties' 3D files.
[EditorSceneFormatImporter] allows to define an importer script for a third-party 3D format.
To use [EditorSceneFormatImporter], register it using the [method EditorPlugin.add_scene_format_importer_plugin] method first.

## IMPORT_SCENE :: const EditorSceneFormatImporter.IMPORT_SCENE: ImportFlags = 1
Unused flag (this has no effect when enabled).

## IMPORT_ANIMATION :: const EditorSceneFormatImporter.IMPORT_ANIMATION: ImportFlags = 2
Import animations from the 3D scene. When importing a scene as an [AnimationLibrary], this flag is always enabled.

## IMPORT_FAIL_ON_MISSING_DEPENDENCIES :: const EditorSceneFormatImporter.IMPORT_FAIL_ON_MISSING_DEPENDENCIES: ImportFlags = 4
Unused flag (this has no effect when enabled).

## IMPORT_GENERATE_TANGENT_ARRAYS :: const EditorSceneFormatImporter.IMPORT_GENERATE_TANGENT_ARRAYS: ImportFlags = 8
If [code]true[/code], generate vertex tangents using [url=http://www.mikktspace.com/]Mikktspace[/url] if the input meshes don't have tangent data. When possible, it's recommended to let the 3D modeling software generate tangents on export instead of relying on this option. Tangents are required for correct display of normal and height maps, along with any material/shader features that require tangents.
If you don't need material features that require tangents, disabling this can reduce output file size and speed up importing if the source 3D file doesn't contain tangents.

## IMPORT_USE_NAMED_SKIN_BINDS :: const EditorSceneFormatImporter.IMPORT_USE_NAMED_SKIN_BINDS: ImportFlags = 16
If checked, use named [Skin]s for animation. The [MeshInstance3D] node contains 3 properties of relevance here: a skeleton [NodePath] pointing to the [Skeleton3D] node (usually [code]..[/code]), a mesh, and a skin:
- The [Skeleton3D] node contains a list of bones with names, their pose and rest, a name, and a parent bone.
- The mesh is all of the raw vertex data needed to display a mesh. In terms of the mesh, it knows how vertices are weight-painted and uses some internal numbering often imported from 3D modeling software.
- The skin contains the information necessary to bind this mesh onto this Skeleton3D. For each of the internal bone IDs chosen by the 3D modeling software, it contains two things. Firstly, a matrix known as the Bind Pose Matrix, Inverse Bind Matrix, or IBM for short. Secondly, the [Skin] contains each bone's name (if this flag is enabled), or the bone's index within the [Skeleton3D] list (if this flag is disabled).
Together, this information is enough to tell Godot how to use the bone poses in the [Skeleton3D] node to render the mesh from each [MeshInstance3D]. Note that each [MeshInstance3D] may share binds, as is common in models exported from Blender, or each [MeshInstance3D] may use a separate [Skin] object, as is common in models exported from other tools such as Maya.

## IMPORT_DISCARD_MESHES_AND_MATERIALS :: const EditorSceneFormatImporter.IMPORT_DISCARD_MESHES_AND_MATERIALS: ImportFlags = 32
Ignore meshes and materials on import. When importing a scene as an [AnimationLibrary], this flag is always enabled.

## IMPORT_FORCE_DISABLE_MESH_COMPRESSION :: const EditorSceneFormatImporter.IMPORT_FORCE_DISABLE_MESH_COMPRESSION: ImportFlags = 64
If [code]true[/code], mesh compression will not be used. Consider enabling if you notice blocky artifacts in your mesh normals or UVs, or if you have meshes that are larger than a few thousand meters in each direction.

## _get_extensions :: func EditorSceneFormatImporter._get_extensions() -> PackedStringArray
Return supported file extensions for this scene importer.

## _get_import_options :: func EditorSceneFormatImporter._get_import_options(path: String) -> void
Override to add general import options. These will appear in the main import dock on the editor. Add options via [method add_import_option] and [method add_import_option_advanced].
[b]Note:[/b] All [EditorSceneFormatImporter] and [EditorScenePostImportPlugin] instances will add options for all files. It is good practice to check the file extension when [param path] is non-empty.
When the user is editing project settings, [param path] will be empty. It is recommended to add all options when [param path] is empty to allow the user to customize Import Defaults.

### path :: String

## _get_option_visibility :: func EditorSceneFormatImporter._get_option_visibility(path: String, for_animation: bool, option: String) -> Variant
Should return [code]true[/code] to show the given option, [code]false[/code] to hide the given option, or [code]null[/code] to ignore.

### path :: String

### for_animation :: bool

### option :: String

## _import_scene :: func EditorSceneFormatImporter._import_scene(path: String, flags: int, options: Dictionary) -> Object
Perform the bulk of the scene import logic here, for example using [GLTFDocument] or [FBXDocument].

### path :: String

### flags :: int

### options :: Dictionary

## add_import_option :: func EditorSceneFormatImporter.add_import_option(name: String, value: Variant) -> void
Add a specific import option (name and default value only). This function can only be called from [method _get_import_options].

### name :: String

### value :: Variant

## add_import_option_advanced :: func EditorSceneFormatImporter.add_import_option_advanced(type: int, name: String, default_value: Variant, hint: int = 0, hint_string: String = "", usage_flags: int = 6) -> void
Add a specific import option. This function can only be called from [method _get_import_options].

### type :: int

### name :: String

### default_value :: Variant

### hint :: int

### hint_string :: String

### usage_flags :: int
