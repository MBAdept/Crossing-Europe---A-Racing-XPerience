# NavigationRegion3D :: <Native> class NavigationRegion3D extends Node3D
A traversable 3D region that [NavigationAgent3D]s can use for pathfinding.
A traversable 3D region based on a [NavigationMesh] that [NavigationAgent3D]s can use for pathfinding.
Two regions can be connected to each other if they share a similar edge. You can set the minimum distance between two vertices required to connect two edges by using [method NavigationServer3D.map_set_edge_connection_margin].
[b]Note:[/b] Overlapping two regions' navigation meshes is not enough for connecting two regions. They must share a similar edge.
The cost of entering this region from another region can be controlled with the [member enter_cost] value.
[b]Note:[/b] This value is not added to the path cost when the start position is already inside this region.
The cost of traveling distances inside this region can be controlled with the [member travel_cost] multiplier.
[b]Note:[/b] This node caches changes to its properties, so if you make changes to the underlying region [RID] in [NavigationServer3D], they will not be reflected in this node's properties.

## enabled :: var NavigationRegion3D.enabled: bool
Determines if the [NavigationRegion3D] is enabled or disabled.

## enter_cost :: var NavigationRegion3D.enter_cost: float
When pathfinding enters this region's navigation mesh from another regions navigation mesh the [member enter_cost] value is added to the path distance for determining the shortest path.

## navigation_layers :: var NavigationRegion3D.navigation_layers: int
A bitfield determining all navigation layers the region belongs to. These navigation layers can be checked upon when requesting a path with [method NavigationServer3D.map_get_path].

## navigation_mesh :: var NavigationRegion3D.navigation_mesh: NavigationMesh
The [NavigationMesh] resource to use.

## travel_cost :: var NavigationRegion3D.travel_cost: float
When pathfinding moves inside this region's navigation mesh the traveled distances are multiplied with [member travel_cost] for determining the shortest path.

## use_edge_connections :: var NavigationRegion3D.use_edge_connections: bool
If enabled the navigation region will use edge connections to connect with other navigation regions within proximity of the navigation map edge connection margin.

## bake_navigation_mesh :: func NavigationRegion3D.bake_navigation_mesh(on_thread: bool = true) -> void
Bakes the [NavigationMesh]. If [param on_thread] is set to [code]true[/code] (default), the baking is done on a separate thread. Baking on separate thread is useful because navigation baking is not a cheap operation. When it is completed, it automatically sets the new [NavigationMesh]. Please note that baking on separate thread may be very slow if geometry is parsed from meshes as async access to each mesh involves heavy synchronization. Also, please note that baking on a separate thread is automatically disabled on operating systems that cannot use threads (such as Web with threads disabled).

### on_thread :: bool

## get_bounds :: func NavigationRegion3D.get_bounds() -> AABB
Returns the axis-aligned bounding box for the region's transformed navigation mesh.

## get_navigation_layer_value :: func NavigationRegion3D.get_navigation_layer_value(layer_number: int) -> bool
Returns whether or not the specified layer of the [member navigation_layers] bitmask is enabled, given a [param layer_number] between 1 and 32.

### layer_number :: int

## get_navigation_map :: func NavigationRegion3D.get_navigation_map() -> RID
Returns the current navigation map [RID] used by this region.

## get_region_rid :: func NavigationRegion3D.get_region_rid() -> RID
Returns the [RID] of this region on the [NavigationServer3D].

## get_rid :: func NavigationRegion3D.get_rid() -> RID
Returns the [RID] of this region on the [NavigationServer3D]. Combined with [method NavigationServer3D.map_get_closest_point_owner] can be used to identify the [NavigationRegion3D] closest to a point on the merged navigation map.

## is_baking :: func NavigationRegion3D.is_baking() -> bool
Returns [code]true[/code] when the [NavigationMesh] is being baked on a background thread.

## set_navigation_layer_value :: func NavigationRegion3D.set_navigation_layer_value(layer_number: int, value: bool) -> void
Based on [param value], enables or disables the specified layer in the [member navigation_layers] bitmask, given a [param layer_number] between 1 and 32.

### layer_number :: int

### value :: bool

## set_navigation_map :: func NavigationRegion3D.set_navigation_map(navigation_map: RID) -> void
Sets the [RID] of the navigation map this region should use. By default the region will automatically join the [World3D] default navigation map so this function is only required to override the default map.

### navigation_map :: RID

## bake_finished :: func NavigationRegion3D.bake_finished() -> void
Notifies when the navigation mesh bake operation is completed.

## navigation_mesh_changed :: func NavigationRegion3D.navigation_mesh_changed() -> void
Notifies when the [NavigationMesh] has changed.
