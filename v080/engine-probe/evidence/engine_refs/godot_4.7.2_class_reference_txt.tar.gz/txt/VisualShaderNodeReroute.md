# VisualShaderNodeReroute :: <Native> class VisualShaderNodeReroute extends VisualShaderNode
A node that allows rerouting a connection within the visual shader graph.
Automatically adapts its port type to the type of the incoming connection and ensures valid connections.

## get_port_type :: func VisualShaderNodeReroute.get_port_type() -> int
Returns the port type of the reroute node.
