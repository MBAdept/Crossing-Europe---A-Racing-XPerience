# XRFaceTracker :: <Native> class XRFaceTracker extends XRTracker
A tracked face.
An instance of this object represents a tracked face and its corresponding blend shapes. The blend shapes come from the [url=https://docs.vrcft.io/docs/tutorial-avatars/tutorial-avatars-extras/unified-blendshapes]Unified Expressions[/url] standard, and contain extended details and visuals for each blend shape. Additionally the [url=https://docs.vrcft.io/docs/tutorial-avatars/tutorial-avatars-extras/compatibility/overview]Tracking Standard Comparison[/url] page documents the relationship between Unified Expressions and other standards.
As face trackers are turned on they are registered with the [XRServer].

## FT_EYE_LOOK_OUT_RIGHT :: const XRFaceTracker.FT_EYE_LOOK_OUT_RIGHT: BlendShapeEntry = 0
Right eye looks outwards.

## FT_EYE_LOOK_IN_RIGHT :: const XRFaceTracker.FT_EYE_LOOK_IN_RIGHT: BlendShapeEntry = 1
Right eye looks inwards.

## FT_EYE_LOOK_UP_RIGHT :: const XRFaceTracker.FT_EYE_LOOK_UP_RIGHT: BlendShapeEntry = 2
Right eye looks upwards.

## FT_EYE_LOOK_DOWN_RIGHT :: const XRFaceTracker.FT_EYE_LOOK_DOWN_RIGHT: BlendShapeEntry = 3
Right eye looks downwards.

## FT_EYE_LOOK_OUT_LEFT :: const XRFaceTracker.FT_EYE_LOOK_OUT_LEFT: BlendShapeEntry = 4
Left eye looks outwards.

## FT_EYE_LOOK_IN_LEFT :: const XRFaceTracker.FT_EYE_LOOK_IN_LEFT: BlendShapeEntry = 5
Left eye looks inwards.

## FT_EYE_LOOK_UP_LEFT :: const XRFaceTracker.FT_EYE_LOOK_UP_LEFT: BlendShapeEntry = 6
Left eye looks upwards.

## FT_EYE_LOOK_DOWN_LEFT :: const XRFaceTracker.FT_EYE_LOOK_DOWN_LEFT: BlendShapeEntry = 7
Left eye looks downwards.

## FT_EYE_CLOSED_RIGHT :: const XRFaceTracker.FT_EYE_CLOSED_RIGHT: BlendShapeEntry = 8
Closes the right eyelid.

## FT_EYE_CLOSED_LEFT :: const XRFaceTracker.FT_EYE_CLOSED_LEFT: BlendShapeEntry = 9
Closes the left eyelid.

## FT_EYE_SQUINT_RIGHT :: const XRFaceTracker.FT_EYE_SQUINT_RIGHT: BlendShapeEntry = 10
Squeezes the right eye socket muscles.

## FT_EYE_SQUINT_LEFT :: const XRFaceTracker.FT_EYE_SQUINT_LEFT: BlendShapeEntry = 11
Squeezes the left eye socket muscles.

## FT_EYE_WIDE_RIGHT :: const XRFaceTracker.FT_EYE_WIDE_RIGHT: BlendShapeEntry = 12
Right eyelid widens beyond relaxed.

## FT_EYE_WIDE_LEFT :: const XRFaceTracker.FT_EYE_WIDE_LEFT: BlendShapeEntry = 13
Left eyelid widens beyond relaxed.

## FT_EYE_DILATION_RIGHT :: const XRFaceTracker.FT_EYE_DILATION_RIGHT: BlendShapeEntry = 14
Dilates the right eye pupil.

## FT_EYE_DILATION_LEFT :: const XRFaceTracker.FT_EYE_DILATION_LEFT: BlendShapeEntry = 15
Dilates the left eye pupil.

## FT_EYE_CONSTRICT_RIGHT :: const XRFaceTracker.FT_EYE_CONSTRICT_RIGHT: BlendShapeEntry = 16
Constricts the right eye pupil.

## FT_EYE_CONSTRICT_LEFT :: const XRFaceTracker.FT_EYE_CONSTRICT_LEFT: BlendShapeEntry = 17
Constricts the left eye pupil.

## FT_BROW_PINCH_RIGHT :: const XRFaceTracker.FT_BROW_PINCH_RIGHT: BlendShapeEntry = 18
Right eyebrow pinches in.

## FT_BROW_PINCH_LEFT :: const XRFaceTracker.FT_BROW_PINCH_LEFT: BlendShapeEntry = 19
Left eyebrow pinches in.

## FT_BROW_LOWERER_RIGHT :: const XRFaceTracker.FT_BROW_LOWERER_RIGHT: BlendShapeEntry = 20
Outer right eyebrow pulls down.

## FT_BROW_LOWERER_LEFT :: const XRFaceTracker.FT_BROW_LOWERER_LEFT: BlendShapeEntry = 21
Outer left eyebrow pulls down.

## FT_BROW_INNER_UP_RIGHT :: const XRFaceTracker.FT_BROW_INNER_UP_RIGHT: BlendShapeEntry = 22
Inner right eyebrow pulls up.

## FT_BROW_INNER_UP_LEFT :: const XRFaceTracker.FT_BROW_INNER_UP_LEFT: BlendShapeEntry = 23
Inner left eyebrow pulls up.

## FT_BROW_OUTER_UP_RIGHT :: const XRFaceTracker.FT_BROW_OUTER_UP_RIGHT: BlendShapeEntry = 24
Outer right eyebrow pulls up.

## FT_BROW_OUTER_UP_LEFT :: const XRFaceTracker.FT_BROW_OUTER_UP_LEFT: BlendShapeEntry = 25
Outer left eyebrow pulls up.

## FT_NOSE_SNEER_RIGHT :: const XRFaceTracker.FT_NOSE_SNEER_RIGHT: BlendShapeEntry = 26
Right side face sneers.

## FT_NOSE_SNEER_LEFT :: const XRFaceTracker.FT_NOSE_SNEER_LEFT: BlendShapeEntry = 27
Left side face sneers.

## FT_NASAL_DILATION_RIGHT :: const XRFaceTracker.FT_NASAL_DILATION_RIGHT: BlendShapeEntry = 28
Right side nose canal dilates.

## FT_NASAL_DILATION_LEFT :: const XRFaceTracker.FT_NASAL_DILATION_LEFT: BlendShapeEntry = 29
Left side nose canal dilates.

## FT_NASAL_CONSTRICT_RIGHT :: const XRFaceTracker.FT_NASAL_CONSTRICT_RIGHT: BlendShapeEntry = 30
Right side nose canal constricts.

## FT_NASAL_CONSTRICT_LEFT :: const XRFaceTracker.FT_NASAL_CONSTRICT_LEFT: BlendShapeEntry = 31
Left side nose canal constricts.

## FT_CHEEK_SQUINT_RIGHT :: const XRFaceTracker.FT_CHEEK_SQUINT_RIGHT: BlendShapeEntry = 32
Raises the right side cheek.

## FT_CHEEK_SQUINT_LEFT :: const XRFaceTracker.FT_CHEEK_SQUINT_LEFT: BlendShapeEntry = 33
Raises the left side cheek.

## FT_CHEEK_PUFF_RIGHT :: const XRFaceTracker.FT_CHEEK_PUFF_RIGHT: BlendShapeEntry = 34
Puffs the right side cheek.

## FT_CHEEK_PUFF_LEFT :: const XRFaceTracker.FT_CHEEK_PUFF_LEFT: BlendShapeEntry = 35
Puffs the left side cheek.

## FT_CHEEK_SUCK_RIGHT :: const XRFaceTracker.FT_CHEEK_SUCK_RIGHT: BlendShapeEntry = 36
Sucks in the right side cheek.

## FT_CHEEK_SUCK_LEFT :: const XRFaceTracker.FT_CHEEK_SUCK_LEFT: BlendShapeEntry = 37
Sucks in the left side cheek.

## FT_JAW_OPEN :: const XRFaceTracker.FT_JAW_OPEN: BlendShapeEntry = 38
Opens jawbone.

## FT_MOUTH_CLOSED :: const XRFaceTracker.FT_MOUTH_CLOSED: BlendShapeEntry = 39
Closes the mouth.

## FT_JAW_RIGHT :: const XRFaceTracker.FT_JAW_RIGHT: BlendShapeEntry = 40
Pushes jawbone right.

## FT_JAW_LEFT :: const XRFaceTracker.FT_JAW_LEFT: BlendShapeEntry = 41
Pushes jawbone left.

## FT_JAW_FORWARD :: const XRFaceTracker.FT_JAW_FORWARD: BlendShapeEntry = 42
Pushes jawbone forward.

## FT_JAW_BACKWARD :: const XRFaceTracker.FT_JAW_BACKWARD: BlendShapeEntry = 43
Pushes jawbone backward.

## FT_JAW_CLENCH :: const XRFaceTracker.FT_JAW_CLENCH: BlendShapeEntry = 44
Flexes jaw muscles.

## FT_JAW_MANDIBLE_RAISE :: const XRFaceTracker.FT_JAW_MANDIBLE_RAISE: BlendShapeEntry = 45
Raises the jawbone.

## FT_LIP_SUCK_UPPER_RIGHT :: const XRFaceTracker.FT_LIP_SUCK_UPPER_RIGHT: BlendShapeEntry = 46
Upper right lip part tucks in the mouth.

## FT_LIP_SUCK_UPPER_LEFT :: const XRFaceTracker.FT_LIP_SUCK_UPPER_LEFT: BlendShapeEntry = 47
Upper left lip part tucks in the mouth.

## FT_LIP_SUCK_LOWER_RIGHT :: const XRFaceTracker.FT_LIP_SUCK_LOWER_RIGHT: BlendShapeEntry = 48
Lower right lip part tucks in the mouth.

## FT_LIP_SUCK_LOWER_LEFT :: const XRFaceTracker.FT_LIP_SUCK_LOWER_LEFT: BlendShapeEntry = 49
Lower left lip part tucks in the mouth.

## FT_LIP_SUCK_CORNER_RIGHT :: const XRFaceTracker.FT_LIP_SUCK_CORNER_RIGHT: BlendShapeEntry = 50
Right lip corner folds into the mouth.

## FT_LIP_SUCK_CORNER_LEFT :: const XRFaceTracker.FT_LIP_SUCK_CORNER_LEFT: BlendShapeEntry = 51
Left lip corner folds into the mouth.

## FT_LIP_FUNNEL_UPPER_RIGHT :: const XRFaceTracker.FT_LIP_FUNNEL_UPPER_RIGHT: BlendShapeEntry = 52
Upper right lip part pushes into a funnel.

## FT_LIP_FUNNEL_UPPER_LEFT :: const XRFaceTracker.FT_LIP_FUNNEL_UPPER_LEFT: BlendShapeEntry = 53
Upper left lip part pushes into a funnel.

## FT_LIP_FUNNEL_LOWER_RIGHT :: const XRFaceTracker.FT_LIP_FUNNEL_LOWER_RIGHT: BlendShapeEntry = 54
Lower right lip part pushes into a funnel.

## FT_LIP_FUNNEL_LOWER_LEFT :: const XRFaceTracker.FT_LIP_FUNNEL_LOWER_LEFT: BlendShapeEntry = 55
Lower left lip part pushes into a funnel.

## FT_LIP_PUCKER_UPPER_RIGHT :: const XRFaceTracker.FT_LIP_PUCKER_UPPER_RIGHT: BlendShapeEntry = 56
Upper right lip part pushes outwards.

## FT_LIP_PUCKER_UPPER_LEFT :: const XRFaceTracker.FT_LIP_PUCKER_UPPER_LEFT: BlendShapeEntry = 57
Upper left lip part pushes outwards.

## FT_LIP_PUCKER_LOWER_RIGHT :: const XRFaceTracker.FT_LIP_PUCKER_LOWER_RIGHT: BlendShapeEntry = 58
Lower right lip part pushes outwards.

## FT_LIP_PUCKER_LOWER_LEFT :: const XRFaceTracker.FT_LIP_PUCKER_LOWER_LEFT: BlendShapeEntry = 59
Lower left lip part pushes outwards.

## FT_MOUTH_UPPER_UP_RIGHT :: const XRFaceTracker.FT_MOUTH_UPPER_UP_RIGHT: BlendShapeEntry = 60
Upper right part of the lip pulls up.

## FT_MOUTH_UPPER_UP_LEFT :: const XRFaceTracker.FT_MOUTH_UPPER_UP_LEFT: BlendShapeEntry = 61
Upper left part of the lip pulls up.

## FT_MOUTH_LOWER_DOWN_RIGHT :: const XRFaceTracker.FT_MOUTH_LOWER_DOWN_RIGHT: BlendShapeEntry = 62
Lower right part of the lip pulls up.

## FT_MOUTH_LOWER_DOWN_LEFT :: const XRFaceTracker.FT_MOUTH_LOWER_DOWN_LEFT: BlendShapeEntry = 63
Lower left part of the lip pulls up.

## FT_MOUTH_UPPER_DEEPEN_RIGHT :: const XRFaceTracker.FT_MOUTH_UPPER_DEEPEN_RIGHT: BlendShapeEntry = 64
Upper right lip part pushes in the cheek.

## FT_MOUTH_UPPER_DEEPEN_LEFT :: const XRFaceTracker.FT_MOUTH_UPPER_DEEPEN_LEFT: BlendShapeEntry = 65
Upper left lip part pushes in the cheek.

## FT_MOUTH_UPPER_RIGHT :: const XRFaceTracker.FT_MOUTH_UPPER_RIGHT: BlendShapeEntry = 66
Moves upper lip right.

## FT_MOUTH_UPPER_LEFT :: const XRFaceTracker.FT_MOUTH_UPPER_LEFT: BlendShapeEntry = 67
Moves upper lip left.

## FT_MOUTH_LOWER_RIGHT :: const XRFaceTracker.FT_MOUTH_LOWER_RIGHT: BlendShapeEntry = 68
Moves lower lip right.

## FT_MOUTH_LOWER_LEFT :: const XRFaceTracker.FT_MOUTH_LOWER_LEFT: BlendShapeEntry = 69
Moves lower lip left.

## FT_MOUTH_CORNER_PULL_RIGHT :: const XRFaceTracker.FT_MOUTH_CORNER_PULL_RIGHT: BlendShapeEntry = 70
Right lip corner pulls diagonally up and out.

## FT_MOUTH_CORNER_PULL_LEFT :: const XRFaceTracker.FT_MOUTH_CORNER_PULL_LEFT: BlendShapeEntry = 71
Left lip corner pulls diagonally up and out.

## FT_MOUTH_CORNER_SLANT_RIGHT :: const XRFaceTracker.FT_MOUTH_CORNER_SLANT_RIGHT: BlendShapeEntry = 72
Right corner lip slants up.

## FT_MOUTH_CORNER_SLANT_LEFT :: const XRFaceTracker.FT_MOUTH_CORNER_SLANT_LEFT: BlendShapeEntry = 73
Left corner lip slants up.

## FT_MOUTH_FROWN_RIGHT :: const XRFaceTracker.FT_MOUTH_FROWN_RIGHT: BlendShapeEntry = 74
Right corner lip pulls down.

## FT_MOUTH_FROWN_LEFT :: const XRFaceTracker.FT_MOUTH_FROWN_LEFT: BlendShapeEntry = 75
Left corner lip pulls down.

## FT_MOUTH_STRETCH_RIGHT :: const XRFaceTracker.FT_MOUTH_STRETCH_RIGHT: BlendShapeEntry = 76
Mouth corner lip pulls out and down.

## FT_MOUTH_STRETCH_LEFT :: const XRFaceTracker.FT_MOUTH_STRETCH_LEFT: BlendShapeEntry = 77
Mouth corner lip pulls out and down.

## FT_MOUTH_DIMPLE_RIGHT :: const XRFaceTracker.FT_MOUTH_DIMPLE_RIGHT: BlendShapeEntry = 78
Right lip corner is pushed backwards.

## FT_MOUTH_DIMPLE_LEFT :: const XRFaceTracker.FT_MOUTH_DIMPLE_LEFT: BlendShapeEntry = 79
Left lip corner is pushed backwards.

## FT_MOUTH_RAISER_UPPER :: const XRFaceTracker.FT_MOUTH_RAISER_UPPER: BlendShapeEntry = 80
Raises and slightly pushes out the upper mouth.

## FT_MOUTH_RAISER_LOWER :: const XRFaceTracker.FT_MOUTH_RAISER_LOWER: BlendShapeEntry = 81
Raises and slightly pushes out the lower mouth.

## FT_MOUTH_PRESS_RIGHT :: const XRFaceTracker.FT_MOUTH_PRESS_RIGHT: BlendShapeEntry = 82
Right side lips press and flatten together vertically.

## FT_MOUTH_PRESS_LEFT :: const XRFaceTracker.FT_MOUTH_PRESS_LEFT: BlendShapeEntry = 83
Left side lips press and flatten together vertically.

## FT_MOUTH_TIGHTENER_RIGHT :: const XRFaceTracker.FT_MOUTH_TIGHTENER_RIGHT: BlendShapeEntry = 84
Right side lips squeeze together horizontally.

## FT_MOUTH_TIGHTENER_LEFT :: const XRFaceTracker.FT_MOUTH_TIGHTENER_LEFT: BlendShapeEntry = 85
Left side lips squeeze together horizontally.

## FT_TONGUE_OUT :: const XRFaceTracker.FT_TONGUE_OUT: BlendShapeEntry = 86
Tongue visibly sticks out of the mouth.

## FT_TONGUE_UP :: const XRFaceTracker.FT_TONGUE_UP: BlendShapeEntry = 87
Tongue points upwards.

## FT_TONGUE_DOWN :: const XRFaceTracker.FT_TONGUE_DOWN: BlendShapeEntry = 88
Tongue points downwards.

## FT_TONGUE_RIGHT :: const XRFaceTracker.FT_TONGUE_RIGHT: BlendShapeEntry = 89
Tongue points right.

## FT_TONGUE_LEFT :: const XRFaceTracker.FT_TONGUE_LEFT: BlendShapeEntry = 90
Tongue points left.

## FT_TONGUE_ROLL :: const XRFaceTracker.FT_TONGUE_ROLL: BlendShapeEntry = 91
Sides of the tongue funnel, creating a roll.

## FT_TONGUE_BLEND_DOWN :: const XRFaceTracker.FT_TONGUE_BLEND_DOWN: BlendShapeEntry = 92
Tongue arches up then down inside the mouth.

## FT_TONGUE_CURL_UP :: const XRFaceTracker.FT_TONGUE_CURL_UP: BlendShapeEntry = 93
Tongue arches down then up inside the mouth.

## FT_TONGUE_SQUISH :: const XRFaceTracker.FT_TONGUE_SQUISH: BlendShapeEntry = 94
Tongue squishes together and thickens.

## FT_TONGUE_FLAT :: const XRFaceTracker.FT_TONGUE_FLAT: BlendShapeEntry = 95
Tongue flattens and thins out.

## FT_TONGUE_TWIST_RIGHT :: const XRFaceTracker.FT_TONGUE_TWIST_RIGHT: BlendShapeEntry = 96
Tongue tip rotates clockwise, with the rest following gradually.

## FT_TONGUE_TWIST_LEFT :: const XRFaceTracker.FT_TONGUE_TWIST_LEFT: BlendShapeEntry = 97
Tongue tip rotates counter-clockwise, with the rest following gradually.

## FT_SOFT_PALATE_CLOSE :: const XRFaceTracker.FT_SOFT_PALATE_CLOSE: BlendShapeEntry = 98
Inner mouth throat closes.

## FT_THROAT_SWALLOW :: const XRFaceTracker.FT_THROAT_SWALLOW: BlendShapeEntry = 99
The Adam's apple visibly swallows.

## FT_NECK_FLEX_RIGHT :: const XRFaceTracker.FT_NECK_FLEX_RIGHT: BlendShapeEntry = 100
Right side neck visibly flexes.

## FT_NECK_FLEX_LEFT :: const XRFaceTracker.FT_NECK_FLEX_LEFT: BlendShapeEntry = 101
Left side neck visibly flexes.

## FT_EYE_CLOSED :: const XRFaceTracker.FT_EYE_CLOSED: BlendShapeEntry = 102
Closes both eye lids.

## FT_EYE_WIDE :: const XRFaceTracker.FT_EYE_WIDE: BlendShapeEntry = 103
Widens both eye lids.

## FT_EYE_SQUINT :: const XRFaceTracker.FT_EYE_SQUINT: BlendShapeEntry = 104
Squints both eye lids.

## FT_EYE_DILATION :: const XRFaceTracker.FT_EYE_DILATION: BlendShapeEntry = 105
Dilates both pupils.

## FT_EYE_CONSTRICT :: const XRFaceTracker.FT_EYE_CONSTRICT: BlendShapeEntry = 106
Constricts both pupils.

## FT_BROW_DOWN_RIGHT :: const XRFaceTracker.FT_BROW_DOWN_RIGHT: BlendShapeEntry = 107
Pulls the right eyebrow down and in.

## FT_BROW_DOWN_LEFT :: const XRFaceTracker.FT_BROW_DOWN_LEFT: BlendShapeEntry = 108
Pulls the left eyebrow down and in.

## FT_BROW_DOWN :: const XRFaceTracker.FT_BROW_DOWN: BlendShapeEntry = 109
Pulls both eyebrows down and in.

## FT_BROW_UP_RIGHT :: const XRFaceTracker.FT_BROW_UP_RIGHT: BlendShapeEntry = 110
Right brow appears worried.

## FT_BROW_UP_LEFT :: const XRFaceTracker.FT_BROW_UP_LEFT: BlendShapeEntry = 111
Left brow appears worried.

## FT_BROW_UP :: const XRFaceTracker.FT_BROW_UP: BlendShapeEntry = 112
Both brows appear worried.

## FT_NOSE_SNEER :: const XRFaceTracker.FT_NOSE_SNEER: BlendShapeEntry = 113
Entire face sneers.

## FT_NASAL_DILATION :: const XRFaceTracker.FT_NASAL_DILATION: BlendShapeEntry = 114
Both nose canals dilate.

## FT_NASAL_CONSTRICT :: const XRFaceTracker.FT_NASAL_CONSTRICT: BlendShapeEntry = 115
Both nose canals constrict.

## FT_CHEEK_PUFF :: const XRFaceTracker.FT_CHEEK_PUFF: BlendShapeEntry = 116
Puffs both cheeks.

## FT_CHEEK_SUCK :: const XRFaceTracker.FT_CHEEK_SUCK: BlendShapeEntry = 117
Sucks in both cheeks.

## FT_CHEEK_SQUINT :: const XRFaceTracker.FT_CHEEK_SQUINT: BlendShapeEntry = 118
Raises both cheeks.

## FT_LIP_SUCK_UPPER :: const XRFaceTracker.FT_LIP_SUCK_UPPER: BlendShapeEntry = 119
Tucks in the upper lips.

## FT_LIP_SUCK_LOWER :: const XRFaceTracker.FT_LIP_SUCK_LOWER: BlendShapeEntry = 120
Tucks in the lower lips.

## FT_LIP_SUCK :: const XRFaceTracker.FT_LIP_SUCK: BlendShapeEntry = 121
Tucks in both lips.

## FT_LIP_FUNNEL_UPPER :: const XRFaceTracker.FT_LIP_FUNNEL_UPPER: BlendShapeEntry = 122
Funnels in the upper lips.

## FT_LIP_FUNNEL_LOWER :: const XRFaceTracker.FT_LIP_FUNNEL_LOWER: BlendShapeEntry = 123
Funnels in the lower lips.

## FT_LIP_FUNNEL :: const XRFaceTracker.FT_LIP_FUNNEL: BlendShapeEntry = 124
Funnels in both lips.

## FT_LIP_PUCKER_UPPER :: const XRFaceTracker.FT_LIP_PUCKER_UPPER: BlendShapeEntry = 125
Upper lip part pushes outwards.

## FT_LIP_PUCKER_LOWER :: const XRFaceTracker.FT_LIP_PUCKER_LOWER: BlendShapeEntry = 126
Lower lip part pushes outwards.

## FT_LIP_PUCKER :: const XRFaceTracker.FT_LIP_PUCKER: BlendShapeEntry = 127
Lips push outwards.

## FT_MOUTH_UPPER_UP :: const XRFaceTracker.FT_MOUTH_UPPER_UP: BlendShapeEntry = 128
Raises the upper lips.

## FT_MOUTH_LOWER_DOWN :: const XRFaceTracker.FT_MOUTH_LOWER_DOWN: BlendShapeEntry = 129
Lowers the lower lips.

## FT_MOUTH_OPEN :: const XRFaceTracker.FT_MOUTH_OPEN: BlendShapeEntry = 130
Mouth opens, revealing teeth.

## FT_MOUTH_RIGHT :: const XRFaceTracker.FT_MOUTH_RIGHT: BlendShapeEntry = 131
Moves mouth right.

## FT_MOUTH_LEFT :: const XRFaceTracker.FT_MOUTH_LEFT: BlendShapeEntry = 132
Moves mouth left.

## FT_MOUTH_SMILE_RIGHT :: const XRFaceTracker.FT_MOUTH_SMILE_RIGHT: BlendShapeEntry = 133
Right side of the mouth smiles.

## FT_MOUTH_SMILE_LEFT :: const XRFaceTracker.FT_MOUTH_SMILE_LEFT: BlendShapeEntry = 134
Left side of the mouth smiles.

## FT_MOUTH_SMILE :: const XRFaceTracker.FT_MOUTH_SMILE: BlendShapeEntry = 135
Mouth expresses a smile.

## FT_MOUTH_SAD_RIGHT :: const XRFaceTracker.FT_MOUTH_SAD_RIGHT: BlendShapeEntry = 136
Right side of the mouth expresses sadness.

## FT_MOUTH_SAD_LEFT :: const XRFaceTracker.FT_MOUTH_SAD_LEFT: BlendShapeEntry = 137
Left side of the mouth expresses sadness.

## FT_MOUTH_SAD :: const XRFaceTracker.FT_MOUTH_SAD: BlendShapeEntry = 138
Mouth expresses sadness.

## FT_MOUTH_STRETCH :: const XRFaceTracker.FT_MOUTH_STRETCH: BlendShapeEntry = 139
Mouth stretches.

## FT_MOUTH_DIMPLE :: const XRFaceTracker.FT_MOUTH_DIMPLE: BlendShapeEntry = 140
Lip corners dimple.

## FT_MOUTH_TIGHTENER :: const XRFaceTracker.FT_MOUTH_TIGHTENER: BlendShapeEntry = 141
Mouth tightens.

## FT_MOUTH_PRESS :: const XRFaceTracker.FT_MOUTH_PRESS: BlendShapeEntry = 142
Mouth presses together.

## FT_MAX :: const XRFaceTracker.FT_MAX: BlendShapeEntry = 143
Represents the size of the [enum BlendShapeEntry] enum.

## blend_shapes :: var XRFaceTracker.blend_shapes: PackedFloat32Array
The array of face blend shape weights with indices corresponding to the [enum BlendShapeEntry] enum.

## type :: var XRFaceTracker.type: XRServer.TrackerType

## get_blend_shape :: func XRFaceTracker.get_blend_shape(blend_shape: int) -> float
Returns the requested face blend shape weight.

### blend_shape :: int

## set_blend_shape :: func XRFaceTracker.set_blend_shape(blend_shape: int, weight: float) -> void
Sets a face blend shape weight.

### blend_shape :: int

### weight :: float
