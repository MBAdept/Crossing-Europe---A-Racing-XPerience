# OpenXRBindingModifierEditor :: <Native> class OpenXRBindingModifierEditor extends PanelContainer
Binding modifier editor.
This is the default binding modifier editor used in the OpenXR action map.

## get_binding_modifier :: func OpenXRBindingModifierEditor.get_binding_modifier() -> OpenXRBindingModifier
Returns the [OpenXRBindingModifier] currently being edited.

## setup :: func OpenXRBindingModifierEditor.setup(action_map: OpenXRActionMap, binding_modifier: OpenXRBindingModifier) -> void
Setup this editor for the provided [param action_map] and [param binding_modifier].

### action_map :: OpenXRActionMap

### binding_modifier :: OpenXRBindingModifier

## binding_modifier_removed :: func OpenXRBindingModifierEditor.binding_modifier_removed(binding_modifier_editor: Object) -> void
Signal emitted when the user presses the delete binding modifier button for this modifier.

### binding_modifier_editor :: Object
