# Window :: <Native> class Window extends Viewport
Base class for all windows, dialogs, and popups.
A node that creates a window. The window can either be a native system window or embedded inside another [Window] (see [member Viewport.gui_embed_subwindows]).
At runtime, [Window]s will not close automatically when requested. You need to handle it manually using the [signal close_requested] signal (this applies both to pressing the close button and clicking outside of a popup).

## NOTIFICATION_VISIBILITY_CHANGED :: const Window.NOTIFICATION_VISIBILITY_CHANGED = 30
Emitted when [Window]'s visibility changes, right before [signal visibility_changed].

## NOTIFICATION_THEME_CHANGED :: const Window.NOTIFICATION_THEME_CHANGED = 32
Sent when the node needs to refresh its theme items. This happens in one of the following cases:
- The [member theme] property is changed on this node or any of its ancestors.
- The [member theme_type_variation] property is changed on this node.
- The node enters the scene tree.
[b]Note:[/b] As an optimization, this notification won't be sent from changes that occur while this node is outside of the scene tree. Instead, all of the theme item updates can be applied at once when the node enters the scene tree.

## MODE_WINDOWED :: const Window.MODE_WINDOWED: Mode = 0
Windowed mode, i.e. [Window] doesn't occupy the whole screen (unless set to the size of the screen).

## MODE_MINIMIZED :: const Window.MODE_MINIMIZED: Mode = 1
Minimized window mode, i.e. [Window] is not visible and available on window manager's window list. Normally happens when the minimize button is pressed.

## MODE_MAXIMIZED :: const Window.MODE_MAXIMIZED: Mode = 2
Maximized window mode, i.e. [Window] will occupy whole screen area except task bar and still display its borders. Normally happens when the maximize button is pressed.

## MODE_FULLSCREEN :: const Window.MODE_FULLSCREEN: Mode = 3
Full screen mode with full multi-window support.
Full screen window covers the entire display area of a screen and has no decorations. The display's video mode is not changed.
[b]On Android:[/b] This enables immersive mode.
[b]On macOS:[/b] A new desktop is used to display the running project.
[b]Note:[/b] Regardless of the platform, enabling full screen will change the window size to match the monitor's size. Therefore, make sure your project supports [url=https://docs.godotengine.org/en/4.7/tutorials/rendering/multiple_resolutions.html]multiple resolutions[/url] when enabling full screen mode.

## MODE_EXCLUSIVE_FULLSCREEN :: const Window.MODE_EXCLUSIVE_FULLSCREEN: Mode = 4
A single window full screen mode. This mode has less overhead, but only one window can be open on a given screen at a time (opening a child window or application switching will trigger a full screen transition).
Full screen window covers the entire display area of a screen and has no border or decorations. The display's video mode is not changed.
[b]Note:[/b] This mode might not work with screen recording software.
[b]On Android:[/b] This enables immersive mode.
[b]On Windows:[/b] Depending on video driver, full screen transition might cause screens to go black for a moment.
[b]On macOS:[/b] A new desktop is used to display the running project. Exclusive full screen mode prevents Dock and Menu from showing up when the mouse pointer is hovering the edge of the screen.
[b]On Linux (X11):[/b] Exclusive full screen mode bypasses compositor.
[b]On Linux (Wayland):[/b] Equivalent to [constant MODE_FULLSCREEN].
[b]Note:[/b] Regardless of the platform, enabling full screen will change the window size to match the monitor's size. Therefore, make sure your project supports [url=https://docs.godotengine.org/en/4.7/tutorials/rendering/multiple_resolutions.html]multiple resolutions[/url] when enabling full screen mode.

## FLAG_RESIZE_DISABLED :: const Window.FLAG_RESIZE_DISABLED: Flags = 0
The window can't be resized by dragging its resize grip. It's still possible to resize the window using [member size]. This flag is ignored for full screen windows. Set with [member unresizable].
[b]Note:[/b] This flag is implemented on Linux (X11), macOS, Windows, and embedded windows.

## FLAG_BORDERLESS :: const Window.FLAG_BORDERLESS: Flags = 1
The window do not have native title bar and other decorations. This flag is ignored for full-screen windows. Set with [member borderless].
[b]Note:[/b] This flag is implemented on Linux (X11/Wayland), macOS, Windows, and embedded windows.

## FLAG_ALWAYS_ON_TOP :: const Window.FLAG_ALWAYS_ON_TOP: Flags = 2
The window is floating on top of all other windows. This flag is ignored for full-screen windows. Set with [member always_on_top].
[b]Note:[/b] This flag is implemented on Linux (X11), macOS, Windows, and embedded windows.

## FLAG_TRANSPARENT :: const Window.FLAG_TRANSPARENT: Flags = 3
The window background can be transparent. Set with [member transparent].
[b]Note:[/b] This flag has no effect if either [member ProjectSettings.display/window/per_pixel_transparency/allowed], or the window's [member Viewport.transparent_bg] is set to [code]false[/code].
[b]Note:[/b] Transparency support is implemented on Linux (X11/Wayland), macOS, Windows, and embedded windows.

## FLAG_NO_FOCUS :: const Window.FLAG_NO_FOCUS: Flags = 4
The window can't be focused. No-focus window will ignore all input, except mouse clicks. Set with [member unfocusable].
[b]Note:[/b] This flag is implemented on Linux (X11), macOS, Windows, and embedded windows.

## FLAG_POPUP :: const Window.FLAG_POPUP: Flags = 5
Window is part of menu or [OptionButton] dropdown. This flag can't be changed when the window is visible. An active popup window will exclusively receive all input, without stealing focus from its parent. Popup windows are automatically closed when uses click outside it, or when an application is switched. Popup window must have transient parent set (see [member transient]).
[b]Note:[/b] This flag is implemented on Linux (X11/Wayland), macOS, Windows, and embedded [Popup] windows.

## FLAG_EXTEND_TO_TITLE :: const Window.FLAG_EXTEND_TO_TITLE: Flags = 6
Window content is expanded to the full size of the window. Unlike borderless window, the frame is left intact and can be used to resize the window, title bar is transparent, but have minimize/maximize/close buttons. Set with [member extend_to_title].
[b]Note:[/b] This flag has no effect in embedded windows.
[b]Note:[/b] This flag is implemented only on macOS.

## FLAG_MOUSE_PASSTHROUGH :: const Window.FLAG_MOUSE_PASSTHROUGH: Flags = 7
All mouse events are passed to the underlying window of the same application.
[b]Note:[/b] This flag has no effect in embedded windows.
[b]Note:[/b] This flag is implemented on Linux (X11), macOS, Windows.

## FLAG_SHARP_CORNERS :: const Window.FLAG_SHARP_CORNERS: Flags = 8
Window style is overridden, forcing sharp corners.
[b]Note:[/b] This flag has no effect in embedded windows.
[b]Note:[/b] This flag is implemented only on Windows (11).

## FLAG_EXCLUDE_FROM_CAPTURE :: const Window.FLAG_EXCLUDE_FROM_CAPTURE: Flags = 9
Windows is excluded from screenshots taken by [method DisplayServer.screen_get_image], [method DisplayServer.screen_get_image_rect], and [method DisplayServer.screen_get_pixel].
[b]Note:[/b] This flag has no effect in embedded windows.
[b]Note:[/b] This flag is implemented on macOS and Windows (10, 20H1).
[b]Note:[/b] Setting this flag will prevent standard screenshot methods from capturing a window image, but does [b]NOT[/b] guarantee that other apps won't be able to capture an image. It should not be used as a DRM or security measure.

## FLAG_POPUP_WM_HINT :: const Window.FLAG_POPUP_WM_HINT: Flags = 10
Signals the window manager that this window is supposed to be an implementation-defined "popup" (usually a floating, borderless, untileable and immovable child window).
[b]Note:[/b] This flag has no effect in embedded windows.
[b]Note:[/b] This flag is implemented on Linux (Wayland).

## FLAG_MINIMIZE_DISABLED :: const Window.FLAG_MINIMIZE_DISABLED: Flags = 11
Window minimize button is disabled.
[b]Note:[/b] This flag has no effect in embedded windows.
[b]Note:[/b] This flag is implemented on Linux (X11), macOS, and Windows.

## FLAG_MAXIMIZE_DISABLED :: const Window.FLAG_MAXIMIZE_DISABLED: Flags = 12
Window maximize button is disabled.
[b]Note:[/b] This flag has no effect in embedded windows.
[b]Note:[/b] This flag is implemented on Linux (X11), macOS, and Windows.

## FLAG_MAX :: const Window.FLAG_MAX: Flags = 13
Max value of the [enum Flags].

## CONTENT_SCALE_MODE_DISABLED :: const Window.CONTENT_SCALE_MODE_DISABLED: ContentScaleMode = 0
The content will not be scaled to match the [Window]'s size ([member content_scale_size] is ignored).

## CONTENT_SCALE_MODE_CANVAS_ITEMS :: const Window.CONTENT_SCALE_MODE_CANVAS_ITEMS: ContentScaleMode = 1
The content will be rendered at the target size. This is more performance-expensive than [constant CONTENT_SCALE_MODE_VIEWPORT], but provides better results.

## CONTENT_SCALE_MODE_VIEWPORT :: const Window.CONTENT_SCALE_MODE_VIEWPORT: ContentScaleMode = 2
The content will be rendered at the base size and then scaled to the target size. More performant than [constant CONTENT_SCALE_MODE_CANVAS_ITEMS], but results in pixelated image.

## CONTENT_SCALE_ASPECT_IGNORE :: const Window.CONTENT_SCALE_ASPECT_IGNORE: ContentScaleAspect = 0
The aspect will be ignored. Scaling will simply stretch the content to fit the target size.

## CONTENT_SCALE_ASPECT_KEEP :: const Window.CONTENT_SCALE_ASPECT_KEEP: ContentScaleAspect = 1
The content's aspect will be preserved. If the target size has different aspect from the base one, the image will be centered and black bars will appear on left and right sides.

## CONTENT_SCALE_ASPECT_KEEP_WIDTH :: const Window.CONTENT_SCALE_ASPECT_KEEP_WIDTH: ContentScaleAspect = 2
The content can be expanded vertically. Scaling horizontally will result in keeping the width ratio and then black bars on left and right sides.

## CONTENT_SCALE_ASPECT_KEEP_HEIGHT :: const Window.CONTENT_SCALE_ASPECT_KEEP_HEIGHT: ContentScaleAspect = 3
The content can be expanded horizontally. Scaling vertically will result in keeping the height ratio and then black bars on top and bottom sides.

## CONTENT_SCALE_ASPECT_EXPAND :: const Window.CONTENT_SCALE_ASPECT_EXPAND: ContentScaleAspect = 4
The content's aspect will be preserved. If the target size has different aspect from the base one, the content will stay in the top-left corner and add an extra visible area in the stretched space.

## CONTENT_SCALE_STRETCH_FRACTIONAL :: const Window.CONTENT_SCALE_STRETCH_FRACTIONAL: ContentScaleStretch = 0
The content will be stretched according to a fractional factor. This fills all the space available in the window, but allows "pixel wobble" to occur due to uneven pixel scaling.

## CONTENT_SCALE_STRETCH_INTEGER :: const Window.CONTENT_SCALE_STRETCH_INTEGER: ContentScaleStretch = 1
The content will be stretched only according to an integer factor, preserving sharp pixels. This may leave a black background visible on the window's edges depending on the window size.

## LAYOUT_DIRECTION_INHERITED :: const Window.LAYOUT_DIRECTION_INHERITED: LayoutDirection = 0
Automatic layout direction, determined from the parent window layout direction.

## LAYOUT_DIRECTION_APPLICATION_LOCALE :: const Window.LAYOUT_DIRECTION_APPLICATION_LOCALE: LayoutDirection = 1
Automatic layout direction, determined from the current locale.

## LAYOUT_DIRECTION_LTR :: const Window.LAYOUT_DIRECTION_LTR: LayoutDirection = 2
Left-to-right layout direction.

## LAYOUT_DIRECTION_RTL :: const Window.LAYOUT_DIRECTION_RTL: LayoutDirection = 3
Right-to-left layout direction.

## LAYOUT_DIRECTION_SYSTEM_LOCALE :: const Window.LAYOUT_DIRECTION_SYSTEM_LOCALE: LayoutDirection = 4
Automatic layout direction, determined from the system locale.

## LAYOUT_DIRECTION_MAX :: const Window.LAYOUT_DIRECTION_MAX: LayoutDirection = 5
Represents the size of the [enum LayoutDirection] enum.

## LAYOUT_DIRECTION_LOCALE :: const Window.LAYOUT_DIRECTION_LOCALE: LayoutDirection = 1

## WINDOW_INITIAL_POSITION_ABSOLUTE :: const Window.WINDOW_INITIAL_POSITION_ABSOLUTE: WindowInitialPosition = 0
Initial window position is determined by [member position].

## WINDOW_INITIAL_POSITION_CENTER_PRIMARY_SCREEN :: const Window.WINDOW_INITIAL_POSITION_CENTER_PRIMARY_SCREEN: WindowInitialPosition = 1
Initial window position is the center of the primary screen.

## WINDOW_INITIAL_POSITION_CENTER_MAIN_WINDOW_SCREEN :: const Window.WINDOW_INITIAL_POSITION_CENTER_MAIN_WINDOW_SCREEN: WindowInitialPosition = 2
Initial window position is the center of the main window screen.

## WINDOW_INITIAL_POSITION_CENTER_OTHER_SCREEN :: const Window.WINDOW_INITIAL_POSITION_CENTER_OTHER_SCREEN: WindowInitialPosition = 3
Initial window position is the center of [member current_screen] screen.

## WINDOW_INITIAL_POSITION_CENTER_SCREEN_WITH_MOUSE_FOCUS :: const Window.WINDOW_INITIAL_POSITION_CENTER_SCREEN_WITH_MOUSE_FOCUS: WindowInitialPosition = 4
Initial window position is the center of the screen containing the mouse pointer.

## WINDOW_INITIAL_POSITION_CENTER_SCREEN_WITH_KEYBOARD_FOCUS :: const Window.WINDOW_INITIAL_POSITION_CENTER_SCREEN_WITH_KEYBOARD_FOCUS: WindowInitialPosition = 5
Initial window position is the center of the screen containing the window with the keyboard focus.

## accessibility_description :: var Window.accessibility_description: String
The human-readable node description that is reported to assistive apps.

## accessibility_name :: var Window.accessibility_name: String
The human-readable node name that is reported to assistive apps.

## always_on_top :: var Window.always_on_top: bool
If [code]true[/code], the window will be on top of all other windows. Does not work if [member transient] is enabled.

## auto_translate :: var Window.auto_translate: bool
Toggles if any text should automatically change to its translated version depending on the current locale.

## borderless :: var Window.borderless: bool
If [code]true[/code], the window will have no borders.

## content_scale_aspect :: var Window.content_scale_aspect: Window.ContentScaleAspect
Specifies how the content's aspect behaves when the [Window] is resized. The base aspect is determined by [member content_scale_size].

## content_scale_factor :: var Window.content_scale_factor: float
Specifies the base scale of [Window]'s content when its [member size] is equal to [member content_scale_size]. See also [method Viewport.get_stretch_transform].

## content_scale_mode :: var Window.content_scale_mode: Window.ContentScaleMode
Specifies how the content is scaled when the [Window] is resized.

## content_scale_size :: var Window.content_scale_size: Vector2i
The content's base size in "virtual" pixels. Not to be confused with [member size], which sets the actual window's physical size in pixels. If set to a value greater than [code]0[/code] and [member content_scale_mode] is set to a value other than [constant CONTENT_SCALE_MODE_DISABLED], the [Window]'s content will be scaled when the window is resized to a different size. Higher values will make the content appear [i]smaller[/i], as it will be able to fit more of the project in view. On the root [Window], this is set to match [member ProjectSettings.display/window/size/viewport_width] and [member ProjectSettings.display/window/size/viewport_height] by default.
For example, when using [constant CONTENT_SCALE_MODE_CANVAS_ITEMS] and [member content_scale_size] set to [code]Vector2i(1280, 720)[/code], using a window size of [code]2560×1440[/code] will make 2D elements appear at double their original size, as the content is scaled by a factor of [code]2.0[/code] ([code]2560.0 / 1280.0 = 2.0[/code], [code]1440.0 / 720.0 = 2.0[/code]).
See [url=https://docs.godotengine.org/en/4.7/tutorials/rendering/multiple_resolutions.html#base-size]the Base size section of the Multiple resolutions documentation[/url] for details.

## content_scale_stretch :: var Window.content_scale_stretch: Window.ContentScaleStretch
The policy to use to determine the final scale factor for 2D elements. This affects how [member content_scale_factor] is applied, in addition to the automatic scale factor determined by [member content_scale_size].

## current_screen :: var Window.current_screen: int
The screen the window is currently on.

## exclude_from_capture :: var Window.exclude_from_capture: bool
If [code]true[/code], the [Window] is excluded from screenshots taken by [method DisplayServer.screen_get_image], [method DisplayServer.screen_get_image_rect], and [method DisplayServer.screen_get_pixel].
[b]Note:[/b] This property is implemented on macOS and Windows.
[b]Note:[/b] Enabling this setting will prevent standard screenshot methods from capturing a window image, but does [b]NOT[/b] guarantee that other apps won't be able to capture an image. It should not be used as a DRM or security measure.

## exclusive :: var Window.exclusive: bool
If [code]true[/code], the [Window] will be in exclusive mode. Exclusive windows are always on top of their parent and will block all input going to the parent [Window].
Needs [member transient] enabled to work.

## extend_to_title :: var Window.extend_to_title: bool
If [code]true[/code], the [Window] contents is expanded to the full size of the window, window title bar is transparent.
[b]Note:[/b] This property is implemented only on macOS.
[b]Note:[/b] This property only works with native windows.

## force_native :: var Window.force_native: bool
If [code]true[/code], native window will be used regardless of parent viewport and project settings.

## hdr_output_requested :: var Window.hdr_output_requested: bool
If [code]true[/code], requests HDR output for the [Window], falling back to SDR if not supported, and automatically switching between HDR and SDR as the window moves between screens, screen capabilities change, or system settings are modified. This will internally force [member Viewport.use_hdr_2d] to be enabled on the main [Viewport]. All other [SubViewport] of this [Window] must have their [member Viewport.use_hdr_2d] property enabled to produce HDR output.

## initial_position :: var Window.initial_position: Window.WindowInitialPosition
Specifies the initial type of position for the [Window].

## keep_title_visible :: var Window.keep_title_visible: bool
If [code]true[/code], the [Window] width is expanded to keep the title bar text fully visible.

## max_size :: var Window.max_size: Vector2i
If non-zero, the [Window] can't be resized to be bigger than this size.
[b]Note:[/b] This property will be ignored if the value is lower than [member min_size].

## maximize_disabled :: var Window.maximize_disabled: bool
If [code]true[/code], the [Window]'s maximize button is disabled.
[b]Note:[/b] If both minimize and maximize buttons are disabled, buttons are fully hidden, and only close button is visible.
[b]Note:[/b] This property is implemented only on macOS and Windows.

## min_size :: var Window.min_size: Vector2i
If non-zero, the [Window] can't be resized to be smaller than this size.
[b]Note:[/b] This property will be ignored in favor of [method get_contents_minimum_size] if [member wrap_controls] is enabled and if its size is bigger.

## minimize_disabled :: var Window.minimize_disabled: bool
If [code]true[/code], the [Window]'s minimize button is disabled.
[b]Note:[/b] If both minimize and maximize buttons are disabled, buttons are fully hidden, and only close button is visible.
[b]Note:[/b] This property is implemented only on macOS and Windows.

## mode :: var Window.mode: Window.Mode
Set's the window's current mode.
[b]Note:[/b] Fullscreen mode is not exclusive full screen on Windows and Linux.
[b]Note:[/b] This method only works with native windows, i.e. the main window and [Window]-derived nodes when [member Viewport.gui_embed_subwindows] is disabled in the main viewport.

## mouse_passthrough :: var Window.mouse_passthrough: bool
If [code]true[/code], all mouse events will be passed to the underlying window of the same application. See also [member mouse_passthrough_polygon].
[b]Note:[/b] This property is implemented on Linux (X11), macOS and Windows.
[b]Note:[/b] This property only works with native windows.

## mouse_passthrough_polygon :: var Window.mouse_passthrough_polygon: PackedVector2Array
Sets a polygonal region of the window which accepts mouse events. Mouse events outside the region will be passed through.
Passing an empty array will disable passthrough support (all mouse events will be intercepted by the window, which is the default behavior).
[codeblocks]
[gdscript]
# Set region, using Path2D node.
$Window.mouse_passthrough_polygon = $Path2D.curve.get_baked_points()

# Set region, using Polygon2D node.
$Window.mouse_passthrough_polygon = $Polygon2D.polygon

# Reset region to default.
$Window.mouse_passthrough_polygon = []
[/gdscript]
[csharp]
// Set region, using Path2D node.
GetNode<Window>("Window").MousePassthroughPolygon = GetNode<Path2D>("Path2D").Curve.GetBakedPoints();

// Set region, using Polygon2D node.
GetNode<Window>("Window").MousePassthroughPolygon = GetNode<Polygon2D>("Polygon2D").Polygon;

// Reset region to default.
GetNode<Window>("Window").MousePassthroughPolygon = [];
[/csharp]
[/codeblocks]
[b]Note:[/b] This property is ignored if [member mouse_passthrough] is set to [code]true[/code].
[b]Note:[/b] On Windows, the portion of a window that lies outside the region is not drawn, while on Linux (X11) and macOS it is.
[b]Note:[/b] This property is implemented on Linux (X11), macOS and Windows.

## nonclient_area :: var Window.nonclient_area: Rect2i
If set, defines the window's custom decoration area which will receive mouse input, even if normal input to the window is blocked (such as when it has an exclusive child opened). See also [signal nonclient_window_input].

## popup_window :: var Window.popup_window: bool
If [code]true[/code], the [Window] will be considered a popup. Popups are sub-windows that don't show as separate windows in system's window manager's window list and will send close request when anything is clicked outside of them (unless [member exclusive] is enabled).

## popup_wm_hint :: var Window.popup_wm_hint: bool
If [code]true[/code], the [Window] will signal to the window manager that it is supposed to be an implementation-defined "popup" (usually a floating, borderless, untileable and immovable child window).

## position :: var Window.position: Vector2i
The window's position in pixels.
If [member ProjectSettings.display/window/subwindows/embed_subwindows] is [code]false[/code], the position is in absolute screen coordinates. This typically applies to editor plugins. If the setting is [code]true[/code], the window's position is in the coordinates of its parent [Viewport].
[b]Note:[/b] This property only works if [member initial_position] is set to [constant WINDOW_INITIAL_POSITION_ABSOLUTE].

## sharp_corners :: var Window.sharp_corners: bool
If [code]true[/code], the [Window] will override the OS window style to display sharp corners.
[b]Note:[/b] This property is implemented only on Windows (11).
[b]Note:[/b] This property only works with native windows.

## size :: var Window.size: Vector2i
The window's size in pixels. See also [member content_scale_size], which doesn't set the window's physical size but affects how scaling works relative to the current [member content_scale_mode].

## theme :: var Window.theme: Theme
The [Theme] resource this node and all its [Control] and [Window] children use. If a child node has its own [Theme] resource set, theme items are merged with child's definitions having higher priority.
[b]Note:[/b] [Window] styles will have no effect unless the window is embedded.

## theme_type_variation :: var Window.theme_type_variation: StringName
The name of a theme type variation used by this [Window] to look up its own theme items. See [member Control.theme_type_variation] for more details.

## title :: var Window.title: String
The window's title. If the [Window] is native, title styles set in [Theme] will have no effect.

## transient :: var Window.transient: bool
If [code]true[/code], the [Window] is transient, i.e. it's considered a child of another [Window]. The transient window will be destroyed with its transient parent and will return focus to their parent when closed. The transient window is displayed on top of a non-exclusive full-screen parent window. Transient windows can't enter full-screen mode.
Note that behavior might be different depending on the platform.

## transient_to_focused :: var Window.transient_to_focused: bool
If [code]true[/code], and the [Window] is [member transient], this window will (at the time of becoming visible) become transient to the currently focused window instead of the immediate parent window in the hierarchy. Note that the transient parent is assigned at the time this window becomes visible, so changing it afterwards has no effect until re-shown.

## transparent :: var Window.transparent: bool
If [code]true[/code], the [Window]'s background can be transparent. This is best used with embedded windows.
[b]Note:[/b] Transparency support is implemented on Linux, macOS and Windows, but availability might vary depending on GPU driver, display manager, and compositor capabilities.
[b]Note:[/b] This property has no effect if [member ProjectSettings.display/window/per_pixel_transparency/allowed] is set to [code]false[/code].

## unfocusable :: var Window.unfocusable: bool
If [code]true[/code], the [Window] can't be focused nor interacted with. It can still be visible.

## unresizable :: var Window.unresizable: bool
If [code]true[/code], the window can't be resized.

## visible :: var Window.visible: bool
If [code]true[/code], the window is visible.

## wrap_controls :: var Window.wrap_controls: bool
If [code]true[/code], the window's size will automatically update when a child node is added or removed, ignoring [member min_size] if the new size is bigger.
If [code]false[/code], you need to call [method child_controls_changed] manually.

## title_color :: <Theme> var Window.title_color: Color
The color of the title's text.

## title_outline_modulate :: <Theme> var Window.title_outline_modulate: Color
The color of the title's text outline.

## close_h_offset :: <Theme> var Window.close_h_offset: int
Horizontal position offset of the close button, relative to the end of the title bar, towards the beginning of the title bar.

## close_v_offset :: <Theme> var Window.close_v_offset: int
Vertical position offset of the close button, relative to the bottom of the title bar, towards the top of the title bar.

## resize_margin :: <Theme> var Window.resize_margin: int
Defines the outside margin at which the window border can be grabbed with mouse and resized.

## title_height :: <Theme> var Window.title_height: int
Height of the title bar.

## title_outline_size :: <Theme> var Window.title_outline_size: int
The size of the title outline.

## title_font :: <Theme> var Window.title_font: Font
The font used to draw the title.

## title_font_size :: <Theme> var Window.title_font_size: int
The size of the title font.

## close :: <Theme> var Window.close: Texture2D
The icon for the close button.

## close_pressed :: <Theme> var Window.close_pressed: Texture2D
The icon for the close button when it's being pressed.

## embedded_border :: <Theme> var Window.embedded_border: StyleBox
The background style used when the [Window] is embedded. Note that this is drawn only under the window's content, excluding the title. For proper borders and title bar style, you can use [code]expand_margin_*[/code] properties of [StyleBoxFlat].
[b]Note:[/b] The content background will not be visible unless [member transparent] is enabled.

## embedded_unfocused_border :: <Theme> var Window.embedded_unfocused_border: StyleBox
The background style used when the [Window] is embedded and unfocused.

## _get_contents_minimum_size :: func Window._get_contents_minimum_size() -> Vector2
Virtual method to be implemented by the user. Overrides the value returned by [method get_contents_minimum_size].

## add_theme_color_override :: func Window.add_theme_color_override(name: StringName, color: Color) -> void
Creates a local override for a theme [Color] with the specified [param name]. Local overrides always take precedence when fetching theme items for the control. An override can be removed with [method remove_theme_color_override].
See also [method get_theme_color] and [method Control.add_theme_color_override] for more details.

### name :: StringName

### color :: Color

## add_theme_constant_override :: func Window.add_theme_constant_override(name: StringName, constant: int) -> void
Creates a local override for a theme constant with the specified [param name]. Local overrides always take precedence when fetching theme items for the control. An override can be removed with [method remove_theme_constant_override].
See also [method get_theme_constant].

### name :: StringName

### constant :: int

## add_theme_font_override :: func Window.add_theme_font_override(name: StringName, font: Font) -> void
Creates a local override for a theme [Font] with the specified [param name]. Local overrides always take precedence when fetching theme items for the control. An override can be removed with [method remove_theme_font_override].
See also [method get_theme_font].

### name :: StringName

### font :: Font

## add_theme_font_size_override :: func Window.add_theme_font_size_override(name: StringName, font_size: int) -> void
Creates a local override for a theme font size with the specified [param name]. Local overrides always take precedence when fetching theme items for the control. An override can be removed with [method remove_theme_font_size_override].
See also [method get_theme_font_size].

### name :: StringName

### font_size :: int

## add_theme_icon_override :: func Window.add_theme_icon_override(name: StringName, texture: Texture2D) -> void
Creates a local override for a theme icon with the specified [param name]. Local overrides always take precedence when fetching theme items for the control. An override can be removed with [method remove_theme_icon_override].
See also [method get_theme_icon].

### name :: StringName

### texture :: Texture2D

## add_theme_stylebox_override :: func Window.add_theme_stylebox_override(name: StringName, stylebox: StyleBox) -> void
Creates a local override for a theme [StyleBox] with the specified [param name]. Local overrides always take precedence when fetching theme items for the control. An override can be removed with [method remove_theme_stylebox_override].
See also [method get_theme_stylebox] and [method Control.add_theme_stylebox_override] for more details.

### name :: StringName

### stylebox :: StyleBox

## begin_bulk_theme_override :: func Window.begin_bulk_theme_override() -> void
Prevents [code]*_theme_*_override[/code] methods from emitting [constant NOTIFICATION_THEME_CHANGED] until [method end_bulk_theme_override] is called.

## can_draw :: func Window.can_draw() -> bool
Returns whether the window is being drawn to the screen.

## child_controls_changed :: func Window.child_controls_changed() -> void
Requests an update of the [Window] size to fit underlying [Control] nodes.

## end_bulk_theme_override :: func Window.end_bulk_theme_override() -> void
Ends a bulk theme override update. See [method begin_bulk_theme_override].

## get_contents_minimum_size :: func Window.get_contents_minimum_size() -> Vector2
Returns the combined minimum size from the child [Control] nodes of the window. Use [method child_controls_changed] to update it when child nodes have changed.
The value returned by this method can be overridden with [method _get_contents_minimum_size].

## get_flag :: func Window.get_flag(flag: int) -> bool
Returns [code]true[/code] if the [param flag] is set.

### flag :: int

## get_focused_window :: func Window.get_focused_window() -> Window
Returns the focused window.

## get_layout_direction :: func Window.get_layout_direction() -> int
Returns layout direction and text writing direction.

## get_output_max_linear_value :: func Window.get_output_max_linear_value() -> float
Returns the maximum value for linear color components that can be displayed in this window, regardless of SDR or HDR output. Returns [code]1.0[/code] if HDR is not enabled or not supported. The [signal output_max_linear_value_changed] signal will be emitted whenever this value changes.
This value is used by tonemapping and other [Environment] effects to ensure that bright colors are presented in the range that can be displayed by this window. When using this maximum linear value in your project, it should only be used to present colors directly to the screen without tonemapping and without influencing lighting, post-processing effects, or surrounding color. The following is an example that produces the brightest purple color that the screen can produce:
[codeblocks]
[gdscript]
func _process(_delta):
	# output_max_linear_value may change often, so do this every frame.
	var max_linear_value = get_window().get_output_max_linear_value()
	# Replace this with your color:
	var original_color = Color.PURPLE
	# Normalize to max_linear_value to produce the brightest color possible,
	# regardless of SDR or HDR output:
	var bright_color = normalize_color(original_color, max_linear_value)


func normalize_color(srgb_color, max_linear_value = 1.0):
	# Color must be linear-encoded to use math operations.
	var linear_color = srgb_color.srgb_to_linear()
	var max_rgb_value = maxf(linear_color.r, maxf(linear_color.g, linear_color.b))
	var brightness_scale = max_linear_value / max_rgb_value
	linear_color *= brightness_scale
	# Undo changes to the alpha channel, which should not be modified.
	linear_color.a = srgb_color.a
	# Convert back to nonlinear sRGB encoding, which is required for Color in
	# Godot unless stated otherwise.
	return linear_color.linear_to_srgb()
[/gdscript]
[/codeblocks]
[b]Note:[/b] You will need to convert sRGB colors to linear before multiplying by this value to get correct results.

## get_position_with_decorations :: func Window.get_position_with_decorations() -> Vector2i
Returns the window's position including its border.
[b]Note:[/b] If [member visible] is [code]false[/code], this method returns the same value as [member position].

## get_size_with_decorations :: func Window.get_size_with_decorations() -> Vector2i
Returns the window's size including its border.
[b]Note:[/b] If [member visible] is [code]false[/code], this method returns the same value as [member size].

## get_theme_color :: func Window.get_theme_color(name: StringName, theme_type: StringName = &"") -> Color
Returns a [Color] from the first matching [Theme] in the tree if that [Theme] has a color item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for more details.

### name :: StringName

### theme_type :: StringName

## get_theme_constant :: func Window.get_theme_constant(name: StringName, theme_type: StringName = &"") -> int
Returns a constant from the first matching [Theme] in the tree if that [Theme] has a constant item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for more details.

### name :: StringName

### theme_type :: StringName

## get_theme_default_base_scale :: func Window.get_theme_default_base_scale() -> float
Returns the default base scale value from the first matching [Theme] in the tree if that [Theme] has a valid [member Theme.default_base_scale] value.
See [method Control.get_theme_color] for details.

## get_theme_default_font :: func Window.get_theme_default_font() -> Font
Returns the default font from the first matching [Theme] in the tree if that [Theme] has a valid [member Theme.default_font] value.
See [method Control.get_theme_color] for details.

## get_theme_default_font_size :: func Window.get_theme_default_font_size() -> int
Returns the default font size value from the first matching [Theme] in the tree if that [Theme] has a valid [member Theme.default_font_size] value.
See [method Control.get_theme_color] for details.

## get_theme_font :: func Window.get_theme_font(name: StringName, theme_type: StringName = &"") -> Font
Returns a [Font] from the first matching [Theme] in the tree if that [Theme] has a font item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for details.

### name :: StringName

### theme_type :: StringName

## get_theme_font_size :: func Window.get_theme_font_size(name: StringName, theme_type: StringName = &"") -> int
Returns a font size from the first matching [Theme] in the tree if that [Theme] has a font size item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for details.

### name :: StringName

### theme_type :: StringName

## get_theme_icon :: func Window.get_theme_icon(name: StringName, theme_type: StringName = &"") -> Texture2D
Returns an icon from the first matching [Theme] in the tree if that [Theme] has an icon item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for details.

### name :: StringName

### theme_type :: StringName

## get_theme_stylebox :: func Window.get_theme_stylebox(name: StringName, theme_type: StringName = &"") -> StyleBox
Returns a [StyleBox] from the first matching [Theme] in the tree if that [Theme] has a stylebox item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for details.

### name :: StringName

### theme_type :: StringName

## get_window_id :: func Window.get_window_id() -> int
Returns the ID of the window.

## grab_focus :: func Window.grab_focus() -> void
Causes the window to grab focus, allowing it to receive user input.

## has_focus :: func Window.has_focus() -> bool
Returns [code]true[/code] if the window is focused.

## has_theme_color :: func Window.has_theme_color(name: StringName, theme_type: StringName = &"") -> bool
Returns [code]true[/code] if there is a matching [Theme] in the tree that has a color item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for details.

### name :: StringName

### theme_type :: StringName

## has_theme_color_override :: func Window.has_theme_color_override(name: StringName) -> bool
Returns [code]true[/code] if there is a local override for a theme [Color] with the specified [param name] in this [Control] node.
See [method add_theme_color_override].

### name :: StringName

## has_theme_constant :: func Window.has_theme_constant(name: StringName, theme_type: StringName = &"") -> bool
Returns [code]true[/code] if there is a matching [Theme] in the tree that has a constant item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for details.

### name :: StringName

### theme_type :: StringName

## has_theme_constant_override :: func Window.has_theme_constant_override(name: StringName) -> bool
Returns [code]true[/code] if there is a local override for a theme constant with the specified [param name] in this [Control] node.
See [method add_theme_constant_override].

### name :: StringName

## has_theme_font :: func Window.has_theme_font(name: StringName, theme_type: StringName = &"") -> bool
Returns [code]true[/code] if there is a matching [Theme] in the tree that has a font item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for details.

### name :: StringName

### theme_type :: StringName

## has_theme_font_override :: func Window.has_theme_font_override(name: StringName) -> bool
Returns [code]true[/code] if there is a local override for a theme [Font] with the specified [param name] in this [Control] node.
See [method add_theme_font_override].

### name :: StringName

## has_theme_font_size :: func Window.has_theme_font_size(name: StringName, theme_type: StringName = &"") -> bool
Returns [code]true[/code] if there is a matching [Theme] in the tree that has a font size item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for details.

### name :: StringName

### theme_type :: StringName

## has_theme_font_size_override :: func Window.has_theme_font_size_override(name: StringName) -> bool
Returns [code]true[/code] if there is a local override for a theme font size with the specified [param name] in this [Control] node.
See [method add_theme_font_size_override].

### name :: StringName

## has_theme_icon :: func Window.has_theme_icon(name: StringName, theme_type: StringName = &"") -> bool
Returns [code]true[/code] if there is a matching [Theme] in the tree that has an icon item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for details.

### name :: StringName

### theme_type :: StringName

## has_theme_icon_override :: func Window.has_theme_icon_override(name: StringName) -> bool
Returns [code]true[/code] if there is a local override for a theme icon with the specified [param name] in this [Control] node.
See [method add_theme_icon_override].

### name :: StringName

## has_theme_stylebox :: func Window.has_theme_stylebox(name: StringName, theme_type: StringName = &"") -> bool
Returns [code]true[/code] if there is a matching [Theme] in the tree that has a stylebox item with the specified [param name] and [param theme_type].
See [method Control.get_theme_color] for details.

### name :: StringName

### theme_type :: StringName

## has_theme_stylebox_override :: func Window.has_theme_stylebox_override(name: StringName) -> bool
Returns [code]true[/code] if there is a local override for a theme [StyleBox] with the specified [param name] in this [Control] node.
See [method add_theme_stylebox_override].

### name :: StringName

## hide :: func Window.hide() -> void
Hides the window. This is not the same as minimized state. Hidden window can't be interacted with and needs to be made visible with [method show].

## is_embedded :: func Window.is_embedded() -> bool
Returns [code]true[/code] if the window is currently embedded in another window.

## is_layout_rtl :: func Window.is_layout_rtl() -> bool
Returns [code]true[/code] if the layout is right-to-left.

## is_maximize_allowed :: func Window.is_maximize_allowed() -> bool
Returns [code]true[/code] if the window can be maximized (the maximize button is enabled).

## is_using_font_oversampling :: func Window.is_using_font_oversampling() -> bool
Returns [code]true[/code] if font oversampling is enabled. See [method set_use_font_oversampling].

## move_to_center :: func Window.move_to_center() -> void
Centers the window in the current screen. If the window is embedded, it is centered in the embedder [Viewport] instead.

## move_to_foreground :: func Window.move_to_foreground() -> void
Causes the window to grab focus, allowing it to receive user input.

## popup :: func Window.popup(rect: Rect2i = Rect2i(0, 0, 0, 0)) -> void
Shows the [Window] and makes it transient (see [member transient]). If [param rect] is provided, it will be set as the [Window]'s size. Fails if called on the main window.
If [member ProjectSettings.display/window/subwindows/embed_subwindows] is [code]true[/code] (single-window mode), [param rect]'s coordinates are global and relative to the main window's top-left corner (excluding window decorations). If [param rect]'s position coordinates are negative, the window will be located outside the main window and may not be visible as a result.
If [member ProjectSettings.display/window/subwindows/embed_subwindows] is [code]false[/code] (multi-window mode), [param rect]'s coordinates are global and relative to the top-left corner of the leftmost screen. If [param rect]'s position coordinates are negative, the window will be placed at the top-left corner of the screen.
[b]Note:[/b] [param rect] must be in global coordinates if specified.

### rect :: Rect2i

## popup_centered :: func Window.popup_centered(minsize: Vector2i = Vector2i(0, 0)) -> void
Popups the [Window] at the center of the current screen, with optionally given minimum size. If the [Window] is embedded, it will be centered in the parent [Viewport] instead.
[b]Note:[/b] Calling it with the default value of [param minsize] is equivalent to calling it with [member size].

### minsize :: Vector2i

## popup_centered_clamped :: func Window.popup_centered_clamped(minsize: Vector2i = Vector2i(0, 0), fallback_ratio: float = 0.75) -> void
Popups the [Window] centered inside its parent [Window]. [param fallback_ratio] determines the maximum size of the [Window], in relation to its parent.
[b]Note:[/b] Calling it with the default value of [param minsize] is equivalent to calling it with [member size].

### minsize :: Vector2i

### fallback_ratio :: float

## popup_centered_ratio :: func Window.popup_centered_ratio(ratio: float = 0.8) -> void
If [Window] is embedded, popups the [Window] centered inside its embedder and sets its size as a [param ratio] of embedder's size.
If [Window] is a native window, popups the [Window] centered inside the screen of its parent [Window] and sets its size as a [param ratio] of the screen size.

### ratio :: float

## popup_exclusive :: func Window.popup_exclusive(from_node: Node, rect: Rect2i = Rect2i(0, 0, 0, 0)) -> void
Attempts to parent this dialog to the last exclusive window relative to [param from_node], and then calls [method Window.popup] on it. The dialog must have no current parent, otherwise the method fails.
See also [method set_unparent_when_invisible] and [method Node.get_last_exclusive_window].

### from_node :: Node

### rect :: Rect2i

## popup_exclusive_centered :: func Window.popup_exclusive_centered(from_node: Node, minsize: Vector2i = Vector2i(0, 0)) -> void
Attempts to parent this dialog to the last exclusive window relative to [param from_node], and then calls [method Window.popup_centered] on it. The dialog must have no current parent, otherwise the method fails.
See also [method set_unparent_when_invisible] and [method Node.get_last_exclusive_window].

### from_node :: Node

### minsize :: Vector2i

## popup_exclusive_centered_clamped :: func Window.popup_exclusive_centered_clamped(from_node: Node, minsize: Vector2i = Vector2i(0, 0), fallback_ratio: float = 0.75) -> void
Attempts to parent this dialog to the last exclusive window relative to [param from_node], and then calls [method Window.popup_centered_clamped] on it. The dialog must have no current parent, otherwise the method fails.
See also [method set_unparent_when_invisible] and [method Node.get_last_exclusive_window].

### from_node :: Node

### minsize :: Vector2i

### fallback_ratio :: float

## popup_exclusive_centered_ratio :: func Window.popup_exclusive_centered_ratio(from_node: Node, ratio: float = 0.8) -> void
Attempts to parent this dialog to the last exclusive window relative to [param from_node], and then calls [method Window.popup_centered_ratio] on it. The dialog must have no current parent, otherwise the method fails.
See also [method set_unparent_when_invisible] and [method Node.get_last_exclusive_window].

### from_node :: Node

### ratio :: float

## popup_exclusive_on_parent :: func Window.popup_exclusive_on_parent(from_node: Node, parent_rect: Rect2i) -> void
Attempts to parent this dialog to the last exclusive window relative to [param from_node], and then calls [method Window.popup_on_parent] on it. The dialog must have no current parent, otherwise the method fails.
See also [method set_unparent_when_invisible] and [method Node.get_last_exclusive_window].

### from_node :: Node

### parent_rect :: Rect2i

## popup_on_parent :: func Window.popup_on_parent(parent_rect: Rect2i) -> void
Popups the [Window] with a position shifted by parent [Window]'s position. If the [Window] is embedded, has the same effect as [method popup].

### parent_rect :: Rect2i

## remove_theme_color_override :: func Window.remove_theme_color_override(name: StringName) -> void
Removes a local override for a theme [Color] with the specified [param name] previously added by [method add_theme_color_override] or via the Inspector dock.

### name :: StringName

## remove_theme_constant_override :: func Window.remove_theme_constant_override(name: StringName) -> void
Removes a local override for a theme constant with the specified [param name] previously added by [method add_theme_constant_override] or via the Inspector dock.

### name :: StringName

## remove_theme_font_override :: func Window.remove_theme_font_override(name: StringName) -> void
Removes a local override for a theme [Font] with the specified [param name] previously added by [method add_theme_font_override] or via the Inspector dock.

### name :: StringName

## remove_theme_font_size_override :: func Window.remove_theme_font_size_override(name: StringName) -> void
Removes a local override for a theme font size with the specified [param name] previously added by [method add_theme_font_size_override] or via the Inspector dock.

### name :: StringName

## remove_theme_icon_override :: func Window.remove_theme_icon_override(name: StringName) -> void
Removes a local override for a theme icon with the specified [param name] previously added by [method add_theme_icon_override] or via the Inspector dock.

### name :: StringName

## remove_theme_stylebox_override :: func Window.remove_theme_stylebox_override(name: StringName) -> void
Removes a local override for a theme [StyleBox] with the specified [param name] previously added by [method add_theme_stylebox_override] or via the Inspector dock.

### name :: StringName

## request_attention :: func Window.request_attention() -> void
Tells the OS that the [Window] needs an attention. This makes the window stand out in some way depending on the system, e.g. it might blink on the task bar.

## reset_size :: func Window.reset_size() -> void
Resets the size to the minimum size, which is the max of [member min_size] and (if [member wrap_controls] is enabled) [method get_contents_minimum_size]. This is equivalent to calling [code]set_size(Vector2i())[/code] (or any size below the minimum).

## set_flag :: func Window.set_flag(flag: int, enabled: bool) -> void
Sets a specified window flag.

### flag :: int

### enabled :: bool

## set_ime_active :: func Window.set_ime_active(active: bool) -> void
If [param active] is [code]true[/code], enables system's native IME (Input Method Editor).

### active :: bool

## set_ime_position :: func Window.set_ime_position(position: Vector2i) -> void
Moves IME to the given position.

### position :: Vector2i

## set_layout_direction :: func Window.set_layout_direction(direction: int) -> void
Sets layout direction and text writing direction. Right-to-left layouts are necessary for certain languages (e.g. Arabic and Hebrew).

### direction :: int

## set_taskbar_progress_state :: func Window.set_taskbar_progress_state(state: int) -> void
Sets the type and state of the progress bar on the taskbar/dock icon of the [Window]. See [enum DisplayServer.ProgressState] for possible values and how each mode behaves.
[b]Note:[/b] This method is implemented only on Windows and macOS.

### state :: int

## set_taskbar_progress_value :: func Window.set_taskbar_progress_value(value: float) -> void
Creates a progress bar on the taskbar/dock icon of the [Window] if it does not exist, sets the progress of the icon.
[param value] acts as a relative percentage value, ranges from [code]0.0[/code] (lowest) to [code]1.0[/code] (highest).
[b]Note:[/b] This method is implemented only on Windows and macOS.

### value :: float

## set_unparent_when_invisible :: func Window.set_unparent_when_invisible(unparent: bool) -> void
If [param unparent] is [code]true[/code], the window is automatically unparented when going invisible.
[b]Note:[/b] Make sure to keep a reference to the node, otherwise it will be orphaned. You also need to manually call [method Node.queue_free] to free the window if it's not parented.

### unparent :: bool

## set_use_font_oversampling :: func Window.set_use_font_oversampling(enable: bool) -> void
Enables font oversampling. This makes fonts look better when they are scaled up.

### enable :: bool

## show :: func Window.show() -> void
Makes the [Window] appear. This enables interactions with the [Window] and doesn't change any of its property other than visibility (unlike e.g. [method popup]).

## start_drag :: func Window.start_drag() -> void
Starts an interactive drag operation on the window, using the current mouse position. Call this method when handling a mouse button being pressed to simulate a pressed event on the window's title bar. Using this method allows the window to participate in space switching, tiling, and other system features.

## start_resize :: func Window.start_resize(edge: int) -> void
Starts an interactive resize operation on the window, using the current mouse position. Call this method when handling a mouse button being pressed to simulate a pressed event on the window's edge.

### edge :: int

## about_to_popup :: func Window.about_to_popup() -> void
Emitted right after [method popup] call, before the [Window] appears or does anything.

## close_requested :: func Window.close_requested() -> void
Emitted when the [Window]'s close button is pressed or when [member popup_window] is enabled and user clicks outside the window.
This signal can be used to handle window closing, e.g. by connecting it to [method hide].

## dpi_changed :: func Window.dpi_changed() -> void
Emitted when the [Window]'s DPI changes as a result of OS-level changes (e.g. moving the window from a Retina display to a lower resolution one).
[b]Note:[/b] Only implemented on macOS and Linux (Wayland).

## files_dropped :: func Window.files_dropped(files: PackedStringArray) -> void
Emitted when files are dragged from the OS file manager and dropped in the game window. The argument is a list of file paths.
[codeblock]
func _ready():
	get_window().files_dropped.connect(on_files_dropped)

func on_files_dropped(files):
	print(files)
[/codeblock]
[b]Note:[/b] This signal only works with native windows, i.e. the main window and [Window]-derived nodes when [member Viewport.gui_embed_subwindows] is disabled in the main viewport.

### files :: PackedStringArray

## focus_entered :: func Window.focus_entered() -> void
Emitted when the [Window] gains focus.

## focus_exited :: func Window.focus_exited() -> void
Emitted when the [Window] loses its focus.

## go_back_requested :: func Window.go_back_requested() -> void
Emitted when a go back request is sent (e.g. pressing the "Back" button on Android), right after [constant Node.NOTIFICATION_WM_GO_BACK_REQUEST].

## mouse_entered :: func Window.mouse_entered() -> void
Emitted when the mouse cursor enters the [Window]'s visible area, that is not occluded behind other [Control]s or windows, provided its [member Viewport.gui_disable_input] is [code]false[/code] and regardless if it's currently focused or not.

## mouse_exited :: func Window.mouse_exited() -> void
Emitted when the mouse cursor leaves the [Window]'s visible area, that is not occluded behind other [Control]s or windows, provided its [member Viewport.gui_disable_input] is [code]false[/code] and regardless if it's currently focused or not.

## nonclient_window_input :: func Window.nonclient_window_input(event: InputEvent) -> void
Emitted when the mouse event is received by the custom decoration area defined by [member nonclient_area], and normal input to the window is blocked (such as when it has an exclusive child opened). [param event]'s position is in the embedder's coordinate system.

### event :: InputEvent

## output_max_linear_value_changed :: func Window.output_max_linear_value_changed(output_max_linear_value: float) -> void
Emitted when the output max linear value returned by [method Window.get_output_max_linear_value] has changed. This occurs when HDR output is enabled or disabled and when any HDR output luminance values of the window have changed, such as when the player adjusts their screen brightness setting or moves the window to a different screen. [param output_max_linear_value] is the new value.

### output_max_linear_value :: float

## theme_changed :: func Window.theme_changed() -> void
Emitted when the [constant NOTIFICATION_THEME_CHANGED] notification is sent.

## title_changed :: func Window.title_changed() -> void
Emitted when window title bar text is changed.

## titlebar_changed :: func Window.titlebar_changed() -> void
Emitted when window title bar decorations are changed, e.g. macOS window enter/exit full screen mode, or extend-to-title flag is changed.

## visibility_changed :: func Window.visibility_changed() -> void
Emitted when [Window] is made visible or disappears.

## window_input :: func Window.window_input(event: InputEvent) -> void
Emitted when the [Window] is currently focused and receives any input, passing the received event as an argument. The event's position, if present, is in the embedder's coordinate system.

### event :: InputEvent
