# SphereMesh :: <Native> class SphereMesh extends PrimitiveMesh
Class representing a spherical [PrimitiveMesh].
Class representing a spherical [PrimitiveMesh].

## height :: var SphereMesh.height: float
Full height of the sphere.

## is_hemisphere :: var SphereMesh.is_hemisphere: bool
If [code]true[/code], a hemisphere is created rather than a full sphere.
[b]Note:[/b] To get a regular hemisphere, the height and radius of the sphere must be equal.

## radial_segments :: var SphereMesh.radial_segments: int
Number of radial segments on the sphere.

## radius :: var SphereMesh.radius: float
Radius of sphere.

## rings :: var SphereMesh.rings: int
Number of segments along the height of the sphere.
