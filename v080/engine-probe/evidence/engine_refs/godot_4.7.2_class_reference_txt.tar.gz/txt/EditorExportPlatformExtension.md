# EditorExportPlatformExtension :: <Native> class EditorExportPlatformExtension extends EditorExportPlatform
Base class for custom [EditorExportPlatform] implementations (plugins).
External [EditorExportPlatform] implementations should inherit from this class.
To use [EditorExportPlatform], register it using the [method EditorPlugin.add_export_platform] method first.

## _can_export :: func EditorExportPlatformExtension._can_export(preset: EditorExportPreset, debug: bool) -> bool
Returns [code]true[/code] if the specified [param preset] is valid and can be exported. Use [method set_config_error] and [method set_config_missing_templates] to set error details.
Usual implementations call [method _has_valid_export_configuration] and [method _has_valid_project_configuration] to determine if exporting is possible.

### preset :: EditorExportPreset

### debug :: bool

## _cleanup :: func EditorExportPlatformExtension._cleanup() -> void
Called by the editor before platform is unregistered.

## _export_pack :: func EditorExportPlatformExtension._export_pack(preset: EditorExportPreset, debug: bool, path: String, flags: int) -> int
Creates a PCK archive at [param path] for the specified [param preset].
This method is called when "Export PCK/ZIP" button is pressed in the export dialog, with "Export as Patch" disabled, and PCK is selected as a file type.

### preset :: EditorExportPreset

### debug :: bool

### path :: String

### flags :: int

## _export_pack_patch :: func EditorExportPlatformExtension._export_pack_patch(preset: EditorExportPreset, debug: bool, path: String, patches: PackedStringArray, flags: int) -> int
Creates a patch PCK archive at [param path] for the specified [param preset], containing only the files that have changed since the last patch.
This method is called when "Export PCK/ZIP" button is pressed in the export dialog, with "Export as Patch" enabled, and PCK is selected as a file type.
[b]Note:[/b] The patches provided in [param patches] have already been loaded when this method is called and are merely provided as context. When empty the patches defined in the export preset have been loaded instead.

### preset :: EditorExportPreset

### debug :: bool

### path :: String

### patches :: PackedStringArray

### flags :: int

## _export_project :: func EditorExportPlatformExtension._export_project(preset: EditorExportPreset, debug: bool, path: String, flags: int) -> int
Creates a full project at [param path] for the specified [param preset].
This method is called when "Export" button is pressed in the export dialog.
This method implementation can call [method EditorExportPlatform.save_pack] or [method EditorExportPlatform.save_zip] to use default PCK/ZIP export process, or calls [method EditorExportPlatform.export_project_files] and implement custom callback for processing each exported file.

### preset :: EditorExportPreset

### debug :: bool

### path :: String

### flags :: int

## _export_zip :: func EditorExportPlatformExtension._export_zip(preset: EditorExportPreset, debug: bool, path: String, flags: int) -> int
Create a ZIP archive at [param path] for the specified [param preset].
This method is called when "Export PCK/ZIP" button is pressed in the export dialog, with "Export as Patch" disabled, and ZIP is selected as a file type.

### preset :: EditorExportPreset

### debug :: bool

### path :: String

### flags :: int

## _export_zip_patch :: func EditorExportPlatformExtension._export_zip_patch(preset: EditorExportPreset, debug: bool, path: String, patches: PackedStringArray, flags: int) -> int
Create a ZIP archive at [param path] for the specified [param preset], containing only the files that have changed since the last patch.
This method is called when "Export PCK/ZIP" button is pressed in the export dialog, with "Export as Patch" enabled, and ZIP is selected as a file type.
[b]Note:[/b] The patches provided in [param patches] have already been loaded when this method is called and are merely provided as context. When empty the patches defined in the export preset have been loaded instead.

### preset :: EditorExportPreset

### debug :: bool

### path :: String

### patches :: PackedStringArray

### flags :: int

## _get_binary_extensions :: func EditorExportPlatformExtension._get_binary_extensions(preset: EditorExportPreset) -> PackedStringArray
Returns array of supported binary extensions for the full project export.

### preset :: EditorExportPreset

## _get_debug_protocol :: func EditorExportPlatformExtension._get_debug_protocol() -> String
Returns protocol used for remote debugging. Default implementation return [code]tcp://[/code].

## _get_device_architecture :: func EditorExportPlatformExtension._get_device_architecture(device: int) -> String
Returns device architecture for one-click deploy.

### device :: int

## _get_export_option_visibility :: func EditorExportPlatformExtension._get_export_option_visibility(preset: EditorExportPreset, option: String) -> bool
Validates [param option] and returns visibility for the specified [param preset]. Default implementation return [code]true[/code] for all options.

### preset :: EditorExportPreset

### option :: String

## _get_export_option_warning :: func EditorExportPlatformExtension._get_export_option_warning(preset: EditorExportPreset, option: StringName) -> String
Validates [param option] and returns warning message for the specified [param preset]. Default implementation return empty string for all options.

### preset :: EditorExportPreset

### option :: StringName

## _get_export_options :: func EditorExportPlatformExtension._get_export_options() -> Dictionary[]
Returns a property list, as an [Array] of dictionaries. Each [Dictionary] must at least contain the [code]name: StringName[/code] and [code]type: Variant.Type[/code] entries.
Additionally, the following keys are supported:
- [code]hint: PropertyHint[/code]
- [code]hint_string: String[/code]
- [code]usage: PropertyUsageFlags[/code]
- [code]class_name: StringName[/code]
- [code]default_value: Variant[/code], default value of the property.
- [code]update_visibility: bool[/code], if set to [code]true[/code], [method _get_export_option_visibility] is called for each property when this property is changed.
- [code]required: bool[/code], if set to [code]true[/code], this property warnings are critical, and should be resolved to make export possible. This value is a hint for the [method _has_valid_export_configuration] implementation, and not used by the engine directly.
See also [method Object._get_property_list].

## _get_logo :: func EditorExportPlatformExtension._get_logo() -> Texture2D
Returns the platform logo displayed in the export dialog. The logo should be 32×32 pixels, adjusted for the current editor scale (see [method EditorInterface.get_editor_scale]).

## _get_name :: func EditorExportPlatformExtension._get_name() -> String
Returns export platform name.

## _get_option_icon :: func EditorExportPlatformExtension._get_option_icon(device: int) -> Texture2D
Returns the item icon for the specified [param device] in the one-click deploy menu. The icon should be 16×16 pixels, adjusted for the current editor scale (see [method EditorInterface.get_editor_scale]).

### device :: int

## _get_option_label :: func EditorExportPlatformExtension._get_option_label(device: int) -> String
Returns one-click deploy menu item label for the specified [param device].

### device :: int

## _get_option_tooltip :: func EditorExportPlatformExtension._get_option_tooltip(device: int) -> String
Returns one-click deploy menu item tooltip for the specified [param device].

### device :: int

## _get_options_count :: func EditorExportPlatformExtension._get_options_count() -> int
Returns the number of devices (or other options) available in the one-click deploy menu.

## _get_options_tooltip :: func EditorExportPlatformExtension._get_options_tooltip() -> String
Returns tooltip of the one-click deploy menu button.

## _get_os_name :: func EditorExportPlatformExtension._get_os_name() -> String
Returns target OS name.

## _get_platform_features :: func EditorExportPlatformExtension._get_platform_features() -> PackedStringArray
Returns array of platform specific features.

## _get_preset_features :: func EditorExportPlatformExtension._get_preset_features(preset: EditorExportPreset) -> PackedStringArray
Returns array of platform specific features for the specified [param preset].

### preset :: EditorExportPreset

## _get_run_icon :: func EditorExportPlatformExtension._get_run_icon() -> Texture2D
Returns the icon of the one-click deploy menu button. The icon should be 16×16 pixels, adjusted for the current editor scale (see [method EditorInterface.get_editor_scale]).

## _has_valid_export_configuration :: func EditorExportPlatformExtension._has_valid_export_configuration(preset: EditorExportPreset, debug: bool) -> bool
Returns [code]true[/code] if export configuration is valid.

### preset :: EditorExportPreset

### debug :: bool

## _has_valid_project_configuration :: func EditorExportPlatformExtension._has_valid_project_configuration(preset: EditorExportPreset) -> bool
Returns [code]true[/code] if project configuration is valid.

### preset :: EditorExportPreset

## _initialize :: func EditorExportPlatformExtension._initialize() -> void
Initializes the plugin. Called by the editor when platform is registered.

## _is_executable :: func EditorExportPlatformExtension._is_executable(path: String) -> bool
Returns [code]true[/code] if specified file is a valid executable (native executable or script) for the target platform.

### path :: String

## _poll_export :: func EditorExportPlatformExtension._poll_export() -> bool
Returns [code]true[/code] if one-click deploy options are changed and editor interface should be updated.

## _run :: func EditorExportPlatformExtension._run(preset: EditorExportPreset, device: int, debug_flags: int) -> int
This method is called when [param device] one-click deploy menu option is selected.
Implementation should export project to a temporary location, upload and run it on the specific [param device], or perform another action associated with the menu item.

### preset :: EditorExportPreset

### device :: int

### debug_flags :: int

## _should_update_export_options :: func EditorExportPlatformExtension._should_update_export_options() -> bool
Returns [code]true[/code] if export options list is changed and presets should be updated.

## get_config_error :: func EditorExportPlatformExtension.get_config_error() -> String
Returns current configuration error message text. This method should be called only from the [method _can_export], [method _has_valid_export_configuration], or [method _has_valid_project_configuration] implementations.

## get_config_missing_templates :: func EditorExportPlatformExtension.get_config_missing_templates() -> bool
Returns [code]true[/code] is export templates are missing from the current configuration. This method should be called only from the [method _can_export], [method _has_valid_export_configuration], or [method _has_valid_project_configuration] implementations.

## set_config_error :: func EditorExportPlatformExtension.set_config_error(error_text: String) -> void
Sets current configuration error message text. This method should be called only from the [method _can_export], [method _has_valid_export_configuration], or [method _has_valid_project_configuration] implementations.

### error_text :: String

## set_config_missing_templates :: func EditorExportPlatformExtension.set_config_missing_templates(missing_templates: bool) -> void
Set to [code]true[/code] is export templates are missing from the current configuration. This method should be called only from the [method _can_export], [method _has_valid_export_configuration], or [method _has_valid_project_configuration] implementations.

### missing_templates :: bool
