# GLTFSkeleton :: <Native> class GLTFSkeleton extends Resource


## joints :: var GLTFSkeleton.joints: PackedInt32Array

## roots :: var GLTFSkeleton.roots: PackedInt32Array

## get_bone_attachment :: func GLTFSkeleton.get_bone_attachment(idx: int) -> BoneAttachment3D

### idx :: int

## get_bone_attachment_count :: func GLTFSkeleton.get_bone_attachment_count() -> int

## get_godot_bone_node :: func GLTFSkeleton.get_godot_bone_node() -> Dictionary
Returns a [Dictionary] that maps skeleton bone indices to the indices of glTF nodes. This property is unused during import, and only set during export. In a glTF file, a bone is a node, so Godot converts skeleton bones to glTF nodes.

## get_godot_skeleton :: func GLTFSkeleton.get_godot_skeleton() -> Skeleton3D

## get_unique_names :: func GLTFSkeleton.get_unique_names() -> String[]

## set_godot_bone_node :: func GLTFSkeleton.set_godot_bone_node(godot_bone_node: Dictionary) -> void
Sets a [Dictionary] that maps skeleton bone indices to the indices of glTF nodes. This property is unused during import, and only set during export. In a glTF file, a bone is a node, so Godot converts skeleton bones to glTF nodes.

### godot_bone_node :: Dictionary

## set_unique_names :: func GLTFSkeleton.set_unique_names(unique_names: String[]) -> void

### unique_names :: String[]
