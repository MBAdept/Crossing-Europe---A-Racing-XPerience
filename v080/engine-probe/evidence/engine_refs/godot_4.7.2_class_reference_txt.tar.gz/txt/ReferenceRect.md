# ReferenceRect :: <Native> class ReferenceRect extends Control
A rectangular box for designing UIs.
A rectangular box that displays only a colored border around its rectangle (see [method Control.get_rect]). It can be used to visualize the extents of a [Control] node, for testing purposes.

## border_color :: var ReferenceRect.border_color: Color
Sets the border color of the [ReferenceRect].

## border_width :: var ReferenceRect.border_width: float
Sets the border width of the [ReferenceRect]. The border grows both inwards and outwards with respect to the rectangle box.

## editor_only :: var ReferenceRect.editor_only: bool
If [code]true[/code], the [ReferenceRect] will only be visible while in editor. Otherwise, [ReferenceRect] will be visible in the running project.
