# ShaderIncludeDB :: <Native> class ShaderIncludeDB extends Object
Internal database of built in shader include files.
This object contains shader fragments from Godot's internal shaders. These can be used when access to internal uniform buffers and/or internal functions is required for instance when composing compositor effects or compute shaders. Only fragments for the current rendering device are loaded.

## get_built_in_include_file :: func ShaderIncludeDB.get_built_in_include_file(filename: String) -> String
Returns the code for the built-in shader fragment. You can also access this in your shader code through [code]#include "filename"[/code].

### filename :: String

## has_built_in_include_file :: func ShaderIncludeDB.has_built_in_include_file(filename: String) -> bool
Returns [code]true[/code] if an include file with this name exists.

### filename :: String

## list_built_in_include_files :: func ShaderIncludeDB.list_built_in_include_files() -> PackedStringArray
Returns a list of built-in include files that are currently registered.
