# FileDialog :: <Native> class FileDialog extends ConfirmationDialog
A dialog for selecting files or directories in the filesystem.
[FileDialog] is a preset dialog used to choose files and directories in the filesystem. It supports filter masks. [FileDialog] automatically sets its window title according to the [member file_mode]. If you want to use a custom title, disable this by setting [member mode_overrides_title] to [code]false[/code].
[b]Note:[/b] [FileDialog] is invisible by default. To make it visible, call one of the [code]popup_*[/code] methods from [Window] on the node, such as [method Window.popup_centered_clamped].

## FILE_MODE_OPEN_FILE :: const FileDialog.FILE_MODE_OPEN_FILE: FileMode = 0
The dialog allows selecting one, and only one file.

## FILE_MODE_OPEN_FILES :: const FileDialog.FILE_MODE_OPEN_FILES: FileMode = 1
The dialog allows selecting multiple files.

## FILE_MODE_OPEN_DIR :: const FileDialog.FILE_MODE_OPEN_DIR: FileMode = 2
The dialog only allows selecting a directory, disallowing the selection of any file.

## FILE_MODE_OPEN_ANY :: const FileDialog.FILE_MODE_OPEN_ANY: FileMode = 3
The dialog allows selecting one file or directory.

## FILE_MODE_SAVE_FILE :: const FileDialog.FILE_MODE_SAVE_FILE: FileMode = 4
The dialog will warn when a file exists.

## ACCESS_RESOURCES :: const FileDialog.ACCESS_RESOURCES: Access = 0
The dialog only allows accessing files under the [Resource] path ([code]res://[/code]).

## ACCESS_USERDATA :: const FileDialog.ACCESS_USERDATA: Access = 1
The dialog only allows accessing files under user data path ([code]user://[/code]).

## ACCESS_FILESYSTEM :: const FileDialog.ACCESS_FILESYSTEM: Access = 2
The dialog allows accessing files on the whole file system.

## DISPLAY_THUMBNAILS :: const FileDialog.DISPLAY_THUMBNAILS: DisplayMode = 0
The dialog displays files as a grid of thumbnails. Use [theme_item thumbnail_size] to adjust their size.

## DISPLAY_LIST :: const FileDialog.DISPLAY_LIST: DisplayMode = 1
The dialog displays files as a list of filenames.

## CUSTOMIZATION_HIDDEN_FILES :: const FileDialog.CUSTOMIZATION_HIDDEN_FILES: Customization = 0
Toggles visibility of the favorite button, and the favorite list on the left side of the dialog.
Equivalent to [member hidden_files_toggle_enabled].

## CUSTOMIZATION_CREATE_FOLDER :: const FileDialog.CUSTOMIZATION_CREATE_FOLDER: Customization = 1
If enabled, shows the button for creating new directories (when using [constant FILE_MODE_OPEN_DIR], [constant FILE_MODE_OPEN_ANY], or [constant FILE_MODE_SAVE_FILE]).
Equivalent to [member folder_creation_enabled].

## CUSTOMIZATION_FILE_FILTER :: const FileDialog.CUSTOMIZATION_FILE_FILTER: Customization = 2
If enabled, shows the toggle file filter button.
Equivalent to [member file_filter_toggle_enabled].

## CUSTOMIZATION_FILE_SORT :: const FileDialog.CUSTOMIZATION_FILE_SORT: Customization = 3
If enabled, shows the file sorting options button.
Equivalent to [member file_sort_options_enabled].

## CUSTOMIZATION_FAVORITES :: const FileDialog.CUSTOMIZATION_FAVORITES: Customization = 4
If enabled, shows the toggle favorite button and favorite list on the left side of the dialog.
Equivalent to [member favorites_enabled].

## CUSTOMIZATION_RECENT :: const FileDialog.CUSTOMIZATION_RECENT: Customization = 5
If enabled, shows the recent directories list on the left side of the dialog.
Equivalent to [member recent_list_enabled].

## CUSTOMIZATION_LAYOUT :: const FileDialog.CUSTOMIZATION_LAYOUT: Customization = 6
If enabled, shows the layout switch buttons (list/thumbnails).
Equivalent to [member layout_toggle_enabled].

## CUSTOMIZATION_OVERWRITE_WARNING :: const FileDialog.CUSTOMIZATION_OVERWRITE_WARNING: Customization = 7
If enabled, the [FileDialog] will warn the user before overwriting files in save mode.
Equivalent to [member overwrite_warning_enabled].

## CUSTOMIZATION_DELETE :: const FileDialog.CUSTOMIZATION_DELETE: Customization = 8
If enabled, the context menu will show the "Delete" option, which allows moving files and folders to trash.
Equivalent to [member deleting_enabled].

## access :: var FileDialog.access: FileDialog.Access
The file system access scope.
[b]Warning:[/b] In Web builds, FileDialog cannot access the host file system. In sandboxed Linux and macOS environments, [member use_native_dialog] is automatically used to allow limited access to host file system.

## current_dir :: var FileDialog.current_dir: String
The current working directory of the file dialog.
[b]Note:[/b] For native file dialogs, this property is only treated as a hint and may not be respected by specific OS implementations.

## current_file :: var FileDialog.current_file: String
The currently selected file of the file dialog.

## current_path :: var FileDialog.current_path: String
The currently selected file path of the file dialog.

## deleting_enabled :: var FileDialog.deleting_enabled: bool
If [code]true[/code], the context menu will show the "Delete" option, which allows moving files and folders to trash.

## dialog_hide_on_ok :: var FileDialog.dialog_hide_on_ok: bool

## display_mode :: var FileDialog.display_mode: FileDialog.DisplayMode
Display mode of the dialog's file list.

## favorites_enabled :: var FileDialog.favorites_enabled: bool
If [code]true[/code], shows the toggle favorite button and favorite list on the left side of the dialog.

## file_filter_toggle_enabled :: var FileDialog.file_filter_toggle_enabled: bool
If [code]true[/code], shows the toggle file filter button.

## file_mode :: var FileDialog.file_mode: FileDialog.FileMode
The dialog's open or save mode, which affects the selection behavior.

## file_sort_options_enabled :: var FileDialog.file_sort_options_enabled: bool
If [code]true[/code], shows the file sorting options button.

## filename_filter :: var FileDialog.filename_filter: String
The filter for file names (case-insensitive). When set to a non-empty string, only files that contains the substring will be shown. [member filename_filter] can be edited by the user with the filter button at the top of the file dialog.
See also [member filters], which should be used to restrict the file types that can be selected instead of [member filename_filter] which is meant to be set by the user.

## filters :: var FileDialog.filters: PackedStringArray
The available file type filters. Each filter string in the array should be formatted like this: [code]*.png,*.jpg,*.jpeg;Image Files;image/png,image/jpeg[/code]. The description text of the filter is optional and can be omitted. Both file extensions and MIME type should be always set.
[b]Note:[/b] Embedded file dialogs and Windows file dialogs support only file extensions, while Android, Linux, and macOS file dialogs also support MIME types.

## folder_creation_enabled :: var FileDialog.folder_creation_enabled: bool
If [code]true[/code], shows the button for creating new directories (when using [constant FILE_MODE_OPEN_DIR], [constant FILE_MODE_OPEN_ANY], or [constant FILE_MODE_SAVE_FILE]), and the context menu will have the "New Folder..." option.

## hidden_files_toggle_enabled :: var FileDialog.hidden_files_toggle_enabled: bool
If [code]true[/code], shows the toggle hidden files button.

## layout_toggle_enabled :: var FileDialog.layout_toggle_enabled: bool
If [code]true[/code], shows the layout switch buttons (list/thumbnails).

## mode_overrides_title :: var FileDialog.mode_overrides_title: bool
If [code]true[/code], changing the [member file_mode] property will set the window title accordingly (e.g. setting [member file_mode] to [constant FILE_MODE_OPEN_FILE] will change the window title to "Open a File").

## option_count :: var FileDialog.option_count: int
The number of additional [OptionButton]s and [CheckBox]es in the dialog.

## option_{index}/default :: var FileDialog.option_{index}/default: int
The default value for the option at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. option_count - 1[/code] range.

## option_{index}/name :: var FileDialog.option_{index}/name: String
The name of the option at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. option_count - 1[/code] range.

## option_{index}/values :: var FileDialog.option_{index}/values: PackedStringArray
The list of values for the option at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. option_count - 1[/code] range.

## overwrite_warning_enabled :: var FileDialog.overwrite_warning_enabled: bool
If [code]true[/code], the [FileDialog] will warn the user before overwriting files in save mode.

## recent_list_enabled :: var FileDialog.recent_list_enabled: bool
If [code]true[/code], shows the recent directories list on the left side of the dialog.

## root_subfolder :: var FileDialog.root_subfolder: String
If non-empty, the given sub-folder will be "root" of this [FileDialog], i.e. user won't be able to go to its parent directory.
[b]Note:[/b] This property is ignored by native file dialogs.

## show_hidden_files :: var FileDialog.show_hidden_files: bool
If [code]true[/code], the dialog will show hidden files.
[b]Note:[/b] This property is ignored by native file dialogs on Android and Linux.

## size :: var FileDialog.size: Vector2i

## title :: var FileDialog.title: String

## use_native_dialog :: var FileDialog.use_native_dialog: bool
If [code]true[/code], and if supported by the current [DisplayServer], OS native dialog will be used instead of custom one.
[b]Note:[/b] On Android, it is only supported when using [constant ACCESS_FILESYSTEM]. For access mode [constant ACCESS_RESOURCES] and [constant ACCESS_USERDATA], the system will fall back to custom FileDialog.
[b]Note:[/b] On Linux and macOS, sandboxed apps always use native dialogs to access the host file system.
[b]Note:[/b] On macOS, sandboxed apps will save security-scoped bookmarks to retain access to the opened folders across multiple sessions. Use [method OS.get_granted_permissions] to get a list of saved bookmarks.
[b]Note:[/b] Native dialogs are isolated from the base process, file dialog properties can't be modified once the dialog is shown.
[b]Note:[/b] This property is ignored in [EditorFileDialog].

## file_disabled_color :: <Theme> var FileDialog.file_disabled_color: Color
The color tint for disabled files (when the [FileDialog] is used in open folder mode).

## file_icon_color :: <Theme> var FileDialog.file_icon_color: Color
The color modulation applied to the file icon.

## folder_icon_color :: <Theme> var FileDialog.folder_icon_color: Color
The color modulation applied to the folder icon.

## thumbnail_size :: <Theme> var FileDialog.thumbnail_size: int
The size of thumbnail icons when [constant DISPLAY_THUMBNAILS] is enabled.

## back_folder :: <Theme> var FileDialog.back_folder: Texture2D
Custom icon for the back arrow.

## create_folder :: <Theme> var FileDialog.create_folder: Texture2D
Custom icon for the create folder button.

## favorite :: <Theme> var FileDialog.favorite: Texture2D
Custom icon for favorite folder button.

## favorite_down :: <Theme> var FileDialog.favorite_down: Texture2D
Custom icon for button to move down a favorite entry.

## favorite_up :: <Theme> var FileDialog.favorite_up: Texture2D
Custom icon for button to move up a favorite entry.

## file :: <Theme> var FileDialog.file: Texture2D
Custom icon for files.

## file_thumbnail :: <Theme> var FileDialog.file_thumbnail: Texture2D
Icon for files when in thumbnail mode.

## folder :: <Theme> var FileDialog.folder: Texture2D
Custom icon for folders.

## folder_thumbnail :: <Theme> var FileDialog.folder_thumbnail: Texture2D
Icon for folders when in thumbnail mode.

## forward_folder :: <Theme> var FileDialog.forward_folder: Texture2D
Custom icon for the forward arrow.

## list_mode :: <Theme> var FileDialog.list_mode: Texture2D
Icon for the button that enables list mode.

## menu_copy_path :: <Theme> var FileDialog.menu_copy_path: Texture2D
Icon for the "Copy Path" context menu option.

## menu_delete :: <Theme> var FileDialog.menu_delete: Texture2D
Icon for the "Delete" context menu option.

## menu_new_folder :: <Theme> var FileDialog.menu_new_folder: Texture2D
Icon for the "New Folder..." context menu option. Usually it should be the same as [theme_item create_folder]; leave it empty if you want the context menu to show no icons.

## menu_open_bundle :: <Theme> var FileDialog.menu_open_bundle: Texture2D
Icon for the "Show Package Contents" context menu option. The option only appears for macOS bundles.

## menu_refresh :: <Theme> var FileDialog.menu_refresh: Texture2D
Icon for the "Refresh" context menu option. Usually it should be the same as [theme_item reload]; leave it empty if you want the context menu to show no icons.

## menu_show_in_file_manager :: <Theme> var FileDialog.menu_show_in_file_manager: Texture2D
Icon for the "Show in File Manager" context menu option.

## parent_folder :: <Theme> var FileDialog.parent_folder: Texture2D
Custom icon for the parent folder arrow.

## reload :: <Theme> var FileDialog.reload: Texture2D
Custom icon for the reload button.

## sort :: <Theme> var FileDialog.sort: Texture2D
Custom icon for the sorting options menu.

## thumbnail_mode :: <Theme> var FileDialog.thumbnail_mode: Texture2D
Icon for the button that enables thumbnail mode.

## toggle_filename_filter :: <Theme> var FileDialog.toggle_filename_filter: Texture2D
Custom icon for the toggle button for the filter for file names.

## toggle_hidden :: <Theme> var FileDialog.toggle_hidden: Texture2D
Custom icon for the toggle hidden button.

## add_filter :: func FileDialog.add_filter(filter: String, description: String = "", mime_type: String = "") -> void
Adds a comma-separated file extension [param filter] and comma-separated MIME type [param mime_type] option to the [FileDialog] with an optional [param description], which restricts what files can be picked.
A [param filter] should be of the form [code]"filename.extension"[/code], where filename and extension can be [code]*[/code] to match any string. Filters starting with [code].[/code] (i.e. empty filenames) are not allowed.
For example, a [param filter] of [code]"*.png, *.jpg"[/code], a [param mime_type] of [code]image/png, image/jpeg[/code], and a [param description] of [code]"Images"[/code] results in filter text "Images (*.png, *.jpg)".
[b]Note:[/b] Embedded file dialogs and Windows file dialogs support only file extensions, while Android, Linux, and macOS file dialogs also support MIME types.

### filter :: String

### description :: String

### mime_type :: String

## add_option :: func FileDialog.add_option(name: String, values: PackedStringArray, default_value_index: int) -> void
Adds an additional [OptionButton] to the file dialog. If [param values] is empty, a [CheckBox] is added instead.
[param default_value_index] should be an index of the value in the [param values]. If [param values] is empty it should be either [code]1[/code] (checked), or [code]0[/code] (unchecked).

### name :: String

### values :: PackedStringArray

### default_value_index :: int

## clear_filename_filter :: func FileDialog.clear_filename_filter() -> void
Clear the filter for file names.

## clear_filters :: func FileDialog.clear_filters() -> void
Clear all the added filters in the dialog.

## deselect_all :: func FileDialog.deselect_all() -> void
Clear all currently selected items in the dialog.

## get_favorite_list :: func FileDialog.get_favorite_list() -> PackedStringArray
Returns the list of favorite directories, which is shared by all [FileDialog] nodes. Useful to store the list of favorites between project sessions. This method can be called only from the main thread.

## get_line_edit :: func FileDialog.get_line_edit() -> LineEdit
Returns the LineEdit for the selected file.
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member CanvasItem.visible] property.

## get_option_default :: func FileDialog.get_option_default(option: int) -> int
Returns the default value index of the [OptionButton] or [CheckBox] with index [param option].

### option :: int

## get_option_name :: func FileDialog.get_option_name(option: int) -> String
Returns the name of the [OptionButton] or [CheckBox] with index [param option].

### option :: int

## get_option_values :: func FileDialog.get_option_values(option: int) -> PackedStringArray
Returns an array of values of the [OptionButton] with index [param option].

### option :: int

## get_recent_list :: func FileDialog.get_recent_list() -> PackedStringArray
Returns the list of recent directories, which is shared by all [FileDialog] nodes. Useful to store the list of recents between project sessions. This method can be called only from the main thread.

## get_selected_options :: func FileDialog.get_selected_options() -> Dictionary
Returns a [Dictionary] with the selected values of the additional [OptionButton]s and/or [CheckBox]es. [Dictionary] keys are names and values are selected value indices.

## get_vbox :: func FileDialog.get_vbox() -> VBoxContainer
Returns the vertical box container of the dialog, custom controls can be added to it.
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member CanvasItem.visible] property.
[b]Note:[/b] Changes to this node are ignored by native file dialogs, use [method add_option] to add custom elements to the dialog instead.

## invalidate :: func FileDialog.invalidate() -> void
Invalidates and updates this dialog's content list.
[b]Note:[/b] This method does nothing on native file dialogs.

## is_customization_flag_enabled :: func FileDialog.is_customization_flag_enabled(flag: int) -> bool
Returns [code]true[/code] if the provided [param flag] is enabled.

### flag :: int

## popup_file_dialog :: func FileDialog.popup_file_dialog() -> void
Shows the [FileDialog] using the default size and position for file dialogs, and selects the file name if there is a current file.

## set_customization_flag_enabled :: func FileDialog.set_customization_flag_enabled(flag: int, enabled: bool) -> void
Sets the specified customization [param flag], allowing to customize the features available in this [FileDialog].

### flag :: int

### enabled :: bool

## set_favorite_list :: func FileDialog.set_favorite_list(favorites: PackedStringArray) -> void
Sets the list of favorite directories, which is shared by all [FileDialog] nodes. Useful to restore the list of favorites saved with [method get_favorite_list]. This method can be called only from the main thread.
[b]Note:[/b] [FileDialog] will update its internal [ItemList] of favorites when its visibility changes. Be sure to call this method earlier if you want your changes to have effect.

### favorites :: PackedStringArray

## set_get_icon_callback :: func FileDialog.set_get_icon_callback(callback: Callable) -> void
Sets the callback used by the [FileDialog] nodes to get a file icon, when [constant DISPLAY_LIST] mode is used. The callback should take a single [String] argument (file path), and return a [Texture2D]. If an invalid texture is returned, the [theme_item file] icon will be used instead.

### callback :: Callable

## set_get_thumbnail_callback :: func FileDialog.set_get_thumbnail_callback(callback: Callable) -> void
Sets the callback used by the [FileDialog] nodes to get a file icon, when [constant DISPLAY_THUMBNAILS] mode is used. The callback should take a single [String] argument (file path), and return a [Texture2D]. If an invalid texture is returned, the [theme_item file_thumbnail] icon will be used instead.
Thumbnails are usually more complex and may take a while to load. To avoid stalling the application, you can use [ImageTexture] to asynchronously create the thumbnail.
[codeblock]
func _ready():
	FileDialog.set_get_thumbnail_callback(thumbnail_method)

func thumbnail_method(path):
	var image_texture = ImageTexture.new()
	make_thumbnail_async(path, image_texture)
	return image_texture

func make_thumbnail_async(path, image_texture):
	var thumbnail_texture = await generate_thumbnail(path) # Some method that generates a thumbnail.
	image_texture.set_image(thumbnail_texture.get_image())
[/codeblock]

### callback :: Callable

## set_option_default :: func FileDialog.set_option_default(option: int, default_value_index: int) -> void
Sets the default value index of the [OptionButton] or [CheckBox] with index [param option].

### option :: int

### default_value_index :: int

## set_option_name :: func FileDialog.set_option_name(option: int, name: String) -> void
Sets the name of the [OptionButton] or [CheckBox] with index [param option].

### option :: int

### name :: String

## set_option_values :: func FileDialog.set_option_values(option: int, values: PackedStringArray) -> void
Sets the option values of the [OptionButton] with index [param option].

### option :: int

### values :: PackedStringArray

## set_recent_list :: func FileDialog.set_recent_list(recents: PackedStringArray) -> void
Sets the list of recent directories, which is shared by all [FileDialog] nodes. Useful to restore the list of recents saved with [method set_recent_list]. This method can be called only from the main thread.
[b]Note:[/b] [FileDialog] will update its internal [ItemList] of recent directories when its visibility changes. Be sure to call this method earlier if you want your changes to have effect.

### recents :: PackedStringArray

## dir_selected :: func FileDialog.dir_selected(dir: String) -> void
Emitted when the user selects a directory.

### dir :: String

## file_selected :: func FileDialog.file_selected(path: String) -> void
Emitted when the user selects a file by double-clicking it or pressing the [b]OK[/b] button.

### path :: String

## filename_filter_changed :: func FileDialog.filename_filter_changed(filter: String) -> void
Emitted when the filter for file names changes.

### filter :: String

## files_selected :: func FileDialog.files_selected(paths: PackedStringArray) -> void
Emitted when the user selects multiple files.

### paths :: PackedStringArray
