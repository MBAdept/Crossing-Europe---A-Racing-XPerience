# OpenXRStructureBase :: <Native> class OpenXRStructureBase extends RefCounted
Object for storing OpenXR structure data.
Object for storing OpenXR structure data that is passed when calling into OpenXR APIs.

## next :: var OpenXRStructureBase.next: OpenXRStructureBase
Setting another structure object here chains these structures together to extend the API functionality. Consult the OpenXR documentation for which structures can be used with a given API call.

## _get_header :: func OpenXRStructureBase._get_header(next: int) -> int

### next :: int

## get_structure_type :: func OpenXRStructureBase.get_structure_type() -> int
Returns the structure type (OpenXR [code]XrStructureType[/code]) used for this structure.
