# VisualShaderNodeColorFunc :: <Native> class VisualShaderNodeColorFunc extends VisualShaderNode
A [Color] function to be used within the visual shader graph.
Accept a [Color] to the input port and transform it according to [member function].

## FUNC_GRAYSCALE :: const VisualShaderNodeColorFunc.FUNC_GRAYSCALE: Function = 0
Converts the color to grayscale using the following formula:
[codeblock]
vec3 c = input;
float max1 = max(c.r, c.g);
float max2 = max(max1, c.b);
float max3 = max(max1, max2);
return vec3(max3, max3, max3);
[/codeblock]

## FUNC_HSV2RGB :: const VisualShaderNodeColorFunc.FUNC_HSV2RGB: Function = 1
Converts HSV vector to RGB equivalent.

## FUNC_RGB2HSV :: const VisualShaderNodeColorFunc.FUNC_RGB2HSV: Function = 2
Converts RGB vector to HSV equivalent.

## FUNC_SEPIA :: const VisualShaderNodeColorFunc.FUNC_SEPIA: Function = 3
Applies sepia tone effect using the following formula:
[codeblock]
vec3 c = input;
float r = (c.r * 0.393) + (c.g * 0.769) + (c.b * 0.189);
float g = (c.r * 0.349) + (c.g * 0.686) + (c.b * 0.168);
float b = (c.r * 0.272) + (c.g * 0.534) + (c.b * 0.131);
return vec3(r, g, b);
[/codeblock]

## FUNC_LINEAR_TO_SRGB :: const VisualShaderNodeColorFunc.FUNC_LINEAR_TO_SRGB: Function = 4
Converts color from linear encoding to nonlinear sRGB encoding using the following formula:
[codeblock]
const vec3 a = vec3(0.055f);
return mix((vec3(1.0f) + a) * pow(c.rgb, vec3(1.0f / 2.4f)) - a, 12.92f * c.rgb, lessThan(c.rgb, vec3(0.0031308f)));
[/codeblock]
The Compatibility renderer uses a simpler formula that may produce undefined behavior with negative input values:
[codeblock]
vec3 c = input;
return max(vec3(1.055) * pow(c, vec3(0.416666667)) - vec3(0.055), vec3(0.0));
[/codeblock]

## FUNC_SRGB_TO_LINEAR :: const VisualShaderNodeColorFunc.FUNC_SRGB_TO_LINEAR: Function = 5
Converts color from nonlinear sRGB encoding to linear encoding using the following formula:
[codeblock]
vec3 c = input;
return mix(pow((c.rgb + vec3(0.055)) * (1.0 / (1.0 + 0.055)), vec3(2.4)), c.rgb * (1.0 / 12.92), lessThan(c.rgb, vec3(0.04045)));
[/codeblock]
The Compatibility renderer uses a simpler formula that behaves poorly with negative input values:
[codeblock]
vec3 c = input;
return c * (c * (c * 0.305306011 + 0.682171111) + 0.012522878);
[/codeblock]

## FUNC_MAX :: const VisualShaderNodeColorFunc.FUNC_MAX: Function = 6
Represents the size of the [enum Function] enum.

## function :: var VisualShaderNodeColorFunc.function: VisualShaderNodeColorFunc.Function
A function to be applied to the input color.
