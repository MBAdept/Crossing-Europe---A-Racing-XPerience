# AudioEffectStereoEnhance :: <Native> class AudioEffectStereoEnhance extends AudioEffect
Adds a stereo manipulation audio effect to an audio bus.
Controls gain of the side channels, and widens the stereo image.
Adjusts gain of the left and right channels, and makes mono sounds stereo through phase shifting.

## pan_pullout :: var AudioEffectStereoEnhance.pan_pullout: float
Gain of the side channels, if they exist. A value of 0 will downmix stereo to mono. Value can range from 0 to 4.

## surround :: var AudioEffectStereoEnhance.surround: float
Widens the stereo image through phase shifting in conjunction with [member time_pullout_ms]. Just pans sound to the left channel if [member time_pullout_ms] is 0. Value can range from 0 to 1.

## time_pullout_ms :: var AudioEffectStereoEnhance.time_pullout_ms: float
Widens the stereo image through phase shifting in conjunction with [member surround]. Just delays the right channel if [member surround] is 0. Value is in milliseconds, and can range from 0 to 50.
