# RDTextureView :: <Native> class RDTextureView extends RefCounted
Texture view (used by [RenderingDevice]).
This object is used by [RenderingDevice].

## format_override :: var RDTextureView.format_override: RenderingDevice.DataFormat
Optional override for the data format to return sampled values in. The corresponding [RDTextureFormat] must have had this added as a shareable format. The default value of [constant RenderingDevice.DATA_FORMAT_MAX] does not override the format.

## swizzle_a :: var RDTextureView.swizzle_a: RenderingDevice.TextureSwizzle
The channel to sample when sampling the alpha channel.

## swizzle_b :: var RDTextureView.swizzle_b: RenderingDevice.TextureSwizzle
The channel to sample when sampling the blue color channel.

## swizzle_g :: var RDTextureView.swizzle_g: RenderingDevice.TextureSwizzle
The channel to sample when sampling the green color channel.

## swizzle_r :: var RDTextureView.swizzle_r: RenderingDevice.TextureSwizzle
The channel to sample when sampling the red color channel.
