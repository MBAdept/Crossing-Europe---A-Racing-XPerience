# VisualShaderNodeUIntFunc :: <Native> class VisualShaderNodeUIntFunc extends VisualShaderNode
An unsigned scalar integer function to be used within the visual shader graph.
Accept an unsigned integer scalar ([code]x[/code]) to the input port and transform it according to [member function].

## FUNC_NEGATE :: const VisualShaderNodeUIntFunc.FUNC_NEGATE: Function = 0
Negates the [code]x[/code] using [code]-(x)[/code].

## FUNC_BITWISE_NOT :: const VisualShaderNodeUIntFunc.FUNC_BITWISE_NOT: Function = 1
Returns the result of bitwise [code]NOT[/code] operation on the integer. Translates to [code]~a[/code] in the Godot Shader Language.

## FUNC_MAX :: const VisualShaderNodeUIntFunc.FUNC_MAX: Function = 2
Represents the size of the [enum Function] enum.

## function :: var VisualShaderNodeUIntFunc.function: VisualShaderNodeUIntFunc.Function
A function to be applied to the scalar.
