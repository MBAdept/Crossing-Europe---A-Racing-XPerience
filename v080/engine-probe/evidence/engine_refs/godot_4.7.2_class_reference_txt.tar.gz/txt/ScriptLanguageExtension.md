# ScriptLanguageExtension :: <Native> class ScriptLanguageExtension extends ScriptLanguage


## LOOKUP_RESULT_SCRIPT_LOCATION :: const ScriptLanguageExtension.LOOKUP_RESULT_SCRIPT_LOCATION: LookupResultType = 0

## LOOKUP_RESULT_CLASS :: const ScriptLanguageExtension.LOOKUP_RESULT_CLASS: LookupResultType = 1

## LOOKUP_RESULT_CLASS_CONSTANT :: const ScriptLanguageExtension.LOOKUP_RESULT_CLASS_CONSTANT: LookupResultType = 2

## LOOKUP_RESULT_CLASS_PROPERTY :: const ScriptLanguageExtension.LOOKUP_RESULT_CLASS_PROPERTY: LookupResultType = 3

## LOOKUP_RESULT_CLASS_METHOD :: const ScriptLanguageExtension.LOOKUP_RESULT_CLASS_METHOD: LookupResultType = 4

## LOOKUP_RESULT_CLASS_SIGNAL :: const ScriptLanguageExtension.LOOKUP_RESULT_CLASS_SIGNAL: LookupResultType = 5

## LOOKUP_RESULT_CLASS_ENUM :: const ScriptLanguageExtension.LOOKUP_RESULT_CLASS_ENUM: LookupResultType = 6

## LOOKUP_RESULT_CLASS_TBD_GLOBALSCOPE :: const ScriptLanguageExtension.LOOKUP_RESULT_CLASS_TBD_GLOBALSCOPE: LookupResultType = 7

## LOOKUP_RESULT_CLASS_ANNOTATION :: const ScriptLanguageExtension.LOOKUP_RESULT_CLASS_ANNOTATION: LookupResultType = 8

## LOOKUP_RESULT_LOCAL_CONSTANT :: const ScriptLanguageExtension.LOOKUP_RESULT_LOCAL_CONSTANT: LookupResultType = 9

## LOOKUP_RESULT_LOCAL_VARIABLE :: const ScriptLanguageExtension.LOOKUP_RESULT_LOCAL_VARIABLE: LookupResultType = 10

## LOOKUP_RESULT_MAX :: const ScriptLanguageExtension.LOOKUP_RESULT_MAX: LookupResultType = 11

## LOCATION_LOCAL :: const ScriptLanguageExtension.LOCATION_LOCAL: CodeCompletionLocation = 0
The option is local to the location of the code completion query - e.g. a local variable. Subsequent value of location represent options from the outer class, the exact value represent how far they are (in terms of inner classes).

## LOCATION_PARENT_MASK :: const ScriptLanguageExtension.LOCATION_PARENT_MASK: CodeCompletionLocation = 256
The option is from the containing class or a parent class, relative to the location of the code completion query. Perform a bitwise OR with the class depth (e.g. [code]0[/code] for the local class, [code]1[/code] for the parent, [code]2[/code] for the grandparent, etc.) to store the depth of an option in the class or a parent class.

## LOCATION_OTHER_USER_CODE :: const ScriptLanguageExtension.LOCATION_OTHER_USER_CODE: CodeCompletionLocation = 512
The option is from user code which is not local and not in a derived class (e.g. Autoload Singletons).

## LOCATION_OTHER :: const ScriptLanguageExtension.LOCATION_OTHER: CodeCompletionLocation = 1024
The option is from other engine code, not covered by the other enum constants - e.g. built-in classes.

## CODE_COMPLETION_KIND_CLASS :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_CLASS: CodeCompletionKind = 0

## CODE_COMPLETION_KIND_FUNCTION :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_FUNCTION: CodeCompletionKind = 1

## CODE_COMPLETION_KIND_SIGNAL :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_SIGNAL: CodeCompletionKind = 2

## CODE_COMPLETION_KIND_VARIABLE :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_VARIABLE: CodeCompletionKind = 3

## CODE_COMPLETION_KIND_MEMBER :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_MEMBER: CodeCompletionKind = 4

## CODE_COMPLETION_KIND_ENUM :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_ENUM: CodeCompletionKind = 5

## CODE_COMPLETION_KIND_CONSTANT :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_CONSTANT: CodeCompletionKind = 6

## CODE_COMPLETION_KIND_NODE_PATH :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_NODE_PATH: CodeCompletionKind = 7

## CODE_COMPLETION_KIND_FILE_PATH :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_FILE_PATH: CodeCompletionKind = 8

## CODE_COMPLETION_KIND_PLAIN_TEXT :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_PLAIN_TEXT: CodeCompletionKind = 9

## CODE_COMPLETION_KIND_KEYWORD :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_KEYWORD: CodeCompletionKind = 10

## CODE_COMPLETION_KIND_MAX :: const ScriptLanguageExtension.CODE_COMPLETION_KIND_MAX: CodeCompletionKind = 11

## _add_global_constant :: func ScriptLanguageExtension._add_global_constant(name: StringName, value: Variant) -> void

### name :: StringName

### value :: Variant

## _add_named_global_constant :: func ScriptLanguageExtension._add_named_global_constant(name: StringName, value: Variant) -> void

### name :: StringName

### value :: Variant

## _auto_indent_code :: func ScriptLanguageExtension._auto_indent_code(code: String, from_line: int, to_line: int) -> String

### code :: String

### from_line :: int

### to_line :: int

## _can_inherit_from_file :: func ScriptLanguageExtension._can_inherit_from_file() -> bool

## _can_make_function :: func ScriptLanguageExtension._can_make_function() -> bool

## _complete_code :: func ScriptLanguageExtension._complete_code(code: String, path: String, owner: Object) -> Dictionary

### code :: String

### path :: String

### owner :: Object

## _create_script :: func ScriptLanguageExtension._create_script() -> Object

## _debug_get_current_stack_info :: func ScriptLanguageExtension._debug_get_current_stack_info() -> Dictionary[]

## _debug_get_error :: func ScriptLanguageExtension._debug_get_error() -> String

## _debug_get_globals :: func ScriptLanguageExtension._debug_get_globals(max_subitems: int, max_depth: int) -> Dictionary

### max_subitems :: int

### max_depth :: int

## _debug_get_stack_level_count :: func ScriptLanguageExtension._debug_get_stack_level_count() -> int

## _debug_get_stack_level_function :: func ScriptLanguageExtension._debug_get_stack_level_function(level: int) -> String

### level :: int

## _debug_get_stack_level_instance :: func ScriptLanguageExtension._debug_get_stack_level_instance(level: int) -> void*

### level :: int

## _debug_get_stack_level_line :: func ScriptLanguageExtension._debug_get_stack_level_line(level: int) -> int

### level :: int

## _debug_get_stack_level_locals :: func ScriptLanguageExtension._debug_get_stack_level_locals(level: int, max_subitems: int, max_depth: int) -> Dictionary

### level :: int

### max_subitems :: int

### max_depth :: int

## _debug_get_stack_level_members :: func ScriptLanguageExtension._debug_get_stack_level_members(level: int, max_subitems: int, max_depth: int) -> Dictionary

### level :: int

### max_subitems :: int

### max_depth :: int

## _debug_get_stack_level_source :: func ScriptLanguageExtension._debug_get_stack_level_source(level: int) -> String
Returns the source associated with a given debug stack position.

### level :: int

## _debug_parse_stack_level_expression :: func ScriptLanguageExtension._debug_parse_stack_level_expression(level: int, expression: String, max_subitems: int, max_depth: int) -> String

### level :: int

### expression :: String

### max_subitems :: int

### max_depth :: int

## _find_function :: func ScriptLanguageExtension._find_function(function: String, code: String) -> int
Returns the line where the function is defined in the code, or [code]-1[/code] if the function is not present.

### function :: String

### code :: String

## _finish :: func ScriptLanguageExtension._finish() -> void

## _frame :: func ScriptLanguageExtension._frame() -> void

## _get_built_in_templates :: func ScriptLanguageExtension._get_built_in_templates(object: StringName) -> Dictionary[]

### object :: StringName

## _get_comment_delimiters :: func ScriptLanguageExtension._get_comment_delimiters() -> PackedStringArray

## _get_doc_comment_delimiters :: func ScriptLanguageExtension._get_doc_comment_delimiters() -> PackedStringArray

## _get_extension :: func ScriptLanguageExtension._get_extension() -> String

## _get_global_class_name :: func ScriptLanguageExtension._get_global_class_name(path: String) -> Dictionary

### path :: String

## _get_name :: func ScriptLanguageExtension._get_name() -> String

## _get_public_annotations :: func ScriptLanguageExtension._get_public_annotations() -> Dictionary[]

## _get_public_constants :: func ScriptLanguageExtension._get_public_constants() -> Dictionary

## _get_public_functions :: func ScriptLanguageExtension._get_public_functions() -> Dictionary[]

## _get_recognized_extensions :: func ScriptLanguageExtension._get_recognized_extensions() -> PackedStringArray

## _get_reserved_words :: func ScriptLanguageExtension._get_reserved_words() -> PackedStringArray

## _get_string_delimiters :: func ScriptLanguageExtension._get_string_delimiters() -> PackedStringArray

## _get_type :: func ScriptLanguageExtension._get_type() -> String

## _handles_global_class_type :: func ScriptLanguageExtension._handles_global_class_type(type: String) -> bool

### type :: String

## _has_named_classes :: func ScriptLanguageExtension._has_named_classes() -> bool

## _init :: func ScriptLanguageExtension._init() -> void

## _is_control_flow_keyword :: func ScriptLanguageExtension._is_control_flow_keyword(keyword: String) -> bool

### keyword :: String

## _is_using_templates :: func ScriptLanguageExtension._is_using_templates() -> bool

## _lookup_code :: func ScriptLanguageExtension._lookup_code(code: String, symbol: String, path: String, owner: Object) -> Dictionary

### code :: String

### symbol :: String

### path :: String

### owner :: Object

## _make_function :: func ScriptLanguageExtension._make_function(class_name: String, function_name: String, function_args: PackedStringArray) -> String

### class_name :: String

### function_name :: String

### function_args :: PackedStringArray

## _make_template :: func ScriptLanguageExtension._make_template(template: String, class_name: String, base_class_name: String) -> Script

### template :: String

### class_name :: String

### base_class_name :: String

## _open_in_external_editor :: func ScriptLanguageExtension._open_in_external_editor(script: Script, line: int, column: int) -> int

### script :: Script

### line :: int

### column :: int

## _overrides_external_editor :: func ScriptLanguageExtension._overrides_external_editor() -> bool

## _preferred_file_name_casing :: func ScriptLanguageExtension._preferred_file_name_casing() -> int

## _profiling_get_accumulated_data :: func ScriptLanguageExtension._profiling_get_accumulated_data(info_array: ScriptLanguageExtensionProfilingInfo*, info_max: int) -> int

### info_array :: ScriptLanguageExtensionProfilingInfo*

### info_max :: int

## _profiling_get_frame_data :: func ScriptLanguageExtension._profiling_get_frame_data(info_array: ScriptLanguageExtensionProfilingInfo*, info_max: int) -> int

### info_array :: ScriptLanguageExtensionProfilingInfo*

### info_max :: int

## _profiling_set_save_native_calls :: func ScriptLanguageExtension._profiling_set_save_native_calls(enable: bool) -> void

### enable :: bool

## _profiling_start :: func ScriptLanguageExtension._profiling_start() -> void

## _profiling_stop :: func ScriptLanguageExtension._profiling_stop() -> void

## _reload_all_scripts :: func ScriptLanguageExtension._reload_all_scripts() -> void

## _reload_scripts :: func ScriptLanguageExtension._reload_scripts(scripts: Array, soft_reload: bool) -> void
Reloads all [param scripts] from disk and the specifics of how that happens is [ScriptLanguageExtension] specific.

### scripts :: Array

### soft_reload :: bool

## _reload_tool_script :: func ScriptLanguageExtension._reload_tool_script(script: Script, soft_reload: bool) -> void
Reloads the given [param script] from disk and the specifics of how that happens is [ScriptLanguageExtension] specific.

### script :: Script

### soft_reload :: bool

## _remove_named_global_constant :: func ScriptLanguageExtension._remove_named_global_constant(name: StringName) -> void

### name :: StringName

## _supports_builtin_mode :: func ScriptLanguageExtension._supports_builtin_mode() -> bool

## _supports_documentation :: func ScriptLanguageExtension._supports_documentation() -> bool

## _thread_enter :: func ScriptLanguageExtension._thread_enter() -> void

## _thread_exit :: func ScriptLanguageExtension._thread_exit() -> void

## _validate :: func ScriptLanguageExtension._validate(script: String, path: String, validate_functions: bool, validate_errors: bool, validate_warnings: bool, validate_safe_lines: bool) -> Dictionary

### script :: String

### path :: String

### validate_functions :: bool

### validate_errors :: bool

### validate_warnings :: bool

### validate_safe_lines :: bool

## _validate_path :: func ScriptLanguageExtension._validate_path(path: String) -> String

### path :: String
