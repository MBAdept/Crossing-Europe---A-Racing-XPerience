# ColorPickerButton :: <Native> class ColorPickerButton extends Button
A button that brings up a [ColorPicker] when pressed.
Encapsulates a [ColorPicker], making it accessible by pressing a button. Pressing the button will toggle the [ColorPicker]'s visibility.
See also [BaseButton] which contains common properties and methods associated with this node.
[b]Note:[/b] By default, the button may not be wide enough for the color preview swatch to be visible. Make sure to set [member Control.custom_minimum_size] to a big enough value to give the button enough space.

## color :: var ColorPickerButton.color: Color
The currently selected color.

## edit_alpha :: var ColorPickerButton.edit_alpha: bool
If [code]true[/code], the alpha channel in the displayed [ColorPicker] will be visible.

## edit_intensity :: var ColorPickerButton.edit_intensity: bool
If [code]true[/code], the intensity slider in the displayed [ColorPicker] will be visible.

## toggle_mode :: var ColorPickerButton.toggle_mode: bool

## bg :: <Theme> var ColorPickerButton.bg: Texture2D
The background of the color preview rect on the button.

## get_picker :: func ColorPickerButton.get_picker() -> ColorPicker
Returns the [ColorPicker] that this node toggles.
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member CanvasItem.visible] property.

## get_popup :: func ColorPickerButton.get_popup() -> PopupPanel
Returns the control's [PopupPanel] which allows you to connect to popup signals. This allows you to handle events when the ColorPicker is shown or hidden.
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member Window.visible] property.

## color_changed :: func ColorPickerButton.color_changed(color: Color) -> void
Emitted when the color changes.

### color :: Color

## picker_created :: func ColorPickerButton.picker_created() -> void
Emitted when the [ColorPicker] is created (the button is pressed for the first time).

## popup_closed :: func ColorPickerButton.popup_closed() -> void
Emitted when the [ColorPicker] is closed.
