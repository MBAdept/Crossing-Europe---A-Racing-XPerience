# SpriteFrames :: <Native> class SpriteFrames extends Resource
Sprite frame library for AnimatedSprite2D and AnimatedSprite3D.
Sprite frame library for an [AnimatedSprite2D] or [AnimatedSprite3D] node. Contains frames and animation data for playback.

## LOOP_NONE :: const SpriteFrames.LOOP_NONE: LoopMode = 0
The animation plays once and stops when it reaches the end, or the start if played in reverse.

## LOOP_LINEAR :: const SpriteFrames.LOOP_LINEAR: LoopMode = 1
The animation restarts from the beginning when it reaches the end, or from the end if played in reverse, repeating continuously.

## LOOP_PINGPONG :: const SpriteFrames.LOOP_PINGPONG: LoopMode = 2
The animation alternates direction each time it reaches the end or start, playing forward and then in reverse repeatedly.
[b]Note:[/b] Both [AnimatedSprite2D] and [AnimatedSprite3D] play the first/last frame for its duration only once at each end of the animation loop (instead of twice, once per forward/backward animation direction).

## add_animation :: func SpriteFrames.add_animation(anim: StringName) -> void
Adds a new [param anim] animation to the library.

### anim :: StringName

## add_frame :: func SpriteFrames.add_frame(anim: StringName, texture: Texture2D, duration: float = 1.0, at_position: int = -1) -> void
Adds a frame to the [param anim] animation. If [param at_position] is [code]-1[/code], the frame will be added to the end of the animation. [param duration] specifies the relative duration, see [method get_frame_duration] for details.

### anim :: StringName

### texture :: Texture2D

### duration :: float

### at_position :: int

## clear :: func SpriteFrames.clear(anim: StringName) -> void
Removes all frames from the [param anim] animation.

### anim :: StringName

## clear_all :: func SpriteFrames.clear_all() -> void
Removes all animations. An empty [code]default[/code] animation will be created.

## duplicate_animation :: func SpriteFrames.duplicate_animation(anim_from: StringName, anim_to: StringName) -> void
Duplicates the animation [param anim_from] to a new animation named [param anim_to]. Fails if [param anim_to] already exists, or if [param anim_from] does not exist.

### anim_from :: StringName

### anim_to :: StringName

## get_animation_loop :: func SpriteFrames.get_animation_loop(anim: StringName) -> bool
Returns [code]true[/code] if [code]get_animation_loop_mode(anim) == LOOP_LINEAR[/code]. Otherwise, returns [code]false[/code].

### anim :: StringName

## get_animation_loop_mode :: func SpriteFrames.get_animation_loop_mode(anim: StringName) -> int
Returns the loop mode for the [param anim] animation.

### anim :: StringName

## get_animation_names :: func SpriteFrames.get_animation_names() -> PackedStringArray
Returns an array containing the names associated to each animation. Values are placed in alphabetical order.

## get_animation_speed :: func SpriteFrames.get_animation_speed(anim: StringName) -> float
Returns the speed in frames per second for the [param anim] animation.

### anim :: StringName

## get_frame_count :: func SpriteFrames.get_frame_count(anim: StringName) -> int
Returns the number of frames for the [param anim] animation.

### anim :: StringName

## get_frame_duration :: func SpriteFrames.get_frame_duration(anim: StringName, idx: int) -> float
Returns a relative duration of the frame [param idx] in the [param anim] animation (defaults to [code]1.0[/code]). For example, a frame with a duration of [code]2.0[/code] is displayed twice as long as a frame with a duration of [code]1.0[/code]. You can calculate the absolute duration (in seconds) of a frame using the following formula:
[codeblock]
absolute_duration = relative_duration / (animation_fps * abs(playing_speed))
[/codeblock]
In this example, [code]playing_speed[/code] refers to either [method AnimatedSprite2D.get_playing_speed] or [method AnimatedSprite3D.get_playing_speed].

### anim :: StringName

### idx :: int

## get_frame_texture :: func SpriteFrames.get_frame_texture(anim: StringName, idx: int) -> Texture2D
Returns the texture of the frame [param idx] in the [param anim] animation.

### anim :: StringName

### idx :: int

## has_animation :: func SpriteFrames.has_animation(anim: StringName) -> bool
Returns [code]true[/code] if the [param anim] animation exists.

### anim :: StringName

## remove_animation :: func SpriteFrames.remove_animation(anim: StringName) -> void
Removes the [param anim] animation.

### anim :: StringName

## remove_frame :: func SpriteFrames.remove_frame(anim: StringName, idx: int) -> void
Removes the [param anim] animation's frame [param idx].

### anim :: StringName

### idx :: int

## rename_animation :: func SpriteFrames.rename_animation(anim: StringName, newname: StringName) -> void
Changes the [param anim] animation's name to [param newname].

### anim :: StringName

### newname :: StringName

## set_animation_loop :: func SpriteFrames.set_animation_loop(anim: StringName, loop: bool) -> void
If [param loop] is [code]false[/code] equivalent to [code]set_animation_loop_mode(LOOP_NONE)[/code].
If [param loop] is [code]true[/code] equivalent to [code]set_animation_loop_mode(LOOP_LINEAR)[/code].

### anim :: StringName

### loop :: bool

## set_animation_loop_mode :: func SpriteFrames.set_animation_loop_mode(anim: StringName, loop_mode: int) -> void
Sets the [param loop_mode] for the [param anim] animation.

### anim :: StringName

### loop_mode :: int

## set_animation_speed :: func SpriteFrames.set_animation_speed(anim: StringName, fps: float) -> void
Sets the speed for the [param anim] animation in frames per second.

### anim :: StringName

### fps :: float

## set_frame :: func SpriteFrames.set_frame(anim: StringName, idx: int, texture: Texture2D, duration: float = 1.0) -> void
Sets the [param texture] and the [param duration] of the frame [param idx] in the [param anim] animation. [param duration] specifies the relative duration, see [method get_frame_duration] for details.

### anim :: StringName

### idx :: int

### texture :: Texture2D

### duration :: float
