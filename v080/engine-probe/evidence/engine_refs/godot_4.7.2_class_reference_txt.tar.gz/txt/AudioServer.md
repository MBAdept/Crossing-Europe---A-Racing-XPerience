# AudioServer :: <Native> class AudioServer extends Object
Server interface for low-level audio access.
[AudioServer] is a low-level server interface for audio access. It is in charge of creating sample data (playable audio) as well as its playback via a voice interface.

## SPEAKER_MODE_STEREO :: const AudioServer.SPEAKER_MODE_STEREO: SpeakerMode = 0
Two or fewer speakers were detected.

## SPEAKER_SURROUND_31 :: const AudioServer.SPEAKER_SURROUND_31: SpeakerMode = 1
A 3.1 channel surround setup was detected.

## SPEAKER_SURROUND_51 :: const AudioServer.SPEAKER_SURROUND_51: SpeakerMode = 2
A 5.1 channel surround setup was detected.

## SPEAKER_SURROUND_71 :: const AudioServer.SPEAKER_SURROUND_71: SpeakerMode = 3
A 7.1 channel surround setup was detected.

## PLAYBACK_TYPE_DEFAULT :: const AudioServer.PLAYBACK_TYPE_DEFAULT: PlaybackType = 0
The playback will be considered of the type declared at [member ProjectSettings.audio/general/default_playback_type].

## PLAYBACK_TYPE_STREAM :: const AudioServer.PLAYBACK_TYPE_STREAM: PlaybackType = 1
Force the playback to be considered as a stream.

## PLAYBACK_TYPE_SAMPLE :: const AudioServer.PLAYBACK_TYPE_SAMPLE: PlaybackType = 2
Force the playback to be considered as a sample. This can provide lower latency and more stable playback (with less risk of audio crackling), at the cost of having less flexibility.
[b]Note:[/b] Only currently supported on the web platform.
[b]Note:[/b] [AudioEffect]s are not supported when playback is considered as a sample.

## PLAYBACK_TYPE_MAX :: const AudioServer.PLAYBACK_TYPE_MAX: PlaybackType = 3
Represents the size of the [enum PlaybackType] enum.

## bus_count :: var AudioServer.bus_count: int
Number of available audio buses.

## input_device :: var AudioServer.input_device: String
Name of the current device for audio input (see [method get_input_device_list]). On systems with multiple audio inputs (such as analog, USB and HDMI audio), this can be used to select the audio input device. The value [code]"Default"[/code] will record audio on the system-wide default audio input. If an invalid device name is set, the value will be reverted back to [code]"Default"[/code].
[b]Note:[/b] [member ProjectSettings.audio/driver/enable_input] must be [code]true[/code] for audio input to work. See also that setting's description for caveats related to permissions and operating system privacy settings.

## output_device :: var AudioServer.output_device: String
Name of the current device for audio output (see [method get_output_device_list]). On systems with multiple audio outputs (such as analog, USB and HDMI audio), this can be used to select the audio output device. The value [code]"Default"[/code] will play audio on the system-wide default audio output. If an invalid device name is set, the value will be reverted back to [code]"Default"[/code].

## playback_speed_scale :: var AudioServer.playback_speed_scale: float
Scales the rate at which audio is played (i.e. setting it to [code]0.5[/code] will make the audio be played at half its speed). See also [member Engine.time_scale] to affect the general simulation speed, which is independent from [member AudioServer.playback_speed_scale].

## add_bus :: func AudioServer.add_bus(at_position: int = -1) -> void
Adds a bus at [param at_position].

### at_position :: int

## add_bus_effect :: func AudioServer.add_bus_effect(bus_idx: int, effect: AudioEffect, at_position: int = -1) -> void
Adds an [AudioEffect] effect to the bus [param bus_idx] at [param at_position].

### bus_idx :: int

### effect :: AudioEffect

### at_position :: int

## generate_bus_layout :: func AudioServer.generate_bus_layout() -> AudioBusLayout
Generates an [AudioBusLayout] using the available buses and effects.

## get_bus_channels :: func AudioServer.get_bus_channels(bus_idx: int) -> int
Returns the number of channels of the bus at index [param bus_idx].

### bus_idx :: int

## get_bus_effect :: func AudioServer.get_bus_effect(bus_idx: int, effect_idx: int) -> AudioEffect
Returns the [AudioEffect] at position [param effect_idx] in bus [param bus_idx].

### bus_idx :: int

### effect_idx :: int

## get_bus_effect_count :: func AudioServer.get_bus_effect_count(bus_idx: int) -> int
Returns the number of effects on the bus at [param bus_idx].

### bus_idx :: int

## get_bus_effect_instance :: func AudioServer.get_bus_effect_instance(bus_idx: int, effect_idx: int, channel: int = 0) -> AudioEffectInstance
Returns the [AudioEffectInstance] assigned to the given bus and effect indices (and optionally channel).

### bus_idx :: int

### effect_idx :: int

### channel :: int

## get_bus_index :: func AudioServer.get_bus_index(bus_name: StringName) -> int
Returns the index of the bus with the name [param bus_name]. Returns [code]-1[/code] if no bus with the specified name exist.

### bus_name :: StringName

## get_bus_name :: func AudioServer.get_bus_name(bus_idx: int) -> String
Returns the name of the bus with the index [param bus_idx].

### bus_idx :: int

## get_bus_peak_volume_left_db :: func AudioServer.get_bus_peak_volume_left_db(bus_idx: int, channel: int) -> float
Returns the peak volume of the left speaker at bus index [param bus_idx] and channel index [param channel].

### bus_idx :: int

### channel :: int

## get_bus_peak_volume_right_db :: func AudioServer.get_bus_peak_volume_right_db(bus_idx: int, channel: int) -> float
Returns the peak volume of the right speaker at bus index [param bus_idx] and channel index [param channel].

### bus_idx :: int

### channel :: int

## get_bus_send :: func AudioServer.get_bus_send(bus_idx: int) -> StringName
Returns the name of the bus that the bus at index [param bus_idx] sends to.

### bus_idx :: int

## get_bus_volume_db :: func AudioServer.get_bus_volume_db(bus_idx: int) -> float
Returns the volume of the bus at index [param bus_idx] in dB.

### bus_idx :: int

## get_bus_volume_linear :: func AudioServer.get_bus_volume_linear(bus_idx: int) -> float
Returns the volume of the bus at index [param bus_idx] as a linear value.
[b]Note:[/b] The returned value is equivalent to the result of [method @GlobalScope.db_to_linear] on the result of [method get_bus_volume_db].

### bus_idx :: int

## get_driver_name :: func AudioServer.get_driver_name() -> String
Returns the name of the current audio driver. The default usually depends on the operating system, but may be overridden via the [code]--audio-driver[/code] [url=https://docs.godotengine.org/en/4.7/tutorials/editor/command_line_tutorial.html]command line argument[/url]. [code]--headless[/code] also automatically sets the audio driver to [code]Dummy[/code]. See also [member ProjectSettings.audio/driver/driver].

## get_input_buffer_length_frames :: func AudioServer.get_input_buffer_length_frames() -> int
Returns the absolute size of the microphone input buffer. This is set to a multiple of the audio latency and can be used to estimate the minimum rate at which the frames need to be fetched.

## get_input_device_list :: func AudioServer.get_input_device_list() -> PackedStringArray
Returns the names of all audio input devices detected on the system.
[b]Note:[/b] [member ProjectSettings.audio/driver/enable_input] must be [code]true[/code] for audio input to work. See also that setting's description for caveats related to permissions and operating system privacy settings.

## get_input_frames :: func AudioServer.get_input_frames(frames: int) -> PackedVector2Array
Returns a [PackedVector2Array] containing exactly [param frames] audio samples from the internal microphone buffer if available, otherwise returns an empty [PackedVector2Array].
The buffer is filled at the rate of [method get_input_mix_rate] frames per second when [method set_input_device_active] has successfully been set to [code]true[/code].
The samples are signed floating-point PCM values between [code]-1[/code] and [code]1[/code].

### frames :: int

## get_input_frames_available :: func AudioServer.get_input_frames_available() -> int
Returns the number of frames available to read using [method get_input_frames].

## get_input_mix_rate :: func AudioServer.get_input_mix_rate() -> float
Returns the sample rate at the input of the [AudioServer].

## get_mix_rate :: func AudioServer.get_mix_rate() -> float
Returns the sample rate at the output of the [AudioServer].

## get_output_device_list :: func AudioServer.get_output_device_list() -> PackedStringArray
Returns the names of all audio output devices detected on the system.

## get_output_latency :: func AudioServer.get_output_latency() -> float
Returns the audio driver's effective output latency. This is based on [member ProjectSettings.audio/driver/output_latency], but the exact returned value will differ depending on the operating system and audio driver.
[b]Note:[/b] This can be expensive; it is not recommended to call [method get_output_latency] every frame.

## get_speaker_mode :: func AudioServer.get_speaker_mode() -> int
Returns the speaker configuration.

## get_time_since_last_mix :: func AudioServer.get_time_since_last_mix() -> float
Returns the relative time since the last mix occurred, in seconds.

## get_time_to_next_mix :: func AudioServer.get_time_to_next_mix() -> float
Returns the relative time until the next mix occurs, in seconds.

## is_bus_bypassing_effects :: func AudioServer.is_bus_bypassing_effects(bus_idx: int) -> bool
If [code]true[/code], the bus at index [param bus_idx] is bypassing effects.

### bus_idx :: int

## is_bus_effect_enabled :: func AudioServer.is_bus_effect_enabled(bus_idx: int, effect_idx: int) -> bool
If [code]true[/code], the effect at index [param effect_idx] on the bus at index [param bus_idx] is enabled.

### bus_idx :: int

### effect_idx :: int

## is_bus_mute :: func AudioServer.is_bus_mute(bus_idx: int) -> bool
If [code]true[/code], the bus at index [param bus_idx] is muted.

### bus_idx :: int

## is_bus_solo :: func AudioServer.is_bus_solo(bus_idx: int) -> bool
If [code]true[/code], the bus at index [param bus_idx] is in solo mode.

### bus_idx :: int

## is_stream_registered_as_sample :: func AudioServer.is_stream_registered_as_sample(stream: AudioStream) -> bool
If [code]true[/code], the stream is registered as a sample. The engine will not have to register it before playing the sample.
If [code]false[/code], the stream will have to be registered before playing it. To prevent lag spikes, register the stream as sample with [method register_stream_as_sample].

### stream :: AudioStream

## lock :: func AudioServer.lock() -> void
Locks the audio driver's main loop.
[b]Note:[/b] Remember to unlock it afterwards.

## move_bus :: func AudioServer.move_bus(index: int, to_index: int) -> void
Moves the bus from index [param index] to index [param to_index].

### index :: int

### to_index :: int

## register_stream_as_sample :: func AudioServer.register_stream_as_sample(stream: AudioStream) -> void
Forces the registration of a stream as a sample.
[b]Note:[/b] Lag spikes may occur when calling this method, especially on single-threaded builds. It is suggested to call this method while loading assets, where the lag spike could be masked, instead of registering the sample right before it needs to be played.

### stream :: AudioStream

## remove_bus :: func AudioServer.remove_bus(index: int) -> void
Removes the bus at index [param index].

### index :: int

## remove_bus_effect :: func AudioServer.remove_bus_effect(bus_idx: int, effect_idx: int) -> void
Removes the effect at index [param effect_idx] from the bus at index [param bus_idx].

### bus_idx :: int

### effect_idx :: int

## set_bus_bypass_effects :: func AudioServer.set_bus_bypass_effects(bus_idx: int, enable: bool) -> void
If [code]true[/code], the bus at index [param bus_idx] is bypassing effects.

### bus_idx :: int

### enable :: bool

## set_bus_effect_enabled :: func AudioServer.set_bus_effect_enabled(bus_idx: int, effect_idx: int, enabled: bool) -> void
If [code]true[/code], the effect at index [param effect_idx] on the bus at index [param bus_idx] is enabled.

### bus_idx :: int

### effect_idx :: int

### enabled :: bool

## set_bus_layout :: func AudioServer.set_bus_layout(bus_layout: AudioBusLayout) -> void
Overwrites the currently used [AudioBusLayout].

### bus_layout :: AudioBusLayout

## set_bus_mute :: func AudioServer.set_bus_mute(bus_idx: int, enable: bool) -> void
If [code]true[/code], the bus at index [param bus_idx] is muted.

### bus_idx :: int

### enable :: bool

## set_bus_name :: func AudioServer.set_bus_name(bus_idx: int, name: String) -> void
Sets the name of the bus at index [param bus_idx] to [param name].

### bus_idx :: int

### name :: String

## set_bus_send :: func AudioServer.set_bus_send(bus_idx: int, send: StringName) -> void
Connects the output of the bus at [param bus_idx] to the bus named [param send].

### bus_idx :: int

### send :: StringName

## set_bus_solo :: func AudioServer.set_bus_solo(bus_idx: int, enable: bool) -> void
If [code]true[/code], the bus at index [param bus_idx] is in solo mode.

### bus_idx :: int

### enable :: bool

## set_bus_volume_db :: func AudioServer.set_bus_volume_db(bus_idx: int, volume_db: float) -> void
Sets the volume in decibels of the bus at index [param bus_idx] to [param volume_db].

### bus_idx :: int

### volume_db :: float

## set_bus_volume_linear :: func AudioServer.set_bus_volume_linear(bus_idx: int, volume_linear: float) -> void
Sets the volume as a linear value of the bus at index [param bus_idx] to [param volume_linear].
[b]Note:[/b] Using this method is equivalent to calling [method set_bus_volume_db] with the result of [method @GlobalScope.linear_to_db] on a value.

### bus_idx :: int

### volume_linear :: float

## set_enable_tagging_used_audio_streams :: func AudioServer.set_enable_tagging_used_audio_streams(enable: bool) -> void
If set to [code]true[/code], all instances of [AudioStreamPlayback] will call [method AudioStreamPlayback._tag_used_streams] every mix step.
[b]Note:[/b] This is enabled by default in the editor, as it is used by editor plugins for the audio stream previews.

### enable :: bool

## set_input_device_active :: func AudioServer.set_input_device_active(active: bool) -> int
If [param active] is [code]true[/code], starts the microphone input stream specified by [member input_device] or returns an error if it failed.
If [param active] is [code]false[/code], stops the input stream if it is running.

### active :: bool

## swap_bus_effects :: func AudioServer.swap_bus_effects(bus_idx: int, effect_idx: int, by_effect_idx: int) -> void
Swaps the position of two effects in bus [param bus_idx].

### bus_idx :: int

### effect_idx :: int

### by_effect_idx :: int

## unlock :: func AudioServer.unlock() -> void
Unlocks the audio driver's main loop. (After locking it, you should always unlock it.)

## bus_layout_changed :: func AudioServer.bus_layout_changed() -> void
Emitted when an audio bus is added, deleted, or moved.

## bus_renamed :: func AudioServer.bus_renamed(bus_index: int, old_name: StringName, new_name: StringName) -> void
Emitted when the audio bus at [param bus_index] is renamed from [param old_name] to [param new_name].

### bus_index :: int

### old_name :: StringName

### new_name :: StringName
