# OpenXRSpatialComponentMesh3DList :: <Native> class OpenXRSpatialComponentMesh3DList extends OpenXRSpatialComponentData
Object for storing the queries mesh3d result data.
Object for storing the queries 3d mesh result data when calling [method OpenXRSpatialEntityExtension.query_snapshot].

## get_mesh :: func OpenXRSpatialComponentMesh3DList.get_mesh(index: int) -> Mesh
Returns the mesh for the entity at this [param index].

### index :: int

## get_transform :: func OpenXRSpatialComponentMesh3DList.get_transform(index: int) -> Transform3D
Returns the transform for positioning our mesh for the entity at this [param index].

### index :: int
