# GPUParticlesCollisionSphere3D :: <Native> class GPUParticlesCollisionSphere3D extends GPUParticlesCollision3D
A sphere-shaped 3D particle collision shape affecting [GPUParticles3D] nodes.
A sphere-shaped 3D particle collision shape affecting [GPUParticles3D] nodes.
Particle collision shapes work in real-time and can be moved, rotated and scaled during gameplay. Unlike attractors, non-uniform scaling of collision shapes is [i]not[/i] supported.
[b]Note:[/b] [member ParticleProcessMaterial.collision_mode] must be [constant ParticleProcessMaterial.COLLISION_RIGID] or [constant ParticleProcessMaterial.COLLISION_HIDE_ON_CONTACT] on the [GPUParticles3D]'s process material for collision to work.
[b]Note:[/b] Particle collision only affects [GPUParticles3D], not [CPUParticles3D].

## radius :: var GPUParticlesCollisionSphere3D.radius: float
The collision sphere's radius in 3D units.
