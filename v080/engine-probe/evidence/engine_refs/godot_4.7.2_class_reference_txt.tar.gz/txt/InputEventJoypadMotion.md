# InputEventJoypadMotion :: <Native> class InputEventJoypadMotion extends InputEvent
Represents axis motions (such as joystick or analog triggers) from a gamepad.
Stores information about joystick motions. One [InputEventJoypadMotion] represents one axis at a time. For gamepad buttons, see [InputEventJoypadButton].

## axis :: var InputEventJoypadMotion.axis: JoyAxis
Axis identifier.

## axis_value :: var InputEventJoypadMotion.axis_value: float
Current position of the joystick on the given axis. The value ranges from [code]-1.0[/code] to [code]1.0[/code]. A value of [code]0[/code] means the axis is in its resting position.
