# ParallaxBackground :: <Native> class ParallaxBackground extends CanvasLayer
A node used to create a parallax scrolling background.
A ParallaxBackground uses one or more [ParallaxLayer] child nodes to create a parallax effect. Each [ParallaxLayer] can move at a different speed using [member ParallaxLayer.motion_offset]. This creates an illusion of depth in a 2D game. If not used with a [Camera2D], you must manually calculate the [member scroll_offset].
[b]Note:[/b] Each [ParallaxBackground] is drawn on one specific [Viewport] and cannot be shared between multiple [Viewport]s, see [member CanvasLayer.custom_viewport]. When using multiple [Viewport]s, for example in a split-screen game, you need create an individual [ParallaxBackground] for each [Viewport] you want it to be drawn on.

## layer :: var ParallaxBackground.layer: int

## scroll_base_offset :: var ParallaxBackground.scroll_base_offset: Vector2
The base position offset for all [ParallaxLayer] children.

## scroll_base_scale :: var ParallaxBackground.scroll_base_scale: Vector2
The base motion scale for all [ParallaxLayer] children.

## scroll_ignore_camera_zoom :: var ParallaxBackground.scroll_ignore_camera_zoom: bool
If [code]true[/code], elements in [ParallaxLayer] child aren't affected by the zoom level of the camera.

## scroll_limit_begin :: var ParallaxBackground.scroll_limit_begin: Vector2
Top-left limits for scrolling to begin. If the camera is outside of this limit, the background will stop scrolling. Must be lower than [member scroll_limit_end] to work.

## scroll_limit_end :: var ParallaxBackground.scroll_limit_end: Vector2
Bottom-right limits for scrolling to end. If the camera is outside of this limit, the background will stop scrolling. Must be higher than [member scroll_limit_begin] to work.

## scroll_offset :: var ParallaxBackground.scroll_offset: Vector2
The ParallaxBackground's scroll value. Calculated automatically when using a [Camera2D], but can be used to manually manage scrolling when no camera is present.
