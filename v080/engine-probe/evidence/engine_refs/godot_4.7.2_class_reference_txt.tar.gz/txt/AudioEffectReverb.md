# AudioEffectReverb :: <Native> class AudioEffectReverb extends AudioEffect
Adds a reverberation audio effect to an audio bus.
Emulates an echo by playing a blurred version of the input audio.
A "reverb" effect plays the input audio back continuously, decaying over a period of time. It simulates sounds in different kinds of spaces, ranging from small rooms, to big caverns.
See also [AudioEffectDelay] for a non-blurry type of echo.

## damping :: var AudioEffectReverb.damping: float
Defines how reflective the imaginary room's walls are. The more reflective, the more high frequency content the reverb has. Value can range from 0 to 1.

## dry :: var AudioEffectReverb.dry: float
The volume ratio of the original audio. At 0, only the modified audio is outputted. Value can range from 0 to 1.

## hipass :: var AudioEffectReverb.hipass: float
High-pass filter allows frequencies higher than a certain cutoff threshold and attenuates frequencies lower than the cutoff threshold. Value can range from 0 to 1.

## predelay_feedback :: var AudioEffectReverb.predelay_feedback: float
Gain of early reflection copies. At higher values, early reflection copies are louder and ring out for longer. Value can range from 0 to 1.

## predelay_msec :: var AudioEffectReverb.predelay_msec: float
Time between the original audio and the early reflections of the reverb signal, in milliseconds. Value can range from 20 to 500.

## room_size :: var AudioEffectReverb.room_size: float
Dimensions of simulated room. Bigger means more echoes. Value can range from 0 to 1.

## spread :: var AudioEffectReverb.spread: float
Widens or narrows the stereo image of the reverb tail. At 1, it fully widens. Value can range from 0 to 1.

## wet :: var AudioEffectReverb.wet: float
The volume ratio of the modified audio. At 0, only the original audio is outputted. Value can range from 0 to 1.
