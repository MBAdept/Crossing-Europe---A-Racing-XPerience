# RDHitGroup :: <Native> class RDHitGroup extends RefCounted
Hit group (used by [RenderingDevice]).
Defines a hit group for use with [method RenderingDevice.raytracing_pipeline_create].
A hit group combines shaders that are executed when a ray intersects geometry. It may include a closest-hit shader, any-hit shader, and intersection shader.
Hit groups are referenced by index when populating hit shader binding tables using [method RenderingDevice.hit_sbt_range_update].

## any_hit_shader :: var RDHitGroup.any_hit_shader: RDPipelineShader
Any-hit shader for this hit group. Executed for each potential intersection. Can be [code]null[/code].

## closest_hit_shader :: var RDHitGroup.closest_hit_shader: RDPipelineShader
Closest-hit shader for this hit group. Executed for the closest intersection. Can be [code]null[/code].

## intersection_shader :: var RDHitGroup.intersection_shader: RDPipelineShader
Intersection shader for this hit group. Required for non-triangle geometry. Must be [code]null[/code] when using for triangle geometry.
