# Node3DGizmo :: <Native> class Node3DGizmo extends RefCounted
Abstract class to expose editor gizmos for [Node3D].
This abstract class helps connect the [Node3D] scene with the editor-specific [EditorNode3DGizmo] class.
[Node3DGizmo] by itself has no exposed API, refer to [method Node3D.add_gizmo] and pass it an [EditorNode3DGizmo] instance.
