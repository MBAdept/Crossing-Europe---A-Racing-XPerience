# OpenXRSpatialComponentAnchorList :: <Native> class OpenXRSpatialComponentAnchorList extends OpenXRSpatialComponentData
Object for storing the queries anchor result data.
Object for storing the queries anchor result data when calling [method OpenXRSpatialEntityExtension.query_snapshot].

## get_entity_pose :: func OpenXRSpatialComponentAnchorList.get_entity_pose(index: int) -> Transform3D
Returns the transform for the entity at this [param index].

### index :: int
