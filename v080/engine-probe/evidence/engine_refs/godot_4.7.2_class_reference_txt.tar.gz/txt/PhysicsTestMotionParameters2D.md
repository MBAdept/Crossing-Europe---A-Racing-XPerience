# PhysicsTestMotionParameters2D :: <Native> class PhysicsTestMotionParameters2D extends RefCounted
Provides parameters for [method PhysicsServer2D.body_test_motion].
By changing various properties of this object, such as the motion, you can configure the parameters for [method PhysicsServer2D.body_test_motion].

## collide_separation_ray :: var PhysicsTestMotionParameters2D.collide_separation_ray: bool
If set to [code]true[/code], shapes of type [constant PhysicsServer2D.SHAPE_SEPARATION_RAY] are used to detect collisions and can stop the motion. Can be useful when snapping to the ground.
If set to [code]false[/code], shapes of type [constant PhysicsServer2D.SHAPE_SEPARATION_RAY] are only used for separation when overlapping with other bodies. That's the main use for separation ray shapes.

## exclude_bodies :: var PhysicsTestMotionParameters2D.exclude_bodies: RID[]
Optional array of body [RID] to exclude from collision. Use [method CollisionObject2D.get_rid] to get the [RID] associated with a [CollisionObject2D]-derived node.

## exclude_objects :: var PhysicsTestMotionParameters2D.exclude_objects: int[]
Optional array of object unique instance ID to exclude from collision. See [method Object.get_instance_id].

## from :: var PhysicsTestMotionParameters2D.from: Transform2D
Transform in global space where the motion should start. Usually set to [member Node2D.global_transform] for the current body's transform.

## margin :: var PhysicsTestMotionParameters2D.margin: float
Increases the size of the shapes involved in the collision detection.

## motion :: var PhysicsTestMotionParameters2D.motion: Vector2
Motion vector to define the length and direction of the motion to test.

## recovery_as_collision :: var PhysicsTestMotionParameters2D.recovery_as_collision: bool
If set to [code]true[/code], any depenetration from the recovery phase is reported as a collision; this is used e.g. by [CharacterBody2D] for improving floor detection during floor snapping.
If set to [code]false[/code], only collisions resulting from the motion are reported, which is generally the desired behavior.
