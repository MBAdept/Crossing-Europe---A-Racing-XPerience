# PackedVector4Array :: <Native> class PackedVector4Array
A packed array of [Vector4]s.
An array specifically designed to hold [Vector4]. Packs data tightly, so it saves memory for large array sizes.
[b]Differences between packed arrays, typed arrays, and untyped arrays:[/b] Packed arrays are generally faster to iterate on and modify compared to a typed array of the same type (e.g. [PackedVector4Array] versus [code]Array[Vector4][/code]). Also, packed arrays consume less memory. As a downside, packed arrays are less flexible as they don't offer as many convenience methods such as [method Array.map]. Typed arrays are in turn faster to iterate on and modify than untyped arrays.
[b]Note:[/b] Packed arrays are always passed by reference. To get a copy of an array that can be modified independently of the original array, use [method duplicate]. This is [i]not[/i] the case for built-in properties and methods. In these cases the returned packed array is a copy, and changing it will [i]not[/i] affect the original value. To update a built-in property of this type, modify the returned array and then assign it to the property again.
[b]Note:[/b] In a boolean context, a packed array will evaluate to [code]false[/code] if it's empty. Otherwise, a packed array will always evaluate to [code]true[/code].

## append :: func PackedVector4Array.append(value: Vector4) -> bool
Appends an element at the end of the array (alias of [method push_back]).

### value :: Vector4

## append_array :: func PackedVector4Array.append_array(array: PackedVector4Array) -> void
Appends a [PackedVector4Array] at the end of this array.

### array :: PackedVector4Array

## bsearch :: func PackedVector4Array.bsearch(value: Vector4, before: bool = true) -> int
Finds the index of an existing value (or the insertion index that maintains sorting order, if the value is not yet present in the array) using binary search. Optionally, a [param before] specifier can be passed. If [code]false[/code], the returned index comes after all existing entries of the value in the array.
[b]Note:[/b] Calling [method bsearch] on an unsorted array results in unexpected behavior.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector4

### before :: bool

## clear :: func PackedVector4Array.clear() -> void
Clears the array. This is equivalent to using [method resize] with a size of [code]0[/code].

## count :: func PackedVector4Array.count(value: Vector4) -> int
Returns the number of times an element is in the array.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector4

## duplicate :: func PackedVector4Array.duplicate() -> PackedVector4Array
Creates a copy of the array, and returns it.

## erase :: func PackedVector4Array.erase(value: Vector4) -> bool
Removes the first occurrence of a value from the array and returns [code]true[/code]. If the value does not exist in the array, nothing happens and [code]false[/code] is returned. To remove an element by index, use [method remove_at] instead.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector4

## fill :: func PackedVector4Array.fill(value: Vector4) -> void
Assigns the given value to all elements in the array. This can typically be used together with [method resize] to create an array with a given size and initialized elements.

### value :: Vector4

## find :: func PackedVector4Array.find(value: Vector4, from: int = 0) -> int
Searches the array for a value and returns its index or [code]-1[/code] if not found. Optionally, the initial search index can be passed.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector4

### from :: int

## get :: func PackedVector4Array.get(index: int) -> Vector4
Returns the [Vector4] at the given [param index] in the array. If [param index] is out-of-bounds or negative, this method fails and returns [code]Vector4(0, 0, 0, 0)[/code].
This method is similar (but not identical) to the [code][][/code] operator. Most notably, when this method fails, it doesn't pause project execution if run from the editor.

### index :: int

## has :: func PackedVector4Array.has(value: Vector4) -> bool
Returns [code]true[/code] if the array contains [param value].
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector4

## insert :: func PackedVector4Array.insert(at_index: int, value: Vector4) -> int
Inserts a new element at a given position in the array. The position must be valid, or at the end of the array ([code]idx == size()[/code]).

### at_index :: int

### value :: Vector4

## is_empty :: func PackedVector4Array.is_empty() -> bool
Returns [code]true[/code] if the array is empty.

## push_back :: func PackedVector4Array.push_back(value: Vector4) -> bool
Inserts a [Vector4] at the end.

### value :: Vector4

## remove_at :: func PackedVector4Array.remove_at(index: int) -> void
Removes an element from the array by index.

### index :: int

## resize :: func PackedVector4Array.resize(new_size: int) -> int
Sets the size of the array. If the array is grown, reserves elements at the end of the array. If the array is shrunk, truncates the array to the new size. Calling [method resize] once and assigning the new values is faster than adding new elements one by one.
Returns [constant OK] on success, or one of the following [enum Error] constants if this method fails: [constant ERR_INVALID_PARAMETER] if the size is negative, or [constant ERR_OUT_OF_MEMORY] if allocations fail. Use [method size] to find the actual size of the array after resize.

### new_size :: int

## reverse :: func PackedVector4Array.reverse() -> void
Reverses the order of the elements in the array.

## rfind :: func PackedVector4Array.rfind(value: Vector4, from: int = -1) -> int
Searches the array in reverse order. Optionally, a start search index can be passed. If negative, the start index is considered relative to the end of the array.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: Vector4

### from :: int

## set :: func PackedVector4Array.set(index: int, value: Vector4) -> void
Changes the [Vector4] at the given index.

### index :: int

### value :: Vector4

## size :: func PackedVector4Array.size() -> int
Returns the number of elements in the array.

## slice :: func PackedVector4Array.slice(begin: int, end: int = 2147483647) -> PackedVector4Array
Returns the slice of the [PackedVector4Array], from [param begin] (inclusive) to [param end] (exclusive), as a new [PackedVector4Array].
The absolute value of [param begin] and [param end] will be clamped to the array size, so the default value for [param end] makes it slice to the size of the array by default (i.e. [code]arr.slice(1)[/code] is a shorthand for [code]arr.slice(1, arr.size())[/code]).
If either [param begin] or [param end] are negative, they will be relative to the end of the array (i.e. [code]arr.slice(0, -2)[/code] is a shorthand for [code]arr.slice(0, arr.size() - 2)[/code]).

### begin :: int

### end :: int

## sort :: func PackedVector4Array.sort() -> void
Sorts the elements of the array in ascending order.
[b]Note:[/b] Vectors with [constant @GDScript.NAN] elements don't behave the same as other vectors. Therefore, the results from this method may not be accurate if NaNs are included.

## to_byte_array :: func PackedVector4Array.to_byte_array() -> PackedByteArray
Returns a [PackedByteArray] with each vector encoded as bytes.

## PackedVector4Array :: func PackedVector4Array.PackedVector4Array() -> PackedVector4Array
Constructs an empty [PackedVector4Array].

## PackedVector4Array :: func PackedVector4Array.PackedVector4Array(from: PackedVector4Array) -> PackedVector4Array
Constructs a [PackedVector4Array] as a copy of the given [PackedVector4Array].

### from :: PackedVector4Array

## PackedVector4Array :: func PackedVector4Array.PackedVector4Array(from: Array) -> PackedVector4Array
Constructs a new [PackedVector4Array]. Optionally, you can pass in a generic [Array] that will be converted.
[b]Note:[/b] When initializing a [PackedVector4Array] with elements, it must be initialized with an [Array] of [Vector4] values:
[codeblock]
var array = PackedVector4Array([Vector4(12, 34, 56, 78), Vector4(90, 12, 34, 56)])
[/codeblock]

### from :: Array

## operator != :: func PackedVector4Array.operator !=(right: PackedVector4Array) -> bool
Returns [code]true[/code] if contents of the arrays differ.

### right :: PackedVector4Array

## operator + :: func PackedVector4Array.operator +(right: PackedVector4Array) -> PackedVector4Array
Returns a new [PackedVector4Array] with contents of [param right] added at the end of this array. For better performance, consider using [method append_array] instead.

### right :: PackedVector4Array

## operator == :: func PackedVector4Array.operator ==(right: PackedVector4Array) -> bool
Returns [code]true[/code] if contents of both arrays are the same, i.e. they have all equal [Vector4]s at the corresponding indices.

### right :: PackedVector4Array

## operator [] :: func PackedVector4Array.operator [](index: int) -> Vector4
Returns the [Vector4] at index [param index]. Negative indices can be used to access the elements starting from the end. Using index out of array's bounds will result in an error.

### index :: int
