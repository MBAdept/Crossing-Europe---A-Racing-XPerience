# GLTFTexture :: <Native> class GLTFTexture extends Resource
GLTFTexture represents a texture in a glTF file.

## sampler :: var GLTFTexture.sampler: int
ID of the texture sampler to use when sampling the image. If -1, then the default texture sampler is used (linear filtering, and repeat wrapping in both axes).

## src_image :: var GLTFTexture.src_image: int
The index of the image associated with this texture, see [method GLTFState.get_images]. If -1, then this texture does not have an image assigned.
