# ENetPacketPeer :: <Native> class ENetPacketPeer extends PacketPeer
A wrapper class for an [url=http://enet.bespin.org/group__peer.html]ENetPeer[/url].
A PacketPeer implementation representing a peer of an [ENetConnection].
This class cannot be instantiated directly but can be retrieved during [method ENetConnection.service] or via [method ENetConnection.get_peers].
[b]Note:[/b] When exporting to Android, make sure to enable the [code]INTERNET[/code] permission in the Android export preset before exporting the project or using one-click deploy. Otherwise, network communication of any kind will be blocked by Android.

## STATE_DISCONNECTED :: const ENetPacketPeer.STATE_DISCONNECTED: PeerState = 0
The peer is disconnected.

## STATE_CONNECTING :: const ENetPacketPeer.STATE_CONNECTING: PeerState = 1
The peer is currently attempting to connect.

## STATE_ACKNOWLEDGING_CONNECT :: const ENetPacketPeer.STATE_ACKNOWLEDGING_CONNECT: PeerState = 2
The peer has acknowledged the connection request.

## STATE_CONNECTION_PENDING :: const ENetPacketPeer.STATE_CONNECTION_PENDING: PeerState = 3
The peer is currently connecting.

## STATE_CONNECTION_SUCCEEDED :: const ENetPacketPeer.STATE_CONNECTION_SUCCEEDED: PeerState = 4
The peer has successfully connected, but is not ready to communicate with yet ([constant STATE_CONNECTED]).

## STATE_CONNECTED :: const ENetPacketPeer.STATE_CONNECTED: PeerState = 5
The peer is currently connected and ready to communicate with.

## STATE_DISCONNECT_LATER :: const ENetPacketPeer.STATE_DISCONNECT_LATER: PeerState = 6
The peer is expected to disconnect after it has no more outgoing packets to send.

## STATE_DISCONNECTING :: const ENetPacketPeer.STATE_DISCONNECTING: PeerState = 7
The peer is currently disconnecting.

## STATE_ACKNOWLEDGING_DISCONNECT :: const ENetPacketPeer.STATE_ACKNOWLEDGING_DISCONNECT: PeerState = 8
The peer has acknowledged the disconnection request.

## STATE_ZOMBIE :: const ENetPacketPeer.STATE_ZOMBIE: PeerState = 9
The peer has lost connection, but is not considered truly disconnected (as the peer didn't acknowledge the disconnection request).

## PEER_PACKET_LOSS :: const ENetPacketPeer.PEER_PACKET_LOSS: PeerStatistic = 0
Mean packet loss of reliable packets as a ratio with respect to the [constant PACKET_LOSS_SCALE].

## PEER_PACKET_LOSS_VARIANCE :: const ENetPacketPeer.PEER_PACKET_LOSS_VARIANCE: PeerStatistic = 1
Packet loss variance.

## PEER_PACKET_LOSS_EPOCH :: const ENetPacketPeer.PEER_PACKET_LOSS_EPOCH: PeerStatistic = 2
The time at which packet loss statistics were last updated (in milliseconds since the connection started). The interval for packet loss statistics updates is 10 seconds, and at least one packet must have been sent since the last statistics update.

## PEER_ROUND_TRIP_TIME :: const ENetPacketPeer.PEER_ROUND_TRIP_TIME: PeerStatistic = 3
Mean packet round trip time for reliable packets.

## PEER_ROUND_TRIP_TIME_VARIANCE :: const ENetPacketPeer.PEER_ROUND_TRIP_TIME_VARIANCE: PeerStatistic = 4
Variance of the mean round trip time.

## PEER_LAST_ROUND_TRIP_TIME :: const ENetPacketPeer.PEER_LAST_ROUND_TRIP_TIME: PeerStatistic = 5
Last recorded round trip time for a reliable packet.

## PEER_LAST_ROUND_TRIP_TIME_VARIANCE :: const ENetPacketPeer.PEER_LAST_ROUND_TRIP_TIME_VARIANCE: PeerStatistic = 6
Variance of the last trip time recorded.

## PEER_PACKET_THROTTLE :: const ENetPacketPeer.PEER_PACKET_THROTTLE: PeerStatistic = 7
The peer's current throttle status.

## PEER_PACKET_THROTTLE_LIMIT :: const ENetPacketPeer.PEER_PACKET_THROTTLE_LIMIT: PeerStatistic = 8
The maximum number of unreliable packets that should not be dropped. This value is always greater than or equal to [code]1[/code]. The initial value is equal to [constant PACKET_THROTTLE_SCALE].

## PEER_PACKET_THROTTLE_COUNTER :: const ENetPacketPeer.PEER_PACKET_THROTTLE_COUNTER: PeerStatistic = 9
Internal value used to increment the packet throttle counter. The value is hardcoded to [code]7[/code] and cannot be changed. You probably want to look at [constant PEER_PACKET_THROTTLE_ACCELERATION] instead.

## PEER_PACKET_THROTTLE_EPOCH :: const ENetPacketPeer.PEER_PACKET_THROTTLE_EPOCH: PeerStatistic = 10
The time at which throttle statistics were last updated (in milliseconds since the connection started). The interval for throttle statistics updates is [constant PEER_PACKET_THROTTLE_INTERVAL].

## PEER_PACKET_THROTTLE_ACCELERATION :: const ENetPacketPeer.PEER_PACKET_THROTTLE_ACCELERATION: PeerStatistic = 11
The throttle's acceleration factor. Higher values will make ENet adapt to fluctuating network conditions faster, causing unrelaible packets to be sent [i]more[/i] often. The default value is [code]2[/code].

## PEER_PACKET_THROTTLE_DECELERATION :: const ENetPacketPeer.PEER_PACKET_THROTTLE_DECELERATION: PeerStatistic = 12
The throttle's deceleration factor. Higher values will make ENet adapt to fluctuating network conditions faster, causing unrelaible packets to be sent [i]less[/i] often. The default value is [code]2[/code].

## PEER_PACKET_THROTTLE_INTERVAL :: const ENetPacketPeer.PEER_PACKET_THROTTLE_INTERVAL: PeerStatistic = 13
The interval over which the lowest mean round trip time should be measured for use by the throttle mechanism (in milliseconds). The default value is [code]5000[/code].

## PACKET_LOSS_SCALE :: const ENetPacketPeer.PACKET_LOSS_SCALE = 65536
The reference scale for packet loss. See [method get_statistic] and [constant PEER_PACKET_LOSS].

## PACKET_THROTTLE_SCALE :: const ENetPacketPeer.PACKET_THROTTLE_SCALE = 32
The reference value for throttle configuration. The default value is [code]32[/code]. See [method throttle_configure].

## FLAG_RELIABLE :: const ENetPacketPeer.FLAG_RELIABLE = 1
Mark the packet to be sent as reliable.

## FLAG_UNSEQUENCED :: const ENetPacketPeer.FLAG_UNSEQUENCED = 2
Mark the packet to be sent unsequenced (unreliable).

## FLAG_UNRELIABLE_FRAGMENT :: const ENetPacketPeer.FLAG_UNRELIABLE_FRAGMENT = 8
Mark the packet to be sent unreliable even if the packet is too big and needs fragmentation (increasing the chance of it being dropped).

## get_channels :: func ENetPacketPeer.get_channels() -> int
Returns the number of channels allocated for communication with peer.

## get_packet_flags :: func ENetPacketPeer.get_packet_flags() -> int
Returns the ENet flags of the next packet in the received queue. See [code]FLAG_*[/code] constants for available packet flags. Note that not all flags are replicated from the sending peer to the receiving peer.

## get_remote_address :: func ENetPacketPeer.get_remote_address() -> String
Returns the IP address of this peer.

## get_remote_port :: func ENetPacketPeer.get_remote_port() -> int
Returns the remote port of this peer.

## get_state :: func ENetPacketPeer.get_state() -> int
Returns the current peer state.

## get_statistic :: func ENetPacketPeer.get_statistic(statistic: int) -> float
Returns the requested [param statistic] for this peer.

### statistic :: int

## is_active :: func ENetPacketPeer.is_active() -> bool
Returns [code]true[/code] if the peer is currently active (i.e. the associated [ENetConnection] is still valid).

## peer_disconnect :: func ENetPacketPeer.peer_disconnect(data: int = 0) -> void
Request a disconnection from a peer. An [constant ENetConnection.EVENT_DISCONNECT] will be generated during [method ENetConnection.service] once the disconnection is complete.

### data :: int

## peer_disconnect_later :: func ENetPacketPeer.peer_disconnect_later(data: int = 0) -> void
Request a disconnection from a peer, but only after all queued outgoing packets are sent. An [constant ENetConnection.EVENT_DISCONNECT] will be generated during [method ENetConnection.service] once the disconnection is complete.

### data :: int

## peer_disconnect_now :: func ENetPacketPeer.peer_disconnect_now(data: int = 0) -> void
Force an immediate disconnection from a peer. No [constant ENetConnection.EVENT_DISCONNECT] will be generated. The foreign peer is not guaranteed to receive the disconnect notification, and is reset immediately upon return from this function.

### data :: int

## ping :: func ENetPacketPeer.ping() -> void
Sends a ping request to a peer. ENet automatically pings all connected peers at regular intervals, however, this function may be called to ensure more frequent ping requests.

## ping_interval :: func ENetPacketPeer.ping_interval(ping_interval: int) -> void
Sets the [param ping_interval] in milliseconds at which pings will be sent to a peer. Pings are used both to monitor the liveness of the connection and also to dynamically adjust the throttle during periods of low traffic so that the throttle has reasonable responsiveness during traffic spikes. The default ping interval is [code]500[/code] milliseconds.

### ping_interval :: int

## reset :: func ENetPacketPeer.reset() -> void
Forcefully disconnects a peer. The foreign host represented by the peer is not notified of the disconnection and will timeout on its connection to the local host.

## send :: func ENetPacketPeer.send(channel: int, packet: PackedByteArray, flags: int) -> int
Queues a [param packet] to be sent over the specified [param channel]. See [code]FLAG_*[/code] constants for available packet flags.

### channel :: int

### packet :: PackedByteArray

### flags :: int

## set_timeout :: func ENetPacketPeer.set_timeout(timeout: int, timeout_min: int, timeout_max: int) -> void
Sets the timeout parameters for a peer. The timeout parameters control how and when a peer will timeout from a failure to acknowledge reliable traffic. Timeout values are expressed in milliseconds.
The [param timeout] is a factor that, multiplied by a value based on the average round trip time, will determine the timeout limit for a reliable packet. When that limit is reached, the timeout will be doubled, and the peer will be disconnected if that limit has reached [param timeout_min]. The [param timeout_max] parameter, on the other hand, defines a fixed timeout for which any packet must be acknowledged or the peer will be dropped.

### timeout :: int

### timeout_min :: int

### timeout_max :: int

## throttle_configure :: func ENetPacketPeer.throttle_configure(interval: int, acceleration: int, deceleration: int) -> void
Configures throttle parameter for a peer.
Unreliable packets are dropped by ENet in response to the varying conditions of the Internet connection to the peer. The throttle represents a probability that an unreliable packet should not be dropped and thus sent by ENet to the peer. By measuring fluctuations in round trip times of reliable packets over the specified [param interval], ENet will either increase the probability by the amount specified in the [param acceleration] parameter, or decrease it by the amount specified in the [param deceleration] parameter (both are ratios to [constant PACKET_THROTTLE_SCALE]).
When the throttle has a value of [constant PACKET_THROTTLE_SCALE], no unreliable packets are dropped by ENet, and so 100% of all unreliable packets will be sent.
When the throttle has a value of [code]0[/code], all unreliable packets are dropped by ENet, and so 0% of all unreliable packets will be sent.
Intermediate values for the throttle represent intermediate probabilities between 0% and 100% of unreliable packets being sent. The bandwidth limits of the local and foreign hosts are taken into account to determine a sensible limit for the throttle probability above which it should not raise even in the best of conditions.

### interval :: int

### acceleration :: int

### deceleration :: int
