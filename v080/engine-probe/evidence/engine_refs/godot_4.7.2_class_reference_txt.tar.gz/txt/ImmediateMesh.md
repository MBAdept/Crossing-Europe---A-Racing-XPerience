# ImmediateMesh :: <Native> class ImmediateMesh extends Mesh
Mesh optimized for creating geometry manually.
A mesh type optimized for creating geometry manually, similar to OpenGL 1.x immediate mode.
Here's a sample on how to generate a triangular face:
[codeblocks]
[gdscript]
var mesh = ImmediateMesh.new()
mesh.surface_begin(Mesh.PRIMITIVE_TRIANGLES)
mesh.surface_add_vertex(Vector3.LEFT)
mesh.surface_add_vertex(Vector3.FORWARD)
mesh.surface_add_vertex(Vector3.ZERO)
mesh.surface_end()
[/gdscript]
[csharp]
var mesh = new ImmediateMesh();
mesh.SurfaceBegin(Mesh.PrimitiveType.Triangles);
mesh.SurfaceAddVertex(Vector3.Left);
mesh.SurfaceAddVertex(Vector3.Forward);
mesh.SurfaceAddVertex(Vector3.Zero);
mesh.SurfaceEnd();
[/csharp]
[/codeblocks]
[b]Note:[/b] Generating complex geometries with [ImmediateMesh] is highly inefficient. Instead, it is designed to generate simple geometry that changes often.

## clear_surfaces :: func ImmediateMesh.clear_surfaces() -> void
Clear all surfaces.

## surface_add_vertex :: func ImmediateMesh.surface_add_vertex(vertex: Vector3) -> void
Add a 3D vertex using the current attributes previously set.

### vertex :: Vector3

## surface_add_vertex_2d :: func ImmediateMesh.surface_add_vertex_2d(vertex: Vector2) -> void
Add a 2D vertex using the current attributes previously set.

### vertex :: Vector2

## surface_begin :: func ImmediateMesh.surface_begin(primitive: int, material: Material = null) -> void
Begin a new surface.

### primitive :: int

### material :: Material

## surface_end :: func ImmediateMesh.surface_end() -> void
End and commit current surface. Note that surface being created will not be visible until this function is called.

## surface_set_color :: func ImmediateMesh.surface_set_color(color: Color) -> void
Set the color attribute that will be pushed with the next vertex.

### color :: Color

## surface_set_normal :: func ImmediateMesh.surface_set_normal(normal: Vector3) -> void
Set the normal attribute that will be pushed with the next vertex.

### normal :: Vector3

## surface_set_tangent :: func ImmediateMesh.surface_set_tangent(tangent: Plane) -> void
Set the tangent attribute that will be pushed with the next vertex.
[b]Note:[/b] Even though [param tangent] is a [Plane], it does not directly represent the tangent plane. Its [member Plane.x], [member Plane.y], and [member Plane.z] represent the tangent vector and [member Plane.d] should be either [code]-1[/code] or [code]1[/code]. See also [constant Mesh.ARRAY_TANGENT].

### tangent :: Plane

## surface_set_uv :: func ImmediateMesh.surface_set_uv(uv: Vector2) -> void
Set the UV attribute that will be pushed with the next vertex.

### uv :: Vector2

## surface_set_uv2 :: func ImmediateMesh.surface_set_uv2(uv2: Vector2) -> void
Set the UV2 attribute that will be pushed with the next vertex.

### uv2 :: Vector2
