# VisualShaderNodeColorConstant :: <Native> class VisualShaderNodeColorConstant extends VisualShaderNodeConstant
A [Color] constant to be used within the visual shader graph.
Has two output ports representing RGB and alpha channels of [Color].
Translated to [code]vec3 rgb[/code] and [code]float alpha[/code] in the shader language.

## constant :: var VisualShaderNodeColorConstant.constant: Color
A [Color] constant which represents a state of this node.
