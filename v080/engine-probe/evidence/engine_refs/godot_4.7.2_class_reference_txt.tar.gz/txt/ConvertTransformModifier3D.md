# ConvertTransformModifier3D :: <Native> class ConvertTransformModifier3D extends BoneConstraint3D
A [SkeletonModifier3D] that apply transform to the bone which converted from reference.
Apply the copied transform of the bone set by [method BoneConstraint3D.set_reference_bone] to the bone set by [method BoneConstraint3D.set_apply_bone] about the specific axis with remapping it with some options.
There are 4 ways to apply the transform, depending on the combination of [method set_relative] and [method set_additive].
[b]Relative + Additive:[/b]
- Extract reference pose relative to the rest and add it to the apply bone's pose.
[b]Relative + Not Additive:[/b]
- Extract reference pose relative to the rest and add it to the apply bone's rest.
[b]Not Relative + Additive:[/b]
- Extract reference pose absolutely and add it to the apply bone's pose.
[b]Not Relative + Not Additive:[/b]
- Extract reference pose absolutely and the apply bone's pose is replaced with it.
[b]Note:[/b] Relative option is available only in the case [method BoneConstraint3D.get_reference_type] is [constant BoneConstraint3D.REFERENCE_TYPE_BONE]. See also [enum BoneConstraint3D.ReferenceType].
[b]Note:[/b] If there is a rotation greater than [code]180[/code] degrees with constrained axes, flipping may occur.

## TRANSFORM_MODE_POSITION :: const ConvertTransformModifier3D.TRANSFORM_MODE_POSITION: TransformMode = 0
Convert with position. Transfer the difference.

## TRANSFORM_MODE_ROTATION :: const ConvertTransformModifier3D.TRANSFORM_MODE_ROTATION: TransformMode = 1
Convert with rotation. The angle is the roll for the specified axis.

## TRANSFORM_MODE_SCALE :: const ConvertTransformModifier3D.TRANSFORM_MODE_SCALE: TransformMode = 2
Convert with scale. Transfers the ratio, not the difference.

## setting_count :: var ConvertTransformModifier3D.setting_count: int
The number of settings in the modifier.

## get_apply_axis :: func ConvertTransformModifier3D.get_apply_axis(index: int) -> int
Returns the axis of the remapping destination transform.

### index :: int

## get_apply_range_max :: func ConvertTransformModifier3D.get_apply_range_max(index: int) -> float
Returns the maximum value of the remapping destination range.

### index :: int

## get_apply_range_min :: func ConvertTransformModifier3D.get_apply_range_min(index: int) -> float
Returns the minimum value of the remapping destination range.

### index :: int

## get_apply_transform_mode :: func ConvertTransformModifier3D.get_apply_transform_mode(index: int) -> int
Returns the operation of the remapping destination transform.

### index :: int

## get_reference_axis :: func ConvertTransformModifier3D.get_reference_axis(index: int) -> int
Returns the axis of the remapping source transform.

### index :: int

## get_reference_range_max :: func ConvertTransformModifier3D.get_reference_range_max(index: int) -> float
Returns the maximum value of the remapping source range.

### index :: int

## get_reference_range_min :: func ConvertTransformModifier3D.get_reference_range_min(index: int) -> float
Returns the minimum value of the remapping source range.

### index :: int

## get_reference_transform_mode :: func ConvertTransformModifier3D.get_reference_transform_mode(index: int) -> int
Returns the operation of the remapping source transform.

### index :: int

## is_additive :: func ConvertTransformModifier3D.is_additive(index: int) -> bool
Returns [code]true[/code] if the additive option is enabled in the setting at [param index].

### index :: int

## is_relative :: func ConvertTransformModifier3D.is_relative(index: int) -> bool
Returns [code]true[/code] if the relative option is enabled in the setting at [param index].

### index :: int

## set_additive :: func ConvertTransformModifier3D.set_additive(index: int, enabled: bool) -> void
Sets additive option in the setting at [param index] to [param enabled]. This mainly affects the process of applying transform to the [method BoneConstraint3D.set_apply_bone].
If sets [param enabled] to [code]true[/code], the processed transform is added to the pose of the current apply bone.
If sets [param enabled] to [code]false[/code], the pose of the current apply bone is replaced with the processed transform. However, if set [method set_relative] to [code]true[/code], the transform is relative to rest.

### index :: int

### enabled :: bool

## set_apply_axis :: func ConvertTransformModifier3D.set_apply_axis(index: int, axis: int) -> void
Sets the axis of the remapping destination transform.

### index :: int

### axis :: int

## set_apply_range_max :: func ConvertTransformModifier3D.set_apply_range_max(index: int, range_max: float) -> void
Sets the maximum value of the remapping destination range.

### index :: int

### range_max :: float

## set_apply_range_min :: func ConvertTransformModifier3D.set_apply_range_min(index: int, range_min: float) -> void
Sets the minimum value of the remapping destination range.

### index :: int

### range_min :: float

## set_apply_transform_mode :: func ConvertTransformModifier3D.set_apply_transform_mode(index: int, transform_mode: int) -> void
Sets the operation of the remapping destination transform.

### index :: int

### transform_mode :: int

## set_reference_axis :: func ConvertTransformModifier3D.set_reference_axis(index: int, axis: int) -> void
Sets the axis of the remapping source transform.

### index :: int

### axis :: int

## set_reference_range_max :: func ConvertTransformModifier3D.set_reference_range_max(index: int, range_max: float) -> void
Sets the maximum value of the remapping source range.

### index :: int

### range_max :: float

## set_reference_range_min :: func ConvertTransformModifier3D.set_reference_range_min(index: int, range_min: float) -> void
Sets the minimum value of the remapping source range.

### index :: int

### range_min :: float

## set_reference_transform_mode :: func ConvertTransformModifier3D.set_reference_transform_mode(index: int, transform_mode: int) -> void
Sets the operation of the remapping source transform.

### index :: int

### transform_mode :: int

## set_relative :: func ConvertTransformModifier3D.set_relative(index: int, enabled: bool) -> void
Sets relative option in the setting at [param index] to [param enabled].
If sets [param enabled] to [code]true[/code], the extracted and applying transform is relative to the rest.
If sets [param enabled] to [code]false[/code], the extracted transform is absolute.

### index :: int

### enabled :: bool
