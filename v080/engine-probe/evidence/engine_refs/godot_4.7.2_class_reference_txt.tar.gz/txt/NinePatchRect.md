# NinePatchRect :: <Native> class NinePatchRect extends Control
A control that displays a texture by keeping its corners intact, but tiling its edges and center.
Also known as 9-slice panels, [NinePatchRect] produces clean panels of any size based on a small texture. To do so, it splits the texture in a 3×3 grid. When you scale the node, it tiles the texture's edges horizontally or vertically, tiles the center on both axes, and leaves the corners unchanged.

## AXIS_STRETCH_MODE_STRETCH :: const NinePatchRect.AXIS_STRETCH_MODE_STRETCH: AxisStretchMode = 0
Stretches the center texture across the NinePatchRect. This may cause the texture to be distorted.

## AXIS_STRETCH_MODE_TILE :: const NinePatchRect.AXIS_STRETCH_MODE_TILE: AxisStretchMode = 1
Repeats the center texture across the NinePatchRect. This won't cause any visible distortion. The texture must be seamless for this to work without displaying artifacts between edges.

## AXIS_STRETCH_MODE_TILE_FIT :: const NinePatchRect.AXIS_STRETCH_MODE_TILE_FIT: AxisStretchMode = 2
Repeats the center texture across the NinePatchRect, but will also stretch the texture to make sure each tile is visible in full. This may cause the texture to be distorted, but less than [constant AXIS_STRETCH_MODE_STRETCH]. The texture must be seamless for this to work without displaying artifacts between edges.

## axis_stretch_horizontal :: var NinePatchRect.axis_stretch_horizontal: NinePatchRect.AxisStretchMode
The stretch mode to use for horizontal stretching/tiling.

## axis_stretch_vertical :: var NinePatchRect.axis_stretch_vertical: NinePatchRect.AxisStretchMode
The stretch mode to use for vertical stretching/tiling.

## draw_center :: var NinePatchRect.draw_center: bool
If [code]true[/code], draw the panel's center. Else, only draw the 9-slice's borders.

## mouse_filter :: var NinePatchRect.mouse_filter: Control.MouseFilter

## patch_margin_bottom :: var NinePatchRect.patch_margin_bottom: int
The height of the 9-slice's bottom row. A margin of 16 means the 9-slice's bottom corners and side will have a height of 16 pixels. You can set all 4 margin values individually to create panels with non-uniform borders.

## patch_margin_left :: var NinePatchRect.patch_margin_left: int
The width of the 9-slice's left column. A margin of 16 means the 9-slice's left corners and side will have a width of 16 pixels. You can set all 4 margin values individually to create panels with non-uniform borders.

## patch_margin_right :: var NinePatchRect.patch_margin_right: int
The width of the 9-slice's right column. A margin of 16 means the 9-slice's right corners and side will have a width of 16 pixels. You can set all 4 margin values individually to create panels with non-uniform borders.

## patch_margin_top :: var NinePatchRect.patch_margin_top: int
The height of the 9-slice's top row. A margin of 16 means the 9-slice's top corners and side will have a height of 16 pixels. You can set all 4 margin values individually to create panels with non-uniform borders.

## region_rect :: var NinePatchRect.region_rect: Rect2
Rectangular region of the texture to sample from. If you're working with an atlas, use this property to define the area the 9-slice should use. All other properties are relative to this one. If the rect is empty, NinePatchRect will use the whole texture.

## texture :: var NinePatchRect.texture: Texture2D
The node's texture resource.

## get_patch_margin :: func NinePatchRect.get_patch_margin(margin: int) -> int
Returns the size of the margin on the specified [enum Side].

### margin :: int

## set_patch_margin :: func NinePatchRect.set_patch_margin(margin: int, value: int) -> void
Sets the size of the margin on the specified [enum Side] to [param value] pixels.

### margin :: int

### value :: int

## texture_changed :: func NinePatchRect.texture_changed() -> void
Emitted when the node's texture changes.
