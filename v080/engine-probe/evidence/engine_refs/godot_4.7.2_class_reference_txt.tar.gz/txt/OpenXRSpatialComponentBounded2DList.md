# OpenXRSpatialComponentBounded2DList :: <Native> class OpenXRSpatialComponentBounded2DList extends OpenXRSpatialComponentData
Object for storing the queries bounded2d result data.
Object for storing the queries 2D bounding rectangle result data when calling [method OpenXRSpatialEntityExtension.query_snapshot].

## get_center_pose :: func OpenXRSpatialComponentBounded2DList.get_center_pose(index: int) -> Transform3D
Returns the center of our bounding rectangle for the entity at this [param index].

### index :: int

## get_size :: func OpenXRSpatialComponentBounded2DList.get_size(index: int) -> Vector2
Returns the size of our bounding rectangle for the entity at this [param index].

### index :: int
