# BoxContainer :: <Native> class BoxContainer extends Container
A container that arranges its child controls horizontally or vertically.
A container that arranges its child controls horizontally or vertically, rearranging them automatically when their minimum size changes.

## ALIGNMENT_BEGIN :: const BoxContainer.ALIGNMENT_BEGIN: AlignmentMode = 0
The child controls will be arranged at the beginning of the container, i.e. top if orientation is vertical, left if orientation is horizontal (right for RTL layout).

## ALIGNMENT_CENTER :: const BoxContainer.ALIGNMENT_CENTER: AlignmentMode = 1
The child controls will be centered in the container.

## ALIGNMENT_END :: const BoxContainer.ALIGNMENT_END: AlignmentMode = 2
The child controls will be arranged at the end of the container, i.e. bottom if orientation is vertical, right if orientation is horizontal (left for RTL layout).

## alignment :: var BoxContainer.alignment: BoxContainer.AlignmentMode
The alignment of the container's children (must be one of [constant ALIGNMENT_BEGIN], [constant ALIGNMENT_CENTER], or [constant ALIGNMENT_END]).

## vertical :: var BoxContainer.vertical: bool
If [code]true[/code], the [BoxContainer] will arrange its children vertically, rather than horizontally.
Can't be changed when using [HBoxContainer] and [VBoxContainer].

## separation :: <Theme> var BoxContainer.separation: int
The space between the [BoxContainer]'s elements, in pixels.

## add_spacer :: func BoxContainer.add_spacer(begin: bool) -> Control
Adds a [Control] node to the box as a spacer. If [param begin] is [code]true[/code], it will insert the [Control] node in front of all other children.

### begin :: bool
