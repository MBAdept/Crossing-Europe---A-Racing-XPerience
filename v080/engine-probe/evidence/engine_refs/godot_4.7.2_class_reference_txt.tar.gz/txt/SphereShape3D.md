# SphereShape3D :: <Native> class SphereShape3D extends Shape3D
A 3D sphere shape used for physics collision.
A 3D sphere shape, intended for use in physics. Usually used to provide a shape for a [CollisionShape3D].
[b]Performance:[/b] [SphereShape3D] is fast to check collisions against. It is faster than [BoxShape3D], [CapsuleShape3D], and [CylinderShape3D].

## radius :: var SphereShape3D.radius: float
The sphere's radius. The shape's diameter is double the radius.
