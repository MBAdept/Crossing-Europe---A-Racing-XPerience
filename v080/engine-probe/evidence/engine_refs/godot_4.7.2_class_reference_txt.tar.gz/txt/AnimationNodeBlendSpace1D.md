# AnimationNodeBlendSpace1D :: <Native> class AnimationNodeBlendSpace1D extends AnimationRootNode
A set of [AnimationRootNode]s placed on a virtual axis, crossfading between the two adjacent ones. Used by [AnimationTree].
A resource used by [AnimationNodeBlendTree].
[AnimationNodeBlendSpace1D] represents a virtual axis on which any type of [AnimationRootNode]s can be added using [method add_blend_point]. Outputs the linear blend of the two [AnimationRootNode]s adjacent to the current value.
You can set the extents of the axis with [member min_space] and [member max_space].

## BLEND_MODE_INTERPOLATED :: const AnimationNodeBlendSpace1D.BLEND_MODE_INTERPOLATED: BlendMode = 0
The interpolation between animations is linear.

## BLEND_MODE_DISCRETE :: const AnimationNodeBlendSpace1D.BLEND_MODE_DISCRETE: BlendMode = 1
The blend space plays the animation of the animation node which blending position is closest to. Useful for frame-by-frame 2D animations.

## BLEND_MODE_DISCRETE_CARRY :: const AnimationNodeBlendSpace1D.BLEND_MODE_DISCRETE_CARRY: BlendMode = 2
Similar to [constant BLEND_MODE_DISCRETE], but starts the new animation at the last animation's playback position.

## SYNC_MODE_NONE :: const AnimationNodeBlendSpace1D.SYNC_MODE_NONE: SyncMode = 0
Inactive animations are frozen and do not advance.

## SYNC_MODE_INDEPENDENT :: const AnimationNodeBlendSpace1D.SYNC_MODE_INDEPENDENT: SyncMode = 1
Inactive animations advance with a weight of [code]0[/code]. This is equivalent to the previous [code]sync = true[/code] behavior.

## SYNC_MODE_CYCLIC_MUTABLE :: const AnimationNodeBlendSpace1D.SYNC_MODE_CYCLIC_MUTABLE: SyncMode = 2
All animations are time-scaled so they stay in sync, with the cycle length dynamically computed from active blend weights. This is self-normalizing: a solo animation plays at normal speed.
[b]Note:[/b] If you apply [AnimationNodeTimeSeek] to the result when handling animations of different lengths, synchronization will be broken. In such cases, it is recommended to use [member AnimationNodeAnimation.use_custom_timeline] to align the animation lengths.

## SYNC_MODE_CYCLIC_CONSTANT :: const AnimationNodeBlendSpace1D.SYNC_MODE_CYCLIC_CONSTANT: SyncMode = 3
All animations are time-scaled so they complete one cycle in [member cyclic_length] seconds, keeping them in sync regardless of their individual lengths.
[b]Note:[/b] If you apply [AnimationNodeTimeSeek] to the result when handling animations of different lengths, synchronization will be broken. In such cases, it is recommended to use [member AnimationNodeAnimation.use_custom_timeline] to align the animation lengths.

## blend_mode :: var AnimationNodeBlendSpace1D.blend_mode: AnimationNodeBlendSpace1D.BlendMode
Controls the interpolation between animations.

## cyclic_length :: var AnimationNodeBlendSpace1D.cyclic_length: float
The cycle length in seconds used by [constant SYNC_MODE_CYCLIC_CONSTANT]. All animations are time-scaled so they complete one full cycle in this duration. Must be greater than [code]0[/code] for cyclic sync to take effect.

## max_space :: var AnimationNodeBlendSpace1D.max_space: float
The blend space's axis's upper limit for the points' position. See [method add_blend_point].

## min_space :: var AnimationNodeBlendSpace1D.min_space: float
The blend space's axis's lower limit for the points' position. See [method add_blend_point].

## snap :: var AnimationNodeBlendSpace1D.snap: float
Position increment to snap to when moving a point on the axis.

## sync :: var AnimationNodeBlendSpace1D.sync: bool
If [code]true[/code], sync mode is enabled (equivalent to [constant SYNC_MODE_INDEPENDENT]). This property is kept for backward compatibility.

## sync_mode :: var AnimationNodeBlendSpace1D.sync_mode: AnimationNodeBlendSpace1D.SyncMode
Controls how animations are synced when blended. See [enum SyncMode] for available options.

## value_label :: var AnimationNodeBlendSpace1D.value_label: String
Label of the virtual axis of the blend space.

## add_blend_point :: func AnimationNodeBlendSpace1D.add_blend_point(node: AnimationRootNode, pos: float, at_index: int = -1, name: StringName = &"") -> void
Adds a new point with [param name] that represents a [param node] on the virtual axis at a given position set by [param pos]. You can insert it at a specific index using the [param at_index] argument. If you use the default value for [param at_index], the point is inserted at the end of the blend points array.
[b]Note:[/b] If no name is provided, safe index is used as reference. In the future, empty names will be deprecated, so explicitly passing a name is recommended.

### node :: AnimationRootNode

### pos :: float

### at_index :: int

### name :: StringName

## find_blend_point_by_name :: func AnimationNodeBlendSpace1D.find_blend_point_by_name(name: StringName) -> int
Returns the index of the blend point with the given [param name]. Returns [code]-1[/code] if no blend point with that name is found.

### name :: StringName

## get_blend_point_count :: func AnimationNodeBlendSpace1D.get_blend_point_count() -> int
Returns the number of points on the blend axis.

## get_blend_point_name :: func AnimationNodeBlendSpace1D.get_blend_point_name(point: int) -> StringName
Returns the name of the blend point at index [param point].

### point :: int

## get_blend_point_node :: func AnimationNodeBlendSpace1D.get_blend_point_node(point: int) -> AnimationRootNode
Returns the [AnimationNode] referenced by the point at index [param point].

### point :: int

## get_blend_point_position :: func AnimationNodeBlendSpace1D.get_blend_point_position(point: int) -> float
Returns the position of the point at index [param point].

### point :: int

## remove_blend_point :: func AnimationNodeBlendSpace1D.remove_blend_point(point: int) -> void
Removes the point at index [param point] from the blend axis.

### point :: int

## reorder_blend_point :: func AnimationNodeBlendSpace1D.reorder_blend_point(from_index: int, to_index: int) -> void
Swaps the blend points at indices [param from_index] and [param to_index], exchanging their positions and properties.

### from_index :: int

### to_index :: int

## set_blend_point_name :: func AnimationNodeBlendSpace1D.set_blend_point_name(point: int, name: StringName) -> void
Sets the name of the blend point at index [param point]. If the name conflicts with an existing point, a unique name will be generated automatically.

### point :: int

### name :: StringName

## set_blend_point_node :: func AnimationNodeBlendSpace1D.set_blend_point_node(point: int, node: AnimationRootNode) -> void
Changes the [AnimationNode] referenced by the point at index [param point].

### point :: int

### node :: AnimationRootNode

## set_blend_point_position :: func AnimationNodeBlendSpace1D.set_blend_point_position(point: int, pos: float) -> void
Updates the position of the point at index [param point] on the blend axis.

### point :: int

### pos :: float
