# JointLimitation3D :: <Native> class JointLimitation3D extends Resource
A base class of the limitation that interacts with [ChainIK3D].
The limitation is attached to each joint and limits the rotation of the bone.
