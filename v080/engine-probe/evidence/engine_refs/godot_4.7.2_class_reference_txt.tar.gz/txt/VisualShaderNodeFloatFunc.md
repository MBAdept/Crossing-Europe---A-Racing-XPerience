# VisualShaderNodeFloatFunc :: <Native> class VisualShaderNodeFloatFunc extends VisualShaderNode
A scalar floating-point function to be used within the visual shader graph.
Accept a floating-point scalar ([code]x[/code]) to the input port and transform it according to [member function].

## FUNC_SIN :: const VisualShaderNodeFloatFunc.FUNC_SIN: Function = 0
Returns the sine of the parameter. Translates to [code]sin(x)[/code] in the Godot Shader Language.

## FUNC_COS :: const VisualShaderNodeFloatFunc.FUNC_COS: Function = 1
Returns the cosine of the parameter. Translates to [code]cos(x)[/code] in the Godot Shader Language.

## FUNC_TAN :: const VisualShaderNodeFloatFunc.FUNC_TAN: Function = 2
Returns the tangent of the parameter. Translates to [code]tan(x)[/code] in the Godot Shader Language.

## FUNC_ASIN :: const VisualShaderNodeFloatFunc.FUNC_ASIN: Function = 3
Returns the arc-sine of the parameter. Translates to [code]asin(x)[/code] in the Godot Shader Language.

## FUNC_ACOS :: const VisualShaderNodeFloatFunc.FUNC_ACOS: Function = 4
Returns the arc-cosine of the parameter. Translates to [code]acos(x)[/code] in the Godot Shader Language.

## FUNC_ATAN :: const VisualShaderNodeFloatFunc.FUNC_ATAN: Function = 5
Returns the arc-tangent of the parameter. Translates to [code]atan(x)[/code] in the Godot Shader Language.

## FUNC_SINH :: const VisualShaderNodeFloatFunc.FUNC_SINH: Function = 6
Returns the hyperbolic sine of the parameter. Translates to [code]sinh(x)[/code] in the Godot Shader Language.

## FUNC_COSH :: const VisualShaderNodeFloatFunc.FUNC_COSH: Function = 7
Returns the hyperbolic cosine of the parameter. Translates to [code]cosh(x)[/code] in the Godot Shader Language.

## FUNC_TANH :: const VisualShaderNodeFloatFunc.FUNC_TANH: Function = 8
Returns the hyperbolic tangent of the parameter. Translates to [code]tanh(x)[/code] in the Godot Shader Language.

## FUNC_LOG :: const VisualShaderNodeFloatFunc.FUNC_LOG: Function = 9
Returns the natural logarithm of the parameter. Translates to [code]log(x)[/code] in the Godot Shader Language.

## FUNC_EXP :: const VisualShaderNodeFloatFunc.FUNC_EXP: Function = 10
Returns the natural exponentiation of the parameter. Translates to [code]exp(x)[/code] in the Godot Shader Language.

## FUNC_SQRT :: const VisualShaderNodeFloatFunc.FUNC_SQRT: Function = 11
Returns the square root of the parameter. Translates to [code]sqrt(x)[/code] in the Godot Shader Language.

## FUNC_ABS :: const VisualShaderNodeFloatFunc.FUNC_ABS: Function = 12
Returns the absolute value of the parameter. Translates to [code]abs(x)[/code] in the Godot Shader Language.

## FUNC_SIGN :: const VisualShaderNodeFloatFunc.FUNC_SIGN: Function = 13
Extracts the sign of the parameter. Translates to [code]sign(x)[/code] in the Godot Shader Language.

## FUNC_FLOOR :: const VisualShaderNodeFloatFunc.FUNC_FLOOR: Function = 14
Finds the nearest integer less than or equal to the parameter. Translates to [code]floor(x)[/code] in the Godot Shader Language.

## FUNC_ROUND :: const VisualShaderNodeFloatFunc.FUNC_ROUND: Function = 15
Finds the nearest integer to the parameter. Translates to [code]round(x)[/code] in the Godot Shader Language.

## FUNC_CEIL :: const VisualShaderNodeFloatFunc.FUNC_CEIL: Function = 16
Finds the nearest integer that is greater than or equal to the parameter. Translates to [code]ceil(x)[/code] in the Godot Shader Language.

## FUNC_FRACT :: const VisualShaderNodeFloatFunc.FUNC_FRACT: Function = 17
Computes the fractional part of the argument. Translates to [code]fract(x)[/code] in the Godot Shader Language.

## FUNC_SATURATE :: const VisualShaderNodeFloatFunc.FUNC_SATURATE: Function = 18
Clamps the value between [code]0.0[/code] and [code]1.0[/code] using [code]min(max(x, 0.0), 1.0)[/code].

## FUNC_NEGATE :: const VisualShaderNodeFloatFunc.FUNC_NEGATE: Function = 19
Negates the [code]x[/code] using [code]-(x)[/code].

## FUNC_ACOSH :: const VisualShaderNodeFloatFunc.FUNC_ACOSH: Function = 20
Returns the arc-hyperbolic-cosine of the parameter. Translates to [code]acosh(x)[/code] in the Godot Shader Language.

## FUNC_ASINH :: const VisualShaderNodeFloatFunc.FUNC_ASINH: Function = 21
Returns the arc-hyperbolic-sine of the parameter. Translates to [code]asinh(x)[/code] in the Godot Shader Language.

## FUNC_ATANH :: const VisualShaderNodeFloatFunc.FUNC_ATANH: Function = 22
Returns the arc-hyperbolic-tangent of the parameter. Translates to [code]atanh(x)[/code] in the Godot Shader Language.

## FUNC_DEGREES :: const VisualShaderNodeFloatFunc.FUNC_DEGREES: Function = 23
Convert a quantity in radians to degrees. Translates to [code]degrees(x)[/code] in the Godot Shader Language.

## FUNC_EXP2 :: const VisualShaderNodeFloatFunc.FUNC_EXP2: Function = 24
Returns 2 raised by the power of the parameter. Translates to [code]exp2(x)[/code] in the Godot Shader Language.

## FUNC_INVERSE_SQRT :: const VisualShaderNodeFloatFunc.FUNC_INVERSE_SQRT: Function = 25
Returns the inverse of the square root of the parameter. Translates to [code]inversesqrt(x)[/code] in the Godot Shader Language.

## FUNC_LOG2 :: const VisualShaderNodeFloatFunc.FUNC_LOG2: Function = 26
Returns the base 2 logarithm of the parameter. Translates to [code]log2(x)[/code] in the Godot Shader Language.

## FUNC_RADIANS :: const VisualShaderNodeFloatFunc.FUNC_RADIANS: Function = 27
Convert a quantity in degrees to radians. Translates to [code]radians(x)[/code] in the Godot Shader Language.

## FUNC_RECIPROCAL :: const VisualShaderNodeFloatFunc.FUNC_RECIPROCAL: Function = 28
Finds reciprocal value of dividing 1 by [code]x[/code] (i.e. [code]1 / x[/code]).

## FUNC_ROUNDEVEN :: const VisualShaderNodeFloatFunc.FUNC_ROUNDEVEN: Function = 29
Finds the nearest even integer to the parameter. Translates to [code]roundEven(x)[/code] in the Godot Shader Language.

## FUNC_TRUNC :: const VisualShaderNodeFloatFunc.FUNC_TRUNC: Function = 30
Returns a value equal to the nearest integer to [code]x[/code] whose absolute value is not larger than the absolute value of [code]x[/code]. Translates to [code]trunc(x)[/code] in the Godot Shader Language.

## FUNC_ONEMINUS :: const VisualShaderNodeFloatFunc.FUNC_ONEMINUS: Function = 31
Subtracts scalar [code]x[/code] from 1 (i.e. [code]1 - x[/code]).

## FUNC_MAX :: const VisualShaderNodeFloatFunc.FUNC_MAX: Function = 32
Represents the size of the [enum Function] enum.

## function :: var VisualShaderNodeFloatFunc.function: VisualShaderNodeFloatFunc.Function
A function to be applied to the scalar.
