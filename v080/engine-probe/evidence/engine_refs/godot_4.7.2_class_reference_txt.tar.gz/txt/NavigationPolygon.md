# NavigationPolygon :: <Native> class NavigationPolygon extends Resource
A 2D navigation mesh that describes a traversable surface for pathfinding.
A navigation mesh can be created either by baking it with the help of the [NavigationServer2D], or by adding vertices and convex polygon indices arrays manually.
To bake a navigation mesh at least one outline needs to be added that defines the outer bounds of the baked area.
[codeblocks]
[gdscript]
var new_navigation_mesh = NavigationPolygon.new()
var bounding_outline = PackedVector2Array([Vector2(0, 0), Vector2(0, 50), Vector2(50, 50), Vector2(50, 0)])
new_navigation_mesh.add_outline(bounding_outline)
NavigationServer2D.bake_from_source_geometry_data(new_navigation_mesh, NavigationMeshSourceGeometryData2D.new());
$NavigationRegion2D.navigation_polygon = new_navigation_mesh
[/gdscript]
[csharp]
var newNavigationMesh = new NavigationPolygon();
Vector2[] boundingOutline = [new Vector2(0, 0), new Vector2(0, 50), new Vector2(50, 50), new Vector2(50, 0)];
newNavigationMesh.AddOutline(boundingOutline);
NavigationServer2D.BakeFromSourceGeometryData(newNavigationMesh, new NavigationMeshSourceGeometryData2D());
GetNode<NavigationRegion2D>("NavigationRegion2D").NavigationPolygon = newNavigationMesh;
[/csharp]
[/codeblocks]
Adding vertices and polygon indices manually.
[codeblocks]
[gdscript]
var new_navigation_mesh = NavigationPolygon.new()
var new_vertices = PackedVector2Array([Vector2(0, 0), Vector2(0, 50), Vector2(50, 50), Vector2(50, 0)])
new_navigation_mesh.vertices = new_vertices
var new_polygon_indices = PackedInt32Array([0, 1, 2, 3])
new_navigation_mesh.add_polygon(new_polygon_indices)
$NavigationRegion2D.navigation_polygon = new_navigation_mesh
[/gdscript]
[csharp]
var newNavigationMesh = new NavigationPolygon();
Vector2[] newVertices = [new Vector2(0, 0), new Vector2(0, 50), new Vector2(50, 50), new Vector2(50, 0)];
newNavigationMesh.Vertices = newVertices;
int[] newPolygonIndices = [0, 1, 2, 3];
newNavigationMesh.AddPolygon(newPolygonIndices);
GetNode<NavigationRegion2D>("NavigationRegion2D").NavigationPolygon = newNavigationMesh;
[/csharp]
[/codeblocks]

## SAMPLE_PARTITION_CONVEX_PARTITION :: const NavigationPolygon.SAMPLE_PARTITION_CONVEX_PARTITION: SamplePartitionType = 0
Convex partitioning that results in a navigation mesh with convex polygons.

## SAMPLE_PARTITION_TRIANGULATE :: const NavigationPolygon.SAMPLE_PARTITION_TRIANGULATE: SamplePartitionType = 1
Triangulation partitioning that results in a navigation mesh with triangle polygons.

## SAMPLE_PARTITION_MAX :: const NavigationPolygon.SAMPLE_PARTITION_MAX: SamplePartitionType = 2
Represents the size of the [enum SamplePartitionType] enum.

## PARSED_GEOMETRY_MESH_INSTANCES :: const NavigationPolygon.PARSED_GEOMETRY_MESH_INSTANCES: ParsedGeometryType = 0
Parses mesh instances as obstruction geometry. This includes [Polygon2D], [MeshInstance2D], [MultiMeshInstance2D], and [TileMap] nodes.
Meshes are only parsed when they use a 2D vertices surface format.

## PARSED_GEOMETRY_STATIC_COLLIDERS :: const NavigationPolygon.PARSED_GEOMETRY_STATIC_COLLIDERS: ParsedGeometryType = 1
Parses [StaticBody2D] and [TileMap] colliders as obstruction geometry. The collider should be in any of the layers specified by [member parsed_collision_mask].

## PARSED_GEOMETRY_BOTH :: const NavigationPolygon.PARSED_GEOMETRY_BOTH: ParsedGeometryType = 2
Both [constant PARSED_GEOMETRY_MESH_INSTANCES] and [constant PARSED_GEOMETRY_STATIC_COLLIDERS].

## PARSED_GEOMETRY_MAX :: const NavigationPolygon.PARSED_GEOMETRY_MAX: ParsedGeometryType = 3
Represents the size of the [enum ParsedGeometryType] enum.

## SOURCE_GEOMETRY_ROOT_NODE_CHILDREN :: const NavigationPolygon.SOURCE_GEOMETRY_ROOT_NODE_CHILDREN: SourceGeometryMode = 0
Scans the child nodes of the root node recursively for geometry.

## SOURCE_GEOMETRY_GROUPS_WITH_CHILDREN :: const NavigationPolygon.SOURCE_GEOMETRY_GROUPS_WITH_CHILDREN: SourceGeometryMode = 1
Scans nodes in a group and their child nodes recursively for geometry. The group is specified by [member source_geometry_group_name].

## SOURCE_GEOMETRY_GROUPS_EXPLICIT :: const NavigationPolygon.SOURCE_GEOMETRY_GROUPS_EXPLICIT: SourceGeometryMode = 2
Uses nodes in a group for geometry. The group is specified by [member source_geometry_group_name].

## SOURCE_GEOMETRY_MAX :: const NavigationPolygon.SOURCE_GEOMETRY_MAX: SourceGeometryMode = 3
Represents the size of the [enum SourceGeometryMode] enum.

## agent_radius :: var NavigationPolygon.agent_radius: float
The distance to erode/shrink the walkable surface when baking the navigation mesh.
[b]Note:[/b] The radius must be equal or higher than [code]0.0[/code]. If the radius is [code]0.0[/code], it won't be possible to fix invalid outline overlaps and other precision errors during the baking process. As a result, some obstacles may be excluded incorrectly from the final navigation mesh, or may delete the navigation mesh's polygons.

## baking_rect :: var NavigationPolygon.baking_rect: Rect2
If the baking [Rect2] has an area the navigation mesh baking will be restricted to its enclosing area.

## baking_rect_offset :: var NavigationPolygon.baking_rect_offset: Vector2
The position offset applied to the [member baking_rect] [Rect2].

## border_size :: var NavigationPolygon.border_size: float
The size of the non-navigable border around the bake bounding area defined by the [member baking_rect] [Rect2].
In conjunction with the [member baking_rect] the border size can be used to bake tile aligned navigation meshes without the tile edges being shrunk by [member agent_radius].

## cell_size :: var NavigationPolygon.cell_size: float
The cell size used to rasterize the navigation mesh vertices. Must match with the cell size on the navigation map.

## parsed_collision_mask :: var NavigationPolygon.parsed_collision_mask: int
The physics layers to scan for static colliders.
Only used when [member parsed_geometry_type] is [constant PARSED_GEOMETRY_STATIC_COLLIDERS] or [constant PARSED_GEOMETRY_BOTH].

## parsed_geometry_type :: var NavigationPolygon.parsed_geometry_type: NavigationPolygon.ParsedGeometryType
Determines which type of nodes will be parsed as geometry.

## sample_partition_type :: var NavigationPolygon.sample_partition_type: NavigationPolygon.SamplePartitionType
Partitioning algorithm for creating the navigation mesh polys.

## source_geometry_group_name :: var NavigationPolygon.source_geometry_group_name: StringName
The group name of nodes that should be parsed for baking source geometry.
Only used when [member source_geometry_mode] is [constant SOURCE_GEOMETRY_GROUPS_WITH_CHILDREN] or [constant SOURCE_GEOMETRY_GROUPS_EXPLICIT].

## source_geometry_mode :: var NavigationPolygon.source_geometry_mode: NavigationPolygon.SourceGeometryMode
The source of the geometry used when baking.

## add_outline :: func NavigationPolygon.add_outline(outline: PackedVector2Array) -> void
Appends a [PackedVector2Array] that contains the vertices of an outline to the internal array that contains all the outlines.

### outline :: PackedVector2Array

## add_outline_at_index :: func NavigationPolygon.add_outline_at_index(outline: PackedVector2Array, index: int) -> void
Adds a [PackedVector2Array] that contains the vertices of an outline to the internal array that contains all the outlines at a fixed position.

### outline :: PackedVector2Array

### index :: int

## add_polygon :: func NavigationPolygon.add_polygon(polygon: PackedInt32Array) -> void
Adds a polygon using the indices of the vertices you get when calling [method get_vertices].

### polygon :: PackedInt32Array

## clear :: func NavigationPolygon.clear() -> void
Clears the internal arrays for vertices and polygon indices.

## clear_outlines :: func NavigationPolygon.clear_outlines() -> void
Clears the array of the outlines, but it doesn't clear the vertices and the polygons that were created by them.

## clear_polygons :: func NavigationPolygon.clear_polygons() -> void
Clears the array of polygons, but it doesn't clear the array of outlines and vertices.

## get_navigation_mesh :: func NavigationPolygon.get_navigation_mesh() -> NavigationMesh
Returns the [NavigationMesh] resulting from this navigation polygon. This navigation mesh can be used to update the navigation mesh of a region with the [method NavigationServer3D.region_set_navigation_mesh] API directly.

## get_outline :: func NavigationPolygon.get_outline(idx: int) -> PackedVector2Array
Returns a [PackedVector2Array] containing the vertices of an outline that was created in the editor or by script.

### idx :: int

## get_outline_count :: func NavigationPolygon.get_outline_count() -> int
Returns the number of outlines that were created in the editor or by script.

## get_parsed_collision_mask_value :: func NavigationPolygon.get_parsed_collision_mask_value(layer_number: int) -> bool
Returns whether or not the specified layer of the [member parsed_collision_mask] is enabled, given a [param layer_number] between 1 and 32.

### layer_number :: int

## get_polygon :: func NavigationPolygon.get_polygon(idx: int) -> PackedInt32Array
Returns a [PackedInt32Array] containing the indices of the vertices of a created polygon.

### idx :: int

## get_polygon_count :: func NavigationPolygon.get_polygon_count() -> int
Returns the count of all polygons.

## get_vertices :: func NavigationPolygon.get_vertices() -> PackedVector2Array
Returns a [PackedVector2Array] containing all the vertices being used to create the polygons.

## make_polygons_from_outlines :: func NavigationPolygon.make_polygons_from_outlines() -> void
Creates polygons from the outlines added in the editor or by script.

## remove_outline :: func NavigationPolygon.remove_outline(idx: int) -> void
Removes an outline created in the editor or by script. You have to call [method make_polygons_from_outlines] for the polygons to update.

### idx :: int

## set_outline :: func NavigationPolygon.set_outline(idx: int, outline: PackedVector2Array) -> void
Changes an outline created in the editor or by script. You have to call [method make_polygons_from_outlines] for the polygons to update.

### idx :: int

### outline :: PackedVector2Array

## set_parsed_collision_mask_value :: func NavigationPolygon.set_parsed_collision_mask_value(layer_number: int, value: bool) -> void
Based on [param value], enables or disables the specified layer in the [member parsed_collision_mask], given a [param layer_number] between 1 and 32.

### layer_number :: int

### value :: bool

## set_vertices :: func NavigationPolygon.set_vertices(vertices: PackedVector2Array) -> void
Sets the vertices that can be then indexed to create polygons with the [method add_polygon] method.

### vertices :: PackedVector2Array
