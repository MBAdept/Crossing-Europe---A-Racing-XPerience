# VisualShaderNodeVec2Parameter :: <Native> class VisualShaderNodeVec2Parameter extends VisualShaderNodeParameter
A [Vector2] parameter to be used within the visual shader graph.
Translated to [code]uniform vec2[/code] in the shader language.

## default_value :: var VisualShaderNodeVec2Parameter.default_value: Vector2
A default value to be assigned within the shader.

## default_value_enabled :: var VisualShaderNodeVec2Parameter.default_value_enabled: bool
Enables usage of the [member default_value].
