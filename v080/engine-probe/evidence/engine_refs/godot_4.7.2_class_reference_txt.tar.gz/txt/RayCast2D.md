# RayCast2D :: <Native> class RayCast2D extends Node2D
A ray in 2D space, used to find the first collision object it intersects.
A raycast represents a ray from its origin to its [member target_position] that finds the closest object along its path, if it intersects any.
[RayCast2D] can ignore some objects by adding them to an exception list, by making its detection reporting ignore [Area2D]s ([member collide_with_areas]) or [PhysicsBody2D]s ([member collide_with_bodies]), or by configuring physics layers.
[RayCast2D] calculates intersection every physics frame, and it holds the result until the next physics frame. For an immediate raycast, or if you want to configure a [RayCast2D] multiple times within the same physics frame, use [method force_raycast_update].
To sweep over a region of 2D space, you can approximate the region with multiple [RayCast2D]s or use [ShapeCast2D].

## collide_with_areas :: var RayCast2D.collide_with_areas: bool
If [code]true[/code], collisions with [Area2D]s will be reported.

## collide_with_bodies :: var RayCast2D.collide_with_bodies: bool
If [code]true[/code], collisions with [PhysicsBody2D]s will be reported.

## collision_mask :: var RayCast2D.collision_mask: int
The ray's collision mask. Only objects in at least one collision layer enabled in the mask will be detected. See [url=https://docs.godotengine.org/en/4.7/tutorials/physics/physics_introduction.html#collision-layers-and-masks]Collision layers and masks[/url] in the documentation for more information.

## enabled :: var RayCast2D.enabled: bool
If [code]true[/code], collisions will be reported.

## exclude_parent :: var RayCast2D.exclude_parent: bool
If [code]true[/code], this raycast will not report collisions with its parent node. This property only has an effect if the parent node is a [CollisionObject2D]. See also [method Node.get_parent] and [method add_exception].

## hit_from_inside :: var RayCast2D.hit_from_inside: bool
If [code]true[/code], the ray will detect a hit when starting inside shapes. In this case the collision normal will be [code]Vector2(0, 0)[/code]. Does not affect concave polygon shapes.

## target_position :: var RayCast2D.target_position: Vector2
The ray's destination point, relative to this raycast's [member Node2D.position].

## add_exception :: func RayCast2D.add_exception(node: CollisionObject2D) -> void
Adds a collision exception so the ray does not report collisions with the specified [param node].

### node :: CollisionObject2D

## add_exception_rid :: func RayCast2D.add_exception_rid(rid: RID) -> void
Adds a collision exception so the ray does not report collisions with the specified [RID].

### rid :: RID

## clear_exceptions :: func RayCast2D.clear_exceptions() -> void
Removes all collision exceptions for this ray.

## force_raycast_update :: func RayCast2D.force_raycast_update() -> void
Updates the collision information for the ray immediately, without waiting for the next [code]_physics_process[/code] call. Use this method, for example, when the ray or its parent has changed state.
[b]Note:[/b] [member enabled] does not need to be [code]true[/code] for this to work.

## get_collider :: func RayCast2D.get_collider() -> Object
Returns the first object that the ray intersects, or [code]null[/code] if no object is intersecting the ray (i.e. [method is_colliding] returns [code]false[/code]).
[b]Note:[/b] This object is not guaranteed to be a [CollisionObject2D]. For example, if the ray intersects a [TileMapLayer], the method will return a [TileMapLayer] instance.

## get_collider_rid :: func RayCast2D.get_collider_rid() -> RID
Returns the [RID] of the first object that the ray intersects, or an empty [RID] if no object is intersecting the ray (i.e. [method is_colliding] returns [code]false[/code]).

## get_collider_shape :: func RayCast2D.get_collider_shape() -> int
Returns the shape ID of the first object that the ray intersects, or [code]0[/code] if no object is intersecting the ray (i.e. [method is_colliding] returns [code]false[/code]).
To get the intersected shape node, for a [CollisionObject2D] target, use:
[codeblocks]
[gdscript]
var target = get_collider() # A CollisionObject2D.
var shape_id = get_collider_shape() # The shape index in the collider.
var owner_id = target.shape_find_owner(shape_id) # The owner ID in the collider.
var shape = target.shape_owner_get_owner(owner_id)
[/gdscript]
[csharp]
var target = (CollisionObject2D)GetCollider(); // A CollisionObject2D.
var shapeId = GetColliderShape(); // The shape index in the collider.
var ownerId = target.ShapeFindOwner(shapeId); // The owner ID in the collider.
var shape = target.ShapeOwnerGetOwner(ownerId);
[/csharp]
[/codeblocks]

## get_collision_mask_value :: func RayCast2D.get_collision_mask_value(layer_number: int) -> bool
Returns whether or not the specified layer of the [member collision_mask] is enabled, given a [param layer_number] between 1 and 32.

### layer_number :: int

## get_collision_normal :: func RayCast2D.get_collision_normal() -> Vector2
Returns the normal of the intersecting object's shape at the collision point, or [code]Vector2(0, 0)[/code] if the ray starts inside the shape and [member hit_from_inside] is [code]true[/code].
[b]Note:[/b] Check that [method is_colliding] returns [code]true[/code] before calling this method to ensure the returned normal is valid and up-to-date.

## get_collision_point :: func RayCast2D.get_collision_point() -> Vector2
Returns the collision point at which the ray intersects the closest object, in the global coordinate system. If [member hit_from_inside] is [code]true[/code] and the ray starts inside of a collision shape, this function will return the origin point of the ray.
[b]Note:[/b] Check that [method is_colliding] returns [code]true[/code] before calling this method to ensure the returned point is valid and up-to-date.

## is_colliding :: func RayCast2D.is_colliding() -> bool
Returns whether any object is intersecting with the ray's vector (considering the vector length).

## remove_exception :: func RayCast2D.remove_exception(node: CollisionObject2D) -> void
Removes a collision exception so the ray can report collisions with the specified [param node].

### node :: CollisionObject2D

## remove_exception_rid :: func RayCast2D.remove_exception_rid(rid: RID) -> void
Removes a collision exception so the ray can report collisions with the specified [RID].

### rid :: RID

## set_collision_mask_value :: func RayCast2D.set_collision_mask_value(layer_number: int, value: bool) -> void
Based on [param value], enables or disables the specified layer in the [member collision_mask], given a [param layer_number] between 1 and 32.

### layer_number :: int

### value :: bool
