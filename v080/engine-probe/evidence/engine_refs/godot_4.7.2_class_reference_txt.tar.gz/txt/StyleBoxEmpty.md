# StyleBoxEmpty :: <Native> class StyleBoxEmpty extends StyleBox
An empty [StyleBox] (does not display anything).
An empty [StyleBox] that can be used to display nothing instead of the default style (e.g. it can "disable" [code]focus[/code] styles).
