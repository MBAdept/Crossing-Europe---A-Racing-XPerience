# OggPacketSequence :: <Native> class OggPacketSequence extends Resource
A sequence of Ogg packets.
A sequence of Ogg packets.

## granule_positions :: var OggPacketSequence.granule_positions: PackedInt64Array
Contains the granule positions for each page in this packet sequence.

## packet_data :: var OggPacketSequence.packet_data: Array[]
Contains the raw packets that make up this OggPacketSequence.

## sampling_rate :: var OggPacketSequence.sampling_rate: float
Holds sample rate information about this sequence. Must be set by another class that actually understands the codec.

## get_length :: func OggPacketSequence.get_length() -> float
The length of this stream, in seconds.
