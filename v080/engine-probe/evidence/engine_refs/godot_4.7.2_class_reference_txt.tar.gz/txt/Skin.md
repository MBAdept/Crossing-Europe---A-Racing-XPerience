# Skin :: <Native> class Skin extends Resource


## add_bind :: func Skin.add_bind(bone: int, pose: Transform3D) -> void

### bone :: int

### pose :: Transform3D

## add_named_bind :: func Skin.add_named_bind(name: String, pose: Transform3D) -> void

### name :: String

### pose :: Transform3D

## clear_binds :: func Skin.clear_binds() -> void

## get_bind_bone :: func Skin.get_bind_bone(bind_index: int) -> int

### bind_index :: int

## get_bind_count :: func Skin.get_bind_count() -> int

## get_bind_name :: func Skin.get_bind_name(bind_index: int) -> StringName

### bind_index :: int

## get_bind_pose :: func Skin.get_bind_pose(bind_index: int) -> Transform3D

### bind_index :: int

## set_bind_bone :: func Skin.set_bind_bone(bind_index: int, bone: int) -> void

### bind_index :: int

### bone :: int

## set_bind_count :: func Skin.set_bind_count(bind_count: int) -> void

### bind_count :: int

## set_bind_name :: func Skin.set_bind_name(bind_index: int, name: StringName) -> void

### bind_index :: int

### name :: StringName

## set_bind_pose :: func Skin.set_bind_pose(bind_index: int, pose: Transform3D) -> void

### bind_index :: int

### pose :: Transform3D
