# SphereOccluder3D :: <Native> class SphereOccluder3D extends Occluder3D
Spherical shape for use with occlusion culling in [OccluderInstance3D].
[SphereOccluder3D] stores a sphere shape that can be used by the engine's occlusion culling system.
See [OccluderInstance3D]'s documentation for instructions on setting up occlusion culling.

## radius :: var SphereOccluder3D.radius: float
The sphere's radius in 3D units.
