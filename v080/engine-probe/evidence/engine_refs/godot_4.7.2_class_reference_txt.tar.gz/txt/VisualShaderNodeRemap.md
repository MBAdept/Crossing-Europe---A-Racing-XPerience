# VisualShaderNodeRemap :: <Native> class VisualShaderNodeRemap extends VisualShaderNode
A visual shader node for remap function.
Remap will transform the input range into output range, e.g. you can change a [code]0..1[/code] value to [code]-2..2[/code] etc. See [method @GlobalScope.remap] for more details.

## OP_TYPE_SCALAR :: const VisualShaderNodeRemap.OP_TYPE_SCALAR: OpType = 0
A floating-point scalar type.

## OP_TYPE_VECTOR_2D :: const VisualShaderNodeRemap.OP_TYPE_VECTOR_2D: OpType = 1
A 2D vector type.

## OP_TYPE_VECTOR_2D_SCALAR :: const VisualShaderNodeRemap.OP_TYPE_VECTOR_2D_SCALAR: OpType = 2
The [code]value[/code] port uses a 2D vector type, while the [code]input min[/code], [code]input max[/code], [code]output min[/code], and [code]output max[/code] ports use a floating-point scalar type.

## OP_TYPE_VECTOR_3D :: const VisualShaderNodeRemap.OP_TYPE_VECTOR_3D: OpType = 3
A 3D vector type.

## OP_TYPE_VECTOR_3D_SCALAR :: const VisualShaderNodeRemap.OP_TYPE_VECTOR_3D_SCALAR: OpType = 4
The [code]value[/code] port uses a 3D vector type, while the [code]input min[/code], [code]input max[/code], [code]output min[/code], and [code]output max[/code] ports use a floating-point scalar type.

## OP_TYPE_VECTOR_4D :: const VisualShaderNodeRemap.OP_TYPE_VECTOR_4D: OpType = 5
A 4D vector type.

## OP_TYPE_VECTOR_4D_SCALAR :: const VisualShaderNodeRemap.OP_TYPE_VECTOR_4D_SCALAR: OpType = 6
The [code]value[/code] port uses a 4D vector type, while the [code]input min[/code], [code]input max[/code], [code]output min[/code], and [code]output max[/code] ports use a floating-point scalar type.

## OP_TYPE_MAX :: const VisualShaderNodeRemap.OP_TYPE_MAX: OpType = 7
Represents the size of the [enum OpType] enum.

## op_type :: var VisualShaderNodeRemap.op_type: VisualShaderNodeRemap.OpType
