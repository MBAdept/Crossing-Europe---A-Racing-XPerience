# ItemList :: <Native> class ItemList extends Control
A vertical list of selectable items with one or multiple columns.
This control provides a vertical list of selectable items that may be in a single or in multiple columns, with each item having options for text and an icon. Tooltips are supported and may be different for every item in the list.
Selectable items in the list may be selected or deselected and multiple selection may be enabled. Selection with right mouse button may also be enabled to allow use of popup context menus. Items may also be "activated" by double-clicking them or by pressing [kbd]Enter[/kbd].
Item text only supports single-line strings. Newline characters (e.g. [code]\n[/code]) in the string won't produce a newline. Text wrapping is enabled in [constant ICON_MODE_TOP] mode, but the column's width is adjusted to fully fit its content by default. You need to set [member fixed_column_width] greater than zero to wrap the text.
All [code]set_*[/code] methods allow negative item indices, i.e. [code]-1[/code] to access the last item, [code]-2[/code] to select the second-to-last item, and so on.
[b]Incremental search:[/b] Like [PopupMenu] and [Tree], [ItemList] supports searching within the list while the control is focused. Press a key that matches the first letter of an item's name to select the first item starting with the given letter. After that point, there are two ways to perform incremental search: 1) Press the same key again before the timeout duration to select the next item starting with the same letter. 2) Press letter keys that match the rest of the word before the timeout duration to match to select the item in question directly. Both of these actions will be reset to the beginning of the list if the timeout duration has passed since the last keystroke was registered. You can adjust the timeout duration by changing [member ProjectSettings.gui/timers/incremental_search_max_interval_msec].

## ICON_MODE_TOP :: const ItemList.ICON_MODE_TOP: IconMode = 0
Icon is drawn above the text.

## ICON_MODE_LEFT :: const ItemList.ICON_MODE_LEFT: IconMode = 1
Icon is drawn to the left of the text.

## SELECT_SINGLE :: const ItemList.SELECT_SINGLE: SelectMode = 0
Only allow selecting a single item.

## SELECT_MULTI :: const ItemList.SELECT_MULTI: SelectMode = 1
Allows selecting multiple items by holding [kbd]Ctrl[/kbd] or [kbd]Shift[/kbd].

## SELECT_TOGGLE :: const ItemList.SELECT_TOGGLE: SelectMode = 2
Allows selecting multiple items by toggling them on and off.

## SCROLL_HINT_MODE_DISABLED :: const ItemList.SCROLL_HINT_MODE_DISABLED: ScrollHintMode = 0
Scroll hints will never be shown.

## SCROLL_HINT_MODE_BOTH :: const ItemList.SCROLL_HINT_MODE_BOTH: ScrollHintMode = 1
Scroll hints will be shown at the top and bottom.

## SCROLL_HINT_MODE_TOP :: const ItemList.SCROLL_HINT_MODE_TOP: ScrollHintMode = 2
Only the top scroll hint will be shown.

## SCROLL_HINT_MODE_BOTTOM :: const ItemList.SCROLL_HINT_MODE_BOTTOM: ScrollHintMode = 3
Only the bottom scroll hint will be shown.

## allow_reselect :: var ItemList.allow_reselect: bool
If [code]true[/code], the currently selected item can be selected again.

## allow_rmb_select :: var ItemList.allow_rmb_select: bool
If [code]true[/code], right mouse button click can select items.

## allow_search :: var ItemList.allow_search: bool
If [code]true[/code], allows navigating the [ItemList] with letter keys through incremental search.

## auto_height :: var ItemList.auto_height: bool
If [code]true[/code], the control will automatically resize the height to fit its content.

## auto_width :: var ItemList.auto_width: bool
If [code]true[/code], the control will automatically resize the width to fit its content.

## clip_contents :: var ItemList.clip_contents: bool

## fixed_column_width :: var ItemList.fixed_column_width: int
The width all columns will be adjusted to.
A value of zero disables the adjustment, each item will have a width equal to the width of its content and the columns will have an uneven width.

## fixed_icon_size :: var ItemList.fixed_icon_size: Vector2i
The size all icons will be adjusted to.
If either X or Y component is not greater than zero, icon size won't be affected.

## focus_mode :: var ItemList.focus_mode: Control.FocusMode

## icon_mode :: var ItemList.icon_mode: ItemList.IconMode
The icon position, whether above or to the left of the text. See the [enum IconMode] constants.

## icon_scale :: var ItemList.icon_scale: float
The scale of icon applied after [member fixed_icon_size] and transposing takes effect.

## item_count :: var ItemList.item_count: int
The number of items currently in the list.

## item_{index}/disabled :: var ItemList.item_{index}/disabled: bool
If [code]true[/code], the item at [code]index[/code] is disabled.
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. item_count - 1[/code] range.

## item_{index}/icon :: var ItemList.item_{index}/icon: Texture2D
The icon of the item at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. item_count - 1[/code] range.

## item_{index}/selectable :: var ItemList.item_{index}/selectable: bool
If [code]true[/code], the item at [code]index[/code] is selectable.
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. item_count - 1[/code] range.

## item_{index}/text :: var ItemList.item_{index}/text: String
The text of the item at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. item_count - 1[/code] range.

## max_columns :: var ItemList.max_columns: int
Maximum columns the list will have.
If greater than zero, the content will be split among the specified columns.
A value of zero means unlimited columns, i.e. all items will be put in the same row.

## max_text_lines :: var ItemList.max_text_lines: int
Maximum lines of text allowed in each item. Space will be reserved even when there is not enough lines of text to display.
[b]Note:[/b] This property takes effect only when [member icon_mode] is [constant ICON_MODE_TOP]. To make the text wrap, [member fixed_column_width] should be greater than zero.

## same_column_width :: var ItemList.same_column_width: bool
Whether all columns will have the same width.
If [code]true[/code], the width is equal to the largest column width of all columns.

## scroll_hint_mode :: var ItemList.scroll_hint_mode: ItemList.ScrollHintMode
The way which scroll hints (indicators that show that the content can still be scrolled in a certain direction) will be shown.

## select_mode :: var ItemList.select_mode: ItemList.SelectMode
Allows single or multiple item selection. See the [enum SelectMode] constants.

## text_overrun_behavior :: var ItemList.text_overrun_behavior: TextServer.OverrunBehavior
The clipping behavior when the text exceeds an item's bounding rectangle.

## tile_scroll_hint :: var ItemList.tile_scroll_hint: bool
If [code]true[/code], the scroll hint texture will be tiled instead of stretched. See [member scroll_hint_mode].

## wraparound_items :: var ItemList.wraparound_items: bool
If [code]true[/code], the control will automatically move items into a new row to fit its content. See also [HFlowContainer] for this behavior.
If [code]false[/code], the control will add a horizontal scrollbar to make all items visible.

## font_color :: <Theme> var ItemList.font_color: Color
Default text [Color] of the item.

## font_hovered_color :: <Theme> var ItemList.font_hovered_color: Color
Text [Color] used when the item is hovered and not selected yet.

## font_hovered_selected_color :: <Theme> var ItemList.font_hovered_selected_color: Color
Text [Color] used when the item is hovered and selected.

## font_outline_color :: <Theme> var ItemList.font_outline_color: Color
The tint of text outline of the item.

## font_selected_color :: <Theme> var ItemList.font_selected_color: Color
Text [Color] used when the item is selected, but not hovered.

## guide_color :: <Theme> var ItemList.guide_color: Color
[Color] of the guideline. The guideline is a line drawn between each row of items.

## scroll_hint_color :: <Theme> var ItemList.scroll_hint_color: Color
[Color] used to modulate the [theme_item scroll_hint] texture.

## h_separation :: <Theme> var ItemList.h_separation: int
The horizontal spacing between items.

## icon_margin :: <Theme> var ItemList.icon_margin: int
The spacing between item's icon and text.

## line_separation :: <Theme> var ItemList.line_separation: int
The vertical spacing between each line of text.

## outline_size :: <Theme> var ItemList.outline_size: int
The size of the item text outline.
[b]Note:[/b] If using a font with [member FontFile.multichannel_signed_distance_field] enabled, its [member FontFile.msdf_pixel_range] must be set to at least [i]twice[/i] the value of [theme_item outline_size] for outline rendering to look correct. Otherwise, the outline may appear to be cut off earlier than intended.

## v_separation :: <Theme> var ItemList.v_separation: int
The vertical spacing between items.

## font :: <Theme> var ItemList.font: Font
[Font] of the item's text.

## font_size :: <Theme> var ItemList.font_size: int
Font size of the item's text.

## scroll_hint :: <Theme> var ItemList.scroll_hint: Texture2D
The indicator that will be shown when the content can still be scrolled. See [member scroll_hint_mode].

## cursor :: <Theme> var ItemList.cursor: StyleBox
[StyleBox] used for the cursor, when the [ItemList] is being focused.

## cursor_unfocused :: <Theme> var ItemList.cursor_unfocused: StyleBox
[StyleBox] used for the cursor, when the [ItemList] is not being focused.

## focus :: <Theme> var ItemList.focus: StyleBox
The focused style for the [ItemList], drawn on top of everything.

## hovered :: <Theme> var ItemList.hovered: StyleBox
[StyleBox] for the hovered, but not selected items.

## hovered_selected :: <Theme> var ItemList.hovered_selected: StyleBox
[StyleBox] for the hovered and selected items, used when the [ItemList] is not being focused.

## hovered_selected_focus :: <Theme> var ItemList.hovered_selected_focus: StyleBox
[StyleBox] for the hovered and selected items, used when the [ItemList] is being focused.

## panel :: <Theme> var ItemList.panel: StyleBox
The background style for the [ItemList].

## selected :: <Theme> var ItemList.selected: StyleBox
[StyleBox] for the selected items, used when the [ItemList] is not being focused.

## selected_focus :: <Theme> var ItemList.selected_focus: StyleBox
[StyleBox] for the selected items, used when the [ItemList] is being focused.

## add_icon_item :: func ItemList.add_icon_item(icon: Texture2D, selectable: bool = true) -> int
Adds an item to the item list with no text, only an icon. Returns the index of an added item.

### icon :: Texture2D

### selectable :: bool

## add_item :: func ItemList.add_item(text: String, icon: Texture2D = null, selectable: bool = true) -> int
Adds an item to the item list with specified text. Returns the index of an added item.
Specify an [param icon], or use [code]null[/code] as the [param icon] for a list item with no icon.
If [param selectable] is [code]true[/code], the list item will be selectable.

### text :: String

### icon :: Texture2D

### selectable :: bool

## center_on_current :: func ItemList.center_on_current(center_verically: bool = true, center_horizontally: bool = true) -> void
Ensures the currently selected item (the first selected item if multiple selection is enabled) is visible, adjusting the scroll position as necessary to place the item at the center of the list if possible. See also [method ensure_current_is_visible].
Fails and prints an error if both arguments are [code]false[/code].

### center_verically :: bool

### center_horizontally :: bool

## clear :: func ItemList.clear() -> void
Removes all items from the list.

## deselect :: func ItemList.deselect(idx: int) -> void
Ensures the item associated with the specified index is not selected.

### idx :: int

## deselect_all :: func ItemList.deselect_all() -> void
Ensures there are no items selected.

## ensure_current_is_visible :: func ItemList.ensure_current_is_visible() -> void
Ensures the currently selected item (the first selected item if multiple selection is enabled) is visible, adjusting the scroll position as necessary. See also [method center_on_current].

## force_update_list_size :: func ItemList.force_update_list_size() -> void
Forces an update to the list size based on its items. This happens automatically whenever size of the items, or other relevant settings like [member auto_height], change. The method can be used to trigger the update ahead of next drawing pass.

## get_h_scroll_bar :: func ItemList.get_h_scroll_bar() -> HScrollBar
Returns the horizontal scrollbar.
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member CanvasItem.visible] property.

## get_item_at_position :: func ItemList.get_item_at_position(position: Vector2, exact: bool = false) -> int
Returns the item index at the given [param position].
When there is no item at that point, -1 will be returned if [param exact] is [code]true[/code], and the closest item index will be returned otherwise.
[b]Note:[/b] The returned value is unreliable if called right after modifying the [ItemList], before it redraws in the next frame.

### position :: Vector2

### exact :: bool

## get_item_auto_translate_mode :: func ItemList.get_item_auto_translate_mode(idx: int) -> int
Returns item's auto translate mode.

### idx :: int

## get_item_custom_bg_color :: func ItemList.get_item_custom_bg_color(idx: int) -> Color
Returns the custom background color of the item specified by [param idx] index.

### idx :: int

## get_item_custom_fg_color :: func ItemList.get_item_custom_fg_color(idx: int) -> Color
Returns the custom foreground color of the item specified by [param idx] index.

### idx :: int

## get_item_icon :: func ItemList.get_item_icon(idx: int) -> Texture2D
Returns the icon associated with the specified index.

### idx :: int

## get_item_icon_modulate :: func ItemList.get_item_icon_modulate(idx: int) -> Color
Returns a [Color] modulating item's icon at the specified index.

### idx :: int

## get_item_icon_region :: func ItemList.get_item_icon_region(idx: int) -> Rect2
Returns the region of item's icon used. The whole icon will be used if the region has no area.

### idx :: int

## get_item_language :: func ItemList.get_item_language(idx: int) -> String
Returns item's text language code.

### idx :: int

## get_item_metadata :: func ItemList.get_item_metadata(idx: int) -> Variant
Returns the metadata value of the specified index.

### idx :: int

## get_item_rect :: func ItemList.get_item_rect(idx: int, expand: bool = true) -> Rect2
Returns the position and size of the item with the specified index, in the coordinate system of the [ItemList] node. If [param expand] is [code]true[/code] the last column expands to fill the rest of the row.
[b]Note:[/b] The returned value is unreliable if called right after modifying the [ItemList], before it redraws in the next frame.

### idx :: int

### expand :: bool

## get_item_text :: func ItemList.get_item_text(idx: int) -> String
Returns the text associated with the specified index.

### idx :: int

## get_item_text_direction :: func ItemList.get_item_text_direction(idx: int) -> int
Returns item's text base writing direction.

### idx :: int

## get_item_tooltip :: func ItemList.get_item_tooltip(idx: int) -> String
Returns the tooltip hint associated with the specified index.

### idx :: int

## get_selected_items :: func ItemList.get_selected_items() -> PackedInt32Array
Returns an array with the indexes of the selected items.

## get_v_scroll_bar :: func ItemList.get_v_scroll_bar() -> VScrollBar
Returns the vertical scrollbar.
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member CanvasItem.visible] property.

## is_anything_selected :: func ItemList.is_anything_selected() -> bool
Returns [code]true[/code] if one or more items are selected.

## is_item_disabled :: func ItemList.is_item_disabled(idx: int) -> bool
Returns [code]true[/code] if the item at the specified index is disabled.

### idx :: int

## is_item_icon_transposed :: func ItemList.is_item_icon_transposed(idx: int) -> bool
Returns [code]true[/code] if the item icon will be drawn transposed, i.e. the X and Y axes are swapped.

### idx :: int

## is_item_selectable :: func ItemList.is_item_selectable(idx: int) -> bool
Returns [code]true[/code] if the item at the specified index is selectable.

### idx :: int

## is_item_tooltip_enabled :: func ItemList.is_item_tooltip_enabled(idx: int) -> bool
Returns [code]true[/code] if the tooltip is enabled for specified item index.

### idx :: int

## is_selected :: func ItemList.is_selected(idx: int) -> bool
Returns [code]true[/code] if the item at the specified index is currently selected.

### idx :: int

## move_item :: func ItemList.move_item(from_idx: int, to_idx: int) -> void
Moves item from index [param from_idx] to [param to_idx].

### from_idx :: int

### to_idx :: int

## remove_item :: func ItemList.remove_item(idx: int) -> void
Removes the item specified by [param idx] index from the list.

### idx :: int

## select :: func ItemList.select(idx: int, single: bool = true) -> void
Selects the item at the specified index.
[b]Note:[/b] This method does not trigger the item selection signal.

### idx :: int

### single :: bool

## set_item_auto_translate_mode :: func ItemList.set_item_auto_translate_mode(idx: int, mode: int) -> void
Sets the auto translate mode of the item associated with the specified index.
Items use [constant Node.AUTO_TRANSLATE_MODE_INHERIT] by default, which uses the same auto translate mode as the [ItemList] itself.

### idx :: int

### mode :: int

## set_item_custom_bg_color :: func ItemList.set_item_custom_bg_color(idx: int, custom_bg_color: Color) -> void
Sets the background color of the item specified by [param idx] index to the specified [Color].

### idx :: int

### custom_bg_color :: Color

## set_item_custom_fg_color :: func ItemList.set_item_custom_fg_color(idx: int, custom_fg_color: Color) -> void
Sets the foreground color of the item specified by [param idx] index to the specified [Color].

### idx :: int

### custom_fg_color :: Color

## set_item_disabled :: func ItemList.set_item_disabled(idx: int, disabled: bool) -> void
Disables (or enables) the item at the specified index.
Disabled items cannot be selected and do not trigger activation signals (when double-clicking or pressing [kbd]Enter[/kbd]).

### idx :: int

### disabled :: bool

## set_item_icon :: func ItemList.set_item_icon(idx: int, icon: Texture2D) -> void
Sets (or replaces) the icon's [Texture2D] associated with the specified index.

### idx :: int

### icon :: Texture2D

## set_item_icon_modulate :: func ItemList.set_item_icon_modulate(idx: int, modulate: Color) -> void
Sets a modulating [Color] of the item associated with the specified index.

### idx :: int

### modulate :: Color

## set_item_icon_region :: func ItemList.set_item_icon_region(idx: int, rect: Rect2) -> void
Sets the region of item's icon used. The whole icon will be used if the region has no area.

### idx :: int

### rect :: Rect2

## set_item_icon_transposed :: func ItemList.set_item_icon_transposed(idx: int, transposed: bool) -> void
Sets whether the item icon will be drawn transposed.

### idx :: int

### transposed :: bool

## set_item_language :: func ItemList.set_item_language(idx: int, language: String) -> void
Sets the language code of the text for the item at the given index to [param language]. This is used for line-breaking and text shaping algorithms. If [param language] is empty, the current locale is used.

### idx :: int

### language :: String

## set_item_metadata :: func ItemList.set_item_metadata(idx: int, metadata: Variant) -> void
Sets a value (of any type) to be stored with the item associated with the specified index.

### idx :: int

### metadata :: Variant

## set_item_selectable :: func ItemList.set_item_selectable(idx: int, selectable: bool) -> void
Allows or disallows selection of the item associated with the specified index.

### idx :: int

### selectable :: bool

## set_item_text :: func ItemList.set_item_text(idx: int, text: String) -> void
Sets text of the item associated with the specified index.

### idx :: int

### text :: String

## set_item_text_direction :: func ItemList.set_item_text_direction(idx: int, direction: int) -> void
Sets item's text base writing direction.

### idx :: int

### direction :: int

## set_item_tooltip :: func ItemList.set_item_tooltip(idx: int, tooltip: String) -> void
Sets the tooltip hint for the item associated with the specified index.

### idx :: int

### tooltip :: String

## set_item_tooltip_enabled :: func ItemList.set_item_tooltip_enabled(idx: int, enable: bool) -> void
Sets whether the tooltip hint is enabled for specified item index.

### idx :: int

### enable :: bool

## sort_items_by_text :: func ItemList.sort_items_by_text() -> void
Sorts items in the list by their text.

## empty_clicked :: func ItemList.empty_clicked(at_position: Vector2, mouse_button_index: int) -> void
Emitted when any mouse click is issued within the rect of the list but on empty space.
[param at_position] is the click position in this control's local coordinate system.

### at_position :: Vector2

### mouse_button_index :: int

## item_activated :: func ItemList.item_activated(index: int) -> void
Emitted when specified list item is activated via double-clicking or by pressing [kbd]Enter[/kbd].

### index :: int

## item_clicked :: func ItemList.item_clicked(index: int, at_position: Vector2, mouse_button_index: int) -> void
Emitted when specified list item has been clicked with any mouse button.
[param at_position] is the click position in this control's local coordinate system.

### index :: int

### at_position :: Vector2

### mouse_button_index :: int

## item_selected :: func ItemList.item_selected(index: int) -> void
Emitted when specified item has been selected. Only applicable in single selection mode.
[member allow_reselect] must be enabled to reselect an item.

### index :: int

## multi_selected :: func ItemList.multi_selected(index: int, selected: bool) -> void
Emitted when a multiple selection is altered on a list allowing multiple selection.

### index :: int

### selected :: bool
