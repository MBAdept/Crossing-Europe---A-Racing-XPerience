# ShaderInclude :: <Native> class ShaderInclude extends Resource
A snippet of shader code to be included in a [Shader] with [code]#include[/code].
A shader include file, saved with the [code].gdshaderinc[/code] extension. This class allows you to define a custom shader snippet that can be included in a [Shader] by using the preprocessor directive [code]#include[/code], followed by the file path (e.g. [code]#include "res://shader_lib.gdshaderinc"[/code]). The snippet doesn't have to be a valid shader on its own.

## code :: var ShaderInclude.code: String
Returns the code of the shader include file. The returned text is what the user has written, not the full generated code used internally.
