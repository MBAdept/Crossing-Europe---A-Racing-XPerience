# VisualShaderNodeIs :: <Native> class VisualShaderNodeIs extends VisualShaderNode
A boolean comparison operator to be used within the visual shader graph.
Returns the boolean result of the comparison between [code]INF[/code] or [code]NaN[/code] and a scalar parameter.

## FUNC_IS_INF :: const VisualShaderNodeIs.FUNC_IS_INF: Function = 0
Comparison with [code]INF[/code] (Infinity).

## FUNC_IS_NAN :: const VisualShaderNodeIs.FUNC_IS_NAN: Function = 1
Comparison with [code]NaN[/code] (Not a Number; indicates invalid numeric results, such as division by zero).

## FUNC_MAX :: const VisualShaderNodeIs.FUNC_MAX: Function = 2
Represents the size of the [enum Function] enum.

## function :: var VisualShaderNodeIs.function: VisualShaderNodeIs.Function
The comparison function.
