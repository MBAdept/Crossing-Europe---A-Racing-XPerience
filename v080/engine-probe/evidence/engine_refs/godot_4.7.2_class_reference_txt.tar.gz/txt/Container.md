# Container :: <Native> class Container extends Control
Base class for all GUI containers.
Base class for all GUI containers. A [Container] automatically arranges its child controls in a certain way. This class can be inherited to make custom container types.

## NOTIFICATION_PRE_SORT_CHILDREN :: const Container.NOTIFICATION_PRE_SORT_CHILDREN = 50
Notification just before children are going to be sorted, in case there's something to process beforehand.

## NOTIFICATION_SORT_CHILDREN :: const Container.NOTIFICATION_SORT_CHILDREN = 51
Notification for when sorting the children, it must be obeyed immediately.

## accessibility_region :: var Container.accessibility_region: bool
If [code]true[/code], this container is marked as a region for accessibility. Use [member Control.accessibility_name] to give the region a descriptive name. Screen readers can navigate between regions using landmark navigation.

## mouse_filter :: var Container.mouse_filter: Control.MouseFilter

## propagate_maximum_size :: var Container.propagate_maximum_size: bool

## _get_allowed_size_flags_horizontal :: func Container._get_allowed_size_flags_horizontal() -> PackedInt32Array
Implement to return a list of allowed horizontal [enum Control.SizeFlags] for child nodes. This doesn't technically prevent the usages of any other size flags, if your implementation requires that. This only limits the options available to the user in the Inspector dock.
[b]Note:[/b] Having no size flags is equal to having [constant Control.SIZE_SHRINK_BEGIN]. As such, this value is always implicitly allowed.

## _get_allowed_size_flags_vertical :: func Container._get_allowed_size_flags_vertical() -> PackedInt32Array
Implement to return a list of allowed vertical [enum Control.SizeFlags] for child nodes. This doesn't technically prevent the usages of any other size flags, if your implementation requires that. This only limits the options available to the user in the Inspector dock.
[b]Note:[/b] Having no size flags is equal to having [constant Control.SIZE_SHRINK_BEGIN]. As such, this value is always implicitly allowed.

## fit_child_in_rect :: func Container.fit_child_in_rect(child: Control, rect: Rect2) -> void
Fit a child control in a given rect. This is mainly a helper for creating custom container classes.

### child :: Control

### rect :: Rect2

## queue_sort :: func Container.queue_sort() -> void
Queue resort of the contained children. This is called automatically anyway, but can be called upon request.

## pre_sort_children :: func Container.pre_sort_children() -> void
Emitted when children are going to be sorted.

## sort_children :: func Container.sort_children() -> void
Emitted when sorting the children is needed.
