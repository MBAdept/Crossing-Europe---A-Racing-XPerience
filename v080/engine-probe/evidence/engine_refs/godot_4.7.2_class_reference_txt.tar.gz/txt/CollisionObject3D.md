# CollisionObject3D :: <Native> class CollisionObject3D extends Node3D
Abstract base class for 3D physics objects.
Abstract base class for 3D physics objects. [CollisionObject3D] can hold any number of [Shape3D]s for collision. Each shape must be assigned to a [i]shape owner[/i]. Shape owners are not nodes and do not appear in the editor, but are accessible through code using the [code]shape_owner_*[/code] methods.
[b]Warning:[/b] With a non-uniform scale, this node will likely not behave as expected. It is advised to keep its scale the same on all axes and adjust its collision shape(s) instead.

## DISABLE_MODE_REMOVE :: const CollisionObject3D.DISABLE_MODE_REMOVE: DisableMode = 0
When [member Node.process_mode] is set to [constant Node.PROCESS_MODE_DISABLED], remove from the physics simulation to stop all physics interactions with this [CollisionObject3D].
Automatically re-added to the physics simulation when the [Node] is processed again.

## DISABLE_MODE_MAKE_STATIC :: const CollisionObject3D.DISABLE_MODE_MAKE_STATIC: DisableMode = 1
When [member Node.process_mode] is set to [constant Node.PROCESS_MODE_DISABLED], make the body static. Doesn't affect [Area3D]. [PhysicsBody3D] can't be affected by forces or other bodies while static.
Automatically set [PhysicsBody3D] back to its original mode when the [Node] is processed again.

## DISABLE_MODE_KEEP_ACTIVE :: const CollisionObject3D.DISABLE_MODE_KEEP_ACTIVE: DisableMode = 2
When [member Node.process_mode] is set to [constant Node.PROCESS_MODE_DISABLED], do not affect the physics simulation.

## collision_layer :: var CollisionObject3D.collision_layer: int
The physics layers this CollisionObject3D [b]is in[/b]. Collision objects can exist in one or more of 32 different layers. See also [member collision_mask].
[b]Note:[/b] Object A can detect a contact with object B only if object B is in any of the layers that object A scans. See [url=https://docs.godotengine.org/en/4.7/tutorials/physics/physics_introduction.html#collision-layers-and-masks]Collision layers and masks[/url] in the documentation for more information.

## collision_mask :: var CollisionObject3D.collision_mask: int
The physics layers this CollisionObject3D [b]scans[/b]. Collision objects can scan one or more of 32 different layers. See also [member collision_layer].
[b]Note:[/b] Object A can detect a contact with object B only if object B is in any of the layers that object A scans. See [url=https://docs.godotengine.org/en/4.7/tutorials/physics/physics_introduction.html#collision-layers-and-masks]Collision layers and masks[/url] in the documentation for more information.

## collision_priority :: var CollisionObject3D.collision_priority: float
The priority used to solve colliding when occurring penetration. The higher the priority is, the lower the penetration into the object will be. This can for example be used to prevent the player from breaking through the boundaries of a level.

## disable_mode :: var CollisionObject3D.disable_mode: CollisionObject3D.DisableMode
Defines the behavior in physics when [member Node.process_mode] is set to [constant Node.PROCESS_MODE_DISABLED].

## input_capture_on_drag :: var CollisionObject3D.input_capture_on_drag: bool
If [code]true[/code], the [CollisionObject3D] will continue to receive input events as the mouse is dragged across its shapes.

## input_ray_pickable :: var CollisionObject3D.input_ray_pickable: bool
If [code]true[/code], this object is pickable. A pickable object can detect the mouse pointer entering/leaving, and if the mouse is inside it, report input events. Requires at least one [member collision_layer] bit to be set.

## _input_event :: func CollisionObject3D._input_event(camera: Camera3D, event: InputEvent, event_position: Vector3, normal: Vector3, shape_idx: int) -> void
Receives unhandled [InputEvent]s. [param event_position] is the location in world space of the mouse pointer on the surface of the shape with index [param shape_idx] and [param normal] is the normal vector of the surface at that point. Connect to the [signal input_event] signal to easily pick up these events.
[b]Note:[/b] [method _input_event] requires [member input_ray_pickable] to be [code]true[/code] and at least one [member collision_layer] bit to be set.

### camera :: Camera3D

### event :: InputEvent

### event_position :: Vector3

### normal :: Vector3

### shape_idx :: int

## _mouse_enter :: func CollisionObject3D._mouse_enter() -> void
Called when the mouse pointer enters any of this object's shapes. Requires [member input_ray_pickable] to be [code]true[/code] and at least one [member collision_layer] bit to be set. Note that moving between different shapes within a single [CollisionObject3D] won't cause this function to be called.

## _mouse_exit :: func CollisionObject3D._mouse_exit() -> void
Called when the mouse pointer exits all this object's shapes. Requires [member input_ray_pickable] to be [code]true[/code] and at least one [member collision_layer] bit to be set. Note that moving between different shapes within a single [CollisionObject3D] won't cause this function to be called.

## create_shape_owner :: func CollisionObject3D.create_shape_owner(owner: Object) -> int
Creates a new shape owner for the given object. Returns [code]owner_id[/code] of the new owner for future reference.

### owner :: Object

## get_collision_layer_value :: func CollisionObject3D.get_collision_layer_value(layer_number: int) -> bool
Returns whether or not the specified layer of the [member collision_layer] is enabled, given a [param layer_number] between 1 and 32.

### layer_number :: int

## get_collision_mask_value :: func CollisionObject3D.get_collision_mask_value(layer_number: int) -> bool
Returns whether or not the specified layer of the [member collision_mask] is enabled, given a [param layer_number] between 1 and 32.

### layer_number :: int

## get_rid :: func CollisionObject3D.get_rid() -> RID
Returns the object's [RID].

## get_shape_owners :: func CollisionObject3D.get_shape_owners() -> PackedInt32Array
Returns an [Array] of [code]owner_id[/code] identifiers. You can use these ids in other methods that take [code]owner_id[/code] as an argument.

## is_shape_owner_disabled :: func CollisionObject3D.is_shape_owner_disabled(owner_id: int) -> bool
If [code]true[/code], the shape owner and its shapes are disabled.

### owner_id :: int

## remove_shape_owner :: func CollisionObject3D.remove_shape_owner(owner_id: int) -> void
Removes the given shape owner.

### owner_id :: int

## set_collision_layer_value :: func CollisionObject3D.set_collision_layer_value(layer_number: int, value: bool) -> void
Based on [param value], enables or disables the specified layer in the [member collision_layer], given a [param layer_number] between 1 and 32.

### layer_number :: int

### value :: bool

## set_collision_mask_value :: func CollisionObject3D.set_collision_mask_value(layer_number: int, value: bool) -> void
Based on [param value], enables or disables the specified layer in the [member collision_mask], given a [param layer_number] between 1 and 32.

### layer_number :: int

### value :: bool

## shape_find_owner :: func CollisionObject3D.shape_find_owner(shape_index: int) -> int
Returns the [code]owner_id[/code] of the given shape.

### shape_index :: int

## shape_owner_add_shape :: func CollisionObject3D.shape_owner_add_shape(owner_id: int, shape: Shape3D) -> void
Adds a [Shape3D] to the shape owner.

### owner_id :: int

### shape :: Shape3D

## shape_owner_clear_shapes :: func CollisionObject3D.shape_owner_clear_shapes(owner_id: int) -> void
Removes all shapes from the shape owner.

### owner_id :: int

## shape_owner_get_owner :: func CollisionObject3D.shape_owner_get_owner(owner_id: int) -> Object
Returns the parent object of the given shape owner.

### owner_id :: int

## shape_owner_get_shape :: func CollisionObject3D.shape_owner_get_shape(owner_id: int, shape_id: int) -> Shape3D
Returns the [Shape3D] with the given ID from the given shape owner.

### owner_id :: int

### shape_id :: int

## shape_owner_get_shape_count :: func CollisionObject3D.shape_owner_get_shape_count(owner_id: int) -> int
Returns the number of shapes the given shape owner contains.

### owner_id :: int

## shape_owner_get_shape_index :: func CollisionObject3D.shape_owner_get_shape_index(owner_id: int, shape_id: int) -> int
Returns the child index of the [Shape3D] with the given ID from the given shape owner.

### owner_id :: int

### shape_id :: int

## shape_owner_get_transform :: func CollisionObject3D.shape_owner_get_transform(owner_id: int) -> Transform3D
Returns the shape owner's [Transform3D].

### owner_id :: int

## shape_owner_remove_shape :: func CollisionObject3D.shape_owner_remove_shape(owner_id: int, shape_id: int) -> void
Removes a shape from the given shape owner.

### owner_id :: int

### shape_id :: int

## shape_owner_set_disabled :: func CollisionObject3D.shape_owner_set_disabled(owner_id: int, disabled: bool) -> void
If [code]true[/code], disables the given shape owner.

### owner_id :: int

### disabled :: bool

## shape_owner_set_transform :: func CollisionObject3D.shape_owner_set_transform(owner_id: int, transform: Transform3D) -> void
Sets the [Transform3D] of the given shape owner.

### owner_id :: int

### transform :: Transform3D

## input_event :: func CollisionObject3D.input_event(camera: Node, event: InputEvent, event_position: Vector3, normal: Vector3, shape_idx: int) -> void
Emitted when the object receives an unhandled [InputEvent]. [param event_position] is the location in world space of the mouse pointer on the surface of the shape with index [param shape_idx] and [param normal] is the normal vector of the surface at that point.

### camera :: Node

### event :: InputEvent

### event_position :: Vector3

### normal :: Vector3

### shape_idx :: int

## mouse_entered :: func CollisionObject3D.mouse_entered() -> void
Emitted when the mouse pointer enters any of this object's shapes. Requires [member input_ray_pickable] to be [code]true[/code] and at least one [member collision_layer] bit to be set.
[b]Note:[/b] Due to the lack of continuous collision detection, this signal may not be emitted in the expected order if the mouse moves fast enough and the [CollisionObject3D]'s area is small. This signal may also not be emitted if another [CollisionObject3D] is overlapping the [CollisionObject3D] in question.

## mouse_exited :: func CollisionObject3D.mouse_exited() -> void
Emitted when the mouse pointer exits all this object's shapes. Requires [member input_ray_pickable] to be [code]true[/code] and at least one [member collision_layer] bit to be set.
[b]Note:[/b] Due to the lack of continuous collision detection, this signal may not be emitted in the expected order if the mouse moves fast enough and the [CollisionObject3D]'s area is small. This signal may also not be emitted if another [CollisionObject3D] is overlapping the [CollisionObject3D] in question.
