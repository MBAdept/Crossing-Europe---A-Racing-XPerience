# VisualShader :: <Native> class VisualShader extends Shader
A custom shader program with a visual editor.
This class provides a graph-like visual editor for creating a [Shader]. Although [VisualShader]s do not require coding, they share the same logic with script shaders. They use [VisualShaderNode]s that can be connected to each other to control the flow of the shader. The visual shader graph is converted to a script shader behind the scenes.

## TYPE_VERTEX :: const VisualShader.TYPE_VERTEX: Type = 0
A vertex shader, operating on vertices.

## TYPE_FRAGMENT :: const VisualShader.TYPE_FRAGMENT: Type = 1
A fragment shader, operating on fragments (pixels).

## TYPE_LIGHT :: const VisualShader.TYPE_LIGHT: Type = 2
A shader for light calculations.

## TYPE_START :: const VisualShader.TYPE_START: Type = 3
A function for the "start" stage of particle shader.

## TYPE_PROCESS :: const VisualShader.TYPE_PROCESS: Type = 4
A function for the "process" stage of particle shader.

## TYPE_COLLIDE :: const VisualShader.TYPE_COLLIDE: Type = 5
A function for the "collide" stage (particle collision handler) of particle shader.

## TYPE_START_CUSTOM :: const VisualShader.TYPE_START_CUSTOM: Type = 6
A function for the "start" stage of particle shader, with customized output.

## TYPE_PROCESS_CUSTOM :: const VisualShader.TYPE_PROCESS_CUSTOM: Type = 7
A function for the "process" stage of particle shader, with customized output.

## TYPE_SKY :: const VisualShader.TYPE_SKY: Type = 8
A shader for 3D environment's sky.

## TYPE_FOG :: const VisualShader.TYPE_FOG: Type = 9
A compute shader that runs for each froxel of the volumetric fog map.

## TYPE_TEXTURE_BLIT :: const VisualShader.TYPE_TEXTURE_BLIT: Type = 10
A shader used to process blit calls to a DrawableTexture.

## TYPE_MAX :: const VisualShader.TYPE_MAX: Type = 11
Represents the size of the [enum Type] enum.

## VARYING_MODE_VERTEX_TO_FRAG_LIGHT :: const VisualShader.VARYING_MODE_VERTEX_TO_FRAG_LIGHT: VaryingMode = 0
Varying is passed from [code]Vertex[/code] function to [code]Fragment[/code] and [code]Light[/code] functions.

## VARYING_MODE_FRAG_TO_LIGHT :: const VisualShader.VARYING_MODE_FRAG_TO_LIGHT: VaryingMode = 1
Varying is passed from [code]Fragment[/code] function to [code]Light[/code] function.

## VARYING_MODE_MAX :: const VisualShader.VARYING_MODE_MAX: VaryingMode = 2
Represents the size of the [enum VaryingMode] enum.

## VARYING_TYPE_FLOAT :: const VisualShader.VARYING_TYPE_FLOAT: VaryingType = 0
Varying is of type [float].

## VARYING_TYPE_INT :: const VisualShader.VARYING_TYPE_INT: VaryingType = 1
Varying is of type [int].

## VARYING_TYPE_UINT :: const VisualShader.VARYING_TYPE_UINT: VaryingType = 2
Varying is of type unsigned [int].

## VARYING_TYPE_VECTOR_2D :: const VisualShader.VARYING_TYPE_VECTOR_2D: VaryingType = 3
Varying is of type [Vector2].

## VARYING_TYPE_VECTOR_3D :: const VisualShader.VARYING_TYPE_VECTOR_3D: VaryingType = 4
Varying is of type [Vector3].

## VARYING_TYPE_VECTOR_4D :: const VisualShader.VARYING_TYPE_VECTOR_4D: VaryingType = 5
Varying is of type [Vector4].

## VARYING_TYPE_BOOLEAN :: const VisualShader.VARYING_TYPE_BOOLEAN: VaryingType = 6
Varying is of type [bool].

## VARYING_TYPE_TRANSFORM :: const VisualShader.VARYING_TYPE_TRANSFORM: VaryingType = 7
Varying is of type [Transform3D].

## VARYING_TYPE_MAX :: const VisualShader.VARYING_TYPE_MAX: VaryingType = 8
Represents the size of the [enum VaryingType] enum.

## NODE_ID_INVALID :: const VisualShader.NODE_ID_INVALID = -1
Indicates an invalid [VisualShader] node.

## NODE_ID_OUTPUT :: const VisualShader.NODE_ID_OUTPUT = 0
Indicates an output node of [VisualShader].

## graph_offset :: var VisualShader.graph_offset: Vector2
Deprecated.

## add_node :: func VisualShader.add_node(type: int, node: VisualShaderNode, position: Vector2, id: int) -> void
Adds the specified [param node] to the shader.

### type :: int

### node :: VisualShaderNode

### position :: Vector2

### id :: int

## add_varying :: func VisualShader.add_varying(name: String, mode: int, type: int) -> void
Adds a new varying value node to the shader.

### name :: String

### mode :: int

### type :: int

## attach_node_to_frame :: func VisualShader.attach_node_to_frame(type: int, id: int, frame: int) -> void
Attaches the given node to the given frame.

### type :: int

### id :: int

### frame :: int

## can_connect_nodes :: func VisualShader.can_connect_nodes(type: int, from_node: int, from_port: int, to_node: int, to_port: int) -> bool
Returns [code]true[/code] if the specified nodes and ports can be connected together.

### type :: int

### from_node :: int

### from_port :: int

### to_node :: int

### to_port :: int

## connect_nodes :: func VisualShader.connect_nodes(type: int, from_node: int, from_port: int, to_node: int, to_port: int) -> int
Connects the specified nodes and ports.

### type :: int

### from_node :: int

### from_port :: int

### to_node :: int

### to_port :: int

## connect_nodes_forced :: func VisualShader.connect_nodes_forced(type: int, from_node: int, from_port: int, to_node: int, to_port: int) -> void
Connects the specified nodes and ports, even if they can't be connected. Such connection is invalid and will not function properly.

### type :: int

### from_node :: int

### from_port :: int

### to_node :: int

### to_port :: int

## detach_node_from_frame :: func VisualShader.detach_node_from_frame(type: int, id: int) -> void
Detaches the given node from the frame it is attached to.

### type :: int

### id :: int

## disconnect_nodes :: func VisualShader.disconnect_nodes(type: int, from_node: int, from_port: int, to_node: int, to_port: int) -> void
Connects the specified nodes and ports.

### type :: int

### from_node :: int

### from_port :: int

### to_node :: int

### to_port :: int

## get_node :: func VisualShader.get_node(type: int, id: int) -> VisualShaderNode
Returns the shader node instance with specified [param type] and [param id].

### type :: int

### id :: int

## get_node_connections :: func VisualShader.get_node_connections(type: int) -> Dictionary[]
Returns the list of connected nodes with the specified type.

### type :: int

## get_node_list :: func VisualShader.get_node_list(type: int) -> PackedInt32Array
Returns the list of all nodes in the shader with the specified type.

### type :: int

## get_node_position :: func VisualShader.get_node_position(type: int, id: int) -> Vector2
Returns the position of the specified node within the shader graph.

### type :: int

### id :: int

## get_valid_node_id :: func VisualShader.get_valid_node_id(type: int) -> int
Returns next valid node ID that can be added to the shader graph.

### type :: int

## has_varying :: func VisualShader.has_varying(name: String) -> bool
Returns [code]true[/code] if the shader has a varying with the given [param name].

### name :: String

## is_node_connection :: func VisualShader.is_node_connection(type: int, from_node: int, from_port: int, to_node: int, to_port: int) -> bool
Returns [code]true[/code] if the specified node and port connection exist.

### type :: int

### from_node :: int

### from_port :: int

### to_node :: int

### to_port :: int

## remove_node :: func VisualShader.remove_node(type: int, id: int) -> void
Removes the specified node from the shader.

### type :: int

### id :: int

## remove_varying :: func VisualShader.remove_varying(name: String) -> void
Removes a varying value node with the given [param name]. Prints an error if a node with this name is not found.

### name :: String

## replace_node :: func VisualShader.replace_node(type: int, id: int, new_class: StringName) -> void
Replaces the specified node with a node of new class type.

### type :: int

### id :: int

### new_class :: StringName

## set_mode :: func VisualShader.set_mode(mode: int) -> void
Sets the mode of this shader.

### mode :: int

## set_node_position :: func VisualShader.set_node_position(type: int, id: int, position: Vector2) -> void
Sets the position of the specified node.

### type :: int

### id :: int

### position :: Vector2
