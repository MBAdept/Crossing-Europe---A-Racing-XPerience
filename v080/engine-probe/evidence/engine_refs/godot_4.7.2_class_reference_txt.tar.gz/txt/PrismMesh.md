# PrismMesh :: <Native> class PrismMesh extends PrimitiveMesh
Class representing a prism-shaped [PrimitiveMesh].
Class representing a prism-shaped [PrimitiveMesh].

## left_to_right :: var PrismMesh.left_to_right: float
Displacement of the upper edge along the X axis. 0.0 positions edge straight above the bottom-left edge.

## size :: var PrismMesh.size: Vector3
Size of the prism.

## subdivide_depth :: var PrismMesh.subdivide_depth: int
Number of added edge loops along the Z axis.

## subdivide_height :: var PrismMesh.subdivide_height: int
Number of added edge loops along the Y axis.

## subdivide_width :: var PrismMesh.subdivide_width: int
Number of added edge loops along the X axis.
