# TubeTrailMesh :: <Native> class TubeTrailMesh extends PrimitiveMesh
Represents a straight tube-shaped [PrimitiveMesh] with variable width.
[TubeTrailMesh] represents a straight tube-shaped mesh with variable width. The tube is composed of a number of cylindrical sections, each with the same [member section_length] and number of [member section_rings]. A [member curve] is sampled along the total length of the tube, meaning that the curve determines the radius of the tube along its length.
This primitive mesh is usually used for particle trails.

## cap_bottom :: var TubeTrailMesh.cap_bottom: bool
If [code]true[/code], generates a cap at the bottom of the tube. This can be set to [code]false[/code] to speed up generation and rendering when the cap is never seen by the camera.

## cap_top :: var TubeTrailMesh.cap_top: bool
If [code]true[/code], generates a cap at the top of the tube. This can be set to [code]false[/code] to speed up generation and rendering when the cap is never seen by the camera.

## curve :: var TubeTrailMesh.curve: Curve
Determines the radius of the tube along its length. The radius of a particular section ring is obtained by multiplying the baseline [member radius] by the value of this curve at the given distance. For values smaller than [code]0[/code], the faces will be inverted. Should be a unit [Curve].

## radial_steps :: var TubeTrailMesh.radial_steps: int
The number of sides on the tube. For example, a value of [code]5[/code] means the tube will be pentagonal. Higher values result in a more detailed tube at the cost of performance.

## radius :: var TubeTrailMesh.radius: float
The baseline radius of the tube. The radius of a particular section ring is obtained by multiplying this radius by the value of the [member curve] at the given distance.

## section_length :: var TubeTrailMesh.section_length: float
The length of a section of the tube.

## section_rings :: var TubeTrailMesh.section_rings: int
The number of rings in a section. The [member curve] is sampled on each ring to determine its radius. Higher values result in a more detailed tube at the cost of performance.

## sections :: var TubeTrailMesh.sections: int
The total number of sections on the tube.
