# VisualShaderNodeVec3Constant :: <Native> class VisualShaderNodeVec3Constant extends VisualShaderNodeConstant
A [Vector3] constant to be used within the visual shader graph.
A constant [Vector3], which can be used as an input node.

## constant :: var VisualShaderNodeVec3Constant.constant: Vector3
A [Vector3] constant which represents the state of this node.
