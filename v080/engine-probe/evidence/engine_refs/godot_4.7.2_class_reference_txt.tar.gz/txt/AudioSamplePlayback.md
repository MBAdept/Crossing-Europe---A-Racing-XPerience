# AudioSamplePlayback :: <Native> class AudioSamplePlayback extends RefCounted
Meta class for playing back audio samples.
Meta class for playing back audio samples.
