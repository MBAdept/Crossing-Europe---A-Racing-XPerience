# EditorSyntaxHighlighter :: <Native> class EditorSyntaxHighlighter extends SyntaxHighlighter
Base class for [SyntaxHighlighter] used by the [ScriptEditor].
Base class that all [SyntaxHighlighter]s used by the [ScriptEditor] extend from.
Add a syntax highlighter to an individual script by calling [method ScriptEditorBase.add_syntax_highlighter]. To apply to all scripts on open, call [method ScriptEditor.register_syntax_highlighter].

## _create :: func EditorSyntaxHighlighter._create() -> EditorSyntaxHighlighter
Virtual method which creates a new instance of the syntax highlighter.

## _get_name :: func EditorSyntaxHighlighter._get_name() -> String
Virtual method which can be overridden to return the syntax highlighter name.

## _get_supported_languages :: func EditorSyntaxHighlighter._get_supported_languages() -> PackedStringArray
Virtual method which can be overridden to return the supported language names.
