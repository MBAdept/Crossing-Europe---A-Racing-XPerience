# AudioStreamPlayer :: <Native> class AudioStreamPlayer extends Node
A node for audio playback.
The [AudioStreamPlayer] node plays an audio stream non-positionally. It is ideal for user interfaces, menus, or background music.
To use this node, [member stream] needs to be set to a valid [AudioStream] resource. Playing more than one sound at the same time is also supported, see [member max_polyphony].
If you need to play audio at a specific position, use [AudioStreamPlayer2D] or [AudioStreamPlayer3D] instead.

## MIX_TARGET_STEREO :: const AudioStreamPlayer.MIX_TARGET_STEREO: MixTarget = 0
The audio will be played only on the first channel. This is the default.

## MIX_TARGET_SURROUND :: const AudioStreamPlayer.MIX_TARGET_SURROUND: MixTarget = 1
The audio will be played on all surround channels.

## MIX_TARGET_CENTER :: const AudioStreamPlayer.MIX_TARGET_CENTER: MixTarget = 2
The audio will be played on the second channel, which is usually the center.

## autoplay :: var AudioStreamPlayer.autoplay: bool
If [code]true[/code], this node calls [method play] when entering the tree.

## bus :: var AudioStreamPlayer.bus: StringName
The target bus name. All sounds from this node will be playing on this bus.
[b]Note:[/b] At runtime, if no bus with the given name exists, all sounds will fall back on [code]"Master"[/code]. See also [method AudioServer.get_bus_name].

## max_polyphony :: var AudioStreamPlayer.max_polyphony: int
The maximum number of sounds this node can play at the same time. Calling [method play] after this value is reached will cut off the oldest sounds.

## mix_target :: var AudioStreamPlayer.mix_target: AudioStreamPlayer.MixTarget
The mix target channels. Has no effect when two speakers or less are detected (see [enum AudioServer.SpeakerMode]).

## pitch_scale :: var AudioStreamPlayer.pitch_scale: float
The audio's pitch and tempo, as a multiplier of the [member stream]'s sample rate. A value of [code]2.0[/code] doubles the audio's pitch, while a value of [code]0.5[/code] halves the pitch.

## playback_type :: var AudioStreamPlayer.playback_type: AudioServer.PlaybackType
The playback type of the stream player. If set other than to the default value, it will force that playback type.

## playing :: var AudioStreamPlayer.playing: bool
If [code]true[/code], this node is playing sounds. Setting this property has the same effect as [method play] and [method stop].

## stream :: var AudioStreamPlayer.stream: AudioStream
The [AudioStream] resource to be played. Setting this property stops all currently playing sounds. If left empty, the [AudioStreamPlayer] does not work.

## stream_paused :: var AudioStreamPlayer.stream_paused: bool
If [code]true[/code], the sounds are paused. Setting [member stream_paused] to [code]false[/code] resumes all sounds.
[b]Note:[/b] This property is automatically changed when exiting or entering the tree, or this node is paused (see [member Node.process_mode]).

## volume_db :: var AudioStreamPlayer.volume_db: float
Volume of sound, in decibels. This is an offset of the [member stream]'s volume.
[b]Note:[/b] To convert between decibel and linear energy (like most volume sliders do), use [member volume_linear], or [method @GlobalScope.db_to_linear] and [method @GlobalScope.linear_to_db].

## volume_linear :: var AudioStreamPlayer.volume_linear: float
Volume of sound, as a linear value.
[b]Note:[/b] This member modifies [member volume_db] for convenience. The returned value is equivalent to the result of [method @GlobalScope.db_to_linear] on [member volume_db]. Setting this member is equivalent to setting [member volume_db] to the result of [method @GlobalScope.linear_to_db] on a value.

## get_playback_position :: func AudioStreamPlayer.get_playback_position() -> float
Returns the position in the [AudioStream] of the latest sound, in seconds. Returns [code]0.0[/code] if no sounds are playing.
[b]Note:[/b] The position is not always accurate, as the [AudioServer] does not mix audio every processed frame. To get more accurate results, add [method AudioServer.get_time_since_last_mix] to the returned position.
[b]Note:[/b] This method always returns [code]0.0[/code] if the [member stream] is an [AudioStreamInteractive], since it can have multiple clips playing at once.

## get_stream_playback :: func AudioStreamPlayer.get_stream_playback() -> AudioStreamPlayback
Returns the latest [AudioStreamPlayback] of this node, usually the most recently created by [method play]. If no sounds are playing, this method fails and returns an empty playback.

## has_stream_playback :: func AudioStreamPlayer.has_stream_playback() -> bool
Returns [code]true[/code] if any sound is active, even if [member stream_paused] is set to [code]true[/code]. See also [member playing] and [method get_stream_playback].

## play :: func AudioStreamPlayer.play(from_position: float = 0.0) -> void
Plays a sound from the beginning, or the given [param from_position] in seconds.

### from_position :: float

## seek :: func AudioStreamPlayer.seek(to_position: float) -> void
Restarts all sounds to be played from the given [param to_position], in seconds. Does nothing if no sounds are playing.

### to_position :: float

## stop :: func AudioStreamPlayer.stop() -> void
Stops all sounds from this node.

## finished :: func AudioStreamPlayer.finished() -> void
Emitted when a sound finishes playing without interruptions. This signal is [i]not[/i] emitted when calling [method stop], or when exiting the tree while sounds are playing.
