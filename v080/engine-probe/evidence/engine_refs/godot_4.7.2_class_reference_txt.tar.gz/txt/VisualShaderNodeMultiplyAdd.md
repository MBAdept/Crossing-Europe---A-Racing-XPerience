# VisualShaderNodeMultiplyAdd :: <Native> class VisualShaderNodeMultiplyAdd extends VisualShaderNode
Performs a fused multiply-add operation within the visual shader graph.
Uses three operands to compute [code](a * b + c)[/code] expression.

## OP_TYPE_SCALAR :: const VisualShaderNodeMultiplyAdd.OP_TYPE_SCALAR: OpType = 0
A floating-point scalar type.

## OP_TYPE_VECTOR_2D :: const VisualShaderNodeMultiplyAdd.OP_TYPE_VECTOR_2D: OpType = 1
A 2D vector type.

## OP_TYPE_VECTOR_3D :: const VisualShaderNodeMultiplyAdd.OP_TYPE_VECTOR_3D: OpType = 2
A 3D vector type.

## OP_TYPE_VECTOR_4D :: const VisualShaderNodeMultiplyAdd.OP_TYPE_VECTOR_4D: OpType = 3
A 4D vector type.

## OP_TYPE_MAX :: const VisualShaderNodeMultiplyAdd.OP_TYPE_MAX: OpType = 4
Represents the size of the [enum OpType] enum.

## op_type :: var VisualShaderNodeMultiplyAdd.op_type: VisualShaderNodeMultiplyAdd.OpType
A type of operands and returned value.
