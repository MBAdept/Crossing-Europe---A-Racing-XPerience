# GLTFPhysicsShape :: <Native> class GLTFPhysicsShape extends Resource
Represents a glTF physics shape.
Represents a physics shape as defined by the [code]OMI_physics_shape[/code] or [code]OMI_collider[/code] glTF extensions. This class is an intermediary between the glTF data and Godot's nodes, and it's abstracted in a way that allows adding support for different glTF physics extensions in the future.

## height :: var GLTFPhysicsShape.height: float
The height of the shape, in meters. This is only used when the shape type is [code]"capsule"[/code] or [code]"cylinder"[/code]. This value should not be negative, and for [code]"capsule"[/code] it should be at least twice the radius.

## importer_mesh :: var GLTFPhysicsShape.importer_mesh: ImporterMesh
The [ImporterMesh] resource of the shape. This is only used when the shape type is [code]"hull"[/code] (convex hull) or [code]"trimesh"[/code] (concave trimesh).

## is_trigger :: var GLTFPhysicsShape.is_trigger: bool
If [code]true[/code], indicates that this shape is a trigger. For Godot, this means that the shape should be a child of an [Area3D] node.
This is the only variable not used in the [method to_node] method, it's intended to be used alongside when deciding where to add the generated node as a child.

## mesh_index :: var GLTFPhysicsShape.mesh_index: int
The index of the shape's mesh in the glTF file. This is only used when the shape type is [code]"hull"[/code] (convex hull) or [code]"trimesh"[/code] (concave trimesh).

## radius :: var GLTFPhysicsShape.radius: float
The radius of the shape, in meters. This is only used when the shape type is [code]"capsule"[/code], [code]"cylinder"[/code], or [code]"sphere"[/code]. This value should not be negative.

## shape_type :: var GLTFPhysicsShape.shape_type: String
The type of shape this shape represents. Valid values are [code]"box"[/code], [code]"capsule"[/code], [code]"cylinder"[/code], [code]"sphere"[/code], [code]"hull"[/code], and [code]"trimesh"[/code].

## size :: var GLTFPhysicsShape.size: Vector3
The size of the shape, in meters. This is only used when the shape type is [code]"box"[/code], and it represents the [code]"diameter"[/code] of the box. This value should not be negative.

## from_dictionary :: func GLTFPhysicsShape.from_dictionary(dictionary: Dictionary) -> GLTFPhysicsShape
Creates a new GLTFPhysicsShape instance by parsing the given [Dictionary].

### dictionary :: Dictionary

## from_node :: func GLTFPhysicsShape.from_node(shape_node: CollisionShape3D) -> GLTFPhysicsShape
Creates a new GLTFPhysicsShape instance from the given Godot [CollisionShape3D] node.

### shape_node :: CollisionShape3D

## from_resource :: func GLTFPhysicsShape.from_resource(shape_resource: Shape3D) -> GLTFPhysicsShape
Creates a new GLTFPhysicsShape instance from the given Godot [Shape3D] resource.

### shape_resource :: Shape3D

## to_dictionary :: func GLTFPhysicsShape.to_dictionary() -> Dictionary
Serializes this GLTFPhysicsShape instance into a [Dictionary] in the format defined by [code]OMI_physics_shape[/code].

## to_node :: func GLTFPhysicsShape.to_node(cache_shapes: bool = false) -> CollisionShape3D
Converts this GLTFPhysicsShape instance into a Godot [CollisionShape3D] node.

### cache_shapes :: bool

## to_resource :: func GLTFPhysicsShape.to_resource(cache_shapes: bool = false) -> Shape3D
Converts this GLTFPhysicsShape instance into a Godot [Shape3D] resource.

### cache_shapes :: bool
