# RDAccelerationStructureInstance :: <Native> class RDAccelerationStructureInstance extends RefCounted
Acceleration structure instance (used by [RenderingDevice]).
[RDAccelerationStructureInstance] describes an instance of a Bottom-Level Acceleration Structure (BLAS) used in the [method RenderingDevice.tlas_build] method.

## blas :: var RDAccelerationStructureInstance.blas: RID
The BLAS referenced by this instance. If [code]null[/code], the instance is treated as a placeholder but still contributes to [code]gl_InstanceIndex[/code] in GLSL.

## flags :: var RDAccelerationStructureInstance.flags: RenderingDevice.AccelerationStructureInstanceFlagBits
Flags for the instance.

## hit_sbt_range :: var RDAccelerationStructureInstance.hit_sbt_range: int
Hit shader binding table range used for this instance, allocated using the [method RenderingDevice.hit_sbt_range_alloc] method.

## id :: var RDAccelerationStructureInstance.id: int
Custom instance ID that can be accessed in GLSL using [code]gl_InstanceCustomIndexEXT[/code].

## mask :: var RDAccelerationStructureInstance.mask: int
Visibility mask used to control which rays can intersect this instance.

## transform :: var RDAccelerationStructureInstance.transform: Transform3D
Transform applied to the referenced BLAS for this instance.
