# LimitAngularVelocityModifier3D :: <Native> class LimitAngularVelocityModifier3D extends SkeletonModifier3D
Limit bone rotation angular velocity.
This modifier limits bone rotation angular velocity by comparing poses between previous and current frame.
You can add bone chains by specifying their root and end bones, then add the bones between them to a list. Modifier processes either that list or the bones excluding those in the list depending on the option [member exclude].
[b]Note:[/b] Most methods in this class take an [code]index[/code] parameter. This parameter specifies which setting list entry to return if the IK has multiple entries (e.g. [code]settings/<index>/root_bone_name[/code]).

## chain_count :: var LimitAngularVelocityModifier3D.chain_count: int
The number of chains.

## exclude :: var LimitAngularVelocityModifier3D.exclude: bool
If [code]true[/code], the modifier processes bones not included in the bone list.
If [code]false[/code], the bones processed by the modifier are equal to the bone list.

## joint_count :: var LimitAngularVelocityModifier3D.joint_count: int
The number of joints in the list which created by chains dynamically.

## max_angular_velocity :: var LimitAngularVelocityModifier3D.max_angular_velocity: float
The maximum angular velocity per second.

## clear_chains :: func LimitAngularVelocityModifier3D.clear_chains() -> void
Clear all chains.

## get_end_bone :: func LimitAngularVelocityModifier3D.get_end_bone(index: int) -> int
Returns the end bone index of the bone chain.

### index :: int

## get_end_bone_name :: func LimitAngularVelocityModifier3D.get_end_bone_name(index: int) -> String
Returns the end bone name of the bone chain.

### index :: int

## get_root_bone :: func LimitAngularVelocityModifier3D.get_root_bone(index: int) -> int
Returns the root bone index of the bone chain.

### index :: int

## get_root_bone_name :: func LimitAngularVelocityModifier3D.get_root_bone_name(index: int) -> String
Returns the root bone name of the bone chain.

### index :: int

## reset :: func LimitAngularVelocityModifier3D.reset() -> void
Sets the reference pose for angle comparison to the current pose with the influence of constraints removed. This function is automatically triggered when joints change or upon activation.

## set_end_bone :: func LimitAngularVelocityModifier3D.set_end_bone(index: int, bone: int) -> void
Sets the end bone index of the bone chain.

### index :: int

### bone :: int

## set_end_bone_name :: func LimitAngularVelocityModifier3D.set_end_bone_name(index: int, bone_name: String) -> void
Sets the end bone name of the bone chain.
[b]Note:[/b] End bone must be the root bone or a child of the root bone.

### index :: int

### bone_name :: String

## set_root_bone :: func LimitAngularVelocityModifier3D.set_root_bone(index: int, bone: int) -> void
Sets the root bone index of the bone chain.

### index :: int

### bone :: int

## set_root_bone_name :: func LimitAngularVelocityModifier3D.set_root_bone_name(index: int, bone_name: String) -> void
Sets the root bone name of the bone chain.

### index :: int

### bone_name :: String
