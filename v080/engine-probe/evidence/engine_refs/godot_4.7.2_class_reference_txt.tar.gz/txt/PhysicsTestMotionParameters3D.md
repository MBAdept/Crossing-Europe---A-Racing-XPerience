# PhysicsTestMotionParameters3D :: <Native> class PhysicsTestMotionParameters3D extends RefCounted
Provides parameters for [method PhysicsServer3D.body_test_motion].
By changing various properties of this object, such as the motion, you can configure the parameters for [method PhysicsServer3D.body_test_motion].

## collide_separation_ray :: var PhysicsTestMotionParameters3D.collide_separation_ray: bool
If set to [code]true[/code], shapes of type [constant PhysicsServer3D.SHAPE_SEPARATION_RAY] are used to detect collisions and can stop the motion. Can be useful when snapping to the ground.
If set to [code]false[/code], shapes of type [constant PhysicsServer3D.SHAPE_SEPARATION_RAY] are only used for separation when overlapping with other bodies. That's the main use for separation ray shapes.

## exclude_bodies :: var PhysicsTestMotionParameters3D.exclude_bodies: RID[]
Optional array of body [RID] to exclude from collision. Use [method CollisionObject3D.get_rid] to get the [RID] associated with a [CollisionObject3D]-derived node.

## exclude_objects :: var PhysicsTestMotionParameters3D.exclude_objects: int[]
Optional array of object unique instance ID to exclude from collision. See [method Object.get_instance_id].

## from :: var PhysicsTestMotionParameters3D.from: Transform3D
Transform in global space where the motion should start. Usually set to [member Node3D.global_transform] for the current body's transform.

## margin :: var PhysicsTestMotionParameters3D.margin: float
Increases the size of the shapes involved in the collision detection.

## max_collisions :: var PhysicsTestMotionParameters3D.max_collisions: int
Maximum number of returned collisions, between [code]1[/code] and [code]32[/code]. Always returns the deepest detected collisions.

## motion :: var PhysicsTestMotionParameters3D.motion: Vector3
Motion vector to define the length and direction of the motion to test.

## recovery_as_collision :: var PhysicsTestMotionParameters3D.recovery_as_collision: bool
If set to [code]true[/code], any depenetration from the recovery phase is reported as a collision; this is used e.g. by [CharacterBody3D] for improving floor detection during floor snapping.
If set to [code]false[/code], only collisions resulting from the motion are reported, which is generally the desired behavior.
