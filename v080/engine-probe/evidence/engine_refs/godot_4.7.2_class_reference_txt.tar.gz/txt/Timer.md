# Timer :: <Native> class Timer extends Node
A countdown timer.
The [Timer] node is a countdown timer and is the simplest way to handle time-based logic in the engine. When a timer reaches the end of its [member wait_time], it will emit the [signal timeout] signal.
After a timer enters the scene tree, it can be manually started with [method start]. A timer node is also started automatically if [member autostart] is [code]true[/code].
Without requiring much code, a timer node can be added and configured in the editor. The [signal timeout] signal it emits can also be connected through the Signals dock in the editor:
[codeblock]
func _on_timer_timeout():
	print("Time to attack!")
[/codeblock]
[b]Note:[/b] To create a one-shot timer without instantiating a node, use [method SceneTree.create_timer].
[b]Note:[/b] Timers are affected by [member Engine.time_scale] unless [member ignore_time_scale] is [code]true[/code]. The higher the time scale, the sooner timers will end. How often a timer processes may depend on the framerate or [member Engine.physics_ticks_per_second].

## TIMER_PROCESS_PHYSICS :: const Timer.TIMER_PROCESS_PHYSICS: TimerProcessCallback = 0
Update the timer every physics process frame (see [constant Node.NOTIFICATION_INTERNAL_PHYSICS_PROCESS]).

## TIMER_PROCESS_IDLE :: const Timer.TIMER_PROCESS_IDLE: TimerProcessCallback = 1
Update the timer every process (rendered) frame (see [constant Node.NOTIFICATION_INTERNAL_PROCESS]).

## autostart :: var Timer.autostart: bool
If [code]true[/code], the timer will start immediately when it enters the scene tree.
[b]Note:[/b] After the timer enters the tree, this property is automatically set to [code]false[/code].
[b]Note:[/b] This property does nothing when the timer is running in the editor.

## ignore_time_scale :: var Timer.ignore_time_scale: bool
If [code]true[/code], the timer will ignore [member Engine.time_scale] and update with the real, elapsed time.

## one_shot :: var Timer.one_shot: bool
If [code]true[/code], the timer will stop after reaching the end. Otherwise, as by default, the timer will automatically restart.

## paused :: var Timer.paused: bool
If [code]true[/code], the timer is paused. A paused timer does not process until this property is set back to [code]false[/code], even when [method start] is called. See also [method stop].

## process_callback :: var Timer.process_callback: Timer.TimerProcessCallback
Specifies when the timer is updated during the main loop.

## time_left :: var Timer.time_left: float
The timer's remaining time in seconds. This is always [code]0[/code] if the timer is stopped.
[b]Note:[/b] This property is read-only and cannot be modified. It is based on [member wait_time].

## wait_time :: var Timer.wait_time: float
The time required for the timer to end, in seconds. This property can also be set every time [method start] is called.
[b]Note:[/b] Timers can only process once per physics or process frame (depending on the [member process_callback]). An unstable framerate may cause the timer to end inconsistently, which is especially noticeable if the wait time is lower than roughly [code]0.05[/code] seconds. For very short timers, it is recommended to write your own code instead of using a [Timer] node. Timers are also affected by [member Engine.time_scale].

## is_stopped :: func Timer.is_stopped() -> bool
Returns [code]true[/code] if the timer is stopped or has not started.

## start :: func Timer.start(time_sec: float = -1) -> void
Starts the timer, or resets the timer if it was started already. Fails if the timer is not inside the scene tree. If [param time_sec] is greater than [code]0[/code], this value is used for the [member wait_time].
[b]Note:[/b] This method does not resume a paused timer. See [member paused].

### time_sec :: float

## stop :: func Timer.stop() -> void
Stops the timer. See also [member paused]. Unlike [method start], this can safely be called if the timer is not inside the scene tree.
[b]Note:[/b] Calling [method stop] does not emit the [signal timeout] signal, as the timer is not considered to have timed out. If this is desired, use [code]$Timer.timeout.emit()[/code] after calling [method stop] to manually emit the signal.

## timeout :: func Timer.timeout() -> void
Emitted when the timer reaches the end.
