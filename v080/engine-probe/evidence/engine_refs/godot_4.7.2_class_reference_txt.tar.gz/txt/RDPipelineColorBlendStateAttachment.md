# RDPipelineColorBlendStateAttachment :: <Native> class RDPipelineColorBlendStateAttachment extends RefCounted
Pipeline color blend state attachment (used by [RenderingDevice]).
Controls how blending between source and destination fragments is performed when using [RenderingDevice].
For reference, this is how common user-facing blend modes are implemented in Godot's 2D renderer:
[b]Mix:[/b]
[codeblock]
var attachment = RDPipelineColorBlendStateAttachment.new()
attachment.enable_blend = true
attachment.color_blend_op = RenderingDevice.BLEND_OP_ADD
attachment.src_color_blend_factor = RenderingDevice.BLEND_FACTOR_SRC_ALPHA
attachment.dst_color_blend_factor = RenderingDevice.BLEND_FACTOR_ONE_MINUS_SRC_ALPHA
attachment.alpha_blend_op = RenderingDevice.BLEND_OP_ADD
attachment.src_alpha_blend_factor = RenderingDevice.BLEND_FACTOR_ONE
attachment.dst_alpha_blend_factor = RenderingDevice.BLEND_FACTOR_ONE_MINUS_SRC_ALPHA
[/codeblock]
[b]Add:[/b]
[codeblock]
var attachment = RDPipelineColorBlendStateAttachment.new()
attachment.enable_blend = true
attachment.alpha_blend_op = RenderingDevice.BLEND_OP_ADD
attachment.color_blend_op = RenderingDevice.BLEND_OP_ADD
attachment.src_color_blend_factor = RenderingDevice.BLEND_FACTOR_SRC_ALPHA
attachment.dst_color_blend_factor = RenderingDevice.BLEND_FACTOR_ONE
attachment.src_alpha_blend_factor = RenderingDevice.BLEND_FACTOR_SRC_ALPHA
attachment.dst_alpha_blend_factor = RenderingDevice.BLEND_FACTOR_ONE
[/codeblock]
[b]Subtract:[/b]
[codeblock]
var attachment = RDPipelineColorBlendStateAttachment.new()
attachment.enable_blend = true
attachment.alpha_blend_op = RenderingDevice.BLEND_OP_REVERSE_SUBTRACT
attachment.color_blend_op = RenderingDevice.BLEND_OP_REVERSE_SUBTRACT
attachment.src_color_blend_factor = RenderingDevice.BLEND_FACTOR_SRC_ALPHA
attachment.dst_color_blend_factor = RenderingDevice.BLEND_FACTOR_ONE
attachment.src_alpha_blend_factor = RenderingDevice.BLEND_FACTOR_SRC_ALPHA
attachment.dst_alpha_blend_factor = RenderingDevice.BLEND_FACTOR_ONE
[/codeblock]
[b]Multiply:[/b]
[codeblock]
var attachment = RDPipelineColorBlendStateAttachment.new()
attachment.enable_blend = true
attachment.alpha_blend_op = RenderingDevice.BLEND_OP_ADD
attachment.color_blend_op = RenderingDevice.BLEND_OP_ADD
attachment.src_color_blend_factor = RenderingDevice.BLEND_FACTOR_DST_COLOR
attachment.dst_color_blend_factor = RenderingDevice.BLEND_FACTOR_ZERO
attachment.src_alpha_blend_factor = RenderingDevice.BLEND_FACTOR_DST_ALPHA
attachment.dst_alpha_blend_factor = RenderingDevice.BLEND_FACTOR_ZERO
[/codeblock]
[b]Pre-multiplied alpha:[/b]
[codeblock]
var attachment = RDPipelineColorBlendStateAttachment.new()
attachment.enable_blend = true
attachment.alpha_blend_op = RenderingDevice.BLEND_OP_ADD
attachment.color_blend_op = RenderingDevice.BLEND_OP_ADD
attachment.src_color_blend_factor = RenderingDevice.BLEND_FACTOR_ONE
attachment.dst_color_blend_factor = RenderingDevice.BLEND_FACTOR_ONE_MINUS_SRC_ALPHA
attachment.src_alpha_blend_factor = RenderingDevice.BLEND_FACTOR_ONE
attachment.dst_alpha_blend_factor = RenderingDevice.BLEND_FACTOR_ONE_MINUS_SRC_ALPHA
[/codeblock]

## alpha_blend_op :: var RDPipelineColorBlendStateAttachment.alpha_blend_op: RenderingDevice.BlendOperation
The blend mode to use for the alpha channel.

## color_blend_op :: var RDPipelineColorBlendStateAttachment.color_blend_op: RenderingDevice.BlendOperation
The blend mode to use for the red/green/blue color channels.

## dst_alpha_blend_factor :: var RDPipelineColorBlendStateAttachment.dst_alpha_blend_factor: RenderingDevice.BlendFactor
Controls how the blend factor for the alpha channel is determined based on the destination's fragments.

## dst_color_blend_factor :: var RDPipelineColorBlendStateAttachment.dst_color_blend_factor: RenderingDevice.BlendFactor
Controls how the blend factor for the color channels is determined based on the destination's fragments.

## enable_blend :: var RDPipelineColorBlendStateAttachment.enable_blend: bool
If [code]true[/code], performs blending between the source and destination according to the factors defined in [member src_color_blend_factor], [member dst_color_blend_factor], [member src_alpha_blend_factor] and [member dst_alpha_blend_factor]. The blend modes [member color_blend_op] and [member alpha_blend_op] are also taken into account, with [member write_r], [member write_g], [member write_b] and [member write_a] controlling the output.

## src_alpha_blend_factor :: var RDPipelineColorBlendStateAttachment.src_alpha_blend_factor: RenderingDevice.BlendFactor
Controls how the blend factor for the alpha channel is determined based on the source's fragments.

## src_color_blend_factor :: var RDPipelineColorBlendStateAttachment.src_color_blend_factor: RenderingDevice.BlendFactor
Controls how the blend factor for the color channels is determined based on the source's fragments.

## write_a :: var RDPipelineColorBlendStateAttachment.write_a: bool
If [code]true[/code], writes the new alpha channel to the final result.

## write_b :: var RDPipelineColorBlendStateAttachment.write_b: bool
If [code]true[/code], writes the new blue color channel to the final result.

## write_g :: var RDPipelineColorBlendStateAttachment.write_g: bool
If [code]true[/code], writes the new green color channel to the final result.

## write_r :: var RDPipelineColorBlendStateAttachment.write_r: bool
If [code]true[/code], writes the new red color channel to the final result.

## set_as_mix :: func RDPipelineColorBlendStateAttachment.set_as_mix() -> void
Convenience method to perform standard mix blending with straight (non-premultiplied) alpha. This sets [member enable_blend] to [code]true[/code], [member src_color_blend_factor] to [constant RenderingDevice.BLEND_FACTOR_SRC_ALPHA], [member dst_color_blend_factor] to [constant RenderingDevice.BLEND_FACTOR_ONE_MINUS_SRC_ALPHA], [member src_alpha_blend_factor] to [constant RenderingDevice.BLEND_FACTOR_SRC_ALPHA] and [member dst_alpha_blend_factor] to [constant RenderingDevice.BLEND_FACTOR_ONE_MINUS_SRC_ALPHA].
