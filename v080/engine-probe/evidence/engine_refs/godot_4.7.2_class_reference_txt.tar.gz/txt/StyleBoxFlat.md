# StyleBoxFlat :: <Native> class StyleBoxFlat extends StyleBox
A customizable [StyleBox] that doesn't use a texture.
By configuring various properties of this style box, you can achieve many common looks without the need of a texture. This includes optionally rounded borders, antialiasing, shadows, and skew.
Setting corner radius to high values is allowed. As soon as corners overlap, the stylebox will switch to a relative system:
[codeblock lang=text]
height = 30
corner_radius_top_left = 50
corner_radius_bottom_left = 100
[/codeblock]
The relative system now would take the 1:2 ratio of the two left corners to calculate the actual corner width. Both corners added will [b]never[/b] be more than the height. Result:
[codeblock lang=text]
corner_radius_top_left: 10
corner_radius_bottom_left: 20
[/codeblock]

## anti_aliasing :: var StyleBoxFlat.anti_aliasing: bool
Antialiasing draws a small ring around the edges, which fades to transparency. As a result, edges look much smoother. This is only noticeable when using rounded corners or [member skew].
[b]Note:[/b] When using beveled corners with 45-degree angles ([member corner_detail] = 1), it is recommended to set [member anti_aliasing] to [code]false[/code] to ensure crisp visuals and avoid possible visual glitches.

## anti_aliasing_size :: var StyleBoxFlat.anti_aliasing_size: float
This changes the size of the antialiasing effect. [code]1.0[/code] is recommended for an optimal result at 100% scale, identical to how rounded rectangles are rendered in web browsers and most vector drawing software.
[b]Note:[/b] Higher values may produce a blur effect but can also create undesired artifacts on small boxes with large-radius corners.

## bg_color :: var StyleBoxFlat.bg_color: Color
The background color of the stylebox.

## border_blend :: var StyleBoxFlat.border_blend: bool
If [code]true[/code], the border will fade into the background color.

## border_color :: var StyleBoxFlat.border_color: Color
Sets the color of the border.

## border_width_bottom :: var StyleBoxFlat.border_width_bottom: int
Border width for the bottom border.

## border_width_left :: var StyleBoxFlat.border_width_left: int
Border width for the left border.

## border_width_right :: var StyleBoxFlat.border_width_right: int
Border width for the right border.

## border_width_top :: var StyleBoxFlat.border_width_top: int
Border width for the top border.

## corner_detail :: var StyleBoxFlat.corner_detail: int
This sets the number of vertices used for each corner. Higher values result in rounder corners but take more processing power to compute. When choosing a value, you should take the corner radius ([method set_corner_radius_all]) into account.
For corner radii less than 10, [code]4[/code] or [code]5[/code] should be enough. For corner radii less than 30, values between [code]8[/code] and [code]12[/code] should be enough.
A corner detail of [code]1[/code] will result in chamfered corners instead of rounded corners, which is useful for some artistic effects.

## corner_radius_bottom_left :: var StyleBoxFlat.corner_radius_bottom_left: int
The bottom-left corner's radius. If [code]0[/code], the corner is not rounded.

## corner_radius_bottom_right :: var StyleBoxFlat.corner_radius_bottom_right: int
The bottom-right corner's radius. If [code]0[/code], the corner is not rounded.

## corner_radius_top_left :: var StyleBoxFlat.corner_radius_top_left: int
The top-left corner's radius. If [code]0[/code], the corner is not rounded.

## corner_radius_top_right :: var StyleBoxFlat.corner_radius_top_right: int
The top-right corner's radius. If [code]0[/code], the corner is not rounded.

## draw_center :: var StyleBoxFlat.draw_center: bool
Toggles drawing of the inner part of the stylebox.

## expand_margin_bottom :: var StyleBoxFlat.expand_margin_bottom: float
Expands the stylebox outside of the control rect on the bottom edge. Useful in combination with [member border_width_bottom] to draw a border outside the control rect.
[b]Note:[/b] Unlike [member StyleBox.content_margin_bottom], [member expand_margin_bottom] does [i]not[/i] affect the size of the clickable area for [Control]s. This can negatively impact usability if used wrong, as the user may try to click an area of the StyleBox that cannot actually receive clicks.

## expand_margin_left :: var StyleBoxFlat.expand_margin_left: float
Expands the stylebox outside of the control rect on the left edge. Useful in combination with [member border_width_left] to draw a border outside the control rect.
[b]Note:[/b] Unlike [member StyleBox.content_margin_left], [member expand_margin_left] does [i]not[/i] affect the size of the clickable area for [Control]s. This can negatively impact usability if used wrong, as the user may try to click an area of the StyleBox that cannot actually receive clicks.

## expand_margin_right :: var StyleBoxFlat.expand_margin_right: float
Expands the stylebox outside of the control rect on the right edge. Useful in combination with [member border_width_right] to draw a border outside the control rect.
[b]Note:[/b] Unlike [member StyleBox.content_margin_right], [member expand_margin_right] does [i]not[/i] affect the size of the clickable area for [Control]s. This can negatively impact usability if used wrong, as the user may try to click an area of the StyleBox that cannot actually receive clicks.

## expand_margin_top :: var StyleBoxFlat.expand_margin_top: float
Expands the stylebox outside of the control rect on the top edge. Useful in combination with [member border_width_top] to draw a border outside the control rect.
[b]Note:[/b] Unlike [member StyleBox.content_margin_top], [member expand_margin_top] does [i]not[/i] affect the size of the clickable area for [Control]s. This can negatively impact usability if used wrong, as the user may try to click an area of the StyleBox that cannot actually receive clicks.

## shadow_color :: var StyleBoxFlat.shadow_color: Color
The color of the shadow. This has no effect if [member shadow_size] is lower than 1.

## shadow_offset :: var StyleBoxFlat.shadow_offset: Vector2
The shadow offset in pixels. Adjusts the position of the shadow relatively to the stylebox.

## shadow_size :: var StyleBoxFlat.shadow_size: int
The shadow size in pixels.

## skew :: var StyleBoxFlat.skew: Vector2
If set to a non-zero value on either axis, [member skew] distorts the StyleBox horizontally and/or vertically. This can be used for "futuristic"-style UIs. Positive values skew the StyleBox towards the right (X axis) and upwards (Y axis), while negative values skew the StyleBox towards the left (X axis) and downwards (Y axis).
[b]Note:[/b] To ensure text does not touch the StyleBox's edges, consider increasing the [StyleBox]'s content margin (see [member StyleBox.content_margin_bottom]). It is preferable to increase the content margin instead of the expand margin (see [member expand_margin_bottom]), as increasing the expand margin does not increase the size of the clickable area for [Control]s.

## get_border_width :: func StyleBoxFlat.get_border_width(margin: int) -> int
Returns the specified [enum Side]'s border width.

### margin :: int

## get_border_width_min :: func StyleBoxFlat.get_border_width_min() -> int
Returns the smallest border width out of all four borders.

## get_corner_radius :: func StyleBoxFlat.get_corner_radius(corner: int) -> int
Returns the given [param corner]'s radius.

### corner :: int

## get_expand_margin :: func StyleBoxFlat.get_expand_margin(margin: int) -> float
Returns the size of the specified [enum Side]'s expand margin.

### margin :: int

## set_border_width :: func StyleBoxFlat.set_border_width(margin: int, width: int) -> void
Sets the specified [enum Side]'s border width to [param width] pixels.

### margin :: int

### width :: int

## set_border_width_all :: func StyleBoxFlat.set_border_width_all(width: int) -> void
Sets the border width to [param width] pixels for all sides.

### width :: int

## set_corner_radius :: func StyleBoxFlat.set_corner_radius(corner: int, radius: int) -> void
Sets the corner radius to [param radius] pixels for the given [param corner].

### corner :: int

### radius :: int

## set_corner_radius_all :: func StyleBoxFlat.set_corner_radius_all(radius: int) -> void
Sets the corner radius to [param radius] pixels for all corners.

### radius :: int

## set_expand_margin :: func StyleBoxFlat.set_expand_margin(margin: int, size: float) -> void
Sets the expand margin to [param size] pixels for the specified [enum Side].

### margin :: int

### size :: float

## set_expand_margin_all :: func StyleBoxFlat.set_expand_margin_all(size: float) -> void
Sets the expand margin to [param size] pixels for all sides.

### size :: float
