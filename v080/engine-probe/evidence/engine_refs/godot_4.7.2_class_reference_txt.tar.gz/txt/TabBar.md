# TabBar :: <Native> class TabBar extends Control
A control that provides a horizontal bar with tabs.
A control that provides a horizontal bar with tabs. Similar to [TabContainer] but is only in charge of drawing tabs, not interacting with children.

## ALIGNMENT_LEFT :: const TabBar.ALIGNMENT_LEFT: AlignmentMode = 0
Aligns tabs to the left.

## ALIGNMENT_CENTER :: const TabBar.ALIGNMENT_CENTER: AlignmentMode = 1
Aligns tabs in the middle.

## ALIGNMENT_RIGHT :: const TabBar.ALIGNMENT_RIGHT: AlignmentMode = 2
Aligns tabs to the right.

## ALIGNMENT_MAX :: const TabBar.ALIGNMENT_MAX: AlignmentMode = 3
Represents the size of the [enum AlignmentMode] enum.

## CLOSE_BUTTON_SHOW_NEVER :: const TabBar.CLOSE_BUTTON_SHOW_NEVER: CloseButtonDisplayPolicy = 0
Never show the close buttons.

## CLOSE_BUTTON_SHOW_ACTIVE_ONLY :: const TabBar.CLOSE_BUTTON_SHOW_ACTIVE_ONLY: CloseButtonDisplayPolicy = 1
Only show the close button on the currently active tab.

## CLOSE_BUTTON_SHOW_ALWAYS :: const TabBar.CLOSE_BUTTON_SHOW_ALWAYS: CloseButtonDisplayPolicy = 2
Show the close button on all tabs.

## CLOSE_BUTTON_MAX :: const TabBar.CLOSE_BUTTON_MAX: CloseButtonDisplayPolicy = 3
Represents the size of the [enum CloseButtonDisplayPolicy] enum.

## clip_tabs :: var TabBar.clip_tabs: bool
If [code]true[/code], tabs overflowing this node's width will be hidden, displaying two navigation buttons instead. Otherwise, this node's minimum size is updated so that all tabs are visible.

## close_with_middle_mouse :: var TabBar.close_with_middle_mouse: bool
If [code]true[/code], middle-clicking on a tab will emit the [signal tab_close_pressed] signal.

## current_tab :: var TabBar.current_tab: int
The index of the current selected tab. A value of [code]-1[/code] means that no tab is selected and can only be set when [member deselect_enabled] is [code]true[/code] or if all tabs are hidden or disabled.

## deselect_enabled :: var TabBar.deselect_enabled: bool
If [code]true[/code], all tabs can be deselected so that no tab is selected. Click on the current tab to deselect it.

## drag_to_rearrange_enabled :: var TabBar.drag_to_rearrange_enabled: bool
If [code]true[/code], tabs can be rearranged with mouse drag.

## focus_mode :: var TabBar.focus_mode: Control.FocusMode

## max_tab_width :: var TabBar.max_tab_width: int
Sets the maximum width which all tabs should be limited to. Unlimited if set to [code]0[/code].

## scroll_to_selected :: var TabBar.scroll_to_selected: bool
If [code]true[/code], the tab offset will be changed to keep the currently selected tab visible.

## scrolling_enabled :: var TabBar.scrolling_enabled: bool
if [code]true[/code], the mouse's scroll wheel can be used to navigate the scroll view.

## select_with_rmb :: var TabBar.select_with_rmb: bool
If [code]true[/code], enables selecting a tab with the right mouse button.

## switch_on_drag_hover :: var TabBar.switch_on_drag_hover: bool
If [code]true[/code], hovering over a tab while dragging something will switch to that tab. Does not have effect when hovering another tab to rearrange. The delay for when this happens is dictated by [theme_item hover_switch_wait_msec].

## tab_alignment :: var TabBar.tab_alignment: TabBar.AlignmentMode
The horizontal alignment of the tabs.

## tab_close_display_policy :: var TabBar.tab_close_display_policy: TabBar.CloseButtonDisplayPolicy
When the close button will appear on the tabs.

## tab_count :: var TabBar.tab_count: int
The number of tabs currently in the bar.

## tab_{index}/disabled :: var TabBar.tab_{index}/disabled: bool
If [code]true[/code], the tab at [code]index[/code] is disabled.
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. tab_count - 1[/code] range.

## tab_{index}/icon :: var TabBar.tab_{index}/icon: Texture2D
If [code]true[/code], the tab at [code]index[/code] is hidden.
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. tab_count - 1[/code] range.

## tab_{index}/title :: var TabBar.tab_{index}/title: String
The title text of the tab at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. tab_count - 1[/code] range.

## tab_{index}/tooltip :: var TabBar.tab_{index}/tooltip: String
The tooltip text of the tab at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. tab_count - 1[/code] range.

## tabs_rearrange_group :: var TabBar.tabs_rearrange_group: int
[TabBar]s with the same rearrange group ID will allow dragging the tabs between them. Enable drag with [member drag_to_rearrange_enabled].
Setting this to [code]-1[/code] will disable rearranging between [TabBar]s.

## drop_mark_color :: <Theme> var TabBar.drop_mark_color: Color
Modulation color for the [theme_item drop_mark] icon.

## font_disabled_color :: <Theme> var TabBar.font_disabled_color: Color
Font color of disabled tabs.

## font_hovered_color :: <Theme> var TabBar.font_hovered_color: Color
Font color of the currently hovered tab. Does not apply to the selected tab.

## font_outline_color :: <Theme> var TabBar.font_outline_color: Color
The tint of text outline of the tab name.

## font_selected_color :: <Theme> var TabBar.font_selected_color: Color
Font color of the currently selected tab.

## font_unselected_color :: <Theme> var TabBar.font_unselected_color: Color
Font color of the other, unselected tabs.

## icon_disabled_color :: <Theme> var TabBar.icon_disabled_color: Color
Icon color of disabled tabs.

## icon_hovered_color :: <Theme> var TabBar.icon_hovered_color: Color
Icon color of the currently hovered tab. Does not apply to the selected tab.

## icon_selected_color :: <Theme> var TabBar.icon_selected_color: Color
Icon color of the currently selected tab.

## icon_unselected_color :: <Theme> var TabBar.icon_unselected_color: Color
Icon color of the other, unselected tabs.

## h_separation :: <Theme> var TabBar.h_separation: int
The horizontal separation between the elements inside tabs.

## hover_switch_wait_msec :: <Theme> var TabBar.hover_switch_wait_msec: int
During a drag-and-drop, this is how many milliseconds to wait before switching the tab.

## icon_max_width :: <Theme> var TabBar.icon_max_width: int
The maximum allowed width of the tab's icon. This limit is applied on top of the default size of the icon, but before the value set with [method set_tab_icon_max_width]. The height is adjusted according to the icon's ratio.

## outline_size :: <Theme> var TabBar.outline_size: int
The size of the tab text outline.
[b]Note:[/b] If using a font with [member FontFile.multichannel_signed_distance_field] enabled, its [member FontFile.msdf_pixel_range] must be set to at least [i]twice[/i] the value of [theme_item outline_size] for outline rendering to look correct. Otherwise, the outline may appear to be cut off earlier than intended.

## tab_separation :: <Theme> var TabBar.tab_separation: int
The space between tabs in the tab bar.

## font :: <Theme> var TabBar.font: Font
The font used to draw tab names.

## font_size :: <Theme> var TabBar.font_size: int
Font size of the tab names.

## close :: <Theme> var TabBar.close: Texture2D
The icon for the close button (see [member tab_close_display_policy]).

## decrement :: <Theme> var TabBar.decrement: Texture2D
Icon for the left arrow button that appears when there are too many tabs to fit in the container width. When the button is disabled (i.e. the first tab is visible), it appears semi-transparent.

## decrement_highlight :: <Theme> var TabBar.decrement_highlight: Texture2D
Icon for the left arrow button that appears when there are too many tabs to fit in the container width. Used when the button is being hovered with the cursor.

## drop_mark :: <Theme> var TabBar.drop_mark: Texture2D
Icon shown to indicate where a dragged tab will be dropped (see [member drag_to_rearrange_enabled]).

## increment :: <Theme> var TabBar.increment: Texture2D
Icon for the right arrow button that appears when there are too many tabs to fit in the container width. When the button is disabled (i.e. the last tab is visible) it appears semi-transparent.

## increment_highlight :: <Theme> var TabBar.increment_highlight: Texture2D
Icon for the right arrow button that appears when there are too many tabs to fit in the container width. Used when the button is being hovered with the cursor.

## button_highlight :: <Theme> var TabBar.button_highlight: StyleBox
Background of the tab and close buttons when they're being hovered with the cursor.

## button_pressed :: <Theme> var TabBar.button_pressed: StyleBox
Background of the tab and close buttons when it's being pressed.

## tab_disabled :: <Theme> var TabBar.tab_disabled: StyleBox
The style of disabled tabs.

## tab_focus :: <Theme> var TabBar.tab_focus: StyleBox
[StyleBox] used when the [TabBar] is focused. The [theme_item tab_focus] [StyleBox] is displayed [i]over[/i] the base [StyleBox] of the selected tab, so a partially transparent [StyleBox] should be used to ensure the base [StyleBox] remains visible. A [StyleBox] that represents an outline or an underline works well for this purpose. To disable the focus visual effect, assign a [StyleBoxEmpty] resource. Note that disabling the focus visual effect will harm keyboard/controller navigation usability, so this is not recommended for accessibility reasons.

## tab_hovered :: <Theme> var TabBar.tab_hovered: StyleBox
The style of the currently hovered tab. Does not apply to the selected tab.
[b]Note:[/b] This style will be drawn with the same width as [theme_item tab_unselected] at minimum.

## tab_selected :: <Theme> var TabBar.tab_selected: StyleBox
The style of the currently selected tab.

## tab_unselected :: <Theme> var TabBar.tab_unselected: StyleBox
The style of the other, unselected tabs.

## add_tab :: func TabBar.add_tab(title: String = "", icon: Texture2D = null) -> void
Adds a new tab.

### title :: String

### icon :: Texture2D

## clear_tabs :: func TabBar.clear_tabs() -> void
Clears all tabs.

## ensure_tab_visible :: func TabBar.ensure_tab_visible(idx: int) -> void
Moves the scroll view to make the tab visible.

### idx :: int

## get_offset_buttons_visible :: func TabBar.get_offset_buttons_visible() -> bool
Returns [code]true[/code] if the offset buttons (the ones that appear when there's not enough space for all tabs) are visible.

## get_previous_tab :: func TabBar.get_previous_tab() -> int
Returns the previously active tab index.

## get_tab_button_icon :: func TabBar.get_tab_button_icon(tab_idx: int) -> Texture2D
Returns the icon for the right button of the tab at index [param tab_idx] or [code]null[/code] if the right button has no icon.

### tab_idx :: int

## get_tab_icon :: func TabBar.get_tab_icon(tab_idx: int) -> Texture2D
Returns the icon for the tab at index [param tab_idx] or [code]null[/code] if the tab has no icon.

### tab_idx :: int

## get_tab_icon_max_width :: func TabBar.get_tab_icon_max_width(tab_idx: int) -> int
Returns the maximum allowed width of the icon for the tab at index [param tab_idx].

### tab_idx :: int

## get_tab_idx_at_point :: func TabBar.get_tab_idx_at_point(point: Vector2) -> int
Returns the index of the tab at local coordinates [param point]. Returns [code]-1[/code] if the point is outside the control boundaries or if there's no tab at the queried position.

### point :: Vector2

## get_tab_language :: func TabBar.get_tab_language(tab_idx: int) -> String
Returns tab title language code.

### tab_idx :: int

## get_tab_metadata :: func TabBar.get_tab_metadata(tab_idx: int) -> Variant
Returns the metadata value set to the tab at index [param tab_idx] using [method set_tab_metadata]. If no metadata was previously set, returns [code]null[/code] by default.

### tab_idx :: int

## get_tab_offset :: func TabBar.get_tab_offset() -> int
Returns the number of hidden tabs offsetted to the left.

## get_tab_rect :: func TabBar.get_tab_rect(tab_idx: int) -> Rect2
Returns tab [Rect2] with local position and size.

### tab_idx :: int

## get_tab_text_direction :: func TabBar.get_tab_text_direction(tab_idx: int) -> int
Returns tab title text base writing direction.

### tab_idx :: int

## get_tab_title :: func TabBar.get_tab_title(tab_idx: int) -> String
Returns the title of the tab at index [param tab_idx].

### tab_idx :: int

## get_tab_tooltip :: func TabBar.get_tab_tooltip(tab_idx: int) -> String
Returns the tooltip text of the tab at index [param tab_idx].

### tab_idx :: int

## is_tab_disabled :: func TabBar.is_tab_disabled(tab_idx: int) -> bool
Returns [code]true[/code] if the tab at index [param tab_idx] is disabled.

### tab_idx :: int

## is_tab_hidden :: func TabBar.is_tab_hidden(tab_idx: int) -> bool
Returns [code]true[/code] if the tab at index [param tab_idx] is hidden.

### tab_idx :: int

## move_tab :: func TabBar.move_tab(from: int, to: int) -> void
Moves a tab from [param from] to [param to].

### from :: int

### to :: int

## remove_tab :: func TabBar.remove_tab(tab_idx: int) -> void
Removes the tab at index [param tab_idx].

### tab_idx :: int

## select_next_available :: func TabBar.select_next_available() -> bool
Selects the first available tab with greater index than the currently selected. Returns [code]true[/code] if tab selection changed.

## select_previous_available :: func TabBar.select_previous_available() -> bool
Selects the first available tab with lower index than the currently selected. Returns [code]true[/code] if tab selection changed.

## set_tab_button_icon :: func TabBar.set_tab_button_icon(tab_idx: int, icon: Texture2D) -> void
Sets an [param icon] for the button of the tab at index [param tab_idx] (located to the right, before the close button), making it visible and clickable (See [signal tab_button_pressed]). Giving it a [code]null[/code] value will hide the button.

### tab_idx :: int

### icon :: Texture2D

## set_tab_disabled :: func TabBar.set_tab_disabled(tab_idx: int, disabled: bool) -> void
If [param disabled] is [code]true[/code], disables the tab at index [param tab_idx], making it non-interactable.

### tab_idx :: int

### disabled :: bool

## set_tab_hidden :: func TabBar.set_tab_hidden(tab_idx: int, hidden: bool) -> void
If [param hidden] is [code]true[/code], hides the tab at index [param tab_idx], making it disappear from the tab area.

### tab_idx :: int

### hidden :: bool

## set_tab_icon :: func TabBar.set_tab_icon(tab_idx: int, icon: Texture2D) -> void
Sets an [param icon] for the tab at index [param tab_idx].

### tab_idx :: int

### icon :: Texture2D

## set_tab_icon_max_width :: func TabBar.set_tab_icon_max_width(tab_idx: int, width: int) -> void
Sets the maximum allowed width of the icon for the tab at index [param tab_idx]. This limit is applied on top of the default size of the icon and on top of [theme_item icon_max_width]. The height is adjusted according to the icon's ratio.

### tab_idx :: int

### width :: int

## set_tab_language :: func TabBar.set_tab_language(tab_idx: int, language: String) -> void
Sets the language code of the title for the tab at index [param tab_idx] to [param language]. This is used for line-breaking and text shaping algorithms. If [param language] is empty, the current locale is used.

### tab_idx :: int

### language :: String

## set_tab_metadata :: func TabBar.set_tab_metadata(tab_idx: int, metadata: Variant) -> void
Sets the metadata value for the tab at index [param tab_idx], which can be retrieved later using [method get_tab_metadata].

### tab_idx :: int

### metadata :: Variant

## set_tab_text_direction :: func TabBar.set_tab_text_direction(tab_idx: int, direction: int) -> void
Sets tab title base writing direction.

### tab_idx :: int

### direction :: int

## set_tab_title :: func TabBar.set_tab_title(tab_idx: int, title: String) -> void
Sets a [param title] for the tab at index [param tab_idx].

### tab_idx :: int

### title :: String

## set_tab_tooltip :: func TabBar.set_tab_tooltip(tab_idx: int, tooltip: String) -> void
Sets a [param tooltip] for tab at index [param tab_idx].
[b]Note:[/b] By default, if the [param tooltip] is empty and the tab text is truncated (not all characters fit into the tab), the title will be displayed as a tooltip. To hide the tooltip, assign [code]" "[/code] as the [param tooltip] text.

### tab_idx :: int

### tooltip :: String

## active_tab_rearranged :: func TabBar.active_tab_rearranged(idx_to: int) -> void
Emitted when the active tab is rearranged via mouse drag. See [member drag_to_rearrange_enabled].

### idx_to :: int

## tab_button_pressed :: func TabBar.tab_button_pressed(tab: int) -> void
Emitted when a tab's right button is pressed. See [method set_tab_button_icon].

### tab :: int

## tab_changed :: func TabBar.tab_changed(tab: int) -> void
Emitted when switching to another tab.

### tab :: int

## tab_clicked :: func TabBar.tab_clicked(tab: int) -> void
Emitted when a tab is clicked, even if it is the current tab.

### tab :: int

## tab_close_pressed :: func TabBar.tab_close_pressed(tab: int) -> void
Emitted when a tab's close button is pressed or, if [member close_with_middle_mouse] is [code]true[/code], when middle-clicking on a tab.
[b]Note:[/b] Tabs are not removed automatically; this behavior needs to be coded manually. For example:
[codeblocks]
[gdscript]
$TabBar.tab_close_pressed.connect($TabBar.remove_tab)
[/gdscript]
[csharp]
GetNode<TabBar>("TabBar").TabClosePressed += GetNode<TabBar>("TabBar").RemoveTab;
[/csharp]
[/codeblocks]

### tab :: int

## tab_hovered :: func TabBar.tab_hovered(tab: int) -> void
Emitted when a tab is hovered by the mouse.

### tab :: int

## tab_rmb_clicked :: func TabBar.tab_rmb_clicked(tab: int) -> void
Emitted when a tab is right-clicked.

### tab :: int

## tab_selected :: func TabBar.tab_selected(tab: int) -> void
Emitted when a tab is selected via click, directional input, or script, even if it is the current tab.

### tab :: int
