# EditorExportPlugin :: <Native> class EditorExportPlugin extends RefCounted
A script that is executed when exporting the project.
[EditorExportPlugin]s are automatically invoked whenever the user exports the project. They can be used to modify scenes and resources during project export based on what [url=https://docs.godotengine.org/en/4.7/tutorials/export/feature_tags.html]Feature Tags[/url] are set. For each plugin, [method _export_begin] is called at the beginning of the export process and then [method _export_file] is called for each exported file.
Register a [EditorExportPlugin] by creating a new [EditorPlugin] and calling its [method EditorPlugin.add_export_plugin] method.

## _begin_customize_resources :: func EditorExportPlugin._begin_customize_resources(platform: EditorExportPlatform, features: PackedStringArray) -> bool
Return [code]true[/code] if this plugin will customize resources based on the platform and features used.
When enabled, [method _get_customization_configuration_hash] and [method _customize_resource] will be called and must be implemented.

### platform :: EditorExportPlatform

### features :: PackedStringArray

## _begin_customize_scenes :: func EditorExportPlugin._begin_customize_scenes(platform: EditorExportPlatform, features: PackedStringArray) -> bool
Return [code]true[/code] if this plugin will customize scenes based on the platform and features used.
When enabled, [method _get_customization_configuration_hash] and [method _customize_scene] will be called and must be implemented.
[b]Note:[/b] [method _customize_scene] will only be called for scenes that have been modified since the last export.

### platform :: EditorExportPlatform

### features :: PackedStringArray

## _customize_resource :: func EditorExportPlugin._customize_resource(resource: Resource, path: String) -> Resource
Customize a resource. If changes are made to it, return the same or a new resource. Otherwise, return [code]null[/code]. When a new resource is returned, [param resource] will be replaced by a copy of the new resource.
The [param path] argument is only used when customizing an actual file, otherwise this means that this resource is part of another one and it will be empty.
Implementing this method is required if [method _begin_customize_resources] returns [code]true[/code].
[b]Note:[/b] When customizing any of the following types and returning another resource, the other resource should not be skipped using [method skip] in [method _export_file]:
- [AtlasTexture]
- [CompressedCubemap]
- [CompressedCubemapArray]
- [CompressedTexture2D]
- [CompressedTexture2DArray]
- [CompressedTexture3D]

### resource :: Resource

### path :: String

## _customize_scene :: func EditorExportPlugin._customize_scene(scene: Node, path: String) -> Node
Customize a scene. If changes are made to it, return the same or a new scene. Otherwise, return [code]null[/code]. If a new scene is returned, it is up to you to dispose of the old one.
Implementing this method is required if [method _begin_customize_scenes] returns [code]true[/code].
[b]Note:[/b] To change a variable in your scene, use the [code]@export[/code] annotation when declaring it.

### scene :: Node

### path :: String

## _end_customize_resources :: func EditorExportPlugin._end_customize_resources() -> void
This is called when the customization process for resources ends.

## _end_customize_scenes :: func EditorExportPlugin._end_customize_scenes() -> void
This is called when the customization process for scenes ends.

## _end_generate_apple_embedded_project :: func EditorExportPlugin._end_generate_apple_embedded_project(path: String, will_build_archive: bool) -> void
This is called after Xcode project generation, but before it is built.
[b]Note:[/b] Only supported on iOS and visionOS.

### path :: String

### will_build_archive :: bool

## _export_begin :: func EditorExportPlugin._export_begin(features: PackedStringArray, is_debug: bool, path: String, flags: int) -> void
Virtual method to be overridden by the user. It is called when the export starts and provides all information about the export. [param features] is the list of features for the export, [param is_debug] is [code]true[/code] for debug builds, [param path] is the target path for the exported project. [param flags] is only used when running a runnable profile, e.g. when using native run on Android.

### features :: PackedStringArray

### is_debug :: bool

### path :: String

### flags :: int

## _export_end :: func EditorExportPlugin._export_end() -> void
Virtual method to be overridden by the user. Called when the export is finished.

## _export_file :: func EditorExportPlugin._export_file(path: String, type: String, features: PackedStringArray) -> void
Virtual method to be overridden by the user. Called for each exported file before [method _customize_resource] and [method _customize_scene]. The arguments can be used to identify the file. [param path] is the path of the file, [param type] is the [Resource] represented by the file (e.g. [PackedScene]), and [param features] is the list of features for the export.
Calling [method skip] inside this callback will make the file not included in the export.

### path :: String

### type :: String

### features :: PackedStringArray

## _get_android_dependencies :: func EditorExportPlugin._get_android_dependencies(platform: EditorExportPlatform, debug: bool) -> PackedStringArray
Virtual method to be overridden by the user. This is called to retrieve the set of Android dependencies provided by this plugin. Each returned Android dependency should have the format of an Android remote binary dependency: [code]org.godot.example:my-plugin:0.0.0[/code]
For more information see [url=https://developer.android.com/build/dependencies?agpversion=4.1#dependency-types]Android documentation on dependencies[/url].
[b]Note:[/b] Only supported on Android and requires [member EditorExportPlatformAndroid.gradle_build/use_gradle_build] to be enabled.

### platform :: EditorExportPlatform

### debug :: bool

## _get_android_dependencies_maven_repos :: func EditorExportPlugin._get_android_dependencies_maven_repos(platform: EditorExportPlatform, debug: bool) -> PackedStringArray
Virtual method to be overridden by the user. This is called to retrieve the URLs of Maven repositories for the set of Android dependencies provided by this plugin.
For more information see [url=https://docs.gradle.org/current/userguide/dependency_management.html#sec:maven_repo]Gradle documentation on dependency management[/url].
[b]Note:[/b] Google's Maven repo and the Maven Central repo are already included by default.
[b]Note:[/b] Only supported on Android and requires [member EditorExportPlatformAndroid.gradle_build/use_gradle_build] to be enabled.

### platform :: EditorExportPlatform

### debug :: bool

## _get_android_libraries :: func EditorExportPlugin._get_android_libraries(platform: EditorExportPlatform, debug: bool) -> PackedStringArray
Virtual method to be overridden by the user. This is called to retrieve the local paths of the Android libraries archive (AAR) files provided by this plugin.
[b]Note:[/b] Relative paths [b]must[/b] be relative to Godot's [code]res://addons/[/code] directory. For example, an AAR file located under [code]res://addons/hello_world_plugin/HelloWorld.release.aar[/code] can be returned as an absolute path using [code]res://addons/hello_world_plugin/HelloWorld.release.aar[/code] or a relative path using [code]hello_world_plugin/HelloWorld.release.aar[/code].
[b]Note:[/b] Only supported on Android and requires [member EditorExportPlatformAndroid.gradle_build/use_gradle_build] to be enabled.

### platform :: EditorExportPlatform

### debug :: bool

## _get_android_manifest_activity_element_contents :: func EditorExportPlugin._get_android_manifest_activity_element_contents(platform: EditorExportPlatform, debug: bool) -> String
Virtual method to be overridden by the user. This is used at export time to update the contents of the [code]activity[/code] element in the generated Android manifest.
[b]Note:[/b] Only supported on Android and requires [member EditorExportPlatformAndroid.gradle_build/use_gradle_build] to be enabled.

### platform :: EditorExportPlatform

### debug :: bool

## _get_android_manifest_application_element_contents :: func EditorExportPlugin._get_android_manifest_application_element_contents(platform: EditorExportPlatform, debug: bool) -> String
Virtual method to be overridden by the user. This is used at export time to update the contents of the [code]application[/code] element in the generated Android manifest.
[b]Note:[/b] Only supported on Android and requires [member EditorExportPlatformAndroid.gradle_build/use_gradle_build] to be enabled.

### platform :: EditorExportPlatform

### debug :: bool

## _get_android_manifest_element_contents :: func EditorExportPlugin._get_android_manifest_element_contents(platform: EditorExportPlatform, debug: bool) -> String
Virtual method to be overridden by the user. This is used at export time to update the contents of the [code]manifest[/code] element in the generated Android manifest.
[b]Note:[/b] Only supported on Android and requires [member EditorExportPlatformAndroid.gradle_build/use_gradle_build] to be enabled.

### platform :: EditorExportPlatform

### debug :: bool

## _get_customization_configuration_hash :: func EditorExportPlugin._get_customization_configuration_hash() -> int
Return a hash based on the configuration passed (for both scenes and resources). This helps keep separate caches for separate export configurations.
Implementing this method is required if [method _begin_customize_resources] returns [code]true[/code].
[b]Note:[/b] [method _customize_resource] and [method _customize_scene] will not be called when the [EditorExportPlugin] script is modified unless this hash changes too.

## _get_export_features :: func EditorExportPlugin._get_export_features(platform: EditorExportPlatform, debug: bool) -> PackedStringArray
Return a [PackedStringArray] of additional features this preset, for the given [param platform], should have.

### platform :: EditorExportPlatform

### debug :: bool

## _get_export_option_visibility :: func EditorExportPlugin._get_export_option_visibility(platform: EditorExportPlatform, option: String) -> bool
Validates [param option] and returns the visibility for the specified [param platform]. The default implementation returns [code]true[/code] for all options.

### platform :: EditorExportPlatform

### option :: String

## _get_export_option_warning :: func EditorExportPlugin._get_export_option_warning(platform: EditorExportPlatform, option: String) -> String
Check the requirements for the given [param option] and return a non-empty warning string if they are not met.
[b]Note:[/b] Use [method get_option] to check the value of the export options.

### platform :: EditorExportPlatform

### option :: String

## _get_export_options :: func EditorExportPlugin._get_export_options(platform: EditorExportPlatform) -> Dictionary[]
Return a list of export options that can be configured for this export plugin.
Each element in the return value is a [Dictionary] with the following keys:
- [code]option[/code]: A dictionary with the structure documented by [method Object.get_property_list], but all keys are optional.
- [code]default_value[/code]: The default value for this option.
- [code]update_visibility[/code]: An optional boolean value. If set to [code]true[/code], the preset will emit [signal Object.property_list_changed] when the option is changed.

### platform :: EditorExportPlatform

## _get_export_options_overrides :: func EditorExportPlugin._get_export_options_overrides(platform: EditorExportPlatform) -> Dictionary
Return a [Dictionary] of override values for export options, that will be used instead of user-provided values. Overridden options will be hidden from the user interface.
[codeblock]
class MyExportPlugin extends EditorExportPlugin:
	func _get_name() -> String:
		return "MyExportPlugin"

	func _supports_platform(platform) -> bool:
		if platform is EditorExportPlatformPC:
			# Run on all desktop platforms including Windows, MacOS and Linux.
			return true
		return false

	func _get_export_options_overrides(platform) -> Dictionary:
		# Override "Embed PCK" to always be enabled.
		return {
			"binary_format/embed_pck": true,
		}
[/codeblock]

### platform :: EditorExportPlatform

## _get_name :: func EditorExportPlugin._get_name() -> String
Return the name identifier of this plugin (for future identification by the exporter). The plugins are sorted by name before exporting.
Implementing this method is required.

## _should_update_export_options :: func EditorExportPlugin._should_update_export_options(platform: EditorExportPlatform) -> bool
Return [code]true[/code] if the result of [method _get_export_options] has changed and the export options of the preset corresponding to [param platform] should be updated.

### platform :: EditorExportPlatform

## _supports_platform :: func EditorExportPlugin._supports_platform(platform: EditorExportPlatform) -> bool
Return [code]true[/code] if the plugin supports the given [param platform].

### platform :: EditorExportPlatform

## _update_android_prebuilt_manifest :: func EditorExportPlugin._update_android_prebuilt_manifest(platform: EditorExportPlatform, manifest_data: PackedByteArray) -> PackedByteArray
Provide access to the Android prebuilt manifest and allows the plugin to modify it if needed.
Implementers of this virtual method should take the binary manifest data from [param manifest_data], copy it, modify it, and then return it with the modifications.
If no modifications are needed, then an empty [PackedByteArray] should be returned.

### platform :: EditorExportPlatform

### manifest_data :: PackedByteArray

## add_apple_embedded_platform_bundle_file :: func EditorExportPlugin.add_apple_embedded_platform_bundle_file(path: String) -> void
Adds an Apple embedded platform bundle file from the given [param path] to the exported project.

### path :: String

## add_apple_embedded_platform_cpp_code :: func EditorExportPlugin.add_apple_embedded_platform_cpp_code(code: String) -> void
Adds C++ code to the Apple embedded platform export. The final code is created from the code appended by each active export plugin.

### code :: String

## add_apple_embedded_platform_embedded_framework :: func EditorExportPlugin.add_apple_embedded_platform_embedded_framework(path: String) -> void
Adds a dynamic library (*.dylib, *.framework) to the Linking Phase in the Apple embedded platform's Xcode project and embeds it into the resulting binary.
[b]Note:[/b] For static libraries (*.a), this works in the same way as [method add_apple_embedded_platform_framework].
[b]Note:[/b] This method should not be used for System libraries as they are already present on the device.

### path :: String

## add_apple_embedded_platform_framework :: func EditorExportPlugin.add_apple_embedded_platform_framework(path: String) -> void
Adds a static library (*.a) or a dynamic library (*.dylib, *.framework) to the Linking Phase to the Apple embedded platform's Xcode project.

### path :: String

## add_apple_embedded_platform_linker_flags :: func EditorExportPlugin.add_apple_embedded_platform_linker_flags(flags: String) -> void
Adds linker flags for the Apple embedded platform export.

### flags :: String

## add_apple_embedded_platform_plist_content :: func EditorExportPlugin.add_apple_embedded_platform_plist_content(plist_content: String) -> void
Adds additional fields to the Apple embedded platform's project Info.plist file.

### plist_content :: String

## add_apple_embedded_platform_project_static_lib :: func EditorExportPlugin.add_apple_embedded_platform_project_static_lib(path: String) -> void
Adds a static library from the given [param path] to the Apple embedded platform project.

### path :: String

## add_file :: func EditorExportPlugin.add_file(path: String, file: PackedByteArray, remap: bool) -> void
Adds a custom file to be exported. [param path] is the virtual path that can be used to load the file, [param file] is the binary data of the file.
When called inside [method _export_file] and [param remap] is [code]true[/code], the current file will not be exported, but instead remapped to this custom file. [param remap] is ignored when called in other places.
[param file] will not be imported, so consider using [method _customize_resource] to remap imported resources.

### path :: String

### file :: PackedByteArray

### remap :: bool

## add_ios_bundle_file :: func EditorExportPlugin.add_ios_bundle_file(path: String) -> void
Adds an iOS bundle file from the given [param path] to the exported project.

### path :: String

## add_ios_cpp_code :: func EditorExportPlugin.add_ios_cpp_code(code: String) -> void
Adds C++ code to the iOS export. The final code is created from the code appended by each active export plugin.

### code :: String

## add_ios_embedded_framework :: func EditorExportPlugin.add_ios_embedded_framework(path: String) -> void
Adds a dynamic library (*.dylib, *.framework) to Linking Phase in iOS's Xcode project and embeds it into resulting binary.
[b]Note:[/b] For static libraries (*.a), this works the in same way as [method add_apple_embedded_platform_framework].
[b]Note:[/b] This method should not be used for System libraries as they are already present on the device.

### path :: String

## add_ios_framework :: func EditorExportPlugin.add_ios_framework(path: String) -> void
Adds a static library (*.a) or a dynamic library (*.dylib, *.framework) to the Linking Phase to the iOS Xcode project.

### path :: String

## add_ios_linker_flags :: func EditorExportPlugin.add_ios_linker_flags(flags: String) -> void
Adds linker flags for the iOS export.

### flags :: String

## add_ios_plist_content :: func EditorExportPlugin.add_ios_plist_content(plist_content: String) -> void
Adds additional fields to the iOS project Info.plist file.

### plist_content :: String

## add_ios_project_static_lib :: func EditorExportPlugin.add_ios_project_static_lib(path: String) -> void
Adds a static library from the given [param path] to the iOS project.

### path :: String

## add_macos_plugin_file :: func EditorExportPlugin.add_macos_plugin_file(path: String) -> void
Adds file or directory matching [param path] to [code]PlugIns[/code] directory of macOS app bundle.
[b]Note:[/b] This is useful only for macOS exports.

### path :: String

## add_shared_object :: func EditorExportPlugin.add_shared_object(path: String, tags: PackedStringArray, target: String) -> void
Adds a shared object or a directory containing only shared objects with the given [param tags] and destination [param path].
[b]Note:[/b] In case of macOS exports, those shared objects will be added to [code]Frameworks[/code] directory of app bundle.
In case of a directory code-sign will error if you place non code object in directory.

### path :: String

### tags :: PackedStringArray

### target :: String

## get_export_platform :: func EditorExportPlugin.get_export_platform() -> EditorExportPlatform
Returns currently used export platform.

## get_export_preset :: func EditorExportPlugin.get_export_preset() -> EditorExportPreset
Returns currently used export preset.

## get_option :: func EditorExportPlugin.get_option(name: StringName) -> Variant
Returns the current value of an export option supplied by [method _get_export_options].

### name :: StringName

## skip :: func EditorExportPlugin.skip() -> void
To be called inside [method _export_file]. Skips the current file, so it's not included in the export.
