# VisualShaderNodeTransformParameter :: <Native> class VisualShaderNodeTransformParameter extends VisualShaderNodeParameter
A [Transform3D] parameter for use within the visual shader graph.
Translated to [code]uniform mat4[/code] in the shader language.

## default_value :: var VisualShaderNodeTransformParameter.default_value: Transform3D
A default value to be assigned within the shader.

## default_value_enabled :: var VisualShaderNodeTransformParameter.default_value_enabled: bool
Enables usage of the [member default_value].
