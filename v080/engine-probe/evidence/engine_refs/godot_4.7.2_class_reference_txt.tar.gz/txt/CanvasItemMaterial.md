# CanvasItemMaterial :: <Native> class CanvasItemMaterial extends Material
A material for [CanvasItem]s.
[CanvasItemMaterial]s provide a means of modifying the textures associated with a CanvasItem. They specialize in describing blend and lighting behaviors for textures. Use a [ShaderMaterial] to more fully customize a material's interactions with a [CanvasItem].

## BLEND_MODE_MIX :: const CanvasItemMaterial.BLEND_MODE_MIX: BlendMode = 0
Mix blending mode. Colors are assumed to be independent of the alpha (opacity) value.

## BLEND_MODE_ADD :: const CanvasItemMaterial.BLEND_MODE_ADD: BlendMode = 1
Additive blending mode.

## BLEND_MODE_SUB :: const CanvasItemMaterial.BLEND_MODE_SUB: BlendMode = 2
Subtractive blending mode.

## BLEND_MODE_MUL :: const CanvasItemMaterial.BLEND_MODE_MUL: BlendMode = 3
Multiplicative blending mode.

## BLEND_MODE_PREMULT_ALPHA :: const CanvasItemMaterial.BLEND_MODE_PREMULT_ALPHA: BlendMode = 4
Mix blending mode. Colors are assumed to be premultiplied by the alpha (opacity) value.

## LIGHT_MODE_NORMAL :: const CanvasItemMaterial.LIGHT_MODE_NORMAL: LightMode = 0
Render the material using both light and non-light sensitive material properties.

## LIGHT_MODE_UNSHADED :: const CanvasItemMaterial.LIGHT_MODE_UNSHADED: LightMode = 1
Render the material as if there were no light.

## LIGHT_MODE_LIGHT_ONLY :: const CanvasItemMaterial.LIGHT_MODE_LIGHT_ONLY: LightMode = 2
Render the material as if there were only light.

## blend_mode :: var CanvasItemMaterial.blend_mode: CanvasItemMaterial.BlendMode
The manner in which a material's rendering is applied to underlying textures.

## light_mode :: var CanvasItemMaterial.light_mode: CanvasItemMaterial.LightMode
The manner in which material reacts to lighting.

## particles_anim_h_frames :: var CanvasItemMaterial.particles_anim_h_frames: int
The number of columns in the spritesheet assigned as [Texture2D] for a [GPUParticles2D] or [CPUParticles2D].
[b]Note:[/b] This property is only used and visible in the editor if [member particles_animation] is [code]true[/code].

## particles_anim_loop :: var CanvasItemMaterial.particles_anim_loop: bool
If [code]true[/code], the particles animation will loop.
[b]Note:[/b] This property is only used and visible in the editor if [member particles_animation] is [code]true[/code].

## particles_anim_v_frames :: var CanvasItemMaterial.particles_anim_v_frames: int
The number of rows in the spritesheet assigned as [Texture2D] for a [GPUParticles2D] or [CPUParticles2D].
[b]Note:[/b] This property is only used and visible in the editor if [member particles_animation] is [code]true[/code].

## particles_animation :: var CanvasItemMaterial.particles_animation: bool
If [code]true[/code], enable spritesheet-based animation features when assigned to [GPUParticles2D] and [CPUParticles2D] nodes. The [member ParticleProcessMaterial.anim_speed_max] or [member CPUParticles2D.anim_speed_max] should also be set to a positive value for the animation to play.
This property (and other [code]particles_anim_*[/code] properties that depend on it) has no effect on other types of nodes.
