# GrooveJoint2D :: <Native> class GrooveJoint2D extends Joint2D
A physics joint that restricts the movement of two 2D physics bodies to a fixed axis.
A physics joint that restricts the movement of two 2D physics bodies to a fixed axis. For example, a [StaticBody2D] representing a piston base can be attached to a [RigidBody2D] representing the piston head, moving up and down.

## initial_offset :: var GrooveJoint2D.initial_offset: float
The body B's initial anchor position defined by the joint's origin and a local offset [member initial_offset] along the joint's Y axis (along the groove).

## length :: var GrooveJoint2D.length: float
The groove's length. The groove is from the joint's origin towards [member length] along the joint's local Y axis.
