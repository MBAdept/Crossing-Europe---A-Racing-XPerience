# ImporterMeshInstance3D :: <Native> class ImporterMeshInstance3D extends Node3D


## cast_shadow :: var ImporterMeshInstance3D.cast_shadow: GeometryInstance3D.ShadowCastingSetting

## layer_mask :: var ImporterMeshInstance3D.layer_mask: int

## mesh :: var ImporterMeshInstance3D.mesh: ImporterMesh

## skeleton_path :: var ImporterMeshInstance3D.skeleton_path: NodePath

## skin :: var ImporterMeshInstance3D.skin: Skin

## visibility_range_begin :: var ImporterMeshInstance3D.visibility_range_begin: float

## visibility_range_begin_margin :: var ImporterMeshInstance3D.visibility_range_begin_margin: float

## visibility_range_end :: var ImporterMeshInstance3D.visibility_range_end: float

## visibility_range_end_margin :: var ImporterMeshInstance3D.visibility_range_end_margin: float

## visibility_range_fade_mode :: var ImporterMeshInstance3D.visibility_range_fade_mode: GeometryInstance3D.VisibilityRangeFadeMode
