# PacketPeerStream :: <Native> class PacketPeerStream extends PacketPeer
Wrapper to use a PacketPeer over a StreamPeer.
PacketStreamPeer provides a wrapper for working using packets over a stream. This allows for using packet based code with StreamPeers. PacketPeerStream implements a custom protocol over the StreamPeer, so the user should not read or write to the wrapped StreamPeer directly.
[b]Note:[/b] When exporting to Android, make sure to enable the [code]INTERNET[/code] permission in the Android export preset before exporting the project or using one-click deploy. Otherwise, network communication of any kind will be blocked by Android.

## input_buffer_max_size :: var PacketPeerStream.input_buffer_max_size: int

## output_buffer_max_size :: var PacketPeerStream.output_buffer_max_size: int

## stream_peer :: var PacketPeerStream.stream_peer: StreamPeer
The wrapped [StreamPeer] object.
