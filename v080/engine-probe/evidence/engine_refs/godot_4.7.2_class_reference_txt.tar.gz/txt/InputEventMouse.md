# InputEventMouse :: <Native> class InputEventMouse extends InputEventWithModifiers
Base input event type for mouse events.
Stores general information about mouse events.

## button_mask :: var InputEventMouse.button_mask: MouseButtonMask
The mouse button mask identifier, one of or a bitwise combination of the [enum MouseButton] button masks.

## device :: var InputEventMouse.device: int

## global_position :: var InputEventMouse.global_position: Vector2
When received in [method Node._input] or [method Node._unhandled_input], returns the mouse's position in the root [Viewport] using the coordinate system of the root [Viewport].
When received in [method Control._gui_input], returns the mouse's position in the [CanvasLayer] that the [Control] is in using the coordinate system of the [CanvasLayer].

## position :: var InputEventMouse.position: Vector2
When received in [method Node._input] or [method Node._unhandled_input], returns the mouse's position in the [Viewport] this [Node] is in using the coordinate system of this [Viewport].
When received in [method Control._gui_input], returns the mouse's position in the [Control] using the local coordinate system of the [Control].
