# CircleShape2D :: <Native> class CircleShape2D extends Shape2D
A 2D circle shape used for physics collision.
A 2D circle shape, intended for use in physics. Usually used to provide a shape for a [CollisionShape2D].
[b]Performance:[/b] [CircleShape2D] is fast to check collisions against. It is faster than [RectangleShape2D] and [CapsuleShape2D].

## radius :: var CircleShape2D.radius: float
The circle's radius.
