# OpenXRSpatialCapabilityConfigurationPlaneTracking :: <Native> class OpenXRSpatialCapabilityConfigurationPlaneTracking extends OpenXRSpatialCapabilityConfigurationBaseHeader
Configuration header for plane tracking.
Configuration header for plane tracking. Pass this to [method OpenXRSpatialEntityExtension.create_spatial_context] to create a spatial context with plane tracking capabilities.

## get_enabled_components :: func OpenXRSpatialCapabilityConfigurationPlaneTracking.get_enabled_components() -> PackedInt64Array
Returns the components enabled by this configuration.
[b]Note:[/b] Only valid after this configuration was used to create a spatial context.

## supports_labels :: func OpenXRSpatialCapabilityConfigurationPlaneTracking.supports_labels() -> bool
Returns [code]true[/code] if we support the plane semantic label component (only valid after the OpenXR session has started). You can query these using the [OpenXRSpatialComponentPlaneSemanticLabelList] data object.

## supports_mesh_2d :: func OpenXRSpatialCapabilityConfigurationPlaneTracking.supports_mesh_2d() -> bool
Returns [code]true[/code] if we support the mesh 2D component (only valid after the OpenXR session has started). You can query these using the [OpenXRSpatialComponentMesh2DList] data object.

## supports_polygons :: func OpenXRSpatialCapabilityConfigurationPlaneTracking.supports_polygons() -> bool
Returns [code]true[/code] if we support the polygon 2D component (only valid after the OpenXR session has started). You can query these using the [OpenXRSpatialComponentPolygon2DList] data object.
