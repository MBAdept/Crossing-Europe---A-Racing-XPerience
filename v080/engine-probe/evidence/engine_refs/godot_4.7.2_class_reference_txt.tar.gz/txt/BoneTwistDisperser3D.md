# BoneTwistDisperser3D :: <Native> class BoneTwistDisperser3D extends SkeletonModifier3D
A node that propagates and disperses the child bone's twist to the parent bones.
This [BoneTwistDisperser3D] allows for smooth twist interpolation between multiple bones by dispersing the end bone's twist to the parents. This only changes the twist without changing the global position of each joint.
This is useful for smoothly twisting bones in combination with [CopyTransformModifier3D] and IK.
[b]Note:[/b] If an extracted twist is greater than 180 degrees, flipping occurs. This is similar to [ConvertTransformModifier3D].
[b]Note:[/b] Most methods in this class take an [code]index[/code] parameter. This parameter specifies which setting list entry to return if the IK has multiple entries (e.g. [code]settings/<index>/root_bone_name[/code]).

## DISPERSE_MODE_EVEN :: const BoneTwistDisperser3D.DISPERSE_MODE_EVEN: DisperseMode = 0
Assign amounts so that they monotonically increase from [code]0.0[/code] to [code]1.0[/code], ensuring all weights are equal. For example, with five joints, the amounts would be [code]0.2[/code], [code]0.4[/code], [code]0.6[/code], [code]0.8[/code], and [code]1.0[/code] starting from the root bone.

## DISPERSE_MODE_WEIGHTED :: const BoneTwistDisperser3D.DISPERSE_MODE_WEIGHTED: DisperseMode = 1
Assign amounts so that they monotonically increase from [code]0.0[/code] to [code]1.0[/code], based on the length of the bones between joint segments. See also [method set_weight_position].

## DISPERSE_MODE_CUSTOM :: const BoneTwistDisperser3D.DISPERSE_MODE_CUSTOM: DisperseMode = 2
You can assign arbitrary amounts to the joint list. See also [method set_joint_twist_amount].
When [method is_end_bone_extended] is [code]false[/code], a child of the reference bone exists solely to determine the twist axis, so its custom amount has absolutely no effect at all.

## mutable_bone_axes :: var BoneTwistDisperser3D.mutable_bone_axes: bool
If [code]true[/code], the solver retrieves the bone axis from the bone pose every frame.
If [code]false[/code], the solver retrieves the bone axis from the bone rest and caches it.

## setting_count :: var BoneTwistDisperser3D.setting_count: int
The number of settings.

## clear_settings :: func BoneTwistDisperser3D.clear_settings() -> void
Clears all settings.

## get_damping_curve :: func BoneTwistDisperser3D.get_damping_curve(index: int) -> Curve
Returns the damping curve when [method get_disperse_mode] is [constant DISPERSE_MODE_CUSTOM].

### index :: int

## get_disperse_mode :: func BoneTwistDisperser3D.get_disperse_mode(index: int) -> int
Returns whether to use automatic amount assignment or to allow manual assignment.

### index :: int

## get_end_bone :: func BoneTwistDisperser3D.get_end_bone(index: int) -> int
Returns the end bone index of the bone chain.

### index :: int

## get_end_bone_direction :: func BoneTwistDisperser3D.get_end_bone_direction(index: int) -> int
Returns the tail direction of the end bone of the bone chain when [method is_end_bone_extended] is [code]true[/code].

### index :: int

## get_end_bone_name :: func BoneTwistDisperser3D.get_end_bone_name(index: int) -> String
Returns the end bone name of the bone chain.

### index :: int

## get_joint_bone :: func BoneTwistDisperser3D.get_joint_bone(index: int, joint: int) -> int
Returns the bone index at [param joint] in the bone chain's joint list.

### index :: int

### joint :: int

## get_joint_bone_name :: func BoneTwistDisperser3D.get_joint_bone_name(index: int, joint: int) -> String
Returns the bone name at [param joint] in the bone chain's joint list.

### index :: int

### joint :: int

## get_joint_count :: func BoneTwistDisperser3D.get_joint_count(index: int) -> int
Returns the joint count of the bone chain's joint list.

### index :: int

## get_joint_twist_amount :: func BoneTwistDisperser3D.get_joint_twist_amount(index: int, joint: int) -> float
Returns the twist amount at [param joint] in the bone chain's joint list when [method get_disperse_mode] is [constant DISPERSE_MODE_CUSTOM].

### index :: int

### joint :: int

## get_reference_bone :: func BoneTwistDisperser3D.get_reference_bone(index: int) -> int
Returns the reference bone to extract twist of the setting at [param index].
This bone is either the end of the chain or its parent, depending on [method is_end_bone_extended].

### index :: int

## get_reference_bone_name :: func BoneTwistDisperser3D.get_reference_bone_name(index: int) -> String
Returns the reference bone name to extract twist of the setting at [param index].
This bone is either the end of the chain or its parent, depending on [method is_end_bone_extended].

### index :: int

## get_root_bone :: func BoneTwistDisperser3D.get_root_bone(index: int) -> int
Returns the root bone index of the bone chain.

### index :: int

## get_root_bone_name :: func BoneTwistDisperser3D.get_root_bone_name(index: int) -> String
Returns the root bone name of the bone chain.

### index :: int

## get_twist_from :: func BoneTwistDisperser3D.get_twist_from(index: int) -> Quaternion
Returns the rotation to an arbitrary state before twisting for the current bone pose to extract the twist when [method is_twist_from_rest] is [code]false[/code].

### index :: int

## get_weight_position :: func BoneTwistDisperser3D.get_weight_position(index: int) -> float
Returns the position at which to divide the segment between joints for weight assignment when [method get_disperse_mode] is [constant DISPERSE_MODE_WEIGHTED].

### index :: int

## is_end_bone_extended :: func BoneTwistDisperser3D.is_end_bone_extended(index: int) -> bool
Returns [code]true[/code] if the end bone is extended to have a tail.

### index :: int

## is_twist_from_rest :: func BoneTwistDisperser3D.is_twist_from_rest(index: int) -> bool
Returns [code]true[/code] if extracting the twist amount from the difference between the bone rest and the current bone pose.

### index :: int

## set_damping_curve :: func BoneTwistDisperser3D.set_damping_curve(index: int, curve: Curve) -> void
Sets the damping curve when [method get_disperse_mode] is [constant DISPERSE_MODE_CUSTOM].

### index :: int

### curve :: Curve

## set_disperse_mode :: func BoneTwistDisperser3D.set_disperse_mode(index: int, disperse_mode: int) -> void
Sets whether to use automatic amount assignment or to allow manual assignment.

### index :: int

### disperse_mode :: int

## set_end_bone :: func BoneTwistDisperser3D.set_end_bone(index: int, bone: int) -> void
Sets the end bone index of the bone chain.

### index :: int

### bone :: int

## set_end_bone_direction :: func BoneTwistDisperser3D.set_end_bone_direction(index: int, bone_direction: int) -> void
Sets the end bone tail direction of the bone chain when [method is_end_bone_extended] is [code]true[/code].

### index :: int

### bone_direction :: int

## set_end_bone_name :: func BoneTwistDisperser3D.set_end_bone_name(index: int, bone_name: String) -> void
Sets the end bone name of the bone chain.
[b]Note:[/b] The end bone must be a child of the root bone.

### index :: int

### bone_name :: String

## set_extend_end_bone :: func BoneTwistDisperser3D.set_extend_end_bone(index: int, enabled: bool) -> void
If [param enabled] is [code]true[/code], the end bone is extended to have a tail.
If [param enabled] is [code]false[/code], [method get_reference_bone] becomes a parent of the end bone and it uses the vector to the end bone as a twist axis.

### index :: int

### enabled :: bool

## set_joint_twist_amount :: func BoneTwistDisperser3D.set_joint_twist_amount(index: int, joint: int, twist_amount: float) -> void
Sets the twist amount at [param joint] in the bone chain's joint list when [method get_disperse_mode] is [constant DISPERSE_MODE_CUSTOM].

### index :: int

### joint :: int

### twist_amount :: float

## set_root_bone :: func BoneTwistDisperser3D.set_root_bone(index: int, bone: int) -> void
Sets the root bone index of the bone chain.

### index :: int

### bone :: int

## set_root_bone_name :: func BoneTwistDisperser3D.set_root_bone_name(index: int, bone_name: String) -> void
Sets the root bone name of the bone chain.

### index :: int

### bone_name :: String

## set_twist_from :: func BoneTwistDisperser3D.set_twist_from(index: int, from: Quaternion) -> void
Sets the rotation to an arbitrary state before twisting for the current bone pose to extract the twist when [method is_twist_from_rest] is [code]false[/code].
In other words, by calling [method set_twist_from] by [signal SkeletonModifier3D.modification_processed] of a specific [SkeletonModifier3D], you can extract only the twists generated by modifiers processed after that but before this [BoneTwistDisperser3D].

### index :: int

### from :: Quaternion

## set_twist_from_rest :: func BoneTwistDisperser3D.set_twist_from_rest(index: int, enabled: bool) -> void
If [param enabled] is [code]true[/code], it extracts the twist amount from the difference between the bone rest and the current bone pose.
If [param enabled] is [code]false[/code], it extracts the twist amount from the difference between [method get_twist_from] and the current bone pose. See also [method set_twist_from].

### index :: int

### enabled :: bool

## set_weight_position :: func BoneTwistDisperser3D.set_weight_position(index: int, weight_position: float) -> void
Sets the position at which to divide the segment between joints for weight assignment when [method get_disperse_mode] is [constant DISPERSE_MODE_WEIGHTED].
For example, when [param weight_position] is [code]0.5[/code], if two bone segments with a length of [code]1.0[/code] exist between three joints, weights are assigned to each joint from root to end at ratios of [code]0.5[/code], [code]1.0[/code], and [code]0.5[/code]. Then amounts become [code]0.25[/code], [code]0.75[/code], and [code]1.0[/code] respectively.

### index :: int

### weight_position :: float
