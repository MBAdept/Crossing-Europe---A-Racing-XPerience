# CheckBox :: <Native> class CheckBox extends Button
A button that represents a binary choice.
[CheckBox] allows the user to choose one of only two possible options. It's similar to [CheckButton] in functionality, but it has a different appearance. To follow established UX patterns, it's recommended to use [CheckBox] when toggling it has [b]no[/b] immediate effect on something. For example, it could be used when toggling it will only do something once a confirmation button is pressed.
See also [BaseButton] which contains common properties and methods associated with this node.
When [member BaseButton.button_group] specifies a [ButtonGroup], [CheckBox] changes its appearance to that of a radio button and uses the various [code]radio_*[/code] theme properties.

## alignment :: var CheckBox.alignment: HorizontalAlignment

## toggle_mode :: var CheckBox.toggle_mode: bool

## checkbox_checked_color :: <Theme> var CheckBox.checkbox_checked_color: Color
The color of the checked icon when the checkbox is pressed.

## checkbox_unchecked_color :: <Theme> var CheckBox.checkbox_unchecked_color: Color
The color of the unchecked icon when the checkbox is not pressed.

## check_v_offset :: <Theme> var CheckBox.check_v_offset: int
The vertical offset used when rendering the check icons (in pixels).

## checked :: <Theme> var CheckBox.checked: Texture2D
The check icon to display when the [CheckBox] is checked.

## checked_disabled :: <Theme> var CheckBox.checked_disabled: Texture2D
The check icon to display when the [CheckBox] is checked and is disabled.

## radio_checked :: <Theme> var CheckBox.radio_checked: Texture2D
The check icon to display when the [CheckBox] is configured as a radio button and is checked.

## radio_checked_disabled :: <Theme> var CheckBox.radio_checked_disabled: Texture2D
The check icon to display when the [CheckBox] is configured as a radio button, is disabled, and is unchecked.

## radio_unchecked :: <Theme> var CheckBox.radio_unchecked: Texture2D
The check icon to display when the [CheckBox] is configured as a radio button and is unchecked.

## radio_unchecked_disabled :: <Theme> var CheckBox.radio_unchecked_disabled: Texture2D
The check icon to display when the [CheckBox] is configured as a radio button, is disabled, and is unchecked.

## unchecked :: <Theme> var CheckBox.unchecked: Texture2D
The check icon to display when the [CheckBox] is unchecked.

## unchecked_disabled :: <Theme> var CheckBox.unchecked_disabled: Texture2D
The check icon to display when the [CheckBox] is unchecked and is disabled.
