# PhysicsServer3DExtension :: <Native> class PhysicsServer3DExtension extends PhysicsServer3D
Provides virtual methods that can be overridden to create custom [PhysicsServer3D] implementations.
This class extends [PhysicsServer3D] by providing additional virtual methods that can be overridden. When these methods are overridden, they will be called instead of the internal methods of the physics server.
Intended for use with GDExtension to create custom implementations of [PhysicsServer3D].

## _area_add_shape :: func PhysicsServer3DExtension._area_add_shape(area: RID, shape: RID, transform: Transform3D, disabled: bool) -> void

### area :: RID

### shape :: RID

### transform :: Transform3D

### disabled :: bool

## _area_attach_object_instance_id :: func PhysicsServer3DExtension._area_attach_object_instance_id(area: RID, id: int) -> void

### area :: RID

### id :: int

## _area_clear_shapes :: func PhysicsServer3DExtension._area_clear_shapes(area: RID) -> void

### area :: RID

## _area_create :: func PhysicsServer3DExtension._area_create() -> RID

## _area_get_collision_layer :: func PhysicsServer3DExtension._area_get_collision_layer(area: RID) -> int

### area :: RID

## _area_get_collision_mask :: func PhysicsServer3DExtension._area_get_collision_mask(area: RID) -> int

### area :: RID

## _area_get_object_instance_id :: func PhysicsServer3DExtension._area_get_object_instance_id(area: RID) -> int

### area :: RID

## _area_get_param :: func PhysicsServer3DExtension._area_get_param(area: RID, param: int) -> Variant

### area :: RID

### param :: int

## _area_get_shape :: func PhysicsServer3DExtension._area_get_shape(area: RID, shape_idx: int) -> RID

### area :: RID

### shape_idx :: int

## _area_get_shape_count :: func PhysicsServer3DExtension._area_get_shape_count(area: RID) -> int

### area :: RID

## _area_get_shape_transform :: func PhysicsServer3DExtension._area_get_shape_transform(area: RID, shape_idx: int) -> Transform3D

### area :: RID

### shape_idx :: int

## _area_get_space :: func PhysicsServer3DExtension._area_get_space(area: RID) -> RID

### area :: RID

## _area_get_transform :: func PhysicsServer3DExtension._area_get_transform(area: RID) -> Transform3D

### area :: RID

## _area_remove_shape :: func PhysicsServer3DExtension._area_remove_shape(area: RID, shape_idx: int) -> void

### area :: RID

### shape_idx :: int

## _area_set_area_monitor_callback :: func PhysicsServer3DExtension._area_set_area_monitor_callback(area: RID, callback: Callable) -> void

### area :: RID

### callback :: Callable

## _area_set_collision_layer :: func PhysicsServer3DExtension._area_set_collision_layer(area: RID, layer: int) -> void

### area :: RID

### layer :: int

## _area_set_collision_mask :: func PhysicsServer3DExtension._area_set_collision_mask(area: RID, mask: int) -> void

### area :: RID

### mask :: int

## _area_set_monitor_callback :: func PhysicsServer3DExtension._area_set_monitor_callback(area: RID, callback: Callable) -> void

### area :: RID

### callback :: Callable

## _area_set_monitorable :: func PhysicsServer3DExtension._area_set_monitorable(area: RID, monitorable: bool) -> void

### area :: RID

### monitorable :: bool

## _area_set_param :: func PhysicsServer3DExtension._area_set_param(area: RID, param: int, value: Variant) -> void

### area :: RID

### param :: int

### value :: Variant

## _area_set_ray_pickable :: func PhysicsServer3DExtension._area_set_ray_pickable(area: RID, enable: bool) -> void

### area :: RID

### enable :: bool

## _area_set_shape :: func PhysicsServer3DExtension._area_set_shape(area: RID, shape_idx: int, shape: RID) -> void

### area :: RID

### shape_idx :: int

### shape :: RID

## _area_set_shape_disabled :: func PhysicsServer3DExtension._area_set_shape_disabled(area: RID, shape_idx: int, disabled: bool) -> void

### area :: RID

### shape_idx :: int

### disabled :: bool

## _area_set_shape_transform :: func PhysicsServer3DExtension._area_set_shape_transform(area: RID, shape_idx: int, transform: Transform3D) -> void

### area :: RID

### shape_idx :: int

### transform :: Transform3D

## _area_set_space :: func PhysicsServer3DExtension._area_set_space(area: RID, space: RID) -> void

### area :: RID

### space :: RID

## _area_set_transform :: func PhysicsServer3DExtension._area_set_transform(area: RID, transform: Transform3D) -> void

### area :: RID

### transform :: Transform3D

## _body_add_collision_exception :: func PhysicsServer3DExtension._body_add_collision_exception(body: RID, excepted_body: RID) -> void

### body :: RID

### excepted_body :: RID

## _body_add_constant_central_force :: func PhysicsServer3DExtension._body_add_constant_central_force(body: RID, force: Vector3) -> void

### body :: RID

### force :: Vector3

## _body_add_constant_force :: func PhysicsServer3DExtension._body_add_constant_force(body: RID, force: Vector3, position: Vector3) -> void

### body :: RID

### force :: Vector3

### position :: Vector3

## _body_add_constant_torque :: func PhysicsServer3DExtension._body_add_constant_torque(body: RID, torque: Vector3) -> void

### body :: RID

### torque :: Vector3

## _body_add_shape :: func PhysicsServer3DExtension._body_add_shape(body: RID, shape: RID, transform: Transform3D, disabled: bool) -> void

### body :: RID

### shape :: RID

### transform :: Transform3D

### disabled :: bool

## _body_apply_central_force :: func PhysicsServer3DExtension._body_apply_central_force(body: RID, force: Vector3) -> void

### body :: RID

### force :: Vector3

## _body_apply_central_impulse :: func PhysicsServer3DExtension._body_apply_central_impulse(body: RID, impulse: Vector3) -> void

### body :: RID

### impulse :: Vector3

## _body_apply_force :: func PhysicsServer3DExtension._body_apply_force(body: RID, force: Vector3, position: Vector3) -> void

### body :: RID

### force :: Vector3

### position :: Vector3

## _body_apply_impulse :: func PhysicsServer3DExtension._body_apply_impulse(body: RID, impulse: Vector3, position: Vector3) -> void

### body :: RID

### impulse :: Vector3

### position :: Vector3

## _body_apply_torque :: func PhysicsServer3DExtension._body_apply_torque(body: RID, torque: Vector3) -> void

### body :: RID

### torque :: Vector3

## _body_apply_torque_impulse :: func PhysicsServer3DExtension._body_apply_torque_impulse(body: RID, impulse: Vector3) -> void

### body :: RID

### impulse :: Vector3

## _body_attach_object_instance_id :: func PhysicsServer3DExtension._body_attach_object_instance_id(body: RID, id: int) -> void

### body :: RID

### id :: int

## _body_clear_shapes :: func PhysicsServer3DExtension._body_clear_shapes(body: RID) -> void

### body :: RID

## _body_create :: func PhysicsServer3DExtension._body_create() -> RID

## _body_get_collision_exceptions :: func PhysicsServer3DExtension._body_get_collision_exceptions(body: RID) -> RID[]

### body :: RID

## _body_get_collision_layer :: func PhysicsServer3DExtension._body_get_collision_layer(body: RID) -> int

### body :: RID

## _body_get_collision_mask :: func PhysicsServer3DExtension._body_get_collision_mask(body: RID) -> int

### body :: RID

## _body_get_collision_priority :: func PhysicsServer3DExtension._body_get_collision_priority(body: RID) -> float

### body :: RID

## _body_get_constant_force :: func PhysicsServer3DExtension._body_get_constant_force(body: RID) -> Vector3

### body :: RID

## _body_get_constant_torque :: func PhysicsServer3DExtension._body_get_constant_torque(body: RID) -> Vector3

### body :: RID

## _body_get_contacts_reported_depth_threshold :: func PhysicsServer3DExtension._body_get_contacts_reported_depth_threshold(body: RID) -> float

### body :: RID

## _body_get_direct_state :: func PhysicsServer3DExtension._body_get_direct_state(body: RID) -> PhysicsDirectBodyState3D

### body :: RID

## _body_get_max_contacts_reported :: func PhysicsServer3DExtension._body_get_max_contacts_reported(body: RID) -> int

### body :: RID

## _body_get_mode :: func PhysicsServer3DExtension._body_get_mode(body: RID) -> int

### body :: RID

## _body_get_object_instance_id :: func PhysicsServer3DExtension._body_get_object_instance_id(body: RID) -> int

### body :: RID

## _body_get_param :: func PhysicsServer3DExtension._body_get_param(body: RID, param: int) -> Variant

### body :: RID

### param :: int

## _body_get_shape :: func PhysicsServer3DExtension._body_get_shape(body: RID, shape_idx: int) -> RID

### body :: RID

### shape_idx :: int

## _body_get_shape_count :: func PhysicsServer3DExtension._body_get_shape_count(body: RID) -> int

### body :: RID

## _body_get_shape_transform :: func PhysicsServer3DExtension._body_get_shape_transform(body: RID, shape_idx: int) -> Transform3D

### body :: RID

### shape_idx :: int

## _body_get_space :: func PhysicsServer3DExtension._body_get_space(body: RID) -> RID

### body :: RID

## _body_get_state :: func PhysicsServer3DExtension._body_get_state(body: RID, state: int) -> Variant

### body :: RID

### state :: int

## _body_get_user_flags :: func PhysicsServer3DExtension._body_get_user_flags(body: RID) -> int

### body :: RID

## _body_is_axis_locked :: func PhysicsServer3DExtension._body_is_axis_locked(body: RID, axis: int) -> bool

### body :: RID

### axis :: int

## _body_is_continuous_collision_detection_enabled :: func PhysicsServer3DExtension._body_is_continuous_collision_detection_enabled(body: RID) -> bool

### body :: RID

## _body_is_omitting_force_integration :: func PhysicsServer3DExtension._body_is_omitting_force_integration(body: RID) -> bool

### body :: RID

## _body_remove_collision_exception :: func PhysicsServer3DExtension._body_remove_collision_exception(body: RID, excepted_body: RID) -> void

### body :: RID

### excepted_body :: RID

## _body_remove_shape :: func PhysicsServer3DExtension._body_remove_shape(body: RID, shape_idx: int) -> void

### body :: RID

### shape_idx :: int

## _body_reset_mass_properties :: func PhysicsServer3DExtension._body_reset_mass_properties(body: RID) -> void

### body :: RID

## _body_set_axis_lock :: func PhysicsServer3DExtension._body_set_axis_lock(body: RID, axis: int, lock: bool) -> void

### body :: RID

### axis :: int

### lock :: bool

## _body_set_axis_velocity :: func PhysicsServer3DExtension._body_set_axis_velocity(body: RID, axis_velocity: Vector3) -> void

### body :: RID

### axis_velocity :: Vector3

## _body_set_collision_layer :: func PhysicsServer3DExtension._body_set_collision_layer(body: RID, layer: int) -> void

### body :: RID

### layer :: int

## _body_set_collision_mask :: func PhysicsServer3DExtension._body_set_collision_mask(body: RID, mask: int) -> void

### body :: RID

### mask :: int

## _body_set_collision_priority :: func PhysicsServer3DExtension._body_set_collision_priority(body: RID, priority: float) -> void

### body :: RID

### priority :: float

## _body_set_constant_force :: func PhysicsServer3DExtension._body_set_constant_force(body: RID, force: Vector3) -> void

### body :: RID

### force :: Vector3

## _body_set_constant_torque :: func PhysicsServer3DExtension._body_set_constant_torque(body: RID, torque: Vector3) -> void

### body :: RID

### torque :: Vector3

## _body_set_contacts_reported_depth_threshold :: func PhysicsServer3DExtension._body_set_contacts_reported_depth_threshold(body: RID, threshold: float) -> void

### body :: RID

### threshold :: float

## _body_set_enable_continuous_collision_detection :: func PhysicsServer3DExtension._body_set_enable_continuous_collision_detection(body: RID, enable: bool) -> void

### body :: RID

### enable :: bool

## _body_set_force_integration_callback :: func PhysicsServer3DExtension._body_set_force_integration_callback(body: RID, callable: Callable, userdata: Variant) -> void

### body :: RID

### callable :: Callable

### userdata :: Variant

## _body_set_max_contacts_reported :: func PhysicsServer3DExtension._body_set_max_contacts_reported(body: RID, amount: int) -> void

### body :: RID

### amount :: int

## _body_set_mode :: func PhysicsServer3DExtension._body_set_mode(body: RID, mode: int) -> void

### body :: RID

### mode :: int

## _body_set_omit_force_integration :: func PhysicsServer3DExtension._body_set_omit_force_integration(body: RID, enable: bool) -> void

### body :: RID

### enable :: bool

## _body_set_param :: func PhysicsServer3DExtension._body_set_param(body: RID, param: int, value: Variant) -> void

### body :: RID

### param :: int

### value :: Variant

## _body_set_ray_pickable :: func PhysicsServer3DExtension._body_set_ray_pickable(body: RID, enable: bool) -> void

### body :: RID

### enable :: bool

## _body_set_shape :: func PhysicsServer3DExtension._body_set_shape(body: RID, shape_idx: int, shape: RID) -> void

### body :: RID

### shape_idx :: int

### shape :: RID

## _body_set_shape_disabled :: func PhysicsServer3DExtension._body_set_shape_disabled(body: RID, shape_idx: int, disabled: bool) -> void

### body :: RID

### shape_idx :: int

### disabled :: bool

## _body_set_shape_transform :: func PhysicsServer3DExtension._body_set_shape_transform(body: RID, shape_idx: int, transform: Transform3D) -> void

### body :: RID

### shape_idx :: int

### transform :: Transform3D

## _body_set_space :: func PhysicsServer3DExtension._body_set_space(body: RID, space: RID) -> void

### body :: RID

### space :: RID

## _body_set_state :: func PhysicsServer3DExtension._body_set_state(body: RID, state: int, value: Variant) -> void

### body :: RID

### state :: int

### value :: Variant

## _body_set_state_sync_callback :: func PhysicsServer3DExtension._body_set_state_sync_callback(body: RID, callable: Callable) -> void

### body :: RID

### callable :: Callable

## _body_set_user_flags :: func PhysicsServer3DExtension._body_set_user_flags(body: RID, flags: int) -> void

### body :: RID

### flags :: int

## _body_test_motion :: func PhysicsServer3DExtension._body_test_motion(body: RID, from: Transform3D, motion: Vector3, margin: float, max_collisions: int, collide_separation_ray: bool, recovery_as_collision: bool, r_result: PhysicsServer3DExtensionMotionResult*) -> bool

### body :: RID

### from :: Transform3D

### motion :: Vector3

### margin :: float

### max_collisions :: int

### collide_separation_ray :: bool

### recovery_as_collision :: bool

### r_result :: PhysicsServer3DExtensionMotionResult*

## _box_shape_create :: func PhysicsServer3DExtension._box_shape_create() -> RID

## _capsule_shape_create :: func PhysicsServer3DExtension._capsule_shape_create() -> RID

## _concave_polygon_shape_create :: func PhysicsServer3DExtension._concave_polygon_shape_create() -> RID

## _cone_twist_joint_get_param :: func PhysicsServer3DExtension._cone_twist_joint_get_param(joint: RID, param: int) -> float

### joint :: RID

### param :: int

## _cone_twist_joint_set_param :: func PhysicsServer3DExtension._cone_twist_joint_set_param(joint: RID, param: int, value: float) -> void

### joint :: RID

### param :: int

### value :: float

## _convex_polygon_shape_create :: func PhysicsServer3DExtension._convex_polygon_shape_create() -> RID

## _custom_shape_create :: func PhysicsServer3DExtension._custom_shape_create() -> RID

## _cylinder_shape_create :: func PhysicsServer3DExtension._cylinder_shape_create() -> RID

## _end_sync :: func PhysicsServer3DExtension._end_sync() -> void

## _finish :: func PhysicsServer3DExtension._finish() -> void

## _flush_queries :: func PhysicsServer3DExtension._flush_queries() -> void

## _free_rid :: func PhysicsServer3DExtension._free_rid(rid: RID) -> void

### rid :: RID

## _generic_6dof_joint_get_flag :: func PhysicsServer3DExtension._generic_6dof_joint_get_flag(joint: RID, axis: int, flag: int) -> bool

### joint :: RID

### axis :: int

### flag :: int

## _generic_6dof_joint_get_param :: func PhysicsServer3DExtension._generic_6dof_joint_get_param(joint: RID, axis: int, param: int) -> float

### joint :: RID

### axis :: int

### param :: int

## _generic_6dof_joint_set_flag :: func PhysicsServer3DExtension._generic_6dof_joint_set_flag(joint: RID, axis: int, flag: int, enable: bool) -> void

### joint :: RID

### axis :: int

### flag :: int

### enable :: bool

## _generic_6dof_joint_set_param :: func PhysicsServer3DExtension._generic_6dof_joint_set_param(joint: RID, axis: int, param: int, value: float) -> void

### joint :: RID

### axis :: int

### param :: int

### value :: float

## _get_process_info :: func PhysicsServer3DExtension._get_process_info(process_info: int) -> int

### process_info :: int

## _heightmap_shape_create :: func PhysicsServer3DExtension._heightmap_shape_create() -> RID

## _hinge_joint_get_flag :: func PhysicsServer3DExtension._hinge_joint_get_flag(joint: RID, flag: int) -> bool

### joint :: RID

### flag :: int

## _hinge_joint_get_param :: func PhysicsServer3DExtension._hinge_joint_get_param(joint: RID, param: int) -> float

### joint :: RID

### param :: int

## _hinge_joint_set_flag :: func PhysicsServer3DExtension._hinge_joint_set_flag(joint: RID, flag: int, enabled: bool) -> void

### joint :: RID

### flag :: int

### enabled :: bool

## _hinge_joint_set_param :: func PhysicsServer3DExtension._hinge_joint_set_param(joint: RID, param: int, value: float) -> void

### joint :: RID

### param :: int

### value :: float

## _init :: func PhysicsServer3DExtension._init() -> void

## _is_flushing_queries :: func PhysicsServer3DExtension._is_flushing_queries() -> bool

## _joint_clear :: func PhysicsServer3DExtension._joint_clear(joint: RID) -> void

### joint :: RID

## _joint_create :: func PhysicsServer3DExtension._joint_create() -> RID

## _joint_disable_collisions_between_bodies :: func PhysicsServer3DExtension._joint_disable_collisions_between_bodies(joint: RID, disable: bool) -> void

### joint :: RID

### disable :: bool

## _joint_get_solver_priority :: func PhysicsServer3DExtension._joint_get_solver_priority(joint: RID) -> int

### joint :: RID

## _joint_get_type :: func PhysicsServer3DExtension._joint_get_type(joint: RID) -> int

### joint :: RID

## _joint_is_disabled_collisions_between_bodies :: func PhysicsServer3DExtension._joint_is_disabled_collisions_between_bodies(joint: RID) -> bool

### joint :: RID

## _joint_make_cone_twist :: func PhysicsServer3DExtension._joint_make_cone_twist(joint: RID, body_A: RID, local_ref_A: Transform3D, body_B: RID, local_ref_B: Transform3D) -> void

### joint :: RID

### body_A :: RID

### local_ref_A :: Transform3D

### body_B :: RID

### local_ref_B :: Transform3D

## _joint_make_generic_6dof :: func PhysicsServer3DExtension._joint_make_generic_6dof(joint: RID, body_A: RID, local_ref_A: Transform3D, body_B: RID, local_ref_B: Transform3D) -> void

### joint :: RID

### body_A :: RID

### local_ref_A :: Transform3D

### body_B :: RID

### local_ref_B :: Transform3D

## _joint_make_hinge :: func PhysicsServer3DExtension._joint_make_hinge(joint: RID, body_A: RID, hinge_A: Transform3D, body_B: RID, hinge_B: Transform3D) -> void

### joint :: RID

### body_A :: RID

### hinge_A :: Transform3D

### body_B :: RID

### hinge_B :: Transform3D

## _joint_make_hinge_simple :: func PhysicsServer3DExtension._joint_make_hinge_simple(joint: RID, body_A: RID, pivot_A: Vector3, axis_A: Vector3, body_B: RID, pivot_B: Vector3, axis_B: Vector3) -> void

### joint :: RID

### body_A :: RID

### pivot_A :: Vector3

### axis_A :: Vector3

### body_B :: RID

### pivot_B :: Vector3

### axis_B :: Vector3

## _joint_make_pin :: func PhysicsServer3DExtension._joint_make_pin(joint: RID, body_A: RID, local_A: Vector3, body_B: RID, local_B: Vector3) -> void

### joint :: RID

### body_A :: RID

### local_A :: Vector3

### body_B :: RID

### local_B :: Vector3

## _joint_make_slider :: func PhysicsServer3DExtension._joint_make_slider(joint: RID, body_A: RID, local_ref_A: Transform3D, body_B: RID, local_ref_B: Transform3D) -> void

### joint :: RID

### body_A :: RID

### local_ref_A :: Transform3D

### body_B :: RID

### local_ref_B :: Transform3D

## _joint_set_solver_priority :: func PhysicsServer3DExtension._joint_set_solver_priority(joint: RID, priority: int) -> void

### joint :: RID

### priority :: int

## _pin_joint_get_local_a :: func PhysicsServer3DExtension._pin_joint_get_local_a(joint: RID) -> Vector3

### joint :: RID

## _pin_joint_get_local_b :: func PhysicsServer3DExtension._pin_joint_get_local_b(joint: RID) -> Vector3

### joint :: RID

## _pin_joint_get_param :: func PhysicsServer3DExtension._pin_joint_get_param(joint: RID, param: int) -> float

### joint :: RID

### param :: int

## _pin_joint_set_local_a :: func PhysicsServer3DExtension._pin_joint_set_local_a(joint: RID, local_A: Vector3) -> void

### joint :: RID

### local_A :: Vector3

## _pin_joint_set_local_b :: func PhysicsServer3DExtension._pin_joint_set_local_b(joint: RID, local_B: Vector3) -> void

### joint :: RID

### local_B :: Vector3

## _pin_joint_set_param :: func PhysicsServer3DExtension._pin_joint_set_param(joint: RID, param: int, value: float) -> void

### joint :: RID

### param :: int

### value :: float

## _separation_ray_shape_create :: func PhysicsServer3DExtension._separation_ray_shape_create() -> RID

## _set_active :: func PhysicsServer3DExtension._set_active(active: bool) -> void

### active :: bool

## _shape_get_custom_solver_bias :: func PhysicsServer3DExtension._shape_get_custom_solver_bias(shape: RID) -> float

### shape :: RID

## _shape_get_data :: func PhysicsServer3DExtension._shape_get_data(shape: RID) -> Variant

### shape :: RID

## _shape_get_margin :: func PhysicsServer3DExtension._shape_get_margin(shape: RID) -> float

### shape :: RID

## _shape_get_type :: func PhysicsServer3DExtension._shape_get_type(shape: RID) -> int

### shape :: RID

## _shape_set_custom_solver_bias :: func PhysicsServer3DExtension._shape_set_custom_solver_bias(shape: RID, bias: float) -> void

### shape :: RID

### bias :: float

## _shape_set_data :: func PhysicsServer3DExtension._shape_set_data(shape: RID, data: Variant) -> void

### shape :: RID

### data :: Variant

## _shape_set_margin :: func PhysicsServer3DExtension._shape_set_margin(shape: RID, margin: float) -> void

### shape :: RID

### margin :: float

## _slider_joint_get_param :: func PhysicsServer3DExtension._slider_joint_get_param(joint: RID, param: int) -> float

### joint :: RID

### param :: int

## _slider_joint_set_param :: func PhysicsServer3DExtension._slider_joint_set_param(joint: RID, param: int, value: float) -> void

### joint :: RID

### param :: int

### value :: float

## _soft_body_add_collision_exception :: func PhysicsServer3DExtension._soft_body_add_collision_exception(body: RID, body_b: RID) -> void

### body :: RID

### body_b :: RID

## _soft_body_apply_central_force :: func PhysicsServer3DExtension._soft_body_apply_central_force(body: RID, force: Vector3) -> void

### body :: RID

### force :: Vector3

## _soft_body_apply_central_impulse :: func PhysicsServer3DExtension._soft_body_apply_central_impulse(body: RID, impulse: Vector3) -> void

### body :: RID

### impulse :: Vector3

## _soft_body_apply_point_force :: func PhysicsServer3DExtension._soft_body_apply_point_force(body: RID, point_index: int, force: Vector3) -> void

### body :: RID

### point_index :: int

### force :: Vector3

## _soft_body_apply_point_impulse :: func PhysicsServer3DExtension._soft_body_apply_point_impulse(body: RID, point_index: int, impulse: Vector3) -> void

### body :: RID

### point_index :: int

### impulse :: Vector3

## _soft_body_create :: func PhysicsServer3DExtension._soft_body_create() -> RID

## _soft_body_get_bounds :: func PhysicsServer3DExtension._soft_body_get_bounds(body: RID) -> AABB

### body :: RID

## _soft_body_get_collision_exceptions :: func PhysicsServer3DExtension._soft_body_get_collision_exceptions(body: RID) -> RID[]

### body :: RID

## _soft_body_get_collision_layer :: func PhysicsServer3DExtension._soft_body_get_collision_layer(body: RID) -> int

### body :: RID

## _soft_body_get_collision_mask :: func PhysicsServer3DExtension._soft_body_get_collision_mask(body: RID) -> int

### body :: RID

## _soft_body_get_damping_coefficient :: func PhysicsServer3DExtension._soft_body_get_damping_coefficient(body: RID) -> float

### body :: RID

## _soft_body_get_drag_coefficient :: func PhysicsServer3DExtension._soft_body_get_drag_coefficient(body: RID) -> float

### body :: RID

## _soft_body_get_linear_stiffness :: func PhysicsServer3DExtension._soft_body_get_linear_stiffness(body: RID) -> float

### body :: RID

## _soft_body_get_point_global_position :: func PhysicsServer3DExtension._soft_body_get_point_global_position(body: RID, point_index: int) -> Vector3

### body :: RID

### point_index :: int

## _soft_body_get_pressure_coefficient :: func PhysicsServer3DExtension._soft_body_get_pressure_coefficient(body: RID) -> float

### body :: RID

## _soft_body_get_shrinking_factor :: func PhysicsServer3DExtension._soft_body_get_shrinking_factor(body: RID) -> float

### body :: RID

## _soft_body_get_simulation_precision :: func PhysicsServer3DExtension._soft_body_get_simulation_precision(body: RID) -> int

### body :: RID

## _soft_body_get_space :: func PhysicsServer3DExtension._soft_body_get_space(body: RID) -> RID

### body :: RID

## _soft_body_get_state :: func PhysicsServer3DExtension._soft_body_get_state(body: RID, state: int) -> Variant

### body :: RID

### state :: int

## _soft_body_get_total_mass :: func PhysicsServer3DExtension._soft_body_get_total_mass(body: RID) -> float

### body :: RID

## _soft_body_is_point_pinned :: func PhysicsServer3DExtension._soft_body_is_point_pinned(body: RID, point_index: int) -> bool

### body :: RID

### point_index :: int

## _soft_body_move_point :: func PhysicsServer3DExtension._soft_body_move_point(body: RID, point_index: int, global_position: Vector3) -> void

### body :: RID

### point_index :: int

### global_position :: Vector3

## _soft_body_pin_point :: func PhysicsServer3DExtension._soft_body_pin_point(body: RID, point_index: int, pin: bool) -> void

### body :: RID

### point_index :: int

### pin :: bool

## _soft_body_remove_all_pinned_points :: func PhysicsServer3DExtension._soft_body_remove_all_pinned_points(body: RID) -> void

### body :: RID

## _soft_body_remove_collision_exception :: func PhysicsServer3DExtension._soft_body_remove_collision_exception(body: RID, body_b: RID) -> void

### body :: RID

### body_b :: RID

## _soft_body_set_collision_layer :: func PhysicsServer3DExtension._soft_body_set_collision_layer(body: RID, layer: int) -> void

### body :: RID

### layer :: int

## _soft_body_set_collision_mask :: func PhysicsServer3DExtension._soft_body_set_collision_mask(body: RID, mask: int) -> void

### body :: RID

### mask :: int

## _soft_body_set_damping_coefficient :: func PhysicsServer3DExtension._soft_body_set_damping_coefficient(body: RID, damping_coefficient: float) -> void

### body :: RID

### damping_coefficient :: float

## _soft_body_set_drag_coefficient :: func PhysicsServer3DExtension._soft_body_set_drag_coefficient(body: RID, drag_coefficient: float) -> void

### body :: RID

### drag_coefficient :: float

## _soft_body_set_linear_stiffness :: func PhysicsServer3DExtension._soft_body_set_linear_stiffness(body: RID, linear_stiffness: float) -> void

### body :: RID

### linear_stiffness :: float

## _soft_body_set_mesh :: func PhysicsServer3DExtension._soft_body_set_mesh(body: RID, mesh: RID) -> void

### body :: RID

### mesh :: RID

## _soft_body_set_pressure_coefficient :: func PhysicsServer3DExtension._soft_body_set_pressure_coefficient(body: RID, pressure_coefficient: float) -> void

### body :: RID

### pressure_coefficient :: float

## _soft_body_set_ray_pickable :: func PhysicsServer3DExtension._soft_body_set_ray_pickable(body: RID, enable: bool) -> void

### body :: RID

### enable :: bool

## _soft_body_set_shrinking_factor :: func PhysicsServer3DExtension._soft_body_set_shrinking_factor(body: RID, shrinking_factor: float) -> void

### body :: RID

### shrinking_factor :: float

## _soft_body_set_simulation_precision :: func PhysicsServer3DExtension._soft_body_set_simulation_precision(body: RID, simulation_precision: int) -> void

### body :: RID

### simulation_precision :: int

## _soft_body_set_space :: func PhysicsServer3DExtension._soft_body_set_space(body: RID, space: RID) -> void

### body :: RID

### space :: RID

## _soft_body_set_state :: func PhysicsServer3DExtension._soft_body_set_state(body: RID, state: int, variant: Variant) -> void

### body :: RID

### state :: int

### variant :: Variant

## _soft_body_set_total_mass :: func PhysicsServer3DExtension._soft_body_set_total_mass(body: RID, total_mass: float) -> void

### body :: RID

### total_mass :: float

## _soft_body_set_transform :: func PhysicsServer3DExtension._soft_body_set_transform(body: RID, transform: Transform3D) -> void

### body :: RID

### transform :: Transform3D

## _soft_body_update_rendering_server :: func PhysicsServer3DExtension._soft_body_update_rendering_server(body: RID, rendering_server_handler: PhysicsServer3DRenderingServerHandler) -> void

### body :: RID

### rendering_server_handler :: PhysicsServer3DRenderingServerHandler

## _space_create :: func PhysicsServer3DExtension._space_create() -> RID

## _space_get_contact_count :: func PhysicsServer3DExtension._space_get_contact_count(space: RID) -> int

### space :: RID

## _space_get_contacts :: func PhysicsServer3DExtension._space_get_contacts(space: RID) -> PackedVector3Array

### space :: RID

## _space_get_direct_state :: func PhysicsServer3DExtension._space_get_direct_state(space: RID) -> PhysicsDirectSpaceState3D

### space :: RID

## _space_get_param :: func PhysicsServer3DExtension._space_get_param(space: RID, param: int) -> float

### space :: RID

### param :: int

## _space_is_active :: func PhysicsServer3DExtension._space_is_active(space: RID) -> bool

### space :: RID

## _space_set_active :: func PhysicsServer3DExtension._space_set_active(space: RID, active: bool) -> void

### space :: RID

### active :: bool

## _space_set_debug_contacts :: func PhysicsServer3DExtension._space_set_debug_contacts(space: RID, max_contacts: int) -> void

### space :: RID

### max_contacts :: int

## _space_set_param :: func PhysicsServer3DExtension._space_set_param(space: RID, param: int, value: float) -> void

### space :: RID

### param :: int

### value :: float

## _sphere_shape_create :: func PhysicsServer3DExtension._sphere_shape_create() -> RID

## _step :: func PhysicsServer3DExtension._step(step: float) -> void

### step :: float

## _sync :: func PhysicsServer3DExtension._sync() -> void

## _world_boundary_shape_create :: func PhysicsServer3DExtension._world_boundary_shape_create() -> RID

## body_test_motion_is_excluding_body :: func PhysicsServer3DExtension.body_test_motion_is_excluding_body(body: RID) -> bool

### body :: RID

## body_test_motion_is_excluding_object :: func PhysicsServer3DExtension.body_test_motion_is_excluding_object(object: int) -> bool

### object :: int
