# AudioEffectSpectrumAnalyzer :: <Native> class AudioEffectSpectrumAnalyzer extends AudioEffect
Creates an [AudioEffectInstance] which performs frequency analysis and exposes results to be accessed in real-time.
Calculates a Fourier Transform of the audio signal. This effect does not alter the audio. Can be used for creating real-time audio visualizations, like a spectrogram.
This resource configures an [AudioEffectSpectrumAnalyzerInstance], which performs the actual analysis at runtime. An instance should be obtained with [method AudioServer.get_bus_effect_instance] to make use of this effect.

## FFT_SIZE_256 :: const AudioEffectSpectrumAnalyzer.FFT_SIZE_256: FFTSize = 0
Use a buffer of 256 samples for the Fast Fourier transform. Lowest latency, but least stable over time.

## FFT_SIZE_512 :: const AudioEffectSpectrumAnalyzer.FFT_SIZE_512: FFTSize = 1
Use a buffer of 512 samples for the Fast Fourier transform. Low latency, but less stable over time.

## FFT_SIZE_1024 :: const AudioEffectSpectrumAnalyzer.FFT_SIZE_1024: FFTSize = 2
Use a buffer of 1024 samples for the Fast Fourier transform. This is a compromise between latency and stability over time.

## FFT_SIZE_2048 :: const AudioEffectSpectrumAnalyzer.FFT_SIZE_2048: FFTSize = 3
Use a buffer of 2048 samples for the Fast Fourier transform. High latency, but stable over time.

## FFT_SIZE_4096 :: const AudioEffectSpectrumAnalyzer.FFT_SIZE_4096: FFTSize = 4
Use a buffer of 4096 samples for the Fast Fourier transform. Highest latency, but most stable over time.

## FFT_SIZE_MAX :: const AudioEffectSpectrumAnalyzer.FFT_SIZE_MAX: FFTSize = 5
Represents the size of the [enum FFTSize] enum.

## buffer_length :: var AudioEffectSpectrumAnalyzer.buffer_length: float
The length of the buffer to keep, in seconds. Higher values keep data around for longer, but require more memory. Value can range from 0.1 to 4.

## fft_size :: var AudioEffectSpectrumAnalyzer.fft_size: AudioEffectSpectrumAnalyzer.FFTSize
The size of the [url=https://en.wikipedia.org/wiki/Fast_Fourier_transform]Fast Fourier transform[/url] buffer. Higher values smooth out the spectrum analysis over time, but have greater latency. The effects of this higher latency are especially noticeable with sudden amplitude changes.
