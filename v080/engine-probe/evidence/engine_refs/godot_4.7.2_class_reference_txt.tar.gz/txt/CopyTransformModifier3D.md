# CopyTransformModifier3D :: <Native> class CopyTransformModifier3D extends BoneConstraint3D
A [SkeletonModifier3D] that apply transform to the bone which copied from reference.
Apply the copied transform of the bone set by [method BoneConstraint3D.set_reference_bone] to the bone set by [method BoneConstraint3D.set_apply_bone] with processing it with some masks and options.
There are 4 ways to apply the transform, depending on the combination of [method set_relative] and [method set_additive].
[b]Relative + Additive:[/b]
- Extract reference pose relative to the rest and add it to the apply bone's pose.
[b]Relative + Not Additive:[/b]
- Extract reference pose relative to the rest and add it to the apply bone's rest.
[b]Not Relative + Additive:[/b]
- Extract reference pose absolutely and add it to the apply bone's pose.
[b]Not Relative + Not Additive:[/b]
- Extract reference pose absolutely and the apply bone's pose is replaced with it.
[b]Note:[/b] Relative option is available only in the case [method BoneConstraint3D.get_reference_type] is [constant BoneConstraint3D.REFERENCE_TYPE_BONE]. See also [enum BoneConstraint3D.ReferenceType].

## TRANSFORM_FLAG_POSITION :: const CopyTransformModifier3D.TRANSFORM_FLAG_POSITION: TransformFlag = 1
If set, allows to copy the position.

## TRANSFORM_FLAG_ROTATION :: const CopyTransformModifier3D.TRANSFORM_FLAG_ROTATION: TransformFlag = 2
If set, allows to copy the rotation.

## TRANSFORM_FLAG_SCALE :: const CopyTransformModifier3D.TRANSFORM_FLAG_SCALE: TransformFlag = 4
If set, allows to copy the scale.

## TRANSFORM_FLAG_ALL :: const CopyTransformModifier3D.TRANSFORM_FLAG_ALL: TransformFlag = 7
If set, allows to copy the position/rotation/scale.

## AXIS_FLAG_X :: const CopyTransformModifier3D.AXIS_FLAG_X: AxisFlag = 1
If set, allows to process the X-axis.

## AXIS_FLAG_Y :: const CopyTransformModifier3D.AXIS_FLAG_Y: AxisFlag = 2
If set, allows to process the Y-axis.

## AXIS_FLAG_Z :: const CopyTransformModifier3D.AXIS_FLAG_Z: AxisFlag = 4
If set, allows to process the Z-axis.

## AXIS_FLAG_ALL :: const CopyTransformModifier3D.AXIS_FLAG_ALL: AxisFlag = 7
If set, allows to process the all axes.

## setting_count :: var CopyTransformModifier3D.setting_count: int
The number of settings in the modifier.

## get_axis_flags :: func CopyTransformModifier3D.get_axis_flags(index: int) -> int
Returns the axis flags of the setting at [param index].

### index :: int

## get_copy_flags :: func CopyTransformModifier3D.get_copy_flags(index: int) -> int
Returns the copy flags of the setting at [param index].

### index :: int

## get_invert_flags :: func CopyTransformModifier3D.get_invert_flags(index: int) -> int
Returns the invert flags of the setting at [param index].

### index :: int

## is_additive :: func CopyTransformModifier3D.is_additive(index: int) -> bool
Returns [code]true[/code] if the additive option is enabled in the setting at [param index].

### index :: int

## is_axis_x_enabled :: func CopyTransformModifier3D.is_axis_x_enabled(index: int) -> bool
Returns [code]true[/code] if the enable flags has the flag for the X-axis in the setting at [param index]. See also [method set_axis_flags].

### index :: int

## is_axis_x_inverted :: func CopyTransformModifier3D.is_axis_x_inverted(index: int) -> bool
Returns [code]true[/code] if the invert flags has the flag for the X-axis in the setting at [param index]. See also [method set_invert_flags].

### index :: int

## is_axis_y_enabled :: func CopyTransformModifier3D.is_axis_y_enabled(index: int) -> bool
Returns [code]true[/code] if the enable flags has the flag for the Y-axis in the setting at [param index]. See also [method set_axis_flags].

### index :: int

## is_axis_y_inverted :: func CopyTransformModifier3D.is_axis_y_inverted(index: int) -> bool
Returns [code]true[/code] if the invert flags has the flag for the Y-axis in the setting at [param index]. See also [method set_invert_flags].

### index :: int

## is_axis_z_enabled :: func CopyTransformModifier3D.is_axis_z_enabled(index: int) -> bool
Returns [code]true[/code] if the enable flags has the flag for the Z-axis in the setting at [param index]. See also [method set_axis_flags].

### index :: int

## is_axis_z_inverted :: func CopyTransformModifier3D.is_axis_z_inverted(index: int) -> bool
Returns [code]true[/code] if the invert flags has the flag for the Z-axis in the setting at [param index]. See also [method set_invert_flags].

### index :: int

## is_position_copying :: func CopyTransformModifier3D.is_position_copying(index: int) -> bool
Returns [code]true[/code] if the copy flags has the flag for the position in the setting at [param index]. See also [method set_copy_flags].

### index :: int

## is_relative :: func CopyTransformModifier3D.is_relative(index: int) -> bool
Returns [code]true[/code] if the relative option is enabled in the setting at [param index].

### index :: int

## is_rotation_copying :: func CopyTransformModifier3D.is_rotation_copying(index: int) -> bool
Returns [code]true[/code] if the copy flags has the flag for the rotation in the setting at [param index]. See also [method set_copy_flags].

### index :: int

## is_scale_copying :: func CopyTransformModifier3D.is_scale_copying(index: int) -> bool
Returns [code]true[/code] if the copy flags has the flag for the scale in the setting at [param index]. See also [method set_copy_flags].

### index :: int

## set_additive :: func CopyTransformModifier3D.set_additive(index: int, enabled: bool) -> void
Sets additive option in the setting at [param index] to [param enabled]. This mainly affects the process of applying transform to the [method BoneConstraint3D.set_apply_bone].
If sets [param enabled] to [code]true[/code], the processed transform is added to the pose of the current apply bone.
If sets [param enabled] to [code]false[/code], the pose of the current apply bone is replaced with the processed transform. However, if set [method set_relative] to [code]true[/code], the transform is relative to rest.

### index :: int

### enabled :: bool

## set_axis_flags :: func CopyTransformModifier3D.set_axis_flags(index: int, axis_flags: int) -> void
Sets the flags to copy axes. If the flag is valid, the axis is copied.

### index :: int

### axis_flags :: int

## set_axis_x_enabled :: func CopyTransformModifier3D.set_axis_x_enabled(index: int, enabled: bool) -> void
If sets [param enabled] to [code]true[/code], the X-axis will be copied.

### index :: int

### enabled :: bool

## set_axis_x_inverted :: func CopyTransformModifier3D.set_axis_x_inverted(index: int, enabled: bool) -> void
If sets [param enabled] to [code]true[/code], the X-axis will be inverted.

### index :: int

### enabled :: bool

## set_axis_y_enabled :: func CopyTransformModifier3D.set_axis_y_enabled(index: int, enabled: bool) -> void
If sets [param enabled] to [code]true[/code], the Y-axis will be copied.

### index :: int

### enabled :: bool

## set_axis_y_inverted :: func CopyTransformModifier3D.set_axis_y_inverted(index: int, enabled: bool) -> void
If sets [param enabled] to [code]true[/code], the Y-axis will be inverted.

### index :: int

### enabled :: bool

## set_axis_z_enabled :: func CopyTransformModifier3D.set_axis_z_enabled(index: int, enabled: bool) -> void
If sets [param enabled] to [code]true[/code], the Z-axis will be copied.

### index :: int

### enabled :: bool

## set_axis_z_inverted :: func CopyTransformModifier3D.set_axis_z_inverted(index: int, enabled: bool) -> void
If sets [param enabled] to [code]true[/code], the Z-axis will be inverted.

### index :: int

### enabled :: bool

## set_copy_flags :: func CopyTransformModifier3D.set_copy_flags(index: int, copy_flags: int) -> void
Sets the flags to process the transform operations. If the flag is valid, the transform operation is processed.
[b]Note:[/b] If the rotation is valid for only one axis, it respects the roll of the valid axis. If the rotation is valid for two axes, it discards the roll of the invalid axis.

### index :: int

### copy_flags :: int

## set_copy_position :: func CopyTransformModifier3D.set_copy_position(index: int, enabled: bool) -> void
If sets [param enabled] to [code]true[/code], the position will be copied.

### index :: int

### enabled :: bool

## set_copy_rotation :: func CopyTransformModifier3D.set_copy_rotation(index: int, enabled: bool) -> void
If sets [param enabled] to [code]true[/code], the rotation will be copied.

### index :: int

### enabled :: bool

## set_copy_scale :: func CopyTransformModifier3D.set_copy_scale(index: int, enabled: bool) -> void
If sets [param enabled] to [code]true[/code], the scale will be copied.

### index :: int

### enabled :: bool

## set_invert_flags :: func CopyTransformModifier3D.set_invert_flags(index: int, axis_flags: int) -> void
Sets the flags to inverte axes. If the flag is valid, the axis is copied.
[b]Note:[/b] An inverted scale means an inverse number, not a negative scale. For example, inverting [code]2.0[/code] means [code]0.5[/code].
[b]Note:[/b] An inverted rotation flips the elements of the quaternion. For example, a two-axis inversion will flip the roll of each axis, and a three-axis inversion will flip the final orientation. However, be aware that flipping only one axis may cause unintended rotation by the unflipped axes, due to the characteristics of the quaternion.

### index :: int

### axis_flags :: int

## set_relative :: func CopyTransformModifier3D.set_relative(index: int, enabled: bool) -> void
Sets relative option in the setting at [param index] to [param enabled].
If sets [param enabled] to [code]true[/code], the extracted and applying transform is relative to the rest.
If sets [param enabled] to [code]false[/code], the extracted transform is absolute.

### index :: int

### enabled :: bool
