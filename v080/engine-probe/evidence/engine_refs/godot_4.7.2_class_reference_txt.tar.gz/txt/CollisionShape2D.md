# CollisionShape2D :: <Native> class CollisionShape2D extends Node2D
A node that provides a [Shape2D] to a [CollisionObject2D] parent.
A node that provides a [Shape2D] to a [CollisionObject2D] parent and allows it to be edited. This can give a detection shape to an [Area2D] or turn a [PhysicsBody2D] into a solid object.

## debug_color :: var CollisionShape2D.debug_color: Color
The collision shape color that is displayed in the editor, or in the running project if [b]Debug > Visible Collision Shapes[/b] is checked at the top of the editor.
[b]Note:[/b] The default value is [member ProjectSettings.debug/shapes/collision/shape_color]. The [code]Color(0, 0, 0, 0)[/code] value documented here is a placeholder, and not the actual default debug color.

## disabled :: var CollisionShape2D.disabled: bool
A disabled collision shape has no effect in the world. This property should be changed with [method Object.set_deferred].

## one_way_collision :: var CollisionShape2D.one_way_collision: bool
Sets whether this collision shape should only detect collision on one side (top or bottom).
[b]Note:[/b] This property has no effect if this [CollisionShape2D] is a child of an [Area2D] node.
[b]Note:[/b] The one way collision direction can be configured by setting [member one_way_collision_direction].

## one_way_collision_direction :: var CollisionShape2D.one_way_collision_direction: Vector2
The direction used for one-way collision.

## one_way_collision_margin :: var CollisionShape2D.one_way_collision_margin: float
The margin used for one-way collision (in pixels). Higher values will make the shape thicker, and work better for colliders that enter the shape at a high velocity.

## shape :: var CollisionShape2D.shape: Shape2D
The actual shape owned by this collision shape.
