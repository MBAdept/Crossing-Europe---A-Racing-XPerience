# AudioStreamMP3 :: <Native> class AudioStreamMP3 extends AudioStream
MP3 audio stream driver.
MP3 audio stream driver. See [member data] if you want to load an MP3 file at run-time. More info can be found in [ResourceImporterMP3].
[b]Note:[/b] This class can optionally support legacy MP1 and MP2 formats, provided that the engine is compiled with the [code]minimp3_extra_formats=yes[/code] SCons option. These extra formats are not enabled by default.

## bar_beats :: var AudioStreamMP3.bar_beats: int
The number of beats within a single bar in the audio track.

## beat_count :: var AudioStreamMP3.beat_count: int
The length of the audio track, in beats. The actual duration of the audio file might be longer than what is indicated by this property. It defines the end of the audio for looping, [AudioStreamPlaylist], and [AudioStreamInteractive].

## bpm :: var AudioStreamMP3.bpm: float
The tempo of the audio track, measured in beats per minute.

## data :: var AudioStreamMP3.data: PackedByteArray
Contains the audio data in bytes.
You can load a file without having to import it beforehand using the code snippet below. Keep in mind that this snippet loads the whole file into memory and may not be ideal for huge files (hundreds of megabytes or more).
[codeblocks]
[gdscript]
func load_mp3(path):
	var file = FileAccess.open(path, FileAccess.READ)
	var sound = AudioStreamMP3.new()
	sound.data = file.get_buffer(file.get_length())
	return sound
[/gdscript]
[csharp]
public AudioStreamMP3 LoadMP3(string path)
{
	using var file = FileAccess.Open(path, FileAccess.ModeFlags.Read);
	var sound = new AudioStreamMP3();
	sound.Data = file.GetBuffer(file.GetLength());
	return sound;
}
[/csharp]
[/codeblocks]

## loop :: var AudioStreamMP3.loop: bool
If [code]true[/code], the stream will play again from the specified [member loop_offset] once it reaches the end of the audio track, or once it reaches the end of the last beat according to the amount specified in [member beat_count]. Useful for ambient sounds and background music.

## loop_offset :: var AudioStreamMP3.loop_offset: float
Time in seconds at which the stream starts after being looped.

## load_from_buffer :: func AudioStreamMP3.load_from_buffer(stream_data: PackedByteArray) -> AudioStreamMP3
Creates a new [AudioStreamMP3] instance from the given buffer. The buffer must contain MP3 data.

### stream_data :: PackedByteArray

## load_from_file :: func AudioStreamMP3.load_from_file(path: String) -> AudioStreamMP3
Creates a new [AudioStreamMP3] instance from the given file path. The file must be in MP3 format.

### path :: String
