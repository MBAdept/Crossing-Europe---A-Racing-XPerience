# CSGBox3D :: <Native> class CSGBox3D extends CSGPrimitive3D
A CSG Box shape.
This node allows you to create a box for use with the CSG system.
[b]Note:[/b] CSG nodes are intended to be used for level prototyping. Creating CSG nodes has a significant CPU cost compared to creating a [MeshInstance3D] with a [PrimitiveMesh]. Moving a CSG node within another CSG node also has a significant CPU cost, so it should be avoided during gameplay.

## material :: var CSGBox3D.material: Material
The material used to render the box.

## size :: var CSGBox3D.size: Vector3
The box's width, height and depth.
