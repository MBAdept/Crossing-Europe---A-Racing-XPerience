# AcceptDialog :: <Native> class AcceptDialog extends Window
A base dialog used for user notification.
The default use of [AcceptDialog] is to allow it to only be accepted or closed, with the same result. However, the [signal confirmed] and [signal canceled] signals allow to make the two actions different, and the [method add_button] method allows to add custom buttons and actions.
[b]Note:[/b] [AcceptDialog] is invisible by default. To make it visible, call one of the [code]popup_*[/code] methods from [Window] on the node, such as [method Window.popup_centered_clamped].

## dialog_autowrap :: var AcceptDialog.dialog_autowrap: bool
Sets autowrapping for the text in the dialog.

## dialog_close_on_escape :: var AcceptDialog.dialog_close_on_escape: bool
If [code]true[/code], the dialog will be hidden when the [code]ui_close_dialog[/code] action is pressed (by default, this action is bound to [kbd]Escape[/kbd], or [kbd]Cmd + W[/kbd] on macOS).

## dialog_hide_on_ok :: var AcceptDialog.dialog_hide_on_ok: bool
If [code]true[/code], the dialog is hidden when the OK button is pressed. You can set it to [code]false[/code] if you want to do e.g. input validation when receiving the [signal confirmed] signal, and handle hiding the dialog in your own logic.
[b]Note:[/b] Some nodes derived from this class can have a different default value, and potentially their own built-in logic overriding this setting. For example [FileDialog] defaults to [code]false[/code], and has its own input validation code that is called when you press OK, which eventually hides the dialog if the input is valid. As such, this property can't be used in [FileDialog] to disable hiding the dialog when pressing OK.

## dialog_text :: var AcceptDialog.dialog_text: String
The text displayed by the dialog.

## exclusive :: var AcceptDialog.exclusive: bool

## keep_title_visible :: var AcceptDialog.keep_title_visible: bool

## maximize_disabled :: var AcceptDialog.maximize_disabled: bool

## minimize_disabled :: var AcceptDialog.minimize_disabled: bool

## ok_button_text :: var AcceptDialog.ok_button_text: String
The text displayed by the OK button (see [method get_ok_button]). If empty, a default text will be used.

## title :: var AcceptDialog.title: String

## transient :: var AcceptDialog.transient: bool

## visible :: var AcceptDialog.visible: bool

## wrap_controls :: var AcceptDialog.wrap_controls: bool

## buttons_min_height :: <Theme> var AcceptDialog.buttons_min_height: int
The minimum height of each button in the bottom row (such as OK/Cancel) in pixels. This can be increased to make buttons with short texts easier to click/tap.

## buttons_min_width :: <Theme> var AcceptDialog.buttons_min_width: int
The minimum width of each button in the bottom row (such as OK/Cancel) in pixels. This can be increased to make buttons with short texts easier to click/tap.

## buttons_separation :: <Theme> var AcceptDialog.buttons_separation: int
The size of the vertical space between the dialog's content and the button row.

## panel :: <Theme> var AcceptDialog.panel: StyleBox
The panel that fills the background of the window.

## add_button :: func AcceptDialog.add_button(text: String, right: bool = false, action: String = "") -> Button
Adds a button with label [param text] and a custom [param action] to the dialog and returns the created button.
If [param action] is not empty, pressing the button will emit the [signal custom_action] signal with the specified action string.
If [code]true[/code], [param right] will place the button to the right of any sibling buttons.
You can use [method remove_button] method to remove a button created with this method from the dialog.

### text :: String

### right :: bool

### action :: String

## add_cancel_button :: func AcceptDialog.add_cancel_button(name: String) -> Button
Adds a button with label [param name] and a cancel action to the dialog and returns the created button.
You can use [method remove_button] method to remove a button created with this method from the dialog.

### name :: String

## get_label :: func AcceptDialog.get_label() -> Label
Returns the label used for built-in text.
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member CanvasItem.visible] property.

## get_ok_button :: func AcceptDialog.get_ok_button() -> Button
Returns the OK [Button] instance.
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member CanvasItem.visible] property.

## register_text_enter :: func AcceptDialog.register_text_enter(line_edit: LineEdit) -> void
Registers a [LineEdit] in the dialog. When the enter key is pressed, the dialog will be accepted.

### line_edit :: LineEdit

## remove_button :: func AcceptDialog.remove_button(button: Button) -> void
Removes the [param button] from the dialog. Does NOT free the [param button]. The [param button] must be a [Button] added with [method add_button] or [method add_cancel_button] method. After removal, pressing the [param button] will no longer emit this dialog's [signal custom_action] or [signal canceled] signals.

### button :: Button

## canceled :: func AcceptDialog.canceled() -> void
Emitted when the dialog is closed or the button created with [method add_cancel_button] is pressed.

## confirmed :: func AcceptDialog.confirmed() -> void
Emitted when the dialog is accepted, i.e. the OK button is pressed.

## custom_action :: func AcceptDialog.custom_action(action: StringName) -> void
Emitted when a custom button with an action is pressed. See [method add_button].

### action :: StringName
