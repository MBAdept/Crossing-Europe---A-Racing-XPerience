# ClassDB :: <Native> class ClassDB extends Object
A class information repository.
Provides access to metadata stored for every available engine class.
[b]Note:[/b] Script-defined classes with [code]class_name[/code] are not part of [ClassDB], so they will not return reflection data such as a method or property list. However, [GDExtension]-defined classes [i]are[/i] part of [ClassDB], so they will return reflection data.

## API_CORE :: const ClassDB.API_CORE: APIType = 0
Native Core class type.

## API_EDITOR :: const ClassDB.API_EDITOR: APIType = 1
Native Editor class type.

## API_EXTENSION :: const ClassDB.API_EXTENSION: APIType = 2
GDExtension class type.

## API_EDITOR_EXTENSION :: const ClassDB.API_EDITOR_EXTENSION: APIType = 3
GDExtension Editor class type.

## API_NONE :: const ClassDB.API_NONE: APIType = 4
Unknown class type.

## can_instantiate :: func ClassDB.can_instantiate(class: StringName) -> bool
Returns [code]true[/code] if objects can be instantiated from the specified [param class], otherwise returns [code]false[/code].

### class :: StringName

## class_call_static :: func ClassDB.class_call_static(class: StringName, method: StringName, ...) -> Variant
Calls a static method on a class.

### class :: StringName

### method :: StringName

## class_exists :: func ClassDB.class_exists(class: StringName) -> bool
Returns whether the specified [param class] is available or not.

### class :: StringName

## class_get_api_type :: func ClassDB.class_get_api_type(class: StringName) -> int
Returns the API type of the specified [param class].

### class :: StringName

## class_get_enum_constants :: func ClassDB.class_get_enum_constants(class: StringName, enum: StringName, no_inheritance: bool = false) -> PackedStringArray
Returns an array with all the keys in [param enum] of [param class] or its ancestry.

### class :: StringName

### enum :: StringName

### no_inheritance :: bool

## class_get_enum_list :: func ClassDB.class_get_enum_list(class: StringName, no_inheritance: bool = false) -> PackedStringArray
Returns an array with all the enums of [param class] or its ancestry.

### class :: StringName

### no_inheritance :: bool

## class_get_integer_constant :: func ClassDB.class_get_integer_constant(class: StringName, name: StringName) -> int
Returns the value of the integer constant [param name] of [param class] or its ancestry. Always returns 0 when the constant could not be found.

### class :: StringName

### name :: StringName

## class_get_integer_constant_enum :: func ClassDB.class_get_integer_constant_enum(class: StringName, name: StringName, no_inheritance: bool = false) -> StringName
Returns which enum the integer constant [param name] of [param class] or its ancestry belongs to.

### class :: StringName

### name :: StringName

### no_inheritance :: bool

## class_get_integer_constant_list :: func ClassDB.class_get_integer_constant_list(class: StringName, no_inheritance: bool = false) -> PackedStringArray
Returns an array with the names all the integer constants of [param class] or its ancestry.

### class :: StringName

### no_inheritance :: bool

## class_get_method_argument_count :: func ClassDB.class_get_method_argument_count(class: StringName, method: StringName, no_inheritance: bool = false) -> int
Returns the number of arguments of the method [param method] of [param class] or its ancestry if [param no_inheritance] is [code]false[/code].

### class :: StringName

### method :: StringName

### no_inheritance :: bool

## class_get_method_list :: func ClassDB.class_get_method_list(class: StringName, no_inheritance: bool = false) -> Dictionary[]
Returns an array with all the methods of [param class] or its ancestry if [param no_inheritance] is [code]false[/code]. Every element of the array is a [Dictionary] with the following keys: [code]args[/code], [code]default_args[/code], [code]flags[/code], [code]id[/code], [code]name[/code], [code]return: (class_name, hint, hint_string, name, type, usage)[/code].
[b]Note:[/b] In exported release builds the debug info is not available, so the returned dictionaries will contain only method names.

### class :: StringName

### no_inheritance :: bool

## class_get_property :: func ClassDB.class_get_property(object: Object, property: StringName) -> Variant
Returns the value of [param property] of [param object] or its ancestry.

### object :: Object

### property :: StringName

## class_get_property_default_value :: func ClassDB.class_get_property_default_value(class: StringName, property: StringName) -> Variant
Returns the default value of [param property] of [param class] or its ancestor classes.

### class :: StringName

### property :: StringName

## class_get_property_getter :: func ClassDB.class_get_property_getter(class: StringName, property: StringName) -> StringName
Returns the getter method name of [param property] of [param class].

### class :: StringName

### property :: StringName

## class_get_property_list :: func ClassDB.class_get_property_list(class: StringName, no_inheritance: bool = false) -> Dictionary[]
Returns an array with all the properties of [param class] or its ancestry if [param no_inheritance] is [code]false[/code].

### class :: StringName

### no_inheritance :: bool

## class_get_property_setter :: func ClassDB.class_get_property_setter(class: StringName, property: StringName) -> StringName
Returns the setter method name of [param property] of [param class].

### class :: StringName

### property :: StringName

## class_get_signal :: func ClassDB.class_get_signal(class: StringName, signal: StringName) -> Dictionary
Returns the [param signal] data of [param class] or its ancestry. The returned value is a [Dictionary] with the following keys: [code]args[/code], [code]default_args[/code], [code]flags[/code], [code]id[/code], [code]name[/code], [code]return: (class_name, hint, hint_string, name, type, usage)[/code].

### class :: StringName

### signal :: StringName

## class_get_signal_list :: func ClassDB.class_get_signal_list(class: StringName, no_inheritance: bool = false) -> Dictionary[]
Returns an array with all the signals of [param class] or its ancestry if [param no_inheritance] is [code]false[/code]. Every element of the array is a [Dictionary] as described in [method class_get_signal].

### class :: StringName

### no_inheritance :: bool

## class_has_enum :: func ClassDB.class_has_enum(class: StringName, name: StringName, no_inheritance: bool = false) -> bool
Returns whether [param class] or its ancestry has an enum called [param name] or not.

### class :: StringName

### name :: StringName

### no_inheritance :: bool

## class_has_integer_constant :: func ClassDB.class_has_integer_constant(class: StringName, name: StringName) -> bool
Returns whether [param class] or its ancestry has an integer constant called [param name] or not.

### class :: StringName

### name :: StringName

## class_has_method :: func ClassDB.class_has_method(class: StringName, method: StringName, no_inheritance: bool = false) -> bool
Returns whether [param class] (or its ancestry if [param no_inheritance] is [code]false[/code]) has a method called [param method] or not.

### class :: StringName

### method :: StringName

### no_inheritance :: bool

## class_has_signal :: func ClassDB.class_has_signal(class: StringName, signal: StringName) -> bool
Returns whether [param class] or its ancestry has a signal called [param signal] or not.

### class :: StringName

### signal :: StringName

## class_set_property :: func ClassDB.class_set_property(object: Object, property: StringName, value: Variant) -> int
Sets [param property] value of [param object] to [param value].

### object :: Object

### property :: StringName

### value :: Variant

## get_class_list :: func ClassDB.get_class_list() -> PackedStringArray
Returns the names of all engine classes available.
[b]Note:[/b] Script-defined classes with [code]class_name[/code] are not included in this list. Use [method ProjectSettings.get_global_class_list] to get a list of script-defined classes instead.

## get_inheriters_from_class :: func ClassDB.get_inheriters_from_class(class: StringName) -> PackedStringArray
Returns the names of all engine classes that directly or indirectly inherit from [param class].

### class :: StringName

## get_parent_class :: func ClassDB.get_parent_class(class: StringName) -> StringName
Returns the parent class of [param class].

### class :: StringName

## instantiate :: func ClassDB.instantiate(class: StringName) -> Variant
Creates an instance of [param class].

### class :: StringName

## is_class_enabled :: func ClassDB.is_class_enabled(class: StringName) -> bool
Returns whether this [param class] is enabled or not.

### class :: StringName

## is_class_enum_bitfield :: func ClassDB.is_class_enum_bitfield(class: StringName, enum: StringName, no_inheritance: bool = false) -> bool
Returns whether [param class] (or its ancestor classes if [param no_inheritance] is [code]false[/code]) has an enum called [param enum] that is a bitfield.

### class :: StringName

### enum :: StringName

### no_inheritance :: bool

## is_parent_class :: func ClassDB.is_parent_class(class: StringName, inherits: StringName) -> bool
Returns whether [param inherits] is an ancestor of [param class] or not.

### class :: StringName

### inherits :: StringName
