# IKModifier3D :: <Native> class IKModifier3D extends SkeletonModifier3D
A node for inverse kinematics which may modify more than one bone.
Base class of [SkeletonModifier3D]s that has some joint lists and applies inverse kinematics. This class has some structs, enums, and helper methods which are useful to solve inverse kinematics.

## mutable_bone_axes :: var IKModifier3D.mutable_bone_axes: bool
If [code]true[/code], the solver retrieves the bone axis from the bone pose every frame.
If [code]false[/code], the solver retrieves the bone axis from the bone rest and caches it, which increases performance slightly, but position changes in the bone pose made before processing this [IKModifier3D] are ignored.

## clear_settings :: func IKModifier3D.clear_settings() -> void
Clears all settings.

## get_setting_count :: func IKModifier3D.get_setting_count() -> int
Returns the number of settings.

## reset :: func IKModifier3D.reset() -> void
Resets a state with respect to the current bone pose.

## set_setting_count :: func IKModifier3D.set_setting_count(count: int) -> void
Sets the number of settings.

### count :: int
