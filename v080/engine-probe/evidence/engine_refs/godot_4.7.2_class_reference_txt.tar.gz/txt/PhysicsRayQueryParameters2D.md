# PhysicsRayQueryParameters2D :: <Native> class PhysicsRayQueryParameters2D extends RefCounted
Provides parameters for [method PhysicsDirectSpaceState2D.intersect_ray].
By changing various properties of this object, such as the ray position, you can configure the parameters for [method PhysicsDirectSpaceState2D.intersect_ray].

## collide_with_areas :: var PhysicsRayQueryParameters2D.collide_with_areas: bool
If [code]true[/code], the query will take [Area2D]s into account.

## collide_with_bodies :: var PhysicsRayQueryParameters2D.collide_with_bodies: bool
If [code]true[/code], the query will take [PhysicsBody2D]s into account.

## collision_mask :: var PhysicsRayQueryParameters2D.collision_mask: int
The physics layers the query will detect (as a bitmask). By default, all collision layers are detected. See [url=https://docs.godotengine.org/en/4.7/tutorials/physics/physics_introduction.html#collision-layers-and-masks]Collision layers and masks[/url] in the documentation for more information.

## exclude :: var PhysicsRayQueryParameters2D.exclude: RID[]
The list of object [RID]s that will be excluded from collisions. Use [method CollisionObject2D.get_rid] to get the [RID] associated with a [CollisionObject2D]-derived node.
[b]Note:[/b] The returned array is copied and any changes to it will not update the original property value. To update the value you need to modify the returned array, and then assign it to the property again.

## from :: var PhysicsRayQueryParameters2D.from: Vector2
The starting point of the ray being queried for, in global coordinates.

## hit_from_inside :: var PhysicsRayQueryParameters2D.hit_from_inside: bool
If [code]true[/code], the query will detect a hit when starting inside shapes. In this case the collision normal will be [code]Vector2(0, 0)[/code]. Does not affect concave polygon shapes.

## to :: var PhysicsRayQueryParameters2D.to: Vector2
The ending point of the ray being queried for, in global coordinates.

## create :: func PhysicsRayQueryParameters2D.create(from: Vector2, to: Vector2, collision_mask: int = 4294967295, exclude: RID[] = []) -> PhysicsRayQueryParameters2D
Returns a new, pre-configured [PhysicsRayQueryParameters2D] object. Use it to quickly create query parameters using the most common options.
[codeblock]
var query = PhysicsRayQueryParameters2D.create(global_position, global_position + Vector2(0, 100))
var collision = get_world_2d().direct_space_state.intersect_ray(query)
[/codeblock]

### from :: Vector2

### to :: Vector2

### collision_mask :: int

### exclude :: RID[]
