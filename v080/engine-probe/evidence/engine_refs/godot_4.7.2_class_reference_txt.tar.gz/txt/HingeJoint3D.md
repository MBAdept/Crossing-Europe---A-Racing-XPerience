# HingeJoint3D :: <Native> class HingeJoint3D extends Joint3D
A physics joint that restricts the rotation of a 3D physics body around an axis relative to another physics body.
A physics joint that restricts the rotation of a 3D physics body around an axis relative to another physics body. For example, Body A can be a [StaticBody3D] representing a door hinge that a [RigidBody3D] rotates around.

## PARAM_BIAS :: const HingeJoint3D.PARAM_BIAS: Param = 0
The speed with which the two bodies get pulled together when they move in different directions.

## PARAM_LIMIT_UPPER :: const HingeJoint3D.PARAM_LIMIT_UPPER: Param = 1
The maximum rotation. Only active if [member angular_limit/enable] is [code]true[/code].

## PARAM_LIMIT_LOWER :: const HingeJoint3D.PARAM_LIMIT_LOWER: Param = 2
The minimum rotation. Only active if [member angular_limit/enable] is [code]true[/code].

## PARAM_LIMIT_BIAS :: const HingeJoint3D.PARAM_LIMIT_BIAS: Param = 3
The speed with which the rotation across the axis perpendicular to the hinge gets corrected.

## PARAM_LIMIT_SOFTNESS :: const HingeJoint3D.PARAM_LIMIT_SOFTNESS: Param = 4

## PARAM_LIMIT_RELAXATION :: const HingeJoint3D.PARAM_LIMIT_RELAXATION: Param = 5
The lower this value, the more the rotation gets slowed down.

## PARAM_MOTOR_TARGET_VELOCITY :: const HingeJoint3D.PARAM_MOTOR_TARGET_VELOCITY: Param = 6
Target speed for the motor.

## PARAM_MOTOR_MAX_IMPULSE :: const HingeJoint3D.PARAM_MOTOR_MAX_IMPULSE: Param = 7
Maximum acceleration for the motor.

## PARAM_MAX :: const HingeJoint3D.PARAM_MAX: Param = 8
Represents the size of the [enum Param] enum.

## FLAG_USE_LIMIT :: const HingeJoint3D.FLAG_USE_LIMIT: Flag = 0
If [code]true[/code], the hinges maximum and minimum rotation, defined by [member angular_limit/lower] and [member angular_limit/upper] has effects.

## FLAG_ENABLE_MOTOR :: const HingeJoint3D.FLAG_ENABLE_MOTOR: Flag = 1
When activated, a motor turns the hinge.

## FLAG_MAX :: const HingeJoint3D.FLAG_MAX: Flag = 2
Represents the size of the [enum Flag] enum.

## angular_limit/bias :: var HingeJoint3D.angular_limit/bias: float
The speed with which the rotation across the axis perpendicular to the hinge gets corrected.

## angular_limit/enable :: var HingeJoint3D.angular_limit/enable: bool
If [code]true[/code], the hinges maximum and minimum rotation, defined by [member angular_limit/lower] and [member angular_limit/upper] has effects.

## angular_limit/lower :: var HingeJoint3D.angular_limit/lower: float
The minimum rotation. Only active if [member angular_limit/enable] is [code]true[/code].

## angular_limit/relaxation :: var HingeJoint3D.angular_limit/relaxation: float
The lower this value, the more the rotation gets slowed down.

## angular_limit/softness :: var HingeJoint3D.angular_limit/softness: float

## angular_limit/upper :: var HingeJoint3D.angular_limit/upper: float
The maximum rotation. Only active if [member angular_limit/enable] is [code]true[/code].

## motor/enable :: var HingeJoint3D.motor/enable: bool
When activated, a motor turns the hinge.

## motor/max_impulse :: var HingeJoint3D.motor/max_impulse: float
Maximum acceleration for the motor.

## motor/target_velocity :: var HingeJoint3D.motor/target_velocity: float
Target speed for the motor.

## params/bias :: var HingeJoint3D.params/bias: float
The speed with which the two bodies get pulled together when they move in different directions.

## get_flag :: func HingeJoint3D.get_flag(flag: int) -> bool
Returns the value of the specified flag.

### flag :: int

## get_param :: func HingeJoint3D.get_param(param: int) -> float
Returns the value of the specified parameter.

### param :: int

## set_flag :: func HingeJoint3D.set_flag(flag: int, enabled: bool) -> void
If [code]true[/code], enables the specified flag.

### flag :: int

### enabled :: bool

## set_param :: func HingeJoint3D.set_param(param: int, value: float) -> void
Sets the value of the specified parameter.

### param :: int

### value :: float
