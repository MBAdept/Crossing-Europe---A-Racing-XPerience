# AudioStreamPlaybackSynchronized :: <Native> class AudioStreamPlaybackSynchronized extends AudioStreamPlayback
Playback class used for [AudioStreamSynchronized].
Playback component of [AudioStreamSynchronized]. Handles the playback of multiple [AudioStream]s in synchrony.
