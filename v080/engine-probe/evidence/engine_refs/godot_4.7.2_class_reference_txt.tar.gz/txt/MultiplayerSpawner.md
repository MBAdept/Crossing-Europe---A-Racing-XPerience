# MultiplayerSpawner :: <Native> class MultiplayerSpawner extends Node
Automatically replicates spawnable nodes from the authority to other multiplayer peers.
Spawnable scenes can be configured in the editor or through code (see [method add_spawnable_scene]).
Also supports custom node spawns through [method spawn], calling [member spawn_function] on all peers.
Internally, [MultiplayerSpawner] uses [method MultiplayerAPI.object_configuration_add] to notify spawns passing the spawned node as the [code]object[/code] and itself as the [code]configuration[/code], and [method MultiplayerAPI.object_configuration_remove] to notify despawns in a similar way.

## spawn_function :: var MultiplayerSpawner.spawn_function: Callable
Method called on all peers when a custom [method spawn] is requested by the authority. Will receive the [code]data[/code] parameter, and should return a [Node] that is not in the scene tree.
[b]Note:[/b] The returned node should [b]not[/b] be added to the scene with [method Node.add_child]. This is done automatically.

## spawn_limit :: var MultiplayerSpawner.spawn_limit: int
Maximum number of nodes allowed to be spawned by this spawner. Includes both spawnable scenes and custom spawns.
When set to [code]0[/code] (the default), there is no limit.

## spawn_path :: var MultiplayerSpawner.spawn_path: NodePath
Path to the spawn root. Spawnable scenes that are added as direct children are replicated to other peers.

## add_spawnable_scene :: func MultiplayerSpawner.add_spawnable_scene(path: String) -> void
Adds a scene path to spawnable scenes, making it automatically replicated from the multiplayer authority to other peers when added as children of the node pointed by [member spawn_path].

### path :: String

## clear_spawnable_scenes :: func MultiplayerSpawner.clear_spawnable_scenes() -> void
Clears all spawnable scenes. Does not despawn existing instances on remote peers.

## get_spawnable_scene :: func MultiplayerSpawner.get_spawnable_scene(index: int) -> String
Returns the spawnable scene path by index.

### index :: int

## get_spawnable_scene_count :: func MultiplayerSpawner.get_spawnable_scene_count() -> int
Returns the count of spawnable scene paths.

## spawn :: func MultiplayerSpawner.spawn(data: Variant = null) -> Node
Requests a custom spawn, with [param data] passed to [member spawn_function] on all peers. Returns the locally spawned node instance already inside the scene tree, and added as a child of the node pointed by [member spawn_path].
[b]Note:[/b] Spawnable scenes are spawned automatically. [method spawn] is only needed for custom spawns.

### data :: Variant

## despawned :: func MultiplayerSpawner.despawned(node: Node) -> void
Emitted when a spawnable scene or custom spawn was despawned by the multiplayer authority. Only called on remote peers.

### node :: Node

## spawned :: func MultiplayerSpawner.spawned(node: Node) -> void
Emitted when a spawnable scene or custom spawn was spawned by the multiplayer authority. Only called on remote peers.

### node :: Node
