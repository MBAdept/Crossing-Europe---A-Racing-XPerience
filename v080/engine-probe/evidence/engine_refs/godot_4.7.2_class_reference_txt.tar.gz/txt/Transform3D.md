# Transform3D :: <Native> class Transform3D
A 3×4 matrix representing a 3D transformation.
The [Transform3D] built-in [Variant] type is a 3×4 matrix representing a transformation in 3D space. It contains a [Basis], which on its own can represent rotation, scale, and shear. Additionally, combined with its own [member origin], the transform can also represent a translation.
For a general introduction, see the [url=https://docs.godotengine.org/en/4.7/tutorials/math/matrices_and_transforms.html]Matrices and transforms[/url] tutorial.
[b]Note:[/b] Godot uses a [url=https://en.wikipedia.org/wiki/Right-hand_rule]right-handed coordinate system[/url], which is a common standard. For directions, the convention for built-in types like [Camera3D] is for -Z to point forward (+X is right, +Y is up, and +Z is back). Other objects may use different direction conventions. For more information, see the [url=https://docs.godotengine.org/en/4.7/tutorials/assets_pipeline/importing_3d_scenes/model_export_considerations.html#d-asset-direction-conventions]3D asset direction conventions[/url] tutorial.
[b]Note:[/b] In a boolean context, a Transform3D will evaluate to [code]false[/code] if it's equal to [constant IDENTITY]. Otherwise, a Transform3D will always evaluate to [code]true[/code].

## IDENTITY :: const Transform3D.IDENTITY = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
The identity [Transform3D]. This is a transform with no translation, no rotation, and a scale of [constant Vector3.ONE]. Its [member basis] is equal to [constant Basis.IDENTITY]. This also means that:
- Its [member Basis.x] points right ([constant Vector3.RIGHT]);
- Its [member Basis.y] points up ([constant Vector3.UP]);
- Its [member Basis.z] points back ([constant Vector3.BACK]).
[codeblock]
var transform = Transform3D.IDENTITY
var basis = transform.basis
print("| X | Y | Z | Origin")
print("| %.f | %.f | %.f | %.f" % [basis.x.x, basis.y.x, basis.z.x, transform.origin.x])
print("| %.f | %.f | %.f | %.f" % [basis.x.y, basis.y.y, basis.z.y, transform.origin.y])
print("| %.f | %.f | %.f | %.f" % [basis.x.z, basis.y.z, basis.z.z, transform.origin.z])
# Prints:
# | X | Y | Z | Origin
# | 1 | 0 | 0 | 0
# | 0 | 1 | 0 | 0
# | 0 | 0 | 1 | 0
[/codeblock]
If a [Vector3], an [AABB], a [Plane], a [PackedVector3Array], or another [Transform3D] is transformed (multiplied) by this constant, no transformation occurs.
[b]Note:[/b] In GDScript, this constant is equivalent to creating a [constructor Transform3D] without any arguments. It can be used to make your code clearer, and for consistency with C#.

## FLIP_X :: const Transform3D.FLIP_X = Transform3D(-1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
[Transform3D] with mirroring applied perpendicular to the YZ plane. Its [member basis] is equal to [constant Basis.FLIP_X].

## FLIP_Y :: const Transform3D.FLIP_Y = Transform3D(1, 0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0)
[Transform3D] with mirroring applied perpendicular to the XZ plane. Its [member basis] is equal to [constant Basis.FLIP_Y].

## FLIP_Z :: const Transform3D.FLIP_Z = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0)
[Transform3D] with mirroring applied perpendicular to the XY plane. Its [member basis] is equal to [constant Basis.FLIP_Z].

## basis :: var Transform3D.basis: Basis
The [Basis] of this transform. It is composed by 3 axes ([member Basis.x], [member Basis.y], and [member Basis.z]). Together, these represent the transform's rotation, scale, and shear.

## origin :: var Transform3D.origin: Vector3
The translation offset of this transform. In 3D space, this can be seen as the position.

## affine_inverse :: func Transform3D.affine_inverse() -> Transform3D
Returns the inverted version of this transform. Unlike [method inverse], this method works with almost any [member basis], including non-uniform ones, but is slower. See also [method Basis.inverse].
[b]Note:[/b] For this method to return correctly, the transform's [member basis] needs to have a determinant that is not exactly [code]0.0[/code] (see [method Basis.determinant]).

## interpolate_with :: func Transform3D.interpolate_with(xform: Transform3D, weight: float) -> Transform3D
Returns the result of the linear interpolation between this transform and [param xform] by the given [param weight].
The [param weight] should be between [code]0.0[/code] and [code]1.0[/code] (inclusive). Values outside this range are allowed and can be used to perform [i]extrapolation[/i] instead.

### xform :: Transform3D

### weight :: float

## inverse :: func Transform3D.inverse() -> Transform3D
Returns the [url=https://en.wikipedia.org/wiki/Invertible_matrix]inverted version of this transform[/url]. See also [method Basis.inverse].
[b]Note:[/b] For this method to return correctly, the transform's [member basis] needs to be [i]orthonormal[/i] (see [method orthonormalized]). That means the basis should only represent a rotation. If it does not, use [method affine_inverse] instead.

## is_equal_approx :: func Transform3D.is_equal_approx(xform: Transform3D) -> bool
Returns [code]true[/code] if this transform and [param xform] are approximately equal, by running [method @GlobalScope.is_equal_approx] on each component.

### xform :: Transform3D

## is_finite :: func Transform3D.is_finite() -> bool
Returns [code]true[/code] if this transform is finite, by calling [method @GlobalScope.is_finite] on each component.

## looking_at :: func Transform3D.looking_at(target: Vector3, up: Vector3 = Vector3(0, 1, 0), use_model_front: bool = false) -> Transform3D
Returns a copy of this transform rotated so that the forward axis (-Z) points towards the [param target] position.
The up axis (+Y) points as close to the [param up] vector as possible while staying perpendicular to the forward axis. The resulting transform is orthonormalized. The existing rotation, scale, and skew information from the original transform is discarded. The [param target] and [param up] vectors cannot be zero, cannot be parallel to each other, and are defined in global/parent space.
If [param use_model_front] is [code]true[/code], the +Z axis (asset front) is treated as forward (implies +X is left) and points toward the [param target] position. By default, the -Z axis (camera forward) is treated as forward (implies +X is right).

### target :: Vector3

### up :: Vector3

### use_model_front :: bool

## orthonormalized :: func Transform3D.orthonormalized() -> Transform3D
Returns a copy of this transform with its [member basis] orthonormalized. An orthonormal basis is both [i]orthogonal[/i] (the axes are perpendicular to each other) and [i]normalized[/i] (the axes have a length of [code]1.0[/code]), which also means it can only represent a rotation. See also [method Basis.orthonormalized].

## rotated :: func Transform3D.rotated(axis: Vector3, angle: float) -> Transform3D
Returns a copy of this transform rotated around the given [param axis] by the given [param angle] (in radians).
The [param axis] must be a normalized vector (see [method Vector3.normalized]). If [param angle] is positive, the basis is rotated counter-clockwise around the axis.
This method is an optimized version of multiplying the given transform [code]X[/code] with a corresponding rotation transform [code]R[/code] from the left, i.e., [code]R * X[/code].
This can be seen as transforming with respect to the global/parent frame.

### axis :: Vector3

### angle :: float

## rotated_local :: func Transform3D.rotated_local(axis: Vector3, angle: float) -> Transform3D
Returns a copy of this transform rotated around the given [param axis] by the given [param angle] (in radians).
The [param axis] must be a normalized vector in the transform's local coordinate system. For example, to rotate around the local X-axis, use [constant Vector3.RIGHT].
This method is an optimized version of multiplying the given transform [code]X[/code] with a corresponding rotation transform [code]R[/code] from the right, i.e., [code]X * R[/code].
This can be seen as transforming with respect to the local frame.

### axis :: Vector3

### angle :: float

## scaled :: func Transform3D.scaled(scale: Vector3) -> Transform3D
Returns a copy of this transform scaled by the given [param scale] factor.
This method is an optimized version of multiplying the given transform [code]X[/code] with a corresponding scaling transform [code]S[/code] from the left, i.e., [code]S * X[/code].
This can be seen as transforming with respect to the global/parent frame.

### scale :: Vector3

## scaled_local :: func Transform3D.scaled_local(scale: Vector3) -> Transform3D
Returns a copy of this transform scaled by the given [param scale] factor.
This method is an optimized version of multiplying the given transform [code]X[/code] with a corresponding scaling transform [code]S[/code] from the right, i.e., [code]X * S[/code].
This can be seen as transforming with respect to the local frame.

### scale :: Vector3

## translated :: func Transform3D.translated(offset: Vector3) -> Transform3D
Returns a copy of this transform translated by the given [param offset].
This method is an optimized version of multiplying the given transform [code]X[/code] with a corresponding translation transform [code]T[/code] from the left, i.e., [code]T * X[/code].
This can be seen as transforming with respect to the global/parent frame.

### offset :: Vector3

## translated_local :: func Transform3D.translated_local(offset: Vector3) -> Transform3D
Returns a copy of this transform translated by the given [param offset].
This method is an optimized version of multiplying the given transform [code]X[/code] with a corresponding translation transform [code]T[/code] from the right, i.e., [code]X * T[/code].
This can be seen as transforming with respect to the local frame.

### offset :: Vector3

## Transform3D :: func Transform3D.Transform3D() -> Transform3D
Constructs a [Transform3D] identical to [constant IDENTITY].
[b]Note:[/b] In C#, this constructs a [Transform3D] with its [member origin] and the components of its [member basis] set to [constant Vector3.ZERO].

## Transform3D :: func Transform3D.Transform3D(from: Transform3D) -> Transform3D
Constructs a [Transform3D] as a copy of the given [Transform3D].

### from :: Transform3D

## Transform3D :: func Transform3D.Transform3D(basis: Basis, origin: Vector3) -> Transform3D
Constructs a [Transform3D] from a [Basis] and [Vector3].

### basis :: Basis

### origin :: Vector3

## Transform3D :: func Transform3D.Transform3D(from: Projection) -> Transform3D
Constructs a [Transform3D] from a [Projection]. Because [Transform3D] is a 3×4 matrix and [Projection] is a 4×4 matrix, this operation trims the last row of the projection matrix ([code]from.x.w[/code], [code]from.y.w[/code], [code]from.z.w[/code], and [code]from.w.w[/code] are not included in the new transform).

### from :: Projection

## Transform3D :: func Transform3D.Transform3D(x_axis: Vector3, y_axis: Vector3, z_axis: Vector3, origin: Vector3) -> Transform3D
Constructs a [Transform3D] from four [Vector3] values (also called matrix columns).
The first three arguments are the [member basis]'s axes ([member Basis.x], [member Basis.y], and [member Basis.z]).

### x_axis :: Vector3

### y_axis :: Vector3

### z_axis :: Vector3

### origin :: Vector3

## operator != :: func Transform3D.operator !=(right: Transform3D) -> bool
Returns [code]true[/code] if the components of both transforms are not equal.
[b]Note:[/b] Due to floating-point precision errors, consider using [method is_equal_approx] instead, which is more reliable.

### right :: Transform3D

## operator * :: func Transform3D.operator *(right: AABB) -> AABB
Transforms (multiplies) the [AABB] by this transformation matrix.

### right :: AABB

## operator * :: func Transform3D.operator *(right: PackedVector3Array) -> PackedVector3Array
Transforms (multiplies) every [Vector3] element of the given [PackedVector3Array] by this transformation matrix.
On larger arrays, this operation is much faster than transforming each [Vector3] individually.

### right :: PackedVector3Array

## operator * :: func Transform3D.operator *(right: Plane) -> Plane
Transforms (multiplies) the [Plane] by this transformation matrix.

### right :: Plane

## operator * :: func Transform3D.operator *(right: Transform3D) -> Transform3D
Transforms (multiplies) this transform by the [param right] transform.
This is the operation performed between parent and child [Node3D]s.
[b]Note:[/b] If you need to only modify one attribute of this transform, consider using one of the following methods, instead:
- For translation, see [method translated] or [method translated_local].
- For rotation, see [method rotated] or [method rotated_local].
- For scale, see [method scaled] or [method scaled_local].

### right :: Transform3D

## operator * :: func Transform3D.operator *(right: Vector3) -> Vector3
Transforms (multiplies) the [Vector3] by this transformation matrix.

### right :: Vector3

## operator * :: func Transform3D.operator *(right: float) -> Transform3D
Multiplies all components of the [Transform3D] by the given [float], including the [member origin]. This affects the transform's scale uniformly, scaling the [member basis].

### right :: float

## operator * :: func Transform3D.operator *(right: int) -> Transform3D
Multiplies all components of the [Transform3D] by the given [int], including the [member origin]. This affects the transform's scale uniformly, scaling the [member basis].

### right :: int

## operator / :: func Transform3D.operator /(right: float) -> Transform3D
Divides all components of the [Transform3D] by the given [float], including the [member origin]. This affects the transform's scale uniformly, scaling the [member basis].

### right :: float

## operator / :: func Transform3D.operator /(right: int) -> Transform3D
Divides all components of the [Transform3D] by the given [int], including the [member origin]. This affects the transform's scale uniformly, scaling the [member basis].

### right :: int

## operator == :: func Transform3D.operator ==(right: Transform3D) -> bool
Returns [code]true[/code] if the components of both transforms are exactly equal.
[b]Note:[/b] Due to floating-point precision errors, consider using [method is_equal_approx] instead, which is more reliable.

### right :: Transform3D
