# Light2D :: <Native> class Light2D extends Node2D
Casts light in a 2D environment.
Casts light in a 2D environment. A light is defined as a color, an energy value, a mode (see constants), and various other parameters (range and shadows-related).

## SHADOW_FILTER_NONE :: const Light2D.SHADOW_FILTER_NONE: ShadowFilter = 0
No filter applies to the shadow map. This provides hard shadow edges and is the fastest to render. See [member shadow_filter].

## SHADOW_FILTER_PCF5 :: const Light2D.SHADOW_FILTER_PCF5: ShadowFilter = 1
Percentage closer filtering (5 samples) applies to the shadow map. This is slower compared to hard shadow rendering. See [member shadow_filter].

## SHADOW_FILTER_PCF13 :: const Light2D.SHADOW_FILTER_PCF13: ShadowFilter = 2
Percentage closer filtering (13 samples) applies to the shadow map. This is the slowest shadow filtering mode, and should be used sparingly. See [member shadow_filter].

## BLEND_MODE_ADD :: const Light2D.BLEND_MODE_ADD: BlendMode = 0
Adds the value of pixels corresponding to the Light2D to the values of pixels under it. This is the common behavior of a light.

## BLEND_MODE_SUB :: const Light2D.BLEND_MODE_SUB: BlendMode = 1
Subtracts the value of pixels corresponding to the Light2D to the values of pixels under it, resulting in inversed light effect.

## BLEND_MODE_MIX :: const Light2D.BLEND_MODE_MIX: BlendMode = 2
Mix the value of pixels corresponding to the Light2D to the values of pixels under it by linear interpolation.

## blend_mode :: var Light2D.blend_mode: Light2D.BlendMode
The Light2D's blend mode.

## color :: var Light2D.color: Color
The Light2D's [Color].

## editor_only :: var Light2D.editor_only: bool
If [code]true[/code], Light2D will only appear when editing the scene.

## enabled :: var Light2D.enabled: bool
If [code]true[/code], Light2D will emit light.

## energy :: var Light2D.energy: float
The Light2D's energy value. The larger the value, the stronger the light.

## range_item_cull_mask :: var Light2D.range_item_cull_mask: int
The layer mask. Only objects with a matching [member CanvasItem.light_mask] will be affected by the Light2D. See also [member shadow_item_cull_mask], which affects which objects can cast shadows.
[b]Note:[/b] [member range_item_cull_mask] is ignored by [DirectionalLight2D], which will always light a 2D node regardless of the 2D node's [member CanvasItem.light_mask].

## range_layer_max :: var Light2D.range_layer_max: int
Maximum layer value of objects that are affected by the Light2D.

## range_layer_min :: var Light2D.range_layer_min: int
Minimum layer value of objects that are affected by the Light2D.

## range_z_max :: var Light2D.range_z_max: int
Maximum [code]z[/code] value of objects that are affected by the Light2D.

## range_z_min :: var Light2D.range_z_min: int
Minimum [code]z[/code] value of objects that are affected by the Light2D.

## shadow_color :: var Light2D.shadow_color: Color
[Color] of shadows cast by the Light2D.

## shadow_enabled :: var Light2D.shadow_enabled: bool
If [code]true[/code], the Light2D will cast shadows.

## shadow_filter :: var Light2D.shadow_filter: Light2D.ShadowFilter
Shadow filter type.

## shadow_filter_smooth :: var Light2D.shadow_filter_smooth: float
Smoothing value for shadows. Higher values will result in softer shadows, at the cost of visible streaks that can appear in shadow rendering. [member shadow_filter_smooth] only has an effect if [member shadow_filter] is [constant SHADOW_FILTER_PCF5] or [constant SHADOW_FILTER_PCF13].

## shadow_item_cull_mask :: var Light2D.shadow_item_cull_mask: int
The shadow mask. Used with [LightOccluder2D] to cast shadows. Only occluders with a matching [member CanvasItem.light_mask] will cast shadows. See also [member range_item_cull_mask], which affects which objects can [i]receive[/i] the light.

## get_height :: func Light2D.get_height() -> float
Returns the light's height, which is used in 2D normal mapping. See [member PointLight2D.height] and [member DirectionalLight2D.height].

## set_height :: func Light2D.set_height(height: float) -> void
Sets the light's height, which is used in 2D normal mapping. See [member PointLight2D.height] and [member DirectionalLight2D.height].

### height :: float
