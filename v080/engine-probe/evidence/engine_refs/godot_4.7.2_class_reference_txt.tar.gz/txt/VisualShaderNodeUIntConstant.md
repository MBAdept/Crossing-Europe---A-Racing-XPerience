# VisualShaderNodeUIntConstant :: <Native> class VisualShaderNodeUIntConstant extends VisualShaderNodeConstant
An unsigned scalar integer constant to be used within the visual shader graph.
Translated to [code]uint[/code] in the shader language.

## constant :: var VisualShaderNodeUIntConstant.constant: int
An unsigned integer constant which represents a state of this node.
