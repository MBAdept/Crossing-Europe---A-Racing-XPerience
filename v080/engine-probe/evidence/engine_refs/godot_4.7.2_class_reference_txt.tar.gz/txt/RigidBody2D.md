# RigidBody2D :: <Native> class RigidBody2D extends PhysicsBody2D
A 2D physics body that is moved by a physics simulation.
[RigidBody2D] implements full 2D physics. It cannot be controlled directly, instead, you must apply forces to it (gravity, impulses, etc.), and the physics simulation will calculate the resulting movement, rotation, react to collisions, and affect other physics bodies in its path.
The body's behavior can be adjusted via [member lock_rotation], [member freeze], and [member freeze_mode]. By changing various properties of the object, such as [member mass], you can control how the physics simulation acts on it.
A rigid body will always maintain its shape and size, even when forces are applied to it. It is useful for objects that can be interacted with in an environment, such as a tree that can be knocked over or a stack of crates that can be pushed around.
If you need to directly affect the body, prefer [method _integrate_forces] as it allows you to directly access the physics state.
If you need to override the default physics behavior, you can write a custom force integration function. See [member custom_integrator].
[b]Note:[/b] Changing the 2D transform or [member linear_velocity] of a [RigidBody2D] very often may lead to some unpredictable behaviors. This also happens when a [RigidBody2D] is the descendant of a constantly moving node, like another [RigidBody2D], as that will cause its global transform to be set whenever its ancestor moves.

## FREEZE_MODE_STATIC :: const RigidBody2D.FREEZE_MODE_STATIC: FreezeMode = 0
Static body freeze mode (default). The body is not affected by gravity and forces. It can be only moved by user code and doesn't collide with other bodies along its path.

## FREEZE_MODE_KINEMATIC :: const RigidBody2D.FREEZE_MODE_KINEMATIC: FreezeMode = 1
Kinematic body freeze mode. Similar to [constant FREEZE_MODE_STATIC], but collides with other bodies along its path when moved. Useful for a frozen body that needs to be animated.

## CENTER_OF_MASS_MODE_AUTO :: const RigidBody2D.CENTER_OF_MASS_MODE_AUTO: CenterOfMassMode = 0
In this mode, the body's center of mass is calculated automatically based on its shapes. This assumes that the shapes' origins are also their center of mass.

## CENTER_OF_MASS_MODE_CUSTOM :: const RigidBody2D.CENTER_OF_MASS_MODE_CUSTOM: CenterOfMassMode = 1
In this mode, the body's center of mass is set through [member center_of_mass]. Defaults to the body's origin position.

## DAMP_MODE_COMBINE :: const RigidBody2D.DAMP_MODE_COMBINE: DampMode = 0
In this mode, the body's damping value is added to any value set in areas or the default value.

## DAMP_MODE_REPLACE :: const RigidBody2D.DAMP_MODE_REPLACE: DampMode = 1
In this mode, the body's damping value replaces any value set in areas or the default value.

## CCD_MODE_DISABLED :: const RigidBody2D.CCD_MODE_DISABLED: CCDMode = 0
Continuous collision detection disabled. This is the fastest way to detect body collisions, but can miss small, fast-moving objects.

## CCD_MODE_CAST_RAY :: const RigidBody2D.CCD_MODE_CAST_RAY: CCDMode = 1
Continuous collision detection enabled using raycasting. This is faster than shapecasting but less precise.

## CCD_MODE_CAST_SHAPE :: const RigidBody2D.CCD_MODE_CAST_SHAPE: CCDMode = 2
Continuous collision detection enabled using shapecasting. This is the slowest CCD method and the most precise.

## angular_damp :: var RigidBody2D.angular_damp: float
Damps the body's rotation. By default, the body will use the [member ProjectSettings.physics/2d/default_angular_damp] setting or any value override set by an [Area2D] the body is in. Depending on [member angular_damp_mode], you can set [member angular_damp] to be added to or to replace the body's damping value.
See [member ProjectSettings.physics/2d/default_angular_damp] for more details about damping.

## angular_damp_mode :: var RigidBody2D.angular_damp_mode: RigidBody2D.DampMode
Defines how [member angular_damp] is applied.

## angular_velocity :: var RigidBody2D.angular_velocity: float
The body's rotational velocity in [i]radians[/i] per second.

## can_sleep :: var RigidBody2D.can_sleep: bool
If [code]true[/code], the body can enter sleep mode when there is no movement. See [member sleeping].

## center_of_mass :: var RigidBody2D.center_of_mass: Vector2
The body's custom center of mass, relative to the body's origin position, when [member center_of_mass_mode] is set to [constant CENTER_OF_MASS_MODE_CUSTOM]. This is the balanced point of the body, where applied forces only cause linear acceleration. Applying forces outside of the center of mass causes angular acceleration.
When [member center_of_mass_mode] is set to [constant CENTER_OF_MASS_MODE_AUTO] (default value), the center of mass is automatically determined, but this does not update the value of [member center_of_mass].

## center_of_mass_mode :: var RigidBody2D.center_of_mass_mode: RigidBody2D.CenterOfMassMode
Defines the way the body's center of mass is set.

## constant_force :: var RigidBody2D.constant_force: Vector2
The body's total constant positional forces applied during each physics update.
See [method add_constant_force] and [method add_constant_central_force].

## constant_torque :: var RigidBody2D.constant_torque: float
The body's total constant rotational forces applied during each physics update.
See [method add_constant_torque].

## contact_monitor :: var RigidBody2D.contact_monitor: bool
If [code]true[/code], the RigidBody2D will emit signals when it collides with another body.
[b]Note:[/b] By default the maximum contacts reported is set to 0, meaning nothing will be recorded, see [member max_contacts_reported].

## continuous_cd :: var RigidBody2D.continuous_cd: RigidBody2D.CCDMode
Continuous collision detection mode.
Continuous collision detection tries to predict where a moving body will collide instead of moving it and correcting its movement after collision. Continuous collision detection is slower, but more precise and misses fewer collisions with small, fast-moving objects. Raycasting and shapecasting methods are available.

## custom_integrator :: var RigidBody2D.custom_integrator: bool
If [code]true[/code], the standard force integration (like gravity or damping) will be disabled for this body. Other than collision response, the body will only move as determined by the [method _integrate_forces] method, if that virtual method is overridden.
Setting this property will call the method [method PhysicsServer2D.body_set_omit_force_integration] internally.

## freeze :: var RigidBody2D.freeze: bool
If [code]true[/code], the body is frozen. Gravity and forces are not applied anymore.
See [member freeze_mode] to set the body's behavior when frozen.
[b]Note:[/b] For a body that is always frozen, use [StaticBody2D] or [AnimatableBody2D] instead.

## freeze_mode :: var RigidBody2D.freeze_mode: RigidBody2D.FreezeMode
The body's freeze mode. Determines the body's behavior when [member freeze] is [code]true[/code].
[b]Note:[/b] For a body that is always frozen, use [StaticBody2D] or [AnimatableBody2D] instead.

## gravity_scale :: var RigidBody2D.gravity_scale: float
Multiplies the gravity applied to the body. The body's gravity is calculated from the [member ProjectSettings.physics/2d/default_gravity] project setting and/or any additional gravity vector applied by [Area2D]s.

## inertia :: var RigidBody2D.inertia: float
The body's moment of inertia. This is like mass, but for rotation: it determines how much torque it takes to rotate the body. The moment of inertia is usually computed automatically from the mass and the shapes, but this property allows you to set a custom value.
If set to [code]0[/code], inertia is automatically computed (default value).
[b]Note:[/b] This value does not change when inertia is automatically computed. Use [PhysicsServer2D] to get the computed inertia.
[codeblocks]
[gdscript]
@onready var ball = $Ball

func get_ball_inertia():
	return 1.0 / PhysicsServer2D.body_get_direct_state(ball.get_rid()).inverse_inertia
[/gdscript]
[csharp]
private RigidBody2D _ball;

public override void _Ready()
{
	_ball = GetNode<RigidBody2D>("Ball");
}

private float GetBallInertia()
{
	return 1.0f / PhysicsServer2D.BodyGetDirectState(_ball.GetRid()).InverseInertia;
}
[/csharp]
[/codeblocks]

## linear_damp :: var RigidBody2D.linear_damp: float
Damps the body's movement. By default, the body will use the [member ProjectSettings.physics/2d/default_linear_damp] setting or any value override set by an [Area2D] the body is in. Depending on [member linear_damp_mode], you can set [member linear_damp] to be added to or to replace the body's damping value.
See [member ProjectSettings.physics/2d/default_linear_damp] for more details about damping.

## linear_damp_mode :: var RigidBody2D.linear_damp_mode: RigidBody2D.DampMode
Defines how [member linear_damp] is applied.

## linear_velocity :: var RigidBody2D.linear_velocity: Vector2
The body's linear velocity in pixels per second. Can be used sporadically, but [b]don't set this every frame[/b], because physics may run in another thread and runs at a different granularity. Use [method _integrate_forces] as your process loop for precise control of the body state.

## lock_rotation :: var RigidBody2D.lock_rotation: bool
If [code]true[/code], the body cannot rotate. Gravity and forces only apply linear movement.

## mass :: var RigidBody2D.mass: float
The body's mass.

## max_contacts_reported :: var RigidBody2D.max_contacts_reported: int
The maximum number of contacts that will be recorded. Requires a value greater than 0 and [member contact_monitor] to be set to [code]true[/code] to start to register contacts. Use [method get_contact_count] to retrieve the count or [method get_colliding_bodies] to retrieve bodies that have been collided with.
[b]Note:[/b] The number of contacts is different from the number of collisions. Collisions between parallel edges will result in two contacts (one at each end), and collisions between parallel faces will result in four contacts (one at each corner).

## physics_material_override :: var RigidBody2D.physics_material_override: PhysicsMaterial
The physics material override for the body.
If a material is assigned to this property, it will be used instead of any other physics material, such as an inherited one.

## sleeping :: var RigidBody2D.sleeping: bool
If [code]true[/code], the body will not move and will not calculate forces until woken up by another body through, for example, a collision, or by using the [method apply_impulse] or [method apply_force] methods.

## _integrate_forces :: func RigidBody2D._integrate_forces(state: PhysicsDirectBodyState2D) -> void
Called during physics processing, allowing you to read and safely modify the simulation state for the object. By default, it is called before the standard force integration, but the [member custom_integrator] property allows you to disable the standard force integration and do fully custom force integration for a body.

### state :: PhysicsDirectBodyState2D

## add_constant_central_force :: func RigidBody2D.add_constant_central_force(force: Vector2) -> void
Adds a constant directional force without affecting rotation that keeps being applied over time until cleared with [code]constant_force = Vector2(0, 0)[/code].
This is equivalent to using [method add_constant_force] at the body's center of mass.

### force :: Vector2

## add_constant_force :: func RigidBody2D.add_constant_force(force: Vector2, position: Vector2 = Vector2(0, 0)) -> void
Adds a constant positioned force to the body that keeps being applied over time until cleared with [code]constant_force = Vector2(0, 0)[/code].
[param position] is the offset from the body origin in global coordinates.

### force :: Vector2

### position :: Vector2

## add_constant_torque :: func RigidBody2D.add_constant_torque(torque: float) -> void
Adds a constant rotational force without affecting position that keeps being applied over time until cleared with [code]constant_torque = 0[/code].

### torque :: float

## apply_central_force :: func RigidBody2D.apply_central_force(force: Vector2) -> void
Applies a directional force without affecting rotation. A force is time dependent and meant to be applied every physics update.
This is equivalent to using [method apply_force] at the body's center of mass.

### force :: Vector2

## apply_central_impulse :: func RigidBody2D.apply_central_impulse(impulse: Vector2 = Vector2(0, 0)) -> void
Applies a directional impulse without affecting rotation.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).
This is equivalent to using [method apply_impulse] at the body's center of mass.

### impulse :: Vector2

## apply_force :: func RigidBody2D.apply_force(force: Vector2, position: Vector2 = Vector2(0, 0)) -> void
Applies a positioned force to the body. A force is time dependent and meant to be applied every physics update.
[param position] is the offset from the body origin in global coordinates.

### force :: Vector2

### position :: Vector2

## apply_impulse :: func RigidBody2D.apply_impulse(impulse: Vector2, position: Vector2 = Vector2(0, 0)) -> void
Applies a positioned impulse to the body.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).
[param position] is the offset from the body origin in global coordinates.

### impulse :: Vector2

### position :: Vector2

## apply_torque :: func RigidBody2D.apply_torque(torque: float) -> void
Applies a rotational force without affecting position. A force is time dependent and meant to be applied every physics update.
[b]Note:[/b] [member inertia] is required for this to work. To have [member inertia], an active [CollisionShape2D] must be a child of the node, or you can manually set [member inertia].

### torque :: float

## apply_torque_impulse :: func RigidBody2D.apply_torque_impulse(torque: float) -> void
Applies a rotational impulse to the body without affecting the position.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).
[b]Note:[/b] [member inertia] is required for this to work. To have [member inertia], an active [CollisionShape2D] must be a child of the node, or you can manually set [member inertia].

### torque :: float

## get_colliding_bodies :: func RigidBody2D.get_colliding_bodies() -> Node2D[]
Returns a list of the bodies colliding with this one. Requires [member contact_monitor] to be set to [code]true[/code] and [member max_contacts_reported] to be set high enough to detect all the collisions.
[b]Note:[/b] The result of this test is not immediate after moving objects. For performance, list of collisions is updated once per frame and before the physics step. Consider using signals instead.

## get_contact_count :: func RigidBody2D.get_contact_count() -> int
Returns the number of contacts this body has with other bodies. By default, this returns 0 unless bodies are configured to monitor contacts (see [member contact_monitor]).
[b]Note:[/b] To retrieve the colliding bodies, use [method get_colliding_bodies].

## set_axis_velocity :: func RigidBody2D.set_axis_velocity(axis_velocity: Vector2) -> void
Sets the body's velocity on the given axis. The velocity in the given vector axis will be set as the given vector length. This is useful for jumping behavior.

### axis_velocity :: Vector2

## body_entered :: func RigidBody2D.body_entered(body: Node) -> void
Emitted when a collision with another [PhysicsBody2D] or [TileMap] occurs. Requires [member contact_monitor] to be set to [code]true[/code] and [member max_contacts_reported] to be set high enough to detect all the collisions. [TileMap]s are detected if the [TileSet] has Collision [Shape2D]s.
[param body] the [Node], if it exists in the tree, of the other [PhysicsBody2D] or [TileMap].

### body :: Node

## body_exited :: func RigidBody2D.body_exited(body: Node) -> void
Emitted when the collision with another [PhysicsBody2D] or [TileMap] ends. Requires [member contact_monitor] to be set to [code]true[/code] and [member max_contacts_reported] to be set high enough to detect all the collisions. [TileMap]s are detected if the [TileSet] has Collision [Shape2D]s.
[param body] the [Node], if it exists in the tree, of the other [PhysicsBody2D] or [TileMap].

### body :: Node

## body_shape_entered :: func RigidBody2D.body_shape_entered(body_rid: RID, body: Node, body_shape_index: int, local_shape_index: int) -> void
Emitted when one of this RigidBody2D's [Shape2D]s collides with another [PhysicsBody2D] or [TileMap]'s [Shape2D]s. Requires [member contact_monitor] to be set to [code]true[/code] and [member max_contacts_reported] to be set high enough to detect all the collisions. [TileMap]s are detected if the [TileSet] has Collision [Shape2D]s.
[param body_rid] the [RID] of the other [PhysicsBody2D] or [TileSet]'s [CollisionObject2D] used by the [PhysicsServer2D].
[param body] the [Node], if it exists in the tree, of the other [PhysicsBody2D] or [TileMap].
[param body_shape_index] the index of the [Shape2D] of the other [PhysicsBody2D] or [TileMap] used by the [PhysicsServer2D]. Get the [CollisionShape2D] node with [code]body.shape_owner_get_owner(body.shape_find_owner(body_shape_index))[/code].
[param local_shape_index] the index of the [Shape2D] of this RigidBody2D used by the [PhysicsServer2D]. Get the [CollisionShape2D] node with [code]self.shape_owner_get_owner(self.shape_find_owner(local_shape_index))[/code].

### body_rid :: RID

### body :: Node

### body_shape_index :: int

### local_shape_index :: int

## body_shape_exited :: func RigidBody2D.body_shape_exited(body_rid: RID, body: Node, body_shape_index: int, local_shape_index: int) -> void
Emitted when the collision between one of this RigidBody2D's [Shape2D]s and another [PhysicsBody2D] or [TileMap]'s [Shape2D]s ends. Requires [member contact_monitor] to be set to [code]true[/code] and [member max_contacts_reported] to be set high enough to detect all the collisions. [TileMap]s are detected if the [TileSet] has Collision [Shape2D]s.
[param body_rid] the [RID] of the other [PhysicsBody2D] or [TileSet]'s [CollisionObject2D] used by the [PhysicsServer2D].
[param body] the [Node], if it exists in the tree, of the other [PhysicsBody2D] or [TileMap].
[param body_shape_index] the index of the [Shape2D] of the other [PhysicsBody2D] or [TileMap] used by the [PhysicsServer2D]. Get the [CollisionShape2D] node with [code]body.shape_owner_get_owner(body.shape_find_owner(body_shape_index))[/code].
[param local_shape_index] the index of the [Shape2D] of this RigidBody2D used by the [PhysicsServer2D]. Get the [CollisionShape2D] node with [code]self.shape_owner_get_owner(self.shape_find_owner(local_shape_index))[/code].

### body_rid :: RID

### body :: Node

### body_shape_index :: int

### local_shape_index :: int

## sleeping_state_changed :: func RigidBody2D.sleeping_state_changed() -> void
Emitted when the physics engine changes the body's sleeping state.
[b]Note:[/b] Changing the value [member sleeping] will not trigger this signal. It is only emitted if the sleeping state is changed by the physics engine or [code]emit_signal("sleeping_state_changed")[/code] is used.
