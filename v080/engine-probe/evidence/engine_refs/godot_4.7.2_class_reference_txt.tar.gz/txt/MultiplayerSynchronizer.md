# MultiplayerSynchronizer :: <Native> class MultiplayerSynchronizer extends Node
Synchronizes properties from the multiplayer authority to the remote peers.
By default, [MultiplayerSynchronizer] synchronizes configured properties to all peers.
Visibility can be handled directly with [method set_visibility_for] or as-needed with [method add_visibility_filter] and [method update_visibility].
[MultiplayerSpawner]s will handle nodes according to visibility of synchronizers as long as the node at [member root_path] was spawned by one.
Internally, [MultiplayerSynchronizer] uses [method MultiplayerAPI.object_configuration_add] to notify synchronization start passing the [Node] at [member root_path] as the [code]object[/code] and itself as the [code]configuration[/code], and uses [method MultiplayerAPI.object_configuration_remove] to notify synchronization end in a similar way.
[b]Note:[/b] Synchronization is not supported for [Object] type properties, like [Resource]. Properties that are unique to each peer, like the instance IDs of [Object]s (see [method Object.get_instance_id]) or [RID]s, will also not work in synchronization.

## VISIBILITY_PROCESS_IDLE :: const MultiplayerSynchronizer.VISIBILITY_PROCESS_IDLE: VisibilityUpdateMode = 0
Visibility filters are updated during process frames (see [constant Node.NOTIFICATION_INTERNAL_PROCESS]).

## VISIBILITY_PROCESS_PHYSICS :: const MultiplayerSynchronizer.VISIBILITY_PROCESS_PHYSICS: VisibilityUpdateMode = 1
Visibility filters are updated during physics frames (see [constant Node.NOTIFICATION_INTERNAL_PHYSICS_PROCESS]).

## VISIBILITY_PROCESS_NONE :: const MultiplayerSynchronizer.VISIBILITY_PROCESS_NONE: VisibilityUpdateMode = 2
Visibility filters are not updated automatically, and must be updated manually by calling [method update_visibility].

## delta_interval :: var MultiplayerSynchronizer.delta_interval: float
Time interval between delta synchronizations. Used when the replication is set to [constant SceneReplicationConfig.REPLICATION_MODE_ON_CHANGE]. If set to [code]0.0[/code] (the default), delta synchronizations happen every network process frame.

## public_visibility :: var MultiplayerSynchronizer.public_visibility: bool
Whether synchronization should be visible to all peers by default. See [method set_visibility_for] and [method add_visibility_filter] for ways of configuring fine-grained visibility options.

## replication_config :: var MultiplayerSynchronizer.replication_config: SceneReplicationConfig
Resource containing which properties to synchronize.

## replication_interval :: var MultiplayerSynchronizer.replication_interval: float
Time interval between synchronizations. Used when the replication is set to [constant SceneReplicationConfig.REPLICATION_MODE_ALWAYS]. If set to [code]0.0[/code] (the default), synchronizations happen every network process frame.

## root_path :: var MultiplayerSynchronizer.root_path: NodePath
Node path that replicated properties are relative to.
If [member root_path] was spawned by a [MultiplayerSpawner], the node will be also be spawned and despawned based on this synchronizer visibility options.

## visibility_update_mode :: var MultiplayerSynchronizer.visibility_update_mode: MultiplayerSynchronizer.VisibilityUpdateMode
Specifies when visibility filters are updated.

## add_visibility_filter :: func MultiplayerSynchronizer.add_visibility_filter(filter: Callable) -> void
Adds a peer visibility filter for this synchronizer.
[param filter] should take a peer ID [int] and return a [bool].

### filter :: Callable

## get_visibility_for :: func MultiplayerSynchronizer.get_visibility_for(peer: int) -> bool
Queries the current visibility for peer [param peer].

### peer :: int

## remove_visibility_filter :: func MultiplayerSynchronizer.remove_visibility_filter(filter: Callable) -> void
Removes a peer visibility filter from this synchronizer.

### filter :: Callable

## set_visibility_for :: func MultiplayerSynchronizer.set_visibility_for(peer: int, visible: bool) -> void
Sets the visibility of [param peer] to [param visible]. If [param peer] is [code]0[/code], the value of [member public_visibility] will be updated instead.

### peer :: int

### visible :: bool

## update_visibility :: func MultiplayerSynchronizer.update_visibility(for_peer: int = 0) -> void
Updates the visibility of [param for_peer] according to visibility filters. If [param for_peer] is [code]0[/code] (the default), all peers' visibilties are updated.

### for_peer :: int

## delta_synchronized :: func MultiplayerSynchronizer.delta_synchronized() -> void
Emitted when a new delta synchronization state is received by this synchronizer after the properties have been updated.

## synchronized :: func MultiplayerSynchronizer.synchronized() -> void
Emitted when a new synchronization state is received by this synchronizer after the properties have been updated.

## visibility_changed :: func MultiplayerSynchronizer.visibility_changed(for_peer: int) -> void
Emitted when visibility of [param for_peer] is updated. See [method update_visibility].

### for_peer :: int
