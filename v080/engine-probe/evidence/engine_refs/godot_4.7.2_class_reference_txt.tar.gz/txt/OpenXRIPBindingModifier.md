# OpenXRIPBindingModifier :: <Native> class OpenXRIPBindingModifier extends OpenXRBindingModifier
Binding modifier that applies directly on an interaction profile.
Binding modifier that applies directly on an interaction profile.
