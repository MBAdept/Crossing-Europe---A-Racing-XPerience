# GLTFAccessor :: <Native> class GLTFAccessor extends Resource
Represents a glTF accessor.
GLTFAccessor is a data structure representing a glTF [code]accessor[/code] that would be found in the [code]"accessors"[/code] array. A buffer is a blob of binary data. A buffer view is a slice of a buffer. An accessor is a typed interpretation of the data in a buffer view.
Most custom data stored in glTF does not need accessors, only buffer views (see [GLTFBufferView]). Accessors are for more advanced use cases such as interleaved mesh data encoded for the GPU.

## TYPE_SCALAR :: const GLTFAccessor.TYPE_SCALAR: GLTFAccessorType = 0
Accessor type "SCALAR". For the glTF object model, this can be used to map to a single float, int, or bool value, or a float array.

## TYPE_VEC2 :: const GLTFAccessor.TYPE_VEC2: GLTFAccessorType = 1
Accessor type "VEC2". For the glTF object model, this maps to "float2", represented in the glTF JSON as an array of two floats.

## TYPE_VEC3 :: const GLTFAccessor.TYPE_VEC3: GLTFAccessorType = 2
Accessor type "VEC3". For the glTF object model, this maps to "float3", represented in the glTF JSON as an array of three floats.

## TYPE_VEC4 :: const GLTFAccessor.TYPE_VEC4: GLTFAccessorType = 3
Accessor type "VEC4". For the glTF object model, this maps to "float4", represented in the glTF JSON as an array of four floats.

## TYPE_MAT2 :: const GLTFAccessor.TYPE_MAT2: GLTFAccessorType = 4
Accessor type "MAT2". For the glTF object model, this maps to "float2x2", represented in the glTF JSON as an array of four floats.

## TYPE_MAT3 :: const GLTFAccessor.TYPE_MAT3: GLTFAccessorType = 5
Accessor type "MAT3". For the glTF object model, this maps to "float3x3", represented in the glTF JSON as an array of nine floats.

## TYPE_MAT4 :: const GLTFAccessor.TYPE_MAT4: GLTFAccessorType = 6
Accessor type "MAT4". For the glTF object model, this maps to "float4x4", represented in the glTF JSON as an array of sixteen floats.

## COMPONENT_TYPE_NONE :: const GLTFAccessor.COMPONENT_TYPE_NONE: GLTFComponentType = 0
Component type "NONE". This is not a valid component type, and is used to indicate that the component type is not set.

## COMPONENT_TYPE_SIGNED_BYTE :: const GLTFAccessor.COMPONENT_TYPE_SIGNED_BYTE: GLTFComponentType = 5120
Component type "BYTE". The value is [code]0x1400[/code] which comes from OpenGL. This indicates data is stored in 1-byte or 8-bit signed integers. This is a core part of the glTF specification.

## COMPONENT_TYPE_UNSIGNED_BYTE :: const GLTFAccessor.COMPONENT_TYPE_UNSIGNED_BYTE: GLTFComponentType = 5121
Component type "UNSIGNED_BYTE". The value is [code]0x1401[/code] which comes from OpenGL. This indicates data is stored in 1-byte or 8-bit unsigned integers. This is a core part of the glTF specification.

## COMPONENT_TYPE_SIGNED_SHORT :: const GLTFAccessor.COMPONENT_TYPE_SIGNED_SHORT: GLTFComponentType = 5122
Component type "SHORT". The value is [code]0x1402[/code] which comes from OpenGL. This indicates data is stored in 2-byte or 16-bit signed integers. This is a core part of the glTF specification.

## COMPONENT_TYPE_UNSIGNED_SHORT :: const GLTFAccessor.COMPONENT_TYPE_UNSIGNED_SHORT: GLTFComponentType = 5123
Component type "UNSIGNED_SHORT". The value is [code]0x1403[/code] which comes from OpenGL. This indicates data is stored in 2-byte or 16-bit unsigned integers. This is a core part of the glTF specification.

## COMPONENT_TYPE_SIGNED_INT :: const GLTFAccessor.COMPONENT_TYPE_SIGNED_INT: GLTFComponentType = 5124
Component type "INT". The value is [code]0x1404[/code] which comes from OpenGL. This indicates data is stored in 4-byte or 32-bit signed integers. This is NOT a core part of the glTF specification, and may not be supported by all glTF importers. May be used by some extensions including [code]KHR_interactivity[/code].

## COMPONENT_TYPE_UNSIGNED_INT :: const GLTFAccessor.COMPONENT_TYPE_UNSIGNED_INT: GLTFComponentType = 5125
Component type "UNSIGNED_INT". The value is [code]0x1405[/code] which comes from OpenGL. This indicates data is stored in 4-byte or 32-bit unsigned integers. This is a core part of the glTF specification.

## COMPONENT_TYPE_SINGLE_FLOAT :: const GLTFAccessor.COMPONENT_TYPE_SINGLE_FLOAT: GLTFComponentType = 5126
Component type "FLOAT". The value is [code]0x1406[/code] which comes from OpenGL. This indicates data is stored in 4-byte or 32-bit floating-point numbers. This is a core part of the glTF specification.

## COMPONENT_TYPE_DOUBLE_FLOAT :: const GLTFAccessor.COMPONENT_TYPE_DOUBLE_FLOAT: GLTFComponentType = 5130
Component type "DOUBLE". The value is [code]0x140A[/code] which comes from OpenGL. This indicates data is stored in 8-byte or 64-bit floating-point numbers. This is NOT a core part of the glTF specification, and may not be supported by all glTF importers. May be used by some extensions including [code]KHR_interactivity[/code].

## COMPONENT_TYPE_HALF_FLOAT :: const GLTFAccessor.COMPONENT_TYPE_HALF_FLOAT: GLTFComponentType = 5131
Component type "HALF_FLOAT". The value is [code]0x140B[/code] which comes from OpenGL. This indicates data is stored in 2-byte or 16-bit floating-point numbers. This is NOT a core part of the glTF specification, and may not be supported by all glTF importers. May be used by some extensions including [code]KHR_interactivity[/code].

## COMPONENT_TYPE_SIGNED_LONG :: const GLTFAccessor.COMPONENT_TYPE_SIGNED_LONG: GLTFComponentType = 5134
Component type "LONG". The value is [code]0x140E[/code] which comes from OpenGL. This indicates data is stored in 8-byte or 64-bit signed integers. This is NOT a core part of the glTF specification, and may not be supported by all glTF importers. May be used by some extensions including [code]KHR_interactivity[/code].

## COMPONENT_TYPE_UNSIGNED_LONG :: const GLTFAccessor.COMPONENT_TYPE_UNSIGNED_LONG: GLTFComponentType = 5135
Component type "UNSIGNED_LONG". The value is [code]0x140F[/code] which comes from OpenGL. This indicates data is stored in 8-byte or 64-bit unsigned integers. This is NOT a core part of the glTF specification, and may not be supported by all glTF importers. May be used by some extensions including [code]KHR_interactivity[/code].

## accessor_type :: var GLTFAccessor.accessor_type: GLTFAccessor.GLTFAccessorType
The glTF accessor type, as an enum.

## buffer_view :: var GLTFAccessor.buffer_view: int
The index of the buffer view this accessor is referencing. If [code]-1[/code], this accessor is not referencing any buffer view.

## byte_offset :: var GLTFAccessor.byte_offset: int
The offset relative to the start of the buffer view in bytes.

## component_type :: var GLTFAccessor.component_type: GLTFAccessor.GLTFComponentType
The glTF component type as an enum. See [enum GLTFComponentType] for possible values. Within the core glTF specification, a value of 5125 or "UNSIGNED_INT" must not be used for any accessor that is not referenced by mesh.primitive.indices.

## count :: var GLTFAccessor.count: int
The number of elements referenced by this accessor.

## max :: var GLTFAccessor.max: PackedFloat64Array
Maximum value of each component in this accessor.

## min :: var GLTFAccessor.min: PackedFloat64Array
Minimum value of each component in this accessor.

## normalized :: var GLTFAccessor.normalized: bool
Specifies whether integer data values are normalized before usage.

## sparse_count :: var GLTFAccessor.sparse_count: int
Number of deviating accessor values stored in the sparse array.

## sparse_indices_buffer_view :: var GLTFAccessor.sparse_indices_buffer_view: int
The index of the buffer view with sparse indices. The referenced buffer view MUST NOT have its target or byteStride properties defined. The buffer view and the optional byteOffset MUST be aligned to the componentType byte length.

## sparse_indices_byte_offset :: var GLTFAccessor.sparse_indices_byte_offset: int
The offset relative to the start of the buffer view in bytes.

## sparse_indices_component_type :: var GLTFAccessor.sparse_indices_component_type: GLTFAccessor.GLTFComponentType
The indices component data type as an enum. Possible values are 5121 for "UNSIGNED_BYTE", 5123 for "UNSIGNED_SHORT", and 5125 for "UNSIGNED_INT".

## sparse_values_buffer_view :: var GLTFAccessor.sparse_values_buffer_view: int
The index of the bufferView with sparse values. The referenced buffer view MUST NOT have its target or byteStride properties defined.

## sparse_values_byte_offset :: var GLTFAccessor.sparse_values_byte_offset: int
The offset relative to the start of the bufferView in bytes.

## type :: var GLTFAccessor.type: int
The glTF accessor type, as an [int]. Possible values are [code]0[/code] for "SCALAR", [code]1[/code] for "VEC2", [code]2[/code] for "VEC3", [code]3[/code] for "VEC4", [code]4[/code] for "MAT2", [code]5[/code] for "MAT3", and [code]6[/code] for "MAT4".

## from_dictionary :: func GLTFAccessor.from_dictionary(dictionary: Dictionary) -> GLTFAccessor
Creates a new GLTFAccessor instance by parsing the given [Dictionary].

### dictionary :: Dictionary

## to_dictionary :: func GLTFAccessor.to_dictionary() -> Dictionary
Serializes this GLTFAccessor instance into a [Dictionary].
