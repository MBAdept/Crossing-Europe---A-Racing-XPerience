# VisualShaderNodeFloatConstant :: <Native> class VisualShaderNodeFloatConstant extends VisualShaderNodeConstant
A scalar floating-point constant to be used within the visual shader graph.
Translated to [code skip-lint]float[/code] in the shader language.

## constant :: var VisualShaderNodeFloatConstant.constant: float
A floating-point constant which represents a state of this node.
