# EditorNode3DGizmoPlugin :: <Native> class EditorNode3DGizmoPlugin extends Resource
A class used by the editor to define Node3D gizmo types.
[EditorNode3DGizmoPlugin] allows you to define a new type of Gizmo. There are two main ways to do so: extending [EditorNode3DGizmoPlugin] for the simpler gizmos, or creating a new [EditorNode3DGizmo] type. See the tutorial in the documentation for more info.
To use [EditorNode3DGizmoPlugin], register it using the [method EditorPlugin.add_node_3d_gizmo_plugin] method first.

## _begin_handle_action :: func EditorNode3DGizmoPlugin._begin_handle_action(gizmo: EditorNode3DGizmo, handle_id: int, secondary: bool) -> void

### gizmo :: EditorNode3DGizmo

### handle_id :: int

### secondary :: bool

## _can_be_hidden :: func EditorNode3DGizmoPlugin._can_be_hidden() -> bool
Override this method to define whether the gizmos handled by this plugin can be hidden or not. Returns [code]true[/code] if not overridden.

## _can_commit_handle_on_click :: func EditorNode3DGizmoPlugin._can_commit_handle_on_click() -> bool
Override this method to define whether the gizmos should commit when the final handle position is the same as the initial one. Returns [code]false[/code] if not overridden.

## _commit_handle :: func EditorNode3DGizmoPlugin._commit_handle(gizmo: EditorNode3DGizmo, handle_id: int, secondary: bool, restore: Variant, cancel: bool) -> void
Override this method to commit a handle being edited (handles must have been previously added by [method EditorNode3DGizmo.add_handles] during [method _redraw]). This usually means creating an [UndoRedo] action for the change, using the current handle value as "do" and the [param restore] argument as "undo".
If the [param cancel] argument is [code]true[/code], the [param restore] value should be directly set, without any [UndoRedo] action.
The [param secondary] argument is [code]true[/code] when the committed handle is secondary (see [method EditorNode3DGizmo.add_handles] for more information).
Called for this plugin's active gizmos.

### gizmo :: EditorNode3DGizmo

### handle_id :: int

### secondary :: bool

### restore :: Variant

### cancel :: bool

## _commit_subgizmos :: func EditorNode3DGizmoPlugin._commit_subgizmos(gizmo: EditorNode3DGizmo, ids: PackedInt32Array, restores: Transform3D[], cancel: bool) -> void
Override this method to commit a group of subgizmos being edited (see [method _subgizmos_intersect_ray] and [method _subgizmos_intersect_frustum]). This usually means creating an [UndoRedo] action for the change, using the current transforms as "do" and the [param restores] transforms as "undo".
If the [param cancel] argument is [code]true[/code], the [param restores] transforms should be directly set, without any [UndoRedo] action. As with all subgizmo methods, transforms are given in local space respect to the gizmo's Node3D. Called for this plugin's active gizmos.

### gizmo :: EditorNode3DGizmo

### ids :: PackedInt32Array

### restores :: Transform3D[]

### cancel :: bool

## _create_gizmo :: func EditorNode3DGizmoPlugin._create_gizmo(for_node_3d: Node3D) -> EditorNode3DGizmo
Override this method to return a custom [EditorNode3DGizmo] for the 3D nodes of your choice, return [code]null[/code] for the rest of nodes. See also [method _has_gizmo].

### for_node_3d :: Node3D

## _get_gizmo_name :: func EditorNode3DGizmoPlugin._get_gizmo_name() -> String
Override this method to provide the name that will appear in the gizmo visibility menu.

## _get_handle_name :: func EditorNode3DGizmoPlugin._get_handle_name(gizmo: EditorNode3DGizmo, handle_id: int, secondary: bool) -> String
Override this method to provide gizmo's handle names. The [param secondary] argument is [code]true[/code] when the requested handle is secondary (see [method EditorNode3DGizmo.add_handles] for more information). Called for this plugin's active gizmos.

### gizmo :: EditorNode3DGizmo

### handle_id :: int

### secondary :: bool

## _get_handle_value :: func EditorNode3DGizmoPlugin._get_handle_value(gizmo: EditorNode3DGizmo, handle_id: int, secondary: bool) -> Variant
Override this method to return the current value of a handle. This value will be requested at the start of an edit and used as the [code]restore[/code] argument in [method _commit_handle].
The [param secondary] argument is [code]true[/code] when the requested handle is secondary (see [method EditorNode3DGizmo.add_handles] for more information).
Called for this plugin's active gizmos.

### gizmo :: EditorNode3DGizmo

### handle_id :: int

### secondary :: bool

## _get_priority :: func EditorNode3DGizmoPlugin._get_priority() -> int
Override this method to set the gizmo's priority. Gizmos with higher priority will have precedence when processing inputs like handles or subgizmos selection.
All built-in editor gizmos return a priority of [code]-1[/code]. If not overridden, this method will return [code]0[/code], which means custom gizmos will automatically get higher priority than built-in gizmos.

## _get_subgizmo_transform :: func EditorNode3DGizmoPlugin._get_subgizmo_transform(gizmo: EditorNode3DGizmo, subgizmo_id: int) -> Transform3D
Override this method to return the current transform of a subgizmo. As with all subgizmo methods, the transform should be in local space respect to the gizmo's Node3D. This transform will be requested at the start of an edit and used in the [code]restore[/code] argument in [method _commit_subgizmos]. Called for this plugin's active gizmos.

### gizmo :: EditorNode3DGizmo

### subgizmo_id :: int

## _has_gizmo :: func EditorNode3DGizmoPlugin._has_gizmo(for_node_3d: Node3D) -> bool
Override this method to define which Node3D nodes have a gizmo from this plugin. Whenever a [Node3D] node is added to a scene this method is called, if it returns [code]true[/code] the node gets a generic [EditorNode3DGizmo] assigned and is added to this plugin's list of active gizmos.

### for_node_3d :: Node3D

## _is_handle_highlighted :: func EditorNode3DGizmoPlugin._is_handle_highlighted(gizmo: EditorNode3DGizmo, handle_id: int, secondary: bool) -> bool
Override this method to return [code]true[/code] whenever to given handle should be highlighted in the editor. The [param secondary] argument is [code]true[/code] when the requested handle is secondary (see [method EditorNode3DGizmo.add_handles] for more information). Called for this plugin's active gizmos.

### gizmo :: EditorNode3DGizmo

### handle_id :: int

### secondary :: bool

## _is_selectable_when_hidden :: func EditorNode3DGizmoPlugin._is_selectable_when_hidden() -> bool
Override this method to define whether Node3D with this gizmo should be selectable even when the gizmo is hidden.

## _redraw :: func EditorNode3DGizmoPlugin._redraw(gizmo: EditorNode3DGizmo) -> void
Override this method to add all the gizmo elements whenever a gizmo update is requested. It's common to call [method EditorNode3DGizmo.clear] at the beginning of this method and then add visual elements depending on the node's properties.

### gizmo :: EditorNode3DGizmo

## _set_handle :: func EditorNode3DGizmoPlugin._set_handle(gizmo: EditorNode3DGizmo, handle_id: int, secondary: bool, camera: Camera3D, screen_pos: Vector2) -> void
Override this method to update the node's properties when the user drags a gizmo handle (previously added with [method EditorNode3DGizmo.add_handles]). The provided [param screen_pos] is the mouse position in screen coordinates and the [param camera] can be used to convert it to raycasts.
The [param secondary] argument is [code]true[/code] when the edited handle is secondary (see [method EditorNode3DGizmo.add_handles] for more information).
Called for this plugin's active gizmos.

### gizmo :: EditorNode3DGizmo

### handle_id :: int

### secondary :: bool

### camera :: Camera3D

### screen_pos :: Vector2

## _set_subgizmo_transform :: func EditorNode3DGizmoPlugin._set_subgizmo_transform(gizmo: EditorNode3DGizmo, subgizmo_id: int, transform: Transform3D) -> void
Override this method to update the node properties during subgizmo editing (see [method _subgizmos_intersect_ray] and [method _subgizmos_intersect_frustum]). The [param transform] is given in the Node3D's local coordinate system. Called for this plugin's active gizmos.

### gizmo :: EditorNode3DGizmo

### subgizmo_id :: int

### transform :: Transform3D

## _subgizmos_intersect_frustum :: func EditorNode3DGizmoPlugin._subgizmos_intersect_frustum(gizmo: EditorNode3DGizmo, camera: Camera3D, frustum_planes: Plane[]) -> PackedInt32Array
Override this method to allow selecting subgizmos using mouse drag box selection. Given a [param camera] and [param frustum_planes], this method should return which subgizmos are contained within the frustums. The [param frustum_planes] argument consists of an array with all the [Plane]s that make up the selection frustum. The returned value should contain a list of unique subgizmo identifiers, these identifiers can have any non-negative value and will be used in other virtual methods like [method _get_subgizmo_transform] or [method _commit_subgizmos]. Called for this plugin's active gizmos.

### gizmo :: EditorNode3DGizmo

### camera :: Camera3D

### frustum_planes :: Plane[]

## _subgizmos_intersect_ray :: func EditorNode3DGizmoPlugin._subgizmos_intersect_ray(gizmo: EditorNode3DGizmo, camera: Camera3D, screen_pos: Vector2) -> int
Override this method to allow selecting subgizmos using mouse clicks. Given a [param camera] and a [param screen_pos] in screen coordinates, this method should return which subgizmo should be selected. The returned value should be a unique subgizmo identifier, which can have any non-negative value and will be used in other virtual methods like [method _get_subgizmo_transform] or [method _commit_subgizmos]. Called for this plugin's active gizmos.

### gizmo :: EditorNode3DGizmo

### camera :: Camera3D

### screen_pos :: Vector2

## add_material :: func EditorNode3DGizmoPlugin.add_material(name: String, material: StandardMaterial3D) -> void
Adds a new material to the internal material list for the plugin. It can then be accessed with [method get_material]. Should not be overridden.

### name :: String

### material :: StandardMaterial3D

## create_handle_material :: func EditorNode3DGizmoPlugin.create_handle_material(name: String, billboard: bool = false, texture: Texture2D = null) -> void
Creates a handle material with its variants (selected and/or editable) and adds them to the internal material list. They can then be accessed with [method get_material] and used in [method EditorNode3DGizmo.add_handles]. Should not be overridden.
You can optionally provide a texture to use instead of the default icon.

### name :: String

### billboard :: bool

### texture :: Texture2D

## create_icon_material :: func EditorNode3DGizmoPlugin.create_icon_material(name: String, texture: Texture2D, on_top: bool = false, color: Color = Color(1, 1, 1, 1)) -> void
Creates an icon material with its variants (selected and/or editable) and adds them to the internal material list. They can then be accessed with [method get_material] and used in [method EditorNode3DGizmo.add_unscaled_billboard]. Should not be overridden.

### name :: String

### texture :: Texture2D

### on_top :: bool

### color :: Color

## create_material :: func EditorNode3DGizmoPlugin.create_material(name: String, color: Color, billboard: bool = false, on_top: bool = false, use_vertex_color: bool = false) -> void
Creates an unshaded material with its variants (selected and/or editable) and adds them to the internal material list. They can then be accessed with [method get_material] and used in [method EditorNode3DGizmo.add_mesh] and [method EditorNode3DGizmo.add_lines]. Should not be overridden.

### name :: String

### color :: Color

### billboard :: bool

### on_top :: bool

### use_vertex_color :: bool

## get_material :: func EditorNode3DGizmoPlugin.get_material(name: String, gizmo: EditorNode3DGizmo = null) -> StandardMaterial3D
Gets material from the internal list of materials. If an [EditorNode3DGizmo] is provided, it will try to get the corresponding variant (selected and/or editable).

### name :: String

### gizmo :: EditorNode3DGizmo
