# VisualShaderNodeMix :: <Native> class VisualShaderNodeMix extends VisualShaderNode
Linearly interpolates between two values within the visual shader graph.
Translates to [code]mix(a, b, weight)[/code] in the shader language.

## OP_TYPE_SCALAR :: const VisualShaderNodeMix.OP_TYPE_SCALAR: OpType = 0
A floating-point scalar.

## OP_TYPE_VECTOR_2D :: const VisualShaderNodeMix.OP_TYPE_VECTOR_2D: OpType = 1
A 2D vector type.

## OP_TYPE_VECTOR_2D_SCALAR :: const VisualShaderNodeMix.OP_TYPE_VECTOR_2D_SCALAR: OpType = 2
The [code]a[/code] and [code]b[/code] ports use a 2D vector type. The [code]weight[/code] port uses a scalar type.

## OP_TYPE_VECTOR_3D :: const VisualShaderNodeMix.OP_TYPE_VECTOR_3D: OpType = 3
A 3D vector type.

## OP_TYPE_VECTOR_3D_SCALAR :: const VisualShaderNodeMix.OP_TYPE_VECTOR_3D_SCALAR: OpType = 4
The [code]a[/code] and [code]b[/code] ports use a 3D vector type. The [code]weight[/code] port uses a scalar type.

## OP_TYPE_VECTOR_4D :: const VisualShaderNodeMix.OP_TYPE_VECTOR_4D: OpType = 5
A 4D vector type.

## OP_TYPE_VECTOR_4D_SCALAR :: const VisualShaderNodeMix.OP_TYPE_VECTOR_4D_SCALAR: OpType = 6
The [code]a[/code] and [code]b[/code] ports use a 4D vector type. The [code]weight[/code] port uses a scalar type.

## OP_TYPE_MAX :: const VisualShaderNodeMix.OP_TYPE_MAX: OpType = 7
Represents the size of the [enum OpType] enum.

## op_type :: var VisualShaderNodeMix.op_type: VisualShaderNodeMix.OpType
A type of operands and returned value.
