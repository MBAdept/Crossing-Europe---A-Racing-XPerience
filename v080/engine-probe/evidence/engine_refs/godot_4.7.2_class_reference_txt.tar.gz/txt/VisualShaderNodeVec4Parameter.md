# VisualShaderNodeVec4Parameter :: <Native> class VisualShaderNodeVec4Parameter extends VisualShaderNodeParameter
A 4D vector parameter to be used within the visual shader graph.
Translated to [code]uniform vec4[/code] in the shader language.

## default_value :: var VisualShaderNodeVec4Parameter.default_value: Vector4
A default value to be assigned within the shader.

## default_value_enabled :: var VisualShaderNodeVec4Parameter.default_value_enabled: bool
Enables usage of the [member default_value].
