# OpenXRFrameSynthesisExtension :: <Native> class OpenXRFrameSynthesisExtension extends OpenXRExtensionWrapper
The OpenXR Frame synthesis extension allows for advanced reprojection at low(er) framerates.
This class implements the [url=https://registry.khronos.org/OpenXR/specs/1.1/html/xrspec.html#XR_EXT_frame_synthesis]OpenXR Frame synthesis extension[/url]. When enabled in the project settings and supported by the XR runtime in use, frame synthesis uses advanced reprojection techniques to inject additional frames so that your XR experience hits the full frame rate of the device.

## enabled :: var OpenXRFrameSynthesisExtension.enabled: bool
Enable frame synthesis. When [code]true[/code] motion vector and depth data is provided to the XR runtime.

## relax_frame_interval :: var OpenXRFrameSynthesisExtension.relax_frame_interval: bool
If [code]true[/code] this informs the XR runtime we will be providing frames at a greatly reduced rate. Enable this when you expect your application to run at low framerates and wish to inject multiple reprojected frames.

## is_available :: func OpenXRFrameSynthesisExtension.is_available() -> bool
Returns [code]true[/code] if frame synthesis is enabled in the project settings and the current XR runtime supports frame synthesis. The value returned will only be valid once OpenXR has been initialized.

## skip_next_frame :: func OpenXRFrameSynthesisExtension.skip_next_frame() -> void
Queues the next frame to be skipped when supplying motion vector and depth data. Call this after teleporting your player or a similar action has moved the player to prevent incorrect reprojection results due to this movement.
