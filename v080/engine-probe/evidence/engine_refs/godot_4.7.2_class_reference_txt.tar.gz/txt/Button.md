# Button :: <Native> class Button extends BaseButton
A themed button that can contain text and an icon.
[Button] is the standard themed button. It can contain text and an icon, and it will display them according to the current [Theme].
[b]Example:[/b] Create a button and connect a method that will be called when the button is pressed:
[codeblocks]
[gdscript]
func _ready():
	var button = Button.new()
	button.text = "Click me"
	button.pressed.connect(_button_pressed)
	add_child(button)

func _button_pressed():
	print("Hello world!")
[/gdscript]
[csharp]
public override void _Ready()
{
	var button = new Button();
	button.Text = "Click me";
	button.Pressed += ButtonPressed;
	AddChild(button);
}

private void ButtonPressed()
{
	GD.Print("Hello world!");
}
[/csharp]
[/codeblocks]
See also [BaseButton] which contains common properties and methods associated with this node.
[b]Note:[/b] Buttons support multitouch via touch input, allowing multiple buttons to be pressed at the same time. Otherwise, mouse input is used, limiting interaction to one button press at a time.

## alignment :: var Button.alignment: HorizontalAlignment
Text alignment policy for the button's text.

## autowrap_mode :: var Button.autowrap_mode: TextServer.AutowrapMode
If set to something other than [constant TextServer.AUTOWRAP_OFF], the text gets wrapped inside the node's bounding rectangle.

## autowrap_trim_flags :: var Button.autowrap_trim_flags: TextServer.LineBreakFlag
Autowrap space trimming flags. See [constant TextServer.BREAK_TRIM_START_EDGE_SPACES] and [constant TextServer.BREAK_TRIM_END_EDGE_SPACES] for more info.

## clip_text :: var Button.clip_text: bool
If [code]true[/code], text that is too large to fit the button is clipped horizontally. If [code]false[/code], the button will always be wide enough to hold the text. The text is not vertically clipped, and the button's height is not affected by this property.

## expand_icon :: var Button.expand_icon: bool
When enabled, the button's icon will expand/shrink to fit the button's size while keeping its aspect. See also [theme_item icon_max_width].

## flat :: var Button.flat: bool
Flat buttons don't display decoration.

## icon :: var Button.icon: Texture2D
Button's icon, if text is present the icon will be placed before the text.
To edit margin and spacing of the icon, use [theme_item h_separation] theme property and [code]content_margin_*[/code] properties of the used [StyleBox]es.

## icon_alignment :: var Button.icon_alignment: HorizontalAlignment
Specifies if the icon should be aligned horizontally to the left, right, or center of a button. Uses the same [enum HorizontalAlignment] constants as the text alignment. If centered horizontally and vertically, text will draw on top of the icon.

## language :: var Button.language: String
Language code used for line-breaking and text shaping algorithms. If left empty, the current locale is used instead.

## text :: var Button.text: String
The button's text that will be displayed inside the button's area.

## text_direction :: var Button.text_direction: Control.TextDirection
Base text writing direction.

## text_overrun_behavior :: var Button.text_overrun_behavior: TextServer.OverrunBehavior
Sets the clipping behavior when the text exceeds the node's bounding rectangle.

## vertical_icon_alignment :: var Button.vertical_icon_alignment: VerticalAlignment
Specifies if the icon should be aligned vertically to the top, bottom, or center of a button. Uses the same [enum VerticalAlignment] constants as the text alignment. If centered horizontally and vertically, text will draw on top of the icon.

## font_color :: <Theme> var Button.font_color: Color
Default text [Color] of the [Button].

## font_disabled_color :: <Theme> var Button.font_disabled_color: Color
Text [Color] used when the [Button] is disabled.

## font_focus_color :: <Theme> var Button.font_focus_color: Color
Text [Color] used when the [Button] is focused. Only replaces the normal text color of the button. Disabled, hovered, and pressed states take precedence over this color.

## font_hover_color :: <Theme> var Button.font_hover_color: Color
Text [Color] used when the [Button] is being hovered.

## font_hover_pressed_color :: <Theme> var Button.font_hover_pressed_color: Color
Text [Color] used when the [Button] is being hovered and pressed.

## font_outline_color :: <Theme> var Button.font_outline_color: Color
The tint of text outline of the [Button].

## font_pressed_color :: <Theme> var Button.font_pressed_color: Color
Text [Color] used when the [Button] is being pressed.

## icon_disabled_color :: <Theme> var Button.icon_disabled_color: Color
Icon modulate [Color] used when the [Button] is disabled.

## icon_focus_color :: <Theme> var Button.icon_focus_color: Color
Icon modulate [Color] used when the [Button] is focused. Only replaces the normal modulate color of the button. Disabled, hovered, and pressed states take precedence over this color.

## icon_hover_color :: <Theme> var Button.icon_hover_color: Color
Icon modulate [Color] used when the [Button] is being hovered.

## icon_hover_pressed_color :: <Theme> var Button.icon_hover_pressed_color: Color
Icon modulate [Color] used when the [Button] is being hovered and pressed.

## icon_normal_color :: <Theme> var Button.icon_normal_color: Color
Default icon modulate [Color] of the [Button].

## icon_pressed_color :: <Theme> var Button.icon_pressed_color: Color
Icon modulate [Color] used when the [Button] is being pressed.

## align_to_largest_stylebox :: <Theme> var Button.align_to_largest_stylebox: int
This constant acts as a boolean. If [code]true[/code], the minimum size of the button and text/icon alignment is always based on the largest stylebox margins, otherwise it's based on the current button state stylebox margins.

## h_separation :: <Theme> var Button.h_separation: int
The horizontal space between [Button]'s icon and text. Negative values will be treated as [code]0[/code] when used.

## icon_max_width :: <Theme> var Button.icon_max_width: int
The maximum allowed width of the [Button]'s icon. This limit is applied on top of the default size of the icon, or its expanded size if [member expand_icon] is [code]true[/code]. The height is adjusted according to the icon's ratio. If the button has additional icons (e.g. [CheckBox]), they will also be limited.

## line_spacing :: <Theme> var Button.line_spacing: int
Additional vertical spacing between lines (in pixels), spacing is added to line descent. This value can be negative.

## outline_size :: <Theme> var Button.outline_size: int
The size of the text outline.
[b]Note:[/b] If using a font with [member FontFile.multichannel_signed_distance_field] enabled, its [member FontFile.msdf_pixel_range] must be set to at least [i]twice[/i] the value of [theme_item outline_size] for outline rendering to look correct. Otherwise, the outline may appear to be cut off earlier than intended.

## font :: <Theme> var Button.font: Font
[Font] of the [Button]'s text.

## font_size :: <Theme> var Button.font_size: int
Font size of the [Button]'s text.

## icon :: <Theme> var Button.icon: Texture2D
Default icon for the [Button]. Appears only if [member icon] is not assigned.

## disabled :: <Theme> var Button.disabled: StyleBox
[StyleBox] used when the [Button] is disabled.

## disabled_mirrored :: <Theme> var Button.disabled_mirrored: StyleBox
[StyleBox] used when the [Button] is disabled (for right-to-left layouts).

## focus :: <Theme> var Button.focus: StyleBox
[StyleBox] used when the [Button] is focused. The [theme_item focus] [StyleBox] is displayed [i]over[/i] the base [StyleBox], so a partially transparent [StyleBox] should be used to ensure the base [StyleBox] remains visible. A [StyleBox] that represents an outline or an underline works well for this purpose. To disable the focus visual effect, assign a [StyleBoxEmpty] resource. Note that disabling the focus visual effect will harm keyboard/controller navigation usability, so this is not recommended for accessibility reasons.

## hover :: <Theme> var Button.hover: StyleBox
[StyleBox] used when the [Button] is being hovered.

## hover_mirrored :: <Theme> var Button.hover_mirrored: StyleBox
[StyleBox] used when the [Button] is being hovered (for right-to-left layouts).

## hover_pressed :: <Theme> var Button.hover_pressed: StyleBox
[StyleBox] used when the [Button] is being pressed and hovered at the same time.

## hover_pressed_mirrored :: <Theme> var Button.hover_pressed_mirrored: StyleBox
[StyleBox] used when the [Button] is being pressed and hovered at the same time (for right-to-left layouts).

## normal :: <Theme> var Button.normal: StyleBox
Default [StyleBox] for the [Button].

## normal_mirrored :: <Theme> var Button.normal_mirrored: StyleBox
Default [StyleBox] for the [Button] (for right-to-left layouts).

## pressed :: <Theme> var Button.pressed: StyleBox
[StyleBox] used when the [Button] is being pressed.

## pressed_mirrored :: <Theme> var Button.pressed_mirrored: StyleBox
[StyleBox] used when the [Button] is being pressed (for right-to-left layouts).
