# OpenXRSpatialQueryResultData :: <Native> class OpenXRSpatialQueryResultData extends OpenXRSpatialComponentData
Object for storing the main query result data.
Object for storing the main query result data when calling [method OpenXRSpatialEntityExtension.query_snapshot]. This must always be the first component requested.

## get_capacity :: func OpenXRSpatialQueryResultData.get_capacity() -> int
Returns the number of entities that were retrieved.

## get_entity_id :: func OpenXRSpatialQueryResultData.get_entity_id(index: int) -> int
Returns the entity id ([code]XrSpatialEntityIdEXT[/code]) for the entity at this [param index].

### index :: int

## get_entity_state :: func OpenXRSpatialQueryResultData.get_entity_state(index: int) -> int
Returns the entity state for the entity at this [param index].

### index :: int
