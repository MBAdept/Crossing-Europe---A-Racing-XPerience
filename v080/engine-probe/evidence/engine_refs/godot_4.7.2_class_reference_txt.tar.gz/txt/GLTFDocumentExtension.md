# GLTFDocumentExtension :: <Native> class GLTFDocumentExtension extends Resource
[GLTFDocument] extension class.
Extends the functionality of the [GLTFDocument] class by allowing you to run arbitrary code at various stages of glTF import or export.
To use, make a new class extending GLTFDocumentExtension, override any methods you need, make an instance of your class, and register it using [method GLTFDocument.register_gltf_document_extension].
[b]Note:[/b] All GLTFDocumentExtension classes are duplicated when beginning the import or export process. Except for configuration values, these classes must be stateless in order to function properly. If you need to store data, use the [code]set_additional_data[/code] and [code]get_additional_data[/code] methods in [GLTFState] or [GLTFNode].

## _convert_scene_node :: func GLTFDocumentExtension._convert_scene_node(state: GLTFState, gltf_node: GLTFNode, scene_node: Node) -> void
Part of the export process. This method is run after [method _export_preflight] and before [method _export_post_convert].
Runs when converting the data from a Godot scene node. This method can be used to process the Godot scene node data into a format that can be used by [method _export_node].

### state :: GLTFState

### gltf_node :: GLTFNode

### scene_node :: Node

## _export_get_property_list :: func GLTFDocumentExtension._export_get_property_list(root_node: Node) -> Dictionary[]
Runs prior to the export process. This method is run before [method _export_preflight] when exporting a scene from the editor, or it may not be run at all in other situations.
Unlike the rest of the export methods, this does not run when calling a [GLTFDocument]'s export methods in sequence with everything else, but rather runs before that entire process occurs, allowing configuration to occur beforehand, potentially minutes or hours in advance of [method _export_preflight]. This allows extensions to decide which properties to show in the editor export settings dialog based on the contents of the scene, hiding any settings that are not relevant for that scene. The [param root_node] parameter may be [code]null[/code], in which case all properties should be shown.

### root_node :: Node

## _export_node :: func GLTFDocumentExtension._export_node(state: GLTFState, gltf_node: GLTFNode, json: Dictionary, node: Node) -> int
Part of the export process. This method is run after [method _get_saveable_image_formats] and before [method _export_post]. If this [GLTFDocumentExtension] is used for exporting images, this runs after [method _serialize_texture_json].
This method can be used to modify the final JSON of each node. Data should be primarily stored in [param gltf_node] prior to serializing the JSON, but the original Godot [Node] is also provided if available. [param node] may be [code]null[/code] if not available, such as when exporting glTF data not generated from a Godot scene.

### state :: GLTFState

### gltf_node :: GLTFNode

### json :: Dictionary

### node :: Node

## _export_object_model_property :: func GLTFDocumentExtension._export_object_model_property(state: GLTFState, node_path: NodePath, godot_node: Node, gltf_node_index: int, target_object: Object, target_depth: int) -> GLTFObjectModelProperty
Part of the export process. Allows GLTFDocumentExtension classes to provide mappings for properties of nodes in the Godot scene tree, to JSON pointers to glTF properties, as defined by the glTF object model.
Returns a [GLTFObjectModelProperty] instance that defines how the property should be mapped. If your extension can't handle the property, return [code]null[/code] or an instance without any JSON pointers (see [method GLTFObjectModelProperty.has_json_pointers]). You should use [method GLTFObjectModelProperty.set_types] to set the types, and set the JSON pointer(s) using the [member GLTFObjectModelProperty.json_pointers] property.
The parameters provide context for the property, including the NodePath, the Godot node, the GLTF node index, and the target object. The [param target_object] will be equal to [param godot_node] if no sub-object can be found, otherwise it will point to a sub-object. For example, if the path is [code]^"A/B/C/MeshInstance3D:mesh:surface_0/material:emission_intensity"[/code], it will get the node, then the mesh, and then the material, so [param target_object] will be the [Material] resource, and [param target_depth] will be 2 because 2 levels were traversed to get to the target.

### state :: GLTFState

### node_path :: NodePath

### godot_node :: Node

### gltf_node_index :: int

### target_object :: Object

### target_depth :: int

## _export_post :: func GLTFDocumentExtension._export_post(state: GLTFState) -> int
Part of the export process. This method is run last, after all other parts of the export process.
This method can be used to modify the final JSON of the generated glTF file.

### state :: GLTFState

## _export_post_convert :: func GLTFDocumentExtension._export_post_convert(state: GLTFState, root: Node) -> int
Part of the export process. This method is run after [method _convert_scene_node] and before [method _export_preserialize].
This method can be used to modify the converted node data structures before serialization with any additional data from the scene tree.

### state :: GLTFState

### root :: Node

## _export_preflight :: func GLTFDocumentExtension._export_preflight(state: GLTFState, root: Node) -> int
Part of the export process. This method is run first, before all other parts of the export process.
The return value is used to determine if this [GLTFDocumentExtension] instance should be used for exporting a given glTF file. If [constant OK], the export will use this [GLTFDocumentExtension] instance. If not overridden, [constant OK] is returned.

### state :: GLTFState

### root :: Node

## _export_preserialize :: func GLTFDocumentExtension._export_preserialize(state: GLTFState) -> int
Part of the export process. This method is run after [method _export_post_convert] and before [method _get_saveable_image_formats].
This method can be used to alter the state before performing serialization. It runs every time when generating a buffer with [method GLTFDocument.generate_buffer] or writing to the file system with [method GLTFDocument.write_to_filesystem].

### state :: GLTFState

## _generate_scene_node :: func GLTFDocumentExtension._generate_scene_node(state: GLTFState, gltf_node: GLTFNode, scene_parent: Node) -> Node3D
Part of the import process. This method is run after [method _import_pre_generate] and before [method _import_node].
Runs when generating a Godot scene node from a GLTFNode. The returned node will be added to the scene tree. Multiple nodes can be generated in this step if they are added as a child of the returned node.
[b]Note:[/b] The [param scene_parent] parameter may be [code]null[/code] if this is the single root node.

### state :: GLTFState

### gltf_node :: GLTFNode

### scene_parent :: Node

## _get_image_file_extension :: func GLTFDocumentExtension._get_image_file_extension() -> String
Returns the file extension to use for saving image data into, for example, [code]".png"[/code]. If defined, when this extension is used to handle images, and the images are saved to a separate file, the image bytes will be copied to a file with this extension. If this is set, there should be a [ResourceImporter] class able to import the file. If not defined or empty, Godot will save the image into a PNG file.

## _get_saveable_image_formats :: func GLTFDocumentExtension._get_saveable_image_formats() -> PackedStringArray
Part of the export process. This method is run after [method _convert_scene_node] and before [method _export_node].
Returns an array of the image formats that can be saved/exported by this extension. This extension will only be selected as the image exporter if the [GLTFDocument]'s [member GLTFDocument.image_format] is in this array. If this [GLTFDocumentExtension] is selected as the image exporter, one of the [method _save_image_at_path] or [method _serialize_image_to_bytes] methods will run next, otherwise [method _export_node] will run next. If the format name contains [code]"Lossy"[/code], the lossy quality slider will be displayed.

## _get_supported_extensions :: func GLTFDocumentExtension._get_supported_extensions() -> PackedStringArray
Part of the import process. This method is run after [method _import_preflight] and before [method _parse_node_extensions].
Returns an array of the glTF extensions supported by this GLTFDocumentExtension class. This is used to validate if a glTF file with required extensions can be loaded.

## _import_node :: func GLTFDocumentExtension._import_node(state: GLTFState, gltf_node: GLTFNode, json: Dictionary, node: Node) -> int
Part of the import process. This method is run after [method _generate_scene_node] and before [method _import_post].
This method can be used to make modifications to each of the generated Godot scene nodes.

### state :: GLTFState

### gltf_node :: GLTFNode

### json :: Dictionary

### node :: Node

## _import_object_model_property :: func GLTFDocumentExtension._import_object_model_property(state: GLTFState, split_json_pointer: PackedStringArray, partial_paths: NodePath[]) -> GLTFObjectModelProperty
Part of the import process. Allows GLTFDocumentExtension classes to provide mappings for JSON pointers to glTF properties, as defined by the glTF object model, to properties of nodes in the Godot scene tree.
Returns a [GLTFObjectModelProperty] instance that defines how the property should be mapped. If your extension can't handle the property, return [code]null[/code] or an instance without any NodePaths (see [method GLTFObjectModelProperty.has_node_paths]). You should use [method GLTFObjectModelProperty.set_types] to set the types, and [method GLTFObjectModelProperty.append_path_to_property] function is useful for most simple cases.
In many cases, [param partial_paths] will contain the start of a path, allowing the extension to complete the path. For example, for [code]/nodes/3/extensions/MY_ext/prop[/code], Godot will pass you a NodePath that leads to node 3, so the GLTFDocumentExtension class only needs to resolve the last [code]MY_ext/prop[/code] part of the path. In this example, the extension should check [code]split.size() > 4 and split[0] == "nodes" and split[2] == "extensions" and split[3] == "MY_ext"[/code] at the start of the function to check if this JSON pointer applies to it, then it can use [param partial_paths] and handle [code]split[4][/code].

### state :: GLTFState

### split_json_pointer :: PackedStringArray

### partial_paths :: NodePath[]

## _import_post :: func GLTFDocumentExtension._import_post(state: GLTFState, root: Node) -> int
Part of the import process. This method is run last, after all other parts of the import process.
This method can be used to modify the final Godot scene generated by the import process.

### state :: GLTFState

### root :: Node

## _import_post_parse :: func GLTFDocumentExtension._import_post_parse(state: GLTFState) -> int
Part of the import process. This method is run after [method _parse_node_extensions] and before [method _import_pre_generate].
This method can be used to modify any of the data imported so far after parsing each node, but before generating the scene or any of its nodes.

### state :: GLTFState

## _import_pre_generate :: func GLTFDocumentExtension._import_pre_generate(state: GLTFState) -> int
Part of the import process. This method is run after [method _import_post_parse] and before [method _generate_scene_node].
This method can be used to modify or read from any of the processed data structures, before generating the nodes and then running the final per-node import step.

### state :: GLTFState

## _import_preflight :: func GLTFDocumentExtension._import_preflight(state: GLTFState, extensions: PackedStringArray) -> int
Part of the import process. This method is run first, before all other parts of the import process.
The return value is used to determine if this [GLTFDocumentExtension] instance should be used for importing a given glTF file. If [constant OK], the import will use this [GLTFDocumentExtension] instance. If not overridden, [constant OK] is returned.

### state :: GLTFState

### extensions :: PackedStringArray

## _parse_image_data :: func GLTFDocumentExtension._parse_image_data(state: GLTFState, image_data: PackedByteArray, mime_type: String, ret_image: Image) -> int
Part of the import process. This method is run after [method _parse_node_extensions] and before [method _parse_texture_json].
Runs when parsing image data from a glTF file. The data could be sourced from a separate file, a URI, or a buffer, and then is passed as a byte array.

### state :: GLTFState

### image_data :: PackedByteArray

### mime_type :: String

### ret_image :: Image

## _parse_node_extensions :: func GLTFDocumentExtension._parse_node_extensions(state: GLTFState, gltf_node: GLTFNode, extensions: Dictionary) -> int
Part of the import process. This method is run after [method _get_supported_extensions] and before [method _import_post_parse].
Runs when parsing the node extensions of a GLTFNode. This method can be used to process the extension JSON data into a format that can be used by [method _generate_scene_node]. The return value should be a member of the [enum Error] enum.

### state :: GLTFState

### gltf_node :: GLTFNode

### extensions :: Dictionary

## _parse_texture_json :: func GLTFDocumentExtension._parse_texture_json(state: GLTFState, texture_json: Dictionary, ret_gltf_texture: GLTFTexture) -> int
Part of the import process. This method is run after [method _parse_image_data] and before [method _generate_scene_node].
Runs when parsing the texture JSON from the glTF textures array. This can be used to set the source image index to use as the texture.

### state :: GLTFState

### texture_json :: Dictionary

### ret_gltf_texture :: GLTFTexture

## _save_image_at_path :: func GLTFDocumentExtension._save_image_at_path(state: GLTFState, image: Image, file_path: String, image_format: String, lossy_quality: float) -> int
Part of the export process. This method is run after [method _get_saveable_image_formats] and before [method _serialize_texture_json].
This method is run when saving images separately from the glTF file. When images are embedded, [method _serialize_image_to_bytes] runs instead. Note that these methods only run when this [GLTFDocumentExtension] is selected as the image exporter.

### state :: GLTFState

### image :: Image

### file_path :: String

### image_format :: String

### lossy_quality :: float

## _serialize_image_to_bytes :: func GLTFDocumentExtension._serialize_image_to_bytes(state: GLTFState, image: Image, image_dict: Dictionary, image_format: String, lossy_quality: float) -> PackedByteArray
Part of the export process. This method is run after [method _get_saveable_image_formats] and before [method _serialize_texture_json].
This method is run when embedding images in the glTF file. When images are saved separately, [method _save_image_at_path] runs instead. Note that these methods only run when this [GLTFDocumentExtension] is selected as the image exporter.
This method must set the image MIME type in the [param image_dict] with the [code]"mimeType"[/code] key. For example, for a PNG image, it would be set to [code]"image/png"[/code]. The return value must be a [PackedByteArray] containing the image data.

### state :: GLTFState

### image :: Image

### image_dict :: Dictionary

### image_format :: String

### lossy_quality :: float

## _serialize_texture_json :: func GLTFDocumentExtension._serialize_texture_json(state: GLTFState, texture_json: Dictionary, gltf_texture: GLTFTexture, image_format: String) -> int
Part of the export process. This method is run after [method _save_image_at_path] or [method _serialize_image_to_bytes], and before [method _export_node]. Note that this method only runs when this [GLTFDocumentExtension] is selected as the image exporter.
This method can be used to set up the extensions for the texture JSON by editing [param texture_json]. The extension must also be added as used extension with [method GLTFState.add_used_extension], be sure to set [code]required[/code] to [code]true[/code] if you are not providing a fallback.

### state :: GLTFState

### texture_json :: Dictionary

### gltf_texture :: GLTFTexture

### image_format :: String
