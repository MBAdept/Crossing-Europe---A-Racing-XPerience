# Quaternion :: <Native> class Quaternion
A unit quaternion used for representing 3D rotations.
The [Quaternion] built-in [Variant] type is a 4D data structure that represents rotation in the form of a [url=https://en.wikipedia.org/wiki/Quaternions_and_spatial_rotation]Hamilton convention quaternion[/url]. Compared to the [Basis] type which can store both rotation and scale, quaternions can [i]only[/i] store rotation.
A [Quaternion] is composed by 4 floating-point components: [member w], [member x], [member y], and [member z]. These components are very compact in memory, and because of this some operations are more efficient and less likely to cause floating-point errors. Methods such as [method get_angle], [method get_axis], and [method slerp] are faster than their [Basis] counterparts.
For a great introduction to quaternions, see [url=https://www.youtube.com/watch?v=d4EgbgTm0Bg]this video by 3Blue1Brown[/url]. You do not need to know the math behind quaternions, as Godot provides several helper methods that handle it for you. These include [method slerp] and [method spherical_cubic_interpolate], as well as the [code]*[/code] operator.
[b]Note:[/b] Quaternions must be normalized before being used for rotation (see [method normalized]).
[b]Note:[/b] Similarly to [Vector2] and [Vector3], the components of a quaternion use 32-bit precision by default, unlike [float] which is always 64-bit. If double precision is needed, compile the engine with the option [code]precision=double[/code].
[b]Note:[/b] In a boolean context, a quaternion will evaluate to [code]false[/code] if it's equal to [constant IDENTITY]. Otherwise, a quaternion will always evaluate to [code]true[/code].

## IDENTITY :: const Quaternion.IDENTITY = Quaternion(0, 0, 0, 1)
The identity quaternion, representing no rotation. This has the same rotation as [constant Basis.IDENTITY].
If a [Vector3] is rotated (multiplied) by this quaternion, it does not change.
[b]Note:[/b] In GDScript, this constant is equivalent to creating a [constructor Quaternion] without any arguments. It can be used to make your code clearer, and for consistency with C#.

## w :: var Quaternion.w: float
W component of the quaternion. This is the "real" part.
[b]Note:[/b] Quaternion components should usually not be manipulated directly.

## x :: var Quaternion.x: float
X component of the quaternion. This is the value along the "imaginary" [code]i[/code] axis.
[b]Note:[/b] Quaternion components should usually not be manipulated directly.

## y :: var Quaternion.y: float
Y component of the quaternion. This is the value along the "imaginary" [code]j[/code] axis.
[b]Note:[/b] Quaternion components should usually not be manipulated directly.

## z :: var Quaternion.z: float
Z component of the quaternion. This is the value along the "imaginary" [code]k[/code] axis.
[b]Note:[/b] Quaternion components should usually not be manipulated directly.

## angle_to :: func Quaternion.angle_to(to: Quaternion) -> float
Returns the angle between this quaternion and [param to]. This is the magnitude of the angle you would need to rotate by to get from one to the other.
[b]Note:[/b] The magnitude of the floating-point error for this method is abnormally high, so methods such as [code]is_zero_approx[/code] will not work reliably.

### to :: Quaternion

## dot :: func Quaternion.dot(with: Quaternion) -> float
Returns the dot product between this quaternion and [param with].
This is equivalent to [code](quat.x * with.x) + (quat.y * with.y) + (quat.z * with.z) + (quat.w * with.w)[/code].

### with :: Quaternion

## exp :: func Quaternion.exp() -> Quaternion
Returns the exponential of this quaternion. The rotation axis of the result is the normalized rotation axis of this quaternion, the angle of the result is the length of the vector part of this quaternion.

## from_euler :: func Quaternion.from_euler(euler: Vector3) -> Quaternion
Constructs a new [Quaternion] from the given [Vector3] of [url=https://en.wikipedia.org/wiki/Euler_angles]Euler angles[/url], in radians. In Godot, Euler angles always use intrinsic order. This method always uses the intrinsic YXZ convention ([constant EULER_ORDER_YXZ]).

### euler :: Vector3

## get_angle :: func Quaternion.get_angle() -> float
Returns the angle of the rotation represented by this quaternion.
[b]Note:[/b] The quaternion must be normalized.

## get_axis :: func Quaternion.get_axis() -> Vector3
Returns the rotation axis of the rotation represented by this quaternion.

## get_euler :: func Quaternion.get_euler(order: int = 2) -> Vector3
Returns this quaternion's rotation as a [Vector3] of [url=https://en.wikipedia.org/wiki/Euler_angles]Euler angles[/url], in radians.
The order of each consecutive rotation can be changed with [param order] (see [enum EulerOrder] constants). In Godot, Euler angles always use intrinsic order. By default, the intrinsic YXZ convention is used ([constant EULER_ORDER_YXZ]): since we are decomposing, local Z (roll) is calculated first, then local X (pitch), and lastly local Y (yaw). When using the opposite method [method from_euler] to compose a rotation, this order is reversed.

### order :: int

## inverse :: func Quaternion.inverse() -> Quaternion
Returns the inverse version of this quaternion, inverting the sign of every component except [member w].

## is_equal_approx :: func Quaternion.is_equal_approx(to: Quaternion) -> bool
Returns [code]true[/code] if this quaternion and [param to] are approximately equal, by calling [method @GlobalScope.is_equal_approx] on each component.

### to :: Quaternion

## is_finite :: func Quaternion.is_finite() -> bool
Returns [code]true[/code] if this quaternion is finite, by calling [method @GlobalScope.is_finite] on each component.

## is_normalized :: func Quaternion.is_normalized() -> bool
Returns [code]true[/code] if this quaternion is normalized. See also [method normalized].

## length :: func Quaternion.length() -> float
Returns this quaternion's length, also called magnitude.

## length_squared :: func Quaternion.length_squared() -> float
Returns this quaternion's length, squared.
[b]Note:[/b] This method is faster than [method length], so prefer it if you only need to compare quaternion lengths.

## log :: func Quaternion.log() -> Quaternion
Returns the logarithm of this quaternion. Multiplies this quaternion's rotation axis by its rotation angle, and stores the result in the returned quaternion's vector part ([member x], [member y], and [member z]). The returned quaternion's real part ([member w]) is always [code]0.0[/code].

## normalized :: func Quaternion.normalized() -> Quaternion
Returns a copy of this quaternion, normalized so that its length is [code]1.0[/code]. See also [method is_normalized].

## slerp :: func Quaternion.slerp(to: Quaternion, weight: float) -> Quaternion
Performs a spherical-linear interpolation with the [param to] quaternion, given a [param weight] and returns the result. Both this quaternion and [param to] must be normalized.

### to :: Quaternion

### weight :: float

## slerpni :: func Quaternion.slerpni(to: Quaternion, weight: float) -> Quaternion
Performs a spherical-linear interpolation with the [param to] quaternion, given a [param weight] and returns the result. Unlike [method slerp], this method does not check if the rotation path is smaller than 90 degrees. Both this quaternion and [param to] must be normalized.

### to :: Quaternion

### weight :: float

## spherical_cubic_interpolate :: func Quaternion.spherical_cubic_interpolate(b: Quaternion, pre_a: Quaternion, post_b: Quaternion, weight: float) -> Quaternion
Performs a spherical cubic interpolation between quaternions [param pre_a], this vector, [param b], and [param post_b], by the given amount [param weight].

### b :: Quaternion

### pre_a :: Quaternion

### post_b :: Quaternion

### weight :: float

## spherical_cubic_interpolate_in_time :: func Quaternion.spherical_cubic_interpolate_in_time(b: Quaternion, pre_a: Quaternion, post_b: Quaternion, weight: float, b_t: float, pre_a_t: float, post_b_t: float) -> Quaternion
Performs a spherical cubic interpolation between quaternions [param pre_a], this vector, [param b], and [param post_b], by the given amount [param weight].
It can perform smoother interpolation than [method spherical_cubic_interpolate] by the time values.

### b :: Quaternion

### pre_a :: Quaternion

### post_b :: Quaternion

### weight :: float

### b_t :: float

### pre_a_t :: float

### post_b_t :: float

## Quaternion :: func Quaternion.Quaternion() -> Quaternion
Constructs a [Quaternion] identical to [constant IDENTITY].
[b]Note:[/b] In C#, this constructs a [Quaternion] with all of its components set to [code]0.0[/code].

## Quaternion :: func Quaternion.Quaternion(from: Quaternion) -> Quaternion
Constructs a [Quaternion] as a copy of the given [Quaternion].

### from :: Quaternion

## Quaternion :: func Quaternion.Quaternion(arc_from: Vector3, arc_to: Vector3) -> Quaternion
Constructs a [Quaternion] representing the shortest arc between [param arc_from] and [param arc_to]. These can be imagined as two points intersecting a sphere's surface, with a radius of [code]1.0[/code].

### arc_from :: Vector3

### arc_to :: Vector3

## Quaternion :: func Quaternion.Quaternion(axis: Vector3, angle: float) -> Quaternion
Constructs a [Quaternion] representing rotation around the [param axis] by the given [param angle], in radians. The axis must be a normalized vector.

### axis :: Vector3

### angle :: float

## Quaternion :: func Quaternion.Quaternion(from: Basis) -> Quaternion
Constructs a [Quaternion] from the given rotation [Basis].
This constructor is faster than [method Basis.get_rotation_quaternion], but the given basis must be [i]orthonormalized[/i] (see [method Basis.orthonormalized]). Otherwise, the constructor fails and returns [constant IDENTITY].

### from :: Basis

## Quaternion :: func Quaternion.Quaternion(x: float, y: float, z: float, w: float) -> Quaternion
Constructs a [Quaternion] defined by the given values.
[b]Note:[/b] Only normalized quaternions represent rotation; if these values are not normalized, the new [Quaternion] will not be a valid rotation.

### x :: float

### y :: float

### z :: float

### w :: float

## operator != :: func Quaternion.operator !=(right: Quaternion) -> bool
Returns [code]true[/code] if the components of both quaternions are not exactly equal.
[b]Note:[/b] Due to floating-point precision errors, consider using [method is_equal_approx] instead, which is more reliable.

### right :: Quaternion

## operator * :: func Quaternion.operator *(right: Quaternion) -> Quaternion
Composes (multiplies) two quaternions. This rotates the [param right] quaternion (the child) by this quaternion (the parent).

### right :: Quaternion

## operator * :: func Quaternion.operator *(right: Vector3) -> Vector3
Rotates (multiplies) the [param right] vector by this quaternion, returning a [Vector3].

### right :: Vector3

## operator * :: func Quaternion.operator *(right: float) -> Quaternion
Multiplies each component of the [Quaternion] by the right [float] value.
This operation is not meaningful on its own, but it can be used as a part of a larger expression.

### right :: float

## operator * :: func Quaternion.operator *(right: int) -> Quaternion
Multiplies each component of the [Quaternion] by the right [int] value.
This operation is not meaningful on its own, but it can be used as a part of a larger expression.

### right :: int

## operator + :: func Quaternion.operator +(right: Quaternion) -> Quaternion
Adds each component of the left [Quaternion] to the right [Quaternion].
This operation is not meaningful on its own, but it can be used as a part of a larger expression, such as approximating an intermediate rotation between two nearby rotations.

### right :: Quaternion

## operator - :: func Quaternion.operator -(right: Quaternion) -> Quaternion
Subtracts each component of the left [Quaternion] by the right [Quaternion].
This operation is not meaningful on its own, but it can be used as a part of a larger expression.

### right :: Quaternion

## operator / :: func Quaternion.operator /(right: float) -> Quaternion
Divides each component of the [Quaternion] by the right [float] value.
This operation is not meaningful on its own, but it can be used as a part of a larger expression.

### right :: float

## operator / :: func Quaternion.operator /(right: int) -> Quaternion
Divides each component of the [Quaternion] by the right [int] value.
This operation is not meaningful on its own, but it can be used as a part of a larger expression.

### right :: int

## operator == :: func Quaternion.operator ==(right: Quaternion) -> bool
Returns [code]true[/code] if the components of both quaternions are exactly equal.
[b]Note:[/b] Due to floating-point precision errors, consider using [method is_equal_approx] instead, which is more reliable.

### right :: Quaternion

## operator [] :: func Quaternion.operator [](index: int) -> float
Accesses each component of this quaternion by their index.
Index [code]0[/code] is the same as [member x], index [code]1[/code] is the same as [member y], index [code]2[/code] is the same as [member z], and index [code]3[/code] is the same as [member w].

### index :: int

## operator unary+ :: func Quaternion.operator unary+() -> Quaternion
Returns the same value as if the [code]+[/code] was not there. Unary [code]+[/code] does nothing, but sometimes it can make your code more readable.

## operator unary- :: func Quaternion.operator unary-() -> Quaternion
Returns the negative value of the [Quaternion]. This is the same as multiplying all components by [code]-1[/code]. This operation results in a quaternion that represents the same rotation.
