# PinJoint2D :: <Native> class PinJoint2D extends Joint2D
A physics joint that attaches two 2D physics bodies at a single point, allowing them to freely rotate.
A physics joint that attaches two 2D physics bodies at a single point, allowing them to freely rotate. For example, a [RigidBody2D] can be attached to a [StaticBody2D] to create a pendulum or a seesaw.

## angular_limit_enabled :: var PinJoint2D.angular_limit_enabled: bool
If [code]true[/code], the pin maximum and minimum rotation, defined by [member angular_limit_lower] and [member angular_limit_upper] are applied.

## angular_limit_lower :: var PinJoint2D.angular_limit_lower: float
The minimum rotation. Only active if [member angular_limit_enabled] is [code]true[/code].

## angular_limit_upper :: var PinJoint2D.angular_limit_upper: float
The maximum rotation. Only active if [member angular_limit_enabled] is [code]true[/code].

## motor_enabled :: var PinJoint2D.motor_enabled: bool
When activated, a motor turns the pin.

## motor_target_velocity :: var PinJoint2D.motor_target_velocity: float
Target speed for the motor. In radians per second.

## softness :: var PinJoint2D.softness: float
The higher this value, the more the bond to the pinned partner can flex.
