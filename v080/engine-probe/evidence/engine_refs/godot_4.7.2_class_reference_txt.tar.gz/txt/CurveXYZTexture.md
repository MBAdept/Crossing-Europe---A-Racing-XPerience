# CurveXYZTexture :: <Native> class CurveXYZTexture extends Texture2D
A 1D texture where the red, green, and blue color channels correspond to points on 3 curves.
A 1D texture where the red, green, and blue color channels correspond to points on 3 unit [Curve] resources. Compared to using separate [CurveTexture]s, this further simplifies the task of saving curves as image files.
If you only need to store one curve within a single texture, use [CurveTexture] instead. See also [GradientTexture1D] and [GradientTexture2D].

## curve_x :: var CurveXYZTexture.curve_x: Curve
The [Curve] that is rendered onto the texture's red channel. Should be a unit [Curve].

## curve_y :: var CurveXYZTexture.curve_y: Curve
The [Curve] that is rendered onto the texture's green channel. Should be a unit [Curve].

## curve_z :: var CurveXYZTexture.curve_z: Curve
The [Curve] that is rendered onto the texture's blue channel. Should be a unit [Curve].

## resource_local_to_scene :: var CurveXYZTexture.resource_local_to_scene: bool

## width :: var CurveXYZTexture.width: int
The width of the texture (in pixels). Higher values make it possible to represent high-frequency data better (such as sudden direction changes), at the cost of increased generation time and memory usage.
