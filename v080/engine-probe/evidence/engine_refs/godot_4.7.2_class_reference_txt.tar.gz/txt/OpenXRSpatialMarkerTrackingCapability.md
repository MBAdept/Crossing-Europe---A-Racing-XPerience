# OpenXRSpatialMarkerTrackingCapability :: <Native> class OpenXRSpatialMarkerTrackingCapability extends OpenXRExtensionWrapper
Implementation for handling spatial entity marker tracking logic.
This class handles the OpenXR marker tracking spatial entity extension.

## do_entity_update :: func OpenXRSpatialMarkerTrackingCapability.do_entity_update(spatial_context: RID, component_data: OpenXRSpatialComponentData[], next_snapshot_create: OpenXRStructureBase = null, next_snapshot_query: OpenXRStructureBase = null) -> void
Calls [method OpenXRSpatialEntityExtension.update_spatial_entities] and [method OpenXRSpatialEntityExtension.query_snapshot] with the marker entities associated with [param spatial_context].
[param component_data] are the [OpenXRSpatialComponentData]s to update for this marker capability.
If [param next_snapshot_create] is non-null, then pass this to the [code]next[/code] parameter in [method OpenXRSpatialEntityExtension.update_spatial_entities].
If [param next_snapshot_query] is non-null, then pass this to the [code]next[/code] parameter in [method OpenXRSpatialEntityExtension.query_snapshot].

### spatial_context :: RID

### component_data :: OpenXRSpatialComponentData[]

### next_snapshot_create :: OpenXRStructureBase

### next_snapshot_query :: OpenXRStructureBase

## is_april_tag_supported :: func OpenXRSpatialMarkerTrackingCapability.is_april_tag_supported() -> bool
Returns [code]true[/code] if April tag marker tracking is supported by the current device.

## is_aruco_supported :: func OpenXRSpatialMarkerTrackingCapability.is_aruco_supported() -> bool
Returns [code]true[/code] if Aruco marker tracking is supported by the current device.

## is_micro_qrcode_supported :: func OpenXRSpatialMarkerTrackingCapability.is_micro_qrcode_supported() -> bool
Returns [code]true[/code] if micro QR code marker tracking is supported by the current device.

## is_qrcode_supported :: func OpenXRSpatialMarkerTrackingCapability.is_qrcode_supported() -> bool
Returns [code]true[/code] if QR code marker tracking is supported by the current device.

## start_entity_discovery :: func OpenXRSpatialMarkerTrackingCapability.start_entity_discovery(spatial_context: RID, component_data: OpenXRSpatialComponentData[], next_snapshot_create: OpenXRStructureBase = null, next_snapshot_query: OpenXRStructureBase = null, user_callback: Callable = Callable()) -> OpenXRFutureResult
Calls [method OpenXRSpatialEntityExtension.discover_spatial_entities] and [method OpenXRSpatialEntityExtension.query_snapshot] with the marker entities associated with [param spatial_context].
[param component_data] are the [OpenXRSpatialComponentData]s to discover for this marker capability.
If [param next_snapshot_create] is non-null, then pass this to the [code]next[/code] parameter in [method OpenXRSpatialEntityExtension.discover_spatial_entities].
If [param next_snapshot_query] is non-null, then pass this to the [code]next[/code] parameter in [method OpenXRSpatialEntityExtension.query_snapshot].
[param user_callback], when non-null, is called with two parameters usually twice. The first parameter is the [RID] of the discovery snapshot and the second parameter is a boolean where [code]false[/code] indicates the discovery snapshot is about to be processed, and [code]true[/code] indicates the discovery snapshot has been processed and [param component_data] has valid data. The second call is skipped if an error was encountered.
The returned [OpenXRFutureResult] is identical to the return from [method OpenXRSpatialEntityExtension.discover_spatial_entities].

### spatial_context :: RID

### component_data :: OpenXRSpatialComponentData[]

### next_snapshot_create :: OpenXRStructureBase

### next_snapshot_query :: OpenXRStructureBase

### user_callback :: Callable
