# NavigationMeshSourceGeometryData3D :: <Native> class NavigationMeshSourceGeometryData3D extends Resource
Container for parsed source geometry data used in navigation mesh baking.
Container for parsed source geometry data used in navigation mesh baking.

## add_faces :: func NavigationMeshSourceGeometryData3D.add_faces(faces: PackedVector3Array, xform: Transform3D) -> void
Adds an array of vertex positions to the geometry data for navigation mesh baking to form triangulated faces. For each face the array must have three vertex positions in clockwise winding order. Since [NavigationMesh] resources have no transform, all vertex positions need to be offset by the node's transform using [param xform].

### faces :: PackedVector3Array

### xform :: Transform3D

## add_mesh :: func NavigationMeshSourceGeometryData3D.add_mesh(mesh: Mesh, xform: Transform3D) -> void
Adds the geometry data of a [Mesh] resource to the navigation mesh baking data. The mesh must have valid triangulated mesh data to be considered. Since [NavigationMesh] resources have no transform, all vertex positions need to be offset by the node's transform using [param xform].

### mesh :: Mesh

### xform :: Transform3D

## add_mesh_array :: func NavigationMeshSourceGeometryData3D.add_mesh_array(mesh_array: Array, xform: Transform3D) -> void
Adds an [Array] the size of [constant Mesh.ARRAY_MAX] and with vertices at index [constant Mesh.ARRAY_VERTEX] and indices at index [constant Mesh.ARRAY_INDEX] to the navigation mesh baking data. The array must have valid triangulated mesh data to be considered. Since [NavigationMesh] resources have no transform, all vertex positions need to be offset by the node's transform using [param xform].

### mesh_array :: Array

### xform :: Transform3D

## add_projected_obstruction :: func NavigationMeshSourceGeometryData3D.add_projected_obstruction(vertices: PackedVector3Array, elevation: float, height: float, carve: bool) -> void
Adds a projected obstruction shape to the source geometry. The [param vertices] are considered projected on an xz-axes plane, placed at the global y-axis [param elevation] and extruded by [param height]. If [param carve] is [code]true[/code] the carved shape will not be affected by additional offsets (e.g. agent radius) of the navigation mesh baking process.

### vertices :: PackedVector3Array

### elevation :: float

### height :: float

### carve :: bool

## append_arrays :: func NavigationMeshSourceGeometryData3D.append_arrays(vertices: PackedFloat32Array, indices: PackedInt32Array) -> void
Appends arrays of [param vertices] and [param indices] at the end of the existing arrays. Adds the existing index as an offset to the appended indices.

### vertices :: PackedFloat32Array

### indices :: PackedInt32Array

## clear :: func NavigationMeshSourceGeometryData3D.clear() -> void
Clears the internal data.

## clear_projected_obstructions :: func NavigationMeshSourceGeometryData3D.clear_projected_obstructions() -> void
Clears all projected obstructions.

## get_bounds :: func NavigationMeshSourceGeometryData3D.get_bounds() -> AABB
Returns an axis-aligned bounding box that covers all the stored geometry data. The bounds are calculated when calling this function with the result cached until further geometry changes are made.

## get_indices :: func NavigationMeshSourceGeometryData3D.get_indices() -> PackedInt32Array
Returns the parsed source geometry data indices array.

## get_projected_obstructions :: func NavigationMeshSourceGeometryData3D.get_projected_obstructions() -> Array
Returns the projected obstructions as an [Array] of dictionaries. Each [Dictionary] contains the following entries:
- [code]vertices[/code] - A [PackedFloat32Array] that defines the outline points of the projected shape.
- [code]elevation[/code] - A [float] that defines the projected shape placement on the y-axis.
- [code]height[/code] - A [float] that defines how much the projected shape is extruded along the y-axis.
- [code]carve[/code] - A [bool] that defines how the obstacle affects the navigation mesh baking. If [code]true[/code] the projected shape will not be affected by addition offsets, e.g. agent radius.

## get_vertices :: func NavigationMeshSourceGeometryData3D.get_vertices() -> PackedFloat32Array
Returns the parsed source geometry data vertices array.

## has_data :: func NavigationMeshSourceGeometryData3D.has_data() -> bool
Returns [code]true[/code] when parsed source geometry data exists.

## merge :: func NavigationMeshSourceGeometryData3D.merge(other_geometry: NavigationMeshSourceGeometryData3D) -> void
Adds the geometry data of another [NavigationMeshSourceGeometryData3D] to the navigation mesh baking data.

### other_geometry :: NavigationMeshSourceGeometryData3D

## set_indices :: func NavigationMeshSourceGeometryData3D.set_indices(indices: PackedInt32Array) -> void
Sets the parsed source geometry data indices. The indices need to be matched with appropriated vertices.
[b]Warning:[/b] Inappropriate data can crash the baking process of the involved third-party libraries.

### indices :: PackedInt32Array

## set_projected_obstructions :: func NavigationMeshSourceGeometryData3D.set_projected_obstructions(projected_obstructions: Array) -> void
Sets the projected obstructions with an Array of Dictionaries with the following key value pairs:
[codeblocks]
[gdscript]
"vertices" : PackedFloat32Array
"elevation" : float
"height" : float
"carve" : bool
[/gdscript]
[/codeblocks]

### projected_obstructions :: Array

## set_vertices :: func NavigationMeshSourceGeometryData3D.set_vertices(vertices: PackedFloat32Array) -> void
Sets the parsed source geometry data vertices. The vertices need to be matched with appropriated indices.
[b]Warning:[/b] Inappropriate data can crash the baking process of the involved third-party libraries.

### vertices :: PackedFloat32Array
