# VisualShaderNodeFrame :: <Native> class VisualShaderNodeFrame extends VisualShaderNodeResizableBase
A frame other visual shader nodes can be attached to for better organization.
A rectangular frame that can be used to group visual shader nodes together to improve organization.
Nodes attached to the frame will move with it when it is dragged and it can automatically resize to enclose all attached nodes.
Its title, description and color can be customized.

## attached_nodes :: var VisualShaderNodeFrame.attached_nodes: PackedInt32Array
The list of nodes attached to the frame.

## autoshrink :: var VisualShaderNodeFrame.autoshrink: bool
If [code]true[/code], the frame will automatically resize to enclose all attached nodes.

## tint_color :: var VisualShaderNodeFrame.tint_color: Color
The color of the frame when [member tint_color_enabled] is [code]true[/code].

## tint_color_enabled :: var VisualShaderNodeFrame.tint_color_enabled: bool
If [code]true[/code], the frame will be tinted with the color specified in [member tint_color].

## title :: var VisualShaderNodeFrame.title: String
The title of the node.

## add_attached_node :: func VisualShaderNodeFrame.add_attached_node(node: int) -> void
Adds a node to the list of nodes attached to the frame. Should not be called directly, use the [method VisualShader.attach_node_to_frame] method instead.

### node :: int

## remove_attached_node :: func VisualShaderNodeFrame.remove_attached_node(node: int) -> void
Removes a node from the list of nodes attached to the frame. Should not be called directly, use the [method VisualShader.detach_node_from_frame] method instead.

### node :: int
