# NavigationLink2D :: <Native> class NavigationLink2D extends Node2D
A link between two positions on [NavigationRegion2D]s that agents can be routed through.
A link between two positions on [NavigationRegion2D]s that agents can be routed through. These positions can be on the same [NavigationRegion2D] or on two different ones. Links are useful to express navigation methods other than traveling along the surface of the navigation polygon, such as ziplines, teleporters, or gaps that can be jumped across.

## bidirectional :: var NavigationLink2D.bidirectional: bool
Whether this link can be traveled in both directions or only from [member start_position] to [member end_position].

## enabled :: var NavigationLink2D.enabled: bool
Whether this link is currently active. If [code]false[/code], [method NavigationServer2D.map_get_path] will ignore this link.

## end_position :: var NavigationLink2D.end_position: Vector2
Ending position of the link.
This position will search out the nearest polygon in the navigation mesh to attach to.
The distance the link will search is controlled by [method NavigationServer2D.map_set_link_connection_radius].

## enter_cost :: var NavigationLink2D.enter_cost: float
When pathfinding enters this link from another regions navigation mesh the [member enter_cost] value is added to the path distance for determining the shortest path.

## navigation_layers :: var NavigationLink2D.navigation_layers: int
A bitfield determining all navigation layers the link belongs to. These navigation layers will be checked when requesting a path with [method NavigationServer2D.map_get_path].

## start_position :: var NavigationLink2D.start_position: Vector2
Starting position of the link.
This position will search out the nearest polygon in the navigation mesh to attach to.
The distance the link will search is controlled by [method NavigationServer2D.map_set_link_connection_radius].

## travel_cost :: var NavigationLink2D.travel_cost: float
When pathfinding moves along the link the traveled distance is multiplied with [member travel_cost] for determining the shortest path.

## get_global_end_position :: func NavigationLink2D.get_global_end_position() -> Vector2
Returns the [member end_position] that is relative to the link as a global position.

## get_global_start_position :: func NavigationLink2D.get_global_start_position() -> Vector2
Returns the [member start_position] that is relative to the link as a global position.

## get_navigation_layer_value :: func NavigationLink2D.get_navigation_layer_value(layer_number: int) -> bool
Returns whether or not the specified layer of the [member navigation_layers] bitmask is enabled, given a [param layer_number] between 1 and 32.

### layer_number :: int

## get_navigation_map :: func NavigationLink2D.get_navigation_map() -> RID
Returns the current navigation map [RID] used by this link.

## get_rid :: func NavigationLink2D.get_rid() -> RID
Returns the [RID] of this link on the [NavigationServer2D].

## set_global_end_position :: func NavigationLink2D.set_global_end_position(position: Vector2) -> void
Sets the [member end_position] that is relative to the link from a global [param position].

### position :: Vector2

## set_global_start_position :: func NavigationLink2D.set_global_start_position(position: Vector2) -> void
Sets the [member start_position] that is relative to the link from a global [param position].

### position :: Vector2

## set_navigation_layer_value :: func NavigationLink2D.set_navigation_layer_value(layer_number: int, value: bool) -> void
Based on [param value], enables or disables the specified layer in the [member navigation_layers] bitmask, given a [param layer_number] between 1 and 32.

### layer_number :: int

### value :: bool

## set_navigation_map :: func NavigationLink2D.set_navigation_map(navigation_map: RID) -> void
Sets the [RID] of the navigation map this link should use. By default the link will automatically join the [World2D] default navigation map so this function is only required to override the default map.

### navigation_map :: RID
