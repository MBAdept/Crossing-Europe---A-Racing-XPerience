# Translation :: <Native> class Translation extends Resource
A language translation that maps a collection of strings to their individual translations.
[Translation] maps a collection of strings to their individual translations, and also provides convenience methods for pluralization.
A [Translation] consists of messages. A message is identified by its context and untranslated string. Unlike [url=https://www.gnu.org/software/gettext/]gettext[/url], using an empty context string in Godot means not using any context.

## locale :: var Translation.locale: String
The locale of the translation.

## plural_rules_override :: var Translation.plural_rules_override: String
The plural rules string to enforce. See [url=https://www.gnu.org/software/gettext/manual/html_node/Plural-forms.html]GNU gettext[/url] for examples and more info.
If empty or invalid, default plural rules from [method TranslationServer.get_plural_rules] are used. The English plural rules are used as a fallback.

## _get_message :: func Translation._get_message(src_message: StringName, context: StringName) -> StringName
Virtual method to override [method get_message].

### src_message :: StringName

### context :: StringName

## _get_plural_message :: func Translation._get_plural_message(src_message: StringName, src_plural_message: StringName, n: int, context: StringName) -> StringName
Virtual method to override [method get_plural_message].

### src_message :: StringName

### src_plural_message :: StringName

### n :: int

### context :: StringName

## add_message :: func Translation.add_message(src_message: StringName, xlated_message: StringName, context: StringName = &"") -> void
Adds a message if nonexistent, followed by its translation.
An additional context could be used to specify the translation context or differentiate polysemic words.

### src_message :: StringName

### xlated_message :: StringName

### context :: StringName

## add_plural_message :: func Translation.add_plural_message(src_message: StringName, xlated_messages: PackedStringArray, context: StringName = &"") -> void
Adds a message involving plural translation if nonexistent, followed by its translation.
An additional context could be used to specify the translation context or differentiate polysemic words.

### src_message :: StringName

### xlated_messages :: PackedStringArray

### context :: StringName

## erase_message :: func Translation.erase_message(src_message: StringName, context: StringName = &"") -> void
Erases a message.

### src_message :: StringName

### context :: StringName

## get_message :: func Translation.get_message(src_message: StringName, context: StringName = &"") -> StringName
Returns a message's translation.

### src_message :: StringName

### context :: StringName

## get_message_count :: func Translation.get_message_count() -> int
Returns the number of existing messages.

## get_message_list :: func Translation.get_message_list() -> PackedStringArray
Returns the keys of all messages, that is, the context and untranslated strings of each message.
[b]Note:[/b] If a message does not use a context, the corresponding element is the untranslated string. Otherwise, the corresponding element is the context and untranslated string separated by the EOT character ([code]U+0004[/code]). This is done for compatibility purposes.
[codeblock]
for key in translation.get_message_list():
	var p = key.find("\u0004")
	if p == -1:
		var untranslated = key
		print("Message %s" % untranslated)
	else:
		var context = key.substr(0, p)
		var untranslated = key.substr(p + 1)
		print("Message %s with context %s" % [untranslated, context])
[/codeblock]

## get_plural_message :: func Translation.get_plural_message(src_message: StringName, src_plural_message: StringName, n: int, context: StringName = &"") -> StringName
Returns a message's translation involving plurals.
The number [param n] is the number or quantity of the plural object. It will be used to guide the translation system to fetch the correct plural form for the selected language.
[b]Note:[/b] Plurals are only supported in [url=https://docs.godotengine.org/en/4.7/tutorials/i18n/localization_using_gettext.html]gettext-based translations (PO)[/url], not CSV.

### src_message :: StringName

### src_plural_message :: StringName

### n :: int

### context :: StringName

## get_translated_message_list :: func Translation.get_translated_message_list() -> PackedStringArray
Returns all the translated strings.
