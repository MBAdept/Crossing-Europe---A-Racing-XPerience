# OpenXRHand :: <Native> class OpenXRHand extends Node3D
Node supporting hand and finger tracking in OpenXR.
This node enables OpenXR's hand tracking functionality. The node should be a child node of an [XROrigin3D] node, tracking will update its position to the player's tracked hand Palm joint location (the center of the middle finger's metacarpal bone). This node also updates the skeleton of a properly skinned hand or avatar model.
If the skeleton is a hand (one of the hand bones is the root node of the skeleton), then the skeleton will be placed relative to the hand palm location and the hand mesh and skeleton should be children of the OpenXRHand node.
If the hand bones are part of a full skeleton, then the root of the hand will keep its location with the assumption that IK is used to position the hand and arm.
By default the skeleton hand bones are repositioned to match the size of the tracked hand. To preserve the modeled bone sizes change [member bone_update] to apply rotation only.

## HAND_LEFT :: const OpenXRHand.HAND_LEFT: Hands = 0
Tracking the player's left hand.

## HAND_RIGHT :: const OpenXRHand.HAND_RIGHT: Hands = 1
Tracking the player's right hand.

## HAND_MAX :: const OpenXRHand.HAND_MAX: Hands = 2
Maximum supported hands.

## MOTION_RANGE_UNOBSTRUCTED :: const OpenXRHand.MOTION_RANGE_UNOBSTRUCTED: MotionRange = 0
When player grips, hand skeleton will form a full fist.

## MOTION_RANGE_CONFORM_TO_CONTROLLER :: const OpenXRHand.MOTION_RANGE_CONFORM_TO_CONTROLLER: MotionRange = 1
When player grips, hand skeleton conforms to the controller the player is holding.

## MOTION_RANGE_MAX :: const OpenXRHand.MOTION_RANGE_MAX: MotionRange = 2
Maximum supported motion ranges.

## SKELETON_RIG_OPENXR :: const OpenXRHand.SKELETON_RIG_OPENXR: SkeletonRig = 0
An OpenXR compliant skeleton.

## SKELETON_RIG_HUMANOID :: const OpenXRHand.SKELETON_RIG_HUMANOID: SkeletonRig = 1
A [SkeletonProfileHumanoid] compliant skeleton.

## SKELETON_RIG_MAX :: const OpenXRHand.SKELETON_RIG_MAX: SkeletonRig = 2
Maximum supported hands.

## BONE_UPDATE_FULL :: const OpenXRHand.BONE_UPDATE_FULL: BoneUpdate = 0
The skeletons bones are fully updated (both position and rotation) to match the tracked bones.

## BONE_UPDATE_ROTATION_ONLY :: const OpenXRHand.BONE_UPDATE_ROTATION_ONLY: BoneUpdate = 1
The skeletons bones are only rotated to align with the tracked bones, preserving bone length.

## BONE_UPDATE_MAX :: const OpenXRHand.BONE_UPDATE_MAX: BoneUpdate = 2
Maximum supported bone update mode.

## bone_update :: var OpenXRHand.bone_update: OpenXRHand.BoneUpdate
Specify the type of updates to perform on the bone.

## hand :: var OpenXRHand.hand: OpenXRHand.Hands
Specifies whether this node tracks the left or right hand of the player.

## hand_skeleton :: var OpenXRHand.hand_skeleton: NodePath
Set a [Skeleton3D] node for which the pose positions will be updated.

## motion_range :: var OpenXRHand.motion_range: OpenXRHand.MotionRange
Set the motion range (if supported) limiting the hand motion.

## skeleton_rig :: var OpenXRHand.skeleton_rig: OpenXRHand.SkeletonRig
Set the type of skeleton rig the [member hand_skeleton] is compliant with.
