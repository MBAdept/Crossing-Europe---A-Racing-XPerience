# ButtonGroup :: <Native> class ButtonGroup extends Resource
A group of buttons that doesn't allow more than one button to be pressed at a time.
A group of [BaseButton]-derived buttons. The buttons in a [ButtonGroup] are treated like radio buttons: No more than one button can be pressed at a time. Some types of buttons (such as [CheckBox]) may have a special appearance in this state.
Every member of a [ButtonGroup] should have [member BaseButton.toggle_mode] set to [code]true[/code].

## allow_unpress :: var ButtonGroup.allow_unpress: bool
If [code]true[/code], it is possible to unpress all buttons in this [ButtonGroup].

## resource_local_to_scene :: var ButtonGroup.resource_local_to_scene: bool

## get_buttons :: func ButtonGroup.get_buttons() -> BaseButton[]
Returns an [Array] of [Button]s who have this as their [ButtonGroup] (see [member BaseButton.button_group]).

## get_pressed_button :: func ButtonGroup.get_pressed_button() -> BaseButton
Returns the current pressed button.

## pressed :: func ButtonGroup.pressed(button: BaseButton) -> void
Emitted when one of the buttons of the group is pressed.

### button :: BaseButton
