# GDScriptSyntaxHighlighter :: <Native> class GDScriptSyntaxHighlighter extends EditorSyntaxHighlighter
A GDScript syntax highlighter that can be used with [TextEdit] and [CodeEdit] nodes.
[b]Note:[/b] This class can only be used for editor plugins because it relies on editor settings.
[codeblocks]
[gdscript]
var code_preview = TextEdit.new()
var highlighter = GDScriptSyntaxHighlighter.new()
code_preview.syntax_highlighter = highlighter
[/gdscript]
[csharp]
var codePreview = new TextEdit();
var highlighter = new GDScriptSyntaxHighlighter();
codePreview.SyntaxHighlighter = highlighter;
[/csharp]
[/codeblocks]
