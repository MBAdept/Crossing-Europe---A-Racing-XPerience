# Texture :: <Native> class Texture extends Resource
Base class for all texture types.
[Texture] is the base class for all texture types. Common texture types are [Texture2D] and [ImageTexture]. See also [Image].
