# VideoStreamTheora :: <Native> class VideoStreamTheora extends VideoStream
[VideoStream] resource for Ogg Theora videos.
[VideoStream] resource handling the [url=https://www.theora.org/]Ogg Theora[/url] video format with [code].ogv[/code] extension. The Theora codec is decoded on the CPU.
[b]Note:[/b] While Ogg Theora videos can also have a [code].ogg[/code] extension, you will have to rename the extension to [code].ogv[/code] to use those videos within Godot.
