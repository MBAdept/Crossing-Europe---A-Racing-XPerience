# VisualShaderNodeVectorOp :: <Native> class VisualShaderNodeVectorOp extends VisualShaderNodeVectorBase
A vector operator to be used within the visual shader graph.
A visual shader node for use of vector operators. Operates on vector [code]a[/code] and vector [code]b[/code].

## OP_ADD :: const VisualShaderNodeVectorOp.OP_ADD: Operator = 0
Adds two vectors.

## OP_SUB :: const VisualShaderNodeVectorOp.OP_SUB: Operator = 1
Subtracts a vector from a vector.

## OP_MUL :: const VisualShaderNodeVectorOp.OP_MUL: Operator = 2
Multiplies two vectors.

## OP_DIV :: const VisualShaderNodeVectorOp.OP_DIV: Operator = 3
Divides vector by vector.

## OP_MOD :: const VisualShaderNodeVectorOp.OP_MOD: Operator = 4
Returns the remainder of the two vectors.

## OP_POW :: const VisualShaderNodeVectorOp.OP_POW: Operator = 5
Returns the value of the first parameter raised to the power of the second, for each component of the vectors.

## OP_MAX :: const VisualShaderNodeVectorOp.OP_MAX: Operator = 6
Returns the greater of two values, for each component of the vectors.

## OP_MIN :: const VisualShaderNodeVectorOp.OP_MIN: Operator = 7
Returns the lesser of two values, for each component of the vectors.

## OP_CROSS :: const VisualShaderNodeVectorOp.OP_CROSS: Operator = 8
Calculates the cross product of two vectors.

## OP_ATAN2 :: const VisualShaderNodeVectorOp.OP_ATAN2: Operator = 9
Returns the arc-tangent of the parameters.

## OP_REFLECT :: const VisualShaderNodeVectorOp.OP_REFLECT: Operator = 10
Returns the vector that points in the direction of reflection. [code]a[/code] is incident vector and [code]b[/code] is the normal vector.

## OP_STEP :: const VisualShaderNodeVectorOp.OP_STEP: Operator = 11
Vector step operator. Returns [code]0.0[/code] if [code]a[/code] is smaller than [code]b[/code] and [code]1.0[/code] otherwise.

## OP_ENUM_SIZE :: const VisualShaderNodeVectorOp.OP_ENUM_SIZE: Operator = 12
Represents the size of the [enum Operator] enum.

## operator :: var VisualShaderNodeVectorOp.operator: VisualShaderNodeVectorOp.Operator
The operator to be used.
