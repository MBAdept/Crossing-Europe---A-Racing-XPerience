# PathFollow3D :: <Native> class PathFollow3D extends Node3D
Point sampler for a [Path3D].
This node takes its parent [Path3D], and returns the coordinates of a point within it, given a distance from the first vertex.
It is useful for making other nodes follow a path, without coding the movement pattern. For that, the nodes must be children of this node. The descendant nodes will then move accordingly when setting the [member progress] in this node.

## ROTATION_NONE :: const PathFollow3D.ROTATION_NONE: RotationMode = 0
Forbids the PathFollow3D to rotate.

## ROTATION_Y :: const PathFollow3D.ROTATION_Y: RotationMode = 1
Allows the PathFollow3D to rotate in the Y axis only.

## ROTATION_XY :: const PathFollow3D.ROTATION_XY: RotationMode = 2
Allows the PathFollow3D to rotate in both the X, and Y axes.

## ROTATION_XYZ :: const PathFollow3D.ROTATION_XYZ: RotationMode = 3
Allows the PathFollow3D to rotate in any axis.

## ROTATION_ORIENTED :: const PathFollow3D.ROTATION_ORIENTED: RotationMode = 4
Uses the up vector information in a [Curve3D] to enforce orientation. This rotation mode requires the [Path3D]'s [member Curve3D.up_vector_enabled] property to be set to [code]true[/code].

## cubic_interp :: var PathFollow3D.cubic_interp: bool
If [code]true[/code], the position between two cached points is interpolated cubically, and linearly otherwise.
The points along the [Curve3D] of the [Path3D] are precomputed before use, for faster calculations. The point at the requested offset is then calculated interpolating between two adjacent cached points. This may present a problem if the curve makes sharp turns, as the cached points may not follow the curve closely enough.
There are two answers to this problem: either increase the number of cached points and increase memory consumption, or make a cubic interpolation between two points at the cost of (slightly) slower calculations.

## h_offset :: var PathFollow3D.h_offset: float
The node's offset along the curve.

## loop :: var PathFollow3D.loop: bool
If [code]true[/code], any offset outside the path's length will wrap around, instead of stopping at the ends. Use it for cyclic paths.

## progress :: var PathFollow3D.progress: float
The distance from the first vertex, measured in 3D units along the path. Changing this value sets this node's position to a point within the path.

## progress_ratio :: var PathFollow3D.progress_ratio: float
The distance from the first vertex, considering 0.0 as the first vertex and 1.0 as the last. This is just another way of expressing the progress within the path, as the progress supplied is multiplied internally by the path's length.
It can be set or get only if the [PathFollow3D] is the child of a [Path3D] which is part of the scene tree, and that this [Path3D] has a [Curve3D] with a non-zero length. Otherwise, trying to set this field will print an error, and getting this field will return [code]0.0[/code].

## rotation_mode :: var PathFollow3D.rotation_mode: PathFollow3D.RotationMode
Allows or forbids rotation on one or more axes, depending on the [enum RotationMode] constants being used.

## tilt_enabled :: var PathFollow3D.tilt_enabled: bool
If [code]true[/code], the tilt property of [Curve3D] takes effect.

## use_model_front :: var PathFollow3D.use_model_front: bool
If [code]true[/code], the node moves on the travel path with orienting the +Z axis as forward. See also [constant Vector3.FORWARD] and [constant Vector3.MODEL_FRONT].

## v_offset :: var PathFollow3D.v_offset: float
The node's offset perpendicular to the curve.

## correct_posture :: func PathFollow3D.correct_posture(transform: Transform3D, rotation_mode: int) -> Transform3D
Correct the [param transform]. [param rotation_mode] implicitly specifies how posture (forward, up and sideway direction) is calculated.

### transform :: Transform3D

### rotation_mode :: int
