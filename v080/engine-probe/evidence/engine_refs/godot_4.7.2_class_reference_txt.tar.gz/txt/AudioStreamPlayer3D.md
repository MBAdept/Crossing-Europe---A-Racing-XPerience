# AudioStreamPlayer3D :: <Native> class AudioStreamPlayer3D extends Node3D
Plays positional sound in 3D space.
Plays audio with positional sound effects, based on the relative position of the audio listener. Positional effects include distance attenuation, directionality, and the Doppler effect. For greater realism, a low-pass filter is applied to distant sounds. This can be disabled by setting [member attenuation_filter_cutoff_hz] to [code]20500[/code].
By default, audio is heard from the camera position. This can be changed by adding an [AudioListener3D] node to the scene and enabling it by calling [method AudioListener3D.make_current] on it.
See also [AudioStreamPlayer] to play a sound non-positionally.
[b]Note:[/b] Hiding an [AudioStreamPlayer3D] node does not disable its audio output. To temporarily disable an [AudioStreamPlayer3D]'s audio output, set [member volume_db] to a very low value like [code]-100[/code] (which isn't audible to human hearing).

## ATTENUATION_INVERSE_DISTANCE :: const AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE: AttenuationModel = 0
Attenuation of loudness according to linear distance.

## ATTENUATION_INVERSE_SQUARE_DISTANCE :: const AudioStreamPlayer3D.ATTENUATION_INVERSE_SQUARE_DISTANCE: AttenuationModel = 1
Attenuation of loudness according to squared distance.

## ATTENUATION_LOGARITHMIC :: const AudioStreamPlayer3D.ATTENUATION_LOGARITHMIC: AttenuationModel = 2
Attenuation of loudness according to logarithmic distance.

## ATTENUATION_DISABLED :: const AudioStreamPlayer3D.ATTENUATION_DISABLED: AttenuationModel = 3
No attenuation of loudness according to distance. The sound will still be heard positionally, unlike an [AudioStreamPlayer]. [constant ATTENUATION_DISABLED] can be combined with a [member max_distance] value greater than [code]0.0[/code] to achieve linear attenuation clamped to a sphere of a defined size.

## DOPPLER_TRACKING_DISABLED :: const AudioStreamPlayer3D.DOPPLER_TRACKING_DISABLED: DopplerTracking = 0
Disables doppler tracking.

## DOPPLER_TRACKING_IDLE_STEP :: const AudioStreamPlayer3D.DOPPLER_TRACKING_IDLE_STEP: DopplerTracking = 1
Executes doppler tracking during process frames (see [constant Node.NOTIFICATION_INTERNAL_PROCESS]).

## DOPPLER_TRACKING_PHYSICS_STEP :: const AudioStreamPlayer3D.DOPPLER_TRACKING_PHYSICS_STEP: DopplerTracking = 2
Executes doppler tracking during physics frames (see [constant Node.NOTIFICATION_INTERNAL_PHYSICS_PROCESS]).

## area_mask :: var AudioStreamPlayer3D.area_mask: int
Determines which [Area3D] layers affect the sound for reverb and audio bus effects. Areas can be used to redirect [AudioStream]s so that they play in a certain audio bus. An example of how you might use this is making a "water" area so that sounds played in the water are redirected through an audio bus to make them sound like they are being played underwater.

## attenuation_filter_cutoff_hz :: var AudioStreamPlayer3D.attenuation_filter_cutoff_hz: float
The cutoff frequency of the attenuation low-pass filter, in Hz. A sound above this frequency is attenuated more than a sound below this frequency. To disable this effect, set this to [code]20500[/code] as this frequency is above the human hearing limit.

## attenuation_filter_db :: var AudioStreamPlayer3D.attenuation_filter_db: float
Amount how much the filter affects the loudness, in decibels.

## attenuation_model :: var AudioStreamPlayer3D.attenuation_model: AudioStreamPlayer3D.AttenuationModel
Decides if audio should get quieter with distance linearly, quadratically, logarithmically, or not be affected by distance, effectively disabling attenuation.

## autoplay :: var AudioStreamPlayer3D.autoplay: bool
If [code]true[/code], audio plays when the AudioStreamPlayer3D node is added to scene tree.

## bus :: var AudioStreamPlayer3D.bus: StringName
The bus on which this audio is playing.
[b]Note:[/b] When setting this property, keep in mind that no validation is performed to see if the given name matches an existing bus. This is because audio bus layouts might be loaded after this property is set. If this given name can't be resolved at runtime, it will fall back to [code]"Master"[/code].

## doppler_tracking :: var AudioStreamPlayer3D.doppler_tracking: AudioStreamPlayer3D.DopplerTracking
Decides in which step the Doppler effect should be calculated.
[b]Note:[/b] If [member doppler_tracking] is not [constant DOPPLER_TRACKING_DISABLED] but the current [Camera3D]/[AudioListener3D] has doppler tracking disabled, the Doppler effect will be heard but will not take the movement of the current listener into account. If accurate Doppler effect is desired, doppler tracking should be enabled on both the [AudioStreamPlayer3D] and the current [Camera3D]/[AudioListener3D].

## emission_angle_degrees :: var AudioStreamPlayer3D.emission_angle_degrees: float
The angle in which the audio reaches a listener unattenuated.

## emission_angle_enabled :: var AudioStreamPlayer3D.emission_angle_enabled: bool
If [code]true[/code], the audio should be attenuated according to the direction of the sound.

## emission_angle_filter_attenuation_db :: var AudioStreamPlayer3D.emission_angle_filter_attenuation_db: float
Attenuation factor used if listener is outside of [member emission_angle_degrees] and [member emission_angle_enabled] is set, in decibels.

## max_db :: var AudioStreamPlayer3D.max_db: float
Sets the absolute maximum of the sound level, in decibels.

## max_distance :: var AudioStreamPlayer3D.max_distance: float
The distance past which the sound can no longer be heard at all. Only has an effect if set to a value greater than [code]0.0[/code]. [member max_distance] works in tandem with [member unit_size]. However, unlike [member unit_size] whose behavior depends on the [member attenuation_model], [member max_distance] always works in a linear fashion. This can be used to prevent the [AudioStreamPlayer3D] from requiring audio mixing when the listener is far away, which saves CPU resources.

## max_polyphony :: var AudioStreamPlayer3D.max_polyphony: int
The maximum number of sounds this node can play at the same time. Playing additional sounds after this value is reached will cut off the oldest sounds.

## panning_strength :: var AudioStreamPlayer3D.panning_strength: float
Scales the panning strength for this node by multiplying the base [member ProjectSettings.audio/general/3d_panning_strength] by this factor. If the product is [code]0.0[/code] then stereo panning is disabled and the volume is the same for all channels. If the product is [code]1.0[/code] then one of the channels will be muted when the sound is located exactly to the left (or right) of the listener.
Two speaker stereo arrangements implement the [url=https://webaudio.github.io/web-audio-api/#stereopanner-algorithm]WebAudio standard for StereoPannerNode Panning[/url] where the volume is cosine of half the azimuth angle to the ear.
For other speaker arrangements such as the 5.1 and 7.1 the SPCAP (Speaker-Placement Correction Amplitude) algorithm is implemented.

## pitch_scale :: var AudioStreamPlayer3D.pitch_scale: float
The pitch and the tempo of the audio, as a multiplier of the audio sample's sample rate.

## playback_type :: var AudioStreamPlayer3D.playback_type: AudioServer.PlaybackType
The playback type of the stream player. If set other than to the default value, it will force that playback type.

## playing :: var AudioStreamPlayer3D.playing: bool
If [code]true[/code], audio is playing or is queued to be played (see [method play]).

## stream :: var AudioStreamPlayer3D.stream: AudioStream
The [AudioStream] resource to be played.

## stream_paused :: var AudioStreamPlayer3D.stream_paused: bool
If [code]true[/code], the playback is paused. You can resume it by setting [member stream_paused] to [code]false[/code].

## unit_size :: var AudioStreamPlayer3D.unit_size: float
The factor for the attenuation effect. Higher values make the sound audible over a larger distance.

## volume_db :: var AudioStreamPlayer3D.volume_db: float
The base sound level before attenuation, in decibels.

## volume_linear :: var AudioStreamPlayer3D.volume_linear: float
The base sound level before attenuation, as a linear value.
[b]Note:[/b] This member modifies [member volume_db] for convenience. The returned value is equivalent to the result of [method @GlobalScope.db_to_linear] on [member volume_db]. Setting this member is equivalent to setting [member volume_db] to the result of [method @GlobalScope.linear_to_db] on a value.

## get_playback_position :: func AudioStreamPlayer3D.get_playback_position() -> float
Returns the position in the [AudioStream].

## get_stream_playback :: func AudioStreamPlayer3D.get_stream_playback() -> AudioStreamPlayback
Returns the [AudioStreamPlayback] object associated with this [AudioStreamPlayer3D].

## has_stream_playback :: func AudioStreamPlayer3D.has_stream_playback() -> bool
Returns whether the [AudioStreamPlayer] can return the [AudioStreamPlayback] object or not.

## play :: func AudioStreamPlayer3D.play(from_position: float = 0.0) -> void
Queues the audio to play on the next physics frame, from the given position [param from_position], in seconds.

### from_position :: float

## seek :: func AudioStreamPlayer3D.seek(to_position: float) -> void
Sets the position from which audio will be played, in seconds.

### to_position :: float

## stop :: func AudioStreamPlayer3D.stop() -> void
Stops the audio.

## finished :: func AudioStreamPlayer3D.finished() -> void
Emitted when the audio stops playing.
