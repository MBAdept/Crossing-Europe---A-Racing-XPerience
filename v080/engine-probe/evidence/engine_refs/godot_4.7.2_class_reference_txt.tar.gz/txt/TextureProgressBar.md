# TextureProgressBar :: <Native> class TextureProgressBar extends Range
Texture-based progress bar. Useful for loading screens and life or stamina bars.
TextureProgressBar works like [ProgressBar], but uses up to 3 textures instead of Godot's [Theme] resource. It can be used to create horizontal, vertical and radial progress bars.

## FILL_LEFT_TO_RIGHT :: const TextureProgressBar.FILL_LEFT_TO_RIGHT: FillMode = 0
The [member texture_progress] fills from left to right.

## FILL_RIGHT_TO_LEFT :: const TextureProgressBar.FILL_RIGHT_TO_LEFT: FillMode = 1
The [member texture_progress] fills from right to left.

## FILL_TOP_TO_BOTTOM :: const TextureProgressBar.FILL_TOP_TO_BOTTOM: FillMode = 2
The [member texture_progress] fills from top to bottom.

## FILL_BOTTOM_TO_TOP :: const TextureProgressBar.FILL_BOTTOM_TO_TOP: FillMode = 3
The [member texture_progress] fills from bottom to top.

## FILL_CLOCKWISE :: const TextureProgressBar.FILL_CLOCKWISE: FillMode = 4
Turns the node into a radial bar. The [member texture_progress] fills clockwise. See [member radial_center_offset], [member radial_initial_angle] and [member radial_fill_degrees] to control the way the bar fills up.

## FILL_COUNTER_CLOCKWISE :: const TextureProgressBar.FILL_COUNTER_CLOCKWISE: FillMode = 5
Turns the node into a radial bar. The [member texture_progress] fills counterclockwise. See [member radial_center_offset], [member radial_initial_angle] and [member radial_fill_degrees] to control the way the bar fills up.

## FILL_BILINEAR_LEFT_AND_RIGHT :: const TextureProgressBar.FILL_BILINEAR_LEFT_AND_RIGHT: FillMode = 6
The [member texture_progress] fills from the center, expanding both towards the left and the right.

## FILL_BILINEAR_TOP_AND_BOTTOM :: const TextureProgressBar.FILL_BILINEAR_TOP_AND_BOTTOM: FillMode = 7
The [member texture_progress] fills from the center, expanding both towards the top and the bottom.

## FILL_CLOCKWISE_AND_COUNTER_CLOCKWISE :: const TextureProgressBar.FILL_CLOCKWISE_AND_COUNTER_CLOCKWISE: FillMode = 8
Turns the node into a radial bar. The [member texture_progress] fills radially from the center, expanding both clockwise and counterclockwise. See [member radial_center_offset], [member radial_initial_angle] and [member radial_fill_degrees] to control the way the bar fills up.

## fill_mode :: var TextureProgressBar.fill_mode: int
The fill direction. See [enum FillMode] for possible values.

## mouse_filter :: var TextureProgressBar.mouse_filter: Control.MouseFilter

## nine_patch_stretch :: var TextureProgressBar.nine_patch_stretch: bool
If [code]true[/code], Godot treats the bar's textures like in [NinePatchRect]. Use the [code]stretch_margin_*[/code] properties like [member stretch_margin_bottom] to set up the nine patch's 3×3 grid. When using a radial [member fill_mode], this setting will only enable stretching for [member texture_progress], while [member texture_under] and [member texture_over] will be treated like in [NinePatchRect].

## radial_center_offset :: var TextureProgressBar.radial_center_offset: Vector2
Offsets [member texture_progress] if [member fill_mode] is [constant FILL_CLOCKWISE], [constant FILL_COUNTER_CLOCKWISE], or [constant FILL_CLOCKWISE_AND_COUNTER_CLOCKWISE].
[b]Note:[/b] The effective radial center always stays within the [member texture_progress] bounds. If you need to move it outside the texture's bounds, modify the [member texture_progress] to contain additional empty space where needed.

## radial_fill_degrees :: var TextureProgressBar.radial_fill_degrees: float
Upper limit for the fill of [member texture_progress] if [member fill_mode] is [constant FILL_CLOCKWISE], [constant FILL_COUNTER_CLOCKWISE], or [constant FILL_CLOCKWISE_AND_COUNTER_CLOCKWISE]. When the node's [code]value[/code] is equal to its [code]max_value[/code], the texture fills up to this angle.
See [member Range.value], [member Range.max_value].

## radial_initial_angle :: var TextureProgressBar.radial_initial_angle: float
Starting angle for the fill of [member texture_progress] if [member fill_mode] is [constant FILL_CLOCKWISE], [constant FILL_COUNTER_CLOCKWISE], or [constant FILL_CLOCKWISE_AND_COUNTER_CLOCKWISE]. When the node's [code]value[/code] is equal to its [code]min_value[/code], the texture doesn't show up at all. When the [code]value[/code] increases, the texture fills and tends towards [member radial_fill_degrees].
[b]Note:[/b] [member radial_initial_angle] is wrapped between [code]0[/code] and [code]360[/code] degrees (inclusive).

## size_flags_vertical :: var TextureProgressBar.size_flags_vertical: Control.SizeFlags

## step :: var TextureProgressBar.step: float

## stretch_margin_bottom :: var TextureProgressBar.stretch_margin_bottom: int
The height of the 9-patch's bottom row. A margin of 16 means the 9-slice's bottom corners and side will have a height of 16 pixels. You can set all 4 margin values individually to create panels with non-uniform borders. Only effective if [member nine_patch_stretch] is [code]true[/code].

## stretch_margin_left :: var TextureProgressBar.stretch_margin_left: int
The width of the 9-patch's left column. Only effective if [member nine_patch_stretch] is [code]true[/code].

## stretch_margin_right :: var TextureProgressBar.stretch_margin_right: int
The width of the 9-patch's right column. Only effective if [member nine_patch_stretch] is [code]true[/code].

## stretch_margin_top :: var TextureProgressBar.stretch_margin_top: int
The height of the 9-patch's top row. Only effective if [member nine_patch_stretch] is [code]true[/code].

## texture_over :: var TextureProgressBar.texture_over: Texture2D
[Texture2D] that draws over the progress bar. Use it to add highlights or an upper-frame that hides part of [member texture_progress].

## texture_progress :: var TextureProgressBar.texture_progress: Texture2D
[Texture2D] that clips based on the node's [code]value[/code] and [member fill_mode]. As [code]value[/code] increased, the texture fills up. It shows entirely when [code]value[/code] reaches [code]max_value[/code]. It doesn't show at all if [code]value[/code] is equal to [code]min_value[/code].
The [code]value[/code] property comes from [Range]. See [member Range.value], [member Range.min_value], [member Range.max_value].

## texture_progress_offset :: var TextureProgressBar.texture_progress_offset: Vector2
The offset of [member texture_progress]. Useful for [member texture_over] and [member texture_under] with fancy borders, to avoid transparent margins in your progress texture.

## texture_under :: var TextureProgressBar.texture_under: Texture2D
[Texture2D] that draws under the progress bar. The bar's background.

## tint_over :: var TextureProgressBar.tint_over: Color
Multiplies the color of the bar's [member texture_over] texture. The effect is similar to [member CanvasItem.modulate], except it only affects this specific texture instead of the entire node.

## tint_progress :: var TextureProgressBar.tint_progress: Color
Multiplies the color of the bar's [member texture_progress] texture.

## tint_under :: var TextureProgressBar.tint_under: Color
Multiplies the color of the bar's [member texture_under] texture.

## get_stretch_margin :: func TextureProgressBar.get_stretch_margin(margin: int) -> int
Returns the stretch margin with the specified index. See [member stretch_margin_bottom] and related properties.

### margin :: int

## set_stretch_margin :: func TextureProgressBar.set_stretch_margin(margin: int, value: int) -> void
Sets the stretch margin with the specified index. See [member stretch_margin_bottom] and related properties.

### margin :: int

### value :: int
