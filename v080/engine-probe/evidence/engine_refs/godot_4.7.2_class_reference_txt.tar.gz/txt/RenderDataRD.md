# RenderDataRD :: <Native> class RenderDataRD extends RenderData
Render data implementation for the RenderingDevice based renderers.
This object manages all render data for the [RenderingDevice]-based renderers. See also [RenderData], [RenderSceneData], and [RenderSceneDataRD].
[b]Note:[/b] This is an internal rendering server object. Do not instantiate this class from a script.
