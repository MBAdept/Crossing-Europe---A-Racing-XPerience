# EditorSelection :: <Native> class EditorSelection extends Object
Manages the SceneTree selection in the editor.
This object manages the SceneTree selection in the editor.
[b]Note:[/b] This class shouldn't be instantiated directly. Instead, access the singleton using [method EditorInterface.get_selection].

## add_node :: func EditorSelection.add_node(node: Node) -> void
Adds a node to the selection.
[b]Note:[/b] The newly selected node will not be automatically edited in the inspector. If you want to edit a node, use [method EditorInterface.edit_node].

### node :: Node

## clear :: func EditorSelection.clear() -> void
Clear the selection.

## get_selected_nodes :: func EditorSelection.get_selected_nodes() -> Node[]
Returns the list of selected nodes.

## get_top_selected_nodes :: func EditorSelection.get_top_selected_nodes() -> Node[]
Returns the list of top selected nodes only, excluding any children. This is useful for performing transform operations (moving them, rotating, etc.).
For example, if there is a node A with a child B and a sibling C, then selecting all three will cause this method to return only A and C. Changing the global transform of A will affect the global transform of B, so there is no need to change B separately.

## get_transformable_selected_nodes :: func EditorSelection.get_transformable_selected_nodes() -> Node[]
Returns the list of top selected nodes only, excluding any children. This is useful for performing transform operations (moving them, rotating, etc.). See [method get_top_selected_nodes].

## remove_node :: func EditorSelection.remove_node(node: Node) -> void
Removes a node from the selection.

### node :: Node

## selection_changed :: func EditorSelection.selection_changed() -> void
Emitted when the selection changes.
