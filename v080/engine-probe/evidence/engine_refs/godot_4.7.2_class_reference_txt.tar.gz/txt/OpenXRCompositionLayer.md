# OpenXRCompositionLayer :: <Native> class OpenXRCompositionLayer extends Node3D
The parent class of all OpenXR composition layer nodes.
Composition layers allow 2D viewports to be displayed inside of the headset by the XR compositor through special projections that retain their quality. This allows for rendering clear text while keeping the layer at a native resolution.
[b]Note:[/b] If the OpenXR runtime doesn't support the given composition layer type, a fallback mesh can be generated with a [ViewportTexture], in order to emulate the composition layer.

## FILTER_NEAREST :: const OpenXRCompositionLayer.FILTER_NEAREST: Filter = 0
Perform nearest-neighbor filtering when sampling the texture.

## FILTER_LINEAR :: const OpenXRCompositionLayer.FILTER_LINEAR: Filter = 1
Perform linear filtering when sampling the texture.

## FILTER_CUBIC :: const OpenXRCompositionLayer.FILTER_CUBIC: Filter = 2
Perform cubic filtering when sampling the texture.

## MIPMAP_MODE_DISABLED :: const OpenXRCompositionLayer.MIPMAP_MODE_DISABLED: MipmapMode = 0
Disable mipmapping.
[b]Note:[/b] Mipmapping can only be disabled in the Compatibility renderer.

## MIPMAP_MODE_NEAREST :: const OpenXRCompositionLayer.MIPMAP_MODE_NEAREST: MipmapMode = 1
Use the mipmap of the nearest resolution.

## MIPMAP_MODE_LINEAR :: const OpenXRCompositionLayer.MIPMAP_MODE_LINEAR: MipmapMode = 2
Use linear interpolation of the two mipmaps of the nearest resolution.

## WRAP_CLAMP_TO_BORDER :: const OpenXRCompositionLayer.WRAP_CLAMP_TO_BORDER: Wrap = 0
Clamp the texture to its specified border color.

## WRAP_CLAMP_TO_EDGE :: const OpenXRCompositionLayer.WRAP_CLAMP_TO_EDGE: Wrap = 1
Clamp the texture to its edge color.

## WRAP_REPEAT :: const OpenXRCompositionLayer.WRAP_REPEAT: Wrap = 2
Repeat the texture infinitely.

## WRAP_MIRRORED_REPEAT :: const OpenXRCompositionLayer.WRAP_MIRRORED_REPEAT: Wrap = 3
Repeat the texture infinitely, mirroring it on each repeat.

## WRAP_MIRROR_CLAMP_TO_EDGE :: const OpenXRCompositionLayer.WRAP_MIRROR_CLAMP_TO_EDGE: Wrap = 4
Mirror the texture once and then clamp the texture to its edge color.
[b]Note:[/b] This wrap mode is not available in the Compatibility renderer.

## SWIZZLE_RED :: const OpenXRCompositionLayer.SWIZZLE_RED: Swizzle = 0
Maps a color channel to the value of the red channel.

## SWIZZLE_GREEN :: const OpenXRCompositionLayer.SWIZZLE_GREEN: Swizzle = 1
Maps a color channel to the value of the green channel.

## SWIZZLE_BLUE :: const OpenXRCompositionLayer.SWIZZLE_BLUE: Swizzle = 2
Maps a color channel to the value of the blue channel.

## SWIZZLE_ALPHA :: const OpenXRCompositionLayer.SWIZZLE_ALPHA: Swizzle = 3
Maps a color channel to the value of the alpha channel.

## SWIZZLE_ZERO :: const OpenXRCompositionLayer.SWIZZLE_ZERO: Swizzle = 4
Maps a color channel to the value of zero.

## SWIZZLE_ONE :: const OpenXRCompositionLayer.SWIZZLE_ONE: Swizzle = 5
Maps a color channel to the value of one.

## EYE_VISIBILITY_BOTH :: const OpenXRCompositionLayer.EYE_VISIBILITY_BOTH: EyeVisibility = 0
The layer is visible to both the left and right eyes.

## EYE_VISIBILITY_LEFT :: const OpenXRCompositionLayer.EYE_VISIBILITY_LEFT: EyeVisibility = 1
The layer is visible only to the left eye.

## EYE_VISIBILITY_RIGHT :: const OpenXRCompositionLayer.EYE_VISIBILITY_RIGHT: EyeVisibility = 2
The layer is visible only to the right eye.

## alpha_blend :: var OpenXRCompositionLayer.alpha_blend: bool
Enables the blending the layer using its alpha channel.
Can be combined with [member Viewport.transparent_bg] to give the layer a transparent background.

## android_surface_size :: var OpenXRCompositionLayer.android_surface_size: Vector2i
The size of the Android surface to create if [member use_android_surface] is enabled.

## enable_hole_punch :: var OpenXRCompositionLayer.enable_hole_punch: bool
Enables a technique called "hole punching", which allows putting the composition layer behind the main projection layer (i.e. setting [member sort_order] to a negative value) while "punching a hole" through everything rendered by Godot so that the layer is still visible.
This can be used to create the illusion that the composition layer exists in the same 3D space as everything rendered by Godot, allowing objects to appear to pass both behind or in front of the composition layer.

## eye_visibility :: var OpenXRCompositionLayer.eye_visibility: OpenXRCompositionLayer.EyeVisibility
The eye(s) the composition layer is visible to.
[b]Note:[/b] Not all composition layer types or runtimes support restricting visibility to a single eye.

## layer_viewport :: var OpenXRCompositionLayer.layer_viewport: SubViewport
The [SubViewport] to render on the composition layer.

## protected_content :: var OpenXRCompositionLayer.protected_content: bool
If enabled, the OpenXR swapchain will be created with the [code]XR_SWAPCHAIN_CREATE_PROTECTED_CONTENT_BIT[/code] flag, which will protect its contents from CPU access.
When used with an Android Surface, this may allow DRM content to be presented, and will only take effect when the Surface is first created; later changes to this property will have no effect.

## sort_order :: var OpenXRCompositionLayer.sort_order: int
The sort order for this composition layer. Higher numbers will be shown in front of lower numbers.
[b]Note:[/b] This will have no effect if a fallback mesh is being used.

## swapchain_state_alpha_swizzle :: var OpenXRCompositionLayer.swapchain_state_alpha_swizzle: OpenXRCompositionLayer.Swizzle
The swizzle value for the alpha channel of the swapchain state.
[b]Note:[/b] This property only has an effect on devices that support the OpenXR XR_FB_swapchain_update_state OpenGLES/Vulkan extensions.

## swapchain_state_blue_swizzle :: var OpenXRCompositionLayer.swapchain_state_blue_swizzle: OpenXRCompositionLayer.Swizzle
The swizzle value for the blue channel of the swapchain state.
[b]Note:[/b] This property only has an effect on devices that support the OpenXR XR_FB_swapchain_update_state OpenGLES/Vulkan extensions.

## swapchain_state_border_color :: var OpenXRCompositionLayer.swapchain_state_border_color: Color
The border color of the swapchain state that is used when the wrap mode clamps to the border.
[b]Note:[/b] This property only has an effect on devices that support the OpenXR XR_FB_swapchain_update_state OpenGLES/Vulkan extensions.

## swapchain_state_green_swizzle :: var OpenXRCompositionLayer.swapchain_state_green_swizzle: OpenXRCompositionLayer.Swizzle
The swizzle value for the green channel of the swapchain state.
[b]Note:[/b] This property only has an effect on devices that support the OpenXR XR_FB_swapchain_update_state OpenGLES/Vulkan extensions.

## swapchain_state_horizontal_wrap :: var OpenXRCompositionLayer.swapchain_state_horizontal_wrap: OpenXRCompositionLayer.Wrap
The horizontal wrap mode of the swapchain state.
[b]Note:[/b] This property only has an effect on devices that support the OpenXR XR_FB_swapchain_update_state OpenGLES/Vulkan extensions.

## swapchain_state_mag_filter :: var OpenXRCompositionLayer.swapchain_state_mag_filter: OpenXRCompositionLayer.Filter
The magnification filter of the swapchain state.
[b]Note:[/b] This property only has an effect on devices that support the OpenXR XR_FB_swapchain_update_state OpenGLES/Vulkan extensions.

## swapchain_state_max_anisotropy :: var OpenXRCompositionLayer.swapchain_state_max_anisotropy: float
The max anisotropy of the swapchain state.
[b]Note:[/b] This property only has an effect on devices that support the OpenXR XR_FB_swapchain_update_state OpenGLES/Vulkan extensions.

## swapchain_state_min_filter :: var OpenXRCompositionLayer.swapchain_state_min_filter: OpenXRCompositionLayer.Filter
The minification filter of the swapchain state.
[b]Note:[/b] This property only has an effect on devices that support the OpenXR XR_FB_swapchain_update_state OpenGLES/Vulkan extensions.

## swapchain_state_mipmap_mode :: var OpenXRCompositionLayer.swapchain_state_mipmap_mode: OpenXRCompositionLayer.MipmapMode
The mipmap mode of the swapchain state.
[b]Note:[/b] This property only has an effect on devices that support the OpenXR XR_FB_swapchain_update_state OpenGLES/Vulkan extensions.

## swapchain_state_red_swizzle :: var OpenXRCompositionLayer.swapchain_state_red_swizzle: OpenXRCompositionLayer.Swizzle
The swizzle value for the red channel of the swapchain state.
[b]Note:[/b] This property only has an effect on devices that support the OpenXR XR_FB_swapchain_update_state OpenGLES/Vulkan extensions.

## swapchain_state_vertical_wrap :: var OpenXRCompositionLayer.swapchain_state_vertical_wrap: OpenXRCompositionLayer.Wrap
The vertical wrap mode of the swapchain state.
[b]Note:[/b] This property only has an effect on devices that support the OpenXR XR_FB_swapchain_update_state OpenGLES/Vulkan extensions.

## use_android_surface :: var OpenXRCompositionLayer.use_android_surface: bool
If enabled, an Android surface will be created (with the dimensions from [member android_surface_size]) which will provide the 2D content for the composition layer, rather than using [member layer_viewport].
See [method get_android_surface] for information about how to get the surface so that your application can draw to it.
[b]Note:[/b] This will only work in Android builds.

## get_android_surface :: func OpenXRCompositionLayer.get_android_surface() -> JavaObject
Returns a [JavaObject] representing an [code]android.view.Surface[/code] if [member use_android_surface] is enabled and OpenXR has created the surface. Otherwise, this will return [code]null[/code].
[b]Note:[/b] The surface can only be created during an active OpenXR session. So, if [member use_android_surface] is enabled outside of an OpenXR session, it won't be created until a new session fully starts.

## intersects_ray :: func OpenXRCompositionLayer.intersects_ray(origin: Vector3, direction: Vector3) -> Vector2
Returns UV coordinates where the given ray intersects with the composition layer. [param origin] and [param direction] must be in global space.
Returns [code]Vector2(-1.0, -1.0)[/code] if the ray doesn't intersect.

### origin :: Vector3

### direction :: Vector3

## is_natively_supported :: func OpenXRCompositionLayer.is_natively_supported() -> bool
Returns [code]true[/code] if the OpenXR runtime natively supports this composition layer type.
[b]Note:[/b] This will only return an accurate result after the OpenXR session has started.
