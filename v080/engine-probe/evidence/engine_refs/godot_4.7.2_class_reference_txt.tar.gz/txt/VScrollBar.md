# VScrollBar :: <Native> class VScrollBar extends ScrollBar
A vertical scrollbar that goes from top (min) to bottom (max).
A vertical scrollbar, typically used to navigate through content that extends beyond the visible height of a control. It is a [Range]-based control and goes from top (min) to bottom (max). Note that this direction is the opposite of [VSlider]'s.

## size_flags_horizontal :: var VScrollBar.size_flags_horizontal: Control.SizeFlags

## size_flags_vertical :: var VScrollBar.size_flags_vertical: Control.SizeFlags

## padding_left :: <Theme> var VScrollBar.padding_left: int
Padding between the left of the [theme_item ScrollBar.scroll] element and the [theme_item ScrollBar.grabber].
[b]Note:[/b] To apply vertical padding, modify the top/bottom content margins of [theme_item ScrollBar.scroll] instead.

## padding_right :: <Theme> var VScrollBar.padding_right: int
Padding between the right of the [theme_item ScrollBar.scroll] element and the [theme_item ScrollBar.grabber].
[b]Note:[/b] To apply vertical padding, modify the top/bottom content margins of [theme_item ScrollBar.scroll] instead.
