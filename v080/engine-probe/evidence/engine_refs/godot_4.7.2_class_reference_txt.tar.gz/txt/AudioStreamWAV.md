# AudioStreamWAV :: <Native> class AudioStreamWAV extends AudioStream
Stores audio data loaded from WAV files.
AudioStreamWAV stores sound samples loaded from WAV files. To play the stored sound, use an [AudioStreamPlayer] (for non-positional audio) or [AudioStreamPlayer2D]/[AudioStreamPlayer3D] (for positional audio). The sound can be looped.
This class can also be used to store dynamically-generated PCM audio data. See also [AudioStreamGenerator] for procedural audio generation.

## FORMAT_8_BITS :: const AudioStreamWAV.FORMAT_8_BITS: Format = 0
8-bit PCM audio codec.

## FORMAT_16_BITS :: const AudioStreamWAV.FORMAT_16_BITS: Format = 1
16-bit PCM audio codec.

## FORMAT_IMA_ADPCM :: const AudioStreamWAV.FORMAT_IMA_ADPCM: Format = 2
Audio is lossily compressed as IMA ADPCM.

## FORMAT_QOA :: const AudioStreamWAV.FORMAT_QOA: Format = 3
Audio is lossily compressed as [url=https://qoaformat.org/]Quite OK Audio[/url].

## LOOP_DISABLED :: const AudioStreamWAV.LOOP_DISABLED: LoopMode = 0
Audio does not loop.

## LOOP_FORWARD :: const AudioStreamWAV.LOOP_FORWARD: LoopMode = 1
Audio loops the data between [member loop_begin] and [member loop_end], playing forward only.

## LOOP_PINGPONG :: const AudioStreamWAV.LOOP_PINGPONG: LoopMode = 2
Audio loops the data between [member loop_begin] and [member loop_end], playing back and forth.

## LOOP_BACKWARD :: const AudioStreamWAV.LOOP_BACKWARD: LoopMode = 3
Audio loops the data between [member loop_begin] and [member loop_end], playing backward only.

## data :: var AudioStreamWAV.data: PackedByteArray
Contains the audio data in bytes.
[b]Note:[/b] If [member format] is set to [constant FORMAT_8_BITS], this property expects signed 8-bit PCM data. To convert from unsigned 8-bit PCM, subtract 128 from each byte.
[b]Note:[/b] If [member format] is set to [constant FORMAT_QOA], this property expects data from a full QOA file.

## format :: var AudioStreamWAV.format: AudioStreamWAV.Format
Audio format.

## loop_begin :: var AudioStreamWAV.loop_begin: int
The loop start point (in number of samples, relative to the beginning of the stream).

## loop_end :: var AudioStreamWAV.loop_end: int
The loop end point (in number of samples, relative to the beginning of the stream).

## loop_mode :: var AudioStreamWAV.loop_mode: AudioStreamWAV.LoopMode
The loop mode.

## mix_rate :: var AudioStreamWAV.mix_rate: int
The sample rate for mixing this audio. Higher values require more storage space, but result in better quality.
In games, common sample rates in use are [code]11025[/code], [code]16000[/code], [code]22050[/code], [code]32000[/code], [code]44100[/code], and [code]48000[/code].
According to the [url=https://en.wikipedia.org/wiki/Nyquist%E2%80%93Shannon_sampling_theorem]Nyquist-Shannon sampling theorem[/url], there is no quality difference to human hearing when going past 40,000 Hz (since most humans can only hear up to ~20,000 Hz, often less). If you are using lower-pitched sounds such as voices, lower sample rates such as [code]32000[/code] or [code]22050[/code] may be usable with no loss in quality.

## stereo :: var AudioStreamWAV.stereo: bool
If [code]true[/code], audio is stereo.

## tags :: var AudioStreamWAV.tags: Dictionary
Contains user-defined tags if found in the WAV data.
Commonly used tags include [code]title[/code], [code]artist[/code], [code]album[/code], [code]tracknumber[/code], and [code]date[/code] ([code]date[/code] does not have a standard date format).
[b]Note:[/b] No tag is [i]guaranteed[/i] to be present in every file, so make sure to account for the keys not always existing.
[b]Note:[/b] Only WAV files using a [code]LIST[/code] chunk with an identifier of [code]INFO[/code] to encode the tags are currently supported.

## load_from_buffer :: func AudioStreamWAV.load_from_buffer(stream_data: PackedByteArray, options: Dictionary = {}) -> AudioStreamWAV
Creates a new [AudioStreamWAV] instance from the given buffer. The buffer must contain WAV data.
The keys and values of [param options] match the properties of [ResourceImporterWAV]. The usage of [param options] is identical to [method AudioStreamWAV.load_from_file].

### stream_data :: PackedByteArray

### options :: Dictionary

## load_from_file :: func AudioStreamWAV.load_from_file(path: String, options: Dictionary = {}) -> AudioStreamWAV
Creates a new [AudioStreamWAV] instance from the given file path. The file must be in WAV format.
The keys and values of [param options] match the properties of [ResourceImporterWAV].
[b]Example:[/b] Load the first file dropped as a WAV and play it:
[codeblock]
@onready var audio_player = $AudioStreamPlayer

func _ready():
	get_window().files_dropped.connect(_on_files_dropped)

func _on_files_dropped(files):
	if files[0].get_extension() == "wav":
		audio_player.stream = AudioStreamWAV.load_from_file(files[0], {
				"force/max_rate": true,
				"force/max_rate_hz": 11025
			})
		audio_player.play()
[/codeblock]

### path :: String

### options :: Dictionary

## save_to_wav :: func AudioStreamWAV.save_to_wav(path: String) -> int
Saves the AudioStreamWAV as a WAV file to [param path]. Samples with IMA ADPCM or Quite OK Audio formats can't be saved.
[b]Note:[/b] A [code].wav[/code] extension is automatically appended to [param path] if it is missing.

### path :: String
