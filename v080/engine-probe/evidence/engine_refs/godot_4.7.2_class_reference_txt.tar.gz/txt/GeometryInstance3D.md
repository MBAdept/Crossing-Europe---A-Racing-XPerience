# GeometryInstance3D :: <Native> class GeometryInstance3D extends VisualInstance3D
Base node for geometry-based visual instances.
Base node for geometry-based visual instances. Shares some common functionality like visibility and custom materials.

## SHADOW_CASTING_SETTING_OFF :: const GeometryInstance3D.SHADOW_CASTING_SETTING_OFF: ShadowCastingSetting = 0
Will not cast any shadows. Use this to improve performance for small geometry that is unlikely to cast noticeable shadows (such as debris).

## SHADOW_CASTING_SETTING_ON :: const GeometryInstance3D.SHADOW_CASTING_SETTING_ON: ShadowCastingSetting = 1
Will cast shadows from all visible faces in the GeometryInstance3D.
Will take culling into account, so faces not being rendered will not be taken into account when shadow casting.

## SHADOW_CASTING_SETTING_DOUBLE_SIDED :: const GeometryInstance3D.SHADOW_CASTING_SETTING_DOUBLE_SIDED: ShadowCastingSetting = 2
Will cast shadows from all visible faces in the GeometryInstance3D.
Will not take culling into account, so all faces will be taken into account when shadow casting.

## SHADOW_CASTING_SETTING_SHADOWS_ONLY :: const GeometryInstance3D.SHADOW_CASTING_SETTING_SHADOWS_ONLY: ShadowCastingSetting = 3
Will only show the shadows casted from this object.
In other words, the actual mesh will not be visible, only the shadows casted from the mesh will be.

## GI_MODE_DISABLED :: const GeometryInstance3D.GI_MODE_DISABLED: GIMode = 0
Disabled global illumination mode. Use for dynamic objects that do not contribute to global illumination (such as characters). When using [VoxelGI] and SDFGI, the geometry will [i]receive[/i] indirect lighting and reflections but the geometry will not be considered in GI baking.

## GI_MODE_STATIC :: const GeometryInstance3D.GI_MODE_STATIC: GIMode = 1
Baked global illumination mode. Use for static objects that contribute to global illumination (such as level geometry). This GI mode is effective when using [VoxelGI], SDFGI and [LightmapGI].

## GI_MODE_DYNAMIC :: const GeometryInstance3D.GI_MODE_DYNAMIC: GIMode = 2
Dynamic global illumination mode. Use for dynamic objects that contribute to global illumination. This GI mode is only effective when using [VoxelGI], but it has a higher performance impact than [constant GI_MODE_STATIC]. When using other GI methods, this will act the same as [constant GI_MODE_DISABLED]. When using [LightmapGI], the object will receive indirect lighting using lightmap probes instead of using the baked lightmap texture.

## LIGHTMAP_SCALE_1X :: const GeometryInstance3D.LIGHTMAP_SCALE_1X: LightmapScale = 0
The standard texel density for lightmapping with [LightmapGI].

## LIGHTMAP_SCALE_2X :: const GeometryInstance3D.LIGHTMAP_SCALE_2X: LightmapScale = 1
Multiplies texel density by 2× for lightmapping with [LightmapGI]. To ensure consistency in texel density, use this when scaling a mesh by a factor between 1.5 and 3.0.

## LIGHTMAP_SCALE_4X :: const GeometryInstance3D.LIGHTMAP_SCALE_4X: LightmapScale = 2
Multiplies texel density by 4× for lightmapping with [LightmapGI]. To ensure consistency in texel density, use this when scaling a mesh by a factor between 3.0 and 6.0.

## LIGHTMAP_SCALE_8X :: const GeometryInstance3D.LIGHTMAP_SCALE_8X: LightmapScale = 3
Multiplies texel density by 8× for lightmapping with [LightmapGI]. To ensure consistency in texel density, use this when scaling a mesh by a factor greater than 6.0.

## LIGHTMAP_SCALE_MAX :: const GeometryInstance3D.LIGHTMAP_SCALE_MAX: LightmapScale = 4
Represents the size of the [enum LightmapScale] enum.

## VISIBILITY_RANGE_FADE_DISABLED :: const GeometryInstance3D.VISIBILITY_RANGE_FADE_DISABLED: VisibilityRangeFadeMode = 0
Will not fade itself nor its visibility dependencies, hysteresis will be used instead. This is the fastest approach to manual LOD, but it can result in noticeable LOD transitions depending on how the LOD meshes are authored. See [member visibility_range_begin] and [member Node3D.visibility_parent] for more information.

## VISIBILITY_RANGE_FADE_SELF :: const GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF: VisibilityRangeFadeMode = 1
Will fade-out itself when reaching the limits of its own visibility range. This is slower than [constant VISIBILITY_RANGE_FADE_DISABLED], but it can provide smoother transitions. The fading range is determined by [member visibility_range_begin_margin] and [member visibility_range_end_margin].
[b]Note:[/b] Only supported when using the Forward+ rendering method. When using the Mobile or Compatibility rendering method, this mode acts like [constant VISIBILITY_RANGE_FADE_DISABLED] but with hysteresis disabled.

## VISIBILITY_RANGE_FADE_DEPENDENCIES :: const GeometryInstance3D.VISIBILITY_RANGE_FADE_DEPENDENCIES: VisibilityRangeFadeMode = 2
Will fade-in its visibility dependencies (see [member Node3D.visibility_parent]) when reaching the limits of its own visibility range. This is slower than [constant VISIBILITY_RANGE_FADE_DISABLED], but it can provide smoother transitions. The fading range is determined by [member visibility_range_begin_margin] and [member visibility_range_end_margin].
[b]Note:[/b] Only supported when using the Forward+ rendering method. When using the Mobile or Compatibility rendering method, this mode acts like [constant VISIBILITY_RANGE_FADE_DISABLED] but with hysteresis disabled.

## cast_shadow :: var GeometryInstance3D.cast_shadow: GeometryInstance3D.ShadowCastingSetting
The mode used to cast shadows from this instance.

## custom_aabb :: var GeometryInstance3D.custom_aabb: AABB
Overrides the bounding box of this node with a custom one. This can be used to avoid the expensive [AABB] recalculation that happens when a skeleton is used with a [MeshInstance3D] or to have precise control over the [MeshInstance3D]'s bounding box. To use the default AABB, set value to an [AABB] with all fields set to [code]0.0[/code]. To avoid frustum culling, set [member custom_aabb] to a very large AABB that covers your entire game world such as [code]AABB(-10000, -10000, -10000, 20000, 20000, 20000)[/code]. To disable all forms of culling (including occlusion and layer culling), call [method RenderingServer.instance_set_ignore_culling] on the [GeometryInstance3D]'s [RID].

## extra_cull_margin :: var GeometryInstance3D.extra_cull_margin: float
The extra distance added to the GeometryInstance3D's bounding box ([AABB]) to increase its cull box.

## gi_lightmap_scale :: var GeometryInstance3D.gi_lightmap_scale: GeometryInstance3D.LightmapScale
The texel density to use for lightmapping in [LightmapGI].

## gi_lightmap_texel_scale :: var GeometryInstance3D.gi_lightmap_texel_scale: float
The texel density to use for lightmapping in [LightmapGI]. Greater scale values provide higher resolution in the lightmap, which can result in sharper shadows for lights that have both direct and indirect light baked. However, greater scale values will also increase the space taken by the mesh in the lightmap texture, which increases the memory, storage, and bake time requirements. When using a single mesh at different scales, consider adjusting this value to keep the lightmap texel density consistent across meshes.
For example, doubling [member gi_lightmap_texel_scale] doubles the lightmap texture resolution for this object [i]on each axis[/i], so it will [i]quadruple[/i] the texel count.

## gi_mode :: var GeometryInstance3D.gi_mode: GeometryInstance3D.GIMode
The global illumination mode to use for the whole geometry. To avoid inconsistent results, use a mode that matches the purpose of the mesh during gameplay (static/dynamic).
[b]Note:[/b] Lights' bake mode will also affect the global illumination rendering. See [member Light3D.light_bake_mode].

## ignore_occlusion_culling :: var GeometryInstance3D.ignore_occlusion_culling: bool
If [code]true[/code], disables occlusion culling for this instance. Useful for gizmos that must be rendered even when occlusion culling is in use.
[b]Note:[/b] [member ignore_occlusion_culling] does not affect frustum culling (which is what happens when an object is not visible given the camera's angle). To avoid frustum culling, set [member custom_aabb] to a very large AABB that covers your entire game world such as [code]AABB(-10000, -10000, -10000, 20000, 20000, 20000)[/code].

## lod_bias :: var GeometryInstance3D.lod_bias: float
Changes how quickly the mesh transitions to a lower level of detail. A value of 0 will force the mesh to its lowest level of detail, a value of 1 will use the default settings, and larger values will keep the mesh in a higher level of detail at farther distances.
Useful for testing level of detail transitions in the editor.

## material_overlay :: var GeometryInstance3D.material_overlay: Material
The material overlay for the whole geometry.
If a material is assigned to this property, it will be rendered on top of any other active material for all the surfaces.

## material_override :: var GeometryInstance3D.material_override: Material
The material override for the whole geometry.
If a material is assigned to this property, it will be used instead of any material set in any material slot of the mesh.

## transparency :: var GeometryInstance3D.transparency: float
The transparency applied to the whole geometry (as a multiplier of the materials' existing transparency). [code]0.0[/code] is fully opaque, while [code]1.0[/code] is fully transparent. Values greater than [code]0.0[/code] (exclusive) will force the geometry's materials to go through the transparent pipeline, which is slower to render and can exhibit rendering issues due to incorrect transparency sorting. However, unlike using a transparent material, setting [member transparency] to a value greater than [code]0.0[/code] (exclusive) will [i]not[/i] disable shadow rendering.
In spatial shaders, [code]1.0 - transparency[/code] is set as the default value of the [code]ALPHA[/code] built-in.
[b]Note:[/b] [member transparency] is clamped between [code]0.0[/code] and [code]1.0[/code], so this property cannot be used to make transparent materials more opaque than they originally are.
[b]Note:[/b] Only supported when using the Forward+ rendering method. When using the Mobile or Compatibility rendering method, [member transparency] is ignored and is considered as always being [code]0.0[/code].

## visibility_range_begin :: var GeometryInstance3D.visibility_range_begin: float
Starting distance from which the GeometryInstance3D will be visible, taking [member visibility_range_begin_margin] into account as well. The default value of 0 is used to disable the range check.

## visibility_range_begin_margin :: var GeometryInstance3D.visibility_range_begin_margin: float
Margin for the [member visibility_range_begin] threshold. The GeometryInstance3D will only change its visibility state when it goes over or under the [member visibility_range_begin] threshold by this amount.
If [member visibility_range_fade_mode] is [constant VISIBILITY_RANGE_FADE_DISABLED], this acts as a hysteresis distance. If [member visibility_range_fade_mode] is [constant VISIBILITY_RANGE_FADE_SELF] or [constant VISIBILITY_RANGE_FADE_DEPENDENCIES], this acts as a fade transition distance and must be set to a value greater than [code]0.0[/code] for the effect to be noticeable.

## visibility_range_end :: var GeometryInstance3D.visibility_range_end: float
Distance from which the GeometryInstance3D will be hidden, taking [member visibility_range_end_margin] into account as well. The default value of 0 is used to disable the range check.

## visibility_range_end_margin :: var GeometryInstance3D.visibility_range_end_margin: float
Margin for the [member visibility_range_end] threshold. The GeometryInstance3D will only change its visibility state when it goes over or under the [member visibility_range_end] threshold by this amount.
If [member visibility_range_fade_mode] is [constant VISIBILITY_RANGE_FADE_DISABLED], this acts as a hysteresis distance. If [member visibility_range_fade_mode] is [constant VISIBILITY_RANGE_FADE_SELF] or [constant VISIBILITY_RANGE_FADE_DEPENDENCIES], this acts as a fade transition distance and must be set to a value greater than [code]0.0[/code] for the effect to be noticeable.

## visibility_range_fade_mode :: var GeometryInstance3D.visibility_range_fade_mode: GeometryInstance3D.VisibilityRangeFadeMode
Controls which instances will be faded when approaching the limits of the visibility range.

## get_instance_shader_parameter :: func GeometryInstance3D.get_instance_shader_parameter(name: StringName) -> Variant
Get the value of a shader parameter as set on this instance.

### name :: StringName

## set_instance_shader_parameter :: func GeometryInstance3D.set_instance_shader_parameter(name: StringName, value: Variant) -> void
Set the value of a shader uniform for this instance only ([url=https://docs.godotengine.org/en/4.7/tutorials/shaders/shader_reference/shading_language.html#per-instance-uniforms]per-instance uniform[/url]). See also [method ShaderMaterial.set_shader_parameter] to assign a uniform on all instances using the same [ShaderMaterial].
[b]Note:[/b] For a shader uniform to be assignable on a per-instance basis, it [i]must[/i] be defined with [code]instance uniform ...[/code] rather than [code]uniform ...[/code] in the shader code.
[b]Note:[/b] [param name] is case-sensitive and must match the name of the uniform in the code exactly (not the capitalized name in the inspector).
[b]Note:[/b] Per-instance shader uniforms are only available in Spatial and CanvasItem shaders, but not for Fog, Sky, or Particles shaders.

### name :: StringName

### value :: Variant
