# RenderingServer :: <Native> class RenderingServer extends Object
Server for anything visible.
The rendering server is the API backend for everything visible. The whole scene system mounts on it to display. The rendering server is completely opaque: the internals are entirely implementation-specific and cannot be accessed.
The rendering server can be used to bypass the scene/[Node] system entirely. This can improve performance in cases where the scene system is the bottleneck, but won't improve performance otherwise (for instance, if the GPU is already fully utilized).
Resources are created using the [code]*_create[/code] functions. These functions return [RID]s which are not references to the objects themselves, but opaque [i]pointers[/i] towards these objects.
All objects are drawn to a viewport. You can use the [Viewport] attached to the [SceneTree] or you can create one yourself with [method viewport_create]. When using a custom scenario or canvas, the scenario or canvas needs to be attached to the viewport using [method viewport_set_scenario] or [method viewport_attach_canvas].
[b]Scenarios:[/b] In 3D, all visual objects must be associated with a scenario. The scenario is a visual representation of the world. If accessing the rendering server from a running game, the scenario can be accessed from the scene tree from any [Node3D] node with [method Node3D.get_world_3d]. Otherwise, a scenario can be created with [method scenario_create].
Similarly, in 2D, a canvas is needed to draw all canvas items.
[b]3D:[/b] In 3D, all visible objects are comprised of a resource and an instance. A resource can be a mesh, a particle system, a light, or any other 3D object. In order to be visible resources must be attached to an instance using [method instance_set_base]. The instance must also be attached to the scenario using [method instance_set_scenario] in order to be visible. RenderingServer methods that don't have a prefix are usually 3D-specific (but not always).
[b]2D:[/b] In 2D, all visible objects are some form of canvas item. In order to be visible, a canvas item needs to be the child of a canvas attached to a viewport, or it needs to be the child of another canvas item that is eventually attached to the canvas. 2D-specific RenderingServer methods generally start with [code]canvas_*[/code].
[b]Headless mode:[/b] Starting the engine with the [code]--headless[/code] [url=https://docs.godotengine.org/en/4.7/tutorials/editor/command_line_tutorial.html]command line argument[/url] disables all rendering and window management functions. Most functions from [RenderingServer] will return dummy values in this case.

## NO_INDEX_ARRAY :: const RenderingServer.NO_INDEX_ARRAY = -1
Marks an error that shows that the index array is empty.

## ARRAY_WEIGHTS_SIZE :: const RenderingServer.ARRAY_WEIGHTS_SIZE = 4
Number of weights/bones per vertex.

## CANVAS_ITEM_Z_MIN :: const RenderingServer.CANVAS_ITEM_Z_MIN = -4096
The minimum Z-layer for canvas items.

## CANVAS_ITEM_Z_MAX :: const RenderingServer.CANVAS_ITEM_Z_MAX = 4096
The maximum Z-layer for canvas items.

## CANVAS_LAYER_MIN :: const RenderingServer.CANVAS_LAYER_MIN = -2147483648
The minimum canvas layer.

## CANVAS_LAYER_MAX :: const RenderingServer.CANVAS_LAYER_MAX = 2147483647
The maximum canvas layer.

## MAX_GLOW_LEVELS :: const RenderingServer.MAX_GLOW_LEVELS = 7
The maximum number of glow levels that can be used with the glow post-processing effect.

## MAX_CURSORS :: const RenderingServer.MAX_CURSORS = 8

## MAX_2D_DIRECTIONAL_LIGHTS :: const RenderingServer.MAX_2D_DIRECTIONAL_LIGHTS = 8
The maximum number of directional lights that can be rendered at a given time in 2D.

## MAX_MESH_SURFACES :: const RenderingServer.MAX_MESH_SURFACES = 256
The maximum number of surfaces a mesh can have.

## TEXTURE_TYPE_2D :: const RenderingServer.TEXTURE_TYPE_2D: TextureType = 0
2D texture.

## TEXTURE_TYPE_LAYERED :: const RenderingServer.TEXTURE_TYPE_LAYERED: TextureType = 1
Layered texture.

## TEXTURE_TYPE_3D :: const RenderingServer.TEXTURE_TYPE_3D: TextureType = 2
3D texture.

## TEXTURE_LAYERED_2D_ARRAY :: const RenderingServer.TEXTURE_LAYERED_2D_ARRAY: TextureLayeredType = 0
Array of 2-dimensional textures (see [Texture2DArray]).

## TEXTURE_LAYERED_CUBEMAP :: const RenderingServer.TEXTURE_LAYERED_CUBEMAP: TextureLayeredType = 1
Cubemap texture (see [Cubemap]).

## TEXTURE_LAYERED_CUBEMAP_ARRAY :: const RenderingServer.TEXTURE_LAYERED_CUBEMAP_ARRAY: TextureLayeredType = 2
Array of cubemap textures (see [CubemapArray]).

## CUBEMAP_LAYER_LEFT :: const RenderingServer.CUBEMAP_LAYER_LEFT: CubeMapLayer = 0
Left face of a [Cubemap].

## CUBEMAP_LAYER_RIGHT :: const RenderingServer.CUBEMAP_LAYER_RIGHT: CubeMapLayer = 1
Right face of a [Cubemap].

## CUBEMAP_LAYER_BOTTOM :: const RenderingServer.CUBEMAP_LAYER_BOTTOM: CubeMapLayer = 2
Bottom face of a [Cubemap].

## CUBEMAP_LAYER_TOP :: const RenderingServer.CUBEMAP_LAYER_TOP: CubeMapLayer = 3
Top face of a [Cubemap].

## CUBEMAP_LAYER_FRONT :: const RenderingServer.CUBEMAP_LAYER_FRONT: CubeMapLayer = 4
Front face of a [Cubemap].

## CUBEMAP_LAYER_BACK :: const RenderingServer.CUBEMAP_LAYER_BACK: CubeMapLayer = 5
Back face of a [Cubemap].

## TEXTURE_DRAWABLE_FORMAT_RGBA8 :: const RenderingServer.TEXTURE_DRAWABLE_FORMAT_RGBA8: TextureDrawableFormat = 0
OpenGL texture format RGBA with four components, each with a bitdepth of 8.

## TEXTURE_DRAWABLE_FORMAT_RGBA8_SRGB :: const RenderingServer.TEXTURE_DRAWABLE_FORMAT_RGBA8_SRGB: TextureDrawableFormat = 1
OpenGL texture format RGBA with four components, each with a bitdepth of 8.
When drawn to, an sRGB to linear color space conversion is performed.

## TEXTURE_DRAWABLE_FORMAT_RGBAH :: const RenderingServer.TEXTURE_DRAWABLE_FORMAT_RGBAH: TextureDrawableFormat = 2
OpenGL texture format GL_RGBA16F where there are four components, each a 16-bit "half-precision" floating-point value.

## TEXTURE_DRAWABLE_FORMAT_RGBAF :: const RenderingServer.TEXTURE_DRAWABLE_FORMAT_RGBAF: TextureDrawableFormat = 3
OpenGL texture format GL_RGBA32F where there are four components, each a 32-bit floating-point value.

## SHADER_SPATIAL :: const RenderingServer.SHADER_SPATIAL: ShaderMode = 0
Shader is a 3D shader.

## SHADER_CANVAS_ITEM :: const RenderingServer.SHADER_CANVAS_ITEM: ShaderMode = 1
Shader is a 2D shader.

## SHADER_PARTICLES :: const RenderingServer.SHADER_PARTICLES: ShaderMode = 2
Shader is a particle shader (can be used in both 2D and 3D).

## SHADER_SKY :: const RenderingServer.SHADER_SKY: ShaderMode = 3
Shader is a 3D sky shader.

## SHADER_FOG :: const RenderingServer.SHADER_FOG: ShaderMode = 4
Shader is a 3D fog shader.

## SHADER_TEXTURE_BLIT :: const RenderingServer.SHADER_TEXTURE_BLIT: ShaderMode = 5
Shader is a texture_blit shader.

## SHADER_MAX :: const RenderingServer.SHADER_MAX: ShaderMode = 6
Represents the size of the [enum ShaderMode] enum.

## MATERIAL_RENDER_PRIORITY_MIN :: const RenderingServer.MATERIAL_RENDER_PRIORITY_MIN = -128
The minimum renderpriority of all materials.

## MATERIAL_RENDER_PRIORITY_MAX :: const RenderingServer.MATERIAL_RENDER_PRIORITY_MAX = 127
The maximum renderpriority of all materials.

## ARRAY_VERTEX :: const RenderingServer.ARRAY_VERTEX: ArrayType = 0
Array is a vertex position array.

## ARRAY_NORMAL :: const RenderingServer.ARRAY_NORMAL: ArrayType = 1
Array is a normal array.

## ARRAY_TANGENT :: const RenderingServer.ARRAY_TANGENT: ArrayType = 2
Array is a tangent array.

## ARRAY_COLOR :: const RenderingServer.ARRAY_COLOR: ArrayType = 3
Array is a vertex color array.

## ARRAY_TEX_UV :: const RenderingServer.ARRAY_TEX_UV: ArrayType = 4
Array is a UV coordinates array.

## ARRAY_TEX_UV2 :: const RenderingServer.ARRAY_TEX_UV2: ArrayType = 5
Array is a UV coordinates array for the second set of UV coordinates.

## ARRAY_CUSTOM0 :: const RenderingServer.ARRAY_CUSTOM0: ArrayType = 6
Array is a custom data array for the first set of custom data.

## ARRAY_CUSTOM1 :: const RenderingServer.ARRAY_CUSTOM1: ArrayType = 7
Array is a custom data array for the second set of custom data.

## ARRAY_CUSTOM2 :: const RenderingServer.ARRAY_CUSTOM2: ArrayType = 8
Array is a custom data array for the third set of custom data.

## ARRAY_CUSTOM3 :: const RenderingServer.ARRAY_CUSTOM3: ArrayType = 9
Array is a custom data array for the fourth set of custom data.

## ARRAY_BONES :: const RenderingServer.ARRAY_BONES: ArrayType = 10
Array contains bone information.

## ARRAY_WEIGHTS :: const RenderingServer.ARRAY_WEIGHTS: ArrayType = 11
Array is weight information.

## ARRAY_INDEX :: const RenderingServer.ARRAY_INDEX: ArrayType = 12
Array is an index array.

## ARRAY_MAX :: const RenderingServer.ARRAY_MAX: ArrayType = 13
Represents the size of the [enum ArrayType] enum.

## ARRAY_CUSTOM_COUNT :: const RenderingServer.ARRAY_CUSTOM_COUNT = 4
The number of custom data arrays available ([constant ARRAY_CUSTOM0], [constant ARRAY_CUSTOM1], [constant ARRAY_CUSTOM2], [constant ARRAY_CUSTOM3]).

## ARRAY_CUSTOM_RGBA8_UNORM :: const RenderingServer.ARRAY_CUSTOM_RGBA8_UNORM: ArrayCustomFormat = 0
Custom data array contains 8-bit-per-channel red/green/blue/alpha color data. Values are normalized, unsigned floating-point in the [code][0.0, 1.0][/code] range.

## ARRAY_CUSTOM_RGBA8_SNORM :: const RenderingServer.ARRAY_CUSTOM_RGBA8_SNORM: ArrayCustomFormat = 1
Custom data array contains 8-bit-per-channel red/green/blue/alpha color data. Values are normalized, signed floating-point in the [code][-1.0, 1.0][/code] range.

## ARRAY_CUSTOM_RG_HALF :: const RenderingServer.ARRAY_CUSTOM_RG_HALF: ArrayCustomFormat = 2
Custom data array contains 16-bit-per-channel red/green color data. Values are floating-point in half precision.

## ARRAY_CUSTOM_RGBA_HALF :: const RenderingServer.ARRAY_CUSTOM_RGBA_HALF: ArrayCustomFormat = 3
Custom data array contains 16-bit-per-channel red/green/blue/alpha color data. Values are floating-point in half precision.

## ARRAY_CUSTOM_R_FLOAT :: const RenderingServer.ARRAY_CUSTOM_R_FLOAT: ArrayCustomFormat = 4
Custom data array contains 32-bit-per-channel red color data. Values are floating-point in single precision.

## ARRAY_CUSTOM_RG_FLOAT :: const RenderingServer.ARRAY_CUSTOM_RG_FLOAT: ArrayCustomFormat = 5
Custom data array contains 32-bit-per-channel red/green color data. Values are floating-point in single precision.

## ARRAY_CUSTOM_RGB_FLOAT :: const RenderingServer.ARRAY_CUSTOM_RGB_FLOAT: ArrayCustomFormat = 6
Custom data array contains 32-bit-per-channel red/green/blue color data. Values are floating-point in single precision.

## ARRAY_CUSTOM_RGBA_FLOAT :: const RenderingServer.ARRAY_CUSTOM_RGBA_FLOAT: ArrayCustomFormat = 7
Custom data array contains 32-bit-per-channel red/green/blue/alpha color data. Values are floating-point in single precision.

## ARRAY_CUSTOM_MAX :: const RenderingServer.ARRAY_CUSTOM_MAX: ArrayCustomFormat = 8
Represents the size of the [enum ArrayCustomFormat] enum.

## ARRAY_FORMAT_VERTEX :: const RenderingServer.ARRAY_FORMAT_VERTEX: ArrayFormat = 1
Flag used to mark a vertex position array.

## ARRAY_FORMAT_NORMAL :: const RenderingServer.ARRAY_FORMAT_NORMAL: ArrayFormat = 2
Flag used to mark a normal array.

## ARRAY_FORMAT_TANGENT :: const RenderingServer.ARRAY_FORMAT_TANGENT: ArrayFormat = 4
Flag used to mark a tangent array.

## ARRAY_FORMAT_COLOR :: const RenderingServer.ARRAY_FORMAT_COLOR: ArrayFormat = 8
Flag used to mark a vertex color array.

## ARRAY_FORMAT_TEX_UV :: const RenderingServer.ARRAY_FORMAT_TEX_UV: ArrayFormat = 16
Flag used to mark a UV coordinates array.

## ARRAY_FORMAT_TEX_UV2 :: const RenderingServer.ARRAY_FORMAT_TEX_UV2: ArrayFormat = 32
Flag used to mark a UV coordinates array for the second UV coordinates.

## ARRAY_FORMAT_CUSTOM0 :: const RenderingServer.ARRAY_FORMAT_CUSTOM0: ArrayFormat = 64
Flag used to mark an array of custom per-vertex data for the first set of custom data.

## ARRAY_FORMAT_CUSTOM1 :: const RenderingServer.ARRAY_FORMAT_CUSTOM1: ArrayFormat = 128
Flag used to mark an array of custom per-vertex data for the second set of custom data.

## ARRAY_FORMAT_CUSTOM2 :: const RenderingServer.ARRAY_FORMAT_CUSTOM2: ArrayFormat = 256
Flag used to mark an array of custom per-vertex data for the third set of custom data.

## ARRAY_FORMAT_CUSTOM3 :: const RenderingServer.ARRAY_FORMAT_CUSTOM3: ArrayFormat = 512
Flag used to mark an array of custom per-vertex data for the fourth set of custom data.

## ARRAY_FORMAT_BONES :: const RenderingServer.ARRAY_FORMAT_BONES: ArrayFormat = 1024
Flag used to mark a bone information array.

## ARRAY_FORMAT_WEIGHTS :: const RenderingServer.ARRAY_FORMAT_WEIGHTS: ArrayFormat = 2048
Flag used to mark a weights array.

## ARRAY_FORMAT_INDEX :: const RenderingServer.ARRAY_FORMAT_INDEX: ArrayFormat = 4096
Flag used to mark an index array.

## ARRAY_FORMAT_BLEND_SHAPE_MASK :: const RenderingServer.ARRAY_FORMAT_BLEND_SHAPE_MASK: ArrayFormat = 7
Mask of mesh channels permitted in blend shapes.

## ARRAY_FORMAT_CUSTOM_BASE :: const RenderingServer.ARRAY_FORMAT_CUSTOM_BASE: ArrayFormat = 13
Shift of first custom channel.

## ARRAY_FORMAT_CUSTOM_BITS :: const RenderingServer.ARRAY_FORMAT_CUSTOM_BITS: ArrayFormat = 3
Number of format bits per custom channel. See [enum ArrayCustomFormat].

## ARRAY_FORMAT_CUSTOM0_SHIFT :: const RenderingServer.ARRAY_FORMAT_CUSTOM0_SHIFT: ArrayFormat = 13
Amount to shift [enum ArrayCustomFormat] for custom channel index 0.

## ARRAY_FORMAT_CUSTOM1_SHIFT :: const RenderingServer.ARRAY_FORMAT_CUSTOM1_SHIFT: ArrayFormat = 16
Amount to shift [enum ArrayCustomFormat] for custom channel index 1.

## ARRAY_FORMAT_CUSTOM2_SHIFT :: const RenderingServer.ARRAY_FORMAT_CUSTOM2_SHIFT: ArrayFormat = 19
Amount to shift [enum ArrayCustomFormat] for custom channel index 2.

## ARRAY_FORMAT_CUSTOM3_SHIFT :: const RenderingServer.ARRAY_FORMAT_CUSTOM3_SHIFT: ArrayFormat = 22
Amount to shift [enum ArrayCustomFormat] for custom channel index 3.

## ARRAY_FORMAT_CUSTOM_MASK :: const RenderingServer.ARRAY_FORMAT_CUSTOM_MASK: ArrayFormat = 7
Mask of custom format bits per custom channel. Must be shifted by one of the SHIFT constants. See [enum ArrayCustomFormat].

## ARRAY_COMPRESS_FLAGS_BASE :: const RenderingServer.ARRAY_COMPRESS_FLAGS_BASE: ArrayFormat = 25
Shift of first compress flag. Compress flags should be passed to [method ArrayMesh.add_surface_from_arrays] and [method SurfaceTool.commit].

## ARRAY_FLAG_USE_2D_VERTICES :: const RenderingServer.ARRAY_FLAG_USE_2D_VERTICES: ArrayFormat = 33554432
Flag used to mark that the array contains 2D vertices.

## ARRAY_FLAG_USE_DYNAMIC_UPDATE :: const RenderingServer.ARRAY_FLAG_USE_DYNAMIC_UPDATE: ArrayFormat = 67108864
Flag used to mark that the mesh data will use [code]GL_DYNAMIC_DRAW[/code] on GLES. Unused on Vulkan.

## ARRAY_FLAG_USE_8_BONE_WEIGHTS :: const RenderingServer.ARRAY_FLAG_USE_8_BONE_WEIGHTS: ArrayFormat = 134217728
Flag used to mark that the array uses 8 bone weights instead of 4.

## ARRAY_FLAG_USES_EMPTY_VERTEX_ARRAY :: const RenderingServer.ARRAY_FLAG_USES_EMPTY_VERTEX_ARRAY: ArrayFormat = 268435456
Flag used to mark that the mesh does not have a vertex array and instead will infer vertex positions in the shader using indices and other information.

## ARRAY_FLAG_COMPRESS_ATTRIBUTES :: const RenderingServer.ARRAY_FLAG_COMPRESS_ATTRIBUTES: ArrayFormat = 536870912
Flag used to mark that a mesh is using compressed attributes (vertices, normals, tangents, UVs). When this form of compression is enabled, vertex positions will be packed into an RGBA16UNORM attribute and scaled in the vertex shader. The normal and tangent will be packed into an RG16UNORM representing an axis, and a 16-bit float stored in the A-channel of the vertex. UVs will use 16-bit normalized floats instead of full 32-bit signed floats. When using this compression mode you must use either vertices, normals, and tangents or only vertices. You cannot use normals without tangents. Importers will automatically enable this compression if they can.

## ARRAY_FLAG_FORMAT_VERSION_BASE :: const RenderingServer.ARRAY_FLAG_FORMAT_VERSION_BASE: ArrayFormat = 35
Flag used to mark the start of the bits used to store the mesh version.

## ARRAY_FLAG_FORMAT_VERSION_SHIFT :: const RenderingServer.ARRAY_FLAG_FORMAT_VERSION_SHIFT: ArrayFormat = 35
Flag used to shift a mesh format int to bring the version into the lowest digits.

## ARRAY_FLAG_FORMAT_VERSION_1 :: const RenderingServer.ARRAY_FLAG_FORMAT_VERSION_1: ArrayFormat = 0
Flag used to record the format used by prior mesh versions before the introduction of a version.

## ARRAY_FLAG_FORMAT_VERSION_2 :: const RenderingServer.ARRAY_FLAG_FORMAT_VERSION_2: ArrayFormat = 34359738368
Flag used to record the second iteration of the mesh version flag. The primary difference between this and [constant ARRAY_FLAG_FORMAT_VERSION_1] is that this version supports [constant ARRAY_FLAG_COMPRESS_ATTRIBUTES] and in this version vertex positions are de-interleaved from normals and tangents.

## ARRAY_FLAG_FORMAT_CURRENT_VERSION :: const RenderingServer.ARRAY_FLAG_FORMAT_CURRENT_VERSION: ArrayFormat = 34359738368
Flag used to record the current version that the engine expects. Currently this is the same as [constant ARRAY_FLAG_FORMAT_VERSION_2].

## ARRAY_FLAG_FORMAT_VERSION_MASK :: const RenderingServer.ARRAY_FLAG_FORMAT_VERSION_MASK: ArrayFormat = 255
Flag used to isolate the bits used for mesh version after using [constant ARRAY_FLAG_FORMAT_VERSION_SHIFT] to shift them into place.

## PRIMITIVE_POINTS :: const RenderingServer.PRIMITIVE_POINTS: PrimitiveType = 0
Primitive to draw consists of points.

## PRIMITIVE_LINES :: const RenderingServer.PRIMITIVE_LINES: PrimitiveType = 1
Primitive to draw consists of lines.

## PRIMITIVE_LINE_STRIP :: const RenderingServer.PRIMITIVE_LINE_STRIP: PrimitiveType = 2
Primitive to draw consists of a line strip from start to end.

## PRIMITIVE_TRIANGLES :: const RenderingServer.PRIMITIVE_TRIANGLES: PrimitiveType = 3
Primitive to draw consists of triangles.

## PRIMITIVE_TRIANGLE_STRIP :: const RenderingServer.PRIMITIVE_TRIANGLE_STRIP: PrimitiveType = 4
Primitive to draw consists of a triangle strip (the last 3 vertices are always combined to make a triangle).

## PRIMITIVE_MAX :: const RenderingServer.PRIMITIVE_MAX: PrimitiveType = 5
Represents the size of the [enum PrimitiveType] enum.

## BLEND_SHAPE_MODE_NORMALIZED :: const RenderingServer.BLEND_SHAPE_MODE_NORMALIZED: BlendShapeMode = 0
Blend shapes are normalized.

## BLEND_SHAPE_MODE_RELATIVE :: const RenderingServer.BLEND_SHAPE_MODE_RELATIVE: BlendShapeMode = 1
Blend shapes are relative to base weight.

## MULTIMESH_TRANSFORM_2D :: const RenderingServer.MULTIMESH_TRANSFORM_2D: MultimeshTransformFormat = 0
Use [Transform2D] to store MultiMesh transform.

## MULTIMESH_TRANSFORM_3D :: const RenderingServer.MULTIMESH_TRANSFORM_3D: MultimeshTransformFormat = 1
Use [Transform3D] to store MultiMesh transform.

## MULTIMESH_INTERP_QUALITY_FAST :: const RenderingServer.MULTIMESH_INTERP_QUALITY_FAST: MultimeshPhysicsInterpolationQuality = 0
MultiMesh physics interpolation favors speed over quality.

## MULTIMESH_INTERP_QUALITY_HIGH :: const RenderingServer.MULTIMESH_INTERP_QUALITY_HIGH: MultimeshPhysicsInterpolationQuality = 1
MultiMesh physics interpolation favors quality over speed.

## LIGHT_PROJECTOR_FILTER_NEAREST :: const RenderingServer.LIGHT_PROJECTOR_FILTER_NEAREST: LightProjectorFilter = 0
Nearest-neighbor filter for light projectors (use for pixel art light projectors). No mipmaps are used for rendering, which means light projectors at a distance will look sharp but grainy. This has roughly the same performance cost as using mipmaps.

## LIGHT_PROJECTOR_FILTER_LINEAR :: const RenderingServer.LIGHT_PROJECTOR_FILTER_LINEAR: LightProjectorFilter = 1
Linear filter for light projectors (use for non-pixel art light projectors). No mipmaps are used for rendering, which means light projectors at a distance will look smooth but blurry. This has roughly the same performance cost as using mipmaps.

## LIGHT_PROJECTOR_FILTER_NEAREST_MIPMAPS :: const RenderingServer.LIGHT_PROJECTOR_FILTER_NEAREST_MIPMAPS: LightProjectorFilter = 2
Nearest-neighbor filter for light projectors (use for pixel art light projectors). Isotropic mipmaps are used for rendering, which means light projectors at a distance will look smooth but blurry. This has roughly the same performance cost as not using mipmaps.

## LIGHT_PROJECTOR_FILTER_LINEAR_MIPMAPS :: const RenderingServer.LIGHT_PROJECTOR_FILTER_LINEAR_MIPMAPS: LightProjectorFilter = 3
Linear filter for light projectors (use for non-pixel art light projectors). Isotropic mipmaps are used for rendering, which means light projectors at a distance will look smooth but blurry. This has roughly the same performance cost as not using mipmaps.

## LIGHT_PROJECTOR_FILTER_NEAREST_MIPMAPS_ANISOTROPIC :: const RenderingServer.LIGHT_PROJECTOR_FILTER_NEAREST_MIPMAPS_ANISOTROPIC: LightProjectorFilter = 4
Nearest-neighbor filter for light projectors (use for pixel art light projectors). Anisotropic mipmaps are used for rendering, which means light projectors at a distance will look smooth and sharp when viewed from oblique angles. This looks better compared to isotropic mipmaps, but is slower. The level of anisotropic filtering is defined by [member ProjectSettings.rendering/textures/default_filters/anisotropic_filtering_level].

## LIGHT_PROJECTOR_FILTER_LINEAR_MIPMAPS_ANISOTROPIC :: const RenderingServer.LIGHT_PROJECTOR_FILTER_LINEAR_MIPMAPS_ANISOTROPIC: LightProjectorFilter = 5
Linear filter for light projectors (use for non-pixel art light projectors). Anisotropic mipmaps are used for rendering, which means light projectors at a distance will look smooth and sharp when viewed from oblique angles. This looks better compared to isotropic mipmaps, but is slower. The level of anisotropic filtering is defined by [member ProjectSettings.rendering/textures/default_filters/anisotropic_filtering_level].

## LIGHT_DIRECTIONAL :: const RenderingServer.LIGHT_DIRECTIONAL: LightType = 0
Directional (sun/moon) light (see [DirectionalLight3D]).

## LIGHT_OMNI :: const RenderingServer.LIGHT_OMNI: LightType = 1
Omni light (see [OmniLight3D]).

## LIGHT_SPOT :: const RenderingServer.LIGHT_SPOT: LightType = 2
Spot light (see [SpotLight3D]).

## LIGHT_AREA :: const RenderingServer.LIGHT_AREA: LightType = 3
Area light (see [AreaLight3D]).

## LIGHT_PARAM_ENERGY :: const RenderingServer.LIGHT_PARAM_ENERGY: LightParam = 0
The light's energy multiplier.

## LIGHT_PARAM_INDIRECT_ENERGY :: const RenderingServer.LIGHT_PARAM_INDIRECT_ENERGY: LightParam = 1
The light's indirect energy multiplier (final indirect energy is [constant LIGHT_PARAM_ENERGY] * [constant LIGHT_PARAM_INDIRECT_ENERGY]).

## LIGHT_PARAM_VOLUMETRIC_FOG_ENERGY :: const RenderingServer.LIGHT_PARAM_VOLUMETRIC_FOG_ENERGY: LightParam = 2
The light's volumetric fog energy multiplier (final volumetric fog energy is [constant LIGHT_PARAM_ENERGY] * [constant LIGHT_PARAM_VOLUMETRIC_FOG_ENERGY]).

## LIGHT_PARAM_SPECULAR :: const RenderingServer.LIGHT_PARAM_SPECULAR: LightParam = 3
The light's influence on specularity.

## LIGHT_PARAM_RANGE :: const RenderingServer.LIGHT_PARAM_RANGE: LightParam = 4
The light's range.

## LIGHT_PARAM_SIZE :: const RenderingServer.LIGHT_PARAM_SIZE: LightParam = 5
The size of the light when using spot light or omni light. The angular size of the light when using directional light.

## LIGHT_PARAM_ATTENUATION :: const RenderingServer.LIGHT_PARAM_ATTENUATION: LightParam = 6
The light's attenuation.

## LIGHT_PARAM_SPOT_ANGLE :: const RenderingServer.LIGHT_PARAM_SPOT_ANGLE: LightParam = 7
The spotlight's angle.

## LIGHT_PARAM_SPOT_ATTENUATION :: const RenderingServer.LIGHT_PARAM_SPOT_ATTENUATION: LightParam = 8
The spotlight's attenuation.

## LIGHT_PARAM_SHADOW_MAX_DISTANCE :: const RenderingServer.LIGHT_PARAM_SHADOW_MAX_DISTANCE: LightParam = 9
The maximum distance for shadow splits. Increasing this value will make directional shadows visible from further away, at the cost of lower overall shadow detail and performance (since more objects need to be included in the directional shadow rendering).

## LIGHT_PARAM_SHADOW_SPLIT_1_OFFSET :: const RenderingServer.LIGHT_PARAM_SHADOW_SPLIT_1_OFFSET: LightParam = 10
Proportion of shadow atlas occupied by the first split.

## LIGHT_PARAM_SHADOW_SPLIT_2_OFFSET :: const RenderingServer.LIGHT_PARAM_SHADOW_SPLIT_2_OFFSET: LightParam = 11
Proportion of shadow atlas occupied by the second split.

## LIGHT_PARAM_SHADOW_SPLIT_3_OFFSET :: const RenderingServer.LIGHT_PARAM_SHADOW_SPLIT_3_OFFSET: LightParam = 12
Proportion of shadow atlas occupied by the third split. The fourth split occupies the rest.

## LIGHT_PARAM_SHADOW_FADE_START :: const RenderingServer.LIGHT_PARAM_SHADOW_FADE_START: LightParam = 13
Proportion of shadow max distance where the shadow will start to fade out.

## LIGHT_PARAM_SHADOW_NORMAL_BIAS :: const RenderingServer.LIGHT_PARAM_SHADOW_NORMAL_BIAS: LightParam = 14
Normal bias used to offset shadow lookup by object normal. Can be used to fix self-shadowing artifacts.

## LIGHT_PARAM_SHADOW_BIAS :: const RenderingServer.LIGHT_PARAM_SHADOW_BIAS: LightParam = 15
Bias for the shadow lookup to fix self-shadowing artifacts.

## LIGHT_PARAM_SHADOW_PANCAKE_SIZE :: const RenderingServer.LIGHT_PARAM_SHADOW_PANCAKE_SIZE: LightParam = 16
Sets the size of the directional shadow pancake. The pancake offsets the start of the shadow's camera frustum to provide a higher effective depth resolution for the shadow. However, a high pancake size can cause artifacts in the shadows of large objects that are close to the edge of the frustum. Reducing the pancake size can help. Setting the size to [code]0[/code] turns off the pancaking effect.

## LIGHT_PARAM_SHADOW_OPACITY :: const RenderingServer.LIGHT_PARAM_SHADOW_OPACITY: LightParam = 17
The light's shadow opacity. Values lower than [code]1.0[/code] make the light appear through shadows. This can be used to fake global illumination at a low performance cost.

## LIGHT_PARAM_SHADOW_BLUR :: const RenderingServer.LIGHT_PARAM_SHADOW_BLUR: LightParam = 18
Blurs the edges of the shadow. Can be used to hide pixel artifacts in low resolution shadow maps. A high value can make shadows appear grainy and can cause other unwanted artifacts. Try to keep as near default as possible.

## LIGHT_PARAM_TRANSMITTANCE_BIAS :: const RenderingServer.LIGHT_PARAM_TRANSMITTANCE_BIAS: LightParam = 19

## LIGHT_PARAM_INTENSITY :: const RenderingServer.LIGHT_PARAM_INTENSITY: LightParam = 20
Constant representing the intensity of the light, measured in Lumens when dealing with a [SpotLight3D] or [OmniLight3D], or measured in Lux with a [DirectionalLight3D]. Only used when [member ProjectSettings.rendering/lights_and_shadows/use_physical_light_units] is [code]true[/code].

## LIGHT_PARAM_MAX :: const RenderingServer.LIGHT_PARAM_MAX: LightParam = 21
Represents the size of the [enum LightParam] enum.

## LIGHT_BAKE_DISABLED :: const RenderingServer.LIGHT_BAKE_DISABLED: LightBakeMode = 0
Light is ignored when baking. This is the fastest mode, but the light will be taken into account when baking global illumination. This mode should generally be used for dynamic lights that change quickly, as the effect of global illumination is less noticeable on those lights.

## LIGHT_BAKE_STATIC :: const RenderingServer.LIGHT_BAKE_STATIC: LightBakeMode = 1
Light is taken into account in static baking ([VoxelGI], [LightmapGI], SDFGI ([member Environment.sdfgi_enabled])). The light can be moved around or modified, but its global illumination will not update in real-time. This is suitable for subtle changes (such as flickering torches), but generally not large changes such as toggling a light on and off.

## LIGHT_BAKE_DYNAMIC :: const RenderingServer.LIGHT_BAKE_DYNAMIC: LightBakeMode = 2
Light is taken into account in dynamic baking ([VoxelGI] and SDFGI ([member Environment.sdfgi_enabled]) only). The light can be moved around or modified with global illumination updating in real-time. The light's global illumination appearance will be slightly different compared to [constant LIGHT_BAKE_STATIC]. This has a greater performance cost compared to [constant LIGHT_BAKE_STATIC]. When using SDFGI, the update speed of dynamic lights is affected by [member ProjectSettings.rendering/global_illumination/sdfgi/frames_to_update_lights].

## LIGHT_OMNI_SHADOW_DUAL_PARABOLOID :: const RenderingServer.LIGHT_OMNI_SHADOW_DUAL_PARABOLOID: LightOmniShadowMode = 0
Use a dual paraboloid shadow map for omni lights.

## LIGHT_OMNI_SHADOW_CUBE :: const RenderingServer.LIGHT_OMNI_SHADOW_CUBE: LightOmniShadowMode = 1
Use a cubemap shadow map for omni lights. Slower but better quality than dual paraboloid.

## LIGHT_DIRECTIONAL_SHADOW_ORTHOGONAL :: const RenderingServer.LIGHT_DIRECTIONAL_SHADOW_ORTHOGONAL: LightDirectionalShadowMode = 0
Use orthogonal shadow projection for directional light.

## LIGHT_DIRECTIONAL_SHADOW_PARALLEL_2_SPLITS :: const RenderingServer.LIGHT_DIRECTIONAL_SHADOW_PARALLEL_2_SPLITS: LightDirectionalShadowMode = 1
Use 2 splits for shadow projection when using directional light.

## LIGHT_DIRECTIONAL_SHADOW_PARALLEL_4_SPLITS :: const RenderingServer.LIGHT_DIRECTIONAL_SHADOW_PARALLEL_4_SPLITS: LightDirectionalShadowMode = 2
Use 4 splits for shadow projection when using directional light.

## LIGHT_DIRECTIONAL_SKY_MODE_LIGHT_AND_SKY :: const RenderingServer.LIGHT_DIRECTIONAL_SKY_MODE_LIGHT_AND_SKY: LightDirectionalSkyMode = 0
Use DirectionalLight3D in both sky rendering and scene lighting.

## LIGHT_DIRECTIONAL_SKY_MODE_LIGHT_ONLY :: const RenderingServer.LIGHT_DIRECTIONAL_SKY_MODE_LIGHT_ONLY: LightDirectionalSkyMode = 1
Only use DirectionalLight3D in scene lighting.

## LIGHT_DIRECTIONAL_SKY_MODE_SKY_ONLY :: const RenderingServer.LIGHT_DIRECTIONAL_SKY_MODE_SKY_ONLY: LightDirectionalSkyMode = 2
Only use DirectionalLight3D in sky rendering.

## SHADOW_QUALITY_HARD :: const RenderingServer.SHADOW_QUALITY_HARD: ShadowQuality = 0
Lowest shadow filtering quality (fastest). Soft shadows are not available with this quality setting, which means the [member Light3D.shadow_blur] property is ignored if [member Light3D.light_size] and [member Light3D.light_angular_distance] is [code]0.0[/code].
[b]Note:[/b] The variable shadow blur performed by [member Light3D.light_size] and [member Light3D.light_angular_distance] is still effective when using hard shadow filtering. In this case, [member Light3D.shadow_blur] [i]is[/i] taken into account. However, the results will not be blurred, instead the blur amount is treated as a maximum radius for the penumbra.

## SHADOW_QUALITY_SOFT_VERY_LOW :: const RenderingServer.SHADOW_QUALITY_SOFT_VERY_LOW: ShadowQuality = 1
Very low shadow filtering quality (faster). When using this quality setting, [member Light3D.shadow_blur] is automatically multiplied by 0.75× to avoid introducing too much noise. This division only applies to lights whose [member Light3D.light_size] or [member Light3D.light_angular_distance] is [code]0.0[/code]).

## SHADOW_QUALITY_SOFT_LOW :: const RenderingServer.SHADOW_QUALITY_SOFT_LOW: ShadowQuality = 2
Low shadow filtering quality (fast).

## SHADOW_QUALITY_SOFT_MEDIUM :: const RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM: ShadowQuality = 3
Medium low shadow filtering quality (average).

## SHADOW_QUALITY_SOFT_HIGH :: const RenderingServer.SHADOW_QUALITY_SOFT_HIGH: ShadowQuality = 4
High low shadow filtering quality (slow). When using this quality setting, [member Light3D.shadow_blur] is automatically multiplied by 1.5× to better make use of the high sample count. This increased blur also improves the stability of dynamic object shadows. This multiplier only applies to lights whose [member Light3D.light_size] or [member Light3D.light_angular_distance] is [code]0.0[/code]).

## SHADOW_QUALITY_SOFT_ULTRA :: const RenderingServer.SHADOW_QUALITY_SOFT_ULTRA: ShadowQuality = 5
Highest low shadow filtering quality (slowest). When using this quality setting, [member Light3D.shadow_blur] is automatically multiplied by 2× to better make use of the high sample count. This increased blur also improves the stability of dynamic object shadows. This multiplier only applies to lights whose [member Light3D.light_size] or [member Light3D.light_angular_distance] is [code]0.0[/code]).

## SHADOW_QUALITY_MAX :: const RenderingServer.SHADOW_QUALITY_MAX: ShadowQuality = 6
Represents the size of the [enum ShadowQuality] enum.

## REFLECTION_PROBE_UPDATE_ONCE :: const RenderingServer.REFLECTION_PROBE_UPDATE_ONCE: ReflectionProbeUpdateMode = 0
Reflection probe will update reflections once and then stop.

## REFLECTION_PROBE_UPDATE_ALWAYS :: const RenderingServer.REFLECTION_PROBE_UPDATE_ALWAYS: ReflectionProbeUpdateMode = 1
Reflection probe will update each frame. This mode is necessary to capture moving objects.

## REFLECTION_PROBE_AMBIENT_DISABLED :: const RenderingServer.REFLECTION_PROBE_AMBIENT_DISABLED: ReflectionProbeAmbientMode = 0
Do not apply any ambient lighting inside the reflection probe's box defined by its size.

## REFLECTION_PROBE_AMBIENT_ENVIRONMENT :: const RenderingServer.REFLECTION_PROBE_AMBIENT_ENVIRONMENT: ReflectionProbeAmbientMode = 1
Apply automatically-sourced environment lighting inside the reflection probe's box defined by its size.

## REFLECTION_PROBE_AMBIENT_COLOR :: const RenderingServer.REFLECTION_PROBE_AMBIENT_COLOR: ReflectionProbeAmbientMode = 2
Apply custom ambient lighting inside the reflection probe's box defined by its size. See [method reflection_probe_set_ambient_color] and [method reflection_probe_set_ambient_energy].

## DECAL_TEXTURE_ALBEDO :: const RenderingServer.DECAL_TEXTURE_ALBEDO: DecalTexture = 0
Albedo texture slot in a decal ([member Decal.texture_albedo]).

## DECAL_TEXTURE_NORMAL :: const RenderingServer.DECAL_TEXTURE_NORMAL: DecalTexture = 1
Normal map texture slot in a decal ([member Decal.texture_normal]).

## DECAL_TEXTURE_ORM :: const RenderingServer.DECAL_TEXTURE_ORM: DecalTexture = 2
Occlusion/Roughness/Metallic texture slot in a decal ([member Decal.texture_orm]).

## DECAL_TEXTURE_EMISSION :: const RenderingServer.DECAL_TEXTURE_EMISSION: DecalTexture = 3
Emission texture slot in a decal ([member Decal.texture_emission]).

## DECAL_TEXTURE_MAX :: const RenderingServer.DECAL_TEXTURE_MAX: DecalTexture = 4
Represents the size of the [enum DecalTexture] enum.

## DECAL_FILTER_NEAREST :: const RenderingServer.DECAL_FILTER_NEAREST: DecalFilter = 0
Nearest-neighbor filter for decals (use for pixel art decals). No mipmaps are used for rendering, which means decals at a distance will look sharp but grainy. This has roughly the same performance cost as using mipmaps.

## DECAL_FILTER_LINEAR :: const RenderingServer.DECAL_FILTER_LINEAR: DecalFilter = 1
Linear filter for decals (use for non-pixel art decals). No mipmaps are used for rendering, which means decals at a distance will look smooth but blurry. This has roughly the same performance cost as using mipmaps.

## DECAL_FILTER_NEAREST_MIPMAPS :: const RenderingServer.DECAL_FILTER_NEAREST_MIPMAPS: DecalFilter = 2
Nearest-neighbor filter for decals (use for pixel art decals). Isotropic mipmaps are used for rendering, which means decals at a distance will look smooth but blurry. This has roughly the same performance cost as not using mipmaps.

## DECAL_FILTER_LINEAR_MIPMAPS :: const RenderingServer.DECAL_FILTER_LINEAR_MIPMAPS: DecalFilter = 3
Linear filter for decals (use for non-pixel art decals). Isotropic mipmaps are used for rendering, which means decals at a distance will look smooth but blurry. This has roughly the same performance cost as not using mipmaps.

## DECAL_FILTER_NEAREST_MIPMAPS_ANISOTROPIC :: const RenderingServer.DECAL_FILTER_NEAREST_MIPMAPS_ANISOTROPIC: DecalFilter = 4
Nearest-neighbor filter for decals (use for pixel art decals). Anisotropic mipmaps are used for rendering, which means decals at a distance will look smooth and sharp when viewed from oblique angles. This looks better compared to isotropic mipmaps, but is slower. The level of anisotropic filtering is defined by [member ProjectSettings.rendering/textures/default_filters/anisotropic_filtering_level].

## DECAL_FILTER_LINEAR_MIPMAPS_ANISOTROPIC :: const RenderingServer.DECAL_FILTER_LINEAR_MIPMAPS_ANISOTROPIC: DecalFilter = 5
Linear filter for decals (use for non-pixel art decals). Anisotropic mipmaps are used for rendering, which means decals at a distance will look smooth and sharp when viewed from oblique angles. This looks better compared to isotropic mipmaps, but is slower. The level of anisotropic filtering is defined by [member ProjectSettings.rendering/textures/default_filters/anisotropic_filtering_level].

## VOXEL_GI_QUALITY_LOW :: const RenderingServer.VOXEL_GI_QUALITY_LOW: VoxelGIQuality = 0
Low [VoxelGI] rendering quality using 4 cones.

## VOXEL_GI_QUALITY_HIGH :: const RenderingServer.VOXEL_GI_QUALITY_HIGH: VoxelGIQuality = 1
High [VoxelGI] rendering quality using 6 cones.

## PARTICLES_MODE_2D :: const RenderingServer.PARTICLES_MODE_2D: ParticlesMode = 0
2D particles.

## PARTICLES_MODE_3D :: const RenderingServer.PARTICLES_MODE_3D: ParticlesMode = 1
3D particles.

## PARTICLES_TRANSFORM_ALIGN_DISABLED :: const RenderingServer.PARTICLES_TRANSFORM_ALIGN_DISABLED: ParticlesTransformAlign = 0
Do not align particle transforms relative to the camera or velocity.

## PARTICLES_TRANSFORM_ALIGN_Z_BILLBOARD :: const RenderingServer.PARTICLES_TRANSFORM_ALIGN_Z_BILLBOARD: ParticlesTransformAlign = 1
Align each particle's Z axis to face the camera.

## PARTICLES_TRANSFORM_ALIGN_Y_TO_VELOCITY :: const RenderingServer.PARTICLES_TRANSFORM_ALIGN_Y_TO_VELOCITY: ParticlesTransformAlign = 2
Align each particle's Y axis to the velocity vector.

## PARTICLES_TRANSFORM_ALIGN_Z_BILLBOARD_Y_TO_VELOCITY :: const RenderingServer.PARTICLES_TRANSFORM_ALIGN_Z_BILLBOARD_Y_TO_VELOCITY: ParticlesTransformAlign = 3
Align each particle's Z axis to face the camera and Y axis to the velocity vector.

## PARTICLES_TRANSFORM_ALIGN_LOCAL_BILLBOARD :: const RenderingServer.PARTICLES_TRANSFORM_ALIGN_LOCAL_BILLBOARD: ParticlesTransformAlign = 4
Billboard each particles around a local axis.

## PARTICLES_ALIGN_CHANNEL_FILTER_DISABLED :: const RenderingServer.PARTICLES_ALIGN_CHANNEL_FILTER_DISABLED: ParticlesTransformAlignCustomSrc = 0
Do not read from CUSTOM when performing billboarding.

## PARTICLES_ALIGN_CHANNEL_FILTER_X :: const RenderingServer.PARTICLES_ALIGN_CHANNEL_FILTER_X: ParticlesTransformAlignCustomSrc = 1
Read from [code]CUSTOM.x[/code] when performing billboarding and use it as an angle, in radians.

## PARTICLES_ALIGN_CHANNEL_FILTER_Y :: const RenderingServer.PARTICLES_ALIGN_CHANNEL_FILTER_Y: ParticlesTransformAlignCustomSrc = 2
Read from [code]CUSTOM.y[/code] when performing billboarding and use it as an angle, in radians.

## PARTICLES_ALIGN_CHANNEL_FILTER_Z :: const RenderingServer.PARTICLES_ALIGN_CHANNEL_FILTER_Z: ParticlesTransformAlignCustomSrc = 3
Read from [code]CUSTOM.z[/code] when performing billboarding and use it as an angle, in radians.

## PARTICLES_ALIGN_CHANNEL_FILTER_W :: const RenderingServer.PARTICLES_ALIGN_CHANNEL_FILTER_W: ParticlesTransformAlignCustomSrc = 4
Read from [code]CUSTOM.w[/code] when performing billboarding and use it as an angle, in radians.

## PARTICLES_ALIGN_AXIS_X :: const RenderingServer.PARTICLES_ALIGN_AXIS_X: ParticlesTransformAlignAxis = 0
Use the X axis for local billboarding.

## PARTICLES_ALIGN_AXIS_Y :: const RenderingServer.PARTICLES_ALIGN_AXIS_Y: ParticlesTransformAlignAxis = 1
Use the Y axis for local billboarding.

## PARTICLES_EMIT_FLAG_POSITION :: const RenderingServer.PARTICLES_EMIT_FLAG_POSITION = 1
Particle starts at the specified position.

## PARTICLES_EMIT_FLAG_ROTATION_SCALE :: const RenderingServer.PARTICLES_EMIT_FLAG_ROTATION_SCALE = 2
Particle starts with specified rotation and scale.

## PARTICLES_EMIT_FLAG_VELOCITY :: const RenderingServer.PARTICLES_EMIT_FLAG_VELOCITY = 4
Particle starts with the specified velocity vector, which defines the emission direction and speed.

## PARTICLES_EMIT_FLAG_COLOR :: const RenderingServer.PARTICLES_EMIT_FLAG_COLOR = 8
Particle starts with specified color.

## PARTICLES_EMIT_FLAG_CUSTOM :: const RenderingServer.PARTICLES_EMIT_FLAG_CUSTOM = 16
Particle starts with specified [code]CUSTOM[/code] data.

## PARTICLES_DRAW_ORDER_INDEX :: const RenderingServer.PARTICLES_DRAW_ORDER_INDEX: ParticlesDrawOrder = 0
Draw particles in the order that they appear in the particles array.

## PARTICLES_DRAW_ORDER_LIFETIME :: const RenderingServer.PARTICLES_DRAW_ORDER_LIFETIME: ParticlesDrawOrder = 1
Sort particles based on their lifetime. In other words, the particle with the highest lifetime is drawn at the front.

## PARTICLES_DRAW_ORDER_REVERSE_LIFETIME :: const RenderingServer.PARTICLES_DRAW_ORDER_REVERSE_LIFETIME: ParticlesDrawOrder = 2
Sort particles based on the inverse of their lifetime. In other words, the particle with the lowest lifetime is drawn at the front.

## PARTICLES_DRAW_ORDER_VIEW_DEPTH :: const RenderingServer.PARTICLES_DRAW_ORDER_VIEW_DEPTH: ParticlesDrawOrder = 3
Sort particles based on their distance to the camera.

## PARTICLES_COLLISION_TYPE_SPHERE_ATTRACT :: const RenderingServer.PARTICLES_COLLISION_TYPE_SPHERE_ATTRACT: ParticlesCollisionType = 0
Sphere attractor type for [GPUParticles3D] (see [GPUParticlesAttractorSphere3D]).

## PARTICLES_COLLISION_TYPE_BOX_ATTRACT :: const RenderingServer.PARTICLES_COLLISION_TYPE_BOX_ATTRACT: ParticlesCollisionType = 1
Box attractor type for [GPUParticles3D] (see [GPUParticlesAttractorBox3D]).

## PARTICLES_COLLISION_TYPE_VECTOR_FIELD_ATTRACT :: const RenderingServer.PARTICLES_COLLISION_TYPE_VECTOR_FIELD_ATTRACT: ParticlesCollisionType = 2
Vector field attractor type for [GPUParticles3D] (see [GPUParticlesAttractorVectorField3D]).

## PARTICLES_COLLISION_TYPE_SPHERE_COLLIDE :: const RenderingServer.PARTICLES_COLLISION_TYPE_SPHERE_COLLIDE: ParticlesCollisionType = 3
Sphere collision type for [GPUParticles3D] (see [GPUParticlesCollisionSphere3D]).

## PARTICLES_COLLISION_TYPE_BOX_COLLIDE :: const RenderingServer.PARTICLES_COLLISION_TYPE_BOX_COLLIDE: ParticlesCollisionType = 4
Box collision type for [GPUParticles3D] (see [GPUParticlesCollisionBox3D]).

## PARTICLES_COLLISION_TYPE_SDF_COLLIDE :: const RenderingServer.PARTICLES_COLLISION_TYPE_SDF_COLLIDE: ParticlesCollisionType = 5
Signed distance field collision type for [GPUParticles3D] (see [GPUParticlesCollisionSDF3D]).

## PARTICLES_COLLISION_TYPE_HEIGHTFIELD_COLLIDE :: const RenderingServer.PARTICLES_COLLISION_TYPE_HEIGHTFIELD_COLLIDE: ParticlesCollisionType = 6
Heightfield collision type for [GPUParticles3D] (see [GPUParticlesCollisionHeightField3D]).

## PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_256 :: const RenderingServer.PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_256: ParticlesCollisionHeightfieldResolution = 0
256×256 heightfield resolution for [GPUParticlesCollisionHeightField3D].

## PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_512 :: const RenderingServer.PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_512: ParticlesCollisionHeightfieldResolution = 1
512×512 heightfield resolution for [GPUParticlesCollisionHeightField3D].

## PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_1024 :: const RenderingServer.PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_1024: ParticlesCollisionHeightfieldResolution = 2
1024×1024 heightfield resolution for [GPUParticlesCollisionHeightField3D].

## PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_2048 :: const RenderingServer.PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_2048: ParticlesCollisionHeightfieldResolution = 3
2048×2048 heightfield resolution for [GPUParticlesCollisionHeightField3D].

## PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_4096 :: const RenderingServer.PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_4096: ParticlesCollisionHeightfieldResolution = 4
4096×4096 heightfield resolution for [GPUParticlesCollisionHeightField3D].

## PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_8192 :: const RenderingServer.PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_8192: ParticlesCollisionHeightfieldResolution = 5
8192×8192 heightfield resolution for [GPUParticlesCollisionHeightField3D].

## PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_MAX :: const RenderingServer.PARTICLES_COLLISION_HEIGHTFIELD_RESOLUTION_MAX: ParticlesCollisionHeightfieldResolution = 6
Represents the size of the [enum ParticlesCollisionHeightfieldResolution] enum.

## FOG_VOLUME_SHAPE_ELLIPSOID :: const RenderingServer.FOG_VOLUME_SHAPE_ELLIPSOID: FogVolumeShape = 0
[FogVolume] will be shaped like an ellipsoid (stretched sphere).

## FOG_VOLUME_SHAPE_CONE :: const RenderingServer.FOG_VOLUME_SHAPE_CONE: FogVolumeShape = 1
[FogVolume] will be shaped like a cone pointing upwards (in local coordinates). The cone's angle is set automatically to fill the size. The cone will be adjusted to fit within the size. Rotate the [FogVolume] node to reorient the cone. Non-uniform scaling via size is not supported (scale the [FogVolume] node instead).

## FOG_VOLUME_SHAPE_CYLINDER :: const RenderingServer.FOG_VOLUME_SHAPE_CYLINDER: FogVolumeShape = 2
[FogVolume] will be shaped like an upright cylinder (in local coordinates). Rotate the [FogVolume] node to reorient the cylinder. The cylinder will be adjusted to fit within the size. Non-uniform scaling via size is not supported (scale the [FogVolume] node instead).

## FOG_VOLUME_SHAPE_BOX :: const RenderingServer.FOG_VOLUME_SHAPE_BOX: FogVolumeShape = 3
[FogVolume] will be shaped like a box.

## FOG_VOLUME_SHAPE_WORLD :: const RenderingServer.FOG_VOLUME_SHAPE_WORLD: FogVolumeShape = 4
[FogVolume] will have no shape, will cover the whole world and will not be culled.

## FOG_VOLUME_SHAPE_MAX :: const RenderingServer.FOG_VOLUME_SHAPE_MAX: FogVolumeShape = 5
Represents the size of the [enum FogVolumeShape] enum.

## VIEWPORT_SCALING_3D_MODE_BILINEAR :: const RenderingServer.VIEWPORT_SCALING_3D_MODE_BILINEAR: ViewportScaling3DMode = 0
Use bilinear scaling for the viewport's 3D buffer. The amount of scaling can be set using [member Viewport.scaling_3d_scale]. Values less than [code]1.0[/code] will result in undersampling while values greater than [code]1.0[/code] will result in supersampling. A value of [code]1.0[/code] disables scaling.

## VIEWPORT_SCALING_3D_MODE_FSR :: const RenderingServer.VIEWPORT_SCALING_3D_MODE_FSR: ViewportScaling3DMode = 1
Use AMD FidelityFX Super Resolution 1.0 upscaling for the viewport's 3D buffer. The amount of scaling can be set using [member Viewport.scaling_3d_scale]. Values less than [code]1.0[/code] will result in the viewport being upscaled using FSR. Values greater than [code]1.0[/code] are not supported and bilinear downsampling will be used instead. A value of [code]1.0[/code] disables scaling.

## VIEWPORT_SCALING_3D_MODE_FSR2 :: const RenderingServer.VIEWPORT_SCALING_3D_MODE_FSR2: ViewportScaling3DMode = 2
Use AMD FidelityFX Super Resolution 2.2 upscaling for the viewport's 3D buffer. The amount of scaling can be set using [member Viewport.scaling_3d_scale]. Values less than [code]1.0[/code] will result in the viewport being upscaled using FSR2. Values greater than [code]1.0[/code] are not supported and bilinear downsampling will be used instead. A value of [code]1.0[/code] will use FSR2 at native resolution as a TAA solution.

## VIEWPORT_SCALING_3D_MODE_METALFX_SPATIAL :: const RenderingServer.VIEWPORT_SCALING_3D_MODE_METALFX_SPATIAL: ViewportScaling3DMode = 3
Use MetalFX spatial upscaling for the viewport's 3D buffer. The amount of scaling can be set using [member Viewport.scaling_3d_scale]. Values less than [code]1.0[/code] will result in the viewport being upscaled using MetalFX. Values greater than [code]1.0[/code] are not supported and bilinear downsampling will be used instead. A value of [code]1.0[/code] disables scaling.
[b]Note:[/b] Only supported when the Metal rendering driver is in use, which limits this scaling mode to macOS and iOS.

## VIEWPORT_SCALING_3D_MODE_METALFX_TEMPORAL :: const RenderingServer.VIEWPORT_SCALING_3D_MODE_METALFX_TEMPORAL: ViewportScaling3DMode = 4
Use MetalFX temporal upscaling for the viewport's 3D buffer. The amount of scaling can be set using [member Viewport.scaling_3d_scale]. Values less than [code]1.0[/code] will result in the viewport being upscaled using MetalFX. Values greater than [code]1.0[/code] are not supported and bilinear downsampling will be used instead. A value of [code]1.0[/code] will use MetalFX at native resolution as a TAA solution.
[b]Note:[/b] Only supported when the Metal rendering driver is in use, which limits this scaling mode to macOS and iOS.

## VIEWPORT_SCALING_3D_MODE_NEAREST :: const RenderingServer.VIEWPORT_SCALING_3D_MODE_NEAREST: ViewportScaling3DMode = 5
Use nearest-neighbor filtering for the viewport's 3D buffer. This looks crisper than [constant VIEWPORT_SCALING_3D_MODE_BILINEAR] and has no additional rendering cost. The amount of scaling can be set using [member Viewport.scaling_3d_scale]. Values greater than [code]1.0[/code] are not supported and bilinear downsampling will be used instead. A value of [code]1.0[/code] disables scaling.
[b]Note:[/b] When using the [b]Nearest[/b] scaling mode, to avoid uneven pixel scaling, it's highly recommended to use a value equal to an integer divisor with a dividend of [code]1[/code]. For example, it's best to use a scale of [code]0.5[/code] (1/2), [code]0.3333[/code] (1/3), [code]0.25[/code] (1/4), [code]0.2[/code] (1/5), and so on.

## VIEWPORT_SCALING_3D_MODE_MAX :: const RenderingServer.VIEWPORT_SCALING_3D_MODE_MAX: ViewportScaling3DMode = 6
Represents the size of the [enum ViewportScaling3DMode] enum.

## VIEWPORT_UPDATE_DISABLED :: const RenderingServer.VIEWPORT_UPDATE_DISABLED: ViewportUpdateMode = 0
Do not update the viewport's render target.

## VIEWPORT_UPDATE_ONCE :: const RenderingServer.VIEWPORT_UPDATE_ONCE: ViewportUpdateMode = 1
Update the viewport's render target once, then switch to [constant VIEWPORT_UPDATE_DISABLED].

## VIEWPORT_UPDATE_WHEN_VISIBLE :: const RenderingServer.VIEWPORT_UPDATE_WHEN_VISIBLE: ViewportUpdateMode = 2
Update the viewport's render target only when it is visible. This is the default value.

## VIEWPORT_UPDATE_WHEN_PARENT_VISIBLE :: const RenderingServer.VIEWPORT_UPDATE_WHEN_PARENT_VISIBLE: ViewportUpdateMode = 3
Update the viewport's render target only when its parent is visible.

## VIEWPORT_UPDATE_ALWAYS :: const RenderingServer.VIEWPORT_UPDATE_ALWAYS: ViewportUpdateMode = 4
Always update the viewport's render target.

## VIEWPORT_CLEAR_ALWAYS :: const RenderingServer.VIEWPORT_CLEAR_ALWAYS: ViewportClearMode = 0
Always clear the viewport's render target before drawing.

## VIEWPORT_CLEAR_NEVER :: const RenderingServer.VIEWPORT_CLEAR_NEVER: ViewportClearMode = 1
Never clear the viewport's render target.

## VIEWPORT_CLEAR_ONLY_NEXT_FRAME :: const RenderingServer.VIEWPORT_CLEAR_ONLY_NEXT_FRAME: ViewportClearMode = 2
Clear the viewport's render target on the next frame, then switch to [constant VIEWPORT_CLEAR_NEVER].

## VIEWPORT_ENVIRONMENT_DISABLED :: const RenderingServer.VIEWPORT_ENVIRONMENT_DISABLED: ViewportEnvironmentMode = 0
Disable rendering of 3D environment over 2D canvas.

## VIEWPORT_ENVIRONMENT_ENABLED :: const RenderingServer.VIEWPORT_ENVIRONMENT_ENABLED: ViewportEnvironmentMode = 1
Enable rendering of 3D environment over 2D canvas.

## VIEWPORT_ENVIRONMENT_INHERIT :: const RenderingServer.VIEWPORT_ENVIRONMENT_INHERIT: ViewportEnvironmentMode = 2
Inherit enable/disable value from parent. If the topmost parent is also set to [constant VIEWPORT_ENVIRONMENT_INHERIT], then this has the same behavior as [constant VIEWPORT_ENVIRONMENT_ENABLED].

## VIEWPORT_ENVIRONMENT_MAX :: const RenderingServer.VIEWPORT_ENVIRONMENT_MAX: ViewportEnvironmentMode = 3
Represents the size of the [enum ViewportEnvironmentMode] enum.

## VIEWPORT_SDF_OVERSIZE_100_PERCENT :: const RenderingServer.VIEWPORT_SDF_OVERSIZE_100_PERCENT: ViewportSDFOversize = 0
Do not oversize the 2D signed distance field. Occluders may disappear when touching the viewport's edges, and [GPUParticles3D] collision may stop working earlier than intended. This has the lowest GPU requirements.

## VIEWPORT_SDF_OVERSIZE_120_PERCENT :: const RenderingServer.VIEWPORT_SDF_OVERSIZE_120_PERCENT: ViewportSDFOversize = 1
2D signed distance field covers 20% of the viewport's size outside the viewport on each side (top, right, bottom, left).

## VIEWPORT_SDF_OVERSIZE_150_PERCENT :: const RenderingServer.VIEWPORT_SDF_OVERSIZE_150_PERCENT: ViewportSDFOversize = 2
2D signed distance field covers 50% of the viewport's size outside the viewport on each side (top, right, bottom, left).

## VIEWPORT_SDF_OVERSIZE_200_PERCENT :: const RenderingServer.VIEWPORT_SDF_OVERSIZE_200_PERCENT: ViewportSDFOversize = 3
2D signed distance field covers 100% of the viewport's size outside the viewport on each side (top, right, bottom, left). This has the highest GPU requirements.

## VIEWPORT_SDF_OVERSIZE_MAX :: const RenderingServer.VIEWPORT_SDF_OVERSIZE_MAX: ViewportSDFOversize = 4
Represents the size of the [enum ViewportSDFOversize] enum.

## VIEWPORT_SDF_SCALE_100_PERCENT :: const RenderingServer.VIEWPORT_SDF_SCALE_100_PERCENT: ViewportSDFScale = 0
Full resolution 2D signed distance field scale. This has the highest GPU requirements.

## VIEWPORT_SDF_SCALE_50_PERCENT :: const RenderingServer.VIEWPORT_SDF_SCALE_50_PERCENT: ViewportSDFScale = 1
Half resolution 2D signed distance field scale on each axis (25% of the viewport pixel count).

## VIEWPORT_SDF_SCALE_25_PERCENT :: const RenderingServer.VIEWPORT_SDF_SCALE_25_PERCENT: ViewportSDFScale = 2
Quarter resolution 2D signed distance field scale on each axis (6.25% of the viewport pixel count). This has the lowest GPU requirements.

## VIEWPORT_SDF_SCALE_MAX :: const RenderingServer.VIEWPORT_SDF_SCALE_MAX: ViewportSDFScale = 3
Represents the size of the [enum ViewportSDFScale] enum.

## VIEWPORT_MSAA_DISABLED :: const RenderingServer.VIEWPORT_MSAA_DISABLED: ViewportMSAA = 0
Multisample antialiasing for 3D is disabled. This is the default value, and also the fastest setting.

## VIEWPORT_MSAA_2X :: const RenderingServer.VIEWPORT_MSAA_2X: ViewportMSAA = 1
Multisample antialiasing uses 2 samples per pixel for 3D. This has a moderate impact on performance.

## VIEWPORT_MSAA_4X :: const RenderingServer.VIEWPORT_MSAA_4X: ViewportMSAA = 2
Multisample antialiasing uses 4 samples per pixel for 3D. This has a high impact on performance.

## VIEWPORT_MSAA_8X :: const RenderingServer.VIEWPORT_MSAA_8X: ViewportMSAA = 3
Multisample antialiasing uses 8 samples per pixel for 3D. This has a very high impact on performance. Likely unsupported on low-end and older hardware.

## VIEWPORT_MSAA_MAX :: const RenderingServer.VIEWPORT_MSAA_MAX: ViewportMSAA = 4
Represents the size of the [enum ViewportMSAA] enum.

## VIEWPORT_ANISOTROPY_DISABLED :: const RenderingServer.VIEWPORT_ANISOTROPY_DISABLED: ViewportAnisotropicFiltering = 0
Anisotropic filtering is disabled.

## VIEWPORT_ANISOTROPY_2X :: const RenderingServer.VIEWPORT_ANISOTROPY_2X: ViewportAnisotropicFiltering = 1
Use 2× anisotropic filtering.

## VIEWPORT_ANISOTROPY_4X :: const RenderingServer.VIEWPORT_ANISOTROPY_4X: ViewportAnisotropicFiltering = 2
Use 4× anisotropic filtering. This is the default value.

## VIEWPORT_ANISOTROPY_8X :: const RenderingServer.VIEWPORT_ANISOTROPY_8X: ViewportAnisotropicFiltering = 3
Use 8× anisotropic filtering.

## VIEWPORT_ANISOTROPY_16X :: const RenderingServer.VIEWPORT_ANISOTROPY_16X: ViewportAnisotropicFiltering = 4
Use 16× anisotropic filtering.

## VIEWPORT_ANISOTROPY_MAX :: const RenderingServer.VIEWPORT_ANISOTROPY_MAX: ViewportAnisotropicFiltering = 5
Represents the size of the [enum ViewportAnisotropicFiltering] enum.

## VIEWPORT_SCREEN_SPACE_AA_DISABLED :: const RenderingServer.VIEWPORT_SCREEN_SPACE_AA_DISABLED: ViewportScreenSpaceAA = 0
Do not perform any antialiasing in the full screen post-process.

## VIEWPORT_SCREEN_SPACE_AA_FXAA :: const RenderingServer.VIEWPORT_SCREEN_SPACE_AA_FXAA: ViewportScreenSpaceAA = 1
Use fast approximate antialiasing. FXAA is a popular screen-space antialiasing method, which is fast but will make the image look blurry, especially at lower resolutions. It can still work relatively well at large resolutions such as 1440p and 4K.

## VIEWPORT_SCREEN_SPACE_AA_SMAA :: const RenderingServer.VIEWPORT_SCREEN_SPACE_AA_SMAA: ViewportScreenSpaceAA = 2
Use subpixel morphological antialiasing. SMAA may produce clearer results than FXAA, but at a slightly higher performance cost.

## VIEWPORT_SCREEN_SPACE_AA_MAX :: const RenderingServer.VIEWPORT_SCREEN_SPACE_AA_MAX: ViewportScreenSpaceAA = 3
Represents the size of the [enum ViewportScreenSpaceAA] enum.

## VIEWPORT_OCCLUSION_BUILD_QUALITY_LOW :: const RenderingServer.VIEWPORT_OCCLUSION_BUILD_QUALITY_LOW: ViewportOcclusionCullingBuildQuality = 0
Low occlusion culling BVH build quality (as defined by Embree). Results in the lowest CPU usage, but least effective culling.

## VIEWPORT_OCCLUSION_BUILD_QUALITY_MEDIUM :: const RenderingServer.VIEWPORT_OCCLUSION_BUILD_QUALITY_MEDIUM: ViewportOcclusionCullingBuildQuality = 1
Medium occlusion culling BVH build quality (as defined by Embree).

## VIEWPORT_OCCLUSION_BUILD_QUALITY_HIGH :: const RenderingServer.VIEWPORT_OCCLUSION_BUILD_QUALITY_HIGH: ViewportOcclusionCullingBuildQuality = 2
High occlusion culling BVH build quality (as defined by Embree). Results in the highest CPU usage, but most effective culling.

## VIEWPORT_RENDER_INFO_OBJECTS_IN_FRAME :: const RenderingServer.VIEWPORT_RENDER_INFO_OBJECTS_IN_FRAME: ViewportRenderInfo = 0
Number of objects drawn in a single frame.

## VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME :: const RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME: ViewportRenderInfo = 1
Number of points, lines, or triangles drawn in a single frame.

## VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME :: const RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME: ViewportRenderInfo = 2
Number of draw calls during this frame.

## VIEWPORT_RENDER_INFO_MAX :: const RenderingServer.VIEWPORT_RENDER_INFO_MAX: ViewportRenderInfo = 3
Represents the size of the [enum ViewportRenderInfo] enum.

## VIEWPORT_RENDER_INFO_TYPE_VISIBLE :: const RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE: ViewportRenderInfoType = 0
Visible render pass (excluding shadows).

## VIEWPORT_RENDER_INFO_TYPE_SHADOW :: const RenderingServer.VIEWPORT_RENDER_INFO_TYPE_SHADOW: ViewportRenderInfoType = 1
Shadow render pass. Objects will be rendered several times depending on the number of amounts of lights with shadows and the number of directional shadow splits.

## VIEWPORT_RENDER_INFO_TYPE_CANVAS :: const RenderingServer.VIEWPORT_RENDER_INFO_TYPE_CANVAS: ViewportRenderInfoType = 2
Canvas item rendering. This includes all 2D rendering.

## VIEWPORT_RENDER_INFO_TYPE_MAX :: const RenderingServer.VIEWPORT_RENDER_INFO_TYPE_MAX: ViewportRenderInfoType = 3
Represents the size of the [enum ViewportRenderInfoType] enum.

## VIEWPORT_DEBUG_DRAW_DISABLED :: const RenderingServer.VIEWPORT_DEBUG_DRAW_DISABLED: ViewportDebugDraw = 0
Debug draw is disabled. Default setting.

## VIEWPORT_DEBUG_DRAW_UNSHADED :: const RenderingServer.VIEWPORT_DEBUG_DRAW_UNSHADED: ViewportDebugDraw = 1
Objects are displayed without light information.

## VIEWPORT_DEBUG_DRAW_LIGHTING :: const RenderingServer.VIEWPORT_DEBUG_DRAW_LIGHTING: ViewportDebugDraw = 2
Objects are displayed with only light information.
[b]Note:[/b] When using this debug draw mode, custom shaders are ignored since all materials in the scene temporarily use a debug material. This means the result from custom shader functions (such as vertex displacement) won't be visible anymore when using this debug draw mode.

## VIEWPORT_DEBUG_DRAW_OVERDRAW :: const RenderingServer.VIEWPORT_DEBUG_DRAW_OVERDRAW: ViewportDebugDraw = 3
Objects are displayed semi-transparent with additive blending so you can see where they are drawing over top of one another. A higher overdraw (represented by brighter colors) means you are wasting performance on drawing pixels that are being hidden behind others.
[b]Note:[/b] When using this debug draw mode, custom shaders are ignored since all materials in the scene temporarily use a debug material. This means the result from custom shader functions (such as vertex displacement) won't be visible anymore when using this debug draw mode.

## VIEWPORT_DEBUG_DRAW_WIREFRAME :: const RenderingServer.VIEWPORT_DEBUG_DRAW_WIREFRAME: ViewportDebugDraw = 4
Debug draw draws objects in wireframe.
[b]Note:[/b] [method set_debug_generate_wireframes] must be called before loading any meshes for wireframes to be visible when using the Compatibility renderer.
[b]Note:[/b] In the Compatibility renderer, backfaces are always visible when using wireframe rendering. In the Forward+ and Mobile renderers, wireframes follow the material's backface culling properties instead.

## VIEWPORT_DEBUG_DRAW_NORMAL_BUFFER :: const RenderingServer.VIEWPORT_DEBUG_DRAW_NORMAL_BUFFER: ViewportDebugDraw = 5
Normal buffer is drawn instead of regular scene so you can see the per-pixel normals that will be used by post-processing effects.

## VIEWPORT_DEBUG_DRAW_VOXEL_GI_ALBEDO :: const RenderingServer.VIEWPORT_DEBUG_DRAW_VOXEL_GI_ALBEDO: ViewportDebugDraw = 6
Objects are displayed with only the albedo value from [VoxelGI]s. Requires at least one visible [VoxelGI] node that has been baked to have a visible effect.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_VOXEL_GI_LIGHTING :: const RenderingServer.VIEWPORT_DEBUG_DRAW_VOXEL_GI_LIGHTING: ViewportDebugDraw = 7
Objects are displayed with only the lighting value from [VoxelGI]s. Requires at least one visible [VoxelGI] node that has been baked to have a visible effect.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_VOXEL_GI_EMISSION :: const RenderingServer.VIEWPORT_DEBUG_DRAW_VOXEL_GI_EMISSION: ViewportDebugDraw = 8
Objects are displayed with only the emission color from [VoxelGI]s. Requires at least one visible [VoxelGI] node that has been baked to have a visible effect.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_SHADOW_ATLAS :: const RenderingServer.VIEWPORT_DEBUG_DRAW_SHADOW_ATLAS: ViewportDebugDraw = 9
Draws the shadow atlas that stores shadows from [OmniLight3D]s and [SpotLight3D]s in the upper left quadrant of the [Viewport].

## VIEWPORT_DEBUG_DRAW_DIRECTIONAL_SHADOW_ATLAS :: const RenderingServer.VIEWPORT_DEBUG_DRAW_DIRECTIONAL_SHADOW_ATLAS: ViewportDebugDraw = 10
Draws the shadow atlas that stores shadows from [DirectionalLight3D]s in the upper left quadrant of the [Viewport].
The slice of the camera frustum related to the shadow map cascade is superimposed to visualize coverage. The color of each slice matches the colors used for [constant VIEWPORT_DEBUG_DRAW_PSSM_SPLITS]. When shadow cascades are blended the overlap is taken into account when drawing the frustum slices.
The last cascade shows all frustum slices to illustrate the coverage of all slices.

## VIEWPORT_DEBUG_DRAW_SCENE_LUMINANCE :: const RenderingServer.VIEWPORT_DEBUG_DRAW_SCENE_LUMINANCE: ViewportDebugDraw = 11
Draws the estimated scene luminance. This is a 1×1 texture that is generated when autoexposure is enabled to control the scene's exposure.
[b]Note:[/b] Only supported when using the Forward+ or Mobile rendering methods.

## VIEWPORT_DEBUG_DRAW_SSAO :: const RenderingServer.VIEWPORT_DEBUG_DRAW_SSAO: ViewportDebugDraw = 12
Draws the screen space ambient occlusion texture instead of the scene so that you can clearly see how it is affecting objects. In order for this display mode to work, you must have [member Environment.ssao_enabled] set in your [WorldEnvironment].
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_SSIL :: const RenderingServer.VIEWPORT_DEBUG_DRAW_SSIL: ViewportDebugDraw = 13
Draws the screen space indirect lighting texture instead of the scene so that you can clearly see how it is affecting objects. In order for this display mode to work, you must have [member Environment.ssil_enabled] set in your [WorldEnvironment].
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_PSSM_SPLITS :: const RenderingServer.VIEWPORT_DEBUG_DRAW_PSSM_SPLITS: ViewportDebugDraw = 14
Colors each PSSM split for the [DirectionalLight3D]s in the scene a different color so you can see where the splits are. In order (from closest to furthest from the camera), they are colored red, green, blue, and yellow.
[b]Note:[/b] When using this debug draw mode, custom shaders are ignored since all materials in the scene temporarily use a debug material. This means the result from custom shader functions (such as vertex displacement) won't be visible anymore when using this debug draw mode.
[b]Note:[/b] Only supported when using the Forward+ or Mobile rendering methods.

## VIEWPORT_DEBUG_DRAW_DECAL_ATLAS :: const RenderingServer.VIEWPORT_DEBUG_DRAW_DECAL_ATLAS: ViewportDebugDraw = 15
Draws the decal atlas that stores decal textures from [Decal]s.
[b]Note:[/b] Only supported when using the Forward+ or Mobile rendering methods.

## VIEWPORT_DEBUG_DRAW_SDFGI :: const RenderingServer.VIEWPORT_DEBUG_DRAW_SDFGI: ViewportDebugDraw = 16
Draws SDFGI cascade data. This is the data structure that is used to bounce lighting against and create reflections.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_SDFGI_PROBES :: const RenderingServer.VIEWPORT_DEBUG_DRAW_SDFGI_PROBES: ViewportDebugDraw = 17
Draws SDFGI probe data. This is the data structure that is used to give indirect lighting dynamic objects moving within the scene.
When in the editor, left-clicking a probe will display additional bright dots that show its occlusion information. A white dot means the light is not occluded at all at the dot's position, while a red dot means the light is fully occluded. Intermediate values are possible.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_GI_BUFFER :: const RenderingServer.VIEWPORT_DEBUG_DRAW_GI_BUFFER: ViewportDebugDraw = 18
Draws the global illumination buffer from [VoxelGI] or SDFGI. Requires [VoxelGI] (at least one visible baked VoxelGI node) or SDFGI ([member Environment.sdfgi_enabled]) to be enabled to have a visible effect.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_DISABLE_LOD :: const RenderingServer.VIEWPORT_DEBUG_DRAW_DISABLE_LOD: ViewportDebugDraw = 19
Disable mesh LOD. All meshes are drawn with full detail, which can be used to compare performance.

## VIEWPORT_DEBUG_DRAW_CLUSTER_OMNI_LIGHTS :: const RenderingServer.VIEWPORT_DEBUG_DRAW_CLUSTER_OMNI_LIGHTS: ViewportDebugDraw = 20
Draws the [OmniLight3D] cluster. Clustering determines where lights are positioned in screen-space, which allows the engine to only process these portions of the screen for lighting.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_CLUSTER_SPOT_LIGHTS :: const RenderingServer.VIEWPORT_DEBUG_DRAW_CLUSTER_SPOT_LIGHTS: ViewportDebugDraw = 21
Draws the [SpotLight3D] cluster. Clustering determines where lights are positioned in screen-space, which allows the engine to only process these portions of the screen for lighting.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_CLUSTER_DECALS :: const RenderingServer.VIEWPORT_DEBUG_DRAW_CLUSTER_DECALS: ViewportDebugDraw = 22
Draws the [Decal] cluster. Clustering determines where decals are positioned in screen-space, which allows the engine to only process these portions of the screen for decals.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_CLUSTER_REFLECTION_PROBES :: const RenderingServer.VIEWPORT_DEBUG_DRAW_CLUSTER_REFLECTION_PROBES: ViewportDebugDraw = 23
Draws the [ReflectionProbe] cluster. Clustering determines where reflection probes are positioned in screen-space, which allows the engine to only process these portions of the screen for reflection probes.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_OCCLUDERS :: const RenderingServer.VIEWPORT_DEBUG_DRAW_OCCLUDERS: ViewportDebugDraw = 24
Draws the occlusion culling buffer. This low-resolution occlusion culling buffer is rasterized on the CPU and is used to check whether instances are occluded by other objects.
[b]Note:[/b] Only supported when using the Forward+ or Mobile rendering methods.

## VIEWPORT_DEBUG_DRAW_MOTION_VECTORS :: const RenderingServer.VIEWPORT_DEBUG_DRAW_MOTION_VECTORS: ViewportDebugDraw = 25
Draws the motion vectors buffer. This is used by temporal antialiasing to correct for motion that occurs during gameplay.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## VIEWPORT_DEBUG_DRAW_INTERNAL_BUFFER :: const RenderingServer.VIEWPORT_DEBUG_DRAW_INTERNAL_BUFFER: ViewportDebugDraw = 26
Internal buffer is drawn instead of regular scene so you can see the per-pixel output that will be used by post-processing effects.
[b]Note:[/b] Only supported when using the Forward+ or Mobile rendering methods.

## VIEWPORT_VRS_DISABLED :: const RenderingServer.VIEWPORT_VRS_DISABLED: ViewportVRSMode = 0
Variable rate shading is disabled.

## VIEWPORT_VRS_TEXTURE :: const RenderingServer.VIEWPORT_VRS_TEXTURE: ViewportVRSMode = 1
Variable rate shading uses a texture. Note, for stereoscopic use a texture atlas with a texture for each view.

## VIEWPORT_VRS_XR :: const RenderingServer.VIEWPORT_VRS_XR: ViewportVRSMode = 2
Variable rate shading texture is supplied by the primary [XRInterface]. Note that this may override the update mode.

## VIEWPORT_VRS_MAX :: const RenderingServer.VIEWPORT_VRS_MAX: ViewportVRSMode = 3
Represents the size of the [enum ViewportVRSMode] enum.

## VIEWPORT_VRS_UPDATE_DISABLED :: const RenderingServer.VIEWPORT_VRS_UPDATE_DISABLED: ViewportVRSUpdateMode = 0
The input texture for variable rate shading will not be processed.

## VIEWPORT_VRS_UPDATE_ONCE :: const RenderingServer.VIEWPORT_VRS_UPDATE_ONCE: ViewportVRSUpdateMode = 1
The input texture for variable rate shading will be processed once.

## VIEWPORT_VRS_UPDATE_ALWAYS :: const RenderingServer.VIEWPORT_VRS_UPDATE_ALWAYS: ViewportVRSUpdateMode = 2
The input texture for variable rate shading will be processed each frame.

## VIEWPORT_VRS_UPDATE_MAX :: const RenderingServer.VIEWPORT_VRS_UPDATE_MAX: ViewportVRSUpdateMode = 3
Represents the size of the [enum ViewportVRSUpdateMode] enum.

## SKY_MODE_AUTOMATIC :: const RenderingServer.SKY_MODE_AUTOMATIC: SkyMode = 0
Automatically selects the appropriate process mode based on your sky shader. If your shader uses [code]TIME[/code] or [code]POSITION[/code], this will use [constant SKY_MODE_REALTIME]. If your shader uses any of the [code]LIGHT_*[/code] variables or any custom uniforms, this uses [constant SKY_MODE_INCREMENTAL]. Otherwise, this defaults to [constant SKY_MODE_QUALITY].

## SKY_MODE_QUALITY :: const RenderingServer.SKY_MODE_QUALITY: SkyMode = 1
Uses high quality importance sampling to process the radiance map. In general, this results in much higher quality than [constant SKY_MODE_REALTIME] but takes much longer to generate. This should not be used if you plan on changing the sky at runtime. If you are finding that the reflection is not blurry enough and is showing sparkles or fireflies, try increasing [member ProjectSettings.rendering/reflections/sky_reflections/ggx_samples].

## SKY_MODE_INCREMENTAL :: const RenderingServer.SKY_MODE_INCREMENTAL: SkyMode = 2
Uses the same high quality importance sampling to process the radiance map as [constant SKY_MODE_QUALITY], but updates over several frames. The number of frames is determined by [member ProjectSettings.rendering/reflections/sky_reflections/roughness_layers]. Use this when you need highest quality radiance maps, but have a sky that updates slowly.

## SKY_MODE_REALTIME :: const RenderingServer.SKY_MODE_REALTIME: SkyMode = 3
Uses the fast filtering algorithm to process the radiance map. In general this results in lower quality, but substantially faster run times. If you need better quality, but still need to update the sky every frame, consider turning on [member ProjectSettings.rendering/reflections/sky_reflections/fast_filter_high_quality].
[b]Note:[/b] The fast filtering algorithm is limited to 256×256 cubemaps, so [method sky_set_radiance_size] must be set to [code]256[/code]. Otherwise, a warning is printed and the overridden radiance size is ignored.

## COMPOSITOR_EFFECT_FLAG_ACCESS_RESOLVED_COLOR :: const RenderingServer.COMPOSITOR_EFFECT_FLAG_ACCESS_RESOLVED_COLOR: CompositorEffectFlags = 1
The rendering effect requires the color buffer to be resolved if MSAA is enabled.

## COMPOSITOR_EFFECT_FLAG_ACCESS_RESOLVED_DEPTH :: const RenderingServer.COMPOSITOR_EFFECT_FLAG_ACCESS_RESOLVED_DEPTH: CompositorEffectFlags = 2
The rendering effect requires the depth buffer to be resolved if MSAA is enabled.

## COMPOSITOR_EFFECT_FLAG_NEEDS_MOTION_VECTORS :: const RenderingServer.COMPOSITOR_EFFECT_FLAG_NEEDS_MOTION_VECTORS: CompositorEffectFlags = 4
The rendering effect requires motion vectors to be produced.

## COMPOSITOR_EFFECT_FLAG_NEEDS_ROUGHNESS :: const RenderingServer.COMPOSITOR_EFFECT_FLAG_NEEDS_ROUGHNESS: CompositorEffectFlags = 8
The rendering effect requires normals and roughness g-buffer to be produced (Forward+ only).

## COMPOSITOR_EFFECT_FLAG_NEEDS_SEPARATE_SPECULAR :: const RenderingServer.COMPOSITOR_EFFECT_FLAG_NEEDS_SEPARATE_SPECULAR: CompositorEffectFlags = 16
The rendering effect requires specular data to be separated out (Forward+ only).

## COMPOSITOR_EFFECT_CALLBACK_TYPE_PRE_OPAQUE :: const RenderingServer.COMPOSITOR_EFFECT_CALLBACK_TYPE_PRE_OPAQUE: CompositorEffectCallbackType = 0
The callback is called before our opaque rendering pass, but after depth prepass (if applicable).

## COMPOSITOR_EFFECT_CALLBACK_TYPE_POST_OPAQUE :: const RenderingServer.COMPOSITOR_EFFECT_CALLBACK_TYPE_POST_OPAQUE: CompositorEffectCallbackType = 1
The callback is called after our opaque rendering pass, but before our sky is rendered.

## COMPOSITOR_EFFECT_CALLBACK_TYPE_POST_SKY :: const RenderingServer.COMPOSITOR_EFFECT_CALLBACK_TYPE_POST_SKY: CompositorEffectCallbackType = 2
The callback is called after our sky is rendered, but before our back buffers are created (and if enabled, before subsurface scattering and/or screen space reflections).

## COMPOSITOR_EFFECT_CALLBACK_TYPE_PRE_TRANSPARENT :: const RenderingServer.COMPOSITOR_EFFECT_CALLBACK_TYPE_PRE_TRANSPARENT: CompositorEffectCallbackType = 3
The callback is called before our transparent rendering pass, but after our sky is rendered and we've created our back buffers.

## COMPOSITOR_EFFECT_CALLBACK_TYPE_POST_TRANSPARENT :: const RenderingServer.COMPOSITOR_EFFECT_CALLBACK_TYPE_POST_TRANSPARENT: CompositorEffectCallbackType = 4
The callback is called after our transparent rendering pass, but before any built-in post-processing effects and output to our render target.

## COMPOSITOR_EFFECT_CALLBACK_TYPE_ANY :: const RenderingServer.COMPOSITOR_EFFECT_CALLBACK_TYPE_ANY: CompositorEffectCallbackType = -1

## ENV_BG_CLEAR_COLOR :: const RenderingServer.ENV_BG_CLEAR_COLOR: EnvironmentBG = 0
Use the clear color as background.

## ENV_BG_COLOR :: const RenderingServer.ENV_BG_COLOR: EnvironmentBG = 1
Use a specified color as the background.

## ENV_BG_SKY :: const RenderingServer.ENV_BG_SKY: EnvironmentBG = 2
Use a sky resource for the background.

## ENV_BG_CANVAS :: const RenderingServer.ENV_BG_CANVAS: EnvironmentBG = 3
Use a specified canvas layer as the background. This can be useful for instantiating a 2D scene in a 3D world.

## ENV_BG_KEEP :: const RenderingServer.ENV_BG_KEEP: EnvironmentBG = 4
Do not clear the background, use whatever was rendered last frame as the background.

## ENV_BG_CAMERA_FEED :: const RenderingServer.ENV_BG_CAMERA_FEED: EnvironmentBG = 5
Displays a camera feed in the background.

## ENV_BG_MAX :: const RenderingServer.ENV_BG_MAX: EnvironmentBG = 6
Represents the size of the [enum EnvironmentBG] enum.

## ENV_AMBIENT_SOURCE_BG :: const RenderingServer.ENV_AMBIENT_SOURCE_BG: EnvironmentAmbientSource = 0
Gather ambient light from whichever source is specified as the background.

## ENV_AMBIENT_SOURCE_DISABLED :: const RenderingServer.ENV_AMBIENT_SOURCE_DISABLED: EnvironmentAmbientSource = 1
Disable ambient light.

## ENV_AMBIENT_SOURCE_COLOR :: const RenderingServer.ENV_AMBIENT_SOURCE_COLOR: EnvironmentAmbientSource = 2
Specify a specific [Color] for ambient light.

## ENV_AMBIENT_SOURCE_SKY :: const RenderingServer.ENV_AMBIENT_SOURCE_SKY: EnvironmentAmbientSource = 3
Gather ambient light from the [Sky] regardless of what the background is.

## ENV_REFLECTION_SOURCE_BG :: const RenderingServer.ENV_REFLECTION_SOURCE_BG: EnvironmentReflectionSource = 0
Use the background for reflections.

## ENV_REFLECTION_SOURCE_DISABLED :: const RenderingServer.ENV_REFLECTION_SOURCE_DISABLED: EnvironmentReflectionSource = 1
Disable reflections.

## ENV_REFLECTION_SOURCE_SKY :: const RenderingServer.ENV_REFLECTION_SOURCE_SKY: EnvironmentReflectionSource = 2
Use the [Sky] for reflections regardless of what the background is.

## ENV_GLOW_BLEND_MODE_ADDITIVE :: const RenderingServer.ENV_GLOW_BLEND_MODE_ADDITIVE: EnvironmentGlowBlendMode = 0
Adds the glow effect to the scene.

## ENV_GLOW_BLEND_MODE_SCREEN :: const RenderingServer.ENV_GLOW_BLEND_MODE_SCREEN: EnvironmentGlowBlendMode = 1
Adds the glow effect to the scene after modifying the glow influence based on the scene value; dark values will be highly influenced by glow and bright values will not be influenced by glow. This approach avoids bright values becoming overly bright from the glow effect. [member Environment.tonemap_white] is used to determine the maximum scene value where the glow should have no influence. When [member Environment.tonemap_mode] is set to [constant Environment.TONE_MAPPER_LINEAR] and [member Viewport.use_hdr_2d] is [code]true[/code], the parent window's [method Window.get_output_max_linear_value] will be used as the maximum scene value.

## ENV_GLOW_BLEND_MODE_SOFTLIGHT :: const RenderingServer.ENV_GLOW_BLEND_MODE_SOFTLIGHT: EnvironmentGlowBlendMode = 2
Adds the glow effect to the tonemapped image after modifying the glow influence based on the image value; dark values and bright values will not be influenced by glow and mid-range values will be highly influenced by glow. This approach avoids bright values becoming overly bright from the glow effect. The glow will have the largest influence on image values of [code]0.25[/code] and will have no influence when applied to image values greater than [code]1.0[/code].
[b]Note:[/b] This blend mode does not support HDR output because expects a maximum output value of [code]1.0[/code]. It is recommended to use a different blend mode when rendering to an HDR screen.

## ENV_GLOW_BLEND_MODE_REPLACE :: const RenderingServer.ENV_GLOW_BLEND_MODE_REPLACE: EnvironmentGlowBlendMode = 3
Replaces all pixels' color by the glow effect. This can be used to simulate a full-screen blur effect by tweaking the glow parameters to match the original image's brightness or to preview glow configuration in the editor.

## ENV_GLOW_BLEND_MODE_MIX :: const RenderingServer.ENV_GLOW_BLEND_MODE_MIX: EnvironmentGlowBlendMode = 4
Mixes the glow image with the scene image. Best used with [member Environment.glow_bloom] to avoid darkening the scene.

## ENV_FOG_MODE_EXPONENTIAL :: const RenderingServer.ENV_FOG_MODE_EXPONENTIAL: EnvironmentFogMode = 0
Use a physically-based fog model defined primarily by fog density.

## ENV_FOG_MODE_DEPTH :: const RenderingServer.ENV_FOG_MODE_DEPTH: EnvironmentFogMode = 1
Use a simple fog model defined by start and end positions and a custom curve. While not physically accurate, this model can be useful when you need more artistic control.

## ENV_TONE_MAPPER_LINEAR :: const RenderingServer.ENV_TONE_MAPPER_LINEAR: EnvironmentToneMapper = 0
Does not modify color data, resulting in a linear tonemapping curve which unnaturally clips bright values, causing bright lighting to look blown out. The simplest and fastest tonemapper.

## ENV_TONE_MAPPER_REINHARD :: const RenderingServer.ENV_TONE_MAPPER_REINHARD: EnvironmentToneMapper = 1
A simple tonemapping curve that rolls off bright values to prevent clipping. This results in an image that can appear dull and low contrast. Slower than [constant ENV_TONE_MAPPER_LINEAR].
[b]Note:[/b] When [member Environment.tonemap_white] is left at the default value of [code]1.0[/code], [constant ENV_TONE_MAPPER_REINHARD] produces an identical image to [constant ENV_TONE_MAPPER_LINEAR].

## ENV_TONE_MAPPER_FILMIC :: const RenderingServer.ENV_TONE_MAPPER_FILMIC: EnvironmentToneMapper = 2
Uses a film-like tonemapping curve to prevent clipping of bright values and provide better contrast than [constant ENV_TONE_MAPPER_REINHARD]. Slightly slower than [constant ENV_TONE_MAPPER_REINHARD].
[b]Note:[/b] This tonemapper does not support HDR output because it produces output in the SDR range. It is recommended to use a different tonemapper when rendering to an HDR screen.

## ENV_TONE_MAPPER_ACES :: const RenderingServer.ENV_TONE_MAPPER_ACES: EnvironmentToneMapper = 3
Uses a high-contrast film-like tonemapping curve and desaturates bright values for a more realistic appearance. Slightly slower than [constant ENV_TONE_MAPPER_FILMIC].
[b]Note:[/b] This tonemapping operator is called "ACES Fitted" in Godot 3.x.
[b]Note:[/b] This tonemapper does not support HDR output because it produces output in the SDR range. It is recommended to use a different tonemapper when rendering to an HDR screen.

## ENV_TONE_MAPPER_AGX :: const RenderingServer.ENV_TONE_MAPPER_AGX: EnvironmentToneMapper = 4
Uses an adjustable film-like tonemapping curve and desaturates bright values for a more realistic appearance. Better than other tonemappers at maintaining the hue of colors as they become brighter. The slowest tonemapping option.

## ENV_SSR_ROUGHNESS_QUALITY_DISABLED :: const RenderingServer.ENV_SSR_ROUGHNESS_QUALITY_DISABLED: EnvironmentSSRRoughnessQuality = 0
Lowest quality of roughness filter for screen-space reflections. Rough materials will not have blurrier screen-space reflections compared to smooth (non-rough) materials. This is the fastest option.

## ENV_SSR_ROUGHNESS_QUALITY_LOW :: const RenderingServer.ENV_SSR_ROUGHNESS_QUALITY_LOW: EnvironmentSSRRoughnessQuality = 1
Low quality of roughness filter for screen-space reflections.

## ENV_SSR_ROUGHNESS_QUALITY_MEDIUM :: const RenderingServer.ENV_SSR_ROUGHNESS_QUALITY_MEDIUM: EnvironmentSSRRoughnessQuality = 2
Medium quality of roughness filter for screen-space reflections.

## ENV_SSR_ROUGHNESS_QUALITY_HIGH :: const RenderingServer.ENV_SSR_ROUGHNESS_QUALITY_HIGH: EnvironmentSSRRoughnessQuality = 3
High quality of roughness filter for screen-space reflections. This is the slowest option.

## ENV_SSAO_QUALITY_VERY_LOW :: const RenderingServer.ENV_SSAO_QUALITY_VERY_LOW: EnvironmentSSAOQuality = 0
Lowest quality of screen-space ambient occlusion.

## ENV_SSAO_QUALITY_LOW :: const RenderingServer.ENV_SSAO_QUALITY_LOW: EnvironmentSSAOQuality = 1
Low quality screen-space ambient occlusion.

## ENV_SSAO_QUALITY_MEDIUM :: const RenderingServer.ENV_SSAO_QUALITY_MEDIUM: EnvironmentSSAOQuality = 2
Medium quality screen-space ambient occlusion.

## ENV_SSAO_QUALITY_HIGH :: const RenderingServer.ENV_SSAO_QUALITY_HIGH: EnvironmentSSAOQuality = 3
High quality screen-space ambient occlusion.

## ENV_SSAO_QUALITY_ULTRA :: const RenderingServer.ENV_SSAO_QUALITY_ULTRA: EnvironmentSSAOQuality = 4
Highest quality screen-space ambient occlusion. Uses the adaptive target setting which can be dynamically adjusted to smoothly balance performance and visual quality.

## ENV_SSIL_QUALITY_VERY_LOW :: const RenderingServer.ENV_SSIL_QUALITY_VERY_LOW: EnvironmentSSILQuality = 0
Lowest quality of screen-space indirect lighting.

## ENV_SSIL_QUALITY_LOW :: const RenderingServer.ENV_SSIL_QUALITY_LOW: EnvironmentSSILQuality = 1
Low quality screen-space indirect lighting.

## ENV_SSIL_QUALITY_MEDIUM :: const RenderingServer.ENV_SSIL_QUALITY_MEDIUM: EnvironmentSSILQuality = 2
High quality screen-space indirect lighting.

## ENV_SSIL_QUALITY_HIGH :: const RenderingServer.ENV_SSIL_QUALITY_HIGH: EnvironmentSSILQuality = 3
High quality screen-space indirect lighting.

## ENV_SSIL_QUALITY_ULTRA :: const RenderingServer.ENV_SSIL_QUALITY_ULTRA: EnvironmentSSILQuality = 4
Highest quality screen-space indirect lighting. Uses the adaptive target setting which can be dynamically adjusted to smoothly balance performance and visual quality.

## ENV_SDFGI_Y_SCALE_50_PERCENT :: const RenderingServer.ENV_SDFGI_Y_SCALE_50_PERCENT: EnvironmentSDFGIYScale = 0
Use 50% scale for SDFGI on the Y (vertical) axis. SDFGI cells will be twice as short as they are wide. This allows providing increased GI detail and reduced light leaking with thin floors and ceilings. This is usually the best choice for scenes that don't feature much verticality.

## ENV_SDFGI_Y_SCALE_75_PERCENT :: const RenderingServer.ENV_SDFGI_Y_SCALE_75_PERCENT: EnvironmentSDFGIYScale = 1
Use 75% scale for SDFGI on the Y (vertical) axis. This is a balance between the 50% and 100% SDFGI Y scales.

## ENV_SDFGI_Y_SCALE_100_PERCENT :: const RenderingServer.ENV_SDFGI_Y_SCALE_100_PERCENT: EnvironmentSDFGIYScale = 2
Use 100% scale for SDFGI on the Y (vertical) axis. SDFGI cells will be as tall as they are wide. This is usually the best choice for highly vertical scenes. The downside is that light leaking may become more noticeable with thin floors and ceilings.

## ENV_SDFGI_RAY_COUNT_4 :: const RenderingServer.ENV_SDFGI_RAY_COUNT_4: EnvironmentSDFGIRayCount = 0
Throw 4 rays per frame when converging SDFGI. This has the lowest GPU requirements, but creates the most noisy result.

## ENV_SDFGI_RAY_COUNT_8 :: const RenderingServer.ENV_SDFGI_RAY_COUNT_8: EnvironmentSDFGIRayCount = 1
Throw 8 rays per frame when converging SDFGI.

## ENV_SDFGI_RAY_COUNT_16 :: const RenderingServer.ENV_SDFGI_RAY_COUNT_16: EnvironmentSDFGIRayCount = 2
Throw 16 rays per frame when converging SDFGI.

## ENV_SDFGI_RAY_COUNT_32 :: const RenderingServer.ENV_SDFGI_RAY_COUNT_32: EnvironmentSDFGIRayCount = 3
Throw 32 rays per frame when converging SDFGI.

## ENV_SDFGI_RAY_COUNT_64 :: const RenderingServer.ENV_SDFGI_RAY_COUNT_64: EnvironmentSDFGIRayCount = 4
Throw 64 rays per frame when converging SDFGI.

## ENV_SDFGI_RAY_COUNT_96 :: const RenderingServer.ENV_SDFGI_RAY_COUNT_96: EnvironmentSDFGIRayCount = 5
Throw 96 rays per frame when converging SDFGI. This has high GPU requirements.

## ENV_SDFGI_RAY_COUNT_128 :: const RenderingServer.ENV_SDFGI_RAY_COUNT_128: EnvironmentSDFGIRayCount = 6
Throw 128 rays per frame when converging SDFGI. This has very high GPU requirements, but creates the least noisy result.

## ENV_SDFGI_RAY_COUNT_MAX :: const RenderingServer.ENV_SDFGI_RAY_COUNT_MAX: EnvironmentSDFGIRayCount = 7
Represents the size of the [enum EnvironmentSDFGIRayCount] enum.

## ENV_SDFGI_CONVERGE_IN_5_FRAMES :: const RenderingServer.ENV_SDFGI_CONVERGE_IN_5_FRAMES: EnvironmentSDFGIFramesToConverge = 0
Converge SDFGI over 5 frames. This is the most responsive, but creates the most noisy result with a given ray count.

## ENV_SDFGI_CONVERGE_IN_10_FRAMES :: const RenderingServer.ENV_SDFGI_CONVERGE_IN_10_FRAMES: EnvironmentSDFGIFramesToConverge = 1
Configure SDFGI to fully converge over 10 frames.

## ENV_SDFGI_CONVERGE_IN_15_FRAMES :: const RenderingServer.ENV_SDFGI_CONVERGE_IN_15_FRAMES: EnvironmentSDFGIFramesToConverge = 2
Configure SDFGI to fully converge over 15 frames.

## ENV_SDFGI_CONVERGE_IN_20_FRAMES :: const RenderingServer.ENV_SDFGI_CONVERGE_IN_20_FRAMES: EnvironmentSDFGIFramesToConverge = 3
Configure SDFGI to fully converge over 20 frames.

## ENV_SDFGI_CONVERGE_IN_25_FRAMES :: const RenderingServer.ENV_SDFGI_CONVERGE_IN_25_FRAMES: EnvironmentSDFGIFramesToConverge = 4
Configure SDFGI to fully converge over 25 frames.

## ENV_SDFGI_CONVERGE_IN_30_FRAMES :: const RenderingServer.ENV_SDFGI_CONVERGE_IN_30_FRAMES: EnvironmentSDFGIFramesToConverge = 5
Configure SDFGI to fully converge over 30 frames. This is the least responsive, but creates the least noisy result with a given ray count.

## ENV_SDFGI_CONVERGE_MAX :: const RenderingServer.ENV_SDFGI_CONVERGE_MAX: EnvironmentSDFGIFramesToConverge = 6
Represents the size of the [enum EnvironmentSDFGIFramesToConverge] enum.

## ENV_SDFGI_UPDATE_LIGHT_IN_1_FRAME :: const RenderingServer.ENV_SDFGI_UPDATE_LIGHT_IN_1_FRAME: EnvironmentSDFGIFramesToUpdateLight = 0
Update indirect light from dynamic lights in SDFGI over 1 frame. This is the most responsive, but has the highest GPU requirements.

## ENV_SDFGI_UPDATE_LIGHT_IN_2_FRAMES :: const RenderingServer.ENV_SDFGI_UPDATE_LIGHT_IN_2_FRAMES: EnvironmentSDFGIFramesToUpdateLight = 1
Update indirect light from dynamic lights in SDFGI over 2 frames.

## ENV_SDFGI_UPDATE_LIGHT_IN_4_FRAMES :: const RenderingServer.ENV_SDFGI_UPDATE_LIGHT_IN_4_FRAMES: EnvironmentSDFGIFramesToUpdateLight = 2
Update indirect light from dynamic lights in SDFGI over 4 frames.

## ENV_SDFGI_UPDATE_LIGHT_IN_8_FRAMES :: const RenderingServer.ENV_SDFGI_UPDATE_LIGHT_IN_8_FRAMES: EnvironmentSDFGIFramesToUpdateLight = 3
Update indirect light from dynamic lights in SDFGI over 8 frames.

## ENV_SDFGI_UPDATE_LIGHT_IN_16_FRAMES :: const RenderingServer.ENV_SDFGI_UPDATE_LIGHT_IN_16_FRAMES: EnvironmentSDFGIFramesToUpdateLight = 4
Update indirect light from dynamic lights in SDFGI over 16 frames. This is the least responsive, but has the lowest GPU requirements.

## ENV_SDFGI_UPDATE_LIGHT_MAX :: const RenderingServer.ENV_SDFGI_UPDATE_LIGHT_MAX: EnvironmentSDFGIFramesToUpdateLight = 5
Represents the size of the [enum EnvironmentSDFGIFramesToUpdateLight] enum.

## SUB_SURFACE_SCATTERING_QUALITY_DISABLED :: const RenderingServer.SUB_SURFACE_SCATTERING_QUALITY_DISABLED: SubSurfaceScatteringQuality = 0
Disables subsurface scattering entirely, even on materials that have [member BaseMaterial3D.subsurf_scatter_enabled] set to [code]true[/code]. This has the lowest GPU requirements.

## SUB_SURFACE_SCATTERING_QUALITY_LOW :: const RenderingServer.SUB_SURFACE_SCATTERING_QUALITY_LOW: SubSurfaceScatteringQuality = 1
Low subsurface scattering quality.

## SUB_SURFACE_SCATTERING_QUALITY_MEDIUM :: const RenderingServer.SUB_SURFACE_SCATTERING_QUALITY_MEDIUM: SubSurfaceScatteringQuality = 2
Medium subsurface scattering quality.

## SUB_SURFACE_SCATTERING_QUALITY_HIGH :: const RenderingServer.SUB_SURFACE_SCATTERING_QUALITY_HIGH: SubSurfaceScatteringQuality = 3
High subsurface scattering quality. This has the highest GPU requirements.

## DOF_BOKEH_BOX :: const RenderingServer.DOF_BOKEH_BOX: DOFBokehShape = 0
Calculate the DOF blur using a box filter. The fastest option, but results in obvious lines in blur pattern.

## DOF_BOKEH_HEXAGON :: const RenderingServer.DOF_BOKEH_HEXAGON: DOFBokehShape = 1
Calculates DOF blur using a hexagon shaped filter.

## DOF_BOKEH_CIRCLE :: const RenderingServer.DOF_BOKEH_CIRCLE: DOFBokehShape = 2
Calculates DOF blur using a circle shaped filter. Best quality and most realistic, but slowest. Use only for areas where a lot of performance can be dedicated to post-processing (e.g. cutscenes).

## DOF_BLUR_QUALITY_VERY_LOW :: const RenderingServer.DOF_BLUR_QUALITY_VERY_LOW: DOFBlurQuality = 0
Lowest quality DOF blur. This is the fastest setting, but you may be able to see filtering artifacts.

## DOF_BLUR_QUALITY_LOW :: const RenderingServer.DOF_BLUR_QUALITY_LOW: DOFBlurQuality = 1
Low quality DOF blur.

## DOF_BLUR_QUALITY_MEDIUM :: const RenderingServer.DOF_BLUR_QUALITY_MEDIUM: DOFBlurQuality = 2
Medium quality DOF blur.

## DOF_BLUR_QUALITY_HIGH :: const RenderingServer.DOF_BLUR_QUALITY_HIGH: DOFBlurQuality = 3
Highest quality DOF blur. Results in the smoothest looking blur by taking the most samples, but is also significantly slower.

## INSTANCE_NONE :: const RenderingServer.INSTANCE_NONE: InstanceType = 0
The instance does not have a type.

## INSTANCE_MESH :: const RenderingServer.INSTANCE_MESH: InstanceType = 1
The instance is a mesh.

## INSTANCE_MULTIMESH :: const RenderingServer.INSTANCE_MULTIMESH: InstanceType = 2
The instance is a multimesh.

## INSTANCE_PARTICLES :: const RenderingServer.INSTANCE_PARTICLES: InstanceType = 3
The instance is a particle emitter.

## INSTANCE_PARTICLES_COLLISION :: const RenderingServer.INSTANCE_PARTICLES_COLLISION: InstanceType = 4
The instance is a GPUParticles collision shape.

## INSTANCE_LIGHT :: const RenderingServer.INSTANCE_LIGHT: InstanceType = 5
The instance is a light.

## INSTANCE_REFLECTION_PROBE :: const RenderingServer.INSTANCE_REFLECTION_PROBE: InstanceType = 6
The instance is a reflection probe.

## INSTANCE_DECAL :: const RenderingServer.INSTANCE_DECAL: InstanceType = 7
The instance is a decal.

## INSTANCE_VOXEL_GI :: const RenderingServer.INSTANCE_VOXEL_GI: InstanceType = 8
The instance is a VoxelGI.

## INSTANCE_LIGHTMAP :: const RenderingServer.INSTANCE_LIGHTMAP: InstanceType = 9
The instance is a lightmap.

## INSTANCE_OCCLUDER :: const RenderingServer.INSTANCE_OCCLUDER: InstanceType = 10
The instance is an occlusion culling occluder.

## INSTANCE_VISIBLITY_NOTIFIER :: const RenderingServer.INSTANCE_VISIBLITY_NOTIFIER: InstanceType = 11
The instance is a visible on-screen notifier.

## INSTANCE_FOG_VOLUME :: const RenderingServer.INSTANCE_FOG_VOLUME: InstanceType = 12
The instance is a fog volume.

## INSTANCE_MAX :: const RenderingServer.INSTANCE_MAX: InstanceType = 13
Represents the size of the [enum InstanceType] enum.

## INSTANCE_GEOMETRY_MASK :: const RenderingServer.INSTANCE_GEOMETRY_MASK: InstanceType = 14
A combination of the flags of geometry instances (mesh, multimesh, immediate and particles).

## INSTANCE_FLAG_USE_BAKED_LIGHT :: const RenderingServer.INSTANCE_FLAG_USE_BAKED_LIGHT: InstanceFlags = 0
Allows the instance to be used in baked lighting.

## INSTANCE_FLAG_USE_DYNAMIC_GI :: const RenderingServer.INSTANCE_FLAG_USE_DYNAMIC_GI: InstanceFlags = 1
Allows the instance to be used with dynamic global illumination.

## INSTANCE_FLAG_DRAW_NEXT_FRAME_IF_VISIBLE :: const RenderingServer.INSTANCE_FLAG_DRAW_NEXT_FRAME_IF_VISIBLE: InstanceFlags = 2
When set, manually requests to draw geometry on next frame.

## INSTANCE_FLAG_IGNORE_OCCLUSION_CULLING :: const RenderingServer.INSTANCE_FLAG_IGNORE_OCCLUSION_CULLING: InstanceFlags = 3
Always draw, even if the instance would be culled by occlusion culling. Does not affect view frustum culling.

## INSTANCE_FLAG_MAX :: const RenderingServer.INSTANCE_FLAG_MAX: InstanceFlags = 4
Represents the size of the [enum InstanceFlags] enum.

## SHADOW_CASTING_SETTING_OFF :: const RenderingServer.SHADOW_CASTING_SETTING_OFF: ShadowCastingSetting = 0
Disable shadows from this instance.

## SHADOW_CASTING_SETTING_ON :: const RenderingServer.SHADOW_CASTING_SETTING_ON: ShadowCastingSetting = 1
Cast shadows from this instance.

## SHADOW_CASTING_SETTING_DOUBLE_SIDED :: const RenderingServer.SHADOW_CASTING_SETTING_DOUBLE_SIDED: ShadowCastingSetting = 2
Disable backface culling when rendering the shadow of the object. This is slightly slower but may result in more correct shadows.

## SHADOW_CASTING_SETTING_SHADOWS_ONLY :: const RenderingServer.SHADOW_CASTING_SETTING_SHADOWS_ONLY: ShadowCastingSetting = 3
Only render the shadows from the object. The object itself will not be drawn.

## VISIBILITY_RANGE_FADE_DISABLED :: const RenderingServer.VISIBILITY_RANGE_FADE_DISABLED: VisibilityRangeFadeMode = 0
Disable visibility range fading for the given instance.

## VISIBILITY_RANGE_FADE_SELF :: const RenderingServer.VISIBILITY_RANGE_FADE_SELF: VisibilityRangeFadeMode = 1
Fade-out the given instance when it approaches its visibility range limits.

## VISIBILITY_RANGE_FADE_DEPENDENCIES :: const RenderingServer.VISIBILITY_RANGE_FADE_DEPENDENCIES: VisibilityRangeFadeMode = 2
Fade-in the given instance's dependencies when reaching its visibility range limits.

## BAKE_CHANNEL_ALBEDO_ALPHA :: const RenderingServer.BAKE_CHANNEL_ALBEDO_ALPHA: BakeChannels = 0
Index of [Image] in array of [Image]s returned by [method bake_render_uv2]. Image uses [constant Image.FORMAT_RGBA8] and contains albedo color in the [code].rgb[/code] channels and alpha in the [code].a[/code] channel.

## BAKE_CHANNEL_NORMAL :: const RenderingServer.BAKE_CHANNEL_NORMAL: BakeChannels = 1
Index of [Image] in array of [Image]s returned by [method bake_render_uv2]. Image uses [constant Image.FORMAT_RGBA8] and contains the per-pixel normal of the object in the [code].rgb[/code] channels and nothing in the [code].a[/code] channel. The per-pixel normal is encoded as [code]normal * 0.5 + 0.5[/code].

## BAKE_CHANNEL_ORM :: const RenderingServer.BAKE_CHANNEL_ORM: BakeChannels = 2
Index of [Image] in array of [Image]s returned by [method bake_render_uv2]. Image uses [constant Image.FORMAT_RGBA8] and contains ambient occlusion (from material and decals only) in the [code].r[/code] channel, roughness in the [code].g[/code] channel, metallic in the [code].b[/code] channel and sub surface scattering amount in the [code].a[/code] channel.

## BAKE_CHANNEL_EMISSION :: const RenderingServer.BAKE_CHANNEL_EMISSION: BakeChannels = 3
Index of [Image] in array of [Image]s returned by [method bake_render_uv2]. Image uses [constant Image.FORMAT_RGBAH] and contains emission color in the [code].rgb[/code] channels and nothing in the [code].a[/code] channel.

## CANVAS_TEXTURE_CHANNEL_DIFFUSE :: const RenderingServer.CANVAS_TEXTURE_CHANNEL_DIFFUSE: CanvasTextureChannel = 0
Diffuse canvas texture ([member CanvasTexture.diffuse_texture]).

## CANVAS_TEXTURE_CHANNEL_NORMAL :: const RenderingServer.CANVAS_TEXTURE_CHANNEL_NORMAL: CanvasTextureChannel = 1
Normal map canvas texture ([member CanvasTexture.normal_texture]).

## CANVAS_TEXTURE_CHANNEL_SPECULAR :: const RenderingServer.CANVAS_TEXTURE_CHANNEL_SPECULAR: CanvasTextureChannel = 2
Specular map canvas texture ([member CanvasTexture.specular_texture]).

## NINE_PATCH_STRETCH :: const RenderingServer.NINE_PATCH_STRETCH: NinePatchAxisMode = 0
The nine patch gets stretched where needed.

## NINE_PATCH_TILE :: const RenderingServer.NINE_PATCH_TILE: NinePatchAxisMode = 1
The nine patch gets filled with tiles where needed.

## NINE_PATCH_TILE_FIT :: const RenderingServer.NINE_PATCH_TILE_FIT: NinePatchAxisMode = 2
The nine patch gets filled with tiles where needed and stretches them a bit if needed.

## CANVAS_ITEM_TEXTURE_FILTER_DEFAULT :: const RenderingServer.CANVAS_ITEM_TEXTURE_FILTER_DEFAULT: CanvasItemTextureFilter = 0
Uses the default filter mode for this [Viewport].

## CANVAS_ITEM_TEXTURE_FILTER_NEAREST :: const RenderingServer.CANVAS_ITEM_TEXTURE_FILTER_NEAREST: CanvasItemTextureFilter = 1
The texture filter reads from the nearest pixel only. This makes the texture look pixelated from up close, and grainy from a distance (due to mipmaps not being sampled).

## CANVAS_ITEM_TEXTURE_FILTER_LINEAR :: const RenderingServer.CANVAS_ITEM_TEXTURE_FILTER_LINEAR: CanvasItemTextureFilter = 2
The texture filter blends between the nearest 4 pixels. This makes the texture look smooth from up close, and grainy from a distance (due to mipmaps not being sampled).

## CANVAS_ITEM_TEXTURE_FILTER_NEAREST_WITH_MIPMAPS :: const RenderingServer.CANVAS_ITEM_TEXTURE_FILTER_NEAREST_WITH_MIPMAPS: CanvasItemTextureFilter = 3
The texture filter reads from the nearest pixel and blends between the nearest 2 mipmaps (or uses the nearest mipmap if [member ProjectSettings.rendering/textures/default_filters/use_nearest_mipmap_filter] is [code]true[/code]). This makes the texture look pixelated from up close, and smooth from a distance.
Use this for non-pixel art textures that may be viewed at a low scale (e.g. due to [Camera2D] zoom or sprite scaling), as mipmaps are important to smooth out pixels that are smaller than on-screen pixels.

## CANVAS_ITEM_TEXTURE_FILTER_LINEAR_WITH_MIPMAPS :: const RenderingServer.CANVAS_ITEM_TEXTURE_FILTER_LINEAR_WITH_MIPMAPS: CanvasItemTextureFilter = 4
The texture filter blends between the nearest 4 pixels and between the nearest 2 mipmaps (or uses the nearest mipmap if [member ProjectSettings.rendering/textures/default_filters/use_nearest_mipmap_filter] is [code]true[/code]). This makes the texture look smooth from up close, and smooth from a distance.
Use this for non-pixel art textures that may be viewed at a low scale (e.g. due to [Camera2D] zoom or sprite scaling), as mipmaps are important to smooth out pixels that are smaller than on-screen pixels.

## CANVAS_ITEM_TEXTURE_FILTER_NEAREST_WITH_MIPMAPS_ANISOTROPIC :: const RenderingServer.CANVAS_ITEM_TEXTURE_FILTER_NEAREST_WITH_MIPMAPS_ANISOTROPIC: CanvasItemTextureFilter = 5
The texture filter reads from the nearest pixel and blends between 2 mipmaps (or uses the nearest mipmap if [member ProjectSettings.rendering/textures/default_filters/use_nearest_mipmap_filter] is [code]true[/code]) based on the angle between the surface and the camera view. This makes the texture look pixelated from up close, and smooth from a distance. Anisotropic filtering improves texture quality on surfaces that are almost in line with the camera, but is slightly slower. The anisotropic filtering level can be changed by adjusting [member ProjectSettings.rendering/textures/default_filters/anisotropic_filtering_level].
[b]Note:[/b] This texture filter is rarely useful in 2D projects. [constant CANVAS_ITEM_TEXTURE_FILTER_NEAREST_WITH_MIPMAPS] is usually more appropriate in this case.

## CANVAS_ITEM_TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC :: const RenderingServer.CANVAS_ITEM_TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC: CanvasItemTextureFilter = 6
The texture filter blends between the nearest 4 pixels and blends between 2 mipmaps (or uses the nearest mipmap if [member ProjectSettings.rendering/textures/default_filters/use_nearest_mipmap_filter] is [code]true[/code]) based on the angle between the surface and the camera view. This makes the texture look smooth from up close, and smooth from a distance. Anisotropic filtering improves texture quality on surfaces that are almost in line with the camera, but is slightly slower. The anisotropic filtering level can be changed by adjusting [member ProjectSettings.rendering/textures/default_filters/anisotropic_filtering_level].
[b]Note:[/b] This texture filter is rarely useful in 2D projects. [constant CANVAS_ITEM_TEXTURE_FILTER_LINEAR_WITH_MIPMAPS] is usually more appropriate in this case.

## CANVAS_ITEM_TEXTURE_FILTER_MAX :: const RenderingServer.CANVAS_ITEM_TEXTURE_FILTER_MAX: CanvasItemTextureFilter = 7
Max value for [enum CanvasItemTextureFilter] enum.

## CANVAS_ITEM_TEXTURE_REPEAT_DEFAULT :: const RenderingServer.CANVAS_ITEM_TEXTURE_REPEAT_DEFAULT: CanvasItemTextureRepeat = 0
Uses the default repeat mode for this [Viewport].

## CANVAS_ITEM_TEXTURE_REPEAT_DISABLED :: const RenderingServer.CANVAS_ITEM_TEXTURE_REPEAT_DISABLED: CanvasItemTextureRepeat = 1
Disables textures repeating. Instead, when reading UVs outside the 0-1 range, the value will be clamped to the edge of the texture, resulting in a stretched out look at the borders of the texture.

## CANVAS_ITEM_TEXTURE_REPEAT_ENABLED :: const RenderingServer.CANVAS_ITEM_TEXTURE_REPEAT_ENABLED: CanvasItemTextureRepeat = 2
Enables the texture to repeat when UV coordinates are outside the 0-1 range. If using one of the linear filtering modes, this can result in artifacts at the edges of a texture when the sampler filters across the edges of the texture.

## CANVAS_ITEM_TEXTURE_REPEAT_MIRROR :: const RenderingServer.CANVAS_ITEM_TEXTURE_REPEAT_MIRROR: CanvasItemTextureRepeat = 3
Flip the texture when repeating so that the edge lines up instead of abruptly changing.

## CANVAS_ITEM_TEXTURE_REPEAT_MAX :: const RenderingServer.CANVAS_ITEM_TEXTURE_REPEAT_MAX: CanvasItemTextureRepeat = 4
Max value for [enum CanvasItemTextureRepeat] enum.

## CANVAS_GROUP_MODE_DISABLED :: const RenderingServer.CANVAS_GROUP_MODE_DISABLED: CanvasGroupMode = 0
Child draws over parent and is not clipped.

## CANVAS_GROUP_MODE_CLIP_ONLY :: const RenderingServer.CANVAS_GROUP_MODE_CLIP_ONLY: CanvasGroupMode = 1
Parent is used for the purposes of clipping only. Child is clipped to the parent's visible area, parent is not drawn.

## CANVAS_GROUP_MODE_CLIP_AND_DRAW :: const RenderingServer.CANVAS_GROUP_MODE_CLIP_AND_DRAW: CanvasGroupMode = 2
Parent is used for clipping child, but parent is also drawn underneath child as normal before clipping child to its visible area.

## CANVAS_GROUP_MODE_TRANSPARENT :: const RenderingServer.CANVAS_GROUP_MODE_TRANSPARENT: CanvasGroupMode = 3

## CANVAS_LIGHT_MODE_POINT :: const RenderingServer.CANVAS_LIGHT_MODE_POINT: CanvasLightMode = 0
2D point light (see [PointLight2D]).

## CANVAS_LIGHT_MODE_DIRECTIONAL :: const RenderingServer.CANVAS_LIGHT_MODE_DIRECTIONAL: CanvasLightMode = 1
2D directional (sun/moon) light (see [DirectionalLight2D]).

## CANVAS_LIGHT_BLEND_MODE_ADD :: const RenderingServer.CANVAS_LIGHT_BLEND_MODE_ADD: CanvasLightBlendMode = 0
Adds light color additive to the canvas.

## CANVAS_LIGHT_BLEND_MODE_SUB :: const RenderingServer.CANVAS_LIGHT_BLEND_MODE_SUB: CanvasLightBlendMode = 1
Adds light color subtractive to the canvas.

## CANVAS_LIGHT_BLEND_MODE_MIX :: const RenderingServer.CANVAS_LIGHT_BLEND_MODE_MIX: CanvasLightBlendMode = 2
The light adds color depending on transparency.

## CANVAS_LIGHT_FILTER_NONE :: const RenderingServer.CANVAS_LIGHT_FILTER_NONE: CanvasLightShadowFilter = 0
Do not apply a filter to canvas light shadows.

## CANVAS_LIGHT_FILTER_PCF5 :: const RenderingServer.CANVAS_LIGHT_FILTER_PCF5: CanvasLightShadowFilter = 1
Use PCF5 filtering to filter canvas light shadows.

## CANVAS_LIGHT_FILTER_PCF13 :: const RenderingServer.CANVAS_LIGHT_FILTER_PCF13: CanvasLightShadowFilter = 2
Use PCF13 filtering to filter canvas light shadows.

## CANVAS_LIGHT_FILTER_MAX :: const RenderingServer.CANVAS_LIGHT_FILTER_MAX: CanvasLightShadowFilter = 3
Max value of the [enum CanvasLightShadowFilter] enum.

## CANVAS_OCCLUDER_POLYGON_CULL_DISABLED :: const RenderingServer.CANVAS_OCCLUDER_POLYGON_CULL_DISABLED: CanvasOccluderPolygonCullMode = 0
Culling of the canvas occluder is disabled.

## CANVAS_OCCLUDER_POLYGON_CULL_CLOCKWISE :: const RenderingServer.CANVAS_OCCLUDER_POLYGON_CULL_CLOCKWISE: CanvasOccluderPolygonCullMode = 1
Culling of the canvas occluder is clockwise.

## CANVAS_OCCLUDER_POLYGON_CULL_COUNTER_CLOCKWISE :: const RenderingServer.CANVAS_OCCLUDER_POLYGON_CULL_COUNTER_CLOCKWISE: CanvasOccluderPolygonCullMode = 2
Culling of the canvas occluder is counterclockwise.

## GLOBAL_VAR_TYPE_BOOL :: const RenderingServer.GLOBAL_VAR_TYPE_BOOL: GlobalShaderParameterType = 0
Boolean global shader parameter ([code]global uniform bool ...[/code]).

## GLOBAL_VAR_TYPE_BVEC2 :: const RenderingServer.GLOBAL_VAR_TYPE_BVEC2: GlobalShaderParameterType = 1
2-dimensional boolean vector global shader parameter ([code]global uniform bvec2 ...[/code]).

## GLOBAL_VAR_TYPE_BVEC3 :: const RenderingServer.GLOBAL_VAR_TYPE_BVEC3: GlobalShaderParameterType = 2
3-dimensional boolean vector global shader parameter ([code]global uniform bvec3 ...[/code]).

## GLOBAL_VAR_TYPE_BVEC4 :: const RenderingServer.GLOBAL_VAR_TYPE_BVEC4: GlobalShaderParameterType = 3
4-dimensional boolean vector global shader parameter ([code]global uniform bvec4 ...[/code]).

## GLOBAL_VAR_TYPE_INT :: const RenderingServer.GLOBAL_VAR_TYPE_INT: GlobalShaderParameterType = 4
Integer global shader parameter ([code]global uniform int ...[/code]).

## GLOBAL_VAR_TYPE_IVEC2 :: const RenderingServer.GLOBAL_VAR_TYPE_IVEC2: GlobalShaderParameterType = 5
2-dimensional integer vector global shader parameter ([code]global uniform ivec2 ...[/code]).

## GLOBAL_VAR_TYPE_IVEC3 :: const RenderingServer.GLOBAL_VAR_TYPE_IVEC3: GlobalShaderParameterType = 6
3-dimensional integer vector global shader parameter ([code]global uniform ivec3 ...[/code]).

## GLOBAL_VAR_TYPE_IVEC4 :: const RenderingServer.GLOBAL_VAR_TYPE_IVEC4: GlobalShaderParameterType = 7
4-dimensional integer vector global shader parameter ([code]global uniform ivec4 ...[/code]).

## GLOBAL_VAR_TYPE_RECT2I :: const RenderingServer.GLOBAL_VAR_TYPE_RECT2I: GlobalShaderParameterType = 8
2-dimensional integer rectangle global shader parameter ([code]global uniform ivec4 ...[/code]). Equivalent to [constant GLOBAL_VAR_TYPE_IVEC4] in shader code, but exposed as a [Rect2i] in the editor UI.

## GLOBAL_VAR_TYPE_UINT :: const RenderingServer.GLOBAL_VAR_TYPE_UINT: GlobalShaderParameterType = 9
Unsigned integer global shader parameter ([code]global uniform uint ...[/code]).

## GLOBAL_VAR_TYPE_UVEC2 :: const RenderingServer.GLOBAL_VAR_TYPE_UVEC2: GlobalShaderParameterType = 10
2-dimensional unsigned integer vector global shader parameter ([code]global uniform uvec2 ...[/code]).

## GLOBAL_VAR_TYPE_UVEC3 :: const RenderingServer.GLOBAL_VAR_TYPE_UVEC3: GlobalShaderParameterType = 11
3-dimensional unsigned integer vector global shader parameter ([code]global uniform uvec3 ...[/code]).

## GLOBAL_VAR_TYPE_UVEC4 :: const RenderingServer.GLOBAL_VAR_TYPE_UVEC4: GlobalShaderParameterType = 12
4-dimensional unsigned integer vector global shader parameter ([code]global uniform uvec4 ...[/code]).

## GLOBAL_VAR_TYPE_FLOAT :: const RenderingServer.GLOBAL_VAR_TYPE_FLOAT: GlobalShaderParameterType = 13
Single-precision floating-point global shader parameter ([code]global uniform float ...[/code]).

## GLOBAL_VAR_TYPE_VEC2 :: const RenderingServer.GLOBAL_VAR_TYPE_VEC2: GlobalShaderParameterType = 14
2-dimensional floating-point vector global shader parameter ([code]global uniform vec2 ...[/code]).

## GLOBAL_VAR_TYPE_VEC3 :: const RenderingServer.GLOBAL_VAR_TYPE_VEC3: GlobalShaderParameterType = 15
3-dimensional floating-point vector global shader parameter ([code]global uniform vec3 ...[/code]).

## GLOBAL_VAR_TYPE_VEC4 :: const RenderingServer.GLOBAL_VAR_TYPE_VEC4: GlobalShaderParameterType = 16
4-dimensional floating-point vector global shader parameter ([code]global uniform vec4 ...[/code]).

## GLOBAL_VAR_TYPE_COLOR :: const RenderingServer.GLOBAL_VAR_TYPE_COLOR: GlobalShaderParameterType = 17
Color global shader parameter ([code]global uniform vec4 ...[/code]). Equivalent to [constant GLOBAL_VAR_TYPE_VEC4] in shader code, but exposed as a [Color] in the editor UI.

## GLOBAL_VAR_TYPE_RECT2 :: const RenderingServer.GLOBAL_VAR_TYPE_RECT2: GlobalShaderParameterType = 18
2-dimensional floating-point rectangle global shader parameter ([code]global uniform vec4 ...[/code]). Equivalent to [constant GLOBAL_VAR_TYPE_VEC4] in shader code, but exposed as a [Rect2] in the editor UI.

## GLOBAL_VAR_TYPE_MAT2 :: const RenderingServer.GLOBAL_VAR_TYPE_MAT2: GlobalShaderParameterType = 19
2×2 matrix global shader parameter ([code]global uniform mat2 ...[/code]). Exposed as a [PackedInt32Array] in the editor UI.

## GLOBAL_VAR_TYPE_MAT3 :: const RenderingServer.GLOBAL_VAR_TYPE_MAT3: GlobalShaderParameterType = 20
3×3 matrix global shader parameter ([code]global uniform mat3 ...[/code]). Exposed as a [Basis] in the editor UI.

## GLOBAL_VAR_TYPE_MAT4 :: const RenderingServer.GLOBAL_VAR_TYPE_MAT4: GlobalShaderParameterType = 21
4×4 matrix global shader parameter ([code]global uniform mat4 ...[/code]). Exposed as a [Projection] in the editor UI.

## GLOBAL_VAR_TYPE_TRANSFORM_2D :: const RenderingServer.GLOBAL_VAR_TYPE_TRANSFORM_2D: GlobalShaderParameterType = 22
2-dimensional transform global shader parameter ([code]global uniform mat2x3 ...[/code]). Exposed as a [Transform2D] in the editor UI.

## GLOBAL_VAR_TYPE_TRANSFORM :: const RenderingServer.GLOBAL_VAR_TYPE_TRANSFORM: GlobalShaderParameterType = 23
3-dimensional transform global shader parameter ([code]global uniform mat3x4 ...[/code]). Exposed as a [Transform3D] in the editor UI.

## GLOBAL_VAR_TYPE_SAMPLER2D :: const RenderingServer.GLOBAL_VAR_TYPE_SAMPLER2D: GlobalShaderParameterType = 24
2D sampler global shader parameter ([code]global uniform sampler2D ...[/code]). Exposed as a [Texture2D] in the editor UI.

## GLOBAL_VAR_TYPE_SAMPLER2DARRAY :: const RenderingServer.GLOBAL_VAR_TYPE_SAMPLER2DARRAY: GlobalShaderParameterType = 25
2D sampler array global shader parameter ([code]global uniform sampler2DArray ...[/code]). Exposed as a [Texture2DArray] in the editor UI.

## GLOBAL_VAR_TYPE_SAMPLER3D :: const RenderingServer.GLOBAL_VAR_TYPE_SAMPLER3D: GlobalShaderParameterType = 26
3D sampler global shader parameter ([code]global uniform sampler3D ...[/code]). Exposed as a [Texture3D] in the editor UI.

## GLOBAL_VAR_TYPE_SAMPLERCUBE :: const RenderingServer.GLOBAL_VAR_TYPE_SAMPLERCUBE: GlobalShaderParameterType = 27
Cubemap sampler global shader parameter ([code]global uniform samplerCube ...[/code]). Exposed as a [Cubemap] in the editor UI.

## GLOBAL_VAR_TYPE_SAMPLEREXT :: const RenderingServer.GLOBAL_VAR_TYPE_SAMPLEREXT: GlobalShaderParameterType = 28
External sampler global shader parameter ([code]global uniform samplerExternalOES ...[/code]). Exposed as an [ExternalTexture] in the editor UI.

## GLOBAL_VAR_TYPE_MAX :: const RenderingServer.GLOBAL_VAR_TYPE_MAX: GlobalShaderParameterType = 29
Represents the size of the [enum GlobalShaderParameterType] enum.

## RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME :: const RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME: RenderingInfo = 0
Number of objects rendered in the current 3D scene. This varies depending on camera position and rotation.

## RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME :: const RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME: RenderingInfo = 1
Number of points, lines, or triangles rendered in the current 3D scene. This varies depending on camera position and rotation.

## RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME :: const RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME: RenderingInfo = 2
Number of draw calls performed to render in the current 3D scene. This varies depending on camera position and rotation.

## RENDERING_INFO_TEXTURE_MEM_USED :: const RenderingServer.RENDERING_INFO_TEXTURE_MEM_USED: RenderingInfo = 3
Texture memory used (in bytes).

## RENDERING_INFO_BUFFER_MEM_USED :: const RenderingServer.RENDERING_INFO_BUFFER_MEM_USED: RenderingInfo = 4
Buffer memory used (in bytes). This includes vertex data, uniform buffers, and many miscellaneous buffer types used internally.

## RENDERING_INFO_VIDEO_MEM_USED :: const RenderingServer.RENDERING_INFO_VIDEO_MEM_USED: RenderingInfo = 5
Video memory used (in bytes). When using the Forward+ or Mobile renderers, this is always greater than the sum of [constant RENDERING_INFO_TEXTURE_MEM_USED] and [constant RENDERING_INFO_BUFFER_MEM_USED], since there is miscellaneous data not accounted for by those two metrics. When using the Compatibility renderer, this is equal to the sum of [constant RENDERING_INFO_TEXTURE_MEM_USED] and [constant RENDERING_INFO_BUFFER_MEM_USED].

## RENDERING_INFO_PIPELINE_COMPILATIONS_CANVAS :: const RenderingServer.RENDERING_INFO_PIPELINE_COMPILATIONS_CANVAS: RenderingInfo = 6
Number of pipeline compilations that were triggered by the 2D canvas renderer.

## RENDERING_INFO_PIPELINE_COMPILATIONS_MESH :: const RenderingServer.RENDERING_INFO_PIPELINE_COMPILATIONS_MESH: RenderingInfo = 7
Number of pipeline compilations that were triggered by loading meshes. These compilations will show up as longer loading times the first time a user runs the game and the pipeline is required.

## RENDERING_INFO_PIPELINE_COMPILATIONS_SURFACE :: const RenderingServer.RENDERING_INFO_PIPELINE_COMPILATIONS_SURFACE: RenderingInfo = 8
Number of pipeline compilations that were triggered by building the surface cache before rendering the scene. These compilations will show up as a stutter when loading a scene the first time a user runs the game and the pipeline is required.

## RENDERING_INFO_PIPELINE_COMPILATIONS_DRAW :: const RenderingServer.RENDERING_INFO_PIPELINE_COMPILATIONS_DRAW: RenderingInfo = 9
Number of pipeline compilations that were triggered while drawing the scene. These compilations will show up as stutters during gameplay the first time a user runs the game and the pipeline is required.

## RENDERING_INFO_PIPELINE_COMPILATIONS_SPECIALIZATION :: const RenderingServer.RENDERING_INFO_PIPELINE_COMPILATIONS_SPECIALIZATION: RenderingInfo = 10
Number of pipeline compilations that were triggered to optimize the current scene. These compilations are done in the background and should not cause any stutters whatsoever.

## PIPELINE_SOURCE_CANVAS :: const RenderingServer.PIPELINE_SOURCE_CANVAS: PipelineSource = 0
Pipeline compilation that was triggered by the 2D canvas renderer.

## PIPELINE_SOURCE_MESH :: const RenderingServer.PIPELINE_SOURCE_MESH: PipelineSource = 1
Pipeline compilation that was triggered by loading a mesh.

## PIPELINE_SOURCE_SURFACE :: const RenderingServer.PIPELINE_SOURCE_SURFACE: PipelineSource = 2
Pipeline compilation that was triggered by building the surface cache before rendering the scene.

## PIPELINE_SOURCE_DRAW :: const RenderingServer.PIPELINE_SOURCE_DRAW: PipelineSource = 3
Pipeline compilation that was triggered while drawing the scene.

## PIPELINE_SOURCE_SPECIALIZATION :: const RenderingServer.PIPELINE_SOURCE_SPECIALIZATION: PipelineSource = 4
Pipeline compilation that was triggered to optimize the current scene.

## PIPELINE_SOURCE_MAX :: const RenderingServer.PIPELINE_SOURCE_MAX: PipelineSource = 5
Represents the size of the [enum PipelineSource] enum.

## SPLASH_STRETCH_MODE_DISABLED :: const RenderingServer.SPLASH_STRETCH_MODE_DISABLED: SplashStretchMode = 0
No stretching is applied.

## SPLASH_STRETCH_MODE_KEEP :: const RenderingServer.SPLASH_STRETCH_MODE_KEEP: SplashStretchMode = 1
Stretches image to fullscreen while preserving aspect ratio.

## SPLASH_STRETCH_MODE_KEEP_WIDTH :: const RenderingServer.SPLASH_STRETCH_MODE_KEEP_WIDTH: SplashStretchMode = 2
Stretches the height of the image based on the width of the screen.

## SPLASH_STRETCH_MODE_KEEP_HEIGHT :: const RenderingServer.SPLASH_STRETCH_MODE_KEEP_HEIGHT: SplashStretchMode = 3
Stretches the width of the image based on the height of the screen.

## SPLASH_STRETCH_MODE_COVER :: const RenderingServer.SPLASH_STRETCH_MODE_COVER: SplashStretchMode = 4
Stretches the image to cover the entire screen while preserving aspect ratio.

## SPLASH_STRETCH_MODE_IGNORE :: const RenderingServer.SPLASH_STRETCH_MODE_IGNORE: SplashStretchMode = 5
Stretches the image to cover the entire screen but doesn't preserve aspect ratio.

## FEATURE_SHADERS :: const RenderingServer.FEATURE_SHADERS: Features = 0

## FEATURE_MULTITHREADED :: const RenderingServer.FEATURE_MULTITHREADED: Features = 1

## render_loop_enabled :: var RenderingServer.render_loop_enabled: bool
If [code]false[/code], disables rendering completely, but the engine logic is still being processed. You can call [method force_draw] to draw a frame even with rendering disabled.

## area_light_create :: func RenderingServer.area_light_create() -> RID
Creates a new area light and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID can be used in most [code]light_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
To place in a scene, attach this area light to an instance using [method instance_set_base] using the returned RID.
[b]Note:[/b] The equivalent node is [AreaLight3D].

## bake_render_uv2 :: func RenderingServer.bake_render_uv2(base: RID, material_overrides: RID[], image_size: Vector2i) -> Image[]
Bakes the material data of the Mesh passed in the [param base] parameter with optional [param material_overrides] to a set of [Image]s of size [param image_size]. Returns an array of [Image]s containing material properties as specified in [enum BakeChannels].

### base :: RID

### material_overrides :: RID[]

### image_size :: Vector2i

## call_on_render_thread :: func RenderingServer.call_on_render_thread(callable: Callable) -> void
As the RenderingServer actual logic may run on a separate thread, accessing its internals from the main (or any other) thread will result in errors. To make it easier to run code that can safely access the rendering internals (such as [RenderingDevice] and similar RD classes), push a callable via this function so it will be executed on the render thread.

### callable :: Callable

## camera_attributes_create :: func RenderingServer.camera_attributes_create() -> RID
Creates a camera attributes object and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]camera_attributes_[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent resource is [CameraAttributes].

## camera_attributes_set_auto_exposure :: func RenderingServer.camera_attributes_set_auto_exposure(camera_attributes: RID, enable: bool, min_sensitivity: float, max_sensitivity: float, speed: float, scale: float) -> void
Sets the parameters to use with the auto-exposure effect. These parameters take on the same meaning as their counterparts in [CameraAttributes] and [CameraAttributesPractical].

### camera_attributes :: RID

### enable :: bool

### min_sensitivity :: float

### max_sensitivity :: float

### speed :: float

### scale :: float

## camera_attributes_set_dof_blur :: func RenderingServer.camera_attributes_set_dof_blur(camera_attributes: RID, far_enable: bool, far_distance: float, far_transition: float, near_enable: bool, near_distance: float, near_transition: float, amount: float) -> void
Sets the parameters to use with the DOF blur effect. These parameters take on the same meaning as their counterparts in [CameraAttributesPractical].

### camera_attributes :: RID

### far_enable :: bool

### far_distance :: float

### far_transition :: float

### near_enable :: bool

### near_distance :: float

### near_transition :: float

### amount :: float

## camera_attributes_set_dof_blur_bokeh_shape :: func RenderingServer.camera_attributes_set_dof_blur_bokeh_shape(shape: int) -> void
Sets the shape of the DOF bokeh pattern to [param shape]. Different shapes may be used to achieve artistic effect, or to meet performance targets.

### shape :: int

## camera_attributes_set_dof_blur_quality :: func RenderingServer.camera_attributes_set_dof_blur_quality(quality: int, use_jitter: bool) -> void
Sets the quality level of the DOF blur effect to [param quality]. [param use_jitter] can be used to jitter samples taken during the blur pass to hide artifacts at the cost of looking more fuzzy.

### quality :: int

### use_jitter :: bool

## camera_attributes_set_exposure :: func RenderingServer.camera_attributes_set_exposure(camera_attributes: RID, multiplier: float, normalization: float) -> void
Sets the exposure values that will be used by the renderers. The normalization amount is used to bake a given Exposure Value (EV) into rendering calculations to reduce the dynamic range of the scene.
The normalization factor can be calculated from exposure value (EV100) as follows:
[codeblock]
func get_exposure_normalization(ev100: float):
	return 1.0 / (pow(2.0, ev100) * 1.2)
[/codeblock]
The exposure value can be calculated from aperture (in f-stops), shutter speed (in seconds), and sensitivity (in ISO) as follows:
[codeblock]
func get_exposure(aperture: float, shutter_speed: float, sensitivity: float):
	return log((aperture * aperture) / shutter_speed * (100.0 / sensitivity)) / log(2)
[/codeblock]

### camera_attributes :: RID

### multiplier :: float

### normalization :: float

## camera_create :: func RenderingServer.camera_create() -> RID
Creates a 3D camera and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]camera_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent node is [Camera3D].

## camera_set_camera_attributes :: func RenderingServer.camera_set_camera_attributes(camera: RID, effects: RID) -> void
Sets the camera_attributes created with [method camera_attributes_create] to the given camera.

### camera :: RID

### effects :: RID

## camera_set_compositor :: func RenderingServer.camera_set_compositor(camera: RID, compositor: RID) -> void
Sets the compositor used by this camera. Equivalent to [member Camera3D.compositor].

### camera :: RID

### compositor :: RID

## camera_set_cull_mask :: func RenderingServer.camera_set_cull_mask(camera: RID, layers: int) -> void
Sets the cull mask associated with this camera. The cull mask describes which 3D layers are rendered by this camera. Equivalent to [member Camera3D.cull_mask].

### camera :: RID

### layers :: int

## camera_set_environment :: func RenderingServer.camera_set_environment(camera: RID, env: RID) -> void
Sets the environment used by this camera. Equivalent to [member Camera3D.environment].

### camera :: RID

### env :: RID

## camera_set_frustum :: func RenderingServer.camera_set_frustum(camera: RID, size: float, offset: Vector2, z_near: float, z_far: float) -> void
Sets camera to use frustum projection. This mode allows adjusting the [param offset] argument to create "tilted frustum" effects.

### camera :: RID

### size :: float

### offset :: Vector2

### z_near :: float

### z_far :: float

## camera_set_orthogonal :: func RenderingServer.camera_set_orthogonal(camera: RID, size: float, z_near: float, z_far: float) -> void
Sets camera to use orthogonal projection, also known as orthographic projection. Objects remain the same size on the screen no matter how far away they are.

### camera :: RID

### size :: float

### z_near :: float

### z_far :: float

## camera_set_perspective :: func RenderingServer.camera_set_perspective(camera: RID, fovy_degrees: float, z_near: float, z_far: float) -> void
Sets camera to use perspective projection. Objects on the screen becomes smaller when they are far away.

### camera :: RID

### fovy_degrees :: float

### z_near :: float

### z_far :: float

## camera_set_transform :: func RenderingServer.camera_set_transform(camera: RID, transform: Transform3D) -> void
Sets [Transform3D] of camera.

### camera :: RID

### transform :: Transform3D

## camera_set_use_vertical_aspect :: func RenderingServer.camera_set_use_vertical_aspect(camera: RID, enable: bool) -> void
If [code]true[/code], preserves the horizontal aspect ratio which is equivalent to [constant Camera3D.KEEP_WIDTH]. If [code]false[/code], preserves the vertical aspect ratio which is equivalent to [constant Camera3D.KEEP_HEIGHT].

### camera :: RID

### enable :: bool

## canvas_create :: func RenderingServer.canvas_create() -> RID
Creates a canvas and returns the assigned [RID]. It can be accessed with the RID that is returned. This RID will be used in all [code]canvas_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
Canvas has no [Resource] or [Node] equivalent.

## canvas_item_add_animation_slice :: func RenderingServer.canvas_item_add_animation_slice(item: RID, animation_length: float, slice_begin: float, slice_end: float, offset: float = 0.0) -> void
Subsequent drawing commands will be ignored unless they fall within the specified animation slice. This is a faster way to implement animations that loop on background rather than redrawing constantly.

### item :: RID

### animation_length :: float

### slice_begin :: float

### slice_end :: float

### offset :: float

## canvas_item_add_circle :: func RenderingServer.canvas_item_add_circle(item: RID, pos: Vector2, radius: float, color: Color, antialiased: bool = false) -> void
Draws a circle on the [CanvasItem] pointed to by the [param item] [RID]. See also [method CanvasItem.draw_circle].

### item :: RID

### pos :: Vector2

### radius :: float

### color :: Color

### antialiased :: bool

## canvas_item_add_clip_ignore :: func RenderingServer.canvas_item_add_clip_ignore(item: RID, ignore: bool) -> void
If [param ignore] is [code]true[/code], ignore clipping on items drawn with this canvas item until this is called again with [param ignore] set to [code]false[/code].

### item :: RID

### ignore :: bool

## canvas_item_add_ellipse :: func RenderingServer.canvas_item_add_ellipse(item: RID, pos: Vector2, major: float, minor: float, color: Color, antialiased: bool = false) -> void
Draws an ellipse with semi-major axis [param major] and semi-minor axis [param minor] on the [CanvasItem] pointed to by the [param item] [RID]. See also [method CanvasItem.draw_ellipse].

### item :: RID

### pos :: Vector2

### major :: float

### minor :: float

### color :: Color

### antialiased :: bool

## canvas_item_add_lcd_texture_rect_region :: func RenderingServer.canvas_item_add_lcd_texture_rect_region(item: RID, rect: Rect2, texture: RID, src_rect: Rect2, modulate: Color) -> void
See also [method CanvasItem.draw_lcd_texture_rect_region].

### item :: RID

### rect :: Rect2

### texture :: RID

### src_rect :: Rect2

### modulate :: Color

## canvas_item_add_line :: func RenderingServer.canvas_item_add_line(item: RID, from: Vector2, to: Vector2, color: Color, width: float = -1.0, antialiased: bool = false) -> void
Draws a line on the [CanvasItem] pointed to by the [param item] [RID]. See also [method CanvasItem.draw_line].

### item :: RID

### from :: Vector2

### to :: Vector2

### color :: Color

### width :: float

### antialiased :: bool

## canvas_item_add_mesh :: func RenderingServer.canvas_item_add_mesh(item: RID, mesh: RID, transform: Transform2D = Transform2D(1, 0, 0, 1, 0, 0), modulate: Color = Color(1, 1, 1, 1), texture: RID = RID()) -> void
Draws a mesh created with [method mesh_create] with given [param transform], [param modulate] color, and [param texture]. This is used internally by [MeshInstance2D].

### item :: RID

### mesh :: RID

### transform :: Transform2D

### modulate :: Color

### texture :: RID

## canvas_item_add_msdf_texture_rect_region :: func RenderingServer.canvas_item_add_msdf_texture_rect_region(item: RID, rect: Rect2, texture: RID, src_rect: Rect2, modulate: Color = Color(1, 1, 1, 1), outline_size: int = 0, px_range: float = 1.0, scale: float = 1.0) -> void
See also [method CanvasItem.draw_msdf_texture_rect_region].

### item :: RID

### rect :: Rect2

### texture :: RID

### src_rect :: Rect2

### modulate :: Color

### outline_size :: int

### px_range :: float

### scale :: float

## canvas_item_add_multiline :: func RenderingServer.canvas_item_add_multiline(item: RID, points: PackedVector2Array, colors: PackedColorArray, width: float = -1.0, antialiased: bool = false) -> void
Draws a 2D multiline on the [CanvasItem] pointed to by the [param item] [RID]. See also [method CanvasItem.draw_multiline] and [method CanvasItem.draw_multiline_colors].

### item :: RID

### points :: PackedVector2Array

### colors :: PackedColorArray

### width :: float

### antialiased :: bool

## canvas_item_add_multimesh :: func RenderingServer.canvas_item_add_multimesh(item: RID, mesh: RID, texture: RID = RID()) -> void
Draws a 2D [MultiMesh] on the [CanvasItem] pointed to by the [param item] [RID]. See also [method CanvasItem.draw_multimesh].

### item :: RID

### mesh :: RID

### texture :: RID

## canvas_item_add_nine_patch :: func RenderingServer.canvas_item_add_nine_patch(item: RID, rect: Rect2, source: Rect2, texture: RID, topleft: Vector2, bottomright: Vector2, x_axis_mode: int = 0, y_axis_mode: int = 0, draw_center: bool = true, modulate: Color = Color(1, 1, 1, 1)) -> void
Draws a nine-patch rectangle on the [CanvasItem] pointed to by the [param item] [RID].

### item :: RID

### rect :: Rect2

### source :: Rect2

### texture :: RID

### topleft :: Vector2

### bottomright :: Vector2

### x_axis_mode :: int

### y_axis_mode :: int

### draw_center :: bool

### modulate :: Color

## canvas_item_add_particles :: func RenderingServer.canvas_item_add_particles(item: RID, particles: RID, texture: RID) -> void
Draws particles on the [CanvasItem] pointed to by the [param item] [RID].

### item :: RID

### particles :: RID

### texture :: RID

## canvas_item_add_polygon :: func RenderingServer.canvas_item_add_polygon(item: RID, points: PackedVector2Array, colors: PackedColorArray, uvs: PackedVector2Array = PackedVector2Array(), texture: RID = RID()) -> void
Draws a 2D polygon on the [CanvasItem] pointed to by the [param item] [RID]. If you need more flexibility (such as being able to use bones), use [method canvas_item_add_triangle_array] instead. See also [method CanvasItem.draw_polygon].
[b]Note:[/b] If you frequently redraw the same polygon with a large number of vertices, consider pre-calculating the triangulation with [method Geometry2D.triangulate_polygon] and using [method CanvasItem.draw_mesh], [method CanvasItem.draw_multimesh], or [method canvas_item_add_triangle_array].

### item :: RID

### points :: PackedVector2Array

### colors :: PackedColorArray

### uvs :: PackedVector2Array

### texture :: RID

## canvas_item_add_polyline :: func RenderingServer.canvas_item_add_polyline(item: RID, points: PackedVector2Array, colors: PackedColorArray, width: float = -1.0, antialiased: bool = false) -> void
Draws a 2D polyline on the [CanvasItem] pointed to by the [param item] [RID]. See also [method CanvasItem.draw_polyline] and [method CanvasItem.draw_polyline_colors].

### item :: RID

### points :: PackedVector2Array

### colors :: PackedColorArray

### width :: float

### antialiased :: bool

## canvas_item_add_primitive :: func RenderingServer.canvas_item_add_primitive(item: RID, points: PackedVector2Array, colors: PackedColorArray, uvs: PackedVector2Array, texture: RID) -> void
Draws a 2D primitive on the [CanvasItem] pointed to by the [param item] [RID]. See also [method CanvasItem.draw_primitive].

### item :: RID

### points :: PackedVector2Array

### colors :: PackedColorArray

### uvs :: PackedVector2Array

### texture :: RID

## canvas_item_add_rect :: func RenderingServer.canvas_item_add_rect(item: RID, rect: Rect2, color: Color, antialiased: bool = false) -> void
Draws a rectangle on the [CanvasItem] pointed to by the [param item] [RID]. See also [method CanvasItem.draw_rect].

### item :: RID

### rect :: Rect2

### color :: Color

### antialiased :: bool

## canvas_item_add_set_transform :: func RenderingServer.canvas_item_add_set_transform(item: RID, transform: Transform2D) -> void
Sets a [Transform2D] that will be used to transform subsequent canvas item commands.

### item :: RID

### transform :: Transform2D

## canvas_item_add_texture_rect :: func RenderingServer.canvas_item_add_texture_rect(item: RID, rect: Rect2, texture: RID, tile: bool = false, modulate: Color = Color(1, 1, 1, 1), transpose: bool = false) -> void
Draws a 2D textured rectangle on the [CanvasItem] pointed to by the [param item] [RID]. See also [method CanvasItem.draw_texture_rect] and [method Texture2D.draw_rect].

### item :: RID

### rect :: Rect2

### texture :: RID

### tile :: bool

### modulate :: Color

### transpose :: bool

## canvas_item_add_texture_rect_region :: func RenderingServer.canvas_item_add_texture_rect_region(item: RID, rect: Rect2, texture: RID, src_rect: Rect2, modulate: Color = Color(1, 1, 1, 1), transpose: bool = false, clip_uv: bool = true) -> void
Draws the specified region of a 2D textured rectangle on the [CanvasItem] pointed to by the [param item] [RID]. See also [method CanvasItem.draw_texture_rect_region] and [method Texture2D.draw_rect_region].

### item :: RID

### rect :: Rect2

### texture :: RID

### src_rect :: Rect2

### modulate :: Color

### transpose :: bool

### clip_uv :: bool

## canvas_item_add_triangle_array :: func RenderingServer.canvas_item_add_triangle_array(item: RID, indices: PackedInt32Array, points: PackedVector2Array, colors: PackedColorArray, uvs: PackedVector2Array = PackedVector2Array(), bones: PackedInt32Array = PackedInt32Array(), weights: PackedFloat32Array = PackedFloat32Array(), texture: RID = RID(), count: int = -1) -> void
Draws a triangle array on the [CanvasItem] pointed to by the [param item] [RID]. This is internally used by [Line2D] and [StyleBoxFlat] for rendering. [method canvas_item_add_triangle_array] is highly flexible, but more complex to use than [method canvas_item_add_polygon].
[b]Note:[/b] If [param count] is set to a non-negative value, only the first [code]count * 3[/code] indices (corresponding to [code skip-lint]count[/code] triangles) will be drawn. Otherwise, all indices are drawn.

### item :: RID

### indices :: PackedInt32Array

### points :: PackedVector2Array

### colors :: PackedColorArray

### uvs :: PackedVector2Array

### bones :: PackedInt32Array

### weights :: PackedFloat32Array

### texture :: RID

### count :: int

## canvas_item_attach_skeleton :: func RenderingServer.canvas_item_attach_skeleton(item: RID, skeleton: RID) -> void
Attaches a skeleton to the [CanvasItem]. Removes the previous skeleton.

### item :: RID

### skeleton :: RID

## canvas_item_clear :: func RenderingServer.canvas_item_clear(item: RID) -> void
Clears the [CanvasItem] and removes all commands in it.

### item :: RID

## canvas_item_create :: func RenderingServer.canvas_item_create() -> RID
Creates a new CanvasItem instance and returns its [RID]. It can be accessed with the RID that is returned. This RID will be used in all [code]canvas_item_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent node is [CanvasItem].

## canvas_item_get_instance_shader_parameter :: func RenderingServer.canvas_item_get_instance_shader_parameter(instance: RID, parameter: StringName) -> Variant
Returns the value of the per-instance shader uniform from the specified canvas item instance. Equivalent to [method CanvasItem.get_instance_shader_parameter].

### instance :: RID

### parameter :: StringName

## canvas_item_get_instance_shader_parameter_default_value :: func RenderingServer.canvas_item_get_instance_shader_parameter_default_value(instance: RID, parameter: StringName) -> Variant
Returns the default value of the per-instance shader uniform from the specified canvas item instance. Equivalent to [method CanvasItem.get_instance_shader_parameter].

### instance :: RID

### parameter :: StringName

## canvas_item_get_instance_shader_parameter_list :: func RenderingServer.canvas_item_get_instance_shader_parameter_list(instance: RID) -> Dictionary[]
Returns a dictionary of per-instance shader uniform names of the per-instance shader uniform from the specified canvas item instance.
The returned dictionary is in PropertyInfo format, with the keys [code]name[/code], [code]class_name[/code], [code]type[/code], [code]hint[/code], [code]hint_string[/code], and [code]usage[/code].

### instance :: RID

## canvas_item_reset_physics_interpolation :: func RenderingServer.canvas_item_reset_physics_interpolation(item: RID) -> void
Prevents physics interpolation for the current physics tick.
This is useful when moving a canvas item to a new location, to give an instantaneous change rather than interpolation from the previous location.

### item :: RID

## canvas_item_set_canvas_group_mode :: func RenderingServer.canvas_item_set_canvas_group_mode(item: RID, mode: int, clear_margin: float = 5.0, fit_empty: bool = false, fit_margin: float = 0.0, blur_mipmaps: bool = false) -> void
Sets the canvas group mode used during 2D rendering for the canvas item specified by the [param item] RID. For faster but more limited clipping, use [method canvas_item_set_clip] instead.
[b]Note:[/b] The equivalent node functionality is found in [CanvasGroup] and [member CanvasItem.clip_children].

### item :: RID

### mode :: int

### clear_margin :: float

### fit_empty :: bool

### fit_margin :: float

### blur_mipmaps :: bool

## canvas_item_set_clip :: func RenderingServer.canvas_item_set_clip(item: RID, clip: bool) -> void
If [param clip] is [code]true[/code], makes the canvas item specified by the [param item] RID not draw anything outside of its rect's coordinates. This clipping is fast, but works only with axis-aligned rectangles. This means that rotation is ignored by the clipping rectangle. For more advanced clipping shapes, use [method canvas_item_set_canvas_group_mode] instead.
[b]Note:[/b] The equivalent node functionality is found in [member Label.clip_text], [RichTextLabel] (always enabled) and more.

### item :: RID

### clip :: bool

## canvas_item_set_copy_to_backbuffer :: func RenderingServer.canvas_item_set_copy_to_backbuffer(item: RID, enabled: bool, rect: Rect2) -> void
Sets the [CanvasItem] to copy a rect to the backbuffer.

### item :: RID

### enabled :: bool

### rect :: Rect2

## canvas_item_set_custom_rect :: func RenderingServer.canvas_item_set_custom_rect(item: RID, use_custom_rect: bool, rect: Rect2 = Rect2(0, 0, 0, 0)) -> void
If [param use_custom_rect] is [code]true[/code], sets the custom visibility rectangle (used for culling) to [param rect] for the canvas item specified by [param item]. Setting a custom visibility rect can reduce CPU load when drawing lots of 2D instances. If [param use_custom_rect] is [code]false[/code], automatically computes a visibility rectangle based on the canvas item's draw commands.

### item :: RID

### use_custom_rect :: bool

### rect :: Rect2

## canvas_item_set_default_texture_filter :: func RenderingServer.canvas_item_set_default_texture_filter(item: RID, filter: int) -> void
Sets the default texture filter mode for the canvas item specified by the [param item] RID. Equivalent to [member CanvasItem.texture_filter].

### item :: RID

### filter :: int

## canvas_item_set_default_texture_repeat :: func RenderingServer.canvas_item_set_default_texture_repeat(item: RID, repeat: int) -> void
Sets the default texture repeat mode for the canvas item specified by the [param item] RID. Equivalent to [member CanvasItem.texture_repeat].

### item :: RID

### repeat :: int

## canvas_item_set_distance_field_mode :: func RenderingServer.canvas_item_set_distance_field_mode(item: RID, enabled: bool) -> void
If [param enabled] is [code]true[/code], enables multichannel signed distance field rendering mode for the canvas item specified by the [param item] RID. This is meant to be used for font rendering, or with specially generated images using [url=https://github.com/Chlumsky/msdfgen]msdfgen[/url].

### item :: RID

### enabled :: bool

## canvas_item_set_draw_behind_parent :: func RenderingServer.canvas_item_set_draw_behind_parent(item: RID, enabled: bool) -> void
If [param enabled] is [code]true[/code], draws the canvas item specified by the [param item] RID behind its parent. Equivalent to [member CanvasItem.show_behind_parent].

### item :: RID

### enabled :: bool

## canvas_item_set_draw_index :: func RenderingServer.canvas_item_set_draw_index(item: RID, index: int) -> void
Sets the index for the [CanvasItem].

### item :: RID

### index :: int

## canvas_item_set_instance_shader_parameter :: func RenderingServer.canvas_item_set_instance_shader_parameter(instance: RID, parameter: StringName, value: Variant) -> void
Sets the per-instance shader uniform on the specified canvas item instance. Equivalent to [method CanvasItem.set_instance_shader_parameter].

### instance :: RID

### parameter :: StringName

### value :: Variant

## canvas_item_set_interpolated :: func RenderingServer.canvas_item_set_interpolated(item: RID, interpolated: bool) -> void
If [param interpolated] is [code]true[/code], turns on physics interpolation for the canvas item.

### item :: RID

### interpolated :: bool

## canvas_item_set_light_mask :: func RenderingServer.canvas_item_set_light_mask(item: RID, mask: int) -> void
Sets the light [param mask] for the canvas item specified by the [param item] RID. Equivalent to [member CanvasItem.light_mask].

### item :: RID

### mask :: int

## canvas_item_set_material :: func RenderingServer.canvas_item_set_material(item: RID, material: RID) -> void
Sets a new [param material] to the canvas item specified by the [param item] RID. Equivalent to [member CanvasItem.material].

### item :: RID

### material :: RID

## canvas_item_set_modulate :: func RenderingServer.canvas_item_set_modulate(item: RID, color: Color) -> void
Multiplies the color of the canvas item specified by the [param item] RID, while affecting its children. See also [method canvas_item_set_self_modulate]. Equivalent to [member CanvasItem.modulate].

### item :: RID

### color :: Color

## canvas_item_set_parent :: func RenderingServer.canvas_item_set_parent(item: RID, parent: RID) -> void
Sets a parent [CanvasItem] to the [CanvasItem]. The item will inherit transform, modulation and visibility from its parent, like [CanvasItem] nodes in the scene tree.

### item :: RID

### parent :: RID

## canvas_item_set_self_modulate :: func RenderingServer.canvas_item_set_self_modulate(item: RID, color: Color) -> void
Multiplies the color of the canvas item specified by the [param item] RID, without affecting its children. See also [method canvas_item_set_modulate]. Equivalent to [member CanvasItem.self_modulate].

### item :: RID

### color :: Color

## canvas_item_set_sort_children_by_y :: func RenderingServer.canvas_item_set_sort_children_by_y(item: RID, enabled: bool) -> void
If [param enabled] is [code]true[/code], child nodes with the lowest Y position are drawn before those with a higher Y position. Y-sorting only affects children that inherit from the canvas item specified by the [param item] RID, not the canvas item itself. Equivalent to [member CanvasItem.y_sort_enabled].

### item :: RID

### enabled :: bool

## canvas_item_set_transform :: func RenderingServer.canvas_item_set_transform(item: RID, transform: Transform2D) -> void
Sets the [param transform] of the canvas item specified by the [param item] RID. This affects where and how the item will be drawn. Child canvas items' transforms are multiplied by their parent's transform. Equivalent to [member Node2D.transform].

### item :: RID

### transform :: Transform2D

## canvas_item_set_use_parent_material :: func RenderingServer.canvas_item_set_use_parent_material(item: RID, enabled: bool) -> void
Sets if the [CanvasItem] uses its parent's material.

### item :: RID

### enabled :: bool

## canvas_item_set_visibility_layer :: func RenderingServer.canvas_item_set_visibility_layer(item: RID, visibility_layer: int) -> void
Sets the rendering visibility layer associated with this [CanvasItem]. Only [Viewport] nodes with a matching rendering mask will render this [CanvasItem].

### item :: RID

### visibility_layer :: int

## canvas_item_set_visibility_notifier :: func RenderingServer.canvas_item_set_visibility_notifier(item: RID, enable: bool, area: Rect2, enter_callable: Callable, exit_callable: Callable) -> void
Sets the given [CanvasItem] as visibility notifier. [param area] defines the area of detecting visibility. [param enter_callable] is called when the [CanvasItem] enters the screen, [param exit_callable] is called when the [CanvasItem] exits the screen. If [param enable] is [code]false[/code], the item will no longer function as notifier.
This method can be used to manually mimic [VisibleOnScreenNotifier2D].

### item :: RID

### enable :: bool

### area :: Rect2

### enter_callable :: Callable

### exit_callable :: Callable

## canvas_item_set_visible :: func RenderingServer.canvas_item_set_visible(item: RID, visible: bool) -> void
Sets the visibility of the [CanvasItem].

### item :: RID

### visible :: bool

## canvas_item_set_z_as_relative_to_parent :: func RenderingServer.canvas_item_set_z_as_relative_to_parent(item: RID, enabled: bool) -> void
If this is enabled, the Z index of the parent will be added to the children's Z index.

### item :: RID

### enabled :: bool

## canvas_item_set_z_index :: func RenderingServer.canvas_item_set_z_index(item: RID, z_index: int) -> void
Sets the [CanvasItem]'s Z index, i.e. its draw order (lower indexes are drawn first).

### item :: RID

### z_index :: int

## canvas_item_transform_physics_interpolation :: func RenderingServer.canvas_item_transform_physics_interpolation(item: RID, transform: Transform2D) -> void
Transforms both the current and previous stored transform for a canvas item.
This allows transforming a canvas item without creating a "glitch" in the interpolation, which is particularly useful for large worlds utilizing a shifting origin.

### item :: RID

### transform :: Transform2D

## canvas_light_attach_to_canvas :: func RenderingServer.canvas_light_attach_to_canvas(light: RID, canvas: RID) -> void
Attaches the canvas light to the canvas. Removes it from its previous canvas.

### light :: RID

### canvas :: RID

## canvas_light_create :: func RenderingServer.canvas_light_create() -> RID
Creates a canvas light and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]canvas_light_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent node is [Light2D].

## canvas_light_occluder_attach_to_canvas :: func RenderingServer.canvas_light_occluder_attach_to_canvas(occluder: RID, canvas: RID) -> void
Attaches a light occluder to the canvas. Removes it from its previous canvas.

### occluder :: RID

### canvas :: RID

## canvas_light_occluder_create :: func RenderingServer.canvas_light_occluder_create() -> RID
Creates a light occluder and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]canvas_light_occluder_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent node is [LightOccluder2D].

## canvas_light_occluder_reset_physics_interpolation :: func RenderingServer.canvas_light_occluder_reset_physics_interpolation(occluder: RID) -> void
Prevents physics interpolation for the current physics tick.
This is useful when moving an occluder to a new location, to give an instantaneous change rather than interpolation from the previous location.

### occluder :: RID

## canvas_light_occluder_set_as_sdf_collision :: func RenderingServer.canvas_light_occluder_set_as_sdf_collision(occluder: RID, enable: bool) -> void
Enables or disables using the light occluder as a signed distance field for 2D particle collision.

### occluder :: RID

### enable :: bool

## canvas_light_occluder_set_enabled :: func RenderingServer.canvas_light_occluder_set_enabled(occluder: RID, enabled: bool) -> void
Enables or disables light occluder.

### occluder :: RID

### enabled :: bool

## canvas_light_occluder_set_interpolated :: func RenderingServer.canvas_light_occluder_set_interpolated(occluder: RID, interpolated: bool) -> void
If [param interpolated] is [code]true[/code], turns on physics interpolation for the light occluder.

### occluder :: RID

### interpolated :: bool

## canvas_light_occluder_set_light_mask :: func RenderingServer.canvas_light_occluder_set_light_mask(occluder: RID, mask: int) -> void
The light mask. See [LightOccluder2D] for more information on light masks.

### occluder :: RID

### mask :: int

## canvas_light_occluder_set_polygon :: func RenderingServer.canvas_light_occluder_set_polygon(occluder: RID, polygon: RID) -> void
Sets a light occluder's polygon.

### occluder :: RID

### polygon :: RID

## canvas_light_occluder_set_transform :: func RenderingServer.canvas_light_occluder_set_transform(occluder: RID, transform: Transform2D) -> void
Sets a light occluder's [Transform2D].

### occluder :: RID

### transform :: Transform2D

## canvas_light_occluder_transform_physics_interpolation :: func RenderingServer.canvas_light_occluder_transform_physics_interpolation(occluder: RID, transform: Transform2D) -> void
Transforms both the current and previous stored transform for a light occluder.
This allows transforming an occluder without creating a "glitch" in the interpolation, which is particularly useful for large worlds utilizing a shifting origin.

### occluder :: RID

### transform :: Transform2D

## canvas_light_reset_physics_interpolation :: func RenderingServer.canvas_light_reset_physics_interpolation(light: RID) -> void
Prevents physics interpolation for the current physics tick.
This is useful when moving a canvas item to a new location, to give an instantaneous change rather than interpolation from the previous location.

### light :: RID

## canvas_light_set_blend_mode :: func RenderingServer.canvas_light_set_blend_mode(light: RID, mode: int) -> void
Sets the blend mode for the given canvas light to [param mode]. Equivalent to [member Light2D.blend_mode].

### light :: RID

### mode :: int

## canvas_light_set_color :: func RenderingServer.canvas_light_set_color(light: RID, color: Color) -> void
Sets the color for a light.

### light :: RID

### color :: Color

## canvas_light_set_enabled :: func RenderingServer.canvas_light_set_enabled(light: RID, enabled: bool) -> void
Enables or disables a canvas light.

### light :: RID

### enabled :: bool

## canvas_light_set_energy :: func RenderingServer.canvas_light_set_energy(light: RID, energy: float) -> void
Sets a canvas light's energy.

### light :: RID

### energy :: float

## canvas_light_set_height :: func RenderingServer.canvas_light_set_height(light: RID, height: float) -> void
Sets a canvas light's height.

### light :: RID

### height :: float

## canvas_light_set_interpolated :: func RenderingServer.canvas_light_set_interpolated(light: RID, interpolated: bool) -> void
If [param interpolated] is [code]true[/code], turns on physics interpolation for the canvas light.

### light :: RID

### interpolated :: bool

## canvas_light_set_item_cull_mask :: func RenderingServer.canvas_light_set_item_cull_mask(light: RID, mask: int) -> void
The light mask. See [LightOccluder2D] for more information on light masks.

### light :: RID

### mask :: int

## canvas_light_set_item_shadow_cull_mask :: func RenderingServer.canvas_light_set_item_shadow_cull_mask(light: RID, mask: int) -> void
The binary mask used to determine which layers this canvas light's shadows affects. See [LightOccluder2D] for more information on light masks.

### light :: RID

### mask :: int

## canvas_light_set_layer_range :: func RenderingServer.canvas_light_set_layer_range(light: RID, min_layer: int, max_layer: int) -> void
The layer range that gets rendered with this light.

### light :: RID

### min_layer :: int

### max_layer :: int

## canvas_light_set_mode :: func RenderingServer.canvas_light_set_mode(light: RID, mode: int) -> void
Sets the mode of the canvas light.

### light :: RID

### mode :: int

## canvas_light_set_shadow_color :: func RenderingServer.canvas_light_set_shadow_color(light: RID, color: Color) -> void
Sets the color of the canvas light's shadow.

### light :: RID

### color :: Color

## canvas_light_set_shadow_enabled :: func RenderingServer.canvas_light_set_shadow_enabled(light: RID, enabled: bool) -> void
Enables or disables the canvas light's shadow.

### light :: RID

### enabled :: bool

## canvas_light_set_shadow_filter :: func RenderingServer.canvas_light_set_shadow_filter(light: RID, filter: int) -> void
Sets the canvas light's shadow's filter.

### light :: RID

### filter :: int

## canvas_light_set_shadow_smooth :: func RenderingServer.canvas_light_set_shadow_smooth(light: RID, smooth: float) -> void
Smoothens the shadow. The lower, the smoother.

### light :: RID

### smooth :: float

## canvas_light_set_texture :: func RenderingServer.canvas_light_set_texture(light: RID, texture: RID) -> void
Sets the texture to be used by a [PointLight2D]. Equivalent to [member PointLight2D.texture].

### light :: RID

### texture :: RID

## canvas_light_set_texture_offset :: func RenderingServer.canvas_light_set_texture_offset(light: RID, offset: Vector2) -> void
Sets the offset of a [PointLight2D]'s texture. Equivalent to [member PointLight2D.offset].

### light :: RID

### offset :: Vector2

## canvas_light_set_texture_scale :: func RenderingServer.canvas_light_set_texture_scale(light: RID, scale: float) -> void
Sets the scale factor of a [PointLight2D]'s texture. Equivalent to [member PointLight2D.texture_scale].

### light :: RID

### scale :: float

## canvas_light_set_transform :: func RenderingServer.canvas_light_set_transform(light: RID, transform: Transform2D) -> void
Sets the canvas light's [Transform2D].

### light :: RID

### transform :: Transform2D

## canvas_light_set_z_range :: func RenderingServer.canvas_light_set_z_range(light: RID, min_z: int, max_z: int) -> void
Sets the Z range of objects that will be affected by this light. Equivalent to [member Light2D.range_z_min] and [member Light2D.range_z_max].

### light :: RID

### min_z :: int

### max_z :: int

## canvas_light_transform_physics_interpolation :: func RenderingServer.canvas_light_transform_physics_interpolation(light: RID, transform: Transform2D) -> void
Transforms both the current and previous stored transform for a canvas light.
This allows transforming a light without creating a "glitch" in the interpolation, which is particularly useful for large worlds utilizing a shifting origin.

### light :: RID

### transform :: Transform2D

## canvas_occluder_polygon_create :: func RenderingServer.canvas_occluder_polygon_create() -> RID
Creates a new light occluder polygon and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]canvas_occluder_polygon_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent resource is [OccluderPolygon2D].

## canvas_occluder_polygon_set_cull_mode :: func RenderingServer.canvas_occluder_polygon_set_cull_mode(occluder_polygon: RID, mode: int) -> void
Sets an occluder polygon's cull mode.

### occluder_polygon :: RID

### mode :: int

## canvas_occluder_polygon_set_shape :: func RenderingServer.canvas_occluder_polygon_set_shape(occluder_polygon: RID, shape: PackedVector2Array, closed: bool) -> void
Sets the shape of the occluder polygon.

### occluder_polygon :: RID

### shape :: PackedVector2Array

### closed :: bool

## canvas_set_disable_scale :: func RenderingServer.canvas_set_disable_scale(disable: bool) -> void
If [param disable] is [code]true[/code], makes 2D rendering ignore the canvas scale defined for each canvas layer. This affects [CanvasLayer]s with the [member CanvasLayer.follow_viewport_enabled] property set to [code]true[/code].
In the editor, this is set to [code]true[/code] by default, and set to [code]false[/code] when [b]View > Preview Canvas Scale[/b] is enabled at the top of the 2D editor viewport.
[b]Note:[/b] Setting this to [code]true[/code] does not impact the behavior of [member CanvasLayer.scale], [member Node2D.scale], or [member Control.scale].

### disable :: bool

## canvas_set_item_mirroring :: func RenderingServer.canvas_set_item_mirroring(canvas: RID, item: RID, mirroring: Vector2) -> void
A copy of the canvas item will be drawn with a local offset of the [param mirroring].
[b]Note:[/b] This is equivalent to calling [method canvas_set_item_repeat] like [code]canvas_set_item_repeat(item, mirroring, 1)[/code], with an additional check ensuring [param canvas] is a parent of [param item].

### canvas :: RID

### item :: RID

### mirroring :: Vector2

## canvas_set_item_repeat :: func RenderingServer.canvas_set_item_repeat(item: RID, repeat_size: Vector2, repeat_times: int) -> void
A copy of the canvas item will be drawn with a local offset of the [param repeat_size] by the number of times of the [param repeat_times]. As the [param repeat_times] increases, the copies will spread away from the origin texture.

### item :: RID

### repeat_size :: Vector2

### repeat_times :: int

## canvas_set_modulate :: func RenderingServer.canvas_set_modulate(canvas: RID, color: Color) -> void
Modulates all colors in the given canvas.

### canvas :: RID

### color :: Color

## canvas_set_shadow_texture_size :: func RenderingServer.canvas_set_shadow_texture_size(size: int) -> void
Sets the [member ProjectSettings.rendering/2d/shadow_atlas/size] to use for [Light2D] shadow rendering (in pixels). The value is rounded up to the nearest power of 2.

### size :: int

## canvas_texture_create :: func RenderingServer.canvas_texture_create() -> RID
Creates a canvas texture and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]canvas_texture_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method. See also [method texture_2d_create].
[b]Note:[/b] The equivalent resource is [CanvasTexture] and is only meant to be used in 2D rendering, not 3D.

## canvas_texture_set_channel :: func RenderingServer.canvas_texture_set_channel(canvas_texture: RID, channel: int, texture: RID) -> void
Sets the [param channel]'s [param texture] for the canvas texture specified by the [param canvas_texture] RID. Equivalent to [member CanvasTexture.diffuse_texture], [member CanvasTexture.normal_texture] and [member CanvasTexture.specular_texture].

### canvas_texture :: RID

### channel :: int

### texture :: RID

## canvas_texture_set_shading_parameters :: func RenderingServer.canvas_texture_set_shading_parameters(canvas_texture: RID, base_color: Color, shininess: float) -> void
Sets the [param base_color] and [param shininess] to use for the canvas texture specified by the [param canvas_texture] RID. Equivalent to [member CanvasTexture.specular_color] and [member CanvasTexture.specular_shininess].

### canvas_texture :: RID

### base_color :: Color

### shininess :: float

## canvas_texture_set_texture_filter :: func RenderingServer.canvas_texture_set_texture_filter(canvas_texture: RID, filter: int) -> void
Sets the texture [param filter] mode to use for the canvas texture specified by the [param canvas_texture] RID.

### canvas_texture :: RID

### filter :: int

## canvas_texture_set_texture_repeat :: func RenderingServer.canvas_texture_set_texture_repeat(canvas_texture: RID, repeat: int) -> void
Sets the texture [param repeat] mode to use for the canvas texture specified by the [param canvas_texture] RID.

### canvas_texture :: RID

### repeat :: int

## compositor_create :: func RenderingServer.compositor_create() -> RID
Creates a new compositor and adds it to the RenderingServer. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.

## compositor_effect_create :: func RenderingServer.compositor_effect_create() -> RID
Creates a new rendering effect and adds it to the RenderingServer. It can be accessed with the RID that is returned.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.

## compositor_effect_set_callback :: func RenderingServer.compositor_effect_set_callback(effect: RID, callback_type: int, callback: Callable) -> void
Sets the callback type ([param callback_type]) and callback method([param callback]) for this rendering effect.

### effect :: RID

### callback_type :: int

### callback :: Callable

## compositor_effect_set_enabled :: func RenderingServer.compositor_effect_set_enabled(effect: RID, enabled: bool) -> void
Enables/disables this rendering effect.

### effect :: RID

### enabled :: bool

## compositor_effect_set_flag :: func RenderingServer.compositor_effect_set_flag(effect: RID, flag: int, set: bool) -> void
Sets the flag ([param flag]) for this rendering effect to [code]true[/code] or [code]false[/code] ([param set]).

### effect :: RID

### flag :: int

### set :: bool

## compositor_set_compositor_effects :: func RenderingServer.compositor_set_compositor_effects(compositor: RID, effects: RID[]) -> void
Sets the compositor effects for the specified compositor RID. [param effects] should be an array containing RIDs created with [method compositor_effect_create].

### compositor :: RID

### effects :: RID[]

## create_local_rendering_device :: func RenderingServer.create_local_rendering_device() -> RenderingDevice
Creates a RenderingDevice that can be used to do draw and compute operations on a separate thread. Cannot draw to the screen nor share data with the global RenderingDevice.
[b]Note:[/b] When using the OpenGL rendering driver or when running in headless mode, this function always returns [code]null[/code].

## debug_canvas_item_get_rect :: func RenderingServer.debug_canvas_item_get_rect(item: RID) -> Rect2
Returns the bounding rectangle for a canvas item in local space, as calculated by the renderer. This bound is used internally for culling.
[b]Warning:[/b] This function is intended for debugging in the editor, and will pass through and return a zero [Rect2] in exported projects.

### item :: RID

## decal_create :: func RenderingServer.decal_create() -> RID
Creates a decal and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]decal_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
To place in a scene, attach this decal to an instance using [method instance_set_base] using the returned RID.
[b]Note:[/b] The equivalent node is [Decal].

## decal_set_albedo_mix :: func RenderingServer.decal_set_albedo_mix(decal: RID, albedo_mix: float) -> void
Sets the [param albedo_mix] in the decal specified by the [param decal] RID. Equivalent to [member Decal.albedo_mix].

### decal :: RID

### albedo_mix :: float

## decal_set_cull_mask :: func RenderingServer.decal_set_cull_mask(decal: RID, mask: int) -> void
Sets the cull [param mask] in the decal specified by the [param decal] RID. Equivalent to [member Decal.cull_mask].

### decal :: RID

### mask :: int

## decal_set_distance_fade :: func RenderingServer.decal_set_distance_fade(decal: RID, enabled: bool, begin: float, length: float) -> void
Sets the distance fade parameters in the decal specified by the [param decal] RID. Equivalent to [member Decal.distance_fade_enabled], [member Decal.distance_fade_begin] and [member Decal.distance_fade_length].

### decal :: RID

### enabled :: bool

### begin :: float

### length :: float

## decal_set_emission_energy :: func RenderingServer.decal_set_emission_energy(decal: RID, energy: float) -> void
Sets the emission [param energy] in the decal specified by the [param decal] RID. Equivalent to [member Decal.emission_energy].

### decal :: RID

### energy :: float

## decal_set_fade :: func RenderingServer.decal_set_fade(decal: RID, above: float, below: float) -> void
Sets the upper fade ([param above]) and lower fade ([param below]) in the decal specified by the [param decal] RID. Equivalent to [member Decal.upper_fade] and [member Decal.lower_fade].

### decal :: RID

### above :: float

### below :: float

## decal_set_modulate :: func RenderingServer.decal_set_modulate(decal: RID, color: Color) -> void
Sets the color multiplier in the decal specified by the [param decal] RID to [param color]. Equivalent to [member Decal.modulate].

### decal :: RID

### color :: Color

## decal_set_normal_fade :: func RenderingServer.decal_set_normal_fade(decal: RID, fade: float) -> void
Sets the normal [param fade] in the decal specified by the [param decal] RID. Equivalent to [member Decal.normal_fade].

### decal :: RID

### fade :: float

## decal_set_size :: func RenderingServer.decal_set_size(decal: RID, size: Vector3) -> void
Sets the [param size] of the decal specified by the [param decal] RID. Equivalent to [member Decal.size].

### decal :: RID

### size :: Vector3

## decal_set_texture :: func RenderingServer.decal_set_texture(decal: RID, type: int, texture: RID) -> void
Sets the [param texture] in the given texture [param type] slot for the specified decal. Equivalent to [method Decal.set_texture].

### decal :: RID

### type :: int

### texture :: RID

## decals_set_filter :: func RenderingServer.decals_set_filter(filter: int) -> void
Sets the texture [param filter] mode to use when rendering decals. This parameter is global and cannot be set on a per-decal basis.

### filter :: int

## directional_light_create :: func RenderingServer.directional_light_create() -> RID
Creates a directional light and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID can be used in most [code]light_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
To place in a scene, attach this directional light to an instance using [method instance_set_base] using the returned RID.
[b]Note:[/b] The equivalent node is [DirectionalLight3D].

## directional_shadow_atlas_set_size :: func RenderingServer.directional_shadow_atlas_set_size(size: int, is_16bits: bool) -> void
Sets the [param size] of the directional light shadows in 3D. See also [member ProjectSettings.rendering/lights_and_shadows/directional_shadow/size]. This parameter is global and cannot be set on a per-viewport basis.

### size :: int

### is_16bits :: bool

## directional_soft_shadow_filter_set_quality :: func RenderingServer.directional_soft_shadow_filter_set_quality(quality: int) -> void
Sets the filter [param quality] for directional light shadows in 3D. See also [member ProjectSettings.rendering/lights_and_shadows/directional_shadow/soft_shadow_filter_quality]. This parameter is global and cannot be set on a per-viewport basis.

### quality :: int

## environment_bake_panorama :: func RenderingServer.environment_bake_panorama(environment: RID, bake_irradiance: bool, size: Vector2i) -> Image
Generates and returns an [Image] containing the radiance map for the specified [param environment] RID's sky. This supports built-in sky material and custom sky shaders. If [param bake_irradiance] is [code]true[/code], the irradiance map is saved instead of the radiance map. The radiance map is used to render reflected light, while the irradiance map is used to render ambient light. See also [method sky_bake_panorama].
[b]Note:[/b] The image is saved using linear encoding without any tonemapping performed, which means it will look too dark if viewed directly in an image editor.
[b]Note:[/b] [param size] should be a 2:1 aspect ratio for the generated panorama to have square pixels. For radiance maps, there is no point in using a height greater than [member Sky.radiance_size], as it won't increase detail. Irradiance maps only contain low-frequency data, so there is usually no point in going past a size of 128×64 pixels when saving an irradiance map.

### environment :: RID

### bake_irradiance :: bool

### size :: Vector2i

## environment_create :: func RenderingServer.environment_create() -> RID
Creates an environment and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]environment_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent resource is [Environment].

## environment_glow_set_use_bicubic_upscale :: func RenderingServer.environment_glow_set_use_bicubic_upscale(enable: bool) -> void
If [param enable] is [code]true[/code], enables bicubic upscaling for glow which improves quality at the cost of performance. Equivalent to [member ProjectSettings.rendering/environment/glow/upscale_mode].
[b]Note:[/b] This setting is only effective when using the Forward+ or Mobile rendering methods, as Compatibility uses a different glow implementation.

### enable :: bool

## environment_set_adjustment :: func RenderingServer.environment_set_adjustment(env: RID, enable: bool, brightness: float, contrast: float, saturation: float, use_1d_color_correction: bool, color_correction: RID) -> void
Sets the values to be used with the "adjustments" post-process effect. See [Environment] for more details.

### env :: RID

### enable :: bool

### brightness :: float

### contrast :: float

### saturation :: float

### use_1d_color_correction :: bool

### color_correction :: RID

## environment_set_ambient_light :: func RenderingServer.environment_set_ambient_light(env: RID, color: Color, ambient: int = 0, energy: float = 1.0, sky_contribution: float = 0.0, reflection_source: int = 0) -> void
Sets the values to be used for ambient light rendering. See [Environment] for more details.

### env :: RID

### color :: Color

### ambient :: int

### energy :: float

### sky_contribution :: float

### reflection_source :: int

## environment_set_background :: func RenderingServer.environment_set_background(env: RID, bg: int) -> void
Sets the environment's background mode. Equivalent to [member Environment.background_mode].

### env :: RID

### bg :: int

## environment_set_bg_color :: func RenderingServer.environment_set_bg_color(env: RID, color: Color) -> void
Color displayed for clear areas of the scene. Only effective if using the [constant ENV_BG_COLOR] background mode.

### env :: RID

### color :: Color

## environment_set_bg_energy :: func RenderingServer.environment_set_bg_energy(env: RID, multiplier: float, exposure_value: float) -> void
Sets the intensity of the background color.

### env :: RID

### multiplier :: float

### exposure_value :: float

## environment_set_camera_id :: func RenderingServer.environment_set_camera_id(env: RID, id: int) -> void
Sets the camera ID to be used as environment background.

### env :: RID

### id :: int

## environment_set_canvas_max_layer :: func RenderingServer.environment_set_canvas_max_layer(env: RID, max_layer: int) -> void
Sets the maximum layer to use if using Canvas background mode.

### env :: RID

### max_layer :: int

## environment_set_fog :: func RenderingServer.environment_set_fog(env: RID, enable: bool, light_color: Color, light_energy: float, sun_scatter: float, density: float, height: float, height_density: float, aerial_perspective: float, sky_affect: float, fog_mode: int = 0) -> void
Configures fog for the specified environment RID. See [code]fog_*[/code] properties in [Environment] for more information.

### env :: RID

### enable :: bool

### light_color :: Color

### light_energy :: float

### sun_scatter :: float

### density :: float

### height :: float

### height_density :: float

### aerial_perspective :: float

### sky_affect :: float

### fog_mode :: int

## environment_set_fog_depth :: func RenderingServer.environment_set_fog_depth(env: RID, curve: float, begin: float, end: float) -> void
Configures fog depth for the specified environment RID. Only has an effect when the fog mode of the environment is [constant ENV_FOG_MODE_DEPTH]. See [code]fog_depth_*[/code] properties in [Environment] for more information.

### env :: RID

### curve :: float

### begin :: float

### end :: float

## environment_set_glow :: func RenderingServer.environment_set_glow(env: RID, enable: bool, levels: PackedFloat32Array, intensity: float, strength: float, mix: float, bloom_threshold: float, blend_mode: int, hdr_bleed_threshold: float, hdr_bleed_scale: float, hdr_luminance_cap: float, glow_map_strength: float, glow_map: RID) -> void
Configures glow for the specified environment RID. See [code]glow_*[/code] properties in [Environment] for more information.

### env :: RID

### enable :: bool

### levels :: PackedFloat32Array

### intensity :: float

### strength :: float

### mix :: float

### bloom_threshold :: float

### blend_mode :: int

### hdr_bleed_threshold :: float

### hdr_bleed_scale :: float

### hdr_luminance_cap :: float

### glow_map_strength :: float

### glow_map :: RID

## environment_set_sdfgi :: func RenderingServer.environment_set_sdfgi(env: RID, enable: bool, cascades: int, min_cell_size: float, y_scale: int, use_occlusion: bool, bounce_feedback: float, read_sky: bool, energy: float, normal_bias: float, probe_bias: float) -> void
Configures signed distance field global illumination for the specified environment RID. See [code]sdfgi_*[/code] properties in [Environment] for more information.

### env :: RID

### enable :: bool

### cascades :: int

### min_cell_size :: float

### y_scale :: int

### use_occlusion :: bool

### bounce_feedback :: float

### read_sky :: bool

### energy :: float

### normal_bias :: float

### probe_bias :: float

## environment_set_sdfgi_frames_to_converge :: func RenderingServer.environment_set_sdfgi_frames_to_converge(frames: int) -> void
Sets the number of frames to use for converging signed distance field global illumination. Equivalent to [member ProjectSettings.rendering/global_illumination/sdfgi/frames_to_converge].

### frames :: int

## environment_set_sdfgi_frames_to_update_light :: func RenderingServer.environment_set_sdfgi_frames_to_update_light(frames: int) -> void
Sets the update speed for dynamic lights' indirect lighting when computing signed distance field global illumination. Equivalent to [member ProjectSettings.rendering/global_illumination/sdfgi/frames_to_update_lights].

### frames :: int

## environment_set_sdfgi_ray_count :: func RenderingServer.environment_set_sdfgi_ray_count(ray_count: int) -> void
Sets the number of rays to throw per frame when computing signed distance field global illumination. Equivalent to [member ProjectSettings.rendering/global_illumination/sdfgi/probe_ray_count].

### ray_count :: int

## environment_set_sky :: func RenderingServer.environment_set_sky(env: RID, sky: RID) -> void
Sets the [Sky] to be used as the environment's background when using [i]BGMode[/i] sky. Equivalent to [member Environment.sky].

### env :: RID

### sky :: RID

## environment_set_sky_custom_fov :: func RenderingServer.environment_set_sky_custom_fov(env: RID, scale: float) -> void
Sets a custom field of view for the background [Sky]. Equivalent to [member Environment.sky_custom_fov].

### env :: RID

### scale :: float

## environment_set_sky_orientation :: func RenderingServer.environment_set_sky_orientation(env: RID, orientation: Basis) -> void
Sets the rotation of the background [Sky] expressed as a [Basis]. Equivalent to [member Environment.sky_rotation], where the rotation vector is used to construct the [Basis].

### env :: RID

### orientation :: Basis

## environment_set_ssao :: func RenderingServer.environment_set_ssao(env: RID, enable: bool, radius: float, intensity: float, power: float, detail: float, horizon: float, sharpness: float, light_affect: float, ao_channel_affect: float) -> void
Sets the variables to be used with the screen-space ambient occlusion (SSAO) post-process effect. See [Environment] for more details.

### env :: RID

### enable :: bool

### radius :: float

### intensity :: float

### power :: float

### detail :: float

### horizon :: float

### sharpness :: float

### light_affect :: float

### ao_channel_affect :: float

## environment_set_ssao_quality :: func RenderingServer.environment_set_ssao_quality(quality: int, half_size: bool, adaptive_target: float, blur_passes: int, fadeout_from: float, fadeout_to: float) -> void
Sets the quality level of the screen-space ambient occlusion (SSAO) post-process effect. See [Environment] for more details.

### quality :: int

### half_size :: bool

### adaptive_target :: float

### blur_passes :: int

### fadeout_from :: float

### fadeout_to :: float

## environment_set_ssil_quality :: func RenderingServer.environment_set_ssil_quality(quality: int, half_size: bool, adaptive_target: float, blur_passes: int, fadeout_from: float, fadeout_to: float) -> void
Sets the quality level of the screen-space indirect lighting (SSIL) post-process effect. See [Environment] for more details.

### quality :: int

### half_size :: bool

### adaptive_target :: float

### blur_passes :: int

### fadeout_from :: float

### fadeout_to :: float

## environment_set_ssr :: func RenderingServer.environment_set_ssr(env: RID, enable: bool, max_steps: int, fade_in: float, fade_out: float, depth_tolerance: float) -> void
Sets the variables to be used with the screen-space reflections (SSR) post-process effect. See [Environment] for more details.

### env :: RID

### enable :: bool

### max_steps :: int

### fade_in :: float

### fade_out :: float

### depth_tolerance :: float

## environment_set_ssr_half_size :: func RenderingServer.environment_set_ssr_half_size(half_size: bool) -> void
Sets whether screen-space reflections will be rendered at full or half size. Half size is faster, but may look pixelated or cause flickering.

### half_size :: bool

## environment_set_ssr_roughness_quality :: func RenderingServer.environment_set_ssr_roughness_quality(quality: int) -> void

### quality :: int

## environment_set_tonemap :: func RenderingServer.environment_set_tonemap(env: RID, tone_mapper: int, exposure: float, white: float) -> void
Sets the variables to be used with the "tonemap" post-process effect. See [Environment] for more details.

### env :: RID

### tone_mapper :: int

### exposure :: float

### white :: float

## environment_set_tonemap_agx_contrast :: func RenderingServer.environment_set_tonemap_agx_contrast(env: RID, agx_contrast: float) -> void
See [member Environment.tonemap_agx_contrast] for more details.

### env :: RID

### agx_contrast :: float

## environment_set_volumetric_fog :: func RenderingServer.environment_set_volumetric_fog(env: RID, enable: bool, density: float, albedo: Color, emission: Color, emission_energy: float, anisotropy: float, length: float, detail_spread: float, gi_inject: float, temporal_reprojection: bool, temporal_reprojection_amount: float, ambient_inject: float, sky_affect: float) -> void
Sets the variables to be used with the volumetric fog post-process effect. See [Environment] for more details.

### env :: RID

### enable :: bool

### density :: float

### albedo :: Color

### emission :: Color

### emission_energy :: float

### anisotropy :: float

### length :: float

### detail_spread :: float

### gi_inject :: float

### temporal_reprojection :: bool

### temporal_reprojection_amount :: float

### ambient_inject :: float

### sky_affect :: float

## environment_set_volumetric_fog_filter_active :: func RenderingServer.environment_set_volumetric_fog_filter_active(active: bool) -> void
Enables filtering of the volumetric fog scattering buffer. This results in much smoother volumes with very few under-sampling artifacts.

### active :: bool

## environment_set_volumetric_fog_volume_size :: func RenderingServer.environment_set_volumetric_fog_volume_size(size: int, depth: int) -> void
Sets the resolution of the volumetric fog's froxel buffer. [param size] is modified by the screen's aspect ratio and then used to set the width and height of the buffer. While [param depth] is directly used to set the depth of the buffer.

### size :: int

### depth :: int

## fog_volume_create :: func RenderingServer.fog_volume_create() -> RID
Creates a new fog volume and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]fog_volume_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent node is [FogVolume].

## fog_volume_set_material :: func RenderingServer.fog_volume_set_material(fog_volume: RID, material: RID) -> void
Sets the [Material] of the fog volume. Can be either a [FogMaterial] or a custom [ShaderMaterial].

### fog_volume :: RID

### material :: RID

## fog_volume_set_shape :: func RenderingServer.fog_volume_set_shape(fog_volume: RID, shape: int) -> void
Sets the shape of the fog volume to either [constant RenderingServer.FOG_VOLUME_SHAPE_ELLIPSOID], [constant RenderingServer.FOG_VOLUME_SHAPE_CONE], [constant RenderingServer.FOG_VOLUME_SHAPE_CYLINDER], [constant RenderingServer.FOG_VOLUME_SHAPE_BOX] or [constant RenderingServer.FOG_VOLUME_SHAPE_WORLD].

### fog_volume :: RID

### shape :: int

## fog_volume_set_size :: func RenderingServer.fog_volume_set_size(fog_volume: RID, size: Vector3) -> void
Sets the size of the fog volume when shape is [constant RenderingServer.FOG_VOLUME_SHAPE_ELLIPSOID], [constant RenderingServer.FOG_VOLUME_SHAPE_CONE], [constant RenderingServer.FOG_VOLUME_SHAPE_CYLINDER] or [constant RenderingServer.FOG_VOLUME_SHAPE_BOX].

### fog_volume :: RID

### size :: Vector3

## force_draw :: func RenderingServer.force_draw(swap_buffers: bool = true, frame_step: float = 0.0) -> void
Forces redrawing of all viewports at once. Must be called from the main thread.

### swap_buffers :: bool

### frame_step :: float

## force_sync :: func RenderingServer.force_sync() -> void
Forces a synchronization between the CPU and GPU, which may be required in certain cases. Only call this when needed, as CPU-GPU synchronization has a performance cost.

## free_rid :: func RenderingServer.free_rid(rid: RID) -> void
Tries to free an object in the RenderingServer. To avoid memory leaks, this should be called after using an object as memory management does not occur automatically when using RenderingServer directly.

### rid :: RID

## get_current_rendering_driver_name :: func RenderingServer.get_current_rendering_driver_name() -> String
Returns the name of the current rendering driver. This can be [code]vulkan[/code], [code]d3d12[/code], [code]metal[/code], [code]opengl3[/code], [code]opengl3_es[/code], or [code]opengl3_angle[/code]. See also [method get_current_rendering_method].
When [member ProjectSettings.rendering/renderer/rendering_method] is [code]forward_plus[/code] or [code]mobile[/code], the rendering driver is determined by [member ProjectSettings.rendering/rendering_device/driver].
When [member ProjectSettings.rendering/renderer/rendering_method] is [code]gl_compatibility[/code], the rendering driver is determined by [member ProjectSettings.rendering/gl_compatibility/driver].
The rendering driver is also determined by the [code]--rendering-driver[/code] command line argument that overrides this project setting, or an automatic fallback that is applied depending on the hardware.

## get_current_rendering_method :: func RenderingServer.get_current_rendering_method() -> String
Returns the name of the current rendering method. This can be [code]forward_plus[/code], [code]mobile[/code], or [code]gl_compatibility[/code]. See also [method get_current_rendering_driver_name].
The rendering method is determined by [member ProjectSettings.rendering/renderer/rendering_method], the [code]--rendering-method[/code] command line argument that overrides this project setting, or an automatic fallback that is applied depending on the hardware.

## get_default_clear_color :: func RenderingServer.get_default_clear_color() -> Color
Returns the default clear color which is used when a specific clear color has not been selected. See also [method set_default_clear_color].

## get_frame_setup_time_cpu :: func RenderingServer.get_frame_setup_time_cpu() -> float
Returns the time taken to setup rendering on the CPU in milliseconds. This value is shared across all viewports and does [i]not[/i] require [method viewport_set_measure_render_time] to be enabled on a viewport to be queried. See also [method viewport_get_measured_render_time_cpu].

## get_rendering_device :: func RenderingServer.get_rendering_device() -> RenderingDevice
Returns the global RenderingDevice.
[b]Note:[/b] When using the OpenGL rendering driver or when running in headless mode, this function always returns [code]null[/code].

## get_rendering_info :: func RenderingServer.get_rendering_info(info: int) -> int
Returns a statistic about the rendering engine which can be used for performance profiling. See also [method viewport_get_render_info], which returns information specific to a viewport.
[b]Note:[/b] Only 3D rendering is currently taken into account by some of these values, such as the number of draw calls.
[b]Note:[/b] Rendering information is not available until at least 2 frames have been rendered by the engine. If rendering information is not available, [method get_rendering_info] returns [code]0[/code]. To print rendering information in [code]_ready()[/code] successfully, use the following:
[codeblock]
func _ready():
	for _i in 2:
		await get_tree().process_frame

	print(RenderingServer.get_rendering_info(RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME))
[/codeblock]

### info :: int

## get_shader_parameter_list :: func RenderingServer.get_shader_parameter_list(shader: RID) -> Dictionary[]
Returns the parameters of a shader.

### shader :: RID

## get_test_cube :: func RenderingServer.get_test_cube() -> RID
Returns the RID of the test cube. This mesh will be created and returned on the first call to [method get_test_cube], then it will be cached for subsequent calls. See also [method make_sphere_mesh].

## get_test_texture :: func RenderingServer.get_test_texture() -> RID
Returns the RID of a 256×256 texture with a testing pattern on it (in [constant Image.FORMAT_RGB8] format). This texture will be created and returned on the first call to [method get_test_texture], then it will be cached for subsequent calls. See also [method get_white_texture].
[b]Example:[/b] Get the test texture and apply it to a [Sprite2D] node:
[codeblock]
var texture_rid = RenderingServer.get_test_texture()
var texture = ImageTexture.create_from_image(RenderingServer.texture_2d_get(texture_rid))
$Sprite2D.texture = texture
[/codeblock]

## get_video_adapter_api_version :: func RenderingServer.get_video_adapter_api_version() -> String
Returns the version of the graphics video adapter [i]currently in use[/i] (e.g. "1.2.189" for Vulkan, "3.3.0 NVIDIA 510.60.02" for OpenGL). This version may be different from the actual latest version supported by the hardware, as Godot may not always request the latest version. See also [method OS.get_video_adapter_driver_info].
[b]Note:[/b] When running a headless or server binary, this function returns an empty string.

## get_video_adapter_name :: func RenderingServer.get_video_adapter_name() -> String
Returns the name of the video adapter (e.g. "GeForce GTX 1080/PCIe/SSE2").
[b]Note:[/b] When running a headless or server binary, this function returns an empty string.
[b]Note:[/b] On the web platform, some browsers such as Firefox may report a different, fixed GPU name such as "GeForce GTX 980" (regardless of the user's actual GPU model). This is done to make fingerprinting more difficult.

## get_video_adapter_type :: func RenderingServer.get_video_adapter_type() -> int
Returns the type of the video adapter. Since dedicated graphics cards from a given generation will [i]usually[/i] be significantly faster than integrated graphics made in the same generation, the device type can be used as a basis for automatic graphics settings adjustment. However, this is not always true, so make sure to provide users with a way to manually override graphics settings.
[b]Note:[/b] When using the OpenGL rendering driver or when running in headless mode, this function always returns [constant RenderingDevice.DEVICE_TYPE_OTHER].

## get_video_adapter_vendor :: func RenderingServer.get_video_adapter_vendor() -> String
Returns the vendor of the video adapter (e.g. "NVIDIA Corporation").
[b]Note:[/b] When running a headless or server binary, this function returns an empty string.

## get_white_texture :: func RenderingServer.get_white_texture() -> RID
Returns the ID of a 4×4 white texture (in [constant Image.FORMAT_RGB8] format). This texture will be created and returned on the first call to [method get_white_texture], then it will be cached for subsequent calls. See also [method get_test_texture].
[b]Example:[/b] Get the white texture and apply it to a [Sprite2D] node:
[codeblock]
var texture_rid = RenderingServer.get_white_texture()
var texture = ImageTexture.create_from_image(RenderingServer.texture_2d_get(texture_rid))
$Sprite2D.texture = texture
[/codeblock]

## gi_set_use_half_resolution :: func RenderingServer.gi_set_use_half_resolution(half_resolution: bool) -> void
If [param half_resolution] is [code]true[/code], renders [VoxelGI] and SDFGI ([member Environment.sdfgi_enabled]) buffers at halved resolution on each axis (e.g. 960×540 when the viewport size is 1920×1080). This improves performance significantly when VoxelGI or SDFGI is enabled, at the cost of artifacts that may be visible on polygon edges. The loss in quality becomes less noticeable as the viewport resolution increases. [LightmapGI] rendering is not affected by this setting. Equivalent to [member ProjectSettings.rendering/global_illumination/gi/use_half_resolution].

### half_resolution :: bool

## global_shader_parameter_add :: func RenderingServer.global_shader_parameter_add(name: StringName, type: int, default_value: Variant) -> void
Creates a new global shader uniform.
[b]Note:[/b] Global shader parameter names are case-sensitive.

### name :: StringName

### type :: int

### default_value :: Variant

## global_shader_parameter_get :: func RenderingServer.global_shader_parameter_get(name: StringName) -> Variant
Returns the value of the global shader uniform specified by [param name].
[b]Note:[/b] [method global_shader_parameter_get] has a large performance penalty as the rendering thread needs to synchronize with the calling thread, which is slow. Do not use this method during gameplay to avoid stuttering. If you need to read values in a script after setting them, consider creating an autoload where you store the values you need to query at the same time you're setting them as global parameters.

### name :: StringName

## global_shader_parameter_get_list :: func RenderingServer.global_shader_parameter_get_list() -> StringName[]
Returns the list of global shader uniform names.
[b]Note:[/b] [method global_shader_parameter_get] has a large performance penalty as the rendering thread needs to synchronize with the calling thread, which is slow. Do not use this method during gameplay to avoid stuttering. If you need to read values in a script after setting them, consider creating an autoload where you store the values you need to query at the same time you're setting them as global parameters.

## global_shader_parameter_get_type :: func RenderingServer.global_shader_parameter_get_type(name: StringName) -> int
Returns the type associated to the global shader uniform specified by [param name].
[b]Note:[/b] [method global_shader_parameter_get] has a large performance penalty as the rendering thread needs to synchronize with the calling thread, which is slow. Do not use this method during gameplay to avoid stuttering. If you need to read values in a script after setting them, consider creating an autoload where you store the values you need to query at the same time you're setting them as global parameters.

### name :: StringName

## global_shader_parameter_remove :: func RenderingServer.global_shader_parameter_remove(name: StringName) -> void
Removes the global shader uniform specified by [param name].

### name :: StringName

## global_shader_parameter_set :: func RenderingServer.global_shader_parameter_set(name: StringName, value: Variant) -> void
Sets the global shader uniform [param name] to [param value].

### name :: StringName

### value :: Variant

## global_shader_parameter_set_override :: func RenderingServer.global_shader_parameter_set_override(name: StringName, value: Variant) -> void
Overrides the global shader uniform [param name] with [param value]. Equivalent to the [ShaderGlobalsOverride] node.

### name :: StringName

### value :: Variant

## has_changed :: func RenderingServer.has_changed() -> bool
Returns [code]true[/code] if changes have been made to the RenderingServer's data. [method force_draw] is usually called if this happens.

## has_feature :: func RenderingServer.has_feature(feature: int) -> bool
This method does nothing and always returns [code]false[/code].

### feature :: int

## has_os_feature :: func RenderingServer.has_os_feature(feature: String) -> bool
Returns [code]true[/code] if the OS supports a certain [param feature]. Features might be [code]s3tc[/code], [code]etc[/code], and [code]etc2[/code].

### feature :: String

## instance_attach_object_instance_id :: func RenderingServer.instance_attach_object_instance_id(instance: RID, id: int) -> void
Attaches a unique Object ID to instance. Object ID must be attached to instance for proper culling with [method instances_cull_aabb], [method instances_cull_convex], and [method instances_cull_ray].

### instance :: RID

### id :: int

## instance_attach_skeleton :: func RenderingServer.instance_attach_skeleton(instance: RID, skeleton: RID) -> void
Attaches a skeleton to an instance. Removes the previous skeleton from the instance.

### instance :: RID

### skeleton :: RID

## instance_create :: func RenderingServer.instance_create() -> RID
Creates a visual instance and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]instance_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
An instance is a way of placing a 3D object in the scenario. Objects like particles, meshes, reflection probes and decals need to be associated with an instance to be visible in the scenario using [method instance_set_base].
[b]Note:[/b] The equivalent node is [VisualInstance3D].

## instance_create2 :: func RenderingServer.instance_create2(base: RID, scenario: RID) -> RID
Creates a visual instance, adds it to the RenderingServer, and sets both base and scenario. It can be accessed with the RID that is returned. This RID will be used in all [code]instance_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method. This is a shorthand for using [method instance_create] and setting the base and scenario manually.

### base :: RID

### scenario :: RID

## instance_geometry_get_shader_parameter :: func RenderingServer.instance_geometry_get_shader_parameter(instance: RID, parameter: StringName) -> Variant
Returns the value of the per-instance shader uniform from the specified 3D geometry instance. Equivalent to [method GeometryInstance3D.get_instance_shader_parameter].
[b]Note:[/b] Per-instance shader parameter names are case-sensitive.

### instance :: RID

### parameter :: StringName

## instance_geometry_get_shader_parameter_default_value :: func RenderingServer.instance_geometry_get_shader_parameter_default_value(instance: RID, parameter: StringName) -> Variant
Returns the default value of the per-instance shader uniform from the specified 3D geometry instance. Equivalent to [method GeometryInstance3D.get_instance_shader_parameter].

### instance :: RID

### parameter :: StringName

## instance_geometry_get_shader_parameter_list :: func RenderingServer.instance_geometry_get_shader_parameter_list(instance: RID) -> Dictionary[]
Returns a dictionary of per-instance shader uniform names of the per-instance shader uniform from the specified 3D geometry instance. The returned dictionary is in PropertyInfo format, with the keys [code]name[/code], [code]class_name[/code], [code]type[/code], [code]hint[/code], [code]hint_string[/code] and [code]usage[/code]. Equivalent to [method GeometryInstance3D.get_instance_shader_parameter].

### instance :: RID

## instance_geometry_set_cast_shadows_setting :: func RenderingServer.instance_geometry_set_cast_shadows_setting(instance: RID, shadow_casting_setting: int) -> void
Sets the shadow casting setting. Equivalent to [member GeometryInstance3D.cast_shadow].

### instance :: RID

### shadow_casting_setting :: int

## instance_geometry_set_flag :: func RenderingServer.instance_geometry_set_flag(instance: RID, flag: int, enabled: bool) -> void
Sets the [param flag] for a given [param instance] to [param enabled].

### instance :: RID

### flag :: int

### enabled :: bool

## instance_geometry_set_lightmap :: func RenderingServer.instance_geometry_set_lightmap(instance: RID, lightmap: RID, lightmap_uv_scale: Rect2, lightmap_slice: int) -> void
Sets the lightmap GI instance to use for the specified 3D geometry instance. The lightmap UV scale for the specified instance (equivalent to [member GeometryInstance3D.gi_lightmap_scale]) and lightmap atlas slice must also be specified.

### instance :: RID

### lightmap :: RID

### lightmap_uv_scale :: Rect2

### lightmap_slice :: int

## instance_geometry_set_lod_bias :: func RenderingServer.instance_geometry_set_lod_bias(instance: RID, lod_bias: float) -> void
Sets the level of detail bias to use when rendering the specified 3D geometry instance. Higher values result in higher detail from further away. Equivalent to [member GeometryInstance3D.lod_bias].

### instance :: RID

### lod_bias :: float

## instance_geometry_set_material_overlay :: func RenderingServer.instance_geometry_set_material_overlay(instance: RID, material: RID) -> void
Sets a material that will be rendered for all surfaces on top of active materials for the mesh associated with this instance. Equivalent to [member GeometryInstance3D.material_overlay].

### instance :: RID

### material :: RID

## instance_geometry_set_material_override :: func RenderingServer.instance_geometry_set_material_override(instance: RID, material: RID) -> void
Sets a material that will override the material for all surfaces on the mesh associated with this instance. Equivalent to [member GeometryInstance3D.material_override].

### instance :: RID

### material :: RID

## instance_geometry_set_shader_parameter :: func RenderingServer.instance_geometry_set_shader_parameter(instance: RID, parameter: StringName, value: Variant) -> void
Sets the per-instance shader uniform on the specified 3D geometry instance. Equivalent to [method GeometryInstance3D.set_instance_shader_parameter].

### instance :: RID

### parameter :: StringName

### value :: Variant

## instance_geometry_set_transparency :: func RenderingServer.instance_geometry_set_transparency(instance: RID, transparency: float) -> void
Sets the transparency for the given geometry instance. Equivalent to [member GeometryInstance3D.transparency].
A transparency of [code]0.0[/code] is fully opaque, while [code]1.0[/code] is fully transparent. Values greater than [code]0.0[/code] (exclusive) will force the geometry's materials to go through the transparent pipeline, which is slower to render and can exhibit rendering issues due to incorrect transparency sorting. However, unlike using a transparent material, setting [param transparency] to a value greater than [code]0.0[/code] (exclusive) will [i]not[/i] disable shadow rendering.
In spatial shaders, [code]1.0 - transparency[/code] is set as the default value of the [code]ALPHA[/code] built-in.
[b]Note:[/b] [param transparency] is clamped between [code]0.0[/code] and [code]1.0[/code], so this property cannot be used to make transparent materials more opaque than they originally are.

### instance :: RID

### transparency :: float

## instance_geometry_set_visibility_range :: func RenderingServer.instance_geometry_set_visibility_range(instance: RID, min: float, max: float, min_margin: float, max_margin: float, fade_mode: int) -> void
Sets the visibility range values for the given geometry instance. Equivalent to [member GeometryInstance3D.visibility_range_begin] and related properties.

### instance :: RID

### min :: float

### max :: float

### min_margin :: float

### max_margin :: float

### fade_mode :: int

## instance_set_base :: func RenderingServer.instance_set_base(instance: RID, base: RID) -> void
Sets the base of the instance. A base can be any of the 3D objects that are created in the RenderingServer that can be displayed. For example, any of the light types, mesh, multimesh, particle system, reflection probe, decal, lightmap, voxel GI and visibility notifiers are all types that can be set as the base of an instance in order to be displayed in the scenario.

### instance :: RID

### base :: RID

## instance_set_blend_shape_weight :: func RenderingServer.instance_set_blend_shape_weight(instance: RID, shape: int, weight: float) -> void
Sets the weight for a given blend shape associated with this instance.

### instance :: RID

### shape :: int

### weight :: float

## instance_set_custom_aabb :: func RenderingServer.instance_set_custom_aabb(instance: RID, aabb: AABB) -> void
Sets a custom AABB to use when culling objects from the view frustum. Equivalent to setting [member GeometryInstance3D.custom_aabb].

### instance :: RID

### aabb :: AABB

## instance_set_extra_visibility_margin :: func RenderingServer.instance_set_extra_visibility_margin(instance: RID, margin: float) -> void
Sets a margin to increase the size of the AABB when culling objects from the view frustum. This allows you to avoid culling objects that fall outside the view frustum. Equivalent to [member GeometryInstance3D.extra_cull_margin].

### instance :: RID

### margin :: float

## instance_set_ignore_culling :: func RenderingServer.instance_set_ignore_culling(instance: RID, enabled: bool) -> void
If [code]true[/code], ignores all culling on the specified 3D geometry instance, including frustum culling, occlusion culling, and layer culling. This is not the same as [member GeometryInstance3D.ignore_occlusion_culling], which only ignores occlusion culling but leaves frustum and layer culling intact.

### instance :: RID

### enabled :: bool

## instance_set_layer_mask :: func RenderingServer.instance_set_layer_mask(instance: RID, mask: int) -> void
Sets the render layers that this instance will be drawn to. Equivalent to [member VisualInstance3D.layers].

### instance :: RID

### mask :: int

## instance_set_pivot_data :: func RenderingServer.instance_set_pivot_data(instance: RID, sorting_offset: float, use_aabb_center: bool) -> void
Sets the sorting offset and switches between using the bounding box or instance origin for depth sorting.

### instance :: RID

### sorting_offset :: float

### use_aabb_center :: bool

## instance_set_scenario :: func RenderingServer.instance_set_scenario(instance: RID, scenario: RID) -> void
Sets the scenario that the instance is in. The scenario is the 3D world that the objects will be displayed in.

### instance :: RID

### scenario :: RID

## instance_set_surface_override_material :: func RenderingServer.instance_set_surface_override_material(instance: RID, surface: int, material: RID) -> void
Sets the override material of a specific surface. Equivalent to [method MeshInstance3D.set_surface_override_material].

### instance :: RID

### surface :: int

### material :: RID

## instance_set_transform :: func RenderingServer.instance_set_transform(instance: RID, transform: Transform3D) -> void
Sets the world space transform of the instance. Equivalent to [member Node3D.global_transform].

### instance :: RID

### transform :: Transform3D

## instance_set_visibility_parent :: func RenderingServer.instance_set_visibility_parent(instance: RID, parent: RID) -> void
Sets the visibility parent for the given instance. Equivalent to [member Node3D.visibility_parent].

### instance :: RID

### parent :: RID

## instance_set_visible :: func RenderingServer.instance_set_visible(instance: RID, visible: bool) -> void
Sets whether an instance is drawn or not. Equivalent to [member Node3D.visible].

### instance :: RID

### visible :: bool

## instance_teleport :: func RenderingServer.instance_teleport(instance: RID) -> void
Resets motion vectors and other interpolated values. Use this [i]after[/i] teleporting a mesh from one position to another to avoid ghosting artifacts.

### instance :: RID

## instances_cull_aabb :: func RenderingServer.instances_cull_aabb(aabb: AABB, scenario: RID = RID()) -> PackedInt64Array
Returns an array of object IDs intersecting with the provided AABB. Only 3D nodes that inherit from [VisualInstance3D] are considered, such as [MeshInstance3D] or [DirectionalLight3D]. Use [method @GlobalScope.instance_from_id] to obtain the actual nodes. A scenario RID must be provided, which is available in the [World3D] you want to query. This forces an update for all resources queued to update.
[b]Warning:[/b] This function is primarily intended for editor usage. For in-game use cases, prefer physics collision.

### aabb :: AABB

### scenario :: RID

## instances_cull_convex :: func RenderingServer.instances_cull_convex(convex: Plane[], scenario: RID = RID()) -> PackedInt64Array
Returns an array of object IDs intersecting with the provided convex shape. Only 3D nodes that inherit from [VisualInstance3D] are considered, such as [MeshInstance3D] or [DirectionalLight3D]. Use [method @GlobalScope.instance_from_id] to obtain the actual nodes. A scenario RID must be provided, which is available in the [World3D] you want to query. This forces an update for all resources queued to update.
[b]Warning:[/b] This function is primarily intended for editor usage. For in-game use cases, prefer physics collision.

### convex :: Plane[]

### scenario :: RID

## instances_cull_ray :: func RenderingServer.instances_cull_ray(from: Vector3, to: Vector3, scenario: RID = RID()) -> PackedInt64Array
Returns an array of object IDs intersecting with the provided 3D ray. Only 3D nodes that inherit from [VisualInstance3D] are considered, such as [MeshInstance3D] or [DirectionalLight3D]. Use [method @GlobalScope.instance_from_id] to obtain the actual nodes. A scenario RID must be provided, which is available in the [World3D] you want to query. This forces an update for all resources queued to update.
[b]Warning:[/b] This function is primarily intended for editor usage. For in-game use cases, prefer physics collision.

### from :: Vector3

### to :: Vector3

### scenario :: RID

## is_on_render_thread :: func RenderingServer.is_on_render_thread() -> bool
Returns [code]true[/code] if our code is currently executing on the rendering thread.

## light_area_set_normalize_energy :: func RenderingServer.light_area_set_normalize_energy(light: RID, enable: bool) -> void
Defines whether the energy of an [AreaLight3D] is normalized (divided) by its area. If set to [code]true[/code], changing the size does not affect the total energy output. Equivalent to [member AreaLight3D.area_normalize_energy].

### light :: RID

### enable :: bool

## light_area_set_size :: func RenderingServer.light_area_set_size(light: RID, size: Vector2) -> void
Sets the extents (width and height) in meters for this area light. Equivalent to [member AreaLight3D.area_size].

### light :: RID

### size :: Vector2

## light_directional_set_blend_splits :: func RenderingServer.light_directional_set_blend_splits(light: RID, enable: bool) -> void
If [code]true[/code], this directional light will blend between shadow map splits resulting in a smoother transition between them. Equivalent to [member DirectionalLight3D.directional_shadow_blend_splits].

### light :: RID

### enable :: bool

## light_directional_set_shadow_mode :: func RenderingServer.light_directional_set_shadow_mode(light: RID, mode: int) -> void
Sets the shadow mode for this directional light. Equivalent to [member DirectionalLight3D.directional_shadow_mode].

### light :: RID

### mode :: int

## light_directional_set_sky_mode :: func RenderingServer.light_directional_set_sky_mode(light: RID, mode: int) -> void
If [code]true[/code], this light will not be used for anything except sky shaders. Use this for lights that impact your sky shader that you may want to hide from affecting the rest of the scene. For example, you may want to enable this when the sun in your sky shader falls below the horizon.

### light :: RID

### mode :: int

## light_omni_set_shadow_mode :: func RenderingServer.light_omni_set_shadow_mode(light: RID, mode: int) -> void
Sets whether to use a dual paraboloid or a cubemap for the shadow map. Dual paraboloid is faster but may suffer from artifacts. Equivalent to [member OmniLight3D.omni_shadow_mode].

### light :: RID

### mode :: int

## light_projectors_set_filter :: func RenderingServer.light_projectors_set_filter(filter: int) -> void
Sets the texture filter mode to use when rendering light projectors. This parameter is global and cannot be set on a per-light basis.

### filter :: int

## light_set_bake_mode :: func RenderingServer.light_set_bake_mode(light: RID, bake_mode: int) -> void
Sets the bake mode to use for the specified 3D light. Equivalent to [member Light3D.light_bake_mode].

### light :: RID

### bake_mode :: int

## light_set_color :: func RenderingServer.light_set_color(light: RID, color: Color) -> void
Sets the color of the light. Equivalent to [member Light3D.light_color].

### light :: RID

### color :: Color

## light_set_cull_mask :: func RenderingServer.light_set_cull_mask(light: RID, mask: int) -> void
Sets the cull mask for this 3D light. Lights only affect objects in the selected layers. Equivalent to [member Light3D.light_cull_mask].

### light :: RID

### mask :: int

## light_set_distance_fade :: func RenderingServer.light_set_distance_fade(decal: RID, enabled: bool, begin: float, shadow: float, length: float) -> void
Sets the distance fade for this 3D light. This acts as a form of level of detail (LOD) and can be used to improve performance. Equivalent to [member Light3D.distance_fade_enabled], [member Light3D.distance_fade_begin], [member Light3D.distance_fade_shadow], and [member Light3D.distance_fade_length].

### decal :: RID

### enabled :: bool

### begin :: float

### shadow :: float

### length :: float

## light_set_max_sdfgi_cascade :: func RenderingServer.light_set_max_sdfgi_cascade(light: RID, cascade: int) -> void
Sets the maximum SDFGI cascade in which the 3D light's indirect lighting is rendered. Higher values allow the light to be rendered in SDFGI further away from the camera.

### light :: RID

### cascade :: int

## light_set_negative :: func RenderingServer.light_set_negative(light: RID, enable: bool) -> void
If [code]true[/code], the 3D light will subtract light instead of adding light. Equivalent to [member Light3D.light_negative].

### light :: RID

### enable :: bool

## light_set_param :: func RenderingServer.light_set_param(light: RID, param: int, value: float) -> void
Sets the specified 3D light parameter. Equivalent to [method Light3D.set_param].

### light :: RID

### param :: int

### value :: float

## light_set_projector :: func RenderingServer.light_set_projector(light: RID, texture: RID) -> void
Sets the projector texture to use for the specified 3D light. Equivalent to [member Light3D.light_projector].

### light :: RID

### texture :: RID

## light_set_reverse_cull_face_mode :: func RenderingServer.light_set_reverse_cull_face_mode(light: RID, enabled: bool) -> void
If [code]true[/code], reverses the backface culling of the mesh. This can be useful when you have a flat mesh that has a light behind it. If you need to cast a shadow on both sides of the mesh, set the mesh to use double-sided shadows with [method instance_geometry_set_cast_shadows_setting]. Equivalent to [member Light3D.shadow_reverse_cull_face].

### light :: RID

### enabled :: bool

## light_set_shadow :: func RenderingServer.light_set_shadow(light: RID, enabled: bool) -> void
If [code]true[/code], light will cast shadows. Equivalent to [member Light3D.shadow_enabled].

### light :: RID

### enabled :: bool

## light_set_shadow_caster_mask :: func RenderingServer.light_set_shadow_caster_mask(light: RID, mask: int) -> void
Sets the shadow caster mask for this 3D light. Shadows will only be cast using objects in the selected layers. Equivalent to [member Light3D.shadow_caster_mask].

### light :: RID

### mask :: int

## lightmap_create :: func RenderingServer.lightmap_create() -> RID
Creates a new lightmap global illumination instance and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]lightmap_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent node is [LightmapGI].

## lightmap_get_probe_capture_bsp_tree :: func RenderingServer.lightmap_get_probe_capture_bsp_tree(lightmap: RID) -> PackedInt32Array
Returns the BSP tree data used for accelerating probe lookups. The BSP data is structured as a series of six signed 32-bit values per BSP node in this order: [code]float plane_x[/code], [code]float plane_y[/code], [code]float plane_z[/code], [code]float plane_distance[/code], [code]int32_t over[/code], [code]int32_t under[/code]. An empty leaf is denoted by the value [code]-2147483648[/code] (the minimum 32-bit signed integer). See also [method lightmap_set_probe_capture_data].

### lightmap :: RID

## lightmap_get_probe_capture_points :: func RenderingServer.lightmap_get_probe_capture_points(lightmap: RID) -> PackedVector3Array
Returns the [i]local space[/i] positions of each lightmap probe capture point. Keep in mind the lightmap instance may have a non-zero transform, which will affect the position of the probe capture points. See also [method lightmap_set_probe_capture_data].

### lightmap :: RID

## lightmap_get_probe_capture_sh :: func RenderingServer.lightmap_get_probe_capture_sh(lightmap: RID) -> PackedColorArray
Returns the L0, L1, and L2 [url=https://en.wikipedia.org/wiki/Spherical_harmonics]spherical harmonics[/url] data for each lightmap probe capture point. This is specified as 9 [Color] values per probe, which means the size of the returned data is always 9 times the number of probe points. See also [method lightmap_set_probe_capture_data].

### lightmap :: RID

## lightmap_get_probe_capture_tetrahedra :: func RenderingServer.lightmap_get_probe_capture_tetrahedra(lightmap: RID) -> PackedInt32Array
Returns the tetrahedralization data used for interpolating between lightmap probe capture points. Each tetrahedron is specified as a series of 4 numbers, each being an index into the probe capture points array returned by [method lightmap_get_probe_capture_points]. See also [method lightmap_set_probe_capture_data].

### lightmap :: RID

## lightmap_set_baked_exposure_normalization :: func RenderingServer.lightmap_set_baked_exposure_normalization(lightmap: RID, baked_exposure: float) -> void
Used to inform the renderer what exposure normalization value was used while baking the lightmap. This value will be used and modulated at run time to ensure that the lightmap maintains a consistent level of exposure even if the scene-wide exposure normalization is changed at run time. For more information see [method camera_attributes_set_exposure].

### lightmap :: RID

### baked_exposure :: float

## lightmap_set_probe_bounds :: func RenderingServer.lightmap_set_probe_bounds(lightmap: RID, bounds: AABB) -> void
Sets the bounds that this lightmap instance should visually affect, both in terms of static lightmap baking and probe-based global illumination.

### lightmap :: RID

### bounds :: AABB

## lightmap_set_probe_capture_data :: func RenderingServer.lightmap_set_probe_capture_data(lightmap: RID, points: PackedVector3Array, point_sh: PackedColorArray, tetrahedra: PackedInt32Array, bsp_tree: PackedInt32Array) -> void
Sets the probe capture data for the given lightmap instance. See [method lightmap_get_probe_capture_points], [method lightmap_get_probe_capture_sh], [method lightmap_get_probe_capture_tetrahedra], and [method lightmap_get_probe_capture_bsp_tree] for the expected data formats.

### lightmap :: RID

### points :: PackedVector3Array

### point_sh :: PackedColorArray

### tetrahedra :: PackedInt32Array

### bsp_tree :: PackedInt32Array

## lightmap_set_probe_capture_update_speed :: func RenderingServer.lightmap_set_probe_capture_update_speed(speed: float) -> void
The framerate-independent update speed when representing dynamic object lighting from [LightmapProbe]s. Higher values make dynamic object lighting update faster. Higher values can prevent fast-moving objects from having "outdated" indirect lighting displayed on them, at the cost of possible flickering when an object moves from a bright area to a shaded area. See also [member ProjectSettings.rendering/lightmapping/probe_capture/update_speed].

### speed :: float

## lightmap_set_probe_interior :: func RenderingServer.lightmap_set_probe_interior(lightmap: RID, interior: bool) -> void
Sets whether the lightmap instance should be considered as interior (when [param interior] is [code]true[/code]). If the lightmap is marked as interior, environment lighting is ignored when baking lightmaps.

### lightmap :: RID

### interior :: bool

## lightmap_set_textures :: func RenderingServer.lightmap_set_textures(lightmap: RID, light: RID, uses_sh: bool) -> void
Set the textures on the given [param lightmap] GI instance to the texture array pointed to by the [param light] RID. If the lightmap texture was baked with [member LightmapGI.directional] set to [code]true[/code], then [param uses_sh] must also be [code]true[/code].

### lightmap :: RID

### light :: RID

### uses_sh :: bool

## lightmaps_set_bicubic_filter :: func RenderingServer.lightmaps_set_bicubic_filter(enable: bool) -> void
Toggles whether a bicubic filter should be used when lightmaps are sampled. This smoothens their appearance at a performance cost.

### enable :: bool

## make_sphere_mesh :: func RenderingServer.make_sphere_mesh(latitudes: int, longitudes: int, radius: float) -> RID
Returns a mesh of a sphere with the given number of horizontal subdivisions, vertical subdivisions and radius. See also [method get_test_cube].

### latitudes :: int

### longitudes :: int

### radius :: float

## material_create :: func RenderingServer.material_create() -> RID
Creates an empty material and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]material_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent resource is [Material].

## material_get_param :: func RenderingServer.material_get_param(material: RID, parameter: StringName) -> Variant
Returns the value of a certain material's parameter.

### material :: RID

### parameter :: StringName

## material_set_next_pass :: func RenderingServer.material_set_next_pass(material: RID, next_material: RID) -> void
Sets an object's next material.

### material :: RID

### next_material :: RID

## material_set_param :: func RenderingServer.material_set_param(material: RID, parameter: StringName, value: Variant) -> void
Sets a material's parameter.

### material :: RID

### parameter :: StringName

### value :: Variant

## material_set_render_priority :: func RenderingServer.material_set_render_priority(material: RID, priority: int) -> void
Sets a material's render priority.

### material :: RID

### priority :: int

## material_set_shader :: func RenderingServer.material_set_shader(shader_material: RID, shader: RID) -> void
Sets a shader material's shader.

### shader_material :: RID

### shader :: RID

## material_set_use_debanding :: func RenderingServer.material_set_use_debanding(enable: bool) -> void
When using the Mobile renderer, [method material_set_use_debanding] can be used to enable or disable the debanding feature of 3D materials ([BaseMaterial3D] and [ShaderMaterial]).
[method material_set_use_debanding] has no effect when using the Compatibility or Forward+ renderer. In Forward+, [Viewport] debanding can be used instead.
See also [member ProjectSettings.rendering/anti_aliasing/quality/use_debanding] and [method RenderingServer.viewport_set_use_debanding].

### enable :: bool

## mesh_add_surface :: func RenderingServer.mesh_add_surface(mesh: RID, surface: Dictionary) -> void
Creates a new surface on the given [param mesh]. Equivalent to [method mesh_add_surface_from_arrays], but takes a single [Dictionary] argument instead of separate arguments. The dictionary must follow this structure:
[codeblock]
{
	# Required:
    "primitive": RenderingServer.PrimitiveType,
    "format": RenderingServer.ArrayFormat,
    "vertex_data": PackedByteArray,
    "vertex_count": int,
    "aabb": AABB,

	# Optional:
	"attribute_data": PackedByteArray,
	"skin_data": PackedByteArray,
	"index_data": PackedByteArray,
	"index_count": int, # Required if `index_data` is specified.
	"uv_scale": Vector4,
	"lods": [
		# Both values are required for each LOD level.
		{
			"edge_length": float,
			"index_data": PackedByteArray,
		},
	],
	"bone_aabbs": Array[AABB],
	"blend_shape_data": PackedByteArray,
	"material": Material,
}
[/codeblock]
See also [method mesh_get_surface], which returns data in the same structure defined above.

### mesh :: RID

### surface :: Dictionary

## mesh_add_surface_from_arrays :: func RenderingServer.mesh_add_surface_from_arrays(mesh: RID, primitive: int, arrays: Array, blend_shapes: Array = [], lods: Dictionary = {}, compress_format: int = 0) -> void
Creates a new surface on the given [param mesh]. [method mesh_get_surface_count] will become the surface index for this new surface.
Surfaces are created to be rendered using a [param primitive], which may be any of the values defined in [enum Mesh.PrimitiveType].
The [param arrays] argument is an array of arrays. Each of the [constant Mesh.ARRAY_MAX] elements contains an array with some of the mesh data for this surface as described by the corresponding member of [enum Mesh.ArrayType] or [code]null[/code] if it is not used by the surface. For example, [code]arrays[0][/code] is the array of vertices. That first vertex sub-array is always required; the others are optional. Adding an index array puts this surface into "index mode" where the vertex and other arrays become the sources of data and the index array defines the vertex order. All sub-arrays must have the same length as the vertex array (or be an exact multiple of the vertex array's length, when multiple elements of a sub-array correspond to a single vertex) or be empty, except for [constant Mesh.ARRAY_INDEX] if it is used.
The [param blend_shapes] argument is an array of vertex data for each blend shape. Each element is an array of the same structure as [param arrays], but [constant Mesh.ARRAY_VERTEX], [constant Mesh.ARRAY_NORMAL], and [constant Mesh.ARRAY_TANGENT] are set if and only if they are set in [param arrays] and all other entries are [code]null[/code].
The [param lods] argument is a dictionary with [float] keys and [PackedInt32Array] values. Each entry in the dictionary represents an LOD level of the surface, where the value is the [constant Mesh.ARRAY_INDEX] array to use for the LOD level and the key is roughly proportional to the distance at which the LOD stats being used. I.e., increasing the key of an LOD also increases the distance that the objects has to be from the camera before the LOD is used.
The [param compress_format] argument is the bitwise OR of, as required: One value of [enum ArrayFormat] left shifted by [code]ARRAY_FORMAT_CUSTOMn_SHIFT[/code] for each custom channel in use, [constant ARRAY_FLAG_USE_DYNAMIC_UPDATE], [constant ARRAY_FLAG_USE_8_BONE_WEIGHTS], or [constant ARRAY_FLAG_USES_EMPTY_VERTEX_ARRAY].
See [method ArrayMesh.add_surface_from_arrays] and [method ImporterMesh.add_surface] for higher-level equivalents of this method.
[b]Note:[/b] When using indices, it is recommended to only use points, lines, or triangles.

### mesh :: RID

### primitive :: int

### arrays :: Array

### blend_shapes :: Array

### lods :: Dictionary

### compress_format :: int

## mesh_clear :: func RenderingServer.mesh_clear(mesh: RID) -> void
Removes all surfaces from a mesh.

### mesh :: RID

## mesh_create :: func RenderingServer.mesh_create() -> RID
Creates a new mesh and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]mesh_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
To place in a scene, attach this mesh to an instance using [method instance_set_base] using the returned RID.
[b]Note:[/b] The equivalent resource is [Mesh].

## mesh_create_from_surfaces :: func RenderingServer.mesh_create_from_surfaces(surfaces: Dictionary[], blend_shape_count: int = 0) -> RID
Creates a new mesh with predefined surfaces for it and adds the mesh to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]mesh_*[/code] RenderingServer functions. This method is more efficient for creating meshes with multiple surfaces compared to creating an empty mesh with [method mesh_create] and adding surfaces one by one with [method mesh_add_surface].
Each element in the [param surfaces] array must follow the same structure as described in [method mesh_add_surface]. The [param blend_shape_count] parameter must match the blend shape data defined in all surfaces.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
To place in a scene, attach this mesh to an instance using [method instance_set_base] using the returned RID.
[b]Note:[/b] The equivalent resource is [Mesh].

### surfaces :: Dictionary[]

### blend_shape_count :: int

## mesh_get_blend_shape_count :: func RenderingServer.mesh_get_blend_shape_count(mesh: RID) -> int
Returns a mesh's blend shape count.

### mesh :: RID

## mesh_get_blend_shape_mode :: func RenderingServer.mesh_get_blend_shape_mode(mesh: RID) -> int
Returns a mesh's blend shape mode.

### mesh :: RID

## mesh_get_custom_aabb :: func RenderingServer.mesh_get_custom_aabb(mesh: RID) -> AABB
Returns a mesh's custom aabb.

### mesh :: RID

## mesh_get_surface :: func RenderingServer.mesh_get_surface(mesh: RID, surface: int) -> Dictionary
Returns a mesh's surface as a dictionary following the same structure as described in [method mesh_add_surface].

### mesh :: RID

### surface :: int

## mesh_get_surface_count :: func RenderingServer.mesh_get_surface_count(mesh: RID) -> int
Returns a mesh's number of surfaces.

### mesh :: RID

## mesh_set_blend_shape_mode :: func RenderingServer.mesh_set_blend_shape_mode(mesh: RID, mode: int) -> void
Sets a mesh's blend shape mode.

### mesh :: RID

### mode :: int

## mesh_set_custom_aabb :: func RenderingServer.mesh_set_custom_aabb(mesh: RID, aabb: AABB) -> void
Sets a mesh's custom aabb.

### mesh :: RID

### aabb :: AABB

## mesh_set_shadow_mesh :: func RenderingServer.mesh_set_shadow_mesh(mesh: RID, shadow_mesh: RID) -> void
Sets an optional second mesh which can be used for rendering shadows and the depth prepass. Can be used to increase performance by supplying a mesh with fused vertices and only vertex position data (without normals, UVs, colors, etc.).
[b]Note:[/b] This mesh must have exactly the same vertex positions as the source mesh (including the source mesh's LODs, if present). If vertex positions differ, then the mesh will not draw correctly.

### mesh :: RID

### shadow_mesh :: RID

## mesh_surface_get_arrays :: func RenderingServer.mesh_surface_get_arrays(mesh: RID, surface: int) -> Array
Returns a mesh's surface's buffer arrays.

### mesh :: RID

### surface :: int

## mesh_surface_get_blend_shape_arrays :: func RenderingServer.mesh_surface_get_blend_shape_arrays(mesh: RID, surface: int) -> Array[]
Returns a mesh's surface's arrays for blend shapes.

### mesh :: RID

### surface :: int

## mesh_surface_get_format_attribute_stride :: func RenderingServer.mesh_surface_get_format_attribute_stride(format: int, vertex_count: int) -> int
Returns the stride of the attribute buffer for a mesh with given [param format].

### format :: int

### vertex_count :: int

## mesh_surface_get_format_index_stride :: func RenderingServer.mesh_surface_get_format_index_stride(format: int, vertex_count: int) -> int
Returns the stride of the index buffer for a mesh with the given [param format].

### format :: int

### vertex_count :: int

## mesh_surface_get_format_normal_tangent_stride :: func RenderingServer.mesh_surface_get_format_normal_tangent_stride(format: int, vertex_count: int) -> int
Returns the stride of the combined normals and tangents for a mesh with given [param format]. Note importantly that, while normals and tangents are in the vertex buffer with vertices, they are only interleaved with each other and so have a different stride than vertex positions.

### format :: int

### vertex_count :: int

## mesh_surface_get_format_offset :: func RenderingServer.mesh_surface_get_format_offset(format: int, vertex_count: int, array_index: int) -> int
Returns the offset of a given attribute by [param array_index] in the start of its respective buffer.

### format :: int

### vertex_count :: int

### array_index :: int

## mesh_surface_get_format_skin_stride :: func RenderingServer.mesh_surface_get_format_skin_stride(format: int, vertex_count: int) -> int
Returns the stride of the skin buffer for a mesh with given [param format].

### format :: int

### vertex_count :: int

## mesh_surface_get_format_vertex_stride :: func RenderingServer.mesh_surface_get_format_vertex_stride(format: int, vertex_count: int) -> int
Returns the stride of the vertex positions for a mesh with given [param format]. Note importantly that vertex positions are stored consecutively and are not interleaved with the other attributes in the vertex buffer (normals and tangents).

### format :: int

### vertex_count :: int

## mesh_surface_get_material :: func RenderingServer.mesh_surface_get_material(mesh: RID, surface: int) -> RID
Returns a mesh's surface's material.

### mesh :: RID

### surface :: int

## mesh_surface_remove :: func RenderingServer.mesh_surface_remove(mesh: RID, surface: int) -> void
Removes the surface at the given index from the Mesh, shifting surfaces with higher index down by one.

### mesh :: RID

### surface :: int

## mesh_surface_set_material :: func RenderingServer.mesh_surface_set_material(mesh: RID, surface: int, material: RID) -> void
Sets a mesh's surface's material.

### mesh :: RID

### surface :: int

### material :: RID

## mesh_surface_update_attribute_region :: func RenderingServer.mesh_surface_update_attribute_region(mesh: RID, surface: int, offset: int, data: PackedByteArray) -> void
Updates the attribute buffer of the mesh surface with the given [param data]. The expected data per attribute is 8 or 12 bytes (4 bytes per float, 2 floats per [Vector2], and 3 floats per [Vector3]) depending on if the mesh is using [Vector2] or [Vector3] vertices. This value can be determined with [method mesh_surface_get_format_attribute_stride] instead.
The starting point of the updates can be changed with [param offset]. The value of [param offset] should be a multiple of 12 bytes in most cases to align to each attribute.
A [PackedVector3Array] of attribute locations can be converted into a [PackedByteArray] using [method PackedVector3Array.to_byte_array] for use in [param data].

### mesh :: RID

### surface :: int

### offset :: int

### data :: PackedByteArray

## mesh_surface_update_index_region :: func RenderingServer.mesh_surface_update_index_region(mesh: RID, surface: int, offset: int, data: PackedByteArray) -> void
Updates the index buffer of the mesh surface with the given [param data]. The expected data are 16 or 32-bit unsigned integers, which can be determined with [method mesh_surface_get_format_index_stride].

### mesh :: RID

### surface :: int

### offset :: int

### data :: PackedByteArray

## mesh_surface_update_skin_region :: func RenderingServer.mesh_surface_update_skin_region(mesh: RID, surface: int, offset: int, data: PackedByteArray) -> void
Updates the skin buffer of the mesh surface with the given [param data]. The expected data per skin is 8 or 12 bytes (4 bytes per float, 2 floats per [Vector2], and 3 floats per [Vector3]) depending on if the mesh is using [Vector2] or [Vector3] vertices. This value can be determined with [method mesh_surface_get_format_skin_stride] instead.
The starting point of the updates can be changed with [param offset]. The value of [param offset] should be a multiple of 12 bytes in most cases to align to each skin.
A [PackedVector3Array] of skin locations can be converted into a [PackedByteArray] using [method PackedVector3Array.to_byte_array] for use in [param data].

### mesh :: RID

### surface :: int

### offset :: int

### data :: PackedByteArray

## mesh_surface_update_vertex_region :: func RenderingServer.mesh_surface_update_vertex_region(mesh: RID, surface: int, offset: int, data: PackedByteArray) -> void
Updates the vertex buffer of the mesh surface with the given [param data]. The expected data per vertex is 8 or 12 bytes (4 bytes per float, 2 floats per [Vector2], and 3 floats per [Vector3]) depending on if the mesh is using [Vector2] or [Vector3] vertices. This value can be determined with [method mesh_surface_get_format_vertex_stride] instead.
The starting point of the updates can be changed with [param offset]. The value of [param offset] should be a multiple of 12 bytes in most cases to align to each vertex.
A [PackedVector3Array] of vertex locations can be converted into a [PackedByteArray] using [method PackedVector3Array.to_byte_array] for use in [param data].

### mesh :: RID

### surface :: int

### offset :: int

### data :: PackedByteArray

## multimesh_allocate_data :: func RenderingServer.multimesh_allocate_data(multimesh: RID, instances: int, transform_format: int, color_format: bool = false, custom_data_format: bool = false, use_indirect: bool = false) -> void
Sets up the multimesh using the specified data. The number of instances is set by [param instances]. The format of the instance transforms is set by [param transform_format], which should be set according to whether the multimesh is meant to be rendered in 2D or 3D. If [param color_format] is [code]true[/code], each instance will have a color associated with it. If [param custom_data_format] is [code]true[/code], each instance will have a custom data vector associated with it. If [param use_indirect] is [code]true[/code], an indirect command buffer will be created for this multimesh, allowing the instance count to be modified directly on the GPU. See also [method multimesh_get_command_buffer_rd_rid].

### multimesh :: RID

### instances :: int

### transform_format :: int

### color_format :: bool

### custom_data_format :: bool

### use_indirect :: bool

## multimesh_create :: func RenderingServer.multimesh_create() -> RID
Creates a new multimesh on the RenderingServer and returns an [RID] handle. This RID will be used in all [code]multimesh_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
To place in a scene, attach this multimesh to an instance using [method instance_set_base] using the returned RID.
[b]Note:[/b] The equivalent resource is [MultiMesh].

## multimesh_get_aabb :: func RenderingServer.multimesh_get_aabb(multimesh: RID) -> AABB
Calculates and returns the axis-aligned bounding box that encloses all instances within the multimesh.

### multimesh :: RID

## multimesh_get_buffer :: func RenderingServer.multimesh_get_buffer(multimesh: RID) -> PackedFloat32Array
Returns the MultiMesh data (such as instance transforms, colors, etc.). See [method multimesh_set_buffer] for details on the returned data.
[b]Note:[/b] If the buffer is in the engine's internal cache, it will have to be fetched from GPU memory and possibly decompressed. This means [method multimesh_get_buffer] is potentially a slow operation and should be avoided whenever possible.

### multimesh :: RID

## multimesh_get_buffer_rd_rid :: func RenderingServer.multimesh_get_buffer_rd_rid(multimesh: RID) -> RID
Returns the [RenderingDevice] [RID] handle of the [MultiMesh], which can be used as any other buffer on the Rendering Device.

### multimesh :: RID

## multimesh_get_command_buffer_rd_rid :: func RenderingServer.multimesh_get_command_buffer_rd_rid(multimesh: RID) -> RID
Returns the [RenderingDevice] [RID] handle of the [MultiMesh] command buffer. This [RID] is only valid if [code]use_indirect[/code] is set to [code]true[/code] when allocating data through [method multimesh_allocate_data]. It can be used to directly modify the instance count via buffer.
The data structure is dependent on both how many surfaces the mesh contains and whether it is indexed or not, the buffer has 5 integers in it, with the last unused if the mesh is not indexed.
Each of the values in the buffer correspond to these options:
[codeblock lang=text]
Indexed:
  0 - indexCount;
  1 - instanceCount;
  2 - firstIndex;
  3 - vertexOffset;
  4 - firstInstance;
Non-indexed:
  0 - vertexCount;
  1 - instanceCount;
  2 - firstVertex;
  3 - firstInstance;
  4 - unused;
[/codeblock]

### multimesh :: RID

## multimesh_get_custom_aabb :: func RenderingServer.multimesh_get_custom_aabb(multimesh: RID) -> AABB
Returns the custom AABB defined for this MultiMesh resource.

### multimesh :: RID

## multimesh_get_instance_count :: func RenderingServer.multimesh_get_instance_count(multimesh: RID) -> int
Returns the number of instances allocated for this multimesh.

### multimesh :: RID

## multimesh_get_mesh :: func RenderingServer.multimesh_get_mesh(multimesh: RID) -> RID
Returns the RID of the mesh that will be used in drawing this multimesh.

### multimesh :: RID

## multimesh_get_visible_instances :: func RenderingServer.multimesh_get_visible_instances(multimesh: RID) -> int
Returns the number of visible instances for this multimesh.

### multimesh :: RID

## multimesh_instance_get_color :: func RenderingServer.multimesh_instance_get_color(multimesh: RID, index: int) -> Color
Returns the color by which the specified instance will be modulated.

### multimesh :: RID

### index :: int

## multimesh_instance_get_custom_data :: func RenderingServer.multimesh_instance_get_custom_data(multimesh: RID, index: int) -> Color
Returns the custom data associated with the specified instance.

### multimesh :: RID

### index :: int

## multimesh_instance_get_transform :: func RenderingServer.multimesh_instance_get_transform(multimesh: RID, index: int) -> Transform3D
Returns the [Transform3D] of the specified instance.

### multimesh :: RID

### index :: int

## multimesh_instance_get_transform_2d :: func RenderingServer.multimesh_instance_get_transform_2d(multimesh: RID, index: int) -> Transform2D
Returns the [Transform2D] of the specified instance. For use when the multimesh is set to use 2D transforms.

### multimesh :: RID

### index :: int

## multimesh_instance_reset_physics_interpolation :: func RenderingServer.multimesh_instance_reset_physics_interpolation(multimesh: RID, index: int) -> void
Prevents physics interpolation for the specified instance during the current physics tick.
This is useful when moving an instance to a new location, to give an instantaneous change rather than interpolation from the previous location.

### multimesh :: RID

### index :: int

## multimesh_instance_set_color :: func RenderingServer.multimesh_instance_set_color(multimesh: RID, index: int, color: Color) -> void
Sets the color by which this instance will be modulated. Equivalent to [method MultiMesh.set_instance_color].

### multimesh :: RID

### index :: int

### color :: Color

## multimesh_instance_set_custom_data :: func RenderingServer.multimesh_instance_set_custom_data(multimesh: RID, index: int, custom_data: Color) -> void
Sets the custom data for this instance. Custom data is passed as a [Color], but is interpreted as a [code]vec4[/code] in the shader. Equivalent to [method MultiMesh.set_instance_custom_data].

### multimesh :: RID

### index :: int

### custom_data :: Color

## multimesh_instance_set_transform :: func RenderingServer.multimesh_instance_set_transform(multimesh: RID, index: int, transform: Transform3D) -> void
Sets the [Transform3D] for this instance. Equivalent to [method MultiMesh.set_instance_transform].

### multimesh :: RID

### index :: int

### transform :: Transform3D

## multimesh_instance_set_transform_2d :: func RenderingServer.multimesh_instance_set_transform_2d(multimesh: RID, index: int, transform: Transform2D) -> void
Sets the [Transform2D] for this instance. For use when multimesh is used in 2D. Equivalent to [method MultiMesh.set_instance_transform_2d].

### multimesh :: RID

### index :: int

### transform :: Transform2D

## multimesh_instances_reset_physics_interpolation :: func RenderingServer.multimesh_instances_reset_physics_interpolation(multimesh: RID) -> void
Prevents physics interpolation for all instances during the current physics tick.
This is useful when moving all instances to new locations, to give instantaneous changes rather than interpolation from the previous locations.

### multimesh :: RID

## multimesh_set_buffer :: func RenderingServer.multimesh_set_buffer(multimesh: RID, buffer: PackedFloat32Array) -> void
Set the entire data to use for drawing the [param multimesh] at once to [param buffer] (such as instance transforms and colors). [param buffer]'s size must match the number of instances multiplied by the per-instance data size (which depends on the enabled MultiMesh fields). Otherwise, an error message is printed and nothing is rendered. See also [method multimesh_get_buffer].
The per-instance data size and expected data order is:
[codeblock lang=text]
2D:
  - Position: 8 floats (8 floats for Transform2D)
  - Position + Vertex color: 12 floats (8 floats for Transform2D, 4 floats for Color)
  - Position + Custom data: 12 floats (8 floats for Transform2D, 4 floats of custom data)
  - Position + Vertex color + Custom data: 16 floats (8 floats for Transform2D, 4 floats for Color, 4 floats of custom data)
3D:
  - Position: 12 floats (12 floats for Transform3D)
  - Position + Vertex color: 16 floats (12 floats for Transform3D, 4 floats for Color)
  - Position + Custom data: 16 floats (12 floats for Transform3D, 4 floats of custom data)
  - Position + Vertex color + Custom data: 20 floats (12 floats for Transform3D, 4 floats for Color, 4 floats of custom data)
[/codeblock]
Instance transforms are in row-major order. Specifically:
- For [Transform2D] the float-order is: [code](x.x, y.x, padding_float, origin.x, x.y, y.y, padding_float, origin.y)[/code].
- For [Transform3D] the float-order is: [code](basis.x.x, basis.y.x, basis.z.x, origin.x, basis.x.y, basis.y.y, basis.z.y, origin.y, basis.x.z, basis.y.z, basis.z.z, origin.z)[/code].

### multimesh :: RID

### buffer :: PackedFloat32Array

## multimesh_set_buffer_interpolated :: func RenderingServer.multimesh_set_buffer_interpolated(multimesh: RID, buffer: PackedFloat32Array, buffer_previous: PackedFloat32Array) -> void
Alternative version of [method multimesh_set_buffer] for use with physics interpolation.
Takes both an array of current data and an array of data for the previous physics tick.

### multimesh :: RID

### buffer :: PackedFloat32Array

### buffer_previous :: PackedFloat32Array

## multimesh_set_custom_aabb :: func RenderingServer.multimesh_set_custom_aabb(multimesh: RID, aabb: AABB) -> void
Sets the custom AABB for this MultiMesh resource.

### multimesh :: RID

### aabb :: AABB

## multimesh_set_mesh :: func RenderingServer.multimesh_set_mesh(multimesh: RID, mesh: RID) -> void
Sets the mesh to be drawn by the multimesh. Equivalent to [member MultiMesh.mesh].

### multimesh :: RID

### mesh :: RID

## multimesh_set_physics_interpolated :: func RenderingServer.multimesh_set_physics_interpolated(multimesh: RID, interpolated: bool) -> void
Turns on and off physics interpolation for this MultiMesh resource.

### multimesh :: RID

### interpolated :: bool

## multimesh_set_physics_interpolation_quality :: func RenderingServer.multimesh_set_physics_interpolation_quality(multimesh: RID, quality: int) -> void
Sets the physics interpolation quality for the [MultiMesh].
A value of [constant MULTIMESH_INTERP_QUALITY_FAST] gives fast but low quality interpolation, a value of [constant MULTIMESH_INTERP_QUALITY_HIGH] gives slower but higher quality interpolation.

### multimesh :: RID

### quality :: int

## multimesh_set_visible_instances :: func RenderingServer.multimesh_set_visible_instances(multimesh: RID, visible: int) -> void
Sets the number of instances visible at a given time. If -1, all instances that have been allocated are drawn. Equivalent to [member MultiMesh.visible_instance_count].

### multimesh :: RID

### visible :: int

## occluder_create :: func RenderingServer.occluder_create() -> RID
Creates an occluder instance and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]occluder_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent resource is [Occluder3D] (not to be confused with the [OccluderInstance3D] node).

## occluder_set_mesh :: func RenderingServer.occluder_set_mesh(occluder: RID, vertices: PackedVector3Array, indices: PackedInt32Array) -> void
Sets the mesh data for the given occluder RID, which controls the shape of the occlusion culling that will be performed.

### occluder :: RID

### vertices :: PackedVector3Array

### indices :: PackedInt32Array

## omni_light_create :: func RenderingServer.omni_light_create() -> RID
Creates a new omni light and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID can be used in most [code]light_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
To place in a scene, attach this omni light to an instance using [method instance_set_base] using the returned RID.
[b]Note:[/b] The equivalent node is [OmniLight3D].

## particles_collision_create :: func RenderingServer.particles_collision_create() -> RID
Creates a new 3D GPU particle collision or attractor and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID can be used in most [code]particles_collision_*[/code] RenderingServer functions.
[b]Note:[/b] The equivalent nodes are [GPUParticlesCollision3D] and [GPUParticlesAttractor3D].

## particles_collision_height_field_update :: func RenderingServer.particles_collision_height_field_update(particles_collision: RID) -> void
Requests an update for the 3D GPU particle collision heightfield. This may be automatically called by the 3D GPU particle collision heightfield depending on its [member GPUParticlesCollisionHeightField3D.update_mode].

### particles_collision :: RID

## particles_collision_set_attractor_attenuation :: func RenderingServer.particles_collision_set_attractor_attenuation(particles_collision: RID, curve: float) -> void
Sets the attenuation [param curve] for the 3D GPU particles attractor specified by the [param particles_collision] RID. Only used for attractors, not colliders. Equivalent to [member GPUParticlesAttractor3D.attenuation].

### particles_collision :: RID

### curve :: float

## particles_collision_set_attractor_directionality :: func RenderingServer.particles_collision_set_attractor_directionality(particles_collision: RID, amount: float) -> void
Sets the directionality [param amount] for the 3D GPU particles attractor specified by the [param particles_collision] RID. Only used for attractors, not colliders. Equivalent to [member GPUParticlesAttractor3D.directionality].

### particles_collision :: RID

### amount :: float

## particles_collision_set_attractor_strength :: func RenderingServer.particles_collision_set_attractor_strength(particles_collision: RID, strength: float) -> void
Sets the [param strength] for the 3D GPU particles attractor specified by the [param particles_collision] RID. Only used for attractors, not colliders. Equivalent to [member GPUParticlesAttractor3D.strength].

### particles_collision :: RID

### strength :: float

## particles_collision_set_box_extents :: func RenderingServer.particles_collision_set_box_extents(particles_collision: RID, extents: Vector3) -> void
Sets the [param extents] for the 3D GPU particles collision by the [param particles_collision] RID. Equivalent to [member GPUParticlesCollisionBox3D.size], [member GPUParticlesCollisionSDF3D.size], [member GPUParticlesCollisionHeightField3D.size], [member GPUParticlesAttractorBox3D.size] or [member GPUParticlesAttractorVectorField3D.size] depending on the [param particles_collision] type.

### particles_collision :: RID

### extents :: Vector3

## particles_collision_set_collision_type :: func RenderingServer.particles_collision_set_collision_type(particles_collision: RID, type: int) -> void
Sets the collision or attractor shape [param type] for the 3D GPU particles collision or attractor specified by the [param particles_collision] RID.

### particles_collision :: RID

### type :: int

## particles_collision_set_cull_mask :: func RenderingServer.particles_collision_set_cull_mask(particles_collision: RID, mask: int) -> void
Sets the cull [param mask] for the 3D GPU particles collision or attractor specified by the [param particles_collision] RID. Equivalent to [member GPUParticlesCollision3D.cull_mask] or [member GPUParticlesAttractor3D.cull_mask] depending on the [param particles_collision] type.

### particles_collision :: RID

### mask :: int

## particles_collision_set_field_texture :: func RenderingServer.particles_collision_set_field_texture(particles_collision: RID, texture: RID) -> void
Sets the signed distance field [param texture] for the 3D GPU particles collision specified by the [param particles_collision] RID. Equivalent to [member GPUParticlesCollisionSDF3D.texture] or [member GPUParticlesAttractorVectorField3D.texture] depending on the [param particles_collision] type.

### particles_collision :: RID

### texture :: RID

## particles_collision_set_height_field_mask :: func RenderingServer.particles_collision_set_height_field_mask(particles_collision: RID, mask: int) -> void
Sets the heightfield [param mask] for the 3D GPU particles heightfield collision specified by the [param particles_collision] RID. Equivalent to [member GPUParticlesCollisionHeightField3D.heightfield_mask].

### particles_collision :: RID

### mask :: int

## particles_collision_set_height_field_resolution :: func RenderingServer.particles_collision_set_height_field_resolution(particles_collision: RID, resolution: int) -> void
Sets the heightmap [param resolution] for the 3D GPU particles heightfield collision specified by the [param particles_collision] RID. Equivalent to [member GPUParticlesCollisionHeightField3D.resolution].

### particles_collision :: RID

### resolution :: int

## particles_collision_set_sphere_radius :: func RenderingServer.particles_collision_set_sphere_radius(particles_collision: RID, radius: float) -> void
Sets the [param radius] for the 3D GPU particles sphere collision or attractor specified by the [param particles_collision] RID. Equivalent to [member GPUParticlesCollisionSphere3D.radius] or [member GPUParticlesAttractorSphere3D.radius] depending on the [param particles_collision] type.

### particles_collision :: RID

### radius :: float

## particles_create :: func RenderingServer.particles_create() -> RID
Creates a GPU-based particle system and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]particles_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
To place in a scene, attach these particles to an instance using [method instance_set_base] using the returned RID.
[b]Note:[/b] The equivalent nodes are [GPUParticles2D] and [GPUParticles3D].
[b]Note:[/b] All [code]particles_*[/code] methods only apply to GPU-based particles, not CPU-based particles. [CPUParticles2D] and [CPUParticles3D] do not have equivalent RenderingServer functions available, as these use [MultiMeshInstance2D] and [MultiMeshInstance3D] under the hood (see [code]multimesh_*[/code] methods).

## particles_emit :: func RenderingServer.particles_emit(particles: RID, transform: Transform3D, velocity: Vector3, color: Color, custom: Color, emit_flags: int) -> void
Manually emits particles from the [param particles] instance.

### particles :: RID

### transform :: Transform3D

### velocity :: Vector3

### color :: Color

### custom :: Color

### emit_flags :: int

## particles_get_current_aabb :: func RenderingServer.particles_get_current_aabb(particles: RID) -> AABB
Calculates and returns the axis-aligned bounding box that contains all the particles. Equivalent to [method GPUParticles3D.capture_aabb].

### particles :: RID

## particles_get_emitting :: func RenderingServer.particles_get_emitting(particles: RID) -> bool
Returns [code]true[/code] if particles are currently set to emitting.

### particles :: RID

## particles_is_inactive :: func RenderingServer.particles_is_inactive(particles: RID) -> bool
Returns [code]true[/code] if particles are not emitting and particles are set to inactive.

### particles :: RID

## particles_request_process :: func RenderingServer.particles_request_process(particles: RID) -> void
Add particle system to list of particle systems that need to be updated. Update will take place on the next frame, or on the next call to [method instances_cull_aabb], [method instances_cull_convex], or [method instances_cull_ray].

### particles :: RID

## particles_request_process_time :: func RenderingServer.particles_request_process_time(particles: RID, process_time: float, process_time_residual: float = 0.0) -> void
Requests the particles to process for extra process time during a single frame.
[param process_time] defines the time that the particles will process while emitting is on. [param process_time_residual] defines the time that particles will process with emitting turned off for the simulation. When combined with the particles' speed scale set to [code]0.0[/code], this is useful to be able to seek a particle system timeline.

### particles :: RID

### process_time :: float

### process_time_residual :: float

## particles_restart :: func RenderingServer.particles_restart(particles: RID) -> void
Reset the particles on the next update. Equivalent to [method GPUParticles3D.restart].

### particles :: RID

## particles_set_amount :: func RenderingServer.particles_set_amount(particles: RID, amount: int) -> void
Sets the number of particles to be drawn and allocates the memory for them. Equivalent to [member GPUParticles3D.amount].

### particles :: RID

### amount :: int

## particles_set_amount_ratio :: func RenderingServer.particles_set_amount_ratio(particles: RID, ratio: float) -> void
Sets the amount ratio for particles to be emitted. Equivalent to [member GPUParticles3D.amount_ratio].

### particles :: RID

### ratio :: float

## particles_set_collision_base_size :: func RenderingServer.particles_set_collision_base_size(particles: RID, size: float) -> void
Sets the base size for particle collision. Equivalent to [member GPUParticles3D.collision_base_size].

### particles :: RID

### size :: float

## particles_set_custom_aabb :: func RenderingServer.particles_set_custom_aabb(particles: RID, aabb: AABB) -> void
Sets a custom axis-aligned bounding box for the particle system. Equivalent to [member GPUParticles3D.visibility_aabb].

### particles :: RID

### aabb :: AABB

## particles_set_draw_order :: func RenderingServer.particles_set_draw_order(particles: RID, order: int) -> void
Sets the draw order of the particles. Equivalent to [member GPUParticles3D.draw_order].

### particles :: RID

### order :: int

## particles_set_draw_pass_mesh :: func RenderingServer.particles_set_draw_pass_mesh(particles: RID, pass: int, mesh: RID) -> void
Sets the mesh to be used for the specified draw pass. Equivalent to [member GPUParticles3D.draw_pass_1], [member GPUParticles3D.draw_pass_2], [member GPUParticles3D.draw_pass_3], and [member GPUParticles3D.draw_pass_4].

### particles :: RID

### pass :: int

### mesh :: RID

## particles_set_draw_passes :: func RenderingServer.particles_set_draw_passes(particles: RID, count: int) -> void
Sets the number of draw passes to use. Equivalent to [member GPUParticles3D.draw_passes].

### particles :: RID

### count :: int

## particles_set_emission_transform :: func RenderingServer.particles_set_emission_transform(particles: RID, transform: Transform3D) -> void
Sets the [Transform3D] that will be used by the particles when they first emit.

### particles :: RID

### transform :: Transform3D

## particles_set_emitter_velocity :: func RenderingServer.particles_set_emitter_velocity(particles: RID, velocity: Vector3) -> void
Sets the velocity of a particle node, that will be used by [member ParticleProcessMaterial.inherit_velocity_ratio].

### particles :: RID

### velocity :: Vector3

## particles_set_emitting :: func RenderingServer.particles_set_emitting(particles: RID, emitting: bool) -> void
If [code]true[/code], particles will emit over time. Setting to [code]false[/code] does not reset the particles, but only stops their emission. Equivalent to [member GPUParticles3D.emitting].

### particles :: RID

### emitting :: bool

## particles_set_explosiveness_ratio :: func RenderingServer.particles_set_explosiveness_ratio(particles: RID, ratio: float) -> void
Sets the explosiveness ratio. Equivalent to [member GPUParticles3D.explosiveness].

### particles :: RID

### ratio :: float

## particles_set_fixed_fps :: func RenderingServer.particles_set_fixed_fps(particles: RID, fps: int) -> void
Sets the frame rate that the particle system rendering will be fixed to. Equivalent to [member GPUParticles3D.fixed_fps].

### particles :: RID

### fps :: int

## particles_set_fractional_delta :: func RenderingServer.particles_set_fractional_delta(particles: RID, enable: bool) -> void
If [code]true[/code], uses fractional delta which smooths the movement of the particles. Equivalent to [member GPUParticles3D.fract_delta].

### particles :: RID

### enable :: bool

## particles_set_interp_to_end :: func RenderingServer.particles_set_interp_to_end(particles: RID, factor: float) -> void
Sets the value that informs a [ParticleProcessMaterial] to rush all particles towards the end of their lifetime.

### particles :: RID

### factor :: float

## particles_set_interpolate :: func RenderingServer.particles_set_interpolate(particles: RID, enable: bool) -> void
Sets whether particles should use interpolation between fixed steps. Equivalent to [member GPUParticles3D.interpolate].

### particles :: RID

### enable :: bool

## particles_set_lifetime :: func RenderingServer.particles_set_lifetime(particles: RID, lifetime: float) -> void
Sets the lifetime of each particle in the system. Equivalent to [member GPUParticles3D.lifetime].

### particles :: RID

### lifetime :: float

## particles_set_mode :: func RenderingServer.particles_set_mode(particles: RID, mode: int) -> void
Sets whether the GPU particles specified by the [param particles] RID should be rendered in 2D or 3D according to [param mode].

### particles :: RID

### mode :: int

## particles_set_one_shot :: func RenderingServer.particles_set_one_shot(particles: RID, one_shot: bool) -> void
If [code]true[/code], particles will emit once and then stop. Equivalent to [member GPUParticles3D.one_shot].

### particles :: RID

### one_shot :: bool

## particles_set_pre_process_time :: func RenderingServer.particles_set_pre_process_time(particles: RID, time: float) -> void
Sets the preprocess time for the particles' animation. This lets you delay starting an animation until after the particles have begun emitting. Equivalent to [member GPUParticles3D.preprocess].

### particles :: RID

### time :: float

## particles_set_process_material :: func RenderingServer.particles_set_process_material(particles: RID, material: RID) -> void
Sets the material for processing the particles.
[b]Note:[/b] This is not the material used to draw the materials. Equivalent to [member GPUParticles3D.process_material].

### particles :: RID

### material :: RID

## particles_set_randomness_ratio :: func RenderingServer.particles_set_randomness_ratio(particles: RID, ratio: float) -> void
Sets the emission randomness ratio. This randomizes the emission of particles within their phase. Equivalent to [member GPUParticles3D.randomness].

### particles :: RID

### ratio :: float

## particles_set_speed_scale :: func RenderingServer.particles_set_speed_scale(particles: RID, scale: float) -> void
Sets the speed scale of the particle system. Equivalent to [member GPUParticles3D.speed_scale].

### particles :: RID

### scale :: float

## particles_set_subemitter :: func RenderingServer.particles_set_subemitter(particles: RID, subemitter_particles: RID) -> void
Sets the subemitter particles for the particle system. Equivalent to [member GPUParticles3D.sub_emitter].

### particles :: RID

### subemitter_particles :: RID

## particles_set_trail_bind_poses :: func RenderingServer.particles_set_trail_bind_poses(particles: RID, bind_poses: Transform3D[]) -> void
Sets the trail bind poses for the particle system. This specified as an array of [Transform3D]s representing the bind pose for each draw pass. See [member GPUParticles3D.draw_skin], [method Skin.get_bind_count], and [method Skin.get_bind_pose]. Set the value for each draw pass to [constant Transform3D.IDENTITY] to use the default behavior, which is what built-in trails use ([RibbonTrailMesh] and [TubeTrailMesh]).

### particles :: RID

### bind_poses :: Transform3D[]

## particles_set_trails :: func RenderingServer.particles_set_trails(particles: RID, enable: bool, length_sec: float) -> void
If [param enable] is [code]true[/code], enables trails for the [param particles] with the specified [param length_sec] in seconds. Equivalent to [member GPUParticles3D.trail_enabled] and [member GPUParticles3D.trail_lifetime].

### particles :: RID

### enable :: bool

### length_sec :: float

## particles_set_transform_align :: func RenderingServer.particles_set_transform_align(particles: RID, align: int) -> void
Sets the transform alignment for the particle system. Equivalent to [member GPUParticles3D.transform_align].

### particles :: RID

### align :: int

## particles_set_transform_align_axis :: func RenderingServer.particles_set_transform_align_axis(particles: RID, rotation_axis: int) -> void
Sets which axis to use for transform alignment.

### particles :: RID

### rotation_axis :: int

## particles_set_transform_align_channel_filter :: func RenderingServer.particles_set_transform_align_channel_filter(particles: RID, channel_filter: int) -> void
When using Z-Billboarding, which CUSTOM channel to read from.

### particles :: RID

### channel_filter :: int

## particles_set_use_local_coordinates :: func RenderingServer.particles_set_use_local_coordinates(particles: RID, enable: bool) -> void
If [code]true[/code], particles use local coordinates. If [code]false[/code] they use global coordinates. Equivalent to [member GPUParticles3D.local_coords].

### particles :: RID

### enable :: bool

## positional_soft_shadow_filter_set_quality :: func RenderingServer.positional_soft_shadow_filter_set_quality(quality: int) -> void
Sets the filter quality for omni and spot light shadows in 3D. See also [member ProjectSettings.rendering/lights_and_shadows/positional_shadow/soft_shadow_filter_quality]. This parameter is global and cannot be set on a per-viewport basis.

### quality :: int

## reflection_probe_create :: func RenderingServer.reflection_probe_create() -> RID
Creates a reflection probe and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]reflection_probe_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
To place in a scene, attach this reflection probe to an instance using [method instance_set_base] using the returned RID.
[b]Note:[/b] The equivalent node is [ReflectionProbe].

## reflection_probe_set_ambient_color :: func RenderingServer.reflection_probe_set_ambient_color(probe: RID, color: Color) -> void
Sets the reflection probe's custom ambient light color. Equivalent to [member ReflectionProbe.ambient_color].

### probe :: RID

### color :: Color

## reflection_probe_set_ambient_energy :: func RenderingServer.reflection_probe_set_ambient_energy(probe: RID, energy: float) -> void
Sets the reflection probe's custom ambient light energy. Equivalent to [member ReflectionProbe.ambient_color_energy].

### probe :: RID

### energy :: float

## reflection_probe_set_ambient_mode :: func RenderingServer.reflection_probe_set_ambient_mode(probe: RID, mode: int) -> void
Sets the reflection probe's ambient light mode. Equivalent to [member ReflectionProbe.ambient_mode].

### probe :: RID

### mode :: int

## reflection_probe_set_as_interior :: func RenderingServer.reflection_probe_set_as_interior(probe: RID, enable: bool) -> void
If [code]true[/code], reflections will ignore sky contribution. Equivalent to [member ReflectionProbe.interior].

### probe :: RID

### enable :: bool

## reflection_probe_set_blend_distance :: func RenderingServer.reflection_probe_set_blend_distance(probe: RID, blend_distance: float) -> void
Sets the distance in meters over which a probe blends into the scene.

### probe :: RID

### blend_distance :: float

## reflection_probe_set_cull_mask :: func RenderingServer.reflection_probe_set_cull_mask(probe: RID, layers: int) -> void
Sets the render cull mask for this reflection probe. Only instances with a matching layer will be reflected by this probe. Equivalent to [member ReflectionProbe.cull_mask].

### probe :: RID

### layers :: int

## reflection_probe_set_enable_box_projection :: func RenderingServer.reflection_probe_set_enable_box_projection(probe: RID, enable: bool) -> void
If [code]true[/code], uses box projection. This can make reflections look more correct in certain situations. Equivalent to [member ReflectionProbe.box_projection].

### probe :: RID

### enable :: bool

## reflection_probe_set_enable_shadows :: func RenderingServer.reflection_probe_set_enable_shadows(probe: RID, enable: bool) -> void
If [code]true[/code], computes shadows in the reflection probe. This makes the reflection much slower to compute. Equivalent to [member ReflectionProbe.enable_shadows].

### probe :: RID

### enable :: bool

## reflection_probe_set_intensity :: func RenderingServer.reflection_probe_set_intensity(probe: RID, intensity: float) -> void
Sets the intensity of the reflection probe. Intensity modulates the strength of the reflection. Equivalent to [member ReflectionProbe.intensity].

### probe :: RID

### intensity :: float

## reflection_probe_set_max_distance :: func RenderingServer.reflection_probe_set_max_distance(probe: RID, distance: float) -> void
Sets the max distance away from the probe an object can be before it is culled. Equivalent to [member ReflectionProbe.max_distance].

### probe :: RID

### distance :: float

## reflection_probe_set_mesh_lod_threshold :: func RenderingServer.reflection_probe_set_mesh_lod_threshold(probe: RID, pixels: float) -> void
Sets the mesh level of detail to use in the reflection probe rendering. Higher values will use less detailed versions of meshes that have LOD variations generated, which can improve performance. Equivalent to [member ReflectionProbe.mesh_lod_threshold].

### probe :: RID

### pixels :: float

## reflection_probe_set_origin_offset :: func RenderingServer.reflection_probe_set_origin_offset(probe: RID, offset: Vector3) -> void
Sets the origin offset to be used when this reflection probe is in box project mode. Equivalent to [member ReflectionProbe.origin_offset].

### probe :: RID

### offset :: Vector3

## reflection_probe_set_reflection_mask :: func RenderingServer.reflection_probe_set_reflection_mask(probe: RID, layers: int) -> void
Sets the render reflection mask for this reflection probe. Only instances with a matching layer will have reflections applied from this probe. Equivalent to [member ReflectionProbe.reflection_mask].

### probe :: RID

### layers :: int

## reflection_probe_set_resolution :: func RenderingServer.reflection_probe_set_resolution(probe: RID, resolution: int) -> void
Deprecated. This method does nothing.

### probe :: RID

### resolution :: int

## reflection_probe_set_size :: func RenderingServer.reflection_probe_set_size(probe: RID, size: Vector3) -> void
Sets the size of the area that the reflection probe will capture. Equivalent to [member ReflectionProbe.size].

### probe :: RID

### size :: Vector3

## reflection_probe_set_update_mode :: func RenderingServer.reflection_probe_set_update_mode(probe: RID, mode: int) -> void
Sets how often the reflection probe updates. Can either be once or every frame.

### probe :: RID

### mode :: int

## request_frame_drawn_callback :: func RenderingServer.request_frame_drawn_callback(callable: Callable) -> void
Schedules a callback to the given callable after a frame has been drawn.

### callable :: Callable

## scenario_create :: func RenderingServer.scenario_create() -> RID
Creates a scenario and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]scenario_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
The scenario is the 3D world that all the visual instances exist in.

## scenario_set_camera_attributes :: func RenderingServer.scenario_set_camera_attributes(scenario: RID, effects: RID) -> void
Sets the camera attributes ([param effects]) that will be used with this scenario. See also [CameraAttributes].

### scenario :: RID

### effects :: RID

## scenario_set_compositor :: func RenderingServer.scenario_set_compositor(scenario: RID, compositor: RID) -> void
Sets the compositor ([param compositor]) that will be used with this scenario. See also [Compositor].

### scenario :: RID

### compositor :: RID

## scenario_set_environment :: func RenderingServer.scenario_set_environment(scenario: RID, environment: RID) -> void
Sets the environment that will be used with this scenario. See also [Environment].

### scenario :: RID

### environment :: RID

## scenario_set_fallback_environment :: func RenderingServer.scenario_set_fallback_environment(scenario: RID, environment: RID) -> void
Sets the fallback environment to be used by this scenario. The fallback environment is used if no environment is set. Internally, this is used by the editor to provide a default environment.

### scenario :: RID

### environment :: RID

## screen_space_roughness_limiter_set_active :: func RenderingServer.screen_space_roughness_limiter_set_active(enable: bool, amount: float, limit: float) -> void
Sets the screen-space roughness limiter parameters, such as whether it should be enabled and its thresholds. Equivalent to [member ProjectSettings.rendering/anti_aliasing/screen_space_roughness_limiter/enabled], [member ProjectSettings.rendering/anti_aliasing/screen_space_roughness_limiter/amount] and [member ProjectSettings.rendering/anti_aliasing/screen_space_roughness_limiter/limit].

### enable :: bool

### amount :: float

### limit :: float

## set_boot_image :: func RenderingServer.set_boot_image(image: Image, color: Color, scale: bool, use_filter: bool = true) -> void
Sets a boot image. The [param color] defines the background color. The value of [param scale] indicates if the image will be scaled to fit the screen size. If [param use_filter] is [code]true[/code], the image will be scaled with linear interpolation. If [param use_filter] is [code]false[/code], the image will be scaled with nearest-neighbor interpolation.

### image :: Image

### color :: Color

### scale :: bool

### use_filter :: bool

## set_boot_image_with_stretch :: func RenderingServer.set_boot_image_with_stretch(image: Image, color: Color, stretch_mode: int, use_filter: bool = true) -> void
Sets a boot image. The [param color] defines the background color. The value of [param stretch_mode] indicates how the image will be stretched (see [enum SplashStretchMode] for possible values). If [param use_filter] is [code]true[/code], the image will be scaled with linear interpolation. If [param use_filter] is [code]false[/code], the image will be scaled with nearest-neighbor interpolation.

### image :: Image

### color :: Color

### stretch_mode :: int

### use_filter :: bool

## set_debug_generate_wireframes :: func RenderingServer.set_debug_generate_wireframes(generate: bool) -> void
If [param generate] is [code]true[/code], generates debug wireframes for all meshes that are loaded when using the Compatibility renderer. By default, the engine does not generate debug wireframes at runtime, since they slow down loading of assets and take up VRAM.
[b]Note:[/b] You must call this method before loading any meshes when using the Compatibility renderer. Otherwise, wireframes will not be used.

### generate :: bool

## set_default_clear_color :: func RenderingServer.set_default_clear_color(color: Color) -> void
Sets the default clear color which is used when a specific clear color has not been selected. See also [method get_default_clear_color].

### color :: Color

## shader_create :: func RenderingServer.shader_create() -> RID
Creates an empty shader and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]shader_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent resource is [Shader].

## shader_get_code :: func RenderingServer.shader_get_code(shader: RID) -> String
Returns a shader's source code as a string.

### shader :: RID

## shader_get_default_texture_parameter :: func RenderingServer.shader_get_default_texture_parameter(shader: RID, name: StringName, index: int = 0) -> RID
Returns a default texture from a shader searched by name.
[b]Note:[/b] If the sampler array is used use [param index] to access the specified texture.

### shader :: RID

### name :: StringName

### index :: int

## shader_get_parameter_default :: func RenderingServer.shader_get_parameter_default(shader: RID, name: StringName) -> Variant
Returns the default value for the specified shader uniform. This is usually the value written in the shader source code.

### shader :: RID

### name :: StringName

## shader_set_code :: func RenderingServer.shader_set_code(shader: RID, code: String) -> void
Sets the shader's source code (which triggers recompilation after being changed).

### shader :: RID

### code :: String

## shader_set_default_texture_parameter :: func RenderingServer.shader_set_default_texture_parameter(shader: RID, name: StringName, texture: RID, index: int = 0) -> void
Sets a shader's default texture. Overwrites the texture given by name.
[b]Note:[/b] If the sampler array is used use [param index] to access the specified texture.

### shader :: RID

### name :: StringName

### texture :: RID

### index :: int

## shader_set_path_hint :: func RenderingServer.shader_set_path_hint(shader: RID, path: String) -> void
Sets the path hint for the specified shader. This should generally match the [Shader] resource's [member Resource.resource_path].

### shader :: RID

### path :: String

## skeleton_allocate_data :: func RenderingServer.skeleton_allocate_data(skeleton: RID, bones: int, is_2d_skeleton: bool = false) -> void
Allocates data for this skeleton using the number of bones specified in [param bones]. If [param is_2d_skeleton] is [code]true[/code], the skeleton will be treated as a 2D skeleton instead of a 3D skeleton. See also [method skeleton_get_bone_count].

### skeleton :: RID

### bones :: int

### is_2d_skeleton :: bool

## skeleton_bone_get_transform :: func RenderingServer.skeleton_bone_get_transform(skeleton: RID, bone: int) -> Transform3D
Returns the [Transform3D] set for a specific bone of this skeleton.

### skeleton :: RID

### bone :: int

## skeleton_bone_get_transform_2d :: func RenderingServer.skeleton_bone_get_transform_2d(skeleton: RID, bone: int) -> Transform2D
Returns the [Transform2D] set for a specific bone of this skeleton.

### skeleton :: RID

### bone :: int

## skeleton_bone_set_transform :: func RenderingServer.skeleton_bone_set_transform(skeleton: RID, bone: int, transform: Transform3D) -> void
Sets the [Transform3D] for a specific bone of this skeleton.

### skeleton :: RID

### bone :: int

### transform :: Transform3D

## skeleton_bone_set_transform_2d :: func RenderingServer.skeleton_bone_set_transform_2d(skeleton: RID, bone: int, transform: Transform2D) -> void
Sets the [Transform2D] for a specific bone of this skeleton.

### skeleton :: RID

### bone :: int

### transform :: Transform2D

## skeleton_create :: func RenderingServer.skeleton_create() -> RID
Creates a skeleton and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]skeleton_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.

## skeleton_get_bone_count :: func RenderingServer.skeleton_get_bone_count(skeleton: RID) -> int
Returns the number of bones allocated for this skeleton. See also [method skeleton_allocate_data].

### skeleton :: RID

## skeleton_set_base_transform_2d :: func RenderingServer.skeleton_set_base_transform_2d(skeleton: RID, base_transform: Transform2D) -> void
Sets the base [Transform2D] to use for the specified skeleton.

### skeleton :: RID

### base_transform :: Transform2D

## sky_bake_panorama :: func RenderingServer.sky_bake_panorama(sky: RID, energy: float, bake_irradiance: bool, size: Vector2i) -> Image
Generates and returns an [Image] containing the radiance map for the specified [param sky] RID. This supports built-in sky material and custom sky shaders. If [param bake_irradiance] is [code]true[/code], the irradiance map is saved instead of the radiance map. The radiance map is used to render reflected light, while the irradiance map is used to render ambient light. See also [method environment_bake_panorama].
[b]Note:[/b] The image is saved using linear encoding without any tonemapping performed, which means it will look too dark if viewed directly in an image editor. [param energy] values above [code]1.0[/code] can be used to brighten the resulting image.
[b]Note:[/b] [param size] should be a 2:1 aspect ratio for the generated panorama to have square pixels. For radiance maps, there is no point in using a height greater than [member Sky.radiance_size], as it won't increase detail. Irradiance maps only contain low-frequency data, so there is usually no point in going past a size of 128×64 pixels when saving an irradiance map.

### sky :: RID

### energy :: float

### bake_irradiance :: bool

### size :: Vector2i

## sky_create :: func RenderingServer.sky_create() -> RID
Creates an empty sky and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]sky_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.

## sky_set_material :: func RenderingServer.sky_set_material(sky: RID, material: RID) -> void
Sets the material that the sky uses to render the background, ambient and reflection maps.

### sky :: RID

### material :: RID

## sky_set_mode :: func RenderingServer.sky_set_mode(sky: RID, mode: int) -> void
Sets the process [param mode] of the sky specified by the [param sky] RID. Equivalent to [member Sky.process_mode].

### sky :: RID

### mode :: int

## sky_set_radiance_size :: func RenderingServer.sky_set_radiance_size(sky: RID, radiance_size: int) -> void
Sets the [param radiance_size] of the sky specified by the [param sky] RID (in pixels). Equivalent to [member Sky.radiance_size].

### sky :: RID

### radiance_size :: int

## spot_light_create :: func RenderingServer.spot_light_create() -> RID
Creates a spot light and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID can be used in most [code]light_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
To place in a scene, attach this spot light to an instance using [method instance_set_base] using the returned RID.

## sub_surface_scattering_set_quality :: func RenderingServer.sub_surface_scattering_set_quality(quality: int) -> void
Sets [member ProjectSettings.rendering/environment/subsurface_scattering/subsurface_scattering_quality] to use when rendering materials that have subsurface scattering enabled.

### quality :: int

## sub_surface_scattering_set_scale :: func RenderingServer.sub_surface_scattering_set_scale(scale: float, depth_scale: float) -> void
Sets the [member ProjectSettings.rendering/environment/subsurface_scattering/subsurface_scattering_scale] and [member ProjectSettings.rendering/environment/subsurface_scattering/subsurface_scattering_depth_scale] to use when rendering materials that have subsurface scattering enabled.

### scale :: float

### depth_scale :: float

## texture_2d_create :: func RenderingServer.texture_2d_create(image: Image) -> RID
Creates a 2-dimensional texture and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]texture_2d_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent resource is [Texture2D].
[b]Note:[/b] Not to be confused with [method RenderingDevice.texture_create], which creates the graphics API's own texture type as opposed to the Godot-specific [Texture2D] resource.

### image :: Image

## texture_2d_get :: func RenderingServer.texture_2d_get(texture: RID) -> Image
Returns an [Image] instance from the given [param texture] [RID].
[b]Example:[/b] Get the test texture from [method get_test_texture] and apply it to a [Sprite2D] node:
[codeblock]
var texture_rid = RenderingServer.get_test_texture()
var texture = ImageTexture.create_from_image(RenderingServer.texture_2d_get(texture_rid))
$Sprite2D.texture = texture
[/codeblock]

### texture :: RID

## texture_2d_layer_get :: func RenderingServer.texture_2d_layer_get(texture: RID, layer: int) -> Image
Returns an [Image] instance from the given [param texture] [RID] and [param layer].

### texture :: RID

### layer :: int

## texture_2d_layered_create :: func RenderingServer.texture_2d_layered_create(layers: Image[], layered_type: int) -> RID
Creates a 2-dimensional layered texture and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]texture_2d_layered_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent resource is [TextureLayered].

### layers :: Image[]

### layered_type :: int

## texture_2d_layered_placeholder_create :: func RenderingServer.texture_2d_layered_placeholder_create(layered_type: int) -> RID
Creates a placeholder for a 2-dimensional layered texture and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]texture_2d_layered_*[/code] RenderingServer functions, although it does nothing when used. See also [method texture_2d_placeholder_create].
[b]Note:[/b] The equivalent resource is [PlaceholderTextureLayered].

### layered_type :: int

## texture_2d_placeholder_create :: func RenderingServer.texture_2d_placeholder_create() -> RID
Creates a placeholder for a 2-dimensional layered texture and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]texture_2d_layered_*[/code] RenderingServer functions, although it does nothing when used. See also [method texture_2d_layered_placeholder_create].
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent resource is [PlaceholderTexture2D].

## texture_2d_update :: func RenderingServer.texture_2d_update(texture: RID, image: Image, layer: int) -> void
Updates the texture specified by the [param texture] [RID] with the data in [param image]. A [param layer] must also be specified, which should be [code]0[/code] when updating a single-layer texture ([Texture2D]).
[b]Note:[/b] The [param image] must have the same width, height and format as the current [param texture] data. Otherwise, an error will be printed and the original texture won't be modified. If you need to use different width, height or format, use [method texture_replace] instead.

### texture :: RID

### image :: Image

### layer :: int

## texture_3d_create :: func RenderingServer.texture_3d_create(format: int, width: int, height: int, depth: int, mipmaps: bool, data: Image[]) -> RID
[b]Note:[/b] The equivalent resource is [Texture3D].

### format :: int

### width :: int

### height :: int

### depth :: int

### mipmaps :: bool

### data :: Image[]

## texture_3d_get :: func RenderingServer.texture_3d_get(texture: RID) -> Image[]
Returns 3D texture data as an array of [Image]s for the specified texture [RID].

### texture :: RID

## texture_3d_placeholder_create :: func RenderingServer.texture_3d_placeholder_create() -> RID
Creates a placeholder for a 3-dimensional texture and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]texture_3d_*[/code] RenderingServer functions, although it does nothing when used.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent resource is [PlaceholderTexture3D].

## texture_3d_update :: func RenderingServer.texture_3d_update(texture: RID, data: Image[]) -> void
Updates the texture specified by the [param texture] [RID]'s data with the data in [param data]. All the texture's layers must be replaced at once.
[b]Note:[/b] The [param texture] must have the same width, height, depth and format as the current texture data. Otherwise, an error will be printed and the original texture won't be modified. If you need to use different width, height, depth or format, use [method texture_replace] instead.

### texture :: RID

### data :: Image[]

## texture_create_from_native_handle :: func RenderingServer.texture_create_from_native_handle(type: int, format: int, native_handle: int, width: int, height: int, depth: int, layers: int = 1, layered_type: int = 0) -> RID
Creates a texture based on a native handle that was created outside of Godot's renderer.
[b]Note:[/b] If using only the rendering device renderer, it's recommend to use [method RenderingDevice.texture_create_from_extension] together with [method RenderingServer.texture_rd_create], rather than this method. This way, the texture's format and usage can be controlled more effectively.

### type :: int

### format :: int

### native_handle :: int

### width :: int

### height :: int

### depth :: int

### layers :: int

### layered_type :: int

## texture_drawable_blit_rect :: func RenderingServer.texture_drawable_blit_rect(textures: RID[], rect: Rect2i, material: RID, modulate: Color, source_textures: RID[], to_mipmap: int = 0) -> void
Draws to [param rect] on up to 4 given Drawable [param textures], using a TextureBlit Shader from [param material]. [param modulate] and up to 4 [param source_textures] are uniforms for the Shader to process with. [param to_mipmap] can specify to perform this draw to a lower mipmap level.
[b]Note:[/b] All [param textures] must be the same size and format.

### textures :: RID[]

### rect :: Rect2i

### material :: RID

### modulate :: Color

### source_textures :: RID[]

### to_mipmap :: int

## texture_drawable_create :: func RenderingServer.texture_drawable_create(width: int, height: int, format: int, color: Color = Color(1, 1, 1, 1), with_mipmaps: bool = false) -> RID
Creates a 2-dimensional texture and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]texture_drawable*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent resource is [DrawableTexture2D].

### width :: int

### height :: int

### format :: int

### color :: Color

### with_mipmaps :: bool

## texture_drawable_generate_mipmaps :: func RenderingServer.texture_drawable_generate_mipmaps(texture: RID) -> void
Calculates new MipMaps for the given Drawable [param texture].

### texture :: RID

## texture_drawable_get_default_material :: func RenderingServer.texture_drawable_get_default_material() -> RID
Returns a ShaderMaterial with the default texture_blit Shader.

## texture_get_format :: func RenderingServer.texture_get_format(texture: RID) -> int
Returns the format for the texture.

### texture :: RID

## texture_get_native_handle :: func RenderingServer.texture_get_native_handle(texture: RID, srgb: bool = false) -> int
Returns the internal graphics handle for this texture object. For use when communicating with third-party APIs mostly with GDExtension.
[param srgb] should be [code]true[/code] when the texture uses nonlinear sRGB encoding and [code]false[/code] when the texture uses linear encoding.
[b]Note:[/b] This function returns a [code]uint64_t[/code] which internally maps to a [code]GLuint[/code] (OpenGL) or [code]VkImage[/code] (Vulkan).

### texture :: RID

### srgb :: bool

## texture_get_path :: func RenderingServer.texture_get_path(texture: RID) -> String
Returns the resource path (starting with [code]res://[/code] or [code]uid://[/code]) for the specified texture RID. Returns an empty [String] if the resource is built-in. See also [method texture_set_path].

### texture :: RID

## texture_get_rd_texture :: func RenderingServer.texture_get_rd_texture(texture: RID, srgb: bool = false) -> RID
Returns a texture [RID] that can be used with [RenderingDevice].
[param srgb] should be [code]true[/code] when the texture uses nonlinear sRGB encoding and [code]false[/code] when the texture uses linear encoding.

### texture :: RID

### srgb :: bool

## texture_proxy_create :: func RenderingServer.texture_proxy_create(base: RID) -> RID
This method does nothing and always returns an invalid [RID].

### base :: RID

## texture_proxy_update :: func RenderingServer.texture_proxy_update(texture: RID, proxy_to: RID) -> void
This method does nothing.

### texture :: RID

### proxy_to :: RID

## texture_rd_create :: func RenderingServer.texture_rd_create(rd_texture: RID, layer_type: int = 0) -> RID
Creates a new texture object based on a texture created directly on the [RenderingDevice]. If the texture contains layers, [param layer_type] is used to define the layer type.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The RenderingServer's [method free_rid] won't free the underlying [param rd_texture], you will want to free the [param rd_texture] using [method RenderingDevice.free_rid].

### rd_texture :: RID

### layer_type :: int

## texture_replace :: func RenderingServer.texture_replace(texture: RID, by_texture: RID) -> void
Replaces [param texture]'s texture data by the texture specified by the [param by_texture] RID, without changing [param texture]'s RID.

### texture :: RID

### by_texture :: RID

## texture_set_force_redraw_if_visible :: func RenderingServer.texture_set_force_redraw_if_visible(texture: RID, enable: bool) -> void
Sets whether the texture RID should force redrawing when it's visible on screen when [member OS.low_processor_usage_mode] is [code]true[/code]. This is used by [AnimatedTexture] to force redrawing.

### texture :: RID

### enable :: bool

## texture_set_path :: func RenderingServer.texture_set_path(texture: RID, path: String) -> void
Sets the resource path for this texture RID. See also [method texture_get_path].
[b]Note:[/b] This is purely a hint and does not cause the texture to be automatically saved when set to a [code]res://[/code] path.

### texture :: RID

### path :: String

## texture_set_size_override :: func RenderingServer.texture_set_size_override(texture: RID, width: int, height: int) -> void
Sets the size at which the texture should be [i]displayed[/i] in 2D, ignoring its original size. This does not rescale the texture data itself, only how it is drawn in 2D. Set [param width] and [param height] to 0 to disable the size override.

### texture :: RID

### width :: int

### height :: int

## viewport_attach_camera :: func RenderingServer.viewport_attach_camera(viewport: RID, camera: RID) -> void
Sets a viewport's camera.

### viewport :: RID

### camera :: RID

## viewport_attach_canvas :: func RenderingServer.viewport_attach_canvas(viewport: RID, canvas: RID) -> void
Sets a viewport's canvas.

### viewport :: RID

### canvas :: RID

## viewport_attach_to_screen :: func RenderingServer.viewport_attach_to_screen(viewport: RID, rect: Rect2 = Rect2(0, 0, 0, 0), screen: int = 0) -> void
Copies the viewport to a region of the screen specified by [param rect]. If [method viewport_set_render_direct_to_screen] is [code]true[/code], then the viewport does not use a framebuffer and the contents of the viewport are rendered directly to screen. However, note that the root viewport is drawn last, therefore it will draw over the screen. Accordingly, you must set the root viewport to an area that does not cover the area that you have attached this viewport to.
For example, you can set the root viewport to not render at all with the following code:
[codeblocks]
[gdscript]
func _ready():
	RenderingServer.viewport_attach_to_screen(get_viewport().get_viewport_rid(), Rect2())
	RenderingServer.viewport_attach_to_screen($Viewport.get_viewport_rid(), Rect2(0, 0, 600, 600))
[/gdscript]
[/codeblocks]
Using this can result in significant optimization, especially on lower-end devices. However, it comes at the cost of having to manage your viewports manually. For further optimization, see [method viewport_set_render_direct_to_screen].

### viewport :: RID

### rect :: Rect2

### screen :: int

## viewport_create :: func RenderingServer.viewport_create() -> RID
Creates an empty viewport and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]viewport_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent node is [Viewport].

## viewport_get_measured_render_time_cpu :: func RenderingServer.viewport_get_measured_render_time_cpu(viewport: RID) -> float
Returns the CPU time taken to render the last frame in milliseconds. This [i]only[/i] includes time spent in rendering-related operations; scripts' [code]_process[/code] functions and other engine subsystems are not included in this readout. To get a complete readout of CPU time spent to render the scene, sum the render times of all viewports that are drawn every frame plus [method get_frame_setup_time_cpu]. Unlike [method Engine.get_frames_per_second], this method will accurately reflect CPU utilization even if framerate is capped via V-Sync or [member Engine.max_fps]. See also [method viewport_get_measured_render_time_gpu].
[b]Note:[/b] Requires measurements to be enabled on the specified [param viewport] using [method viewport_set_measure_render_time]. Otherwise, this method returns [code]0.0[/code].

### viewport :: RID

## viewport_get_measured_render_time_gpu :: func RenderingServer.viewport_get_measured_render_time_gpu(viewport: RID) -> float
Returns the GPU time taken to render the last frame in milliseconds. To get a complete readout of GPU time spent to render the scene, sum the render times of all viewports that are drawn every frame. Unlike [method Engine.get_frames_per_second], this method accurately reflects GPU utilization even if framerate is capped via V-Sync or [member Engine.max_fps]. See also [method viewport_get_measured_render_time_cpu].
[b]Note:[/b] Requires measurements to be enabled on the specified [param viewport] using [method viewport_set_measure_render_time]. Otherwise, this method returns [code]0.0[/code].
[b]Note:[/b] When GPU utilization is low enough during a certain period of time, GPUs will decrease their power state (which in turn decreases core and memory clock speeds). This can cause the reported GPU time to increase if GPU utilization is kept low enough by a framerate cap (compared to what it would be at the GPU's highest power state). Keep this in mind when benchmarking using [method viewport_get_measured_render_time_gpu]. This behavior can be overridden in the graphics driver settings at the cost of higher power usage.

### viewport :: RID

## viewport_get_render_info :: func RenderingServer.viewport_get_render_info(viewport: RID, type: int, info: int) -> int
Returns a statistic about the rendering engine which can be used for performance profiling. This is separated into render pass [param type]s, each of them having the same [param info]s you can query (different passes will return different values).
See also [method get_rendering_info], which returns global information across all viewports.
[b]Note:[/b] Viewport rendering information is not available until at least 2 frames have been rendered by the engine. If rendering information is not available, [method viewport_get_render_info] returns [code]0[/code]. To print rendering information in [code]_ready()[/code] successfully, use the following:
[codeblock]
func _ready():
	for _i in 2:
		await get_tree().process_frame

	print(
			RenderingServer.viewport_get_render_info(get_viewport().get_viewport_rid(),
			RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE,
			RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME)
	)
[/codeblock]

### viewport :: RID

### type :: int

### info :: int

## viewport_get_render_target :: func RenderingServer.viewport_get_render_target(viewport: RID) -> RID
Returns the render target for the viewport.

### viewport :: RID

## viewport_get_texture :: func RenderingServer.viewport_get_texture(viewport: RID) -> RID
Returns the viewport's last rendered frame.

### viewport :: RID

## viewport_get_update_mode :: func RenderingServer.viewport_get_update_mode(viewport: RID) -> int
Returns the viewport's update mode.
[b]Warning:[/b] Calling this from any thread other than the rendering thread will be detrimental to performance.

### viewport :: RID

## viewport_remove_canvas :: func RenderingServer.viewport_remove_canvas(viewport: RID, canvas: RID) -> void
Detaches a viewport from a canvas.

### viewport :: RID

### canvas :: RID

## viewport_set_active :: func RenderingServer.viewport_set_active(viewport: RID, active: bool) -> void
If [code]true[/code], sets the viewport active, else sets it inactive.

### viewport :: RID

### active :: bool

## viewport_set_anisotropic_filtering_level :: func RenderingServer.viewport_set_anisotropic_filtering_level(viewport: RID, anisotropic_filtering_level: int) -> void
Sets the maximum number of samples to take when using anisotropic filtering on textures (as a power of two). A higher sample count will result in sharper textures at oblique angles, but is more expensive to compute. A value of [code]0[/code] forcibly disables anisotropic filtering, even on materials where it is enabled.
The anisotropic filtering level also affects decals and light projectors if they are configured to use anisotropic filtering. See [member ProjectSettings.rendering/textures/decals/filter] and [member ProjectSettings.rendering/textures/light_projectors/filter].
[b]Note:[/b] In 3D, for this setting to have an effect, set [member BaseMaterial3D.texture_filter] to [constant BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC] or [constant BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS_ANISOTROPIC] on materials.
[b]Note:[/b] In 2D, for this setting to have an effect, set [member CanvasItem.texture_filter] to [constant CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC] or [constant CanvasItem.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS_ANISOTROPIC] on the [CanvasItem] node displaying the texture (or in [CanvasTexture]). However, anisotropic filtering is rarely useful in 2D, so only enable it for textures in 2D if it makes a meaningful visual difference.

### viewport :: RID

### anisotropic_filtering_level :: int

## viewport_set_canvas_cull_mask :: func RenderingServer.viewport_set_canvas_cull_mask(viewport: RID, canvas_cull_mask: int) -> void
Sets the rendering mask associated with this [Viewport]. Only [CanvasItem] nodes with a matching rendering visibility layer will be rendered by this [Viewport].

### viewport :: RID

### canvas_cull_mask :: int

## viewport_set_canvas_stacking :: func RenderingServer.viewport_set_canvas_stacking(viewport: RID, canvas: RID, layer: int, sublayer: int) -> void
Sets the stacking order for a viewport's canvas.
[param layer] is the actual canvas layer, while [param sublayer] specifies the stacking order of the canvas among those in the same layer.
[b]Note:[/b] [param layer] should be between [constant CANVAS_LAYER_MIN] and [constant CANVAS_LAYER_MAX] (inclusive). Any other value will wrap around.

### viewport :: RID

### canvas :: RID

### layer :: int

### sublayer :: int

## viewport_set_canvas_transform :: func RenderingServer.viewport_set_canvas_transform(viewport: RID, canvas: RID, offset: Transform2D) -> void
Sets the transformation of a viewport's canvas.

### viewport :: RID

### canvas :: RID

### offset :: Transform2D

## viewport_set_clear_mode :: func RenderingServer.viewport_set_clear_mode(viewport: RID, clear_mode: int) -> void
Sets the clear mode of a viewport.

### viewport :: RID

### clear_mode :: int

## viewport_set_debug_draw :: func RenderingServer.viewport_set_debug_draw(viewport: RID, draw: int) -> void
Sets the debug draw mode of a viewport.

### viewport :: RID

### draw :: int

## viewport_set_default_canvas_item_texture_filter :: func RenderingServer.viewport_set_default_canvas_item_texture_filter(viewport: RID, filter: int) -> void
Sets the default texture filtering mode for the specified [param viewport] RID.

### viewport :: RID

### filter :: int

## viewport_set_default_canvas_item_texture_repeat :: func RenderingServer.viewport_set_default_canvas_item_texture_repeat(viewport: RID, repeat: int) -> void
Sets the default texture repeat mode for the specified [param viewport] RID.

### viewport :: RID

### repeat :: int

## viewport_set_disable_2d :: func RenderingServer.viewport_set_disable_2d(viewport: RID, disable: bool) -> void
If [code]true[/code], the viewport's canvas (i.e. 2D and GUI elements) is not rendered.

### viewport :: RID

### disable :: bool

## viewport_set_disable_3d :: func RenderingServer.viewport_set_disable_3d(viewport: RID, disable: bool) -> void
If [code]true[/code], the viewport's 3D elements are not rendered.

### viewport :: RID

### disable :: bool

## viewport_set_environment_mode :: func RenderingServer.viewport_set_environment_mode(viewport: RID, mode: int) -> void
Sets the viewport's environment mode which allows enabling or disabling rendering of 3D environment over 2D canvas. When disabled, 2D will not be affected by the environment. When enabled, 2D will be affected by the environment if the environment background mode is [constant ENV_BG_CANVAS]. The default behavior is to inherit the setting from the viewport's parent. If the topmost parent is also set to [constant VIEWPORT_ENVIRONMENT_INHERIT], then the behavior will be the same as if it was set to [constant VIEWPORT_ENVIRONMENT_ENABLED].

### viewport :: RID

### mode :: int

## viewport_set_fsr_sharpness :: func RenderingServer.viewport_set_fsr_sharpness(viewport: RID, sharpness: float) -> void
Determines how sharp the upscaled image will be when using the FSR upscaling mode. Sharpness halves with every whole number. Values go from 0.0 (sharpest) to 2.0. Values above 2.0 won't make a visible difference.

### viewport :: RID

### sharpness :: float

## viewport_set_global_canvas_transform :: func RenderingServer.viewport_set_global_canvas_transform(viewport: RID, transform: Transform2D) -> void
Sets the viewport's global transformation matrix.

### viewport :: RID

### transform :: Transform2D

## viewport_set_measure_render_time :: func RenderingServer.viewport_set_measure_render_time(viewport: RID, enable: bool) -> void
Sets the measurement for the given [param viewport] RID (obtained using [method Viewport.get_viewport_rid]). Once enabled, [method viewport_get_measured_render_time_cpu] and [method viewport_get_measured_render_time_gpu] will return values greater than [code]0.0[/code] when queried with the given [param viewport].

### viewport :: RID

### enable :: bool

## viewport_set_msaa_2d :: func RenderingServer.viewport_set_msaa_2d(viewport: RID, msaa: int) -> void
Sets the multisample antialiasing mode for 2D/Canvas on the specified [param viewport] RID. Equivalent to [member ProjectSettings.rendering/anti_aliasing/quality/msaa_2d] or [member Viewport.msaa_2d].

### viewport :: RID

### msaa :: int

## viewport_set_msaa_3d :: func RenderingServer.viewport_set_msaa_3d(viewport: RID, msaa: int) -> void
Sets the multisample antialiasing mode for 3D on the specified [param viewport] RID. Equivalent to [member ProjectSettings.rendering/anti_aliasing/quality/msaa_3d] or [member Viewport.msaa_3d].

### viewport :: RID

### msaa :: int

## viewport_set_occlusion_culling_build_quality :: func RenderingServer.viewport_set_occlusion_culling_build_quality(quality: int) -> void
Sets the [member ProjectSettings.rendering/occlusion_culling/bvh_build_quality] to use for occlusion culling. This parameter is global and cannot be set on a per-viewport basis.

### quality :: int

## viewport_set_occlusion_rays_per_thread :: func RenderingServer.viewport_set_occlusion_rays_per_thread(rays_per_thread: int) -> void
Sets the [member ProjectSettings.rendering/occlusion_culling/occlusion_rays_per_thread] to use for occlusion culling. This parameter is global and cannot be set on a per-viewport basis.

### rays_per_thread :: int

## viewport_set_parent_viewport :: func RenderingServer.viewport_set_parent_viewport(viewport: RID, parent_viewport: RID) -> void
Sets the viewport's parent to the viewport specified by the [param parent_viewport] RID.

### viewport :: RID

### parent_viewport :: RID

## viewport_set_positional_shadow_atlas_quadrant_subdivision :: func RenderingServer.viewport_set_positional_shadow_atlas_quadrant_subdivision(viewport: RID, quadrant: int, subdivision: int) -> void
Sets the number of subdivisions to use in the specified shadow atlas [param quadrant] for omni and spot shadows. See also [method Viewport.set_positional_shadow_atlas_quadrant_subdiv].

### viewport :: RID

### quadrant :: int

### subdivision :: int

## viewport_set_positional_shadow_atlas_size :: func RenderingServer.viewport_set_positional_shadow_atlas_size(viewport: RID, size: int, use_16_bits: bool = false) -> void
Sets the [param size] of the shadow atlas's images (used for omni and spot lights) on the viewport specified by the [param viewport] RID. The value is rounded up to the nearest power of 2. If [param use_16_bits] is [code]true[/code], use 16 bits for the omni/spot shadow depth map. Enabling this results in shadows having less precision and may result in shadow acne, but can lead to performance improvements on some devices.
[b]Note:[/b] If this is set to [code]0[/code], no positional shadows will be visible at all. This can improve performance significantly on low-end systems by reducing both the CPU and GPU load (as fewer draw calls are needed to draw the scene without shadows).

### viewport :: RID

### size :: int

### use_16_bits :: bool

## viewport_set_render_direct_to_screen :: func RenderingServer.viewport_set_render_direct_to_screen(viewport: RID, enabled: bool) -> void
If [code]true[/code], render the contents of the viewport directly to screen. This allows a low-level optimization where you can skip drawing a viewport to the root viewport. While this optimization can result in a significant increase in speed (especially on older devices), it comes at a cost of usability. When this is enabled, you cannot read from the viewport or from the screen_texture. You also lose the benefit of certain window settings, such as the various stretch modes. Another consequence to be aware of is that in 2D the rendering happens in window coordinates, so if you have a viewport that is double the size of the window, and you set this, then only the portion that fits within the window will be drawn, no automatic scaling is possible, even if your game scene is significantly larger than the window size.

### viewport :: RID

### enabled :: bool

## viewport_set_scaling_3d_mode :: func RenderingServer.viewport_set_scaling_3d_mode(viewport: RID, scaling_3d_mode: int) -> void
Sets the 3D resolution scaling mode. Bilinear scaling renders at different resolution to either undersample or supersample the viewport. FidelityFX Super Resolution 1.0, abbreviated to FSR, is an upscaling technology that produces high quality images at fast framerates by using a spatially aware upscaling algorithm. FSR is slightly more expensive than bilinear, but it produces significantly higher image quality. FSR should be used where possible.

### viewport :: RID

### scaling_3d_mode :: int

## viewport_set_scaling_3d_scale :: func RenderingServer.viewport_set_scaling_3d_scale(viewport: RID, scale: float) -> void
Scales the 3D render buffer based on the viewport size uses an image filter specified in [enum ViewportScaling3DMode] to scale the output image to the full viewport size. Values lower than [code]1.0[/code] can be used to speed up 3D rendering at the cost of quality (undersampling). Values greater than [code]1.0[/code] are only valid for bilinear mode and can be used to improve 3D rendering quality at a high performance cost (supersampling). See also [enum ViewportMSAA] for multi-sample antialiasing, which is significantly cheaper but only smoothens the edges of polygons.
When using FSR upscaling, AMD recommends exposing the following values as preset options to users "Ultra Quality: 0.77", "Quality: 0.67", "Balanced: 0.59", "Performance: 0.5" instead of exposing the entire scale.

### viewport :: RID

### scale :: float

## viewport_set_scenario :: func RenderingServer.viewport_set_scenario(viewport: RID, scenario: RID) -> void
Sets a viewport's scenario. The scenario contains information about environment information, reflection atlas, etc.

### viewport :: RID

### scenario :: RID

## viewport_set_screen_space_aa :: func RenderingServer.viewport_set_screen_space_aa(viewport: RID, mode: int) -> void
Sets the viewport's screen-space antialiasing mode. Equivalent to [member ProjectSettings.rendering/anti_aliasing/quality/screen_space_aa] or [member Viewport.screen_space_aa].

### viewport :: RID

### mode :: int

## viewport_set_sdf_oversize_and_scale :: func RenderingServer.viewport_set_sdf_oversize_and_scale(viewport: RID, oversize: int, scale: int) -> void
Sets the viewport's 2D signed distance field [member ProjectSettings.rendering/2d/sdf/oversize] and [member ProjectSettings.rendering/2d/sdf/scale]. This is used when sampling the signed distance field in [CanvasItem] shaders as well as [GPUParticles2D] collision. This is [i]not[/i] used by SDFGI in 3D rendering.

### viewport :: RID

### oversize :: int

### scale :: int

## viewport_set_size :: func RenderingServer.viewport_set_size(viewport: RID, width: int, height: int, view_count: int = 1) -> void
Sets the viewport's [param width] and [param height] in pixels. Optionally the [param view_count] can be set to increase the number of view layers for stereo rendering.

### viewport :: RID

### width :: int

### height :: int

### view_count :: int

## viewport_set_snap_2d_transforms_to_pixel :: func RenderingServer.viewport_set_snap_2d_transforms_to_pixel(viewport: RID, enabled: bool) -> void
If [code]true[/code], canvas item transforms (i.e. origin position) are snapped to the nearest pixel when rendering. This can lead to a crisper appearance at the cost of less smooth movement, especially when [Camera2D] smoothing is enabled. Equivalent to [member ProjectSettings.rendering/2d/snap/snap_2d_transforms_to_pixel].

### viewport :: RID

### enabled :: bool

## viewport_set_snap_2d_vertices_to_pixel :: func RenderingServer.viewport_set_snap_2d_vertices_to_pixel(viewport: RID, enabled: bool) -> void
If [code]true[/code], canvas item vertices (i.e. polygon points) are snapped to the nearest pixel when rendering. This can lead to a crisper appearance at the cost of less smooth movement, especially when [Camera2D] smoothing is enabled. Equivalent to [member ProjectSettings.rendering/2d/snap/snap_2d_vertices_to_pixel].

### viewport :: RID

### enabled :: bool

## viewport_set_texture_mipmap_bias :: func RenderingServer.viewport_set_texture_mipmap_bias(viewport: RID, mipmap_bias: float) -> void
Affects the final texture sharpness by reading from a lower or higher mipmap (also called "texture LOD bias"). Negative values make mipmapped textures sharper but grainier when viewed at a distance, while positive values make mipmapped textures blurrier (even when up close). To get sharper textures at a distance without introducing too much graininess, set this between [code]-0.75[/code] and [code]0.0[/code]. Enabling temporal antialiasing ([member ProjectSettings.rendering/anti_aliasing/quality/use_taa]) can help reduce the graininess visible when using negative mipmap bias.
[b]Note:[/b] When the 3D scaling mode is set to FSR 1.0, this value is used to adjust the automatic mipmap bias which is calculated internally based on the scale factor. The formula for this is [code]-log2(1.0 / scale) + mipmap_bias[/code].
[b]Note:[/b] This method is only supported in the Forward+ and Mobile renderers, not Compatibility. In Compatibility, this method is always treated as if [param mipmap_bias] was set to [code]0.0[/code].

### viewport :: RID

### mipmap_bias :: float

## viewport_set_transparent_background :: func RenderingServer.viewport_set_transparent_background(viewport: RID, enabled: bool) -> void
If [code]true[/code], the viewport renders its background as transparent.

### viewport :: RID

### enabled :: bool

## viewport_set_update_mode :: func RenderingServer.viewport_set_update_mode(viewport: RID, update_mode: int) -> void
Sets when the viewport should be updated.

### viewport :: RID

### update_mode :: int

## viewport_set_use_debanding :: func RenderingServer.viewport_set_use_debanding(viewport: RID, enable: bool) -> void
Equivalent to [member Viewport.use_debanding]. See also [member ProjectSettings.rendering/anti_aliasing/quality/use_debanding].

### viewport :: RID

### enable :: bool

## viewport_set_use_hdr_2d :: func RenderingServer.viewport_set_use_hdr_2d(viewport: RID, enabled: bool) -> void
If [code]true[/code], 2D rendering will use a high dynamic range (HDR) [code]RGBA16[/code] format framebuffer. Additionally, 2D rendering will be performed on linear values and will be converted using the appropriate transfer function immediately before blitting to the screen (if the Viewport is attached to the screen).
Practically speaking, this means that the end result of the Viewport will not be clamped to the [code]0-1[/code] range and can be used in 3D rendering without color encoding adjustments. This allows 2D rendering to take advantage of effects requiring high dynamic range (e.g. 2D glow) as well as substantially improves the appearance of effects requiring highly detailed gradients. This setting has the same effect as [member Viewport.use_hdr_2d].

### viewport :: RID

### enabled :: bool

## viewport_set_use_occlusion_culling :: func RenderingServer.viewport_set_use_occlusion_culling(viewport: RID, enable: bool) -> void
If [code]true[/code], enables occlusion culling on the specified viewport. Equivalent to [member ProjectSettings.rendering/occlusion_culling/use_occlusion_culling].

### viewport :: RID

### enable :: bool

## viewport_set_use_taa :: func RenderingServer.viewport_set_use_taa(viewport: RID, enable: bool) -> void
If [code]true[/code], use temporal antialiasing. Equivalent to [member ProjectSettings.rendering/anti_aliasing/quality/use_taa] or [member Viewport.use_taa].

### viewport :: RID

### enable :: bool

## viewport_set_use_xr :: func RenderingServer.viewport_set_use_xr(viewport: RID, use_xr: bool) -> void
If [code]true[/code], the viewport uses augmented or virtual reality technologies. See [XRInterface].

### viewport :: RID

### use_xr :: bool

## viewport_set_vrs_mode :: func RenderingServer.viewport_set_vrs_mode(viewport: RID, mode: int) -> void
Sets the Variable Rate Shading (VRS) mode for the viewport. If the GPU does not support VRS, this property is ignored. Equivalent to [member ProjectSettings.rendering/vrs/mode].

### viewport :: RID

### mode :: int

## viewport_set_vrs_texture :: func RenderingServer.viewport_set_vrs_texture(viewport: RID, texture: RID) -> void
The texture to use when the VRS mode is set to [constant RenderingServer.VIEWPORT_VRS_TEXTURE]. Equivalent to [member ProjectSettings.rendering/vrs/texture].

### viewport :: RID

### texture :: RID

## viewport_set_vrs_update_mode :: func RenderingServer.viewport_set_vrs_update_mode(viewport: RID, mode: int) -> void
Sets the update mode for Variable Rate Shading (VRS) for the viewport. VRS requires the input texture to be converted to the format usable by the VRS method supported by the hardware. The update mode defines how often this happens. If the GPU does not support VRS, or VRS is not enabled, this property is ignored.
If set to [constant RenderingServer.VIEWPORT_VRS_UPDATE_ONCE], the input texture is copied once and the mode is changed to [constant RenderingServer.VIEWPORT_VRS_UPDATE_DISABLED].

### viewport :: RID

### mode :: int

## visibility_notifier_create :: func RenderingServer.visibility_notifier_create() -> RID
Creates a new 3D visibility notifier object and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]visibility_notifier_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
To place in a scene, attach this notifier to an instance using [method instance_set_base] using the returned RID.
[b]Note:[/b] The equivalent node is [VisibleOnScreenNotifier3D].

## visibility_notifier_set_aabb :: func RenderingServer.visibility_notifier_set_aabb(notifier: RID, aabb: AABB) -> void
Sets the AABB of the specified visibility notifier.

### notifier :: RID

### aabb :: AABB

## visibility_notifier_set_callbacks :: func RenderingServer.visibility_notifier_set_callbacks(notifier: RID, enter_callable: Callable, exit_callable: Callable) -> void
Sets the methods to be called when the notifier enters or exits the view.

### notifier :: RID

### enter_callable :: Callable

### exit_callable :: Callable

## voxel_gi_allocate_data :: func RenderingServer.voxel_gi_allocate_data(voxel_gi: RID, to_cell_xform: Transform3D, aabb: AABB, octree_size: Vector3i, octree_cells: PackedByteArray, data_cells: PackedByteArray, distance_field: PackedByteArray, level_counts: PackedInt32Array) -> void
Allocates and initializes the voxel GI data for the specified [param voxel_gi] RID. [param octree_cells] must be a multiple of 32. [param octree_cells] must be double the size of [param data_cells]. The allocated data can be retrieved later using the various [code]voxel_gi_get_*[/code] methods.

### voxel_gi :: RID

### to_cell_xform :: Transform3D

### aabb :: AABB

### octree_size :: Vector3i

### octree_cells :: PackedByteArray

### data_cells :: PackedByteArray

### distance_field :: PackedByteArray

### level_counts :: PackedInt32Array

## voxel_gi_create :: func RenderingServer.voxel_gi_create() -> RID
Creates a new voxel-based global illumination object and adds it to the RenderingServer. It can be accessed with the RID that is returned. This RID will be used in all [code]voxel_gi_*[/code] RenderingServer functions.
Once finished with your RID, you will want to free the RID using the RenderingServer's [method free_rid] method.
[b]Note:[/b] The equivalent node is [VoxelGI].

## voxel_gi_get_data_cells :: func RenderingServer.voxel_gi_get_data_cells(voxel_gi: RID) -> PackedByteArray
Returns the data cells for the specified voxel GI data instance. See also [method voxel_gi_allocate_data].

### voxel_gi :: RID

## voxel_gi_get_distance_field :: func RenderingServer.voxel_gi_get_distance_field(voxel_gi: RID) -> PackedByteArray
Returns the distance field data for the specified voxel GI data instance. See also [method voxel_gi_allocate_data].

### voxel_gi :: RID

## voxel_gi_get_level_counts :: func RenderingServer.voxel_gi_get_level_counts(voxel_gi: RID) -> PackedInt32Array
Returns the level counts for the specified voxel GI data instance. See also [method voxel_gi_allocate_data].

### voxel_gi :: RID

## voxel_gi_get_octree_cells :: func RenderingServer.voxel_gi_get_octree_cells(voxel_gi: RID) -> PackedByteArray
Returns the octree cell data for the specified voxel GI data instance. See also [method voxel_gi_allocate_data].

### voxel_gi :: RID

## voxel_gi_get_octree_size :: func RenderingServer.voxel_gi_get_octree_size(voxel_gi: RID) -> Vector3i
Returns the octree size for the specified voxel GI data instance, which corresponds to the number of subdivisions per axis. This can be viewed in the editor by hovering the [b]Bake VoxelGI[/b] button at the top of the 3D editor viewport when a [VoxelGI] node is selected and looking at the [b]Subdivisions[/b] field in the tooltip.

### voxel_gi :: RID

## voxel_gi_get_to_cell_xform :: func RenderingServer.voxel_gi_get_to_cell_xform(voxel_gi: RID) -> Transform3D
Returns the transform to cell space for the specified voxel GI data instance. See also [method voxel_gi_allocate_data].

### voxel_gi :: RID

## voxel_gi_set_baked_exposure_normalization :: func RenderingServer.voxel_gi_set_baked_exposure_normalization(voxel_gi: RID, baked_exposure: float) -> void
Used to inform the renderer what exposure normalization value was used while baking the voxel gi. This value will be used and modulated at run time to ensure that the voxel gi maintains a consistent level of exposure even if the scene-wide exposure normalization is changed at run time. For more information see [method camera_attributes_set_exposure].

### voxel_gi :: RID

### baked_exposure :: float

## voxel_gi_set_bias :: func RenderingServer.voxel_gi_set_bias(voxel_gi: RID, bias: float) -> void
Sets the [member VoxelGIData.bias] value to use on the specified [param voxel_gi]'s [RID].

### voxel_gi :: RID

### bias :: float

## voxel_gi_set_dynamic_range :: func RenderingServer.voxel_gi_set_dynamic_range(voxel_gi: RID, range: float) -> void
Sets the [member VoxelGIData.dynamic_range] value to use on the specified [param voxel_gi]'s [RID].

### voxel_gi :: RID

### range :: float

## voxel_gi_set_energy :: func RenderingServer.voxel_gi_set_energy(voxel_gi: RID, energy: float) -> void
Sets the [member VoxelGIData.energy] value to use on the specified [param voxel_gi]'s [RID].

### voxel_gi :: RID

### energy :: float

## voxel_gi_set_interior :: func RenderingServer.voxel_gi_set_interior(voxel_gi: RID, enable: bool) -> void
Sets the [member VoxelGIData.interior] value to use on the specified [param voxel_gi]'s [RID].

### voxel_gi :: RID

### enable :: bool

## voxel_gi_set_normal_bias :: func RenderingServer.voxel_gi_set_normal_bias(voxel_gi: RID, bias: float) -> void
Sets the [member VoxelGIData.normal_bias] value to use on the specified [param voxel_gi]'s [RID].

### voxel_gi :: RID

### bias :: float

## voxel_gi_set_propagation :: func RenderingServer.voxel_gi_set_propagation(voxel_gi: RID, amount: float) -> void
Sets the [member VoxelGIData.propagation] value to use on the specified [param voxel_gi]'s [RID].

### voxel_gi :: RID

### amount :: float

## voxel_gi_set_quality :: func RenderingServer.voxel_gi_set_quality(quality: int) -> void
Sets the [member ProjectSettings.rendering/global_illumination/voxel_gi/quality] value to use when rendering. This parameter is global and cannot be set on a per-VoxelGI basis.

### quality :: int

## voxel_gi_set_use_two_bounces :: func RenderingServer.voxel_gi_set_use_two_bounces(voxel_gi: RID, enable: bool) -> void
Sets the [member VoxelGIData.use_two_bounces] value to use on the specified [param voxel_gi]'s [RID].

### voxel_gi :: RID

### enable :: bool

## frame_post_draw :: func RenderingServer.frame_post_draw() -> void
Emitted at the end of the frame, after the RenderingServer has finished updating all the Viewports.

## frame_pre_draw :: func RenderingServer.frame_pre_draw() -> void
Emitted at the beginning of the frame, before the RenderingServer updates all the Viewports.
