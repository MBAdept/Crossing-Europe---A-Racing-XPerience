# VisualShaderNodeUIntParameter :: <Native> class VisualShaderNodeUIntParameter extends VisualShaderNodeParameter
A visual shader node for shader parameter (uniform) of type unsigned [int].
A [VisualShaderNodeParameter] of type unsigned [int]. Offers additional customization for range of accepted values.

## default_value :: var VisualShaderNodeUIntParameter.default_value: int
Default value of this parameter, which will be used if not set externally. [member default_value_enabled] must be enabled; defaults to [code]0[/code] otherwise.

## default_value_enabled :: var VisualShaderNodeUIntParameter.default_value_enabled: bool
If [code]true[/code], the node will have a custom default value.
