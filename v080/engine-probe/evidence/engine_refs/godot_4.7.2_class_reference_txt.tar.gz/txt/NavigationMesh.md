# NavigationMesh :: <Native> class NavigationMesh extends Resource
A navigation mesh that defines traversable areas and obstacles.
A navigation mesh is a collection of polygons that define which areas of an environment are traversable to aid agents in pathfinding through complicated spaces.

## SAMPLE_PARTITION_WATERSHED :: const NavigationMesh.SAMPLE_PARTITION_WATERSHED: SamplePartitionType = 0
Watershed partitioning. Generally the best choice if you precompute the navigation mesh, use this if you have large open areas.

## SAMPLE_PARTITION_MONOTONE :: const NavigationMesh.SAMPLE_PARTITION_MONOTONE: SamplePartitionType = 1
Monotone partitioning. Use this if you want fast navigation mesh generation.

## SAMPLE_PARTITION_LAYERS :: const NavigationMesh.SAMPLE_PARTITION_LAYERS: SamplePartitionType = 2
Layer partitioning. Good choice to use for tiled navigation mesh with medium and small sized tiles.

## SAMPLE_PARTITION_MAX :: const NavigationMesh.SAMPLE_PARTITION_MAX: SamplePartitionType = 3
Represents the size of the [enum SamplePartitionType] enum.

## PARSED_GEOMETRY_MESH_INSTANCES :: const NavigationMesh.PARSED_GEOMETRY_MESH_INSTANCES: ParsedGeometryType = 0
Parses mesh instances as geometry. This includes [MeshInstance3D], [CSGShape3D], and [GridMap] nodes.

## PARSED_GEOMETRY_STATIC_COLLIDERS :: const NavigationMesh.PARSED_GEOMETRY_STATIC_COLLIDERS: ParsedGeometryType = 1
Parses [StaticBody3D] colliders as geometry. The collider should be in any of the layers specified by [member geometry_collision_mask].

## PARSED_GEOMETRY_BOTH :: const NavigationMesh.PARSED_GEOMETRY_BOTH: ParsedGeometryType = 2
Both [constant PARSED_GEOMETRY_MESH_INSTANCES] and [constant PARSED_GEOMETRY_STATIC_COLLIDERS].

## PARSED_GEOMETRY_MAX :: const NavigationMesh.PARSED_GEOMETRY_MAX: ParsedGeometryType = 3
Represents the size of the [enum ParsedGeometryType] enum.

## SOURCE_GEOMETRY_ROOT_NODE_CHILDREN :: const NavigationMesh.SOURCE_GEOMETRY_ROOT_NODE_CHILDREN: SourceGeometryMode = 0
Scans the child nodes of the root node recursively for geometry.

## SOURCE_GEOMETRY_GROUPS_WITH_CHILDREN :: const NavigationMesh.SOURCE_GEOMETRY_GROUPS_WITH_CHILDREN: SourceGeometryMode = 1
Scans nodes in a group and their child nodes recursively for geometry. The group is specified by [member geometry_source_group_name].

## SOURCE_GEOMETRY_GROUPS_EXPLICIT :: const NavigationMesh.SOURCE_GEOMETRY_GROUPS_EXPLICIT: SourceGeometryMode = 2
Uses nodes in a group for geometry. The group is specified by [member geometry_source_group_name].

## SOURCE_GEOMETRY_MAX :: const NavigationMesh.SOURCE_GEOMETRY_MAX: SourceGeometryMode = 3
Represents the size of the [enum SourceGeometryMode] enum.

## agent_height :: var NavigationMesh.agent_height: float
The minimum floor to ceiling height that will still allow the floor area to be considered walkable.
[b]Note:[/b] While baking, this value will be rounded up to the nearest multiple of [member cell_height].

## agent_max_climb :: var NavigationMesh.agent_max_climb: float
The minimum ledge height that is considered to still be traversable.
[b]Note:[/b] While baking, this value will be rounded down to the nearest multiple of [member cell_height].

## agent_max_slope :: var NavigationMesh.agent_max_slope: float
The maximum slope that is considered walkable, in degrees.

## agent_radius :: var NavigationMesh.agent_radius: float
The distance to erode/shrink the walkable area of the heightfield away from obstructions.
[b]Note:[/b] While baking, this value will be rounded up to the nearest multiple of [member cell_size].
[b]Note:[/b] The radius must be equal or higher than [code]0.0[/code]. If the radius is [code]0.0[/code], it won't be possible to fix invalid outline overlaps and other precision errors during the baking process. As a result, some obstacles may be excluded incorrectly from the final navigation mesh, or may delete the navigation mesh's polygons.

## border_size :: var NavigationMesh.border_size: float
The size of the non-navigable border around the bake bounding area.
In conjunction with the [member filter_baking_aabb] and a [member edge_max_error] value at [code]1.0[/code] or below the border size can be used to bake tile aligned navigation meshes without the tile edges being shrunk by [member agent_radius].
[b]Note:[/b] If this value is not [code]0.0[/code], it will be rounded up to the nearest multiple of [member cell_size] during baking.

## cell_height :: var NavigationMesh.cell_height: float
The cell height used to rasterize the navigation mesh vertices on the Y axis. Must match with the cell height on the navigation map.

## cell_size :: var NavigationMesh.cell_size: float
The cell size used to rasterize the navigation mesh vertices on the XZ plane. Must match with the cell size on the navigation map.

## detail_sample_distance :: var NavigationMesh.detail_sample_distance: float
The sampling distance to use when generating the detail mesh, in cell unit.

## detail_sample_max_error :: var NavigationMesh.detail_sample_max_error: float
The maximum distance the detail mesh surface should deviate from heightfield, in cell unit.

## edge_max_error :: var NavigationMesh.edge_max_error: float
The maximum distance a simplified contour's border edges should deviate the original raw contour.

## edge_max_length :: var NavigationMesh.edge_max_length: float
The maximum allowed length for contour edges along the border of the mesh. A value of [code]0.0[/code] disables this feature.
[b]Note:[/b] While baking, this value will be rounded up to the nearest multiple of [member cell_size].

## filter_baking_aabb :: var NavigationMesh.filter_baking_aabb: AABB
If the baking [AABB] has a volume the navigation mesh baking will be restricted to its enclosing area.

## filter_baking_aabb_offset :: var NavigationMesh.filter_baking_aabb_offset: Vector3
The position offset applied to the [member filter_baking_aabb] [AABB].

## filter_ledge_spans :: var NavigationMesh.filter_ledge_spans: bool
If [code]true[/code], marks spans that are ledges as non-walkable.

## filter_low_hanging_obstacles :: var NavigationMesh.filter_low_hanging_obstacles: bool
If [code]true[/code], marks non-walkable spans as walkable if their maximum is within [member agent_max_climb] of a walkable neighbor.

## filter_walkable_low_height_spans :: var NavigationMesh.filter_walkable_low_height_spans: bool
If [code]true[/code], marks walkable spans as not walkable if the clearance above the span is less than [member agent_height].

## geometry_collision_mask :: var NavigationMesh.geometry_collision_mask: int
The physics layers to scan for static colliders.
Only used when [member geometry_parsed_geometry_type] is [constant PARSED_GEOMETRY_STATIC_COLLIDERS] or [constant PARSED_GEOMETRY_BOTH].

## geometry_parsed_geometry_type :: var NavigationMesh.geometry_parsed_geometry_type: NavigationMesh.ParsedGeometryType
Determines which type of nodes will be parsed as geometry.

## geometry_source_geometry_mode :: var NavigationMesh.geometry_source_geometry_mode: NavigationMesh.SourceGeometryMode
The source of the geometry used when baking.

## geometry_source_group_name :: var NavigationMesh.geometry_source_group_name: StringName
The name of the group to scan for geometry.
Only used when [member geometry_source_geometry_mode] is [constant SOURCE_GEOMETRY_GROUPS_WITH_CHILDREN] or [constant SOURCE_GEOMETRY_GROUPS_EXPLICIT].

## region_merge_size :: var NavigationMesh.region_merge_size: float
Any regions with a size smaller than this will be merged with larger regions if possible.
[b]Note:[/b] This value will be squared to calculate the number of cells. For example, a value of 20 will set the number of cells to 400.

## region_min_size :: var NavigationMesh.region_min_size: float
The minimum size of a region for it to be created.
[b]Note:[/b] This value will be squared to calculate the minimum number of cells allowed to form isolated island areas. For example, a value of 8 will set the number of cells to 64.

## sample_partition_type :: var NavigationMesh.sample_partition_type: NavigationMesh.SamplePartitionType
Partitioning algorithm for creating the navigation mesh polys.

## vertices_per_polygon :: var NavigationMesh.vertices_per_polygon: float
The maximum number of vertices allowed for polygons generated during the contour to polygon conversion process.

## add_polygon :: func NavigationMesh.add_polygon(polygon: PackedInt32Array) -> void
Adds a polygon using the indices of the vertices you get when calling [method get_vertices].

### polygon :: PackedInt32Array

## clear :: func NavigationMesh.clear() -> void
Clears the internal arrays for vertices and polygon indices.

## clear_polygons :: func NavigationMesh.clear_polygons() -> void
Clears the array of polygons, but it doesn't clear the array of vertices.

## create_from_mesh :: func NavigationMesh.create_from_mesh(mesh: Mesh) -> void
Initializes the navigation mesh by setting the vertices and indices according to a [Mesh].
[b]Note:[/b] The given [param mesh] must be of type [constant Mesh.PRIMITIVE_TRIANGLES] and have an index array.

### mesh :: Mesh

## get_collision_mask_value :: func NavigationMesh.get_collision_mask_value(layer_number: int) -> bool
Returns whether or not the specified layer of the [member geometry_collision_mask] is enabled, given a [param layer_number] between 1 and 32.

### layer_number :: int

## get_polygon :: func NavigationMesh.get_polygon(idx: int) -> PackedInt32Array
Returns a [PackedInt32Array] containing the indices of the vertices of a created polygon.

### idx :: int

## get_polygon_count :: func NavigationMesh.get_polygon_count() -> int
Returns the number of polygons in the navigation mesh.

## get_vertices :: func NavigationMesh.get_vertices() -> PackedVector3Array
Returns a [PackedVector3Array] containing all the vertices being used to create the polygons.

## set_collision_mask_value :: func NavigationMesh.set_collision_mask_value(layer_number: int, value: bool) -> void
Based on [param value], enables or disables the specified layer in the [member geometry_collision_mask], given a [param layer_number] between 1 and 32.

### layer_number :: int

### value :: bool

## set_vertices :: func NavigationMesh.set_vertices(vertices: PackedVector3Array) -> void
Sets the vertices that can be then indexed to create polygons with the [method add_polygon] method.

### vertices :: PackedVector3Array
