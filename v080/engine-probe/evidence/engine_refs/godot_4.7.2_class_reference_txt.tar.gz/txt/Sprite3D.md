# Sprite3D :: <Native> class Sprite3D extends SpriteBase3D
2D sprite node in a 3D world.
A node that displays a 2D texture in a 3D environment. The texture displayed can be a region from a larger atlas texture, or a frame from a sprite sheet animation. See also [SpriteBase3D] where properties such as the billboard mode are defined.

## frame :: var Sprite3D.frame: int
Current frame to display from sprite sheet. [member hframes] or [member vframes] must be greater than 1. This property is automatically adjusted when [member hframes] or [member vframes] are changed to keep pointing to the same visual frame (same column and row). If that's impossible, this value is reset to [code]0[/code].

## frame_coords :: var Sprite3D.frame_coords: Vector2i
Coordinates of the frame to display from sprite sheet. This is as an alias for the [member frame] property. [member hframes] or [member vframes] must be greater than 1.

## hframes :: var Sprite3D.hframes: int
The number of columns in the sprite sheet. When this property is changed, [member frame] is adjusted so that the same visual frame is maintained (same row and column). If that's impossible, [member frame] is reset to [code]0[/code].

## region_enabled :: var Sprite3D.region_enabled: bool
If [code]true[/code], the sprite will use [member region_rect] and display only the specified part of its texture.

## region_rect :: var Sprite3D.region_rect: Rect2
The region of the atlas texture to display. [member region_enabled] must be [code]true[/code].

## texture :: var Sprite3D.texture: Texture2D
[Texture2D] object to draw. If [member GeometryInstance3D.material_override] is used, this will be overridden. The size information is still used.

## vframes :: var Sprite3D.vframes: int
The number of rows in the sprite sheet. When this property is changed, [member frame] is adjusted so that the same visual frame is maintained (same row and column). If that's impossible, [member frame] is reset to [code]0[/code].

## frame_changed :: func Sprite3D.frame_changed() -> void
Emitted when the [member frame] changes.

## texture_changed :: func Sprite3D.texture_changed() -> void
Emitted when the [member texture] changes.
