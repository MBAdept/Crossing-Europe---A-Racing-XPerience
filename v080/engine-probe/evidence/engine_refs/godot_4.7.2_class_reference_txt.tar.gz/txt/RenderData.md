# RenderData :: <Native> class RenderData extends Object
Abstract render data object, holds frame data related to rendering a single frame of a viewport.
Abstract render data object, exists for the duration of rendering a single viewport. See also [RenderDataRD], [RenderSceneData], and [RenderSceneDataRD].
[b]Note:[/b] This is an internal rendering server object. Do not instantiate this class from a script.

## get_camera_attributes :: func RenderData.get_camera_attributes() -> RID
Returns the [RID] of the camera attributes object in the [RenderingServer] being used to render this viewport.

## get_environment :: func RenderData.get_environment() -> RID
Returns the [RID] of the environment object in the [RenderingServer] being used to render this viewport.

## get_render_scene_buffers :: func RenderData.get_render_scene_buffers() -> RenderSceneBuffers
Returns the [RenderSceneBuffers] object managing the scene buffers for rendering this viewport.

## get_render_scene_data :: func RenderData.get_render_scene_data() -> RenderSceneData
Returns the [RenderSceneData] object managing this frames scene data.
