# EditorExportPlatformWindows :: <Native> class EditorExportPlatformWindows extends EditorExportPlatformPC
Exporter for Windows.
The Windows exporter customizes how a Windows build is handled. In the editor's "Export" window, it is created when adding a new "Windows" preset.

## application/company_name :: var EditorExportPlatformWindows.application/company_name: String
Company that produced the application. Required. See [url=https://learn.microsoft.com/en-us/windows/win32/menurc/stringfileinfo-block]StringFileInfo[/url].

## application/console_wrapper_icon :: var EditorExportPlatformWindows.application/console_wrapper_icon: String
Console wrapper icon file. If left empty, it will fallback to [member application/icon], then to [member ProjectSettings.application/config/windows_native_icon], and lastly, [member ProjectSettings.application/config/icon].

## application/copyright :: var EditorExportPlatformWindows.application/copyright: String
Copyright notice for the bundle visible to the user. Optional. See [url=https://learn.microsoft.com/en-us/windows/win32/menurc/stringfileinfo-block]StringFileInfo[/url].

## application/d3d12_agility_sdk_multiarch :: var EditorExportPlatformWindows.application/d3d12_agility_sdk_multiarch: bool
If [code]true[/code], and [member application/export_d3d12] is set, the Agility SDK DLLs will be stored in arch-specific subdirectories.

## application/export_angle :: var EditorExportPlatformWindows.application/export_angle: int
If set to [code]1[/code], ANGLE libraries are exported with the exported application. If set to [code]0[/code], ANGLE libraries are exported only if [member ProjectSettings.rendering/gl_compatibility/driver] is set to [code]"opengl3_angle"[/code].

## application/export_d3d12 :: var EditorExportPlatformWindows.application/export_d3d12: int
If set to [code]1[/code], the Direct3D 12 runtime libraries (Agility SDK, PIX) are exported with the exported application. If set to [code]0[/code], Direct3D 12 libraries are exported only if [member ProjectSettings.rendering/rendering_device/driver] is set to [code]"d3d12"[/code].

## application/file_description :: var EditorExportPlatformWindows.application/file_description: String
File description to be presented to users. Required. See [url=https://learn.microsoft.com/en-us/windows/win32/menurc/stringfileinfo-block]StringFileInfo[/url].

## application/file_version :: var EditorExportPlatformWindows.application/file_version: String
Version number of the file. Falls back to [member ProjectSettings.application/config/version] if left empty. See [url=https://learn.microsoft.com/en-us/windows/win32/menurc/stringfileinfo-block]StringFileInfo[/url].

## application/icon :: var EditorExportPlatformWindows.application/icon: String
Application icon file. If left empty, it will fallback to [member ProjectSettings.application/config/windows_native_icon], and then to [member ProjectSettings.application/config/icon].

## application/icon_interpolation :: var EditorExportPlatformWindows.application/icon_interpolation: int
Interpolation method used to resize application icon.

## application/modify_resources :: var EditorExportPlatformWindows.application/modify_resources: bool
If enabled, icon and metadata of the exported executable is set according to the other [code]application/*[/code] values.

## application/product_name :: var EditorExportPlatformWindows.application/product_name: String
Name of the application. Required. See [url=https://learn.microsoft.com/en-us/windows/win32/menurc/stringfileinfo-block]StringFileInfo[/url].

## application/product_version :: var EditorExportPlatformWindows.application/product_version: String
Application version visible to the user. Falls back to [member ProjectSettings.application/config/version] if left empty. See [url=https://learn.microsoft.com/en-us/windows/win32/menurc/stringfileinfo-block]StringFileInfo[/url].

## application/trademarks :: var EditorExportPlatformWindows.application/trademarks: String
Trademarks and registered trademarks that apply to the file. Optional. See [url=https://learn.microsoft.com/en-us/windows/win32/menurc/stringfileinfo-block]StringFileInfo[/url].

## binary_format/architecture :: var EditorExportPlatformWindows.binary_format/architecture: String
Application executable architecture.
Supported architectures: [code]x86_32[/code], [code]x86_64[/code], and [code]arm64[/code].

## binary_format/embed_pck :: var EditorExportPlatformWindows.binary_format/embed_pck: bool
If [code]true[/code], project resources are embedded into the executable.

## codesign/custom_options :: var EditorExportPlatformWindows.codesign/custom_options: PackedStringArray
Array of the additional command line arguments passed to the code signing tool. See [url=https://learn.microsoft.com/en-us/dotnet/framework/tools/signtool-exe]Sign Tool[/url].

## codesign/description :: var EditorExportPlatformWindows.codesign/description: String
Description of the signed content. See [url=https://learn.microsoft.com/en-us/dotnet/framework/tools/signtool-exe]Sign Tool[/url].

## codesign/digest_algorithm :: var EditorExportPlatformWindows.codesign/digest_algorithm: int
Digest algorithm to use for creating signature. See [url=https://learn.microsoft.com/en-us/dotnet/framework/tools/signtool-exe]Sign Tool[/url].

## codesign/enable :: var EditorExportPlatformWindows.codesign/enable: bool
If [code]true[/code], executable signing is enabled.

## codesign/identity :: var EditorExportPlatformWindows.codesign/identity: String
PKCS #12 certificate file used to sign executable or certificate SHA-1 hash (if [member codesign/identity_type] is set to "Use certificate store"). See [url=https://learn.microsoft.com/en-us/dotnet/framework/tools/signtool-exe]Sign Tool[/url].
Can be overridden with the environment variable [code]GODOT_WINDOWS_CODESIGN_IDENTITY[/code].

## codesign/identity_type :: var EditorExportPlatformWindows.codesign/identity_type: int
Type of identity to use. See [url=https://learn.microsoft.com/en-us/dotnet/framework/tools/signtool-exe]Sign Tool[/url].
Can be overridden with the environment variable [code]GODOT_WINDOWS_CODESIGN_IDENTITY_TYPE[/code].

## codesign/password :: var EditorExportPlatformWindows.codesign/password: String
Password for the certificate file used to sign executable. See [url=https://learn.microsoft.com/en-us/dotnet/framework/tools/signtool-exe]Sign Tool[/url].
Can be overridden with the environment variable [code]GODOT_WINDOWS_CODESIGN_PASSWORD[/code].

## codesign/timestamp :: var EditorExportPlatformWindows.codesign/timestamp: bool
If [code]true[/code], time-stamp is added to the signature. See [url=https://learn.microsoft.com/en-us/dotnet/framework/tools/signtool-exe]Sign Tool[/url].

## codesign/timestamp_server_url :: var EditorExportPlatformWindows.codesign/timestamp_server_url: String
URL of the time stamp server. If left empty, the default server is used. See [url=https://learn.microsoft.com/en-us/dotnet/framework/tools/signtool-exe]Sign Tool[/url].

## custom_template/debug :: var EditorExportPlatformWindows.custom_template/debug: String
Path to the custom export template. If left empty, default template is used.

## custom_template/release :: var EditorExportPlatformWindows.custom_template/release: String
Path to the custom export template. If left empty, default template is used.

## debug/export_console_wrapper :: var EditorExportPlatformWindows.debug/export_console_wrapper: int
If [code]true[/code], a console wrapper executable is exported alongside the main executable, which allows running the project with enabled console output.

## shader_baker/enabled :: var EditorExportPlatformWindows.shader_baker/enabled: bool
If [code]true[/code], shaders will be compiled and embedded in the application. This option is only supported when using the Forward+ and Mobile renderers.
[b]Note:[/b] When exporting as a dedicated server, the shader baker is always disabled since no rendering is performed.

## ssh_remote_deploy/cleanup_script :: var EditorExportPlatformWindows.ssh_remote_deploy/cleanup_script: String
Script code to execute on the remote host when app is finished.
The following variables can be used in the script:
- [code]{temp_dir}[/code] - Path of temporary folder on the remote, used to upload app and scripts to.
- [code]{archive_name}[/code] - Name of the ZIP containing uploaded application.
- [code]{exe_name}[/code] - Name of application executable.
- [code]{cmd_args}[/code] - Array of the command line argument for the application.

## ssh_remote_deploy/enabled :: var EditorExportPlatformWindows.ssh_remote_deploy/enabled: bool
Enables remote deploy using SSH/SCP.

## ssh_remote_deploy/extra_args_scp :: var EditorExportPlatformWindows.ssh_remote_deploy/extra_args_scp: String
Array of the additional command line arguments passed to the SCP.

## ssh_remote_deploy/extra_args_ssh :: var EditorExportPlatformWindows.ssh_remote_deploy/extra_args_ssh: String
Array of the additional command line arguments passed to the SSH.

## ssh_remote_deploy/host :: var EditorExportPlatformWindows.ssh_remote_deploy/host: String
Remote host SSH user name and address, in [code]user@address[/code] format.

## ssh_remote_deploy/port :: var EditorExportPlatformWindows.ssh_remote_deploy/port: String
Remote host SSH port number.

## ssh_remote_deploy/run_script :: var EditorExportPlatformWindows.ssh_remote_deploy/run_script: String
Script code to execute on the remote host when running the app.
The following variables can be used in the script:
- [code]{temp_dir}[/code] - Path of temporary folder on the remote, used to upload app and scripts to.
- [code]{archive_name}[/code] - Name of the ZIP containing uploaded application.
- [code]{exe_name}[/code] - Name of application executable.
- [code]{cmd_args}[/code] - Array of the command line argument for the application.

## texture_format/etc2_astc :: var EditorExportPlatformWindows.texture_format/etc2_astc: bool
If [code]true[/code], project textures are exported in the ETC2/ASTC format.

## texture_format/s3tc_bptc :: var EditorExportPlatformWindows.texture_format/s3tc_bptc: bool
If [code]true[/code], project textures are exported in the S3TC/BPTC format.
