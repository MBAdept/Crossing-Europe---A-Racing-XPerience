# AnimationPlayer :: <Native> class AnimationPlayer extends AnimationMixer
A node used for animation playback.
An animation player is used for general-purpose playback of animations. It contains a dictionary of [AnimationLibrary] resources and custom blend times between animation transitions.
Some methods and properties use a single key to reference an animation directly. These keys are formatted as the key for the library, followed by a forward slash, then the key for the animation within the library, for example [code]"movement/run"[/code]. If the library's key is an empty string (known as the default library), the forward slash is omitted, being the same key used by the library.
[AnimationPlayer] is better-suited than [Tween] for more complex animations, for example ones with non-trivial timings. It can also be used over [Tween] if the animation track editor is more convenient than doing it in code.
Updating the target properties of animations occurs at the process frame.

## ANIMATION_PROCESS_PHYSICS :: const AnimationPlayer.ANIMATION_PROCESS_PHYSICS: AnimationProcessCallback = 0

## ANIMATION_PROCESS_IDLE :: const AnimationPlayer.ANIMATION_PROCESS_IDLE: AnimationProcessCallback = 1

## ANIMATION_PROCESS_MANUAL :: const AnimationPlayer.ANIMATION_PROCESS_MANUAL: AnimationProcessCallback = 2

## ANIMATION_METHOD_CALL_DEFERRED :: const AnimationPlayer.ANIMATION_METHOD_CALL_DEFERRED: AnimationMethodCallMode = 0

## ANIMATION_METHOD_CALL_IMMEDIATE :: const AnimationPlayer.ANIMATION_METHOD_CALL_IMMEDIATE: AnimationMethodCallMode = 1

## assigned_animation :: var AnimationPlayer.assigned_animation: StringName
If playing, the current animation's key, otherwise, the animation last played. When set, this changes the animation, but will not play it unless already playing. See also [member current_animation].

## autoplay :: var AnimationPlayer.autoplay: StringName
The key of the animation to play when the scene loads.

## current_animation :: var AnimationPlayer.current_animation: StringName
The key of the currently playing animation. If no animation is playing, the property's value is an empty string. Changing this value does not restart the animation. See [method play] for more information on playing animations.
[b]Note:[/b] While this property appears in the Inspector, it's not meant to be edited, and it's not saved in the scene. This property is mainly used to get the currently playing animation, and internally for animation playback tracks. For more information, see [Animation].

## current_animation_length :: var AnimationPlayer.current_animation_length: float
The length (in seconds) of the currently playing animation.

## current_animation_position :: var AnimationPlayer.current_animation_position: float
The position (in seconds) of the currently playing animation.

## movie_quit_on_finish :: var AnimationPlayer.movie_quit_on_finish: bool
If [code]true[/code] and the engine is running in Movie Maker mode (see [MovieWriter]), exits the engine with [method SceneTree.quit] as soon as an animation is done playing in this [AnimationPlayer]. A message is printed when the engine quits for this reason.
[b]Note:[/b] This obeys the same logic as the [signal AnimationMixer.animation_finished] signal, so it will not quit the engine if the animation is set to be looping.

## playback_auto_capture :: var AnimationPlayer.playback_auto_capture: bool
If [code]true[/code], performs [method AnimationMixer.capture] before playback automatically. This means just [method play_with_capture] is executed with default arguments instead of [method play].
[b]Note:[/b] Capture interpolation is only performed if the animation contains a capture track. See also [constant Animation.UPDATE_CAPTURE].

## playback_auto_capture_duration :: var AnimationPlayer.playback_auto_capture_duration: float
See also [method play_with_capture] and [method AnimationMixer.capture].
If [member playback_auto_capture_duration] is negative value, the duration is set to the interval between the current position and the first key.

## playback_auto_capture_ease_type :: var AnimationPlayer.playback_auto_capture_ease_type: Tween.EaseType
The ease type of the capture interpolation. See also [enum Tween.EaseType].

## playback_auto_capture_transition_type :: var AnimationPlayer.playback_auto_capture_transition_type: Tween.TransitionType
The transition type of the capture interpolation. See also [enum Tween.TransitionType].

## playback_default_blend_time :: var AnimationPlayer.playback_default_blend_time: float
The default time in which to blend animations. Ranges from 0 to 4096 with 0.01 precision.

## speed_scale :: var AnimationPlayer.speed_scale: float
The speed scaling ratio. For example, if this value is [code]1[/code], then the animation plays at normal speed. If it's [code]0.5[/code], then it plays at half speed. If it's [code]2[/code], then it plays at double speed.
If set to a negative value, the animation is played in reverse. If set to [code]0[/code], the animation will not advance.

## animation_get_next :: func AnimationPlayer.animation_get_next(animation_from: StringName) -> StringName
Returns the key of the animation which is queued to play after the [param animation_from] animation.

### animation_from :: StringName

## animation_set_next :: func AnimationPlayer.animation_set_next(animation_from: StringName, animation_to: StringName) -> void
Triggers the [param animation_to] animation when the [param animation_from] animation completes.

### animation_from :: StringName

### animation_to :: StringName

## clear_queue :: func AnimationPlayer.clear_queue() -> void
Clears all queued, unplayed animations.

## get_blend_time :: func AnimationPlayer.get_blend_time(animation_from: StringName, animation_to: StringName) -> float
Returns the blend time (in seconds) between two animations, referenced by their keys.

### animation_from :: StringName

### animation_to :: StringName

## get_method_call_mode :: func AnimationPlayer.get_method_call_mode() -> int
Returns the call mode used for "Call Method" tracks.

## get_playing_speed :: func AnimationPlayer.get_playing_speed() -> float
Returns the actual playing speed of current animation or [code]0[/code] if not playing. This speed is the [member speed_scale] property multiplied by [code]custom_speed[/code] argument specified when calling the [method play] method.
Returns a negative value if the current animation is playing backwards.

## get_process_callback :: func AnimationPlayer.get_process_callback() -> int
Returns the process notification in which to update animations.

## get_queue :: func AnimationPlayer.get_queue() -> StringName[]
Returns a list of the animation keys that are currently queued to play.

## get_root :: func AnimationPlayer.get_root() -> NodePath
Returns the node which node path references will travel from.

## get_section_end_time :: func AnimationPlayer.get_section_end_time() -> float
Returns the end time of the section currently being played.

## get_section_start_time :: func AnimationPlayer.get_section_start_time() -> float
Returns the start time of the section currently being played.

## has_section :: func AnimationPlayer.has_section() -> bool
Returns [code]true[/code] if an animation is currently playing with a section.

## is_animation_active :: func AnimationPlayer.is_animation_active() -> bool
Returns [code]true[/code] if the an animation is currently active. An animation is active if it was played by calling [method play] and was not finished yet, or was stopped by calling [method stop].
This can be used to check whether an animation is currently paused or stopped.
[codeblock]
var is_paused = not is_playing() and is_animation_active()
var is_stopped = not is_playing() and not is_animation_active()
[/codeblock]

## is_playing :: func AnimationPlayer.is_playing() -> bool
Returns [code]true[/code] if an animation is currently playing (even if [member speed_scale] and/or [code]custom_speed[/code] are [code]0[/code]).

## pause :: func AnimationPlayer.pause() -> void
Pauses the currently playing animation. The [member current_animation_position] will be kept and calling [method play] or [method play_backwards] without arguments or with the same animation name as [member assigned_animation] will resume the animation.
See also [method stop].

## play :: func AnimationPlayer.play(name: StringName = &"", custom_blend: float = -1, custom_speed: float = 1.0, from_end: bool = false) -> void
Plays the animation with key [param name]. Custom blend times and speed can be set.
The [param from_end] option only affects when switching to a new animation track, or if the same track but at the start or end. It does not affect resuming playback that was paused in the middle of an animation. If [param custom_speed] is negative and [param from_end] is [code]true[/code], the animation will play backwards (which is equivalent to calling [method play_backwards]).
The [AnimationPlayer] keeps track of its current or last played animation with [member assigned_animation]. If this method is called with that same animation [param name], or with no [param name] parameter, the assigned animation will resume playing if it was paused.
[b]Note:[/b] The animation will be updated the next time the [AnimationPlayer] is processed. If other variables are updated at the same time this is called, they may be updated too early. To perform the update immediately, call [code]advance(0)[/code].

### name :: StringName

### custom_blend :: float

### custom_speed :: float

### from_end :: bool

## play_backwards :: func AnimationPlayer.play_backwards(name: StringName = &"", custom_blend: float = -1) -> void
Plays the animation with key [param name] in reverse.
This method is a shorthand for [method play] with [code]custom_speed = -1.0[/code] and [code]from_end = true[/code], so see its description for more information.

### name :: StringName

### custom_blend :: float

## play_section :: func AnimationPlayer.play_section(name: StringName = &"", start_time: float = -1, end_time: float = -1, custom_blend: float = -1, custom_speed: float = 1.0, from_end: bool = false) -> void
Plays the animation with key [param name] and the section starting from [param start_time] and ending on [param end_time]. See also [method play].
Setting [param start_time] to a value outside the range of the animation means the start of the animation will be used instead, and setting [param end_time] to a value outside the range of the animation means the end of the animation will be used instead. [param start_time] cannot be equal to [param end_time].

### name :: StringName

### start_time :: float

### end_time :: float

### custom_blend :: float

### custom_speed :: float

### from_end :: bool

## play_section_backwards :: func AnimationPlayer.play_section_backwards(name: StringName = &"", start_time: float = -1, end_time: float = -1, custom_blend: float = -1) -> void
Plays the animation with key [param name] and the section starting from [param start_time] and ending on [param end_time] in reverse.
This method is a shorthand for [method play_section] with [code]custom_speed = -1.0[/code] and [code]from_end = true[/code], see its description for more information.

### name :: StringName

### start_time :: float

### end_time :: float

### custom_blend :: float

## play_section_with_markers :: func AnimationPlayer.play_section_with_markers(name: StringName = &"", start_marker: StringName = &"", end_marker: StringName = &"", custom_blend: float = -1, custom_speed: float = 1.0, from_end: bool = false) -> void
Plays the animation with key [param name] and the section starting from [param start_marker] and ending on [param end_marker].
If the start marker is empty, the section starts from the beginning of the animation. If the end marker is empty, the section ends on the end of the animation. See also [method play].

### name :: StringName

### start_marker :: StringName

### end_marker :: StringName

### custom_blend :: float

### custom_speed :: float

### from_end :: bool

## play_section_with_markers_backwards :: func AnimationPlayer.play_section_with_markers_backwards(name: StringName = &"", start_marker: StringName = &"", end_marker: StringName = &"", custom_blend: float = -1) -> void
Plays the animation with key [param name] and the section starting from [param start_marker] and ending on [param end_marker] in reverse.
This method is a shorthand for [method play_section_with_markers] with [code]custom_speed = -1.0[/code] and [code]from_end = true[/code], see its description for more information.

### name :: StringName

### start_marker :: StringName

### end_marker :: StringName

### custom_blend :: float

## play_with_capture :: func AnimationPlayer.play_with_capture(name: StringName = &"", duration: float = -1.0, custom_blend: float = -1, custom_speed: float = 1.0, from_end: bool = false, trans_type: int = 0, ease_type: int = 0) -> void
See also [method AnimationMixer.capture].
You can use this method to use more detailed options for capture than those performed by [member playback_auto_capture]. When [member playback_auto_capture] is [code]false[/code], this method is almost the same as the following:
[codeblock]
capture(name, duration, trans_type, ease_type)
play(name, custom_blend, custom_speed, from_end)
[/codeblock]
If [param name] is blank, it specifies [member assigned_animation].
If [param duration] is a negative value, the duration is set to the interval between the current position and the first key, when [param from_end] is [code]true[/code], uses the interval between the current position and the last key instead.
[b]Note:[/b] The [param duration] takes [member speed_scale] into account, but [param custom_speed] does not, because the capture cache is interpolated with the blend result and the result may contain multiple animations.

### name :: StringName

### duration :: float

### custom_blend :: float

### custom_speed :: float

### from_end :: bool

### trans_type :: int

### ease_type :: int

## queue :: func AnimationPlayer.queue(name: StringName) -> void
Queues an animation for playback once the current animation and all previously queued animations are done.
[b]Note:[/b] If a looped animation is currently playing, the queued animation will never play unless the looped animation is stopped somehow.

### name :: StringName

## reset_section :: func AnimationPlayer.reset_section() -> void
Resets the current section. Does nothing if a section has not been set.

## seek :: func AnimationPlayer.seek(seconds: float, update: bool = false, update_only: bool = false) -> void
Seeks the animation to the [param seconds] point in time (in seconds). If [param update] is [code]true[/code], the animation updates too, otherwise it updates at process time. Events between the current frame and [param seconds] are skipped.
If [param update_only] is [code]true[/code], the method / audio / animation playback tracks will not be processed.
[b]Note:[/b] Seeking to the end of the animation doesn't emit [signal AnimationMixer.animation_finished]. If you want to skip animation and emit the signal, use [method AnimationMixer.advance].

### seconds :: float

### update :: bool

### update_only :: bool

## set_blend_time :: func AnimationPlayer.set_blend_time(animation_from: StringName, animation_to: StringName, sec: float) -> void
Specifies a blend time (in seconds) between two animations, referenced by their keys.

### animation_from :: StringName

### animation_to :: StringName

### sec :: float

## set_method_call_mode :: func AnimationPlayer.set_method_call_mode(mode: int) -> void
Sets the call mode used for "Call Method" tracks.

### mode :: int

## set_process_callback :: func AnimationPlayer.set_process_callback(mode: int) -> void
Sets the process notification in which to update animations.

### mode :: int

## set_root :: func AnimationPlayer.set_root(path: NodePath) -> void
Sets the node which node path references will travel from.

### path :: NodePath

## set_section :: func AnimationPlayer.set_section(start_time: float = -1, end_time: float = -1) -> void
Changes the start and end times of the section being played. The current playback position will be clamped within the new section. See also [method play_section].

### start_time :: float

### end_time :: float

## set_section_with_markers :: func AnimationPlayer.set_section_with_markers(start_marker: StringName = &"", end_marker: StringName = &"") -> void
Changes the start and end markers of the section being played. The current playback position will be clamped within the new section. See also [method play_section_with_markers].
If the argument is empty, the section uses the beginning or end of the animation. If both are empty, it means that the section is not set.

### start_marker :: StringName

### end_marker :: StringName

## stop :: func AnimationPlayer.stop(keep_state: bool = false) -> void
Stops the currently playing animation. The animation position is reset to [code]0[/code] and the [code]custom_speed[/code] is reset to [code]1.0[/code]. See also [method pause].
If [param keep_state] is [code]true[/code], the animation state is not updated visually.
[b]Note:[/b] The method / audio / animation playback tracks will not be processed by this method.

### keep_state :: bool

## animation_changed :: func AnimationPlayer.animation_changed(old_name: StringName, new_name: StringName) -> void
Emitted when a queued animation plays after the previous animation finished. See also [method AnimationPlayer.queue].
[b]Note:[/b] The signal is not emitted when the animation is changed via [method AnimationPlayer.play] or by an [AnimationTree].

### old_name :: StringName

### new_name :: StringName

## current_animation_changed :: func AnimationPlayer.current_animation_changed(anim_name: StringName) -> void
Emitted when [member current_animation] changes.

### anim_name :: StringName
