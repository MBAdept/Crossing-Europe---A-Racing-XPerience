# TextureCubemapArrayRD :: <Native> class TextureCubemapArrayRD extends TextureLayeredRD
Texture Array for Cubemaps that is bound to a texture created on the [RenderingDevice].
This texture class allows you to use a cubemap array texture created directly on the [RenderingDevice] as a texture for materials, meshes, etc.
[b]Note:[/b] [TextureCubemapArrayRD] is intended for low-level usage with [RenderingDevice]. For most use cases, use [CubemapArray] instead.
