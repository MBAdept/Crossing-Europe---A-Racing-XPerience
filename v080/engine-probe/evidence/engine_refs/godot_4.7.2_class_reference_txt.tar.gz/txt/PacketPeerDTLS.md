# PacketPeerDTLS :: <Native> class PacketPeerDTLS extends PacketPeer
DTLS packet peer.
This class represents a DTLS peer connection. It can be used to connect to a DTLS server, and is returned by [method DTLSServer.take_connection].
[b]Note:[/b] When exporting to Android, make sure to enable the [code]INTERNET[/code] permission in the Android export preset before exporting the project or using one-click deploy. Otherwise, network communication of any kind will be blocked by Android.
[b]Warning:[/b] TLS certificate revocation and certificate pinning are currently not supported. Revoked certificates are accepted as long as they are otherwise valid. If this is a concern, you may want to use automatically managed certificates with a short validity period.

## STATUS_DISCONNECTED :: const PacketPeerDTLS.STATUS_DISCONNECTED: Status = 0
A status representing a [PacketPeerDTLS] that is disconnected.

## STATUS_HANDSHAKING :: const PacketPeerDTLS.STATUS_HANDSHAKING: Status = 1
A status representing a [PacketPeerDTLS] that is currently performing the handshake with a remote peer.

## STATUS_CONNECTED :: const PacketPeerDTLS.STATUS_CONNECTED: Status = 2
A status representing a [PacketPeerDTLS] that is connected to a remote peer.

## STATUS_ERROR :: const PacketPeerDTLS.STATUS_ERROR: Status = 3
A status representing a [PacketPeerDTLS] in a generic error state.

## STATUS_ERROR_HOSTNAME_MISMATCH :: const PacketPeerDTLS.STATUS_ERROR_HOSTNAME_MISMATCH: Status = 4
An error status that shows a mismatch in the DTLS certificate domain presented by the host and the domain requested for validation.

## connect_to_peer :: func PacketPeerDTLS.connect_to_peer(packet_peer: PacketPeerUDP, hostname: String, client_options: TLSOptions = null) -> int
Connects a [param packet_peer] beginning the DTLS handshake using the underlying [PacketPeerUDP] which must be connected (see [method PacketPeerUDP.connect_to_host]). You can optionally specify the [param client_options] to be used while verifying the TLS connections. See [method TLSOptions.client] and [method TLSOptions.client_unsafe].

### packet_peer :: PacketPeerUDP

### hostname :: String

### client_options :: TLSOptions

## disconnect_from_peer :: func PacketPeerDTLS.disconnect_from_peer() -> void
Disconnects this peer, terminating the DTLS session.

## get_status :: func PacketPeerDTLS.get_status() -> int
Returns the status of the connection.

## poll :: func PacketPeerDTLS.poll() -> void
Poll the connection to check for incoming packets. Call this frequently to update the status and keep the connection working.
