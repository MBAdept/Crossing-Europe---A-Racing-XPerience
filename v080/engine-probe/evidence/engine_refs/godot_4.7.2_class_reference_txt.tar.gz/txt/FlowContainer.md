# FlowContainer :: <Native> class FlowContainer extends Container
A container that arranges its child controls horizontally or vertically and wraps them around at the borders.
A container that arranges its child controls horizontally or vertically and wraps them around at the borders. This is similar to how text in a book wraps around when no more words can fit on a line.

## ALIGNMENT_BEGIN :: const FlowContainer.ALIGNMENT_BEGIN: AlignmentMode = 0
The child controls will be arranged at the beginning of the container, i.e. top if orientation is vertical, left if orientation is horizontal (right for RTL layout).

## ALIGNMENT_CENTER :: const FlowContainer.ALIGNMENT_CENTER: AlignmentMode = 1
The child controls will be centered in the container.

## ALIGNMENT_END :: const FlowContainer.ALIGNMENT_END: AlignmentMode = 2
The child controls will be arranged at the end of the container, i.e. bottom if orientation is vertical, right if orientation is horizontal (left for RTL layout).

## LAST_WRAP_ALIGNMENT_INHERIT :: const FlowContainer.LAST_WRAP_ALIGNMENT_INHERIT: LastWrapAlignmentMode = 0
The last partially filled row or column will wrap aligned to the previous row or column in accordance with [member alignment].

## LAST_WRAP_ALIGNMENT_BEGIN :: const FlowContainer.LAST_WRAP_ALIGNMENT_BEGIN: LastWrapAlignmentMode = 1
The last partially filled row or column will wrap aligned to the beginning of the previous row or column.

## LAST_WRAP_ALIGNMENT_CENTER :: const FlowContainer.LAST_WRAP_ALIGNMENT_CENTER: LastWrapAlignmentMode = 2
The last partially filled row or column will wrap aligned to the center of the previous row or column.

## LAST_WRAP_ALIGNMENT_END :: const FlowContainer.LAST_WRAP_ALIGNMENT_END: LastWrapAlignmentMode = 3
The last partially filled row or column will wrap aligned to the end of the previous row or column.

## alignment :: var FlowContainer.alignment: FlowContainer.AlignmentMode
The alignment of the container's children (must be one of [constant ALIGNMENT_BEGIN], [constant ALIGNMENT_CENTER], or [constant ALIGNMENT_END]).

## last_wrap_alignment :: var FlowContainer.last_wrap_alignment: FlowContainer.LastWrapAlignmentMode
The wrap behavior of the last, partially filled row or column (must be one of [constant LAST_WRAP_ALIGNMENT_INHERIT], [constant LAST_WRAP_ALIGNMENT_BEGIN], [constant LAST_WRAP_ALIGNMENT_CENTER], or [constant LAST_WRAP_ALIGNMENT_END]).

## reverse_fill :: var FlowContainer.reverse_fill: bool
If [code]true[/code], reverses fill direction. Horizontal [FlowContainer]s will fill rows bottom to top, vertical [FlowContainer]s will fill columns right to left.
When using a vertical [FlowContainer] with a right to left [member Control.layout_direction], columns will fill left to right instead.

## vertical :: var FlowContainer.vertical: bool
If [code]true[/code], the [FlowContainer] will arrange its children vertically, rather than horizontally.
Can't be changed when using [HFlowContainer] and [VFlowContainer].

## h_separation :: <Theme> var FlowContainer.h_separation: int
The horizontal separation of child nodes.

## v_separation :: <Theme> var FlowContainer.v_separation: int
The vertical separation of child nodes.

## get_line_count :: func FlowContainer.get_line_count() -> int
Returns the current line count.
