# Skeleton2D :: <Native> class Skeleton2D extends Node2D
The parent of a hierarchy of [Bone2D]s, used to create a 2D skeletal animation.
[Skeleton2D] parents a hierarchy of [Bone2D] nodes. It holds a reference to each [Bone2D]'s rest pose and acts as a single point of access to its bones.
To set up different types of inverse kinematics for the given Skeleton2D, a [SkeletonModificationStack2D] should be created. The inverse kinematics be applied by increasing [member SkeletonModificationStack2D.modification_count] and creating the desired number of modifications.

## execute_modifications :: func Skeleton2D.execute_modifications(delta: float, execution_mode: int) -> void
Executes all the modifications on the [SkeletonModificationStack2D], if the Skeleton2D has one assigned.

### delta :: float

### execution_mode :: int

## get_bone :: func Skeleton2D.get_bone(idx: int) -> Bone2D
Returns a [Bone2D] from the node hierarchy parented by Skeleton2D. The object to return is identified by the parameter [param idx]. Bones are indexed by descending the node hierarchy from top to bottom, adding the children of each branch before moving to the next sibling.

### idx :: int

## get_bone_count :: func Skeleton2D.get_bone_count() -> int
Returns the number of [Bone2D] nodes in the node hierarchy parented by Skeleton2D.

## get_bone_local_pose_override :: func Skeleton2D.get_bone_local_pose_override(bone_idx: int) -> Transform2D
Returns the local pose override transform for [param bone_idx].

### bone_idx :: int

## get_modification_stack :: func Skeleton2D.get_modification_stack() -> SkeletonModificationStack2D
Returns the [SkeletonModificationStack2D] attached to this skeleton, if one exists.

## get_skeleton :: func Skeleton2D.get_skeleton() -> RID
Returns the [RID] of a Skeleton2D instance.

## set_bone_local_pose_override :: func Skeleton2D.set_bone_local_pose_override(bone_idx: int, override_pose: Transform2D, strength: float, persistent: bool) -> void
Sets the local pose transform, [param override_pose], for the bone at [param bone_idx].
[param strength] is the interpolation strength that will be used when applying the pose, and [param persistent] determines if the applied pose will remain.
[b]Note:[/b] The pose transform needs to be a local transform relative to the [Bone2D] node at [param bone_idx]!

### bone_idx :: int

### override_pose :: Transform2D

### strength :: float

### persistent :: bool

## set_modification_stack :: func Skeleton2D.set_modification_stack(modification_stack: SkeletonModificationStack2D) -> void
Sets the [SkeletonModificationStack2D] attached to this skeleton.

### modification_stack :: SkeletonModificationStack2D

## bone_setup_changed :: func Skeleton2D.bone_setup_changed() -> void
Emitted when the [Bone2D] setup attached to this skeletons changes. This is primarily used internally within the skeleton.
