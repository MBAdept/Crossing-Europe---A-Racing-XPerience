# XRInterfaceExtension :: <Native> class XRInterfaceExtension extends XRInterface
Base class for XR interface extensions (plugins).
External XR interface plugins should inherit from this class.

## _end_frame :: func XRInterfaceExtension._end_frame() -> void
Called if interface is active and queues have been submitted.

## _get_anchor_detection_is_enabled :: func XRInterfaceExtension._get_anchor_detection_is_enabled() -> bool
Return [code]true[/code] if anchor detection is enabled for this interface.

## _get_camera_feed_id :: func XRInterfaceExtension._get_camera_feed_id() -> int
Returns the camera feed ID for the [CameraFeed] registered with the [CameraServer] that should be presented as the background on an AR capable device (if applicable).

## _get_camera_transform :: func XRInterfaceExtension._get_camera_transform() -> Transform3D
Returns the [Transform3D] that positions the [XRCamera3D] in the world.

## _get_capabilities :: func XRInterfaceExtension._get_capabilities() -> int
Returns the capabilities of this interface.

## _get_color_texture :: func XRInterfaceExtension._get_color_texture() -> RID
Return color texture into which to render (if applicable).

## _get_depth_texture :: func XRInterfaceExtension._get_depth_texture() -> RID
Return depth texture into which to render (if applicable).

## _get_name :: func XRInterfaceExtension._get_name() -> StringName
Returns the name of this interface.

## _get_play_area :: func XRInterfaceExtension._get_play_area() -> PackedVector3Array
Returns a [PackedVector3Array] that represents the play areas boundaries (if applicable).

## _get_play_area_mode :: func XRInterfaceExtension._get_play_area_mode() -> int
Returns the play area mode that sets up our play area.

## _get_projection_for_view :: func XRInterfaceExtension._get_projection_for_view(view: int, aspect: float, z_near: float, z_far: float) -> PackedFloat64Array
Returns the projection matrix for the given view as a [PackedFloat64Array].

### view :: int

### aspect :: float

### z_near :: float

### z_far :: float

## _get_render_target_size :: func XRInterfaceExtension._get_render_target_size() -> Vector2
Returns the size of our render target for this interface, this overrides the size of the [Viewport] marked as the xr viewport.

## _get_suggested_pose_names :: func XRInterfaceExtension._get_suggested_pose_names(tracker_name: StringName) -> PackedStringArray
Returns a [PackedStringArray] with pose names configured by this interface. Note that user configuration can override this list.

### tracker_name :: StringName

## _get_suggested_tracker_names :: func XRInterfaceExtension._get_suggested_tracker_names() -> PackedStringArray
Returns a [PackedStringArray] with tracker names configured by this interface. Note that user configuration can override this list.

## _get_system_info :: func XRInterfaceExtension._get_system_info() -> Dictionary
Returns a [Dictionary] with system information related to this interface.

## _get_tracking_status :: func XRInterfaceExtension._get_tracking_status() -> int
Returns the current status of our tracking.

## _get_transform_for_view :: func XRInterfaceExtension._get_transform_for_view(view: int, cam_transform: Transform3D) -> Transform3D
Returns a [Transform3D] for a given view.

### view :: int

### cam_transform :: Transform3D

## _get_velocity_texture :: func XRInterfaceExtension._get_velocity_texture() -> RID
Return velocity texture into which to render (if applicable).

## _get_view_count :: func XRInterfaceExtension._get_view_count() -> int
Returns the number of views this interface requires, 1 for mono, 2 for stereoscopic.

## _get_vrs_texture :: func XRInterfaceExtension._get_vrs_texture() -> RID

## _get_vrs_texture_format :: func XRInterfaceExtension._get_vrs_texture_format() -> int
Returns the format of the texture returned by [method _get_vrs_texture].

## _initialize :: func XRInterfaceExtension._initialize() -> bool
Initializes the interface, returns [code]true[/code] on success.

## _is_initialized :: func XRInterfaceExtension._is_initialized() -> bool
Returns [code]true[/code] if this interface has been initialized.

## _post_draw_viewport :: func XRInterfaceExtension._post_draw_viewport(render_target: RID, screen_rect: Rect2) -> void
Called after the XR [Viewport] draw logic has completed.

### render_target :: RID

### screen_rect :: Rect2

## _pre_draw_viewport :: func XRInterfaceExtension._pre_draw_viewport(render_target: RID) -> bool
Called if this is our primary [XRInterfaceExtension] before we start processing a [Viewport] for every active XR [Viewport], returns [code]true[/code] if that viewport should be rendered. An XR interface may return [code]false[/code] if the user has taken off their headset and we can pause rendering.

### render_target :: RID

## _pre_render :: func XRInterfaceExtension._pre_render() -> void
Called if this [XRInterfaceExtension] is active before rendering starts. Most XR interfaces will sync tracking at this point in time.

## _process :: func XRInterfaceExtension._process() -> void
Called if this [XRInterfaceExtension] is active before our physics and game process is called. Most XR interfaces will update its [XRPositionalTracker]s at this point in time.

## _set_anchor_detection_is_enabled :: func XRInterfaceExtension._set_anchor_detection_is_enabled(enabled: bool) -> void
Enables anchor detection on this interface if supported.

### enabled :: bool

## _set_play_area_mode :: func XRInterfaceExtension._set_play_area_mode(mode: int) -> bool
Set the play area mode for this interface.

### mode :: int

## _supports_play_area_mode :: func XRInterfaceExtension._supports_play_area_mode(mode: int) -> bool
Returns [code]true[/code] if this interface supports this play area mode.

### mode :: int

## _trigger_haptic_pulse :: func XRInterfaceExtension._trigger_haptic_pulse(action_name: String, tracker_name: StringName, frequency: float, amplitude: float, duration_sec: float, delay_sec: float) -> void
Triggers a haptic pulse to be emitted on the specified tracker.

### action_name :: String

### tracker_name :: StringName

### frequency :: float

### amplitude :: float

### duration_sec :: float

### delay_sec :: float

## _uninitialize :: func XRInterfaceExtension._uninitialize() -> void
Uninitialize the interface.

## add_blit :: func XRInterfaceExtension.add_blit(render_target: RID, src_rect: Rect2, dst_rect: Rect2i, use_layer: bool, layer: int, apply_lens_distortion: bool, eye_center: Vector2, k1: float, k2: float, upscale: float, aspect_ratio: float) -> void
Blits our render results to screen optionally applying lens distortion. This can only be called while processing [code]_commit_views[/code].

### render_target :: RID

### src_rect :: Rect2

### dst_rect :: Rect2i

### use_layer :: bool

### layer :: int

### apply_lens_distortion :: bool

### eye_center :: Vector2

### k1 :: float

### k2 :: float

### upscale :: float

### aspect_ratio :: float

## get_color_texture :: func XRInterfaceExtension.get_color_texture() -> RID

## get_depth_texture :: func XRInterfaceExtension.get_depth_texture() -> RID

## get_render_target_texture :: func XRInterfaceExtension.get_render_target_texture(render_target: RID) -> RID
Returns a valid [RID] for a texture to which we should render the current frame if supported by the interface.

### render_target :: RID

## get_velocity_texture :: func XRInterfaceExtension.get_velocity_texture() -> RID
