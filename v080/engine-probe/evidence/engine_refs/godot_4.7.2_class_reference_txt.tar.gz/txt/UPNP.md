# UPNP :: <Native> class UPNP extends RefCounted
Universal Plug and Play (UPnP) functions for network device discovery, querying and port forwarding.
This class can be used to discover compatible [UPNPDevice]s on the local network and execute commands on them, like managing port mappings (for port forwarding/NAT traversal) and querying the local and remote network IP address. Note that methods on this class are synchronous and block the calling thread.
To forward a specific port (here [code]7777[/code], note both [method discover] and [method add_port_mapping] can return errors that should be checked):
[codeblock]
var upnp = UPNP.new()
upnp.discover()
upnp.add_port_mapping(7777)
[/codeblock]
To close a specific port (e.g. after you have finished using it):
[codeblock]
upnp.delete_port_mapping(port)
[/codeblock]
[b]Note:[/b] UPnP discovery blocks the current thread. To perform discovery without blocking the main thread, use [Thread]s like this:
[codeblock]
# Emitted when UPnP port mapping setup is completed (regardless of success or failure).
signal upnp_completed(error)

# Replace this with your own server port number between 1024 and 65535.
const SERVER_PORT = 3928
var thread = null

func _upnp_setup(server_port):
	# UPNP queries take some time.
	var upnp = UPNP.new()
	var err = upnp.discover()

	if err != UPNP.UPNP_RESULT_SUCCESS:
		push_error(str(err))
		upnp_completed.emit(err)
		return

	if upnp.get_gateway() and upnp.get_gateway().is_valid_gateway():
		upnp.add_port_mapping(server_port, server_port, ProjectSettings.get_setting("application/config/name"), "UDP")
		upnp.add_port_mapping(server_port, server_port, ProjectSettings.get_setting("application/config/name"), "TCP")
		upnp_completed.emit(UPNP.UPNP_RESULT_SUCCESS)

func _ready():
	thread = Thread.new()
	thread.start(_upnp_setup.bind(SERVER_PORT))

func _exit_tree():
	# Wait for thread finish here to handle game exit while the thread is running.
	thread.wait_to_finish()
[/codeblock]
[b]Terminology:[/b] In the context of UPnP networking, "gateway" (or "internet gateway device", short IGD) refers to network devices that allow computers in the local network to access the internet ("wide area network", WAN). These gateways are often also called "routers".
[b]Pitfalls:[/b]
- As explained above, these calls are blocking and shouldn't be run on the main thread, especially as they can block for multiple seconds at a time. Use threading!
- Networking is physical and messy. Packets get lost in transit or get filtered, addresses, free ports and assigned mappings change, and devices may leave or join the network at any time. Be mindful of this, be diligent when checking and handling errors, and handle these gracefully if you can: add clear error UI, timeouts and re-try handling.
- Port mappings may change (and be removed) at any time, and the remote/external IP address of the gateway can change likewise. You should consider re-querying the external IP and try to update/refresh the port mapping periodically (for example, every 5 minutes and on networking failures).
- Not all devices support UPnP, and some users disable UPnP support. You need to handle this (e.g. documenting and requiring the user to manually forward ports, or adding alternative methods of NAT traversal, like a relay/mirror server, or NAT hole punching, STUN/TURN, etc.).
- Consider what happens on mapping conflicts. Maybe multiple users on the same network would like to play your game at the same time, or maybe another application uses the same port. Make the port configurable, and optimally choose a port automatically (re-trying with a different port on failure).
[b]Further reading:[/b] If you want to know more about UPnP (and the Internet Gateway Device (IGD) and Port Control Protocol (PCP) specifically), [url=https://en.wikipedia.org/wiki/Universal_Plug_and_Play]Wikipedia[/url] is a good first stop, the specification can be found at the [url=https://openconnectivity.org/developer/specifications/upnp-resources/upnp/]Open Connectivity Foundation[/url] and Godot's implementation is based on the [url=https://github.com/miniupnp/miniupnp]MiniUPnP client[/url].

## UPNP_RESULT_SUCCESS :: const UPNP.UPNP_RESULT_SUCCESS: UPNPResult = 0
UPNP command or discovery was successful.

## UPNP_RESULT_NOT_AUTHORIZED :: const UPNP.UPNP_RESULT_NOT_AUTHORIZED: UPNPResult = 1
Not authorized to use the command on the [UPNPDevice]. May be returned when the user disabled UPNP on their router.

## UPNP_RESULT_PORT_MAPPING_NOT_FOUND :: const UPNP.UPNP_RESULT_PORT_MAPPING_NOT_FOUND: UPNPResult = 2
No port mapping was found for the given port, protocol combination on the given [UPNPDevice].

## UPNP_RESULT_INCONSISTENT_PARAMETERS :: const UPNP.UPNP_RESULT_INCONSISTENT_PARAMETERS: UPNPResult = 3
Inconsistent parameters.

## UPNP_RESULT_NO_SUCH_ENTRY_IN_ARRAY :: const UPNP.UPNP_RESULT_NO_SUCH_ENTRY_IN_ARRAY: UPNPResult = 4
No such entry in array. May be returned if a given port, protocol combination is not found on a [UPNPDevice].

## UPNP_RESULT_ACTION_FAILED :: const UPNP.UPNP_RESULT_ACTION_FAILED: UPNPResult = 5
The action failed.

## UPNP_RESULT_SRC_IP_WILDCARD_NOT_PERMITTED :: const UPNP.UPNP_RESULT_SRC_IP_WILDCARD_NOT_PERMITTED: UPNPResult = 6
The [UPNPDevice] does not allow wildcard values for the source IP address.

## UPNP_RESULT_EXT_PORT_WILDCARD_NOT_PERMITTED :: const UPNP.UPNP_RESULT_EXT_PORT_WILDCARD_NOT_PERMITTED: UPNPResult = 7
The [UPNPDevice] does not allow wildcard values for the external port.

## UPNP_RESULT_INT_PORT_WILDCARD_NOT_PERMITTED :: const UPNP.UPNP_RESULT_INT_PORT_WILDCARD_NOT_PERMITTED: UPNPResult = 8
The [UPNPDevice] does not allow wildcard values for the internal port.

## UPNP_RESULT_REMOTE_HOST_MUST_BE_WILDCARD :: const UPNP.UPNP_RESULT_REMOTE_HOST_MUST_BE_WILDCARD: UPNPResult = 9
The remote host value must be a wildcard.

## UPNP_RESULT_EXT_PORT_MUST_BE_WILDCARD :: const UPNP.UPNP_RESULT_EXT_PORT_MUST_BE_WILDCARD: UPNPResult = 10
The external port value must be a wildcard.

## UPNP_RESULT_NO_PORT_MAPS_AVAILABLE :: const UPNP.UPNP_RESULT_NO_PORT_MAPS_AVAILABLE: UPNPResult = 11
No port maps are available. May also be returned if port mapping functionality is not available.

## UPNP_RESULT_CONFLICT_WITH_OTHER_MECHANISM :: const UPNP.UPNP_RESULT_CONFLICT_WITH_OTHER_MECHANISM: UPNPResult = 12
Conflict with other mechanism. May be returned instead of [constant UPNP_RESULT_CONFLICT_WITH_OTHER_MAPPING] if a port mapping conflicts with an existing one.

## UPNP_RESULT_CONFLICT_WITH_OTHER_MAPPING :: const UPNP.UPNP_RESULT_CONFLICT_WITH_OTHER_MAPPING: UPNPResult = 13
Conflict with an existing port mapping.

## UPNP_RESULT_SAME_PORT_VALUES_REQUIRED :: const UPNP.UPNP_RESULT_SAME_PORT_VALUES_REQUIRED: UPNPResult = 14
External and internal port values must be the same.

## UPNP_RESULT_ONLY_PERMANENT_LEASE_SUPPORTED :: const UPNP.UPNP_RESULT_ONLY_PERMANENT_LEASE_SUPPORTED: UPNPResult = 15
Only permanent leases are supported. Do not use the [code]duration[/code] parameter when adding port mappings.

## UPNP_RESULT_INVALID_GATEWAY :: const UPNP.UPNP_RESULT_INVALID_GATEWAY: UPNPResult = 16
Invalid gateway.

## UPNP_RESULT_INVALID_PORT :: const UPNP.UPNP_RESULT_INVALID_PORT: UPNPResult = 17
Invalid port.

## UPNP_RESULT_INVALID_PROTOCOL :: const UPNP.UPNP_RESULT_INVALID_PROTOCOL: UPNPResult = 18
Invalid protocol.

## UPNP_RESULT_INVALID_DURATION :: const UPNP.UPNP_RESULT_INVALID_DURATION: UPNPResult = 19
Invalid duration.

## UPNP_RESULT_INVALID_ARGS :: const UPNP.UPNP_RESULT_INVALID_ARGS: UPNPResult = 20
Invalid arguments.

## UPNP_RESULT_INVALID_RESPONSE :: const UPNP.UPNP_RESULT_INVALID_RESPONSE: UPNPResult = 21
Invalid response.

## UPNP_RESULT_INVALID_PARAM :: const UPNP.UPNP_RESULT_INVALID_PARAM: UPNPResult = 22
Invalid parameter.

## UPNP_RESULT_HTTP_ERROR :: const UPNP.UPNP_RESULT_HTTP_ERROR: UPNPResult = 23
HTTP error.

## UPNP_RESULT_SOCKET_ERROR :: const UPNP.UPNP_RESULT_SOCKET_ERROR: UPNPResult = 24
Socket error.

## UPNP_RESULT_MEM_ALLOC_ERROR :: const UPNP.UPNP_RESULT_MEM_ALLOC_ERROR: UPNPResult = 25
Error allocating memory.

## UPNP_RESULT_NO_GATEWAY :: const UPNP.UPNP_RESULT_NO_GATEWAY: UPNPResult = 26
No gateway available. You may need to call [method discover] first, or discovery didn't detect any valid IGDs (InternetGatewayDevices).

## UPNP_RESULT_NO_DEVICES :: const UPNP.UPNP_RESULT_NO_DEVICES: UPNPResult = 27
No devices available. You may need to call [method discover] first, or discovery didn't detect any valid [UPNPDevice]s.

## UPNP_RESULT_UNKNOWN_ERROR :: const UPNP.UPNP_RESULT_UNKNOWN_ERROR: UPNPResult = 28
Unknown error.

## discover_ipv6 :: var UPNP.discover_ipv6: bool
If [code]true[/code], IPv6 is used for [UPNPDevice] discovery.

## discover_local_port :: var UPNP.discover_local_port: int
If [code]0[/code], the local port to use for discovery is chosen automatically by the system. If [code]1[/code], discovery will be done from the source port 1900 (same as destination port). Otherwise, the value will be used as the port.

## discover_multicast_if :: var UPNP.discover_multicast_if: String
Multicast interface to use for discovery. Uses the default multicast interface if empty.

## add_device :: func UPNP.add_device(device: UPNPDevice) -> void
Adds the given [UPNPDevice] to the list of discovered devices.

### device :: UPNPDevice

## add_port_mapping :: func UPNP.add_port_mapping(port: int, port_internal: int = 0, desc: String = "", proto: String = "UDP", duration: int = 0) -> int
Adds a mapping to forward the external [param port] (between 1 and 65535, although recommended to use port 1024 or above) on the default gateway (see [method get_gateway]) to the [param port_internal] on the local machine for the given protocol [param proto] (either [code]"TCP"[/code] or [code]"UDP"[/code], with UDP being the default). If a port mapping for the given port and protocol combination already exists on that gateway device, this method tries to overwrite it. If that is not desired, you can retrieve the gateway manually with [method get_gateway] and call [method add_port_mapping] on it, if any. Note that forwarding a well-known port (below 1024) with UPnP may fail depending on the device.
Depending on the gateway device, if a mapping for that port already exists, it will either be updated or it will refuse this command due to that conflict, especially if the existing mapping for that port wasn't created via UPnP or points to a different network address (or device) than this one.
If [param port_internal] is [code]0[/code] (the default), the same port number is used for both the external and the internal port (the [param port] value).
The description ([param desc]) is shown in some routers management UIs and can be used to point out which application added the mapping.
The mapping's lease [param duration] can be limited by specifying a duration in seconds. The default of [code]0[/code] means no duration, i.e. a permanent lease and notably some devices only support these permanent leases. Note that whether permanent or not, this is only a request and the gateway may still decide at any point to remove the mapping (which usually happens on a reboot of the gateway, when its external IP address changes, or on some models when it detects a port mapping has become inactive, i.e. had no traffic for multiple minutes). If not [code]0[/code] (permanent), the allowed range according to spec is between [code]120[/code] (2 minutes) and [code]86400[/code] seconds (24 hours).
See [enum UPNPResult] for possible return values.

### port :: int

### port_internal :: int

### desc :: String

### proto :: String

### duration :: int

## clear_devices :: func UPNP.clear_devices() -> void
Clears the list of discovered devices.

## delete_port_mapping :: func UPNP.delete_port_mapping(port: int, proto: String = "UDP") -> int
Deletes the port mapping for the given port and protocol combination on the default gateway (see [method get_gateway]) if one exists. [param port] must be a valid port between 1 and 65535, [param proto] can be either [code]"TCP"[/code] or [code]"UDP"[/code]. May be refused for mappings pointing to addresses other than this one, for well-known ports (below 1024), or for mappings not added via UPnP. See [enum UPNPResult] for possible return values.

### port :: int

### proto :: String

## discover :: func UPNP.discover(timeout: int = 2000, ttl: int = 2, device_filter: String = "InternetGatewayDevice") -> int
Discovers local [UPNPDevice]s. Clears the list of previously discovered devices.
Filters for IGD (InternetGatewayDevice) type devices by default, as those manage port forwarding. [param timeout] is the time to wait for responses in milliseconds. [param ttl] is the time-to-live; only touch this if you know what you're doing.
See [enum UPNPResult] for possible return values.

### timeout :: int

### ttl :: int

### device_filter :: String

## get_device :: func UPNP.get_device(index: int) -> UPNPDevice
Returns the [UPNPDevice] at the given [param index].

### index :: int

## get_device_count :: func UPNP.get_device_count() -> int
Returns the number of discovered [UPNPDevice]s.

## get_gateway :: func UPNP.get_gateway() -> UPNPDevice
Returns the default gateway. That is the first discovered [UPNPDevice] that is also a valid IGD (InternetGatewayDevice).

## query_external_address :: func UPNP.query_external_address() -> String
Returns the external [IP] address of the default gateway (see [method get_gateway]) as string. Returns an empty string on error.

## remove_device :: func UPNP.remove_device(index: int) -> void
Removes the device at [param index] from the list of discovered devices.

### index :: int

## set_device :: func UPNP.set_device(index: int, device: UPNPDevice) -> void
Sets the device at [param index] from the list of discovered devices to [param device].

### index :: int

### device :: UPNPDevice
