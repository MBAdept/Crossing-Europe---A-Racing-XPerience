# PackedFloat64Array :: <Native> class PackedFloat64Array
A packed array of 64-bit floating-point values.
An array specifically designed to hold 64-bit floating-point values (double). Packs data tightly, so it saves memory for large array sizes.
If you only need to pack 32-bit floats tightly, see [PackedFloat32Array] for a more memory-friendly alternative.
[b]Differences between packed arrays, typed arrays, and untyped arrays:[/b] Packed arrays are generally faster to iterate on and modify compared to a typed array of the same type (e.g. [PackedFloat64Array] versus [code]Array[float][/code]). Also, packed arrays consume less memory. As a downside, packed arrays are less flexible as they don't offer as many convenience methods such as [method Array.map]. Typed arrays are in turn faster to iterate on and modify than untyped arrays.
[b]Note:[/b] Packed arrays are always passed by reference. To get a copy of an array that can be modified independently of the original array, use [method duplicate]. This is [i]not[/i] the case for built-in properties and methods. In these cases the returned packed array is a copy, and changing it will [i]not[/i] affect the original value. To update a built-in property of this type, modify the returned array and then assign it to the property again.
[b]Note:[/b] In a boolean context, a packed array will evaluate to [code]false[/code] if it's empty. Otherwise, a packed array will always evaluate to [code]true[/code].

## append :: func PackedFloat64Array.append(value: float) -> bool
Appends an element at the end of the array (alias of [method push_back]).

### value :: float

## append_array :: func PackedFloat64Array.append_array(array: PackedFloat64Array) -> void
Appends a [PackedFloat64Array] at the end of this array.

### array :: PackedFloat64Array

## bsearch :: func PackedFloat64Array.bsearch(value: float, before: bool = true) -> int
Finds the index of an existing value (or the insertion index that maintains sorting order, if the value is not yet present in the array) using binary search. Optionally, a [param before] specifier can be passed. If [code]false[/code], the returned index comes after all existing entries of the value in the array.
[b]Note:[/b] Calling [method bsearch] on an unsorted array results in unexpected behavior.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

### before :: bool

## clear :: func PackedFloat64Array.clear() -> void
Clears the array. This is equivalent to using [method resize] with a size of [code]0[/code].

## count :: func PackedFloat64Array.count(value: float) -> int
Returns the number of times an element is in the array.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

## duplicate :: func PackedFloat64Array.duplicate() -> PackedFloat64Array
Creates a copy of the array, and returns it.

## erase :: func PackedFloat64Array.erase(value: float) -> bool
Removes the first occurrence of a value from the array and returns [code]true[/code]. If the value does not exist in the array, nothing happens and [code]false[/code] is returned. To remove an element by index, use [method remove_at] instead.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

## fill :: func PackedFloat64Array.fill(value: float) -> void
Assigns the given value to all elements in the array. This can typically be used together with [method resize] to create an array with a given size and initialized elements.

### value :: float

## find :: func PackedFloat64Array.find(value: float, from: int = 0) -> int
Searches the array for a value and returns its index or [code]-1[/code] if not found. Optionally, the initial search index can be passed.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

### from :: int

## get :: func PackedFloat64Array.get(index: int) -> float
Returns the 64-bit float at the given [param index] in the array. If [param index] is out-of-bounds or negative, this method fails and returns [code]0.0[/code].
This method is similar (but not identical) to the [code][][/code] operator. Most notably, when this method fails, it doesn't pause project execution if run from the editor.

### index :: int

## has :: func PackedFloat64Array.has(value: float) -> bool
Returns [code]true[/code] if the array contains [param value].
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

## insert :: func PackedFloat64Array.insert(at_index: int, value: float) -> int
Inserts a new element at a given position in the array. The position must be valid, or at the end of the array ([code]idx == size()[/code]).

### at_index :: int

### value :: float

## is_empty :: func PackedFloat64Array.is_empty() -> bool
Returns [code]true[/code] if the array is empty.

## push_back :: func PackedFloat64Array.push_back(value: float) -> bool
Appends an element at the end of the array.

### value :: float

## remove_at :: func PackedFloat64Array.remove_at(index: int) -> void
Removes an element from the array by index.

### index :: int

## resize :: func PackedFloat64Array.resize(new_size: int) -> int
Sets the size of the array. If the array is grown, reserves elements at the end of the array. If the array is shrunk, truncates the array to the new size. Calling [method resize] once and assigning the new values is faster than adding new elements one by one.
Returns [constant OK] on success, or one of the following [enum Error] constants if this method fails: [constant ERR_INVALID_PARAMETER] if the size is negative, or [constant ERR_OUT_OF_MEMORY] if allocations fail. Use [method size] to find the actual size of the array after resize.

### new_size :: int

## reverse :: func PackedFloat64Array.reverse() -> void
Reverses the order of the elements in the array.

## rfind :: func PackedFloat64Array.rfind(value: float, from: int = -1) -> int
Searches the array in reverse order. Optionally, a start search index can be passed. If negative, the start index is considered relative to the end of the array.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

### value :: float

### from :: int

## set :: func PackedFloat64Array.set(index: int, value: float) -> void
Changes the float at the given index.

### index :: int

### value :: float

## size :: func PackedFloat64Array.size() -> int
Returns the number of elements in the array.

## slice :: func PackedFloat64Array.slice(begin: int, end: int = 2147483647) -> PackedFloat64Array
Returns the slice of the [PackedFloat64Array], from [param begin] (inclusive) to [param end] (exclusive), as a new [PackedFloat64Array].
The absolute value of [param begin] and [param end] will be clamped to the array size, so the default value for [param end] makes it slice to the size of the array by default (i.e. [code]arr.slice(1)[/code] is a shorthand for [code]arr.slice(1, arr.size())[/code]).
If either [param begin] or [param end] are negative, they will be relative to the end of the array (i.e. [code]arr.slice(0, -2)[/code] is a shorthand for [code]arr.slice(0, arr.size() - 2)[/code]).

### begin :: int

### end :: int

## sort :: func PackedFloat64Array.sort() -> void
Sorts the elements of the array in ascending order.
[b]Note:[/b] [constant @GDScript.NAN] doesn't behave the same as other numbers. Therefore, the results from this method may not be accurate if NaNs are included.

## to_byte_array :: func PackedFloat64Array.to_byte_array() -> PackedByteArray
Returns a copy of the data converted to a [PackedByteArray], where each element has been encoded as 8 bytes.
The size of the new array will be [code]float64_array.size() * 8[/code].

## PackedFloat64Array :: func PackedFloat64Array.PackedFloat64Array() -> PackedFloat64Array
Constructs an empty [PackedFloat64Array].

## PackedFloat64Array :: func PackedFloat64Array.PackedFloat64Array(from: PackedFloat64Array) -> PackedFloat64Array
Constructs a [PackedFloat64Array] as a copy of the given [PackedFloat64Array].

### from :: PackedFloat64Array

## PackedFloat64Array :: func PackedFloat64Array.PackedFloat64Array(from: Array) -> PackedFloat64Array
Constructs a new [PackedFloat64Array]. Optionally, you can pass in a generic [Array] that will be converted.

### from :: Array

## operator != :: func PackedFloat64Array.operator !=(right: PackedFloat64Array) -> bool
Returns [code]true[/code] if contents of the arrays differ.

### right :: PackedFloat64Array

## operator + :: func PackedFloat64Array.operator +(right: PackedFloat64Array) -> PackedFloat64Array
Returns a new [PackedFloat64Array] with contents of [param right] added at the end of this array. For better performance, consider using [method append_array] instead.

### right :: PackedFloat64Array

## operator == :: func PackedFloat64Array.operator ==(right: PackedFloat64Array) -> bool
Returns [code]true[/code] if contents of both arrays are the same, i.e. they have all equal doubles at the corresponding indices.

### right :: PackedFloat64Array

## operator [] :: func PackedFloat64Array.operator [](index: int) -> float
Returns the [float] at index [param index]. Negative indices can be used to access the elements starting from the end. Using index out of array's bounds will result in an error.

### index :: int
