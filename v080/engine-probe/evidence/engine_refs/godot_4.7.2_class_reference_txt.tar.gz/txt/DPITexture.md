# DPITexture :: <Native> class DPITexture extends Texture2D
An automatically scalable [Texture2D] based on an SVG image.
An automatically scalable [Texture2D] based on an SVG image. [DPITexture]s are used to automatically re-rasterize icons and other texture based UI theme elements to match viewport scale and font oversampling. See also [member ProjectSettings.display/window/stretch/mode] ("canvas_items" mode) and [member Viewport.oversampling_override].

## base_scale :: var DPITexture.base_scale: float
Texture scale. [code]1.0[/code] is the original SVG size. Higher values result in a larger image.

## color_map :: var DPITexture.color_map: Dictionary
If set, remaps texture colors according to [Color]-[Color] map.

## fix_alpha_border :: var DPITexture.fix_alpha_border: bool
If [code]true[/code], puts pixels of the same surrounding color in transition from transparent to opaque areas. For textures displayed with bilinear filtering, this helps to reduce the outline effect when exporting images from an image editor.

## premult_alpha :: var DPITexture.premult_alpha: bool
An alternative to fixing darkened borders with [member fix_alpha_border] is to use premultiplied alpha. By enabling this option, the texture will be converted to this format. A premultiplied alpha texture requires specific materials to be displayed correctly:
- In 2D, a [CanvasItemMaterial] will need to be created and configured to use the [constant CanvasItemMaterial.BLEND_MODE_PREMULT_ALPHA] blend mode on [CanvasItem]s that use this texture. In custom [code]canvas_item[/code] shaders, [code]render_mode blend_premul_alpha;[/code] should be used.
- In 3D, a [BaseMaterial3D] will need to be created and configured to use the [constant BaseMaterial3D.BLEND_MODE_PREMULT_ALPHA] blend mode on materials that use this texture. In custom [code]spatial[/code] shaders, [code]render_mode blend_premul_alpha;[/code] should be used.

## resource_local_to_scene :: var DPITexture.resource_local_to_scene: bool

## saturation :: var DPITexture.saturation: float
Overrides texture saturation.

## create_from_string :: func DPITexture.create_from_string(source: String, scale: float = 1.0, saturation: float = 1.0, color_map: Dictionary = {}) -> DPITexture
Creates a new [DPITexture] and initializes it by allocating and setting the SVG data to [param source].

### source :: String

### scale :: float

### saturation :: float

### color_map :: Dictionary

## get_scaled_rid :: func DPITexture.get_scaled_rid() -> RID
Returns the [RID] of the texture rasterized to match the oversampling of the currently drawn canvas item.

## get_source :: func DPITexture.get_source() -> String
Returns this SVG texture's source code.

## set_size_override :: func DPITexture.set_size_override(size: Vector2i) -> void
Resizes the texture to the specified dimensions.

### size :: Vector2i

## set_source :: func DPITexture.set_source(source: String) -> void
Sets this SVG texture's source code.

### source :: String
