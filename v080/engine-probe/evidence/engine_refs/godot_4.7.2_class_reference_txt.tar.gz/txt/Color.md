# Color :: <Native> class Color
A color represented in RGBA format.
A color represented in RGBA format by a red ([member r]), green ([member g]), blue ([member b]), and alpha ([member a]) component. Each component is a 32-bit floating-point value, usually ranging from [code]0.0[/code] to [code]1.0[/code]. Some properties (such as [member CanvasItem.modulate]) may support values greater than [code]1.0[/code], for overbright or HDR (High Dynamic Range) colors.
Colors can be created in a number of ways: By the various [Color] constructors, by static methods such as [method from_hsv], and by using a name from the set of standardized colors based on [url=https://en.wikipedia.org/wiki/X11_color_names]X11 color names[/url] with the addition of [constant TRANSPARENT].
[url=https://raw.githubusercontent.com/godotengine/godot-docs/master/img/color_constants.png]Color constants cheatsheet[/url]
Although [Color] may be used to store values of any encoding, the red ([member r]), green ([member g]), and blue ([member b]) properties of [Color] are expected by Godot to be encoded using the [url=https://en.wikipedia.org/wiki/SRGB#Transfer_function_(%22gamma%22)]nonlinear sRGB transfer function[/url] unless otherwise stated. This color encoding is used by many traditional art and web tools, making it easy to match colors between Godot and these tools. Godot uses [url=https://en.wikipedia.org/wiki/Rec._709]Rec. ITU-R BT.709[/url] color primaries, which are used by the sRGB standard.
All physical simulation, such as lighting calculations, and colorimetry transformations, such as [method get_luminance], must be performed on linearly encoded values to produce correct results. When performing these calculations, convert [Color] to and from linear encoding using [method srgb_to_linear] and [method linear_to_srgb].
[b]Note:[/b] In a boolean context, a Color will evaluate to [code]false[/code] if it is equal to [code]Color(0, 0, 0, 1)[/code] (opaque black). Otherwise, a Color will always evaluate to [code]true[/code].
[b]Note:[/b] In C#, color constants are defined in the [code]Colors[/code] static class instead of [code skip-lint]Color[/code]. Additionally, named colors use [code]PascalCase[/code] syntax instead of [code]UPPER_SNAKE_CASE[/code]. For example, [code skip-lint]Color.ALICE_BLUE[/code] in GDScript is [code skip-lint]Colors.AliceBlue[/code] in C#.

## ALICE_BLUE :: const Color.ALICE_BLUE = Color(0.9411765, 0.972549, 1, 1)
Alice blue color.

## ANTIQUE_WHITE :: const Color.ANTIQUE_WHITE = Color(0.98039216, 0.92156863, 0.84313726, 1)
Antique white color.

## AQUA :: const Color.AQUA = Color(0, 1, 1, 1)
Aqua color.

## AQUAMARINE :: const Color.AQUAMARINE = Color(0.49803922, 1, 0.83137256, 1)
Aquamarine color.

## AZURE :: const Color.AZURE = Color(0.9411765, 1, 1, 1)
Azure color.

## BEIGE :: const Color.BEIGE = Color(0.9607843, 0.9607843, 0.8627451, 1)
Beige color.

## BISQUE :: const Color.BISQUE = Color(1, 0.89411765, 0.76862746, 1)
Bisque color.

## BLACK :: const Color.BLACK = Color(0, 0, 0, 1)
Black color. In GDScript, this is the default value of any color.

## BLANCHED_ALMOND :: const Color.BLANCHED_ALMOND = Color(1, 0.92156863, 0.8039216, 1)
Blanched almond color.

## BLUE :: const Color.BLUE = Color(0, 0, 1, 1)
Blue color.

## BLUE_VIOLET :: const Color.BLUE_VIOLET = Color(0.5411765, 0.16862746, 0.8862745, 1)
Blue violet color.

## BROWN :: const Color.BROWN = Color(0.64705884, 0.16470589, 0.16470589, 1)
Brown color.

## BURLYWOOD :: const Color.BURLYWOOD = Color(0.87058824, 0.72156864, 0.5294118, 1)
Burlywood color.

## CADET_BLUE :: const Color.CADET_BLUE = Color(0.37254903, 0.61960787, 0.627451, 1)
Cadet blue color.

## CHARTREUSE :: const Color.CHARTREUSE = Color(0.49803922, 1, 0, 1)
Chartreuse color.

## CHOCOLATE :: const Color.CHOCOLATE = Color(0.8235294, 0.4117647, 0.11764706, 1)
Chocolate color.

## CORAL :: const Color.CORAL = Color(1, 0.49803922, 0.3137255, 1)
Coral color.

## CORNFLOWER_BLUE :: const Color.CORNFLOWER_BLUE = Color(0.39215687, 0.58431375, 0.92941177, 1)
Cornflower blue color.

## CORNSILK :: const Color.CORNSILK = Color(1, 0.972549, 0.8627451, 1)
Cornsilk color.

## CRIMSON :: const Color.CRIMSON = Color(0.8627451, 0.078431375, 0.23529412, 1)
Crimson color.

## CYAN :: const Color.CYAN = Color(0, 1, 1, 1)
Cyan color.

## DARK_BLUE :: const Color.DARK_BLUE = Color(0, 0, 0.54509807, 1)
Dark blue color.

## DARK_CYAN :: const Color.DARK_CYAN = Color(0, 0.54509807, 0.54509807, 1)
Dark cyan color.

## DARK_GOLDENROD :: const Color.DARK_GOLDENROD = Color(0.72156864, 0.5254902, 0.043137256, 1)
Dark goldenrod color.

## DARK_GRAY :: const Color.DARK_GRAY = Color(0.6627451, 0.6627451, 0.6627451, 1)
Dark gray color.

## DARK_GREEN :: const Color.DARK_GREEN = Color(0, 0.39215687, 0, 1)
Dark green color.

## DARK_KHAKI :: const Color.DARK_KHAKI = Color(0.7411765, 0.7176471, 0.41960785, 1)
Dark khaki color.

## DARK_MAGENTA :: const Color.DARK_MAGENTA = Color(0.54509807, 0, 0.54509807, 1)
Dark magenta color.

## DARK_OLIVE_GREEN :: const Color.DARK_OLIVE_GREEN = Color(0.33333334, 0.41960785, 0.18431373, 1)
Dark olive green color.

## DARK_ORANGE :: const Color.DARK_ORANGE = Color(1, 0.54901963, 0, 1)
Dark orange color.

## DARK_ORCHID :: const Color.DARK_ORCHID = Color(0.6, 0.19607843, 0.8, 1)
Dark orchid color.

## DARK_RED :: const Color.DARK_RED = Color(0.54509807, 0, 0, 1)
Dark red color.

## DARK_SALMON :: const Color.DARK_SALMON = Color(0.9137255, 0.5882353, 0.47843137, 1)
Dark salmon color.

## DARK_SEA_GREEN :: const Color.DARK_SEA_GREEN = Color(0.56078434, 0.7372549, 0.56078434, 1)
Dark sea green color.

## DARK_SLATE_BLUE :: const Color.DARK_SLATE_BLUE = Color(0.28235295, 0.23921569, 0.54509807, 1)
Dark slate blue color.

## DARK_SLATE_GRAY :: const Color.DARK_SLATE_GRAY = Color(0.18431373, 0.30980393, 0.30980393, 1)
Dark slate gray color.

## DARK_TURQUOISE :: const Color.DARK_TURQUOISE = Color(0, 0.80784315, 0.81960785, 1)
Dark turquoise color.

## DARK_VIOLET :: const Color.DARK_VIOLET = Color(0.5803922, 0, 0.827451, 1)
Dark violet color.

## DEEP_PINK :: const Color.DEEP_PINK = Color(1, 0.078431375, 0.5764706, 1)
Deep pink color.

## DEEP_SKY_BLUE :: const Color.DEEP_SKY_BLUE = Color(0, 0.7490196, 1, 1)
Deep sky blue color.

## DIM_GRAY :: const Color.DIM_GRAY = Color(0.4117647, 0.4117647, 0.4117647, 1)
Dim gray color.

## DODGER_BLUE :: const Color.DODGER_BLUE = Color(0.11764706, 0.5647059, 1, 1)
Dodger blue color.

## FIREBRICK :: const Color.FIREBRICK = Color(0.69803923, 0.13333334, 0.13333334, 1)
Firebrick color.

## FLORAL_WHITE :: const Color.FLORAL_WHITE = Color(1, 0.98039216, 0.9411765, 1)
Floral white color.

## FOREST_GREEN :: const Color.FOREST_GREEN = Color(0.13333334, 0.54509807, 0.13333334, 1)
Forest green color.

## FUCHSIA :: const Color.FUCHSIA = Color(1, 0, 1, 1)
Fuchsia color.

## GAINSBORO :: const Color.GAINSBORO = Color(0.8627451, 0.8627451, 0.8627451, 1)
Gainsboro color.

## GHOST_WHITE :: const Color.GHOST_WHITE = Color(0.972549, 0.972549, 1, 1)
Ghost white color.

## GOLD :: const Color.GOLD = Color(1, 0.84313726, 0, 1)
Gold color.

## GOLDENROD :: const Color.GOLDENROD = Color(0.85490197, 0.64705884, 0.1254902, 1)
Goldenrod color.

## GRAY :: const Color.GRAY = Color(0.74509805, 0.74509805, 0.74509805, 1)
Gray color.

## GREEN :: const Color.GREEN = Color(0, 1, 0, 1)
Green color.

## GREEN_YELLOW :: const Color.GREEN_YELLOW = Color(0.6784314, 1, 0.18431373, 1)
Green yellow color.

## HONEYDEW :: const Color.HONEYDEW = Color(0.9411765, 1, 0.9411765, 1)
Honeydew color.

## HOT_PINK :: const Color.HOT_PINK = Color(1, 0.4117647, 0.7058824, 1)
Hot pink color.

## INDIAN_RED :: const Color.INDIAN_RED = Color(0.8039216, 0.36078432, 0.36078432, 1)
Indian red color.

## INDIGO :: const Color.INDIGO = Color(0.29411766, 0, 0.50980395, 1)
Indigo color.

## IVORY :: const Color.IVORY = Color(1, 1, 0.9411765, 1)
Ivory color.

## KHAKI :: const Color.KHAKI = Color(0.9411765, 0.9019608, 0.54901963, 1)
Khaki color.

## LAVENDER :: const Color.LAVENDER = Color(0.9019608, 0.9019608, 0.98039216, 1)
Lavender color.

## LAVENDER_BLUSH :: const Color.LAVENDER_BLUSH = Color(1, 0.9411765, 0.9607843, 1)
Lavender blush color.

## LAWN_GREEN :: const Color.LAWN_GREEN = Color(0.4862745, 0.9882353, 0, 1)
Lawn green color.

## LEMON_CHIFFON :: const Color.LEMON_CHIFFON = Color(1, 0.98039216, 0.8039216, 1)
Lemon chiffon color.

## LIGHT_BLUE :: const Color.LIGHT_BLUE = Color(0.6784314, 0.84705883, 0.9019608, 1)
Light blue color.

## LIGHT_CORAL :: const Color.LIGHT_CORAL = Color(0.9411765, 0.5019608, 0.5019608, 1)
Light coral color.

## LIGHT_CYAN :: const Color.LIGHT_CYAN = Color(0.8784314, 1, 1, 1)
Light cyan color.

## LIGHT_GOLDENROD :: const Color.LIGHT_GOLDENROD = Color(0.98039216, 0.98039216, 0.8235294, 1)
Light goldenrod color.

## LIGHT_GRAY :: const Color.LIGHT_GRAY = Color(0.827451, 0.827451, 0.827451, 1)
Light gray color.

## LIGHT_GREEN :: const Color.LIGHT_GREEN = Color(0.5647059, 0.93333334, 0.5647059, 1)
Light green color.

## LIGHT_PINK :: const Color.LIGHT_PINK = Color(1, 0.7137255, 0.75686276, 1)
Light pink color.

## LIGHT_SALMON :: const Color.LIGHT_SALMON = Color(1, 0.627451, 0.47843137, 1)
Light salmon color.

## LIGHT_SEA_GREEN :: const Color.LIGHT_SEA_GREEN = Color(0.1254902, 0.69803923, 0.6666667, 1)
Light sea green color.

## LIGHT_SKY_BLUE :: const Color.LIGHT_SKY_BLUE = Color(0.5294118, 0.80784315, 0.98039216, 1)
Light sky blue color.

## LIGHT_SLATE_GRAY :: const Color.LIGHT_SLATE_GRAY = Color(0.46666667, 0.53333336, 0.6, 1)
Light slate gray color.

## LIGHT_STEEL_BLUE :: const Color.LIGHT_STEEL_BLUE = Color(0.6901961, 0.76862746, 0.87058824, 1)
Light steel blue color.

## LIGHT_YELLOW :: const Color.LIGHT_YELLOW = Color(1, 1, 0.8784314, 1)
Light yellow color.

## LIME :: const Color.LIME = Color(0, 1, 0, 1)
Lime color.

## LIME_GREEN :: const Color.LIME_GREEN = Color(0.19607843, 0.8039216, 0.19607843, 1)
Lime green color.

## LINEN :: const Color.LINEN = Color(0.98039216, 0.9411765, 0.9019608, 1)
Linen color.

## MAGENTA :: const Color.MAGENTA = Color(1, 0, 1, 1)
Magenta color.

## MAROON :: const Color.MAROON = Color(0.6901961, 0.1882353, 0.3764706, 1)
Maroon color.

## MEDIUM_AQUAMARINE :: const Color.MEDIUM_AQUAMARINE = Color(0.4, 0.8039216, 0.6666667, 1)
Medium aquamarine color.

## MEDIUM_BLUE :: const Color.MEDIUM_BLUE = Color(0, 0, 0.8039216, 1)
Medium blue color.

## MEDIUM_ORCHID :: const Color.MEDIUM_ORCHID = Color(0.7294118, 0.33333334, 0.827451, 1)
Medium orchid color.

## MEDIUM_PURPLE :: const Color.MEDIUM_PURPLE = Color(0.5764706, 0.4392157, 0.85882354, 1)
Medium purple color.

## MEDIUM_SEA_GREEN :: const Color.MEDIUM_SEA_GREEN = Color(0.23529412, 0.7019608, 0.44313726, 1)
Medium sea green color.

## MEDIUM_SLATE_BLUE :: const Color.MEDIUM_SLATE_BLUE = Color(0.48235294, 0.40784314, 0.93333334, 1)
Medium slate blue color.

## MEDIUM_SPRING_GREEN :: const Color.MEDIUM_SPRING_GREEN = Color(0, 0.98039216, 0.6039216, 1)
Medium spring green color.

## MEDIUM_TURQUOISE :: const Color.MEDIUM_TURQUOISE = Color(0.28235295, 0.81960785, 0.8, 1)
Medium turquoise color.

## MEDIUM_VIOLET_RED :: const Color.MEDIUM_VIOLET_RED = Color(0.78039217, 0.08235294, 0.52156866, 1)
Medium violet red color.

## MIDNIGHT_BLUE :: const Color.MIDNIGHT_BLUE = Color(0.09803922, 0.09803922, 0.4392157, 1)
Midnight blue color.

## MINT_CREAM :: const Color.MINT_CREAM = Color(0.9607843, 1, 0.98039216, 1)
Mint cream color.

## MISTY_ROSE :: const Color.MISTY_ROSE = Color(1, 0.89411765, 0.88235295, 1)
Misty rose color.

## MOCCASIN :: const Color.MOCCASIN = Color(1, 0.89411765, 0.70980394, 1)
Moccasin color.

## NAVAJO_WHITE :: const Color.NAVAJO_WHITE = Color(1, 0.87058824, 0.6784314, 1)
Navajo white color.

## NAVY_BLUE :: const Color.NAVY_BLUE = Color(0, 0, 0.5019608, 1)
Navy blue color.

## OLD_LACE :: const Color.OLD_LACE = Color(0.99215686, 0.9607843, 0.9019608, 1)
Old lace color.

## OLIVE :: const Color.OLIVE = Color(0.5019608, 0.5019608, 0, 1)
Olive color.

## OLIVE_DRAB :: const Color.OLIVE_DRAB = Color(0.41960785, 0.5568628, 0.13725491, 1)
Olive drab color.

## ORANGE :: const Color.ORANGE = Color(1, 0.64705884, 0, 1)
Orange color.

## ORANGE_RED :: const Color.ORANGE_RED = Color(1, 0.27058825, 0, 1)
Orange red color.

## ORCHID :: const Color.ORCHID = Color(0.85490197, 0.4392157, 0.8392157, 1)
Orchid color.

## PALE_GOLDENROD :: const Color.PALE_GOLDENROD = Color(0.93333334, 0.9098039, 0.6666667, 1)
Pale goldenrod color.

## PALE_GREEN :: const Color.PALE_GREEN = Color(0.59607846, 0.9843137, 0.59607846, 1)
Pale green color.

## PALE_TURQUOISE :: const Color.PALE_TURQUOISE = Color(0.6862745, 0.93333334, 0.93333334, 1)
Pale turquoise color.

## PALE_VIOLET_RED :: const Color.PALE_VIOLET_RED = Color(0.85882354, 0.4392157, 0.5764706, 1)
Pale violet red color.

## PAPAYA_WHIP :: const Color.PAPAYA_WHIP = Color(1, 0.9372549, 0.8352941, 1)
Papaya whip color.

## PEACH_PUFF :: const Color.PEACH_PUFF = Color(1, 0.85490197, 0.7254902, 1)
Peach puff color.

## PERU :: const Color.PERU = Color(0.8039216, 0.52156866, 0.24705882, 1)
Peru color.

## PINK :: const Color.PINK = Color(1, 0.7529412, 0.79607844, 1)
Pink color.

## PLUM :: const Color.PLUM = Color(0.8666667, 0.627451, 0.8666667, 1)
Plum color.

## POWDER_BLUE :: const Color.POWDER_BLUE = Color(0.6901961, 0.8784314, 0.9019608, 1)
Powder blue color.

## PURPLE :: const Color.PURPLE = Color(0.627451, 0.1254902, 0.9411765, 1)
Purple color.

## REBECCA_PURPLE :: const Color.REBECCA_PURPLE = Color(0.4, 0.2, 0.6, 1)
Rebecca purple color.

## RED :: const Color.RED = Color(1, 0, 0, 1)
Red color.

## ROSY_BROWN :: const Color.ROSY_BROWN = Color(0.7372549, 0.56078434, 0.56078434, 1)
Rosy brown color.

## ROYAL_BLUE :: const Color.ROYAL_BLUE = Color(0.25490198, 0.4117647, 0.88235295, 1)
Royal blue color.

## SADDLE_BROWN :: const Color.SADDLE_BROWN = Color(0.54509807, 0.27058825, 0.07450981, 1)
Saddle brown color.

## SALMON :: const Color.SALMON = Color(0.98039216, 0.5019608, 0.44705883, 1)
Salmon color.

## SANDY_BROWN :: const Color.SANDY_BROWN = Color(0.95686275, 0.6431373, 0.3764706, 1)
Sandy brown color.

## SEA_GREEN :: const Color.SEA_GREEN = Color(0.18039216, 0.54509807, 0.34117648, 1)
Sea green color.

## SEASHELL :: const Color.SEASHELL = Color(1, 0.9607843, 0.93333334, 1)
Seashell color.

## SIENNA :: const Color.SIENNA = Color(0.627451, 0.32156864, 0.1764706, 1)
Sienna color.

## SILVER :: const Color.SILVER = Color(0.7529412, 0.7529412, 0.7529412, 1)
Silver color.

## SKY_BLUE :: const Color.SKY_BLUE = Color(0.5294118, 0.80784315, 0.92156863, 1)
Sky blue color.

## SLATE_BLUE :: const Color.SLATE_BLUE = Color(0.41568628, 0.3529412, 0.8039216, 1)
Slate blue color.

## SLATE_GRAY :: const Color.SLATE_GRAY = Color(0.4392157, 0.5019608, 0.5647059, 1)
Slate gray color.

## SNOW :: const Color.SNOW = Color(1, 0.98039216, 0.98039216, 1)
Snow color.

## SPRING_GREEN :: const Color.SPRING_GREEN = Color(0, 1, 0.49803922, 1)
Spring green color.

## STEEL_BLUE :: const Color.STEEL_BLUE = Color(0.27450982, 0.50980395, 0.7058824, 1)
Steel blue color.

## TAN :: const Color.TAN = Color(0.8235294, 0.7058824, 0.54901963, 1)
Tan color.

## TEAL :: const Color.TEAL = Color(0, 0.5019608, 0.5019608, 1)
Teal color.

## THISTLE :: const Color.THISTLE = Color(0.84705883, 0.7490196, 0.84705883, 1)
Thistle color.

## TOMATO :: const Color.TOMATO = Color(1, 0.3882353, 0.2784314, 1)
Tomato color.

## TRANSPARENT :: const Color.TRANSPARENT = Color(1, 1, 1, 0)
Transparent color (white with zero alpha).

## TURQUOISE :: const Color.TURQUOISE = Color(0.2509804, 0.8784314, 0.8156863, 1)
Turquoise color.

## VIOLET :: const Color.VIOLET = Color(0.93333334, 0.50980395, 0.93333334, 1)
Violet color.

## WEB_GRAY :: const Color.WEB_GRAY = Color(0.5019608, 0.5019608, 0.5019608, 1)
Web gray color.

## WEB_GREEN :: const Color.WEB_GREEN = Color(0, 0.5019608, 0, 1)
Web green color.

## WEB_MAROON :: const Color.WEB_MAROON = Color(0.5019608, 0, 0, 1)
Web maroon color.

## WEB_PURPLE :: const Color.WEB_PURPLE = Color(0.5019608, 0, 0.5019608, 1)
Web purple color.

## WHEAT :: const Color.WHEAT = Color(0.9607843, 0.87058824, 0.7019608, 1)
Wheat color.

## WHITE :: const Color.WHITE = Color(1, 1, 1, 1)
White color.

## WHITE_SMOKE :: const Color.WHITE_SMOKE = Color(0.9607843, 0.9607843, 0.9607843, 1)
White smoke color.

## YELLOW :: const Color.YELLOW = Color(1, 1, 0, 1)
Yellow color.

## YELLOW_GREEN :: const Color.YELLOW_GREEN = Color(0.6039216, 0.8039216, 0.19607843, 1)
Yellow green color.

## a :: var Color.a: float
The color's alpha component, typically on the range of 0 to 1. A value of 0 means that the color is fully transparent. A value of 1 means that the color is fully opaque.
[b]Note:[/b] The alpha channel is always stored with linear encoding, regardless of the encoding of the other color channels. The [method linear_to_srgb] and [method srgb_to_linear] methods do not affect the alpha channel.

## a8 :: var Color.a8: int
Wrapper for [member a] that uses the range 0 to 255, instead of 0 to 1.

## b :: var Color.b: float
The color's blue component, typically on the range of 0 to 1.

## b8 :: var Color.b8: int
Wrapper for [member b] that uses the range 0 to 255, instead of 0 to 1.

## g :: var Color.g: float
The color's green component, typically on the range of 0 to 1.

## g8 :: var Color.g8: int
Wrapper for [member g] that uses the range 0 to 255, instead of 0 to 1.

## h :: var Color.h: float
The HSV hue of this color, on the range 0 to 1.

## ok_hsl_h :: var Color.ok_hsl_h: float
The OKHSL hue of this color, on the range 0 to 1.

## ok_hsl_l :: var Color.ok_hsl_l: float
The OKHSL lightness of this color, on the range 0 to 1.

## ok_hsl_s :: var Color.ok_hsl_s: float
The OKHSL saturation of this color, on the range 0 to 1.

## r :: var Color.r: float
The color's red component, typically on the range of 0 to 1.

## r8 :: var Color.r8: int
Wrapper for [member r] that uses the range 0 to 255, instead of 0 to 1.

## s :: var Color.s: float
The HSV saturation of this color, on the range 0 to 1.

## v :: var Color.v: float
The HSV value (brightness) of this color, on the range 0 to 1.

## blend :: func Color.blend(over: Color) -> Color
Returns a new color resulting from overlaying this color over the given color. In a painting program, you can imagine it as the [param over] color painted over this color (including alpha).
[codeblocks]
[gdscript]
var bg = Color(0.0, 1.0, 0.0, 0.5) # Green with alpha of 50%
var fg = Color(1.0, 0.0, 0.0, 0.5) # Red with alpha of 50%
var blended_color = bg.blend(fg) # Brown with alpha of 75%
[/gdscript]
[csharp]
var bg = new Color(0.0f, 1.0f, 0.0f, 0.5f); // Green with alpha of 50%
var fg = new Color(1.0f, 0.0f, 0.0f, 0.5f); // Red with alpha of 50%
Color blendedColor = bg.Blend(fg); // Brown with alpha of 75%
[/csharp]
[/codeblocks]

### over :: Color

## clamp :: func Color.clamp(min: Color = Color(0, 0, 0, 0), max: Color = Color(1, 1, 1, 1)) -> Color
Returns a new color with all components clamped between the components of [param min] and [param max], by running [method @GlobalScope.clamp] on each component.

### min :: Color

### max :: Color

## darkened :: func Color.darkened(amount: float) -> Color
Returns a new color resulting from making this color darker by the specified [param amount] (ratio from 0.0 to 1.0). See also [method lightened].
[codeblocks]
[gdscript]
var green = Color(0.0, 1.0, 0.0)
var darkgreen = green.darkened(0.2) # 20% darker than regular green
[/gdscript]
[csharp]
var green = new Color(0.0f, 1.0f, 0.0f);
Color darkgreen = green.Darkened(0.2f); // 20% darker than regular green
[/csharp]
[/codeblocks]

### amount :: float

## from_hsv :: func Color.from_hsv(h: float, s: float, v: float, alpha: float = 1.0) -> Color
Constructs a color from an [url=https://en.wikipedia.org/wiki/HSL_and_HSV]HSV profile[/url]. The hue ([param h]), saturation ([param s]), and value ([param v]) are typically between 0.0 and 1.0.
[codeblocks]
[gdscript]
var color = Color.from_hsv(0.58, 0.5, 0.79, 0.8)
[/gdscript]
[csharp]
var color = Color.FromHsv(0.58f, 0.5f, 0.79f, 0.8f);
[/csharp]
[/codeblocks]

### h :: float

### s :: float

### v :: float

### alpha :: float

## from_ok_hsl :: func Color.from_ok_hsl(h: float, s: float, l: float, alpha: float = 1.0) -> Color
Constructs a color from an [url=https://bottosson.github.io/posts/colorpicker/]OK HSL profile[/url]. The hue ([param h]), saturation ([param s]), and lightness ([param l]) are typically between 0.0 and 1.0.
[codeblocks]
[gdscript]
var color = Color.from_ok_hsl(0.58, 0.5, 0.79, 0.8)
[/gdscript]
[csharp]
var color = Color.FromOkHsl(0.58f, 0.5f, 0.79f, 0.8f);
[/csharp]
[/codeblocks]

### h :: float

### s :: float

### l :: float

### alpha :: float

## from_rgba8 :: func Color.from_rgba8(r8: int, g8: int, b8: int, a8: int = 255) -> Color
Returns a [Color] constructed from red ([param r8]), green ([param g8]), blue ([param b8]), and optionally alpha ([param a8]) integer channels, each divided by [code]255.0[/code] for their final value.
[codeblock]
var red = Color.from_rgba8(255, 0, 0)             # Same as Color(1, 0, 0).
var dark_blue = Color.from_rgba8(0, 0, 51)        # Same as Color(0, 0, 0.2).
var my_color = Color.from_rgba8(306, 255, 0, 102) # Same as Color(1.2, 1, 0, 0.4).
[/codeblock]
[b]Note:[/b] Due to the lower precision of [method from_rgba8] compared to the standard [Color] constructor, a color created with [method from_rgba8] will generally not be equal to the same color created with the standard [Color] constructor. Use [method is_equal_approx] for comparisons to avoid issues with floating-point precision error.

### r8 :: int

### g8 :: int

### b8 :: int

### a8 :: int

## from_rgbe9995 :: func Color.from_rgbe9995(rgbe: int) -> Color
Decodes a [Color] from an RGBE9995 format integer. See [constant Image.FORMAT_RGBE9995].

### rgbe :: int

## from_string :: func Color.from_string(str: String, default: Color) -> Color
Creates a [Color] from the given string, which can be either an HTML color code or a named color (case-insensitive). Returns [param default] if the color cannot be inferred from the string.
If you want to create a color from String in a constant expression, use the equivalent constructor instead (i.e. [code]Color("color string")[/code]).

### str :: String

### default :: Color

## get_luminance :: func Color.get_luminance() -> float
Returns the light intensity of the color, as a value between 0.0 and 1.0 (inclusive). This is useful when determining light or dark color. Colors with a luminance smaller than 0.5 can be generally considered dark.
[b]Note:[/b] [method get_luminance] relies on the color using linear encoding to return an accurate relative luminance value. If the color uses the default nonlinear sRGB encoding, use [method srgb_to_linear] to convert it to linear encoding first.

## hex :: func Color.hex(hex: int) -> Color
Returns the [Color] associated with the provided [param hex] integer in 32-bit RGBA format (8 bits per channel). This method is the inverse of [method to_rgba32].
In GDScript and C#, the [int] is best visualized with hexadecimal notation ([code]"0x"[/code] prefix, making it [code]"0xRRGGBBAA"[/code]).
[codeblocks]
[gdscript]
var red = Color.hex(0xff0000ff)
var dark_cyan = Color.hex(0x008b8bff)
var my_color = Color.hex(0xbbefd2a4)
[/gdscript]
[csharp]
var red = new Color(0xff0000ff);
var dark_cyan = new Color(0x008b8bff);
var my_color = new Color(0xbbefd2a4);
[/csharp]
[/codeblocks]
If you want to use hex notation in a constant expression, use the equivalent constructor instead (i.e. [code]Color(0xRRGGBBAA)[/code]).

### hex :: int

## hex64 :: func Color.hex64(hex: int) -> Color
Returns the [Color] associated with the provided [param hex] integer in 64-bit RGBA format (16 bits per channel). This method is the inverse of [method to_rgba64].
In GDScript and C#, the [int] is best visualized with hexadecimal notation ([code]"0x"[/code] prefix, making it [code]"0xRRRRGGGGBBBBAAAA"[/code]).

### hex :: int

## html :: func Color.html(rgba: String) -> Color
Returns a new color from [param rgba], an HTML hexadecimal color string. [param rgba] is not case-sensitive, and may be prefixed by a hash sign ([code]#[/code]).
[param rgba] must be a valid three-digit or six-digit hexadecimal color string, and may contain an alpha channel value. If [param rgba] does not contain an alpha channel value, an alpha channel value of 1.0 is applied. If [param rgba] is invalid, returns an empty color.
[codeblocks]
[gdscript]
var blue = Color.html("#0000ff") # blue is Color(0.0, 0.0, 1.0, 1.0)
var green = Color.html("#0F0")   # green is Color(0.0, 1.0, 0.0, 1.0)
var col = Color.html("663399cc") # col is Color(0.4, 0.2, 0.6, 0.8)
[/gdscript]
[csharp]
var blue = Color.FromHtml("#0000ff"); // blue is Color(0.0, 0.0, 1.0, 1.0)
var green = Color.FromHtml("#0F0");   // green is Color(0.0, 1.0, 0.0, 1.0)
var col = Color.FromHtml("663399cc"); // col is Color(0.4, 0.2, 0.6, 0.8)
[/csharp]
[/codeblocks]

### rgba :: String

## html_is_valid :: func Color.html_is_valid(color: String) -> bool
Returns [code]true[/code] if [param color] is a valid HTML hexadecimal color string. The string must be a hexadecimal value (case-insensitive) of either 3, 4, 6 or 8 digits, and may be prefixed by a hash sign ([code]#[/code]). This method is identical to [method String.is_valid_html_color].
[codeblocks]
[gdscript]
Color.html_is_valid("#55aaFF")   # Returns true
Color.html_is_valid("#55AAFF20") # Returns true
Color.html_is_valid("55AAFF")    # Returns true
Color.html_is_valid("#F2C")      # Returns true

Color.html_is_valid("#AABBC")    # Returns false
Color.html_is_valid("#55aaFF5")  # Returns false
[/gdscript]
[csharp]
Color.HtmlIsValid("#55AAFF");   // Returns true
Color.HtmlIsValid("#55AAFF20"); // Returns true
Color.HtmlIsValid("55AAFF");    // Returns true
Color.HtmlIsValid("#F2C");      // Returns true

Color.HtmlIsValid("#AABBC");    // Returns false
Color.HtmlIsValid("#55aaFF5");  // Returns false
[/csharp]
[/codeblocks]

### color :: String

## inverted :: func Color.inverted() -> Color
Returns the color with its [member r], [member g], and [member b] components inverted ([code](1 - r, 1 - g, 1 - b, a)[/code]).
[codeblocks]
[gdscript]
var black = Color.WHITE.inverted()
var color = Color(0.3, 0.4, 0.9)
var inverted_color = color.inverted() # Equivalent to `Color(0.7, 0.6, 0.1)`
[/gdscript]
[csharp]
var black = Colors.White.Inverted();
var color = new Color(0.3f, 0.4f, 0.9f);
Color invertedColor = color.Inverted(); // Equivalent to `new Color(0.7f, 0.6f, 0.1f)`
[/csharp]
[/codeblocks]

## is_equal_approx :: func Color.is_equal_approx(to: Color) -> bool
Returns [code]true[/code] if this color and [param to] are approximately equal, by running [method @GlobalScope.is_equal_approx] on each component.

### to :: Color

## lerp :: func Color.lerp(to: Color, weight: float) -> Color
Returns the linear interpolation between this color's components and [param to]'s components. The interpolation factor [param weight] should be between 0.0 and 1.0 (inclusive). See also [method @GlobalScope.lerp].
[codeblocks]
[gdscript]
var red = Color(1.0, 0.0, 0.0)
var aqua = Color(0.0, 1.0, 0.8)

red.lerp(aqua, 0.2) # Returns Color(0.8, 0.2, 0.16)
red.lerp(aqua, 0.5) # Returns Color(0.5, 0.5, 0.4)
red.lerp(aqua, 1.0) # Returns Color(0.0, 1.0, 0.8)
[/gdscript]
[csharp]
var red = new Color(1.0f, 0.0f, 0.0f);
var aqua = new Color(0.0f, 1.0f, 0.8f);

red.Lerp(aqua, 0.2f); // Returns Color(0.8f, 0.2f, 0.16f)
red.Lerp(aqua, 0.5f); // Returns Color(0.5f, 0.5f, 0.4f)
red.Lerp(aqua, 1.0f); // Returns Color(0.0f, 1.0f, 0.8f)
[/csharp]
[/codeblocks]

### to :: Color

### weight :: float

## lightened :: func Color.lightened(amount: float) -> Color
Returns a new color resulting from making this color lighter by the specified [param amount], which should be a ratio from 0.0 to 1.0. See also [method darkened].
[codeblocks]
[gdscript]
var green = Color(0.0, 1.0, 0.0)
var light_green = green.lightened(0.2) # 20% lighter than regular green
[/gdscript]
[csharp]
var green = new Color(0.0f, 1.0f, 0.0f);
Color lightGreen = green.Lightened(0.2f); // 20% lighter than regular green
[/csharp]
[/codeblocks]

### amount :: float

## linear_to_srgb :: func Color.linear_to_srgb() -> Color
Returns a copy of the color that is encoded using the [url=https://en.wikipedia.org/wiki/SRGB]nonlinear sRGB transfer function[/url]. This method requires the original color to use linear encoding. See also [method srgb_to_linear] which performs the opposite operation.
[b]Note:[/b] The color's alpha channel ([member a]) is not affected. The alpha channel is always stored with linear encoding, regardless of the color space of the other color channels.

## srgb_to_linear :: func Color.srgb_to_linear() -> Color
Returns a copy of the color that uses linear encoding. This method requires the original color to be encoded using the [url=https://en.wikipedia.org/wiki/SRGB]nonlinear sRGB transfer function[/url]. See also [method linear_to_srgb] which performs the opposite operation.
[b]Note:[/b] The color's alpha channel ([member a]) is not affected. The alpha channel is always stored with linear encoding, regardless of the color space of the other color channels.

## to_abgr32 :: func Color.to_abgr32() -> int
Returns the color converted to a 32-bit integer in ABGR format (each component is 8 bits). ABGR is the reversed version of the default RGBA format.
[codeblocks]
[gdscript]
var color = Color(1, 0.5, 0.2)
print(color.to_abgr32()) # Prints 4281565439
[/gdscript]
[csharp]
var color = new Color(1.0f, 0.5f, 0.2f);
GD.Print(color.ToAbgr32()); // Prints 4281565439
[/csharp]
[/codeblocks]

## to_abgr64 :: func Color.to_abgr64() -> int
Returns the color converted to a 64-bit integer in ABGR format (each component is 16 bits). ABGR is the reversed version of the default RGBA format.
[codeblocks]
[gdscript]
var color = Color(1, 0.5, 0.2)
print(color.to_abgr64()) # Prints -225178692812801
[/gdscript]
[csharp]
var color = new Color(1.0f, 0.5f, 0.2f);
GD.Print(color.ToAbgr64()); // Prints -225178692812801
[/csharp]
[/codeblocks]

## to_argb32 :: func Color.to_argb32() -> int
Returns the color converted to a 32-bit integer in ARGB format (each component is 8 bits). ARGB is more compatible with DirectX.
[codeblocks]
[gdscript]
var color = Color(1, 0.5, 0.2)
print(color.to_argb32()) # Prints 4294934323
[/gdscript]
[csharp]
var color = new Color(1.0f, 0.5f, 0.2f);
GD.Print(color.ToArgb32()); // Prints 4294934323
[/csharp]
[/codeblocks]

## to_argb64 :: func Color.to_argb64() -> int
Returns the color converted to a 64-bit integer in ARGB format (each component is 16 bits). ARGB is more compatible with DirectX.
[codeblocks]
[gdscript]
var color = Color(1, 0.5, 0.2)
print(color.to_argb64()) # Prints -2147470541
[/gdscript]
[csharp]
var color = new Color(1.0f, 0.5f, 0.2f);
GD.Print(color.ToArgb64()); // Prints -2147470541
[/csharp]
[/codeblocks]

## to_html :: func Color.to_html(with_alpha: bool = true) -> String
Returns the color converted to an HTML hexadecimal color [String] in RGBA format, without the hash ([code]#[/code]) prefix.
Setting [param with_alpha] to [code]false[/code], excludes alpha from the hexadecimal string, using RGB format instead of RGBA format.
[codeblocks]
[gdscript]
var white = Color(1, 1, 1, 0.5)
var with_alpha = white.to_html() # Returns "ffffff7f"
var without_alpha = white.to_html(false) # Returns "ffffff"
[/gdscript]
[csharp]
var white = new Color(1, 1, 1, 0.5f);
string withAlpha = white.ToHtml(); // Returns "ffffff7f"
string withoutAlpha = white.ToHtml(false); // Returns "ffffff"
[/csharp]
[/codeblocks]

### with_alpha :: bool

## to_rgba32 :: func Color.to_rgba32() -> int
Returns the color converted to a 32-bit integer in RGBA format (each component is 8 bits). RGBA is Godot's default format. This method is the inverse of [method hex].
[codeblocks]
[gdscript]
var color = Color(1, 0.5, 0.2)
print(color.to_rgba32()) # Prints 4286526463
[/gdscript]
[csharp]
var color = new Color(1, 0.5f, 0.2f);
GD.Print(color.ToRgba32()); // Prints 4286526463
[/csharp]
[/codeblocks]

## to_rgba64 :: func Color.to_rgba64() -> int
Returns the color converted to a 64-bit integer in RGBA format (each component is 16 bits). RGBA is Godot's default format. This method is the inverse of [method hex64].
[codeblocks]
[gdscript]
var color = Color(1, 0.5, 0.2)
print(color.to_rgba64()) # Prints -140736629309441
[/gdscript]
[csharp]
var color = new Color(1, 0.5f, 0.2f);
GD.Print(color.ToRgba64()); // Prints -140736629309441
[/csharp]
[/codeblocks]

## Color :: func Color.Color() -> Color
Constructs a default [Color] from opaque black. This is the same as [constant BLACK].
[b]Note:[/b] In C#, this constructs a [Color] with all of its components set to [code]0.0[/code] (transparent black).

## Color :: func Color.Color(from: Color, alpha: float) -> Color
Constructs a [Color] from the existing color, with [member a] set to the given [param alpha] value.
[codeblocks]
[gdscript]
var red = Color(Color.RED, 0.2) # 20% opaque red.
[/gdscript]
[csharp]
var red = new Color(Colors.Red, 0.2f); // 20% opaque red.
[/csharp]
[/codeblocks]

### from :: Color

### alpha :: float

## Color :: func Color.Color(from: Color) -> Color
Constructs a [Color] as a copy of the given [Color].

### from :: Color

## Color :: func Color.Color(code: String) -> Color
Constructs a [Color] either from an HTML color code or from a standardized color name. The supported color names are the same as the constants.

### code :: String

## Color :: func Color.Color(code: String, alpha: float) -> Color
Constructs a [Color] either from an HTML color code or from a standardized color name, with [param alpha] on the range of 0.0 to 1.0. The supported color names are the same as the constants.

### code :: String

### alpha :: float

## Color :: func Color.Color(r: float, g: float, b: float) -> Color
Constructs a [Color] from RGB values, typically between 0.0 and 1.0. [member a] is set to 1.0.
[codeblocks]
[gdscript]
var color = Color(0.2, 1.0, 0.7) # Similar to `Color.from_rgba8(51, 255, 178, 255)`
[/gdscript]
[csharp]
var color = new Color(0.2f, 1.0f, 0.7f); // Similar to `Color.Color8(51, 255, 178, 255)`
[/csharp]
[/codeblocks]

### r :: float

### g :: float

### b :: float

## Color :: func Color.Color(r: float, g: float, b: float, a: float) -> Color
Constructs a [Color] from RGBA values, typically between 0.0 and 1.0.
[codeblocks]
[gdscript]
var color = Color(0.2, 1.0, 0.7, 0.8) # Similar to `Color.from_rgba8(51, 255, 178, 204)`
[/gdscript]
[csharp]
var color = new Color(0.2f, 1.0f, 0.7f, 0.8f); // Similar to `Color.Color8(51, 255, 178, 255, 204)`
[/csharp]
[/codeblocks]

### r :: float

### g :: float

### b :: float

### a :: float

## operator != :: func Color.operator !=(right: Color) -> bool
Returns [code]true[/code] if the colors are not exactly equal.
[b]Note:[/b] Due to floating-point precision errors, consider using [method is_equal_approx] instead, which is more reliable.

### right :: Color

## operator * :: func Color.operator *(right: Color) -> Color
Multiplies each component of the [Color] by the components of the given [Color].

### right :: Color

## operator * :: func Color.operator *(right: float) -> Color
Multiplies each component of the [Color] by the given [float].

### right :: float

## operator * :: func Color.operator *(right: int) -> Color
Multiplies each component of the [Color] by the given [int].

### right :: int

## operator + :: func Color.operator +(right: Color) -> Color
Adds each component of the [Color] with the components of the given [Color].

### right :: Color

## operator - :: func Color.operator -(right: Color) -> Color
Subtracts each component of the [Color] by the components of the given [Color].

### right :: Color

## operator / :: func Color.operator /(right: Color) -> Color
Divides each component of the [Color] by the components of the given [Color].

### right :: Color

## operator / :: func Color.operator /(right: float) -> Color
Divides each component of the [Color] by the given [float].

### right :: float

## operator / :: func Color.operator /(right: int) -> Color
Divides each component of the [Color] by the given [int].

### right :: int

## operator == :: func Color.operator ==(right: Color) -> bool
Returns [code]true[/code] if the colors are exactly equal.
[b]Note:[/b] Due to floating-point precision errors, consider using [method is_equal_approx] instead, which is more reliable.

### right :: Color

## operator [] :: func Color.operator [](index: int) -> float
Access color components using their index. [code][0][/code] is equivalent to [member r], [code][1][/code] is equivalent to [member g], [code][2][/code] is equivalent to [member b], and [code][3][/code] is equivalent to [member a].

### index :: int

## operator unary+ :: func Color.operator unary+() -> Color
Returns the same value as if the [code]+[/code] was not there. Unary [code]+[/code] does nothing, but sometimes it can make your code more readable.

## operator unary- :: func Color.operator unary-() -> Color
Inverts the given color. This is equivalent to [code]Color.WHITE - c[/code] or [code]Color(1 - c.r, 1 - c.g, 1 - c.b, 1 - c.a)[/code]. Unlike with [method inverted], the [member a] component is inverted, too.
