# AudioEffectFilter :: <Native> class AudioEffectFilter extends AudioEffect
Base class for filters. Use effects that inherit this class instead of using it directly.
A "filter" controls the gain of frequencies, using [member cutoff_hz] as a frequency threshold. Filters can help to give room for each sound, and create interesting effects.
There are different types of filter that inherit this class:
Shelf filters: [AudioEffectLowShelfFilter] and [AudioEffectHighShelfFilter]
Band-pass and notch filters: [AudioEffectBandPassFilter], [AudioEffectBandLimitFilter], and [AudioEffectNotchFilter]
Low/high-pass filters: [AudioEffectLowPassFilter] and [AudioEffectHighPassFilter]

## FILTER_6DB :: const AudioEffectFilter.FILTER_6DB: FilterDB = 0
Cutting off at 6 dB per octave. One octave is twice the frequency above [member cutoff_hz], or half the frequency below [member cutoff_hz].

## FILTER_12DB :: const AudioEffectFilter.FILTER_12DB: FilterDB = 1
Cutting off at 12 dB per octave. One octave is twice the frequency above [member cutoff_hz], or half the frequency below [member cutoff_hz].

## FILTER_18DB :: const AudioEffectFilter.FILTER_18DB: FilterDB = 2
Cutting off at 18 dB per octave. One octave is twice the frequency above [member cutoff_hz], or half the frequency below [member cutoff_hz].

## FILTER_24DB :: const AudioEffectFilter.FILTER_24DB: FilterDB = 3
Cutting off at 24 dB per octave. One octave is twice the frequency above [member cutoff_hz], or half the frequency below [member cutoff_hz].

## cutoff_hz :: var AudioEffectFilter.cutoff_hz: float
Frequency threshold for the filter, in Hz. Value can range from 1 to 20500.

## db :: var AudioEffectFilter.db: AudioEffectFilter.FilterDB
Steepness of the cutoff curve in dB per octave (twice the frequency above [member cutoff_hz], or half the frequency below [member cutoff_hz]), also known as the "order" of the filter. Higher orders have a more aggressive cutoff.

## gain :: var AudioEffectFilter.gain: float
Gain of the frequencies affected by the filter. This property is only available for [AudioEffectLowShelfFilter] and [AudioEffectHighShelfFilter]. Value can range from 0 to 4.

## resonance :: var AudioEffectFilter.resonance: float
Gain at or directly next to the [member cutoff_hz] frequency threshold. Value can range from 0 to 1.
Its exact behavior depends on the selected filter type:
- For shelf filters, it accentuates or masks the order by increasing frequencies right next to the [member cutoff_hz] frequency and decreasing frequencies on the opposite side.
- For the band-pass and notch filters, it widens or narrows the filter at the [member cutoff_hz] frequency threshold.
- For low/high-pass filters, it increases or decreases frequencies at the [member cutoff_hz] frequency threshold.
