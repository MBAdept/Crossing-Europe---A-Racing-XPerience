# VisualShaderNodeBooleanParameter :: <Native> class VisualShaderNodeBooleanParameter extends VisualShaderNodeParameter
A boolean parameter to be used within the visual shader graph.
Translated to [code]uniform bool[/code] in the shader language.

## default_value :: var VisualShaderNodeBooleanParameter.default_value: bool
A default value to be assigned within the shader.

## default_value_enabled :: var VisualShaderNodeBooleanParameter.default_value_enabled: bool
Enables usage of the [member default_value].
