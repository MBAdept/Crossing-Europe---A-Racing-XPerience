# TranslationDomain :: <Native> class TranslationDomain extends RefCounted
A self-contained collection of [Translation] resources.
[TranslationDomain] is a self-contained collection of [Translation] resources. Translations can be added to or removed from it.
If you're working with the main translation domain, it is more convenient to use the wrap methods on [TranslationServer].

## enabled :: var TranslationDomain.enabled: bool
If [code]true[/code], translation is enabled. Otherwise, [method translate] and [method translate_plural] will return the input message unchanged regardless of the current locale.

## pseudolocalization_accents_enabled :: var TranslationDomain.pseudolocalization_accents_enabled: bool
Replace all characters with their accented variants during pseudolocalization.
[b]Note:[/b] Updating this property does not automatically update texts in the scene tree. Please propagate the [constant MainLoop.NOTIFICATION_TRANSLATION_CHANGED] notification manually after you have finished modifying pseudolocalization related options.

## pseudolocalization_double_vowels_enabled :: var TranslationDomain.pseudolocalization_double_vowels_enabled: bool
Double vowels in strings during pseudolocalization to simulate the lengthening of text due to localization.
[b]Note:[/b] Updating this property does not automatically update texts in the scene tree. Please propagate the [constant MainLoop.NOTIFICATION_TRANSLATION_CHANGED] notification manually after you have finished modifying pseudolocalization related options.

## pseudolocalization_enabled :: var TranslationDomain.pseudolocalization_enabled: bool
If [code]true[/code], enables pseudolocalization for the project. This can be used to spot untranslatable strings or layout issues that may occur once the project is localized to languages that have longer strings than the source language.
[b]Note:[/b] Updating this property does not automatically update texts in the scene tree. Please propagate the [constant MainLoop.NOTIFICATION_TRANSLATION_CHANGED] notification manually after you have finished modifying pseudolocalization related options.

## pseudolocalization_expansion_ratio :: var TranslationDomain.pseudolocalization_expansion_ratio: float
The expansion ratio to use during pseudolocalization. A value of [code]0.3[/code] is sufficient for most practical purposes, and will increase the length of each string by 30%.
[b]Note:[/b] Updating this property does not automatically update texts in the scene tree. Please propagate the [constant MainLoop.NOTIFICATION_TRANSLATION_CHANGED] notification manually after you have finished modifying pseudolocalization related options.

## pseudolocalization_fake_bidi_enabled :: var TranslationDomain.pseudolocalization_fake_bidi_enabled: bool
If [code]true[/code], emulate bidirectional (right-to-left) text when pseudolocalization is enabled. This can be used to spot issues with RTL layout and UI mirroring that will crop up if the project is localized to RTL languages such as Arabic or Hebrew.
[b]Note:[/b] Updating this property does not automatically update texts in the scene tree. Please propagate the [constant MainLoop.NOTIFICATION_TRANSLATION_CHANGED] notification manually after you have finished modifying pseudolocalization related options.

## pseudolocalization_override_enabled :: var TranslationDomain.pseudolocalization_override_enabled: bool
Replace all characters in the string with [code]*[/code]. Useful for finding non-localizable strings.
[b]Note:[/b] Updating this property does not automatically update texts in the scene tree. Please propagate the [constant MainLoop.NOTIFICATION_TRANSLATION_CHANGED] notification manually after you have finished modifying pseudolocalization related options.

## pseudolocalization_prefix :: var TranslationDomain.pseudolocalization_prefix: String
Prefix that will be prepended to the pseudolocalized string.
[b]Note:[/b] Updating this property does not automatically update texts in the scene tree. Please propagate the [constant MainLoop.NOTIFICATION_TRANSLATION_CHANGED] notification manually after you have finished modifying pseudolocalization related options.

## pseudolocalization_skip_placeholders_enabled :: var TranslationDomain.pseudolocalization_skip_placeholders_enabled: bool
Skip placeholders for string formatting like [code]%s[/code] or [code]%f[/code] during pseudolocalization. Useful to identify strings which need additional control characters to display correctly.
[b]Note:[/b] Updating this property does not automatically update texts in the scene tree. Please propagate the [constant MainLoop.NOTIFICATION_TRANSLATION_CHANGED] notification manually after you have finished modifying pseudolocalization related options.

## pseudolocalization_suffix :: var TranslationDomain.pseudolocalization_suffix: String
Suffix that will be appended to the pseudolocalized string.
[b]Note:[/b] Updating this property does not automatically update texts in the scene tree. Please propagate the [constant MainLoop.NOTIFICATION_TRANSLATION_CHANGED] notification manually after you have finished modifying pseudolocalization related options.

## add_translation :: func TranslationDomain.add_translation(translation: Translation) -> void
Adds a translation.

### translation :: Translation

## clear :: func TranslationDomain.clear() -> void
Removes all translations.

## find_translations :: func TranslationDomain.find_translations(locale: String, exact: bool) -> Translation[]
Returns the [Translation] instances that match [param locale] (see [method TranslationServer.compare_locales]). If [param exact] is [code]true[/code], only instances whose locale exactly equals [param locale] will be returned.

### locale :: String

### exact :: bool

## get_locale_override :: func TranslationDomain.get_locale_override() -> String
Returns the locale override of the domain. Returns an empty string if locale override is disabled.

## get_translation_object :: func TranslationDomain.get_translation_object(locale: String) -> Translation
Returns the [Translation] instance that best matches [param locale]. Returns [code]null[/code] if there are no matches.

### locale :: String

## get_translations :: func TranslationDomain.get_translations() -> Translation[]
Returns all available [Translation] instances as added by [method add_translation].

## has_translation :: func TranslationDomain.has_translation(translation: Translation) -> bool
Returns [code]true[/code] if this translation domain contains the given [param translation].

### translation :: Translation

## has_translation_for_locale :: func TranslationDomain.has_translation_for_locale(locale: String, exact: bool) -> bool
Returns [code]true[/code] if there are any [Translation] instances that match [param locale] (see [method TranslationServer.compare_locales]). If [param exact] is [code]true[/code], only instances whose locale exactly equals [param locale] are considered.

### locale :: String

### exact :: bool

## pseudolocalize :: func TranslationDomain.pseudolocalize(message: StringName) -> StringName
Returns the pseudolocalized string based on the [param message] passed in.

### message :: StringName

## remove_translation :: func TranslationDomain.remove_translation(translation: Translation) -> void
Removes the given translation.

### translation :: Translation

## set_locale_override :: func TranslationDomain.set_locale_override(locale: String) -> void
Sets the locale override of the domain.
If [param locale] is an empty string, locale override is disabled. Otherwise, [param locale] will be standardized to match known locales (e.g. [code]en-US[/code] would be matched to [code]en_US[/code]).
[b]Note:[/b] Calling this method does not automatically update texts in the scene tree. Please propagate the [constant MainLoop.NOTIFICATION_TRANSLATION_CHANGED] signal manually.

### locale :: String

## translate :: func TranslationDomain.translate(message: StringName, context: StringName = &"") -> StringName
Returns the current locale's translation for the given message and context.

### message :: StringName

### context :: StringName

## translate_plural :: func TranslationDomain.translate_plural(message: StringName, message_plural: StringName, n: int, context: StringName = &"") -> StringName
Returns the current locale's translation for the given message, plural message and context.
The number [param n] is the number or quantity of the plural object. It will be used to guide the translation system to fetch the correct plural form for the selected language.

### message :: StringName

### message_plural :: StringName

### n :: int

### context :: StringName
