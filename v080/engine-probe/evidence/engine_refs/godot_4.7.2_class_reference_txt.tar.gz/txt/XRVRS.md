# XRVRS :: <Native> class XRVRS extends Object
Helper class for XR interfaces that generates VRS images.
This class is used by various XR interfaces to generate VRS textures that can be used to speed up rendering.

## vrs_min_radius :: var XRVRS.vrs_min_radius: float
The minimum radius around the focal point where full quality is guaranteed if VRS is used as a percentage of screen size.

## vrs_render_region :: var XRVRS.vrs_render_region: Rect2i
The render region that the VRS texture will be scaled to when generated.

## vrs_strength :: var XRVRS.vrs_strength: float
The strength used to calculate the VRS density map. The greater this value, the more noticeable VRS is.

## make_vrs_texture :: func XRVRS.make_vrs_texture(target_size: Vector2, eye_foci: PackedVector2Array) -> RID
Generates the VRS texture based on a render [param target_size] adjusted by our VRS tile size. For each eyes focal point passed in [param eye_foci] a layer is created. Focal point should be in NDC.
The result will be cached, requesting a VRS texture with unchanged parameters and settings will return the cached RID.

### target_size :: Vector2

### eye_foci :: PackedVector2Array
