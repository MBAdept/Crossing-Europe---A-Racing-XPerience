# ParticleProcessMaterial :: <Native> class ParticleProcessMaterial extends Material
Holds a particle configuration for [GPUParticles2D] or [GPUParticles3D] nodes.
[ParticleProcessMaterial] defines particle properties and behavior. It is used in the [code]process_material[/code] of the [GPUParticles2D] and [GPUParticles3D] nodes. Some of this material's properties are applied to each particle when emitted, while others can have a [CurveTexture] or a [GradientTexture1D] applied to vary numerical or color values over the lifetime of the particle.

## PARAM_INITIAL_LINEAR_VELOCITY :: const ParticleProcessMaterial.PARAM_INITIAL_LINEAR_VELOCITY: Parameter = 0
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set initial velocity properties.

## PARAM_ANGULAR_VELOCITY :: const ParticleProcessMaterial.PARAM_ANGULAR_VELOCITY: Parameter = 1
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set angular velocity properties.

## PARAM_ORBIT_VELOCITY :: const ParticleProcessMaterial.PARAM_ORBIT_VELOCITY: Parameter = 2
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set orbital velocity properties.

## PARAM_LINEAR_ACCEL :: const ParticleProcessMaterial.PARAM_LINEAR_ACCEL: Parameter = 3
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set linear acceleration properties.

## PARAM_RADIAL_ACCEL :: const ParticleProcessMaterial.PARAM_RADIAL_ACCEL: Parameter = 4
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set radial acceleration properties.

## PARAM_TANGENTIAL_ACCEL :: const ParticleProcessMaterial.PARAM_TANGENTIAL_ACCEL: Parameter = 5
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set tangential acceleration properties.

## PARAM_DAMPING :: const ParticleProcessMaterial.PARAM_DAMPING: Parameter = 6
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set damping properties.

## PARAM_ANGLE :: const ParticleProcessMaterial.PARAM_ANGLE: Parameter = 7
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set angle properties.

## PARAM_SCALE :: const ParticleProcessMaterial.PARAM_SCALE: Parameter = 8
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set scale properties.

## PARAM_HUE_VARIATION :: const ParticleProcessMaterial.PARAM_HUE_VARIATION: Parameter = 9
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set hue variation properties.

## PARAM_ANIM_SPEED :: const ParticleProcessMaterial.PARAM_ANIM_SPEED: Parameter = 10
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set animation speed properties.

## PARAM_ANIM_OFFSET :: const ParticleProcessMaterial.PARAM_ANIM_OFFSET: Parameter = 11
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set animation offset properties.

## PARAM_RADIAL_VELOCITY :: const ParticleProcessMaterial.PARAM_RADIAL_VELOCITY: Parameter = 15
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set radial velocity properties.

## PARAM_DIRECTIONAL_VELOCITY :: const ParticleProcessMaterial.PARAM_DIRECTIONAL_VELOCITY: Parameter = 16
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set directional velocity properties.

## PARAM_SCALE_OVER_VELOCITY :: const ParticleProcessMaterial.PARAM_SCALE_OVER_VELOCITY: Parameter = 17
Use with [method set_param_min], [method set_param_max], and [method set_param_texture] to set scale over velocity properties.

## PARAM_MAX :: const ParticleProcessMaterial.PARAM_MAX: Parameter = 18
Represents the size of the [enum Parameter] enum.

## PARTICLE_FLAG_ALIGN_Y_TO_VELOCITY :: const ParticleProcessMaterial.PARTICLE_FLAG_ALIGN_Y_TO_VELOCITY: ParticleFlags = 0
Use with [method set_particle_flag] to set [member particle_flag_align_y].

## PARTICLE_FLAG_ROTATE_Y :: const ParticleProcessMaterial.PARTICLE_FLAG_ROTATE_Y: ParticleFlags = 1
Use with [method set_particle_flag] to set [member particle_flag_rotate_y].

## PARTICLE_FLAG_DISABLE_Z :: const ParticleProcessMaterial.PARTICLE_FLAG_DISABLE_Z: ParticleFlags = 2
Use with [method set_particle_flag] to set [member particle_flag_disable_z].

## PARTICLE_FLAG_DAMPING_AS_FRICTION :: const ParticleProcessMaterial.PARTICLE_FLAG_DAMPING_AS_FRICTION: ParticleFlags = 3

## PARTICLE_FLAG_INHERIT_EMITTER_SCALE :: const ParticleProcessMaterial.PARTICLE_FLAG_INHERIT_EMITTER_SCALE: ParticleFlags = 4

## PARTICLE_FLAG_MAX :: const ParticleProcessMaterial.PARTICLE_FLAG_MAX: ParticleFlags = 5
Represents the size of the [enum ParticleFlags] enum.

## EMISSION_SHAPE_POINT :: const ParticleProcessMaterial.EMISSION_SHAPE_POINT: EmissionShape = 0
All particles will be emitted from a single point.

## EMISSION_SHAPE_SPHERE :: const ParticleProcessMaterial.EMISSION_SHAPE_SPHERE: EmissionShape = 1
Particles will be emitted in the volume of a sphere.

## EMISSION_SHAPE_SPHERE_SURFACE :: const ParticleProcessMaterial.EMISSION_SHAPE_SPHERE_SURFACE: EmissionShape = 2
Particles will be emitted on the surface of a sphere.

## EMISSION_SHAPE_BOX :: const ParticleProcessMaterial.EMISSION_SHAPE_BOX: EmissionShape = 3
Particles will be emitted in the volume of a box.

## EMISSION_SHAPE_POINTS :: const ParticleProcessMaterial.EMISSION_SHAPE_POINTS: EmissionShape = 4
Particles will be emitted at a position determined by sampling a random point on the [member emission_point_texture]. Particle color will be modulated by [member emission_color_texture].

## EMISSION_SHAPE_DIRECTED_POINTS :: const ParticleProcessMaterial.EMISSION_SHAPE_DIRECTED_POINTS: EmissionShape = 5
Particles will be emitted at a position determined by sampling a random point on the [member emission_point_texture]. Particle velocity and rotation will be set based on [member emission_normal_texture]. Particle color will be modulated by [member emission_color_texture].

## EMISSION_SHAPE_RING :: const ParticleProcessMaterial.EMISSION_SHAPE_RING: EmissionShape = 6
Particles will be emitted in a ring or cylinder.

## EMISSION_SHAPE_MAX :: const ParticleProcessMaterial.EMISSION_SHAPE_MAX: EmissionShape = 7
Represents the size of the [enum EmissionShape] enum.

## PARAM_TURB_VEL_INFLUENCE :: const ParticleProcessMaterial.PARAM_TURB_VEL_INFLUENCE: Parameter = 13
Use with [method set_param_min] and [method set_param_max] to set the turbulence minimum und maximum influence on each particles velocity.

## PARAM_TURB_INIT_DISPLACEMENT :: const ParticleProcessMaterial.PARAM_TURB_INIT_DISPLACEMENT: Parameter = 14
Use with [method set_param_min] and [method set_param_max] to set the turbulence minimum and maximum displacement of the particles spawn position.

## PARAM_TURB_INFLUENCE_OVER_LIFE :: const ParticleProcessMaterial.PARAM_TURB_INFLUENCE_OVER_LIFE: Parameter = 12
Use with [method set_param_texture] to set the turbulence influence over the particles life time.

## SUB_EMITTER_DISABLED :: const ParticleProcessMaterial.SUB_EMITTER_DISABLED: SubEmitterMode = 0
The subemitter is disabled.

## SUB_EMITTER_CONSTANT :: const ParticleProcessMaterial.SUB_EMITTER_CONSTANT: SubEmitterMode = 1
The submitter is emitted on the constant interval defined by [member sub_emitter_frequency].

## SUB_EMITTER_AT_END :: const ParticleProcessMaterial.SUB_EMITTER_AT_END: SubEmitterMode = 2
The subemitter is emitted at the end of the particle's lifetime.

## SUB_EMITTER_AT_COLLISION :: const ParticleProcessMaterial.SUB_EMITTER_AT_COLLISION: SubEmitterMode = 3
The subemitter is emitted when the particle collides.

## SUB_EMITTER_AT_START :: const ParticleProcessMaterial.SUB_EMITTER_AT_START: SubEmitterMode = 4
The subemitter is emitted when the particle spawns.

## SUB_EMITTER_MAX :: const ParticleProcessMaterial.SUB_EMITTER_MAX: SubEmitterMode = 5
Represents the size of the [enum SubEmitterMode] enum.

## COLLISION_DISABLED :: const ParticleProcessMaterial.COLLISION_DISABLED: CollisionMode = 0
No collision for particles. Particles will go through [GPUParticlesCollision3D] nodes.

## COLLISION_RIGID :: const ParticleProcessMaterial.COLLISION_RIGID: CollisionMode = 1
[RigidBody3D]-style collision for particles using [GPUParticlesCollision3D] nodes.

## COLLISION_HIDE_ON_CONTACT :: const ParticleProcessMaterial.COLLISION_HIDE_ON_CONTACT: CollisionMode = 2
Hide particles instantly when colliding with a [GPUParticlesCollision3D] node. This can be combined with a subemitter that uses the [constant COLLISION_RIGID] collision mode to "replace" the parent particle with the subemitter on impact.

## COLLISION_MAX :: const ParticleProcessMaterial.COLLISION_MAX: CollisionMode = 3
Represents the size of the [enum CollisionMode] enum.

## alpha_curve :: var ParticleProcessMaterial.alpha_curve: Texture2D
The alpha value of each particle's color will be multiplied by this [CurveTexture] over its lifetime.
[b]Note:[/b] [member alpha_curve] multiplies the particle mesh's vertex colors. To have a visible effect on a [BaseMaterial3D], [member BaseMaterial3D.vertex_color_use_as_albedo] [i]must[/i] be [code]true[/code]. For a [ShaderMaterial], [code]ALPHA *= COLOR.a;[/code] must be inserted in the shader's [code]fragment()[/code] function. Otherwise, [member alpha_curve] will have no visible effect.

## angle_curve :: var ParticleProcessMaterial.angle_curve: Texture2D
Each particle's rotation will be animated along this [CurveTexture].

## angle_max :: var ParticleProcessMaterial.angle_max: float
Maximum initial rotation applied to each particle, in degrees.
Only applied when [member particle_flag_disable_z] or [member particle_flag_rotate_y] are [code]true[/code] or the [BaseMaterial3D] being used to draw the particle is using [constant BaseMaterial3D.BILLBOARD_PARTICLES].

## angle_min :: var ParticleProcessMaterial.angle_min: float
Minimum equivalent of [member angle_max].

## angular_velocity_curve :: var ParticleProcessMaterial.angular_velocity_curve: Texture2D
Each particle's angular velocity (rotation speed) will vary along this [CurveTexture] over its lifetime.

## angular_velocity_max :: var ParticleProcessMaterial.angular_velocity_max: float
Maximum initial angular velocity (rotation speed) applied to each particle in [i]degrees[/i] per second.
Only applied when [member particle_flag_disable_z] or [member particle_flag_rotate_y] are [code]true[/code] or the [BaseMaterial3D] being used to draw the particle is using [constant BaseMaterial3D.BILLBOARD_PARTICLES].

## angular_velocity_min :: var ParticleProcessMaterial.angular_velocity_min: float
Minimum equivalent of [member angular_velocity_max].

## anim_offset_curve :: var ParticleProcessMaterial.anim_offset_curve: Texture2D
Each particle's animation offset will vary along this [CurveTexture].

## anim_offset_max :: var ParticleProcessMaterial.anim_offset_max: float
Maximum animation offset that corresponds to frame index in the texture. [code]0[/code] is the first frame, [code]1[/code] is the last one. See [member CanvasItemMaterial.particles_animation].

## anim_offset_min :: var ParticleProcessMaterial.anim_offset_min: float
Minimum equivalent of [member anim_offset_max].

## anim_speed_curve :: var ParticleProcessMaterial.anim_speed_curve: Texture2D
Each particle's animation speed will vary along this [CurveTexture].

## anim_speed_max :: var ParticleProcessMaterial.anim_speed_max: float
Maximum particle animation speed. Animation speed of [code]1[/code] means that the particles will make full [code]0[/code] to [code]1[/code] offset cycle during lifetime, [code]2[/code] means [code]2[/code] cycles etc.
With animation speed greater than [code]1[/code], remember to enable [member CanvasItemMaterial.particles_anim_loop] property if you want the animation to repeat.

## anim_speed_min :: var ParticleProcessMaterial.anim_speed_min: float
Minimum equivalent of [member anim_speed_max].

## attractor_interaction_enabled :: var ParticleProcessMaterial.attractor_interaction_enabled: bool
If [code]true[/code], interaction with particle attractors is enabled. In 3D, attraction only occurs within the area defined by the [GPUParticles3D] node's [member GPUParticles3D.visibility_aabb].

## collision_bounce :: var ParticleProcessMaterial.collision_bounce: float
The particles' bounciness. Values range from [code]0[/code] (no bounce) to [code]1[/code] (full bounciness). Only effective if [member collision_mode] is [constant COLLISION_RIGID].

## collision_friction :: var ParticleProcessMaterial.collision_friction: float
The particles' friction. Values range from [code]0[/code] (frictionless) to [code]1[/code] (maximum friction). Only effective if [member collision_mode] is [constant COLLISION_RIGID].

## collision_mode :: var ParticleProcessMaterial.collision_mode: ParticleProcessMaterial.CollisionMode
The particles' collision mode.
[b]Note:[/b] 3D Particles can only collide with [GPUParticlesCollision3D] nodes, not [PhysicsBody3D] nodes. To make particles collide with various objects, you can add [GPUParticlesCollision3D] nodes as children of [PhysicsBody3D] nodes. In 3D, collisions only occur within the area defined by the [GPUParticles3D] node's [member GPUParticles3D.visibility_aabb].
[b]Note:[/b] 2D Particles can only collide with [LightOccluder2D] nodes, not [PhysicsBody2D] nodes.

## collision_use_scale :: var ParticleProcessMaterial.collision_use_scale: bool
If [code]true[/code], [member GPUParticles3D.collision_base_size] is multiplied by the particle's effective scale (see [member scale_min], [member scale_max], [member scale_curve], and [member scale_over_velocity_curve]).

## color :: var ParticleProcessMaterial.color: Color
Each particle's initial color. If the [GPUParticles2D]'s [code]texture[/code] is defined, it will be multiplied by this color.
[b]Note:[/b] [member color] multiplies the particle mesh's vertex colors. To have a visible effect on a [BaseMaterial3D], [member BaseMaterial3D.vertex_color_use_as_albedo] [i]must[/i] be [code]true[/code]. For a [ShaderMaterial], [code]ALBEDO *= COLOR.rgb;[/code] must be inserted in the shader's [code]fragment()[/code] function. Otherwise, [member color] will have no visible effect.

## color_initial_ramp :: var ParticleProcessMaterial.color_initial_ramp: Texture2D
Each particle's initial color will vary along this [GradientTexture1D] (multiplied with [member color]).
[b]Note:[/b] [member color_initial_ramp] multiplies the particle mesh's vertex colors. To have a visible effect on a [BaseMaterial3D], [member BaseMaterial3D.vertex_color_use_as_albedo] [i]must[/i] be [code]true[/code]. For a [ShaderMaterial], [code]ALBEDO *= COLOR.rgb;[/code] must be inserted in the shader's [code]fragment()[/code] function. Otherwise, [member color_initial_ramp] will have no visible effect.

## color_ramp :: var ParticleProcessMaterial.color_ramp: Texture2D
Each particle's color will vary along this [GradientTexture1D] over its lifetime (multiplied with [member color]).
[b]Note:[/b] [member color_ramp] multiplies the particle mesh's vertex colors. To have a visible effect on a [BaseMaterial3D], [member BaseMaterial3D.vertex_color_use_as_albedo] [i]must[/i] be [code]true[/code]. For a [ShaderMaterial], [code]ALBEDO *= COLOR.rgb;[/code] must be inserted in the shader's [code]fragment()[/code] function. Otherwise, [member color_ramp] will have no visible effect.

## damping_curve :: var ParticleProcessMaterial.damping_curve: Texture2D
Damping will vary along this [CurveTexture].

## damping_max :: var ParticleProcessMaterial.damping_max: float
The maximum rate at which particles lose velocity. For example value of [code]100[/code] means that the particle will go from [code]100[/code] velocity to [code]0[/code] in [code]1[/code] second.

## damping_min :: var ParticleProcessMaterial.damping_min: float
Minimum equivalent of [member damping_max].

## direction :: var ParticleProcessMaterial.direction: Vector3
Unit vector specifying the particles' emission direction.

## directional_velocity_curve :: var ParticleProcessMaterial.directional_velocity_curve: Texture2D
A curve that specifies the velocity along each of the axes of the particle system along its lifetime.
[b]Note:[/b] Animated velocities will not be affected by damping, use [member velocity_limit_curve] instead.

## directional_velocity_max :: var ParticleProcessMaterial.directional_velocity_max: float
Maximum directional velocity value, which is multiplied by [member directional_velocity_curve].
[b]Note:[/b] Animated velocities will not be affected by damping, use [member velocity_limit_curve] instead.

## directional_velocity_min :: var ParticleProcessMaterial.directional_velocity_min: float
Minimum directional velocity value, which is multiplied by [member directional_velocity_curve].
[b]Note:[/b] Animated velocities will not be affected by damping, use [member velocity_limit_curve] instead.

## emission_box_extents :: var ParticleProcessMaterial.emission_box_extents: Vector3
The box's extents if [member emission_shape] is set to [constant EMISSION_SHAPE_BOX].
[b]Note:[/b] [member emission_box_extents] starts from the center point and applies the X, Y, and Z values in both directions. The size is twice the area of the extents.

## emission_color_texture :: var ParticleProcessMaterial.emission_color_texture: Texture2D
Particle color will be modulated by color determined by sampling this texture at the same point as the [member emission_point_texture].
[b]Note:[/b] [member emission_color_texture] multiplies the particle mesh's vertex colors. To have a visible effect on a [BaseMaterial3D], [member BaseMaterial3D.vertex_color_use_as_albedo] [i]must[/i] be [code]true[/code]. For a [ShaderMaterial], [code]ALBEDO *= COLOR.rgb;[/code] must be inserted in the shader's [code]fragment()[/code] function. Otherwise, [member emission_color_texture] will have no visible effect.

## emission_curve :: var ParticleProcessMaterial.emission_curve: Texture2D
Each particle's color will be multiplied by this [CurveTexture] over its lifetime.
[b]Note:[/b] [member emission_curve] multiplies the particle mesh's vertex colors. To have a visible effect on a [BaseMaterial3D], [member BaseMaterial3D.vertex_color_use_as_albedo] [i]must[/i] be [code]true[/code]. For a [ShaderMaterial], [code]ALBEDO *= COLOR.rgb;[/code] must be inserted in the shader's [code]fragment()[/code] function. Otherwise, [member emission_curve] will have no visible effect.

## emission_normal_texture :: var ParticleProcessMaterial.emission_normal_texture: Texture2D
Particle velocity and rotation will be set by sampling this texture at the same point as the [member emission_point_texture]. Used only in [constant EMISSION_SHAPE_DIRECTED_POINTS]. Can be created automatically from mesh or node by selecting "Create Emission Points from Mesh/Node" under the "Particles" tool in the toolbar.

## emission_point_count :: var ParticleProcessMaterial.emission_point_count: int
The number of emission points if [member emission_shape] is set to [constant EMISSION_SHAPE_POINTS] or [constant EMISSION_SHAPE_DIRECTED_POINTS].

## emission_point_texture :: var ParticleProcessMaterial.emission_point_texture: Texture2D
Particles will be emitted at positions determined by sampling this texture at a random position. Used with [constant EMISSION_SHAPE_POINTS] and [constant EMISSION_SHAPE_DIRECTED_POINTS]. Can be created automatically from mesh or node by selecting "Create Emission Points from Mesh/Node" under the "Particles" tool in the toolbar.

## emission_ring_axis :: var ParticleProcessMaterial.emission_ring_axis: Vector3
The axis of the ring when using the emitter [constant EMISSION_SHAPE_RING].

## emission_ring_cone_angle :: var ParticleProcessMaterial.emission_ring_cone_angle: float
The angle of the cone when using the emitter [constant EMISSION_SHAPE_RING]. The default angle of 90 degrees results in a ring, while an angle of 0 degrees results in a cone. Intermediate values will result in a ring where one end is larger than the other.
[b]Note:[/b] Depending on [member emission_ring_height], the angle may be clamped if the ring's end is reached to form a perfect cone.

## emission_ring_height :: var ParticleProcessMaterial.emission_ring_height: float
The height of the ring when using the emitter [constant EMISSION_SHAPE_RING].

## emission_ring_inner_radius :: var ParticleProcessMaterial.emission_ring_inner_radius: float
The inner radius of the ring when using the emitter [constant EMISSION_SHAPE_RING].

## emission_ring_radius :: var ParticleProcessMaterial.emission_ring_radius: float
The radius of the ring when using the emitter [constant EMISSION_SHAPE_RING].

## emission_shape :: var ParticleProcessMaterial.emission_shape: ParticleProcessMaterial.EmissionShape
Particles will be emitted inside this region.

## emission_shape_offset :: var ParticleProcessMaterial.emission_shape_offset: Vector3
The offset for the [member emission_shape], in local space.

## emission_shape_scale :: var ParticleProcessMaterial.emission_shape_scale: Vector3
The scale of the [member emission_shape], in local space.

## emission_sphere_radius :: var ParticleProcessMaterial.emission_sphere_radius: float
The sphere's radius if [member emission_shape] is set to [constant EMISSION_SHAPE_SPHERE].

## flatness :: var ParticleProcessMaterial.flatness: float
Amount of [member spread] along the Y axis.

## gravity :: var ParticleProcessMaterial.gravity: Vector3
Gravity applied to every particle.

## hue_variation_curve :: var ParticleProcessMaterial.hue_variation_curve: Texture2D
Each particle's hue will vary along this [CurveTexture].

## hue_variation_max :: var ParticleProcessMaterial.hue_variation_max: float
Maximum initial hue variation applied to each particle. It will shift the particle color's hue.

## hue_variation_min :: var ParticleProcessMaterial.hue_variation_min: float
Minimum equivalent of [member hue_variation_max].

## inherit_velocity_ratio :: var ParticleProcessMaterial.inherit_velocity_ratio: float
Percentage of the velocity of the respective [GPUParticles2D] or [GPUParticles3D] inherited by each particle when spawning.

## initial_velocity_max :: var ParticleProcessMaterial.initial_velocity_max: float
Maximum initial velocity magnitude for each particle. Direction comes from [member direction] and [member spread].

## initial_velocity_min :: var ParticleProcessMaterial.initial_velocity_min: float
Minimum equivalent of [member initial_velocity_max].

## lifetime_randomness :: var ParticleProcessMaterial.lifetime_randomness: float
Particle lifetime randomness ratio. The equation for the lifetime of a particle is [code]lifetime * (1.0 - randf() * lifetime_randomness)[/code]. For example, a [member lifetime_randomness] of [code]0.4[/code] scales the lifetime between [code]0.6[/code] to [code]1.0[/code] of its original value.

## linear_accel_curve :: var ParticleProcessMaterial.linear_accel_curve: Texture2D
Each particle's linear acceleration will vary along this [CurveTexture].

## linear_accel_max :: var ParticleProcessMaterial.linear_accel_max: float
Maximum linear acceleration applied to each particle in the direction of motion.

## linear_accel_min :: var ParticleProcessMaterial.linear_accel_min: float
Minimum equivalent of [member linear_accel_max].

## orbit_velocity_curve :: var ParticleProcessMaterial.orbit_velocity_curve: Texture2D
Each particle's orbital velocity will vary along this [CurveTexture].
[b]Note:[/b] For 3D orbital velocity, use a [CurveXYZTexture].
[b]Note:[/b] Animated velocities will not be affected by damping, use [member velocity_limit_curve] instead.

## orbit_velocity_max :: var ParticleProcessMaterial.orbit_velocity_max: float
Maximum orbital velocity applied to each particle. Makes the particles circle around origin. Specified in number of full rotations around origin per second.
[b]Note:[/b] Animated velocities will not be affected by damping, use [member velocity_limit_curve] instead.

## orbit_velocity_min :: var ParticleProcessMaterial.orbit_velocity_min: float
Minimum equivalent of [member orbit_velocity_max].
[b]Note:[/b] Animated velocities will not be affected by damping, use [member velocity_limit_curve] instead.

## particle_flag_align_y :: var ParticleProcessMaterial.particle_flag_align_y: bool
Align Y axis of particle with the direction of its velocity.

## particle_flag_damping_as_friction :: var ParticleProcessMaterial.particle_flag_damping_as_friction: bool
Changes the behavior of the damping properties from a linear deceleration to a deceleration based on speed percentage.

## particle_flag_disable_z :: var ParticleProcessMaterial.particle_flag_disable_z: bool
If [code]true[/code], particles will not move on the z axis.

## particle_flag_inherit_emitter_scale :: var ParticleProcessMaterial.particle_flag_inherit_emitter_scale: bool
If [code]true[/code], particles will inherit the scale of the emitter.
[b]Note:[/b] This has no effect when [member GPUParticles3D.local_coords] is [code]true[/code], since particles in local space are already affected by the emitter's scale.

## particle_flag_rotate_y :: var ParticleProcessMaterial.particle_flag_rotate_y: bool
If [code]true[/code], particles rotate around Y axis by [member angle_min].

## radial_accel_curve :: var ParticleProcessMaterial.radial_accel_curve: Texture2D
Each particle's radial acceleration will vary along this [CurveTexture].

## radial_accel_max :: var ParticleProcessMaterial.radial_accel_max: float
Maximum radial acceleration applied to each particle. Makes particle accelerate away from the origin or towards it if negative.

## radial_accel_min :: var ParticleProcessMaterial.radial_accel_min: float
Minimum equivalent of [member radial_accel_max].

## radial_velocity_curve :: var ParticleProcessMaterial.radial_velocity_curve: Texture2D
A [CurveTexture] that defines the velocity over the particle's lifetime away (or toward) the [member velocity_pivot].
[b]Note:[/b] Animated velocities will not be affected by damping, use [member velocity_limit_curve] instead.

## radial_velocity_max :: var ParticleProcessMaterial.radial_velocity_max: float
Maximum radial velocity applied to each particle. Makes particles move away from the [member velocity_pivot], or toward it if negative.
[b]Note:[/b] Animated velocities will not be affected by damping, use [member velocity_limit_curve] instead.

## radial_velocity_min :: var ParticleProcessMaterial.radial_velocity_min: float
Minimum radial velocity applied to each particle. Makes particles move away from the [member velocity_pivot], or toward it if negative.
[b]Note:[/b] Animated velocities will not be affected by damping, use [member velocity_limit_curve] instead.

## rotation_3d_max :: var ParticleProcessMaterial.rotation_3d_max: Vector3
The maximum 3D orientation, in degrees. Works only in 3D and if [member use_rotation_3d] is enabled.

## rotation_3d_min :: var ParticleProcessMaterial.rotation_3d_min: Vector3
The minimum 3D orientation, in degrees. Works only in 3D and if [member use_rotation_3d] is enabled.

## rotation_velocity_3d_curve :: var ParticleProcessMaterial.rotation_velocity_3d_curve: Texture2D
Rotation velocity curve over lifetime, per-axis. Enable [member use_rotation_velocity_3d] to use this.

## rotation_velocity_3d_max :: var ParticleProcessMaterial.rotation_velocity_3d_max: Vector3
Maximum 3D rotation velocity on the particle's local axis. Enable [member use_rotation_velocity_3d] to use this.

## rotation_velocity_3d_min :: var ParticleProcessMaterial.rotation_velocity_3d_min: Vector3
Minimum 3D rotation velocity on the particle's local axis. Enable [member use_rotation_velocity_3d] to use this.

## scale_3d_max :: var ParticleProcessMaterial.scale_3d_max: Vector3
The maximum value of the random scale vector for each particle.
Works only if [member use_scale_3d] is enabled.

## scale_3d_min :: var ParticleProcessMaterial.scale_3d_min: Vector3
The minimum value of the random scale vector for each particle.
Works only if [member use_scale_3d] is enabled.

## scale_curve :: var ParticleProcessMaterial.scale_curve: Texture2D
Each particle's scale will vary along this [CurveTexture] over its lifetime. If a [CurveXYZTexture] is supplied instead, the scale will be separated per-axis.

## scale_max :: var ParticleProcessMaterial.scale_max: float
Maximum initial scale applied to each particle.

## scale_min :: var ParticleProcessMaterial.scale_min: float
Minimum equivalent of [member scale_max].

## scale_over_velocity_curve :: var ParticleProcessMaterial.scale_over_velocity_curve: Texture2D
Either a [CurveTexture] or a [CurveXYZTexture] that scales each particle based on its velocity.

## scale_over_velocity_max :: var ParticleProcessMaterial.scale_over_velocity_max: float
Maximum velocity value reference for [member scale_over_velocity_curve].
[member scale_over_velocity_curve] will be interpolated between [member scale_over_velocity_min] and [member scale_over_velocity_max].

## scale_over_velocity_min :: var ParticleProcessMaterial.scale_over_velocity_min: float
Minimum velocity value reference for [member scale_over_velocity_curve].
[member scale_over_velocity_curve] will be interpolated between [member scale_over_velocity_min] and [member scale_over_velocity_max].

## spread :: var ParticleProcessMaterial.spread: float
Each particle's initial direction range from [code]+spread[/code] to [code]-spread[/code] degrees.

## sub_emitter_amount_at_collision :: var ParticleProcessMaterial.sub_emitter_amount_at_collision: int
The amount of particles to spawn from the subemitter node when a collision occurs. When combined with [constant COLLISION_HIDE_ON_CONTACT] on the main particles material, this can be used to achieve effects such as raindrops hitting the ground.
[b]Note:[/b] This value shouldn't exceed [member GPUParticles2D.amount] or [member GPUParticles3D.amount] defined on the [i]subemitter node[/i] (not the main node), relative to the subemitter's particle lifetime. If the number of particles is exceeded, no new particles will spawn from the subemitter until enough particles have expired.

## sub_emitter_amount_at_end :: var ParticleProcessMaterial.sub_emitter_amount_at_end: int
The amount of particles to spawn from the subemitter node when the particle expires.
[b]Note:[/b] This value shouldn't exceed [member GPUParticles2D.amount] or [member GPUParticles3D.amount] defined on the [i]subemitter node[/i] (not the main node), relative to the subemitter's particle lifetime. If the number of particles is exceeded, no new particles will spawn from the subemitter until enough particles have expired.

## sub_emitter_amount_at_start :: var ParticleProcessMaterial.sub_emitter_amount_at_start: int
The amount of particles to spawn from the subemitter node when the particle spawns.
[b]Note:[/b] This value shouldn't exceed [member GPUParticles2D.amount] or [member GPUParticles3D.amount] defined on the [i]subemitter node[/i] (not the main node), relative to the subemitter's particle lifetime. If the number of particles is exceeded, no new particles will spawn from the subemitter until enough particles have expired.

## sub_emitter_frequency :: var ParticleProcessMaterial.sub_emitter_frequency: float
The frequency at which particles should be emitted from the subemitter node. One particle will be spawned every [member sub_emitter_frequency] seconds.
[b]Note:[/b] This value shouldn't exceed [member GPUParticles2D.amount] or [member GPUParticles3D.amount] defined on the [i]subemitter node[/i] (not the main node), relative to the subemitter's particle lifetime. If the number of particles is exceeded, no new particles will spawn from the subemitter until enough particles have expired.

## sub_emitter_keep_velocity :: var ParticleProcessMaterial.sub_emitter_keep_velocity: bool
If [code]true[/code], the subemitter inherits the parent particle's velocity when it spawns.

## sub_emitter_mode :: var ParticleProcessMaterial.sub_emitter_mode: ParticleProcessMaterial.SubEmitterMode
The particle subemitter mode (see [member GPUParticles2D.sub_emitter] and [member GPUParticles3D.sub_emitter]).

## tangential_accel_curve :: var ParticleProcessMaterial.tangential_accel_curve: Texture2D
Each particle's tangential acceleration will vary along this [CurveTexture].

## tangential_accel_max :: var ParticleProcessMaterial.tangential_accel_max: float
Maximum tangential acceleration applied to each particle. Tangential acceleration is perpendicular to the particle's velocity giving the particles a swirling motion.

## tangential_accel_min :: var ParticleProcessMaterial.tangential_accel_min: float
Minimum equivalent of [member tangential_accel_max].

## turbulence_enabled :: var ParticleProcessMaterial.turbulence_enabled: bool
If [code]true[/code], enables turbulence for the particle system. Turbulence can be used to vary particle movement according to its position (based on a 3D noise pattern). In 3D, [GPUParticlesAttractorVectorField3D] with [NoiseTexture3D] can be used as an alternative to turbulence that works in world space and with multiple particle systems reacting in the same way.
[b]Note:[/b] Enabling turbulence has a high performance cost on the GPU. Only enable turbulence on a few particle systems at once at most, and consider disabling it when targeting mobile/web platforms.

## turbulence_influence_max :: var ParticleProcessMaterial.turbulence_influence_max: float
Maximum turbulence influence on each particle.
The actual amount of turbulence influence on each particle is calculated as a random value between [member turbulence_influence_min] and [member turbulence_influence_max] and multiplied by the amount of turbulence influence from [member turbulence_influence_over_life].

## turbulence_influence_min :: var ParticleProcessMaterial.turbulence_influence_min: float
Minimum turbulence influence on each particle.
The actual amount of turbulence influence on each particle is calculated as a random value between [member turbulence_influence_min] and [member turbulence_influence_max] and multiplied by the amount of turbulence influence from [member turbulence_influence_over_life].

## turbulence_influence_over_life :: var ParticleProcessMaterial.turbulence_influence_over_life: Texture2D
Each particle's amount of turbulence will be influenced along this [CurveTexture] over its life time.

## turbulence_initial_displacement_max :: var ParticleProcessMaterial.turbulence_initial_displacement_max: float
Maximum displacement of each particle's spawn position by the turbulence.
The actual amount of displacement will be a factor of the underlying turbulence multiplied by a random value between [member turbulence_initial_displacement_min] and [member turbulence_initial_displacement_max].

## turbulence_initial_displacement_min :: var ParticleProcessMaterial.turbulence_initial_displacement_min: float
Minimum displacement of each particle's spawn position by the turbulence.
The actual amount of displacement will be a factor of the underlying turbulence multiplied by a random value between [member turbulence_initial_displacement_min] and [member turbulence_initial_displacement_max].

## turbulence_noise_scale :: var ParticleProcessMaterial.turbulence_noise_scale: float
This value controls the overall scale/frequency of the turbulence noise pattern.
A small scale will result in smaller features with more detail while a high scale will result in smoother noise with larger features.

## turbulence_noise_speed :: var ParticleProcessMaterial.turbulence_noise_speed: Vector3
A scrolling velocity for the turbulence field. This sets a directional trend for the pattern to move in over time.
The default value of [code]Vector3(0, 0, 0)[/code] turns off the scrolling.

## turbulence_noise_speed_random :: var ParticleProcessMaterial.turbulence_noise_speed_random: float
The in-place rate of change of the turbulence field. This defines how quickly the noise pattern varies over time.
A value of 0.0 will result in a fixed pattern.

## turbulence_noise_strength :: var ParticleProcessMaterial.turbulence_noise_strength: float
The turbulence noise strength. Increasing this will result in a stronger, more contrasting, flow pattern.

## use_rotation_3d :: var ParticleProcessMaterial.use_rotation_3d: bool
Enable the usage of [member rotation_3d_min] and [member rotation_3d_max].

## use_rotation_velocity_3d :: var ParticleProcessMaterial.use_rotation_velocity_3d: bool
Enable 3D rotation velocity.

## use_scale_3d :: var ParticleProcessMaterial.use_scale_3d: bool
Enable the usage of [member scale_3d_min] and [member scale_3d_max].

## velocity_limit_curve :: var ParticleProcessMaterial.velocity_limit_curve: Texture2D
A [CurveTexture] that defines the maximum velocity of a particle during its lifetime.

## velocity_pivot :: var ParticleProcessMaterial.velocity_pivot: Vector3
A pivot point used to calculate radial and orbital velocity of particles.

## get_param :: func ParticleProcessMaterial.get_param(param: int) -> Vector2
Returns the minimum and maximum values of the given [param param] as a vector.
The [code]x[/code] component of the returned vector corresponds to minimum and the [code]y[/code] component corresponds to maximum.

### param :: int

## get_param_max :: func ParticleProcessMaterial.get_param_max(param: int) -> float
Returns the maximum value range for the given parameter.

### param :: int

## get_param_min :: func ParticleProcessMaterial.get_param_min(param: int) -> float
Returns the minimum value range for the given parameter.

### param :: int

## get_param_texture :: func ParticleProcessMaterial.get_param_texture(param: int) -> Texture2D
Returns the [Texture2D] used by the specified parameter.

### param :: int

## get_particle_flag :: func ParticleProcessMaterial.get_particle_flag(particle_flag: int) -> bool
Returns [code]true[/code] if the specified particle flag is enabled.

### particle_flag :: int

## set_param :: func ParticleProcessMaterial.set_param(param: int, value: Vector2) -> void
Sets the minimum and maximum values of the given [param param].
The [code]x[/code] component of the argument vector corresponds to minimum and the [code]y[/code] component corresponds to maximum.

### param :: int

### value :: Vector2

## set_param_max :: func ParticleProcessMaterial.set_param_max(param: int, value: float) -> void
Sets the maximum value range for the given parameter.

### param :: int

### value :: float

## set_param_min :: func ParticleProcessMaterial.set_param_min(param: int, value: float) -> void
Sets the minimum value range for the given parameter.

### param :: int

### value :: float

## set_param_texture :: func ParticleProcessMaterial.set_param_texture(param: int, texture: Texture2D) -> void
Sets the [Texture2D] for the specified [enum Parameter].

### param :: int

### texture :: Texture2D

## set_particle_flag :: func ParticleProcessMaterial.set_particle_flag(particle_flag: int, enable: bool) -> void
Sets the [param particle_flag] to [param enable].

### particle_flag :: int

### enable :: bool

## emission_shape_changed :: func ParticleProcessMaterial.emission_shape_changed() -> void
Emitted when this material's emission shape is changed in any way. This includes changes to [member emission_shape], [member emission_shape_scale], or [member emission_sphere_radius], and any other property that affects the emission shape's offset, size, scale, or orientation.
[b]Note:[/b] This signal is only emitted inside the editor for performance reasons.
