# RDSamplerState :: <Native> class RDSamplerState extends RefCounted
Sampler state (used by [RenderingDevice]).
This object is used by [RenderingDevice].

## anisotropy_max :: var RDSamplerState.anisotropy_max: float
Maximum anisotropy that can be used when sampling. Only effective if [member use_anisotropy] is [code]true[/code]. Higher values result in a sharper sampler at oblique angles, at the cost of performance (due to memory bandwidth). This value may be limited by the graphics hardware in use. Most graphics hardware only supports values up to [code]16.0[/code].
If [member anisotropy_max] is [code]1.0[/code], forcibly disables anisotropy even if [member use_anisotropy] is [code]true[/code].

## border_color :: var RDSamplerState.border_color: RenderingDevice.SamplerBorderColor
The border color that will be returned when sampling outside the sampler's bounds and the [member repeat_u], [member repeat_v] or [member repeat_w] modes have repeating disabled.

## compare_op :: var RDSamplerState.compare_op: RenderingDevice.CompareOperator
The compare operation to use. Only effective if [member enable_compare] is [code]true[/code].

## enable_compare :: var RDSamplerState.enable_compare: bool
If [code]true[/code], returned values will be based on the comparison operation defined in [member compare_op]. This is a hardware-based approach and is therefore faster than performing this manually in a shader. For example, compare operations are used for shadow map rendering by comparing depth values from a shadow sampler.

## lod_bias :: var RDSamplerState.lod_bias: float
The mipmap LOD bias to use. Positive values will make the sampler blurrier at a given distance, while negative values will make the sampler sharper at a given distance (at the risk of looking grainy). Recommended values are between [code]-0.5[/code] and [code]0.0[/code]. Only effective if the sampler has mipmaps available.

## mag_filter :: var RDSamplerState.mag_filter: RenderingDevice.SamplerFilter
The sampler's magnification filter. It is the filtering method used when sampling texels that appear bigger than on-screen pixels.

## max_lod :: var RDSamplerState.max_lod: float
The maximum mipmap LOD bias to display (lowest resolution). Only effective if the sampler has mipmaps available.

## min_filter :: var RDSamplerState.min_filter: RenderingDevice.SamplerFilter
The sampler's minification filter. It is the filtering method used when sampling texels that appear smaller than on-screen pixels.

## min_lod :: var RDSamplerState.min_lod: float
The minimum mipmap LOD bias to display (highest resolution). Only effective if the sampler has mipmaps available.

## mip_filter :: var RDSamplerState.mip_filter: RenderingDevice.SamplerFilter
The filtering method to use for mipmaps.

## repeat_u :: var RDSamplerState.repeat_u: RenderingDevice.SamplerRepeatMode
The repeat mode to use along the U axis of UV coordinates. This affects the returned values if sampling outside the UV bounds.

## repeat_v :: var RDSamplerState.repeat_v: RenderingDevice.SamplerRepeatMode
The repeat mode to use along the V axis of UV coordinates. This affects the returned values if sampling outside the UV bounds.

## repeat_w :: var RDSamplerState.repeat_w: RenderingDevice.SamplerRepeatMode
The repeat mode to use along the W axis of UV coordinates. This affects the returned values if sampling outside the UV bounds. Only effective for 3D samplers.

## unnormalized_uvw :: var RDSamplerState.unnormalized_uvw: bool
If [code]true[/code], the texture will be sampled with coordinates ranging from 0 to the texture's resolution. Otherwise, the coordinates will be normalized and range from 0 to 1.

## use_anisotropy :: var RDSamplerState.use_anisotropy: bool
If [code]true[/code], perform anisotropic sampling. See [member anisotropy_max].
