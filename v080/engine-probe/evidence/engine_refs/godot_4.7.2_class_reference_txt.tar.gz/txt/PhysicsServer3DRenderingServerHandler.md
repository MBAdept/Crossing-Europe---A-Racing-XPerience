# PhysicsServer3DRenderingServerHandler :: <Native> class PhysicsServer3DRenderingServerHandler extends Object
A class used to provide [method PhysicsServer3DExtension._soft_body_update_rendering_server] with a rendering handler for soft bodies.

## _set_aabb :: func PhysicsServer3DRenderingServerHandler._set_aabb(aabb: AABB) -> void
Called by the [PhysicsServer3D] to set the bounding box for the [SoftBody3D].

### aabb :: AABB

## _set_normal :: func PhysicsServer3DRenderingServerHandler._set_normal(vertex_id: int, normal: Vector3) -> void
Called by the [PhysicsServer3D] to set the normal for the [SoftBody3D] vertex at the index specified by [param vertex_id].
[b]Note:[/b] The [param normal] parameter used to be of type [code]const void*[/code] prior to Godot 4.2.

### vertex_id :: int

### normal :: Vector3

## _set_vertex :: func PhysicsServer3DRenderingServerHandler._set_vertex(vertex_id: int, vertex: Vector3) -> void
Called by the [PhysicsServer3D] to set the position for the [SoftBody3D] vertex at the index specified by [param vertex_id].
[b]Note:[/b] The [param vertex] parameter used to be of type [code]const void*[/code] prior to Godot 4.2.

### vertex_id :: int

### vertex :: Vector3

## set_aabb :: func PhysicsServer3DRenderingServerHandler.set_aabb(aabb: AABB) -> void
Sets the bounding box for the [SoftBody3D].

### aabb :: AABB

## set_normal :: func PhysicsServer3DRenderingServerHandler.set_normal(vertex_id: int, normal: Vector3) -> void
Sets the normal for the [SoftBody3D] vertex at the index specified by [param vertex_id].

### vertex_id :: int

### normal :: Vector3

## set_vertex :: func PhysicsServer3DRenderingServerHandler.set_vertex(vertex_id: int, vertex: Vector3) -> void
Sets the position for the [SoftBody3D] vertex at the index specified by [param vertex_id].

### vertex_id :: int

### vertex :: Vector3
