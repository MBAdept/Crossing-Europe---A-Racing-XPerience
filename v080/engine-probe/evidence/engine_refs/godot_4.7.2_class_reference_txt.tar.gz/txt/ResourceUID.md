# ResourceUID :: <Native> class ResourceUID extends Object
A singleton that manages the unique identifiers of all resources within a project.
Resource UIDs (Unique IDentifiers) allow the engine to keep references between resources intact, even if files are renamed or moved. They can be accessed with [code]uid://[/code].
[ResourceUID] keeps track of all registered resource UIDs in a project, generates new UIDs, and converts between their string and integer representations.

## INVALID_ID :: const ResourceUID.INVALID_ID = -1
The value to use for an invalid UID, for example if the resource could not be loaded.
Its text representation is [code]uid://<invalid>[/code].

## add_id :: func ResourceUID.add_id(id: int, path: String) -> void
Adds a new UID value which is mapped to the given resource path.
Fails with an error if the UID already exists, so be sure to check [method has_id] beforehand, or use [method set_id] instead.

### id :: int

### path :: String

## create_id :: func ResourceUID.create_id() -> int
Generates a random resource UID which is guaranteed to be unique within the list of currently loaded UIDs.
In order for this UID to be registered, you must call [method add_id] or [method set_id].

## create_id_for_path :: func ResourceUID.create_id_for_path(path: String) -> int
Like [method create_id], but the UID is seeded with the provided [param path] and project name. UIDs generated for that path will be always the same within the current project.

### path :: String

## ensure_path :: func ResourceUID.ensure_path(path_or_uid: String) -> String
Returns a path, converting [param path_or_uid] if necessary. Fails and returns an empty string if an invalid UID is provided.

### path_or_uid :: String

## get_id_path :: func ResourceUID.get_id_path(id: int) -> String
Returns the path that the given UID value refers to.
Fails with an error if the UID does not exist, so be sure to check [method has_id] beforehand.

### id :: int

## has_id :: func ResourceUID.has_id(id: int) -> bool
Returns whether the given UID value is known to the cache.

### id :: int

## id_to_text :: func ResourceUID.id_to_text(id: int) -> String
Converts the given UID to a [code]uid://[/code] string value.

### id :: int

## path_to_uid :: func ResourceUID.path_to_uid(path: String) -> String
Converts the provided resource [param path] to a UID. Returns the unchanged path if it has no associated UID.

### path :: String

## remove_id :: func ResourceUID.remove_id(id: int) -> void
Removes a loaded UID value from the cache.
Fails with an error if the UID does not exist, so be sure to check [method has_id] beforehand.

### id :: int

## set_id :: func ResourceUID.set_id(id: int, path: String) -> void
Updates the resource path of an existing UID.
Fails with an error if the UID does not exist, so be sure to check [method has_id] beforehand, or use [method add_id] instead.

### id :: int

### path :: String

## text_to_id :: func ResourceUID.text_to_id(text_id: String) -> int
Extracts the UID value from the given [code]uid://[/code] string.

### text_id :: String

## uid_to_path :: func ResourceUID.uid_to_path(uid: String) -> String
Converts the provided [param uid] to a path. Prints an error if the UID is invalid.

### uid :: String
