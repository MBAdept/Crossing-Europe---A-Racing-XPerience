# OpenXRSpatialComponentPersistenceList :: <Native> class OpenXRSpatialComponentPersistenceList extends OpenXRSpatialComponentData
Object for storing the query persistence result data.
Object for storing the query persistence result data when calling [method OpenXRSpatialEntityExtension.query_snapshot].

## get_persistent_state :: func OpenXRSpatialComponentPersistenceList.get_persistent_state(index: int) -> int
Returns the persistent state ([code]XrSpatialPersistenceStateEXT[/code]) for the entity at this [param index].

### index :: int

## get_persistent_uuid :: func OpenXRSpatialComponentPersistenceList.get_persistent_uuid(index: int) -> String
Returns the persistent uuid for the entity at this [param index].

### index :: int
