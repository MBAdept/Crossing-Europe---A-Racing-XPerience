# PanoramaSkyMaterial :: <Native> class PanoramaSkyMaterial extends Material
A material that provides a special texture to a [Sky], usually an HDR panorama.
A resource referenced in a [Sky] that is used to draw a background. [PanoramaSkyMaterial] functions similar to skyboxes in other engines, except it uses an equirectangular sky map instead of a [Cubemap].
Using an HDR panorama is strongly recommended for accurate, high-quality reflections. Godot supports the Radiance HDR ([code].hdr[/code]) and OpenEXR ([code].exr[/code]) image formats for this purpose.
You can use [url=https://danilw.github.io/GLSL-howto/cubemap_to_panorama_js/cubemap_to_panorama.html]this tool[/url] to convert a cubemap to an equirectangular sky map.

## energy_multiplier :: var PanoramaSkyMaterial.energy_multiplier: float
The sky's overall brightness multiplier. Higher values result in a brighter sky.

## filter :: var PanoramaSkyMaterial.filter: bool
A boolean value to determine if the background texture should be filtered or not.

## panorama :: var PanoramaSkyMaterial.panorama: Texture2D
[Texture2D] to be applied to the [PanoramaSkyMaterial].
