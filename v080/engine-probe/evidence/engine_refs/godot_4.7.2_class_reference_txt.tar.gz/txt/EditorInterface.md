# EditorInterface :: <Native> class EditorInterface extends Object
Godot editor's interface.
[EditorInterface] gives you control over Godot editor's window. It allows customizing the window, saving and (re-)loading scenes, rendering mesh previews, inspecting and editing resources and objects, and provides access to [EditorSettings], [EditorFileSystem], [EditorResourcePreview], [ScriptEditor], the editor viewport, and information about scenes.
[b]Note:[/b] This class shouldn't be instantiated directly. Instead, access the singleton directly by its name.
[codeblocks]
[gdscript]
var editor_settings = EditorInterface.get_editor_settings()
[/gdscript]
[csharp]
// In C# you can access it via the static Singleton property.
EditorSettings settings = EditorInterface.Singleton.GetEditorSettings();
[/csharp]
[/codeblocks]

## distraction_free_mode :: var EditorInterface.distraction_free_mode: bool
If [code]true[/code], enables distraction-free mode which hides side docks to increase the space available for the main view.

## movie_maker_enabled :: var EditorInterface.movie_maker_enabled: bool
If [code]true[/code], the Movie Maker mode is enabled in the editor. See [MovieWriter] for more information.

## add_root_node :: func EditorInterface.add_root_node(node: Node) -> void
Makes [param node] root of the currently opened scene. Only works if the scene is empty. If the [param node] is a scene instance, an inheriting scene will be created.

### node :: Node

## close_scene :: func EditorInterface.close_scene() -> int
Closes the currently active scene, discarding any pending changes in the process. Returns [constant OK] on success or [constant ERR_DOES_NOT_EXIST] if there is no scene to close.

## edit_node :: func EditorInterface.edit_node(node: Node) -> void
Edits the given [Node]. The node will be also selected if it's inside the scene tree.

### node :: Node

## edit_resource :: func EditorInterface.edit_resource(resource: Resource) -> void
Edits the given [Resource]. If the resource is a [Script] you can also edit it with [method edit_script] to specify the line and column position.

### resource :: Resource

## edit_script :: func EditorInterface.edit_script(script: Script, line: int = -1, column: int = 0, grab_focus: bool = true) -> void
Edits the given [Script]. The line and column on which to open the script can also be specified. The script will be open with the user-configured editor for the script's language which may be an external editor.

### script :: Script

### line :: int

### column :: int

### grab_focus :: bool

## get_base_control :: func EditorInterface.get_base_control() -> Control
Returns the main container of Godot editor's window. For example, you can use it to retrieve the size of the container and place your controls accordingly.
[b]Warning:[/b] Removing and freeing this node will render the editor useless and may cause a crash.

## get_command_palette :: func EditorInterface.get_command_palette() -> EditorCommandPalette
Returns the editor's [EditorCommandPalette] instance.
[b]Warning:[/b] Removing and freeing this node will render a part of the editor useless and may cause a crash.

## get_current_directory :: func EditorInterface.get_current_directory() -> String
Returns the current directory being viewed in the [FileSystemDock]. If a file is selected, its base directory will be returned using [method String.get_base_dir] instead.

## get_current_feature_profile :: func EditorInterface.get_current_feature_profile() -> String
Returns the name of the currently activated feature profile. If the default profile is currently active, an empty string is returned instead.
In order to get a reference to the [EditorFeatureProfile], you must load the feature profile using [method EditorFeatureProfile.load_from_file].
[b]Note:[/b] Feature profiles created via the user interface are loaded from the [code]feature_profiles[/code] directory, as a file with the [code].profile[/code] extension. The editor configuration folder can be found by using [method EditorPaths.get_config_dir].

## get_current_path :: func EditorInterface.get_current_path() -> String
Returns the current path being viewed in the [FileSystemDock].

## get_edited_scene_root :: func EditorInterface.get_edited_scene_root() -> Node
Returns the edited (current) scene's root [Node].

## get_editor_language :: func EditorInterface.get_editor_language() -> String
Returns the language currently used for the editor interface.

## get_editor_main_screen :: func EditorInterface.get_editor_main_screen() -> VBoxContainer
Returns the editor control responsible for main screen plugins and tools. Use it with plugins that implement [method EditorPlugin._has_main_screen].
[b]Note:[/b] This node is a [VBoxContainer], which means that if you add a [Control] child to it, you need to set the child's [member Control.size_flags_vertical] to [constant Control.SIZE_EXPAND_FILL] to make it use the full available space.
[b]Warning:[/b] Removing and freeing this node will render a part of the editor useless and may cause a crash.

## get_editor_paths :: func EditorInterface.get_editor_paths() -> EditorPaths
Returns the [EditorPaths] singleton.

## get_editor_scale :: func EditorInterface.get_editor_scale() -> float
Returns the actual scale of the editor UI ([code]1.0[/code] being 100% scale). This can be used to adjust position and dimensions of the UI added by plugins.
[b]Note:[/b] This value is set via the [member EditorSettings.interface/editor/appearance/display_scale] and [member EditorSettings.interface/editor/appearance/custom_display_scale] settings. The editor must be restarted for changes to be properly applied.

## get_editor_settings :: func EditorInterface.get_editor_settings() -> EditorSettings
Returns the editor's [EditorSettings] instance.

## get_editor_theme :: func EditorInterface.get_editor_theme() -> Theme
Returns the editor's [Theme].
[b]Note:[/b] When creating custom editor UI, prefer accessing theme items directly from your GUI nodes using the [code]get_theme_*[/code] methods.

## get_editor_toaster :: func EditorInterface.get_editor_toaster() -> EditorToaster
Returns the editor's [EditorToaster].

## get_editor_undo_redo :: func EditorInterface.get_editor_undo_redo() -> EditorUndoRedoManager
Returns the editor's [EditorUndoRedoManager].

## get_editor_viewport_2d :: func EditorInterface.get_editor_viewport_2d() -> SubViewport
Returns the 2D editor [SubViewport]. It does not have a camera. Instead, the view transforms are done directly and can be accessed with [member Viewport.global_canvas_transform].

## get_editor_viewport_3d :: func EditorInterface.get_editor_viewport_3d(idx: int = 0) -> SubViewport
Returns the specified 3D editor [SubViewport], from [code]0[/code] to [code]3[/code]. The viewport can be used to access the active editor cameras with [method Viewport.get_camera_3d].

### idx :: int

## get_file_system_dock :: func EditorInterface.get_file_system_dock() -> FileSystemDock
Returns the editor's [FileSystemDock] instance.
[b]Warning:[/b] Removing and freeing this node will render a part of the editor useless and may cause a crash.

## get_inspector :: func EditorInterface.get_inspector() -> EditorInspector
Returns the editor's [EditorInspector] instance.
[b]Warning:[/b] Removing and freeing this node will render a part of the editor useless and may cause a crash.

## get_node_3d_rotate_snap :: func EditorInterface.get_node_3d_rotate_snap() -> float
Returns the amount of degrees the 3D editor's rotational snapping is set to.

## get_node_3d_scale_snap :: func EditorInterface.get_node_3d_scale_snap() -> float
Returns the amount of units the 3D editor's scale snapping is set to.

## get_node_3d_translate_snap :: func EditorInterface.get_node_3d_translate_snap() -> float
Returns the amount of units the 3D editor's translation snapping is set to.

## get_open_scene_roots :: func EditorInterface.get_open_scene_roots() -> Node[]
Returns an array with references to the root nodes of the currently opened scenes.

## get_open_scenes :: func EditorInterface.get_open_scenes() -> PackedStringArray
Returns an array with the file paths of the currently opened scenes.

## get_playing_scene :: func EditorInterface.get_playing_scene() -> String
Returns the name of the scene that is being played. If no scene is currently being played, returns an empty string.

## get_resource_filesystem :: func EditorInterface.get_resource_filesystem() -> EditorFileSystem
Returns the editor's [EditorFileSystem] instance.

## get_resource_previewer :: func EditorInterface.get_resource_previewer() -> EditorResourcePreview
Returns the editor's [EditorResourcePreview] instance.

## get_script_editor :: func EditorInterface.get_script_editor() -> ScriptEditor
Returns the editor's [ScriptEditor] instance.
[b]Warning:[/b] Removing and freeing this node will render a part of the editor useless and may cause a crash.

## get_selected_paths :: func EditorInterface.get_selected_paths() -> PackedStringArray
Returns an array containing the paths of the currently selected files (and directories) in the [FileSystemDock].

## get_selection :: func EditorInterface.get_selection() -> EditorSelection
Returns the editor's [EditorSelection] instance.

## get_unsaved_scenes :: func EditorInterface.get_unsaved_scenes() -> PackedStringArray
Returns an array of file paths of currently unsaved scenes.

## inspect_object :: func EditorInterface.inspect_object(object: Object, for_property: String = "", inspector_only: bool = false) -> void
Shows the given property on the given [param object] in the editor's Inspector dock. If [param inspector_only] is [code]true[/code], plugins will not attempt to edit [param object].

### object :: Object

### for_property :: String

### inspector_only :: bool

## is_multi_window_enabled :: func EditorInterface.is_multi_window_enabled() -> bool
Returns [code]true[/code] if multiple window support is enabled in the editor. Multiple window support is enabled if [i]all[/i] of these statements are true:
- [member EditorSettings.interface/multi_window/enable] is [code]true[/code].
- [member EditorSettings.interface/editor/display/single_window_mode] is [code]false[/code].
- [member Viewport.gui_embed_subwindows] is [code]false[/code]. This is forced to [code]true[/code] on platforms that don't support multiple windows such as Web, or when the [code]--single-window[/code] [url=https://docs.godotengine.org/en/4.7/tutorials/editor/command_line_tutorial.html]command line argument[/url] is used.

## is_node_3d_snap_enabled :: func EditorInterface.is_node_3d_snap_enabled() -> bool
Returns [code]true[/code] if the 3D editor currently has snapping mode enabled, and [code]false[/code] otherwise.

## is_object_edited :: func EditorInterface.is_object_edited(object: Object) -> bool
Returns [code]true[/code] if the object has been marked as edited through [method set_object_edited].

### object :: Object

## is_playing_scene :: func EditorInterface.is_playing_scene() -> bool
Returns [code]true[/code] if a scene is currently being played, [code]false[/code] otherwise. Paused scenes are considered as being played.

## is_plugin_enabled :: func EditorInterface.is_plugin_enabled(plugin: String) -> bool
Returns [code]true[/code] if the specified [param plugin] is enabled. The plugin name is the same as its directory name.

### plugin :: String

## make_mesh_previews :: func EditorInterface.make_mesh_previews(meshes: Mesh[], preview_size: int) -> Texture2D[]
Returns mesh previews rendered at the given size as an [Array] of [Texture2D]s.

### meshes :: Mesh[]

### preview_size :: int

## mark_scene_as_unsaved :: func EditorInterface.mark_scene_as_unsaved() -> void
Marks the current scene tab as unsaved.

## open_scene_from_path :: func EditorInterface.open_scene_from_path(scene_filepath: String, set_inherited: bool = false) -> void
Opens the scene at the given path. If [param set_inherited] is [code]true[/code], creates a new inherited scene.

### scene_filepath :: String

### set_inherited :: bool

## play_current_scene :: func EditorInterface.play_current_scene() -> void
Plays the currently active scene.

## play_custom_scene :: func EditorInterface.play_custom_scene(scene_filepath: String) -> void
Plays the scene specified by its filepath.

### scene_filepath :: String

## play_main_scene :: func EditorInterface.play_main_scene() -> void
Plays the main scene.

## popup_create_dialog :: func EditorInterface.popup_create_dialog(callback: Callable, base_type: StringName = "", current_type: String = "", dialog_title: String = "", type_blocklist: StringName[] = []) -> void
Pops up an editor dialog for creating an object.
The [param callback] must take a single argument of type [String], which will contain the type name of the selected object (or the script path of the type, if the type is created from a script), or be an empty string if no item is selected.
The [param base_type] specifies the base type of objects to display. For example, if you set this to "Resource", all types derived from [Resource] will display in the create dialog.
The [param current_type] will be passed in the search box of the create dialog, and the specified type can be immediately selected when the dialog pops up. If the [param current_type] is not derived from [param base_type], there will be no result of the type in the dialog.
The [param dialog_title] allows you to define a custom title for the dialog. This is useful if you want to accurately hint the usage of the dialog. If the [param dialog_title] is an empty string, the dialog will use "Create New 'Base Type'" as the default title.
The [param type_blocklist] contains a list of type names, and the types in the blocklist will be hidden from the create dialog.
[b]Note:[/b] Trying to list the base type in the [param type_blocklist] will hide all types derived from the base type from the create dialog.

### callback :: Callable

### base_type :: StringName

### current_type :: String

### dialog_title :: String

### type_blocklist :: StringName[]

## popup_dialog :: func EditorInterface.popup_dialog(dialog: Window, rect: Rect2i = Rect2i(0, 0, 0, 0)) -> void
Pops up the [param dialog] in the editor UI with [method Window.popup_exclusive]. The dialog must have no current parent, otherwise the method fails.
See also [method Window.set_unparent_when_invisible].

### dialog :: Window

### rect :: Rect2i

## popup_dialog_centered :: func EditorInterface.popup_dialog_centered(dialog: Window, minsize: Vector2i = Vector2i(0, 0)) -> void
Pops up the [param dialog] in the editor UI with [method Window.popup_exclusive_centered]. The dialog must have no current parent, otherwise the method fails.
See also [method Window.set_unparent_when_invisible].

### dialog :: Window

### minsize :: Vector2i

## popup_dialog_centered_clamped :: func EditorInterface.popup_dialog_centered_clamped(dialog: Window, minsize: Vector2i = Vector2i(0, 0), fallback_ratio: float = 0.75) -> void
Pops up the [param dialog] in the editor UI with [method Window.popup_exclusive_centered_clamped]. The dialog must have no current parent, otherwise the method fails.
See also [method Window.set_unparent_when_invisible].

### dialog :: Window

### minsize :: Vector2i

### fallback_ratio :: float

## popup_dialog_centered_ratio :: func EditorInterface.popup_dialog_centered_ratio(dialog: Window, ratio: float = 0.8) -> void
Pops up the [param dialog] in the editor UI with [method Window.popup_exclusive_centered_ratio]. The dialog must have no current parent, otherwise the method fails.
See also [method Window.set_unparent_when_invisible].

### dialog :: Window

### ratio :: float

## popup_method_selector :: func EditorInterface.popup_method_selector(object: Object, callback: Callable, current_value: String = "") -> void
Pops up an editor dialog for selecting a method from [param object]. The [param callback] must take a single argument of type [String] which will contain the name of the selected method or be empty if the dialog is canceled. If [param current_value] is provided, the method will be selected automatically in the method list, if it exists.

### object :: Object

### callback :: Callable

### current_value :: String

## popup_node_selector :: func EditorInterface.popup_node_selector(callback: Callable, valid_types: StringName[] = [], current_value: Node = null) -> void
Pops up an editor dialog for selecting a [Node] from the edited scene. The [param callback] must take a single argument of type [NodePath]. It is called on the selected [NodePath] or the empty path [code]^""[/code] if the dialog is canceled. If [param valid_types] is provided, the dialog will only show Nodes that match one of the listed Node types. If [param current_value] is provided, the Node will be automatically selected in the tree, if it exists.
[b]Example:[/b] Display the node selection dialog as soon as this node is added to the tree for the first time:
[codeblock]
func _ready():
	if Engine.is_editor_hint():
		EditorInterface.popup_node_selector(_on_node_selected, ["Button"])

func _on_node_selected(node_path):
	if node_path.is_empty():
		print("node selection canceled")
	else:
		print("selected ", node_path)
[/codeblock]

### callback :: Callable

### valid_types :: StringName[]

### current_value :: Node

## popup_property_selector :: func EditorInterface.popup_property_selector(object: Object, callback: Callable, type_filter: PackedInt32Array = PackedInt32Array(), current_value: String = "") -> void
Pops up an editor dialog for selecting properties from [param object]. The [param callback] must take a single argument of type [NodePath]. It is called on the selected property path (see [method NodePath.get_as_property_path]) or the empty path [code]^""[/code] if the dialog is canceled. If [param type_filter] is provided, the dialog will only show properties that match one of the listed [enum Variant.Type] values. If [param current_value] is provided, the property will be selected automatically in the property list, if it exists.
[codeblock]
func _ready():
	if Engine.is_editor_hint():
		EditorInterface.popup_property_selector(this, _on_property_selected, [TYPE_INT])

func _on_property_selected(property_path):
	if property_path.is_empty():
		print("property selection canceled")
	else:
		print("selected ", property_path)
[/codeblock]

### object :: Object

### callback :: Callable

### type_filter :: PackedInt32Array

### current_value :: String

## popup_quick_open :: func EditorInterface.popup_quick_open(callback: Callable, base_types: StringName[] = []) -> void
Pops up an editor dialog for quick selecting a resource file. The [param callback] must take a single argument of type [String] which will contain the path of the selected resource or be empty if the dialog is canceled. If [param base_types] is provided, the dialog will only show resources that match these types. Only types deriving from [Resource] are supported.

### callback :: Callable

### base_types :: StringName[]

## reload_scene_from_path :: func EditorInterface.reload_scene_from_path(scene_filepath: String) -> void
Reloads the scene at the given path. Fails if the scene is not open.

### scene_filepath :: String

## restart_editor :: func EditorInterface.restart_editor(save: bool = true) -> void
Restarts the editor. This closes the editor and then opens the same project. If [param save] is [code]true[/code], the project will be saved before restarting.

### save :: bool

## save_all_scenes :: func EditorInterface.save_all_scenes() -> void
Saves all opened scenes in the editor.

## save_scene :: func EditorInterface.save_scene() -> int
Saves the currently active scene. Returns either [constant OK] or [constant ERR_CANT_CREATE].

## save_scene_as :: func EditorInterface.save_scene_as(path: String, with_preview: bool = true) -> void
Saves the currently active scene as a file at [param path].

### path :: String

### with_preview :: bool

## select_file :: func EditorInterface.select_file(file: String) -> void
Selects the file, with the path provided by [param file], in the FileSystem dock.

### file :: String

## set_current_feature_profile :: func EditorInterface.set_current_feature_profile(profile_name: String) -> void
Selects and activates the specified feature profile with the given [param profile_name]. Set [param profile_name] to an empty string to reset to the default feature profile.
A feature profile can be created programmatically using the [EditorFeatureProfile] class.
[b]Note:[/b] The feature profile that gets activated must be located in the [code]feature_profiles[/code] directory, as a file with the [code].profile[/code] extension. If a profile could not be found, an error occurs. The editor configuration folder can be found by using [method EditorPaths.get_config_dir].

### profile_name :: String

## set_main_screen_editor :: func EditorInterface.set_main_screen_editor(name: String) -> void
Sets the editor's current main screen to the one specified in [param name]. [param name] must match the title of the tab in question exactly (e.g. [code]2D[/code], [code]3D[/code], [code skip-lint]Script[/code], [code]Game[/code], or [code]Asset Store[/code] for default tabs).

### name :: String

## set_object_edited :: func EditorInterface.set_object_edited(object: Object, edited: bool) -> void
If [param edited] is [code]true[/code], the object is marked as edited.
[b]Note:[/b] This is primarily used by the editor for [Resource] based objects to track their modified state. For example, any changes to an open scene, a resource in the inspector, or an edited script will cause this method to be called with [code]true[/code]. Saving the scene, script, or resource resets the edited state by calling this method with [code]false[/code].
[b]Note:[/b] Each call to this method increments the object's edited version. This is used to track changes in the editor and to trigger when thumbnails should be regenerated for resources.

### object :: Object

### edited :: bool

## set_plugin_enabled :: func EditorInterface.set_plugin_enabled(plugin: String, enabled: bool) -> void
Sets the enabled status of a plugin. The plugin name is the same as its directory name.

### plugin :: String

### enabled :: bool

## stop_playing_scene :: func EditorInterface.stop_playing_scene() -> void
Stops the scene that is currently playing.
