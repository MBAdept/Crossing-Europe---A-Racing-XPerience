# ScrollBar :: <Native> class ScrollBar extends Range
Abstract base class for scrollbars.
Abstract base class for scrollbars, typically used to navigate through content that extends beyond the visible area of a control. Scrollbars are [Range]-based controls.

## custom_step :: var ScrollBar.custom_step: float
Overrides the step used when clicking increment and decrement buttons or when using arrow keys when the [ScrollBar] is focused.

## focus_mode :: var ScrollBar.focus_mode: Control.FocusMode

## step :: var ScrollBar.step: float

## decrement :: <Theme> var ScrollBar.decrement: Texture2D
Icon used as a button to scroll the [ScrollBar] left/up. Supports custom step using the [member ScrollBar.custom_step] property.

## decrement_highlight :: <Theme> var ScrollBar.decrement_highlight: Texture2D
Displayed when the mouse cursor hovers over the decrement button.

## decrement_pressed :: <Theme> var ScrollBar.decrement_pressed: Texture2D
Displayed when the decrement button is being pressed.

## increment :: <Theme> var ScrollBar.increment: Texture2D
Icon used as a button to scroll the [ScrollBar] right/down. Supports custom step using the [member ScrollBar.custom_step] property.

## increment_highlight :: <Theme> var ScrollBar.increment_highlight: Texture2D
Displayed when the mouse cursor hovers over the increment button.

## increment_pressed :: <Theme> var ScrollBar.increment_pressed: Texture2D
Displayed when the increment button is being pressed.

## grabber :: <Theme> var ScrollBar.grabber: StyleBox
Used as texture for the grabber, the draggable element representing current scroll.

## grabber_highlight :: <Theme> var ScrollBar.grabber_highlight: StyleBox
Used when the mouse hovers over the grabber.

## grabber_pressed :: <Theme> var ScrollBar.grabber_pressed: StyleBox
Used when the grabber is being dragged.

## scroll :: <Theme> var ScrollBar.scroll: StyleBox
Used as background of this [ScrollBar].

## scroll_focus :: <Theme> var ScrollBar.scroll_focus: StyleBox
Used as background when the [ScrollBar] has the GUI focus.

## scrolling :: func ScrollBar.scrolling() -> void
Emitted when the scrollbar is being scrolled.
