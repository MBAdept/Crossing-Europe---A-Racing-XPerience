# WebRTCPeerConnectionExtension :: <Native> class WebRTCPeerConnectionExtension extends WebRTCPeerConnection


## _add_ice_candidate :: func WebRTCPeerConnectionExtension._add_ice_candidate(sdp_mid_name: String, sdp_mline_index: int, sdp_name: String) -> int

### sdp_mid_name :: String

### sdp_mline_index :: int

### sdp_name :: String

## _close :: func WebRTCPeerConnectionExtension._close() -> void

## _create_data_channel :: func WebRTCPeerConnectionExtension._create_data_channel(label: String, config: Dictionary) -> WebRTCDataChannel

### label :: String

### config :: Dictionary

## _create_offer :: func WebRTCPeerConnectionExtension._create_offer() -> int

## _get_connection_state :: func WebRTCPeerConnectionExtension._get_connection_state() -> int

## _get_gathering_state :: func WebRTCPeerConnectionExtension._get_gathering_state() -> int

## _get_signaling_state :: func WebRTCPeerConnectionExtension._get_signaling_state() -> int

## _initialize :: func WebRTCPeerConnectionExtension._initialize(config: Dictionary) -> int

### config :: Dictionary

## _poll :: func WebRTCPeerConnectionExtension._poll() -> int

## _set_local_description :: func WebRTCPeerConnectionExtension._set_local_description(type: String, sdp: String) -> int

### type :: String

### sdp :: String

## _set_remote_description :: func WebRTCPeerConnectionExtension._set_remote_description(type: String, sdp: String) -> int

### type :: String

### sdp :: String
