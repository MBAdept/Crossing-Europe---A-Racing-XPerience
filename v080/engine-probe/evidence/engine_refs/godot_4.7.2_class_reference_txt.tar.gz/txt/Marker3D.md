# Marker3D :: <Native> class Marker3D extends Node3D
Generic 3D position hint for editing.
Generic 3D position hint for editing. It's just like a plain [Node3D], but it displays as a cross in the 3D editor at all times.

## gizmo_extents :: var Marker3D.gizmo_extents: float
Size of the gizmo cross that appears in the editor.
