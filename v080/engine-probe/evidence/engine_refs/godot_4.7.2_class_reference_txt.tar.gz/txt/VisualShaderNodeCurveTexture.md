# VisualShaderNodeCurveTexture :: <Native> class VisualShaderNodeCurveTexture extends VisualShaderNodeResizableBase
Performs a [CurveTexture] lookup within the visual shader graph.
Comes with a built-in editor for texture's curves.

## texture :: var VisualShaderNodeCurveTexture.texture: CurveTexture
The source texture.
