# XRPositionalTracker :: <Native> class XRPositionalTracker extends XRTracker
A tracked object.
An instance of this object represents a device that is tracked, such as a controller or anchor point. HMDs aren't represented here as they are handled internally.
As controllers are turned on and the [XRInterface] detects them, instances of this object are automatically added to this list of active tracking objects accessible through the [XRServer].
The [XRNode3D] and [XRAnchor3D] both consume objects of this type and should be used in your project. The positional trackers are just under-the-hood objects that make this all work. These are mostly exposed so that GDExtension-based interfaces can interact with them.

## TRACKER_HAND_UNKNOWN :: const XRPositionalTracker.TRACKER_HAND_UNKNOWN: TrackerHand = 0
The hand this tracker is held in is unknown or not applicable.

## TRACKER_HAND_LEFT :: const XRPositionalTracker.TRACKER_HAND_LEFT: TrackerHand = 1
This tracker is the left hand controller.

## TRACKER_HAND_RIGHT :: const XRPositionalTracker.TRACKER_HAND_RIGHT: TrackerHand = 2
This tracker is the right hand controller.

## TRACKER_HAND_MAX :: const XRPositionalTracker.TRACKER_HAND_MAX: TrackerHand = 3
Represents the size of the [enum TrackerHand] enum.

## hand :: var XRPositionalTracker.hand: XRPositionalTracker.TrackerHand
Defines which hand this tracker relates to.

## profile :: var XRPositionalTracker.profile: String
The profile associated with this tracker, interface dependent but will indicate the type of controller being tracked.

## get_input :: func XRPositionalTracker.get_input(name: StringName) -> Variant
Returns an input for this tracker. It can return a boolean, float or [Vector2] value depending on whether the input is a button, trigger or thumbstick/thumbpad.

### name :: StringName

## get_pose :: func XRPositionalTracker.get_pose(name: StringName) -> XRPose
Returns the current [XRPose] state object for the bound [param name] pose.

### name :: StringName

## has_pose :: func XRPositionalTracker.has_pose(name: StringName) -> bool
Returns [code]true[/code] if the tracker is available and is currently tracking the bound [param name] pose.

### name :: StringName

## invalidate_pose :: func XRPositionalTracker.invalidate_pose(name: StringName) -> void
Marks this pose as invalid, we don't clear the last reported state but it allows users to decide if trackers need to be hidden if we lose tracking or just remain at their last known position.

### name :: StringName

## set_input :: func XRPositionalTracker.set_input(name: StringName, value: Variant) -> void
Changes the value for the given input. This method is called by an [XRInterface] implementation and should not be used directly.

### name :: StringName

### value :: Variant

## set_pose :: func XRPositionalTracker.set_pose(name: StringName, transform: Transform3D, linear_velocity: Vector3, angular_velocity: Vector3, tracking_confidence: int) -> void
Sets the transform, linear velocity, angular velocity and tracking confidence for the given pose. This method is called by an [XRInterface] implementation and should not be used directly.

### name :: StringName

### transform :: Transform3D

### linear_velocity :: Vector3

### angular_velocity :: Vector3

### tracking_confidence :: int

## button_pressed :: func XRPositionalTracker.button_pressed(action_name: String) -> void
Emitted when a button on this tracker is pressed. Note that many XR runtimes allow other inputs to be mapped to buttons.

### action_name :: String

## button_released :: func XRPositionalTracker.button_released(action_name: String) -> void
Emitted when a button on this tracker is released.

### action_name :: String

## input_float_changed :: func XRPositionalTracker.input_float_changed(action_name: String, value: float) -> void
Emitted when a trigger or similar input on this tracker changes value.

### action_name :: String

### value :: float

## input_vector2_changed :: func XRPositionalTracker.input_vector2_changed(action_name: String, vector: Vector2) -> void
Emitted when a thumbstick or thumbpad on this tracker moves.

### action_name :: String

### vector :: Vector2

## pose_changed :: func XRPositionalTracker.pose_changed(pose: XRPose) -> void
Emitted when the state of a pose tracked by this tracker changes.

### pose :: XRPose

## pose_lost_tracking :: func XRPositionalTracker.pose_lost_tracking(pose: XRPose) -> void
Emitted when a pose tracked by this tracker stops getting updated tracking data.

### pose :: XRPose

## profile_changed :: func XRPositionalTracker.profile_changed(role: String) -> void
Emitted when the profile of our tracker changes.

### role :: String
