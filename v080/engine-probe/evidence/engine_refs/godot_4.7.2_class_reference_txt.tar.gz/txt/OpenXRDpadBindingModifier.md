# OpenXRDpadBindingModifier :: <Native> class OpenXRDpadBindingModifier extends OpenXRIPBindingModifier
The DPad binding modifier converts an axis input to a dpad output.
The DPad binding modifier converts an axis input to a dpad output, emulating a DPad. New input paths for each dpad direction will be added to the interaction profile. When bound to actions the DPad emulation will be activated. You should [b]not[/b] combine dpad inputs with normal inputs in the same action set for the same control, this will result in an error being returned when suggested bindings are submitted to OpenXR.
See [url=https://registry.khronos.org/OpenXR/specs/1.1/html/xrspec.html#XR_EXT_dpad_binding]XR_EXT_dpad_binding[/url] for in-depth details.
[b]Note:[/b] If the DPad binding modifier extension is enabled, all dpad binding paths will be available in the action map. Adding the modifier to an interaction profile allows you to further customize the behavior.

## action_set :: var OpenXRDpadBindingModifier.action_set: OpenXRActionSet
Action set for which this dpad binding modifier is active.

## center_region :: var OpenXRDpadBindingModifier.center_region: float
Center region in which our center position of our dpad return [code]true[/code].

## input_path :: var OpenXRDpadBindingModifier.input_path: String
Input path for this dpad binding modifier.

## is_sticky :: var OpenXRDpadBindingModifier.is_sticky: bool
If [code]false[/code], when the joystick enters a new dpad zone this becomes [code]true[/code].
If [code]true[/code], when the joystick remains in active dpad zone, this remains [code]true[/code] even if we overlap with another zone.

## off_haptic :: var OpenXRDpadBindingModifier.off_haptic: OpenXRHapticBase
Haptic pulse to emit when the user releases the input.

## on_haptic :: var OpenXRDpadBindingModifier.on_haptic: OpenXRHapticBase
Haptic pulse to emit when the user presses the input.

## threshold :: var OpenXRDpadBindingModifier.threshold: float
When our input value is equal or larger than this value, our dpad in that direction becomes [code]true[/code]. It stays [code]true[/code] until it falls under the [member threshold_released] value.

## threshold_released :: var OpenXRDpadBindingModifier.threshold_released: float
When our input value falls below this, our output becomes [code]false[/code].

## wedge_angle :: var OpenXRDpadBindingModifier.wedge_angle: float
The angle of each wedge that identifies the 4 directions of the emulated dpad.
