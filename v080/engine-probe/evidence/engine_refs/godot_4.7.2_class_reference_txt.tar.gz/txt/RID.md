# RID :: <Native> class RID
A handle for a [Resource]'s unique identifier.
The RID [Variant] type is used to access a low-level resource by its unique ID. RIDs are opaque, which means they do not grant access to the resource by themselves. They are used by the low-level server classes, such as [DisplayServer], [RenderingServer], [TextServer], etc.
A low-level resource may correspond to a high-level [Resource], such as [Texture] or [Mesh].
[b]Note:[/b] RIDs are only useful during the current session. It won't correspond to a similar resource if sent over a network, or loaded from a file at a later time.
[b]Note:[/b] In a boolean context, an RID will evaluate to [code]false[/code] if it has the invalid ID [code]0[/code]. Otherwise, an RID will always evaluate to [code]true[/code]. This is equivalent to calling [method is_valid].

## get_id :: func RID.get_id() -> int
Returns the ID of the referenced low-level resource.

## is_valid :: func RID.is_valid() -> bool
Returns [code]true[/code] if the [RID] is not [code]0[/code].

## RID :: func RID.RID() -> RID
Constructs an empty [RID] with the invalid ID [code]0[/code].

## RID :: func RID.RID(from: RID) -> RID
Constructs an [RID] as a copy of the given [RID].

### from :: RID

## operator != :: func RID.operator !=(right: RID) -> bool
Returns [code]true[/code] if the [RID]s are not equal.

### right :: RID

## operator < :: func RID.operator <(right: RID) -> bool
Returns [code]true[/code] if the [RID]'s ID is less than [param right]'s ID.

### right :: RID

## operator <= :: func RID.operator <=(right: RID) -> bool
Returns [code]true[/code] if the [RID]'s ID is less than or equal to [param right]'s ID.

### right :: RID

## operator == :: func RID.operator ==(right: RID) -> bool
Returns [code]true[/code] if both [RID]s are equal, which means they both refer to the same low-level resource.

### right :: RID

## operator > :: func RID.operator >(right: RID) -> bool
Returns [code]true[/code] if the [RID]'s ID is greater than [param right]'s ID.

### right :: RID

## operator >= :: func RID.operator >=(right: RID) -> bool
Returns [code]true[/code] if the [RID]'s ID is greater than or equal to [param right]'s ID.

### right :: RID
