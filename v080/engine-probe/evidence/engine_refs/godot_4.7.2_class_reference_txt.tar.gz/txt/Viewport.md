# Viewport :: <Native> class Viewport extends Node
Abstract base class for viewports. Encapsulates drawing and interaction with a game world.
A [Viewport] creates a different view into the screen, or a sub-view inside another viewport. Child 2D nodes will display on it, and child Camera3D 3D nodes will render on it too.
Optionally, a viewport can have its own 2D or 3D world, so it doesn't share what it draws with other viewports.
Viewports can also choose to be audio listeners, so they generate positional audio depending on a 2D or 3D camera child of it.
Also, viewports can be assigned to different screens in case the devices have multiple screens.
Finally, viewports can also behave as render targets, in which case they will not be visible unless the associated texture is used to draw.

## SHADOW_ATLAS_QUADRANT_SUBDIV_DISABLED :: const Viewport.SHADOW_ATLAS_QUADRANT_SUBDIV_DISABLED: PositionalShadowAtlasQuadrantSubdiv = 0
This quadrant will not be used.

## SHADOW_ATLAS_QUADRANT_SUBDIV_1 :: const Viewport.SHADOW_ATLAS_QUADRANT_SUBDIV_1: PositionalShadowAtlasQuadrantSubdiv = 1
This quadrant will only be used by one shadow map.

## SHADOW_ATLAS_QUADRANT_SUBDIV_4 :: const Viewport.SHADOW_ATLAS_QUADRANT_SUBDIV_4: PositionalShadowAtlasQuadrantSubdiv = 2
This quadrant will be split in 4 and used by up to 4 shadow maps.

## SHADOW_ATLAS_QUADRANT_SUBDIV_16 :: const Viewport.SHADOW_ATLAS_QUADRANT_SUBDIV_16: PositionalShadowAtlasQuadrantSubdiv = 3
This quadrant will be split 16 ways and used by up to 16 shadow maps.

## SHADOW_ATLAS_QUADRANT_SUBDIV_64 :: const Viewport.SHADOW_ATLAS_QUADRANT_SUBDIV_64: PositionalShadowAtlasQuadrantSubdiv = 4
This quadrant will be split 64 ways and used by up to 64 shadow maps.

## SHADOW_ATLAS_QUADRANT_SUBDIV_256 :: const Viewport.SHADOW_ATLAS_QUADRANT_SUBDIV_256: PositionalShadowAtlasQuadrantSubdiv = 5
This quadrant will be split 256 ways and used by up to 256 shadow maps. Unless the [member positional_shadow_atlas_size] is very high, the shadows in this quadrant will be very low resolution.

## SHADOW_ATLAS_QUADRANT_SUBDIV_1024 :: const Viewport.SHADOW_ATLAS_QUADRANT_SUBDIV_1024: PositionalShadowAtlasQuadrantSubdiv = 6
This quadrant will be split 1024 ways and used by up to 1024 shadow maps. Unless the [member positional_shadow_atlas_size] is very high, the shadows in this quadrant will be very low resolution.

## SHADOW_ATLAS_QUADRANT_SUBDIV_MAX :: const Viewport.SHADOW_ATLAS_QUADRANT_SUBDIV_MAX: PositionalShadowAtlasQuadrantSubdiv = 7
Represents the size of the [enum PositionalShadowAtlasQuadrantSubdiv] enum.

## SCALING_3D_MODE_BILINEAR :: const Viewport.SCALING_3D_MODE_BILINEAR: Scaling3DMode = 0
Use bilinear scaling for the viewport's 3D buffer. The amount of scaling can be set using [member scaling_3d_scale]. Values less than [code]1.0[/code] will result in undersampling while values greater than [code]1.0[/code] will result in supersampling. A value of [code]1.0[/code] disables scaling.

## SCALING_3D_MODE_FSR :: const Viewport.SCALING_3D_MODE_FSR: Scaling3DMode = 1
Use AMD FidelityFX Super Resolution 1.0 upscaling for the viewport's 3D buffer. The amount of scaling can be set using [member scaling_3d_scale]. Values less than [code]1.0[/code] will result in the viewport being upscaled using FSR. Values greater than [code]1.0[/code] are not supported and bilinear downsampling will be used instead. A value of [code]1.0[/code] disables scaling.

## SCALING_3D_MODE_FSR2 :: const Viewport.SCALING_3D_MODE_FSR2: Scaling3DMode = 2
Use AMD FidelityFX Super Resolution 2.2 upscaling for the viewport's 3D buffer. The amount of scaling can be set using [member Viewport.scaling_3d_scale]. Values less than [code]1.0[/code] will result in the viewport being upscaled using FSR2. Values greater than [code]1.0[/code] are not supported and bilinear downsampling will be used instead. A value of [code]1.0[/code] will use FSR2 at native resolution as a TAA solution.

## SCALING_3D_MODE_METALFX_SPATIAL :: const Viewport.SCALING_3D_MODE_METALFX_SPATIAL: Scaling3DMode = 3
Use the [url=https://developer.apple.com/documentation/metalfx/mtlfxspatialscaler#overview]MetalFX spatial upscaler[/url] for the viewport's 3D buffer.
The amount of scaling can be set using [member scaling_3d_scale].
Values less than [code]1.0[/code] will result in the viewport being upscaled using MetalFX. Values greater than [code]1.0[/code] are not supported and bilinear downsampling will be used instead. A value of [code]1.0[/code] disables scaling.
More information: [url=https://developer.apple.com/documentation/metalfx]MetalFX[/url].
[b]Note:[/b] Only supported when the Metal rendering driver is in use, which limits this scaling mode to macOS and iOS.

## SCALING_3D_MODE_METALFX_TEMPORAL :: const Viewport.SCALING_3D_MODE_METALFX_TEMPORAL: Scaling3DMode = 4
Use the [url=https://developer.apple.com/documentation/metalfx/mtlfxtemporalscaler#overview]MetalFX temporal upscaler[/url] for the viewport's 3D buffer.
The amount of scaling can be set using [member scaling_3d_scale]. To determine the minimum input scale, use the [method RenderingDevice.limit_get] method with [constant RenderingDevice.LIMIT_METALFX_TEMPORAL_SCALER_MIN_SCALE].
Values less than [code]1.0[/code] will result in the viewport being upscaled using MetalFX. Values greater than [code]1.0[/code] are not supported and bilinear downsampling will be used instead. A value of [code]1.0[/code] will use MetalFX at native resolution as a TAA solution.
More information: [url=https://developer.apple.com/documentation/metalfx]MetalFX[/url].
[b]Note:[/b] Only supported when the Metal rendering driver is in use, which limits this scaling mode to macOS and iOS.

## SCALING_3D_MODE_NEAREST :: const Viewport.SCALING_3D_MODE_NEAREST: Scaling3DMode = 5
Use nearest-neighbor filtering for the viewport's 3D buffer. This looks crisper than [constant SCALING_3D_MODE_BILINEAR] and has no additional rendering cost. The amount of scaling can be set using [member scaling_3d_scale]. Values greater than [code]1.0[/code] are not supported and bilinear downsampling will be used instead. A value of [code]1.0[/code] disables scaling.
[b]Note:[/b] When using the [b]Nearest[/b] scaling mode, to avoid uneven pixel scaling, it's highly recommended to use a value equal to an integer divisor with a dividend of [code]1[/code]. For example, it's best to use a scale of [code]0.5[/code] (1/2), [code]0.3333[/code] (1/3), [code]0.25[/code] (1/4), [code]0.2[/code] (1/5), and so on.

## SCALING_3D_MODE_MAX :: const Viewport.SCALING_3D_MODE_MAX: Scaling3DMode = 6
Represents the size of the [enum Scaling3DMode] enum.

## MSAA_DISABLED :: const Viewport.MSAA_DISABLED: MSAA = 0
Multisample antialiasing mode disabled. This is the default value, and is also the fastest setting.

## MSAA_2X :: const Viewport.MSAA_2X: MSAA = 1
Use 2× Multisample Antialiasing. This has a moderate performance cost. It helps reduce aliasing noticeably, but 4× MSAA still looks substantially better.

## MSAA_4X :: const Viewport.MSAA_4X: MSAA = 2
Use 4× Multisample Antialiasing. This has a significant performance cost, and is generally a good compromise between performance and quality.

## MSAA_8X :: const Viewport.MSAA_8X: MSAA = 3
Use 8× Multisample Antialiasing. This has a very high performance cost. The difference between 4× and 8× MSAA may not always be visible in real gameplay conditions. Likely unsupported on low-end and older hardware.

## MSAA_MAX :: const Viewport.MSAA_MAX: MSAA = 4
Represents the size of the [enum MSAA] enum.

## ANISOTROPY_DISABLED :: const Viewport.ANISOTROPY_DISABLED: AnisotropicFiltering = 0
Anisotropic filtering is disabled.

## ANISOTROPY_2X :: const Viewport.ANISOTROPY_2X: AnisotropicFiltering = 1
Use 2× anisotropic filtering.

## ANISOTROPY_4X :: const Viewport.ANISOTROPY_4X: AnisotropicFiltering = 2
Use 4× anisotropic filtering. This is the default value.

## ANISOTROPY_8X :: const Viewport.ANISOTROPY_8X: AnisotropicFiltering = 3
Use 8× anisotropic filtering.

## ANISOTROPY_16X :: const Viewport.ANISOTROPY_16X: AnisotropicFiltering = 4
Use 16× anisotropic filtering.

## ANISOTROPY_MAX :: const Viewport.ANISOTROPY_MAX: AnisotropicFiltering = 5
Represents the size of the [enum AnisotropicFiltering] enum.

## SCREEN_SPACE_AA_DISABLED :: const Viewport.SCREEN_SPACE_AA_DISABLED: ScreenSpaceAA = 0
Do not perform any antialiasing in the full screen post-process.

## SCREEN_SPACE_AA_FXAA :: const Viewport.SCREEN_SPACE_AA_FXAA: ScreenSpaceAA = 1
Use fast approximate antialiasing. FXAA is a popular screen-space antialiasing method, which is fast but will make the image look blurry, especially at lower resolutions. It can still work relatively well at large resolutions such as 1440p and 4K.

## SCREEN_SPACE_AA_SMAA :: const Viewport.SCREEN_SPACE_AA_SMAA: ScreenSpaceAA = 2
Use subpixel morphological antialiasing. SMAA may produce clearer results than FXAA, but at a slightly higher performance cost.

## SCREEN_SPACE_AA_MAX :: const Viewport.SCREEN_SPACE_AA_MAX: ScreenSpaceAA = 3
Represents the size of the [enum ScreenSpaceAA] enum.

## RENDER_INFO_OBJECTS_IN_FRAME :: const Viewport.RENDER_INFO_OBJECTS_IN_FRAME: RenderInfo = 0
Amount of objects in frame.

## RENDER_INFO_PRIMITIVES_IN_FRAME :: const Viewport.RENDER_INFO_PRIMITIVES_IN_FRAME: RenderInfo = 1
Amount of vertices in frame.

## RENDER_INFO_DRAW_CALLS_IN_FRAME :: const Viewport.RENDER_INFO_DRAW_CALLS_IN_FRAME: RenderInfo = 2
Amount of draw calls in frame.

## RENDER_INFO_MAX :: const Viewport.RENDER_INFO_MAX: RenderInfo = 3
Represents the size of the [enum RenderInfo] enum.

## RENDER_INFO_TYPE_VISIBLE :: const Viewport.RENDER_INFO_TYPE_VISIBLE: RenderInfoType = 0
Visible render pass (excluding shadows).

## RENDER_INFO_TYPE_SHADOW :: const Viewport.RENDER_INFO_TYPE_SHADOW: RenderInfoType = 1
Shadow render pass. Objects will be rendered several times depending on the number of amounts of lights with shadows and the number of directional shadow splits.

## RENDER_INFO_TYPE_CANVAS :: const Viewport.RENDER_INFO_TYPE_CANVAS: RenderInfoType = 2
Canvas item rendering. This includes all 2D rendering.

## RENDER_INFO_TYPE_MAX :: const Viewport.RENDER_INFO_TYPE_MAX: RenderInfoType = 3
Represents the size of the [enum RenderInfoType] enum.

## DEBUG_DRAW_DISABLED :: const Viewport.DEBUG_DRAW_DISABLED: DebugDraw = 0
Objects are displayed normally.

## DEBUG_DRAW_UNSHADED :: const Viewport.DEBUG_DRAW_UNSHADED: DebugDraw = 1
Objects are displayed without light information.

## DEBUG_DRAW_LIGHTING :: const Viewport.DEBUG_DRAW_LIGHTING: DebugDraw = 2
Objects are displayed without textures and only with lighting information.
[b]Note:[/b] When using this debug draw mode, custom shaders are ignored since all materials in the scene temporarily use a debug material. This means the result from custom shader functions (such as vertex displacement) won't be visible anymore when using this debug draw mode.

## DEBUG_DRAW_OVERDRAW :: const Viewport.DEBUG_DRAW_OVERDRAW: DebugDraw = 3
Objects are displayed semi-transparent with additive blending so you can see where they are drawing over top of one another. A higher overdraw means you are wasting performance on drawing pixels that are being hidden behind others.
[b]Note:[/b] When using this debug draw mode, custom shaders are ignored since all materials in the scene temporarily use a debug material. This means the result from custom shader functions (such as vertex displacement) won't be visible anymore when using this debug draw mode.

## DEBUG_DRAW_WIREFRAME :: const Viewport.DEBUG_DRAW_WIREFRAME: DebugDraw = 4
Objects are displayed as wireframe models.
[b]Note:[/b] [method RenderingServer.set_debug_generate_wireframes] must be called before loading any meshes for wireframes to be visible when using the Compatibility renderer.
[b]Note:[/b] In the Compatibility renderer, backfaces are always visible when using wireframe rendering. In the Forward+ and Mobile renderers, wireframes follow the material's backface culling properties instead.

## DEBUG_DRAW_NORMAL_BUFFER :: const Viewport.DEBUG_DRAW_NORMAL_BUFFER: DebugDraw = 5
Objects are displayed without lighting information and their textures replaced by normal mapping.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_VOXEL_GI_ALBEDO :: const Viewport.DEBUG_DRAW_VOXEL_GI_ALBEDO: DebugDraw = 6
Objects are displayed with only the albedo value from [VoxelGI]s. Requires at least one visible [VoxelGI] node that has been baked to have a visible effect.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_VOXEL_GI_LIGHTING :: const Viewport.DEBUG_DRAW_VOXEL_GI_LIGHTING: DebugDraw = 7
Objects are displayed with only the lighting value from [VoxelGI]s. Requires at least one visible [VoxelGI] node that has been baked to have a visible effect.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_VOXEL_GI_EMISSION :: const Viewport.DEBUG_DRAW_VOXEL_GI_EMISSION: DebugDraw = 8
Objects are displayed with only the emission color from [VoxelGI]s. Requires at least one visible [VoxelGI] node that has been baked to have a visible effect.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_SHADOW_ATLAS :: const Viewport.DEBUG_DRAW_SHADOW_ATLAS: DebugDraw = 9
Draws the shadow atlas that stores shadows from [OmniLight3D]s and [SpotLight3D]s in the upper left quadrant of the [Viewport].

## DEBUG_DRAW_DIRECTIONAL_SHADOW_ATLAS :: const Viewport.DEBUG_DRAW_DIRECTIONAL_SHADOW_ATLAS: DebugDraw = 10
Draws the shadow atlas that stores shadows from [DirectionalLight3D]s in the upper left quadrant of the [Viewport].

## DEBUG_DRAW_SCENE_LUMINANCE :: const Viewport.DEBUG_DRAW_SCENE_LUMINANCE: DebugDraw = 11
Draws the scene luminance buffer (if available) in the upper left quadrant of the [Viewport].
[b]Note:[/b] Only supported when using the Forward+ or Mobile rendering methods.

## DEBUG_DRAW_SSAO :: const Viewport.DEBUG_DRAW_SSAO: DebugDraw = 12
Draws the screen-space ambient occlusion texture instead of the scene so that you can clearly see how it is affecting objects. In order for this display mode to work, you must have [member Environment.ssao_enabled] set in your [WorldEnvironment].
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_SSIL :: const Viewport.DEBUG_DRAW_SSIL: DebugDraw = 13
Draws the screen-space indirect lighting texture instead of the scene so that you can clearly see how it is affecting objects. In order for this display mode to work, you must have [member Environment.ssil_enabled] set in your [WorldEnvironment].
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_PSSM_SPLITS :: const Viewport.DEBUG_DRAW_PSSM_SPLITS: DebugDraw = 14
Colors each PSSM split for the [DirectionalLight3D]s in the scene a different color so you can see where the splits are. In order (from closest to furthest from the camera), they are colored red, green, blue, and yellow.
[b]Note:[/b] When using this debug draw mode, custom shaders are ignored since all materials in the scene temporarily use a debug material. This means the result from custom shader functions (such as vertex displacement) won't be visible anymore when using this debug draw mode.
[b]Note:[/b] Only supported when using the Forward+ or Mobile rendering methods.

## DEBUG_DRAW_DECAL_ATLAS :: const Viewport.DEBUG_DRAW_DECAL_ATLAS: DebugDraw = 15
Draws the decal atlas used by [Decal]s and light projector textures in the upper left quadrant of the [Viewport].
[b]Note:[/b] Only supported when using the Forward+ or Mobile rendering methods.

## DEBUG_DRAW_SDFGI :: const Viewport.DEBUG_DRAW_SDFGI: DebugDraw = 16
Draws the cascades used to render signed distance field global illumination (SDFGI).
Does nothing if the current environment's [member Environment.sdfgi_enabled] is [code]false[/code].
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_SDFGI_PROBES :: const Viewport.DEBUG_DRAW_SDFGI_PROBES: DebugDraw = 17
Draws the probes used for signed distance field global illumination (SDFGI).
When in the editor, left-clicking a probe will display additional bright dots that show its occlusion information. A white dot means the light is not occluded at all at the dot's position, while a red dot means the light is fully occluded. Intermediate values are possible.
Does nothing if the current environment's [member Environment.sdfgi_enabled] is [code]false[/code].
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_GI_BUFFER :: const Viewport.DEBUG_DRAW_GI_BUFFER: DebugDraw = 18
Draws the buffer used for global illumination from [VoxelGI] or SDFGI. Requires [VoxelGI] (at least one visible baked VoxelGI node) or SDFGI ([member Environment.sdfgi_enabled]) to be enabled to have a visible effect.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_DISABLE_LOD :: const Viewport.DEBUG_DRAW_DISABLE_LOD: DebugDraw = 19
Draws all of the objects at their highest polycount regardless of their distance from the camera. No low level of detail (LOD) is applied.

## DEBUG_DRAW_CLUSTER_OMNI_LIGHTS :: const Viewport.DEBUG_DRAW_CLUSTER_OMNI_LIGHTS: DebugDraw = 20
Draws the cluster used by [OmniLight3D] nodes to optimize light rendering.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_CLUSTER_SPOT_LIGHTS :: const Viewport.DEBUG_DRAW_CLUSTER_SPOT_LIGHTS: DebugDraw = 21
Draws the cluster used by [SpotLight3D] nodes to optimize light rendering.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_CLUSTER_DECALS :: const Viewport.DEBUG_DRAW_CLUSTER_DECALS: DebugDraw = 22
Draws the cluster used by [Decal] nodes to optimize decal rendering.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_CLUSTER_REFLECTION_PROBES :: const Viewport.DEBUG_DRAW_CLUSTER_REFLECTION_PROBES: DebugDraw = 23
Draws the cluster used by [ReflectionProbe] nodes to optimize reflection probes.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_OCCLUDERS :: const Viewport.DEBUG_DRAW_OCCLUDERS: DebugDraw = 24
Draws the buffer used for occlusion culling.
[b]Note:[/b] Only supported when using the Forward+ or Mobile rendering methods.

## DEBUG_DRAW_MOTION_VECTORS :: const Viewport.DEBUG_DRAW_MOTION_VECTORS: DebugDraw = 25
Draws vector lines over the viewport to indicate the movement of pixels between frames.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_INTERNAL_BUFFER :: const Viewport.DEBUG_DRAW_INTERNAL_BUFFER: DebugDraw = 26
Draws the internal resolution buffer of the scene in linear colorspace before tonemapping or post-processing is applied.
[b]Note:[/b] Only supported when using the Forward+ or Mobile rendering methods.

## DEBUG_DRAW_CLUSTER_AREA_LIGHTS :: const Viewport.DEBUG_DRAW_CLUSTER_AREA_LIGHTS: DebugDraw = 27
Draws the cluster used by [AreaLight3D] nodes to optimize light rendering.
[b]Note:[/b] Only supported when using the Forward+ rendering method.

## DEBUG_DRAW_AREA_LIGHT_ATLAS :: const Viewport.DEBUG_DRAW_AREA_LIGHT_ATLAS: DebugDraw = 28
Draws the atlas used by [AreaLight3D] nodes in the upper left quadrant of the [Viewport].
[b]Note:[/b] Only supported when using the Forward+ or Mobile rendering method.

## DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST :: const Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST: DefaultCanvasItemTextureFilter = 0
The texture filter reads from the nearest pixel only. This makes the texture look pixelated from up close, and grainy from a distance (due to mipmaps not being sampled).

## DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_LINEAR :: const Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_LINEAR: DefaultCanvasItemTextureFilter = 1
The texture filter blends between the nearest 4 pixels. This makes the texture look smooth from up close, and grainy from a distance (due to mipmaps not being sampled).

## DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_LINEAR_WITH_MIPMAPS :: const Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_LINEAR_WITH_MIPMAPS: DefaultCanvasItemTextureFilter = 2
The texture filter blends between the nearest 4 pixels and between the nearest 2 mipmaps (or uses the nearest mipmap if [member ProjectSettings.rendering/textures/default_filters/use_nearest_mipmap_filter] is [code]true[/code]). This makes the texture look smooth from up close, and smooth from a distance.
Use this for non-pixel art textures that may be viewed at a low scale (e.g. due to [Camera2D] zoom or sprite scaling), as mipmaps are important to smooth out pixels that are smaller than on-screen pixels.

## DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST_WITH_MIPMAPS :: const Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST_WITH_MIPMAPS: DefaultCanvasItemTextureFilter = 3
The texture filter reads from the nearest pixel and blends between the nearest 2 mipmaps (or uses the nearest mipmap if [member ProjectSettings.rendering/textures/default_filters/use_nearest_mipmap_filter] is [code]true[/code]). This makes the texture look pixelated from up close, and smooth from a distance.
Use this for non-pixel art textures that may be viewed at a low scale (e.g. due to [Camera2D] zoom or sprite scaling), as mipmaps are important to smooth out pixels that are smaller than on-screen pixels.

## DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_PARENT_NODE :: const Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_PARENT_NODE: DefaultCanvasItemTextureFilter = 4
The [Viewport] will inherit the filter from its parent [CanvasItem] or [Viewport].

## DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_MAX :: const Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_MAX: DefaultCanvasItemTextureFilter = 5
Represents the size of the [enum DefaultCanvasItemTextureFilter] enum.

## DEFAULT_CANVAS_ITEM_TEXTURE_REPEAT_DISABLED :: const Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_REPEAT_DISABLED: DefaultCanvasItemTextureRepeat = 0
Disables textures repeating. Instead, when reading UVs outside the 0-1 range, the value will be clamped to the edge of the texture, resulting in a stretched out look at the borders of the texture.

## DEFAULT_CANVAS_ITEM_TEXTURE_REPEAT_ENABLED :: const Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_REPEAT_ENABLED: DefaultCanvasItemTextureRepeat = 1
Enables the texture to repeat when UV coordinates are outside the 0-1 range. If using one of the linear filtering modes, this can result in artifacts at the edges of a texture when the sampler filters across the edges of the texture.

## DEFAULT_CANVAS_ITEM_TEXTURE_REPEAT_MIRROR :: const Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_REPEAT_MIRROR: DefaultCanvasItemTextureRepeat = 2
Flip the texture when repeating so that the edge lines up instead of abruptly changing.

## DEFAULT_CANVAS_ITEM_TEXTURE_REPEAT_PARENT_NODE :: const Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_REPEAT_PARENT_NODE: DefaultCanvasItemTextureRepeat = 3
The [Viewport] will inherit the repeat mode from its parent [CanvasItem] or [Viewport].

## DEFAULT_CANVAS_ITEM_TEXTURE_REPEAT_MAX :: const Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_REPEAT_MAX: DefaultCanvasItemTextureRepeat = 4
Represents the size of the [enum DefaultCanvasItemTextureRepeat] enum.

## SDF_OVERSIZE_100_PERCENT :: const Viewport.SDF_OVERSIZE_100_PERCENT: SDFOversize = 0
The signed distance field only covers the viewport's own rectangle.

## SDF_OVERSIZE_120_PERCENT :: const Viewport.SDF_OVERSIZE_120_PERCENT: SDFOversize = 1
The signed distance field is expanded to cover 20% of the viewport's size around the borders.

## SDF_OVERSIZE_150_PERCENT :: const Viewport.SDF_OVERSIZE_150_PERCENT: SDFOversize = 2
The signed distance field is expanded to cover 50% of the viewport's size around the borders.

## SDF_OVERSIZE_200_PERCENT :: const Viewport.SDF_OVERSIZE_200_PERCENT: SDFOversize = 3
The signed distance field is expanded to cover 100% (double) of the viewport's size around the borders.

## SDF_OVERSIZE_MAX :: const Viewport.SDF_OVERSIZE_MAX: SDFOversize = 4
Represents the size of the [enum SDFOversize] enum.

## SDF_SCALE_100_PERCENT :: const Viewport.SDF_SCALE_100_PERCENT: SDFScale = 0
The signed distance field is rendered at full resolution.

## SDF_SCALE_50_PERCENT :: const Viewport.SDF_SCALE_50_PERCENT: SDFScale = 1
The signed distance field is rendered at half the resolution of this viewport.

## SDF_SCALE_25_PERCENT :: const Viewport.SDF_SCALE_25_PERCENT: SDFScale = 2
The signed distance field is rendered at a quarter the resolution of this viewport.

## SDF_SCALE_MAX :: const Viewport.SDF_SCALE_MAX: SDFScale = 3
Represents the size of the [enum SDFScale] enum.

## VRS_DISABLED :: const Viewport.VRS_DISABLED: VRSMode = 0
Variable Rate Shading is disabled.

## VRS_TEXTURE :: const Viewport.VRS_TEXTURE: VRSMode = 1
Variable Rate Shading uses a texture. Note, for stereoscopic use a texture atlas with a texture for each view.

## VRS_XR :: const Viewport.VRS_XR: VRSMode = 2
Variable Rate Shading's texture is supplied by the primary [XRInterface].

## VRS_MAX :: const Viewport.VRS_MAX: VRSMode = 3
Represents the size of the [enum VRSMode] enum.

## VRS_UPDATE_DISABLED :: const Viewport.VRS_UPDATE_DISABLED: VRSUpdateMode = 0
The input texture for variable rate shading will not be processed.

## VRS_UPDATE_ONCE :: const Viewport.VRS_UPDATE_ONCE: VRSUpdateMode = 1
The input texture for variable rate shading will be processed once.

## VRS_UPDATE_ALWAYS :: const Viewport.VRS_UPDATE_ALWAYS: VRSUpdateMode = 2
The input texture for variable rate shading will be processed each frame.

## VRS_UPDATE_MAX :: const Viewport.VRS_UPDATE_MAX: VRSUpdateMode = 3
Represents the size of the [enum VRSUpdateMode] enum.

## anisotropic_filtering_level :: var Viewport.anisotropic_filtering_level: Viewport.AnisotropicFiltering
Sets the maximum number of samples to take when using anisotropic filtering on textures (as a power of two). A higher sample count will result in sharper textures at oblique angles, but is more expensive to compute. A value of [code]0[/code] forcibly disables anisotropic filtering, even on materials where it is enabled.
The anisotropic filtering level also affects decals and light projectors if they are configured to use anisotropic filtering. See [member ProjectSettings.rendering/textures/decals/filter] and [member ProjectSettings.rendering/textures/light_projectors/filter].
[b]Note:[/b] In 3D, for this setting to have an effect, set [member BaseMaterial3D.texture_filter] to [constant BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC] or [constant BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS_ANISOTROPIC] on materials.
[b]Note:[/b] In 2D, for this setting to have an effect, set [member CanvasItem.texture_filter] to [constant CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC] or [constant CanvasItem.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS_ANISOTROPIC] on the [CanvasItem] node displaying the texture (or in [CanvasTexture]). However, anisotropic filtering is rarely useful in 2D, so only enable it for textures in 2D if it makes a meaningful visual difference.

## audio_listener_enable_2d :: var Viewport.audio_listener_enable_2d: bool
If [code]true[/code], the viewport will process 2D audio streams.

## audio_listener_enable_3d :: var Viewport.audio_listener_enable_3d: bool
If [code]true[/code], the viewport will process 3D audio streams.

## canvas_cull_mask :: var Viewport.canvas_cull_mask: int
The rendering layers in which this [Viewport] renders [CanvasItem] nodes.
[b]Note:[/b] A [CanvasItem] does not inherit its parents' visibility layers. See [member CanvasItem.visibility_layer]'s description for details.

## canvas_item_default_texture_filter :: var Viewport.canvas_item_default_texture_filter: Viewport.DefaultCanvasItemTextureFilter
The default filter mode used by [CanvasItem] nodes in this viewport.

## canvas_item_default_texture_repeat :: var Viewport.canvas_item_default_texture_repeat: Viewport.DefaultCanvasItemTextureRepeat
The default repeat mode used by [CanvasItem] nodes in this viewport.

## canvas_transform :: var Viewport.canvas_transform: Transform2D
The canvas transform of the viewport, useful for changing the on-screen positions of all child [CanvasItem]s. This is relative to the global canvas transform of the viewport.

## debug_draw :: var Viewport.debug_draw: Viewport.DebugDraw
The overlay mode for test rendered geometry in debug purposes.

## disable_3d :: var Viewport.disable_3d: bool
Disable 3D rendering (but keep 2D rendering).

## fsr_sharpness :: var Viewport.fsr_sharpness: float
Determines how sharp the upscaled image will be when using the FSR upscaling mode. Sharpness halves with every whole number. Values go from 0.0 (sharpest) to 2.0. Values above 2.0 won't make a visible difference.
To control this property on the root viewport, set the [member ProjectSettings.rendering/scaling_3d/fsr_sharpness] project setting.

## global_canvas_transform :: var Viewport.global_canvas_transform: Transform2D
The global canvas transform of the viewport. The canvas transform is relative to this.

## gui_disable_input :: var Viewport.gui_disable_input: bool
If [code]true[/code], the viewport will not receive input events.

## gui_drag_threshold :: var Viewport.gui_drag_threshold: int
The minimum distance the mouse cursor must move while pressed before a drag operation begins.

## gui_embed_subwindows :: var Viewport.gui_embed_subwindows: bool
If [code]true[/code], sub-windows (popups and dialogs) will be embedded inside application window as control-like nodes. If [code]false[/code], they will appear as separate windows handled by the operating system.

## gui_snap_controls_to_pixels :: var Viewport.gui_snap_controls_to_pixels: bool
If [code]true[/code], the GUI controls on the viewport will lay pixel perfectly.

## handle_input_locally :: var Viewport.handle_input_locally: bool
If [code]true[/code], this viewport will mark incoming input events as handled by itself. If [code]false[/code], this is instead done by the first parent viewport that is set to handle input locally.
A [SubViewportContainer] will automatically set this property to [code]false[/code] for the [Viewport] contained inside of it.
See also [method set_input_as_handled] and [method is_input_handled].

## mesh_lod_threshold :: var Viewport.mesh_lod_threshold: float
The automatic LOD bias to use for meshes rendered within the [Viewport] (this is analogous to [member ReflectionProbe.mesh_lod_threshold]). Higher values will use less detailed versions of meshes that have LOD variations generated. If set to [code]0.0[/code], automatic LOD is disabled. Increase [member mesh_lod_threshold] to improve performance at the cost of geometry detail.
To control this property on the root viewport, set the [member ProjectSettings.rendering/mesh_lod/lod_change/threshold_pixels] project setting.
[b]Note:[/b] Depending on the mesh's attributes (vertex colors, blend shapes, ...), a mesh may have fewer levels of LOD generated to avoid visible distortion of the mesh once it is affected by vertex colors or blend shapes. Meshes with a very low vertex count will also not have any LODs generated, which means this setting will not affect them at all. In general, this setting makes the largest impact on static meshes with a high vertex count.
[b]Note:[/b] [member mesh_lod_threshold] does not affect [GeometryInstance3D] visibility ranges (also known as "manual" LOD or hierarchical LOD).

## msaa_2d :: var Viewport.msaa_2d: Viewport.MSAA
The multisample antialiasing mode for 2D/Canvas rendering. A higher number results in smoother edges at the cost of significantly worse performance. A value of [constant Viewport.MSAA_2X] or [constant Viewport.MSAA_4X] is best unless targeting very high-end systems. This has no effect on shader-induced aliasing or texture aliasing.
See also [member ProjectSettings.rendering/anti_aliasing/quality/msaa_2d] and [method RenderingServer.viewport_set_msaa_2d].

## msaa_3d :: var Viewport.msaa_3d: Viewport.MSAA
The multisample antialiasing mode for 3D rendering. A higher number results in smoother edges at the cost of significantly worse performance. A value of [constant Viewport.MSAA_2X] or [constant Viewport.MSAA_4X] is best unless targeting very high-end systems. See also bilinear scaling 3D [member scaling_3d_mode] for supersampling, which provides higher quality but is much more expensive. This has no effect on shader-induced aliasing or texture aliasing.
See also [member ProjectSettings.rendering/anti_aliasing/quality/msaa_3d] and [method RenderingServer.viewport_set_msaa_3d].

## oversampling :: var Viewport.oversampling: bool
If [code]true[/code] and one of the following conditions are true: [member SubViewport.size_2d_override_stretch] and [member SubViewport.size_2d_override] are set, [member Window.content_scale_factor] is set and scaling is enabled, [member oversampling_override] is set, font and [DPITexture] oversampling are enabled.

## oversampling_override :: var Viewport.oversampling_override: float
If greater than zero, this value is used as the font oversampling factor, otherwise oversampling is equal to viewport scale.

## own_world_3d :: var Viewport.own_world_3d: bool
If [code]true[/code], the viewport will use a unique copy of the [World3D] defined in [member world_3d].

## physics_interpolation_mode :: var Viewport.physics_interpolation_mode: Node.PhysicsInterpolationMode

## physics_object_picking :: var Viewport.physics_object_picking: bool
If [code]true[/code], the objects rendered by viewport become subjects of mouse picking process.
[b]Note:[/b] The number of simultaneously pickable objects is limited to 64 and they are selected in a non-deterministic order, which can be different in each picking process.

## physics_object_picking_first_only :: var Viewport.physics_object_picking_first_only: bool
If [code]true[/code], the input_event signal will only be sent to one physics object in the mouse picking process. If you want to get the top object only, you must also enable [member physics_object_picking_sort].
If [code]false[/code], an input_event signal will be sent to all physics objects in the mouse picking process.
This applies to 2D CanvasItem object picking only.

## physics_object_picking_sort :: var Viewport.physics_object_picking_sort: bool
If [code]true[/code], objects receive mouse picking events sorted primarily by their [member CanvasItem.z_index] and secondarily by their position in the scene tree. If [code]false[/code], the order is undetermined.
[b]Note:[/b] This setting is disabled by default because of its potential expensive computational cost.
[b]Note:[/b] Sorting happens after selecting the pickable objects. Because of the limitation of 64 simultaneously pickable objects, it is not guaranteed that the object with the highest [member CanvasItem.z_index] receives the picking event.

## positional_shadow_atlas_16_bits :: var Viewport.positional_shadow_atlas_16_bits: bool
Use 16 bits for the omni/spot shadow depth map. Enabling this results in shadows having less precision and may result in shadow acne, but can lead to performance improvements on some devices.

## positional_shadow_atlas_quad_0 :: var Viewport.positional_shadow_atlas_quad_0: Viewport.PositionalShadowAtlasQuadrantSubdiv
The subdivision amount of the first quadrant on the shadow atlas.

## positional_shadow_atlas_quad_1 :: var Viewport.positional_shadow_atlas_quad_1: Viewport.PositionalShadowAtlasQuadrantSubdiv
The subdivision amount of the second quadrant on the shadow atlas.

## positional_shadow_atlas_quad_2 :: var Viewport.positional_shadow_atlas_quad_2: Viewport.PositionalShadowAtlasQuadrantSubdiv
The subdivision amount of the third quadrant on the shadow atlas.

## positional_shadow_atlas_quad_3 :: var Viewport.positional_shadow_atlas_quad_3: Viewport.PositionalShadowAtlasQuadrantSubdiv
The subdivision amount of the fourth quadrant on the shadow atlas.

## positional_shadow_atlas_size :: var Viewport.positional_shadow_atlas_size: int
The shadow atlas' resolution (used for omni and spot lights). The value is rounded up to the nearest power of 2.
[b]Note:[/b] If this is set to [code]0[/code], no positional shadows will be visible at all. This can improve performance significantly on low-end systems by reducing both the CPU and GPU load (as fewer draw calls are needed to draw the scene without shadows).

## scaling_3d_mode :: var Viewport.scaling_3d_mode: Viewport.Scaling3DMode
Sets scaling 3D mode. Bilinear scaling renders at different resolution to either undersample or supersample the viewport. FidelityFX Super Resolution 1.0, abbreviated to FSR, is an upscaling technology that produces high quality images at fast framerates by using a spatially aware upscaling algorithm. FSR is slightly more expensive than bilinear, but it produces significantly higher image quality. FSR should be used where possible.
To control this property on the root viewport, set the [member ProjectSettings.rendering/scaling_3d/mode] project setting.

## scaling_3d_scale :: var Viewport.scaling_3d_scale: float
Scales the 3D render buffer based on the viewport size uses an image filter specified in [member ProjectSettings.rendering/scaling_3d/mode] to scale the output image to the full viewport size. Values lower than [code]1.0[/code] can be used to speed up 3D rendering at the cost of quality (undersampling). Values greater than [code]1.0[/code] are only valid for bilinear mode and can be used to improve 3D rendering quality at a high performance cost (supersampling). See also [member ProjectSettings.rendering/anti_aliasing/quality/msaa_3d] for multi-sample antialiasing, which is significantly cheaper but only smooths the edges of polygons.
When using FSR upscaling, AMD recommends exposing the following values as preset options to users "Ultra Quality: 0.77", "Quality: 0.67", "Balanced: 0.59", "Performance: 0.5" instead of exposing the entire scale.
To control this property on the root viewport, set the [member ProjectSettings.rendering/scaling_3d/scale] project setting.

## screen_space_aa :: var Viewport.screen_space_aa: Viewport.ScreenSpaceAA
Sets the screen-space antialiasing method used. Screen-space antialiasing works by selectively blurring edges in a post-process shader. It differs from MSAA which takes multiple coverage samples while rendering objects. Screen-space AA methods are typically faster than MSAA and will smooth out specular aliasing, but tend to make scenes appear blurry.
See also [member ProjectSettings.rendering/anti_aliasing/quality/screen_space_aa] and [method RenderingServer.viewport_set_screen_space_aa].

## sdf_oversize :: var Viewport.sdf_oversize: Viewport.SDFOversize
Controls how much of the original viewport's size should be covered by the 2D signed distance field. This SDF can be sampled in [CanvasItem] shaders and is also used for [GPUParticles2D] collision. Higher values allow portions of occluders located outside the viewport to still be taken into account in the generated signed distance field, at the cost of performance. If you notice particles falling through [LightOccluder2D]s as the occluders leave the viewport, increase this setting.
The percentage is added on each axis and on both sides. For example, with the default [constant SDF_OVERSIZE_120_PERCENT], the signed distance field will cover 20% of the viewport's size outside the viewport on each side (top, right, bottom, left).

## sdf_scale :: var Viewport.sdf_scale: Viewport.SDFScale
The resolution scale to use for the 2D signed distance field. Higher values lead to a more precise and more stable signed distance field as the camera moves, at the cost of performance.

## snap_2d_transforms_to_pixel :: var Viewport.snap_2d_transforms_to_pixel: bool
If [code]true[/code], [CanvasItem] nodes will internally snap to full pixels. Their position can still be sub-pixel, but the decimals will not have effect. This can lead to a crisper appearance at the cost of less smooth movement, especially when [Camera2D] smoothing is enabled.

## snap_2d_vertices_to_pixel :: var Viewport.snap_2d_vertices_to_pixel: bool
If [code]true[/code], vertices of [CanvasItem] nodes will snap to full pixels. Only affects the final vertex positions, not the transforms. This can lead to a crisper appearance at the cost of less smooth movement, especially when [Camera2D] smoothing is enabled.

## texture_mipmap_bias :: var Viewport.texture_mipmap_bias: float
Affects the final texture sharpness by reading from a lower or higher mipmap (also called "texture LOD bias"). Negative values make mipmapped textures sharper but grainier when viewed at a distance, while positive values make mipmapped textures blurrier (even when up close).
Enabling temporal antialiasing ([member use_taa]) will automatically apply a [code]-0.5[/code] offset to this value, while enabling FXAA ([member screen_space_aa]) will automatically apply a [code]-0.25[/code] offset to this value. If both TAA and FXAA are enabled at the same time, an offset of [code]-0.75[/code] is applied to this value.
To control this property on the root viewport, set the [member ProjectSettings.rendering/textures/default_filters/texture_mipmap_bias] project setting.
[b]Note:[/b] If [member scaling_3d_scale] is lower than [code]1.0[/code] (exclusive), [member texture_mipmap_bias] is used to adjust the automatic mipmap bias which is calculated internally based on the scale factor. The formula for this is [code]log2(scaling_3d_scale) + mipmap_bias[/code].
[b]Note:[/b] This property is only supported in the Forward+ and Mobile renderers, not Compatibility. In Compatibility, this property is always treated as if it was set to [code]0.0[/code].

## transparent_bg :: var Viewport.transparent_bg: bool
If [code]true[/code], the viewport should render its background as transparent.
[b]Note:[/b] Due to technical limitations, certain rendering features are disabled when a viewport has a transparent background. This currently applies to screen-space reflections, subsurface scattering, and depth of field.

## use_debanding :: var Viewport.use_debanding: bool
When using the Mobile or Forward+ renderers, set [member use_debanding] to enable or disable the debanding feature of this [Viewport]. If [member use_hdr_2d] is [code]false[/code], 2D rendering is [i]not[/i] affected by debanding unless the [member Environment.background_mode] is [constant Environment.BG_CANVAS]. If [member use_hdr_2d] is [code]true[/code], debanding will only be applied if this is the root [Viewport] and will affect all 2D and 3D rendering, including canvas items.
[member use_debanding] has no effect when using the Compatibility rendering method. The Mobile renderer can also use material debanding, which can be set with [method RenderingServer.material_set_use_debanding] or configured with [member ProjectSettings.rendering/anti_aliasing/quality/use_debanding].
See also [member ProjectSettings.rendering/anti_aliasing/quality/use_debanding], [method RenderingServer.material_set_use_debanding], and [method RenderingServer.viewport_set_use_debanding].

## use_hdr_2d :: var Viewport.use_hdr_2d: bool
If [code]true[/code], 2D rendering will use a high dynamic range (HDR) [code]RGBA16[/code] format framebuffer. Additionally, 2D rendering will be performed on linear values and will be converted using the appropriate transfer function immediately before blitting to the screen (if the Viewport is attached to the screen).
Practically speaking, this means that the end result of the Viewport will not be clamped to the [code]0-1[/code] range and can be used in 3D rendering without color encoding adjustments. This allows 2D rendering to take advantage of effects requiring high dynamic range (e.g. 2D glow) as well as substantially improves the appearance of effects requiring highly detailed gradients.

## use_occlusion_culling :: var Viewport.use_occlusion_culling: bool
If [code]true[/code], [OccluderInstance3D] nodes will be usable for occlusion culling in 3D for this viewport. For the root viewport, [member ProjectSettings.rendering/occlusion_culling/use_occlusion_culling] must be set to [code]true[/code] instead.
[b]Note:[/b] Enabling occlusion culling has a cost on the CPU. Only enable occlusion culling if you actually plan to use it, and think whether your scene can actually benefit from occlusion culling. Large, open scenes with few or no objects blocking the view will generally not benefit much from occlusion culling. Large open scenes generally benefit more from mesh LOD and visibility ranges ([member GeometryInstance3D.visibility_range_begin] and [member GeometryInstance3D.visibility_range_end]) compared to occlusion culling.
[b]Note:[/b] Due to memory constraints, occlusion culling is not supported by default in Web export templates. It can be enabled by compiling custom Web export templates with [code]module_raycast_enabled=yes[/code].

## use_taa :: var Viewport.use_taa: bool
Enables temporal antialiasing for this viewport. TAA works by jittering the camera and accumulating the images of the last rendered frames, motion vector rendering is used to account for camera and object motion.
[b]Note:[/b] The implementation is not complete yet, some visual instances such as particles and skinned meshes may show artifacts.
See also [member ProjectSettings.rendering/anti_aliasing/quality/use_taa] and [method RenderingServer.viewport_set_use_taa].

## use_xr :: var Viewport.use_xr: bool
If [code]true[/code], the viewport will use the primary XR interface to render XR output. When applicable this can result in a stereoscopic image and the resulting render being output to a headset.

## vrs_mode :: var Viewport.vrs_mode: Viewport.VRSMode
The Variable Rate Shading (VRS) mode that is used for this viewport. Note, if hardware does not support VRS this property is ignored.

## vrs_texture :: var Viewport.vrs_texture: Texture2D
Texture to use when [member vrs_mode] is set to [constant Viewport.VRS_TEXTURE].
The texture [i]must[/i] use a lossless compression format so that colors can be matched precisely. The following VRS densities are mapped to various colors, with brighter colors representing a lower level of shading precision:
[codeblock lang=text]
- 1×1 = rgb(0, 0, 0)     - #000000
- 1×2 = rgb(0, 85, 0)    - #005500
- 2×1 = rgb(85, 0, 0)    - #550000
- 2×2 = rgb(85, 85, 0)   - #555500
- 2×4 = rgb(85, 170, 0)  - #55aa00
- 4×2 = rgb(170, 85, 0)  - #aa5500
- 4×4 = rgb(170, 170, 0) - #aaaa00
- 4×8 = rgb(170, 255, 0) - #aaff00 - Not supported on most hardware
- 8×4 = rgb(255, 170, 0) - #ffaa00 - Not supported on most hardware
- 8×8 = rgb(255, 255, 0) - #ffff00 - Not supported on most hardware
[/codeblock]

## vrs_update_mode :: var Viewport.vrs_update_mode: Viewport.VRSUpdateMode
Sets the update mode for Variable Rate Shading (VRS) for the viewport. VRS requires the input texture to be converted to the format usable by the VRS method supported by the hardware. The update mode defines how often this happens. If the GPU does not support VRS, or VRS is not enabled, this property is ignored.

## world_2d :: var Viewport.world_2d: World2D
The custom [World2D] which can be used as 2D environment source.

## world_3d :: var Viewport.world_3d: World3D
The custom [World3D] which can be used as 3D environment source.

## find_world_2d :: func Viewport.find_world_2d() -> World2D
Returns the first valid [World2D] for this viewport, searching the [member world_2d] property of itself and any Viewport ancestor.

## find_world_3d :: func Viewport.find_world_3d() -> World3D
Returns the first valid [World3D] for this viewport, searching the [member world_3d] property of itself and any Viewport ancestor.

## get_audio_listener_2d :: func Viewport.get_audio_listener_2d() -> AudioListener2D
Returns the currently active 2D audio listener. Returns [code]null[/code] if there are no active 2D audio listeners, in which case the active 2D camera will be treated as listener.

## get_audio_listener_3d :: func Viewport.get_audio_listener_3d() -> AudioListener3D
Returns the currently active 3D audio listener. Returns [code]null[/code] if there are no active 3D audio listeners, in which case the active 3D camera will be treated as listener.

## get_camera_2d :: func Viewport.get_camera_2d() -> Camera2D
Returns the currently active 2D camera. Returns [code]null[/code] if there are no active cameras.
[b]Note:[/b] If called while the [i]Camera Override[/i] system is active in editor, this will return the internally managed override camera. It is therefore advised to avoid caching the return value, or to check that the cached value is still a valid instance and is the current camera before use. See [method @GlobalScope.is_instance_valid] and [method Camera2D.is_current].

## get_camera_3d :: func Viewport.get_camera_3d() -> Camera3D
Returns the currently active 3D camera. Returns [code]null[/code] if there are no active cameras.
[b]Note:[/b] If called while the [i]Camera Override[/i] system is active in editor, this will return the internally managed override camera. It is therefore advised to avoid caching the return value, or to check that the cached value is a valid instance and is the current camera before use. See [method @GlobalScope.is_instance_valid] and [member Camera3D.current].

## get_canvas_cull_mask_bit :: func Viewport.get_canvas_cull_mask_bit(layer: int) -> bool
Returns an individual bit on the rendering layer mask.

### layer :: int

## get_embedded_subwindows :: func Viewport.get_embedded_subwindows() -> Window[]
Returns a list of the visible embedded [Window]s inside the viewport.
[b]Note:[/b] [Window]s inside other viewports will not be listed.

## get_final_transform :: func Viewport.get_final_transform() -> Transform2D
Returns the transform from the viewport's coordinate system to the embedder's coordinate system.

## get_mouse_position :: func Viewport.get_mouse_position() -> Vector2
Returns the mouse's position in this [Viewport] using the coordinate system of this [Viewport].

## get_oversampling :: func Viewport.get_oversampling() -> float
Returns viewport oversampling factor.

## get_positional_shadow_atlas_quadrant_subdiv :: func Viewport.get_positional_shadow_atlas_quadrant_subdiv(quadrant: int) -> int
Returns the positional shadow atlas quadrant subdivision of the specified quadrant.

### quadrant :: int

## get_render_info :: func Viewport.get_render_info(type: int, info: int) -> int
Returns rendering statistics of the given type.

### type :: int

### info :: int

## get_screen_transform :: func Viewport.get_screen_transform() -> Transform2D
Returns the transform from the Viewport's coordinates to the screen coordinates of the containing window manager window.

## get_stretch_transform :: func Viewport.get_stretch_transform() -> Transform2D
Returns the automatically computed 2D stretch transform, taking the [Viewport]'s stretch settings into account. The final value is multiplied by [member Window.content_scale_factor], but only for the root viewport. If this method is called on a [SubViewport] (e.g., in a scene tree with [SubViewportContainer] and [SubViewport]), the scale factor of the root window will not be applied. Using [method Transform2D.get_scale] on the returned value, this can be used to compensate for scaling when zooming a [Camera2D] node, or to scale down a [TextureRect] to be pixel-perfect regardless of the automatically computed scale factor.
[b]Note:[/b] Due to how pixel scaling works, the returned transform's X and Y scale may differ slightly, even when [member Window.content_scale_aspect] is set to a mode that preserves the pixels' aspect ratio. If [member Window.content_scale_aspect] is [constant Window.CONTENT_SCALE_ASPECT_IGNORE], the X and Y scale may differ [i]significantly[/i].

## get_texture :: func Viewport.get_texture() -> ViewportTexture
Returns the viewport's texture.
[b]Note:[/b] When trying to store the current texture (e.g. in a file), it might be completely black or outdated if used too early, especially when used in e.g. [method Node._ready]. To make sure the texture you get is correct, you can await [signal RenderingServer.frame_post_draw] signal.
[codeblocks]
[gdscript]
func _ready():
    await RenderingServer.frame_post_draw
    $Viewport.get_texture().get_image().save_png("user://Screenshot.png")
[/gdscript]
[csharp]
public async override void _Ready()
{
    await ToSignal(RenderingServer.Singleton, RenderingServer.SignalName.FramePostDraw);
    var viewport = GetNode<Viewport>("Viewport");
    viewport.GetTexture().GetImage().SavePng("user://Screenshot.png");
}
[/csharp]
[/codeblocks]
[b]Note:[/b] When [member use_hdr_2d] is [code]true[/code] the returned texture will be an HDR image using linear encoding.

## get_viewport_rid :: func Viewport.get_viewport_rid() -> RID
Returns the viewport's RID from the [RenderingServer].

## get_visible_rect :: func Viewport.get_visible_rect() -> Rect2
Returns the visible rectangle in global screen coordinates.

## gui_cancel_drag :: func Viewport.gui_cancel_drag() -> void
Cancels the drag operation that was previously started through [method Control._get_drag_data] or forced with [method Control.force_drag].

## gui_get_drag_data :: func Viewport.gui_get_drag_data() -> Variant
Returns the drag data from the GUI, that was previously returned by [method Control._get_drag_data].

## gui_get_drag_description :: func Viewport.gui_get_drag_description() -> String
Returns the human-readable description of the drag data, used for assistive apps.

## gui_get_focus_owner :: func Viewport.gui_get_focus_owner() -> Control
Returns the currently focused [Control] within this viewport. If no [Control] is focused, returns [code]null[/code].

## gui_get_hovered_control :: func Viewport.gui_get_hovered_control() -> Control
Returns the [Control] that the mouse is currently hovering over in this viewport. If no [Control] has the cursor, returns [code]null[/code].
Typically the leaf [Control] node or deepest level of the subtree which claims hover. This is very useful when used together with [method Node.is_ancestor_of] to find if the mouse is within a control tree.

## gui_is_drag_successful :: func Viewport.gui_is_drag_successful() -> bool
Returns [code]true[/code] if the drag operation is successful.

## gui_is_dragging :: func Viewport.gui_is_dragging() -> bool
Returns [code]true[/code] if a drag operation is currently ongoing and where the drop action could happen in this viewport.
Alternative to [constant Node.NOTIFICATION_DRAG_BEGIN] and [constant Node.NOTIFICATION_DRAG_END] when you prefer polling the value.

## gui_release_focus :: func Viewport.gui_release_focus() -> void
Removes the focus from the currently focused [Control] within this viewport. If no [Control] has the focus, does nothing.

## gui_set_drag_description :: func Viewport.gui_set_drag_description(description: String) -> void
Sets the human-readable description of the drag data to [param description], used for assistive apps.

### description :: String

## is_input_handled :: func Viewport.is_input_handled() -> bool
Returns whether the current [InputEvent] has been handled. Input events are not handled until [method set_input_as_handled] has been called during the lifetime of an [InputEvent].
This is usually done as part of input handling methods like [method Node._input], [method Control._gui_input] or others, as well as in corresponding signal handlers.
If [member handle_input_locally] is set to [code]false[/code], this method will try finding the first parent viewport that is set to handle input locally, and return its value for [method is_input_handled] instead.

## notify_mouse_entered :: func Viewport.notify_mouse_entered() -> void
Inform the Viewport that the mouse has entered its area. Use this function before sending an [InputEventMouseButton] or [InputEventMouseMotion] to the [Viewport] with [method Viewport.push_input]. See also [method notify_mouse_exited].
[b]Note:[/b] In most cases, it is not necessary to call this function because [SubViewport] nodes that are children of [SubViewportContainer] are notified automatically. This is only necessary when interacting with viewports in non-default ways, for example as textures in [TextureRect] or with an [Area3D] that forwards input events.

## notify_mouse_exited :: func Viewport.notify_mouse_exited() -> void
Inform the Viewport that the mouse has left its area. Use this function when the node that displays the viewport notices the mouse has left the area of the displayed viewport. See also [method notify_mouse_entered].
[b]Note:[/b] In most cases, it is not necessary to call this function because [SubViewport] nodes that are children of [SubViewportContainer] are notified automatically. This is only necessary when interacting with viewports in non-default ways, for example as textures in [TextureRect] or with an [Area3D] that forwards input events.

## push_input :: func Viewport.push_input(event: InputEvent, in_local_coords: bool = false) -> void
Triggers the given [param event] in this [Viewport]. This can be used to pass an [InputEvent] between viewports, or to locally apply inputs that were sent over the network or saved to a file.
If [param in_local_coords] is [code]false[/code], the event's position is in the embedder's coordinates and will be converted to viewport coordinates. If [param in_local_coords] is [code]true[/code], the event's position is in viewport coordinates.
While this method serves a similar purpose as [method Input.parse_input_event], it does not remap the specified [param event] based on project settings like [member ProjectSettings.input_devices/pointing/emulate_touch_from_mouse].
Calling this method will propagate calls to child nodes for following methods in the given order:
- [method Node._input]
- [method Control._gui_input] for [Control] nodes
- [method Node._shortcut_input]
- [method Node._unhandled_key_input]
- [method Node._unhandled_input]
If an earlier method marks the input as handled via [method set_input_as_handled], any later method in this list will not be called.
If none of the methods handle the event and [member physics_object_picking] is [code]true[/code], the event is used for physics object picking.

### event :: InputEvent

### in_local_coords :: bool

## push_text_input :: func Viewport.push_text_input(text: String) -> void
Helper method which calls the [code]set_text()[/code] method on the currently focused [Control], provided that it is defined (e.g. if the focused Control is [Button] or [LineEdit]).

### text :: String

## push_unhandled_input :: func Viewport.push_unhandled_input(event: InputEvent, in_local_coords: bool = false) -> void
Triggers the given [param event] in this [Viewport]. This can be used to pass an [InputEvent] between viewports, or to locally apply inputs that were sent over the network or saved to a file.
If [param in_local_coords] is [code]false[/code], the event's position is in the embedder's coordinates and will be converted to viewport coordinates. If [param in_local_coords] is [code]true[/code], the event's position is in viewport coordinates.
Calling this method will propagate calls to child nodes for following methods in the given order:
- [method Node._shortcut_input]
- [method Node._unhandled_key_input]
- [method Node._unhandled_input]
If an earlier method marks the input as handled via [method set_input_as_handled], any later method in this list will not be called.
If none of the methods handle the event and [member physics_object_picking] is [code]true[/code], the event is used for physics object picking.
[b]Note:[/b] This method doesn't propagate input events to embedded [Window]s or [SubViewport]s.

### event :: InputEvent

### in_local_coords :: bool

## set_canvas_cull_mask_bit :: func Viewport.set_canvas_cull_mask_bit(layer: int, enable: bool) -> void
Set/clear individual bits on the rendering layer mask. This simplifies editing this [Viewport]'s layers.

### layer :: int

### enable :: bool

## set_input_as_handled :: func Viewport.set_input_as_handled() -> void
Stops the input from propagating further up the [SceneTree].
[b]Note:[/b] This does not affect the methods in [Input], only the way events are propagated.

## set_positional_shadow_atlas_quadrant_subdiv :: func Viewport.set_positional_shadow_atlas_quadrant_subdiv(quadrant: int, subdiv: int) -> void
Sets the number of subdivisions to use in the specified quadrant. A higher number of subdivisions allows you to have more shadows in the scene at once, but reduces the quality of the shadows. A good practice is to have quadrants with a varying number of subdivisions and to have as few subdivisions as possible.

### quadrant :: int

### subdiv :: int

## update_mouse_cursor_state :: func Viewport.update_mouse_cursor_state() -> void
Force instantly updating the display based on the current mouse cursor position. This includes updating the mouse cursor shape and sending necessary [signal Control.mouse_entered], [signal CollisionObject2D.mouse_entered], [signal CollisionObject3D.mouse_entered] and [signal Window.mouse_entered] signals and their respective [code]mouse_exited[/code] counterparts.

## warp_mouse :: func Viewport.warp_mouse(position: Vector2) -> void
Moves the mouse pointer to the specified position in this [Viewport] using the coordinate system of this [Viewport].
[b]Note:[/b] [method warp_mouse] is only supported on Windows, macOS and Linux. It has no effect on Android, iOS and Web.

### position :: Vector2

## gui_focus_changed :: func Viewport.gui_focus_changed(node: Control) -> void
Emitted when a Control node grabs keyboard focus.
[b]Note:[/b] A Control node losing focus doesn't cause this signal to be emitted.

### node :: Control

## size_changed :: func Viewport.size_changed() -> void
Emitted when the size of the viewport is changed, whether by resizing of window, or some other means.
