# SkeletonModifier3D :: <Native> class SkeletonModifier3D extends Node3D
A node that may modify a Skeleton3D's bones.
[SkeletonModifier3D] retrieves a target [Skeleton3D] by having a [Skeleton3D] parent.
If there is an [AnimationMixer], a modification always performs after playback process of the [AnimationMixer].
This node should be used to implement custom IK solvers, constraints, or skeleton physics.

## BONE_AXIS_PLUS_X :: const SkeletonModifier3D.BONE_AXIS_PLUS_X: BoneAxis = 0
Enumerated value for the +X axis.

## BONE_AXIS_MINUS_X :: const SkeletonModifier3D.BONE_AXIS_MINUS_X: BoneAxis = 1
Enumerated value for the -X axis.

## BONE_AXIS_PLUS_Y :: const SkeletonModifier3D.BONE_AXIS_PLUS_Y: BoneAxis = 2
Enumerated value for the +Y axis.

## BONE_AXIS_MINUS_Y :: const SkeletonModifier3D.BONE_AXIS_MINUS_Y: BoneAxis = 3
Enumerated value for the -Y axis.

## BONE_AXIS_PLUS_Z :: const SkeletonModifier3D.BONE_AXIS_PLUS_Z: BoneAxis = 4
Enumerated value for the +Z axis.

## BONE_AXIS_MINUS_Z :: const SkeletonModifier3D.BONE_AXIS_MINUS_Z: BoneAxis = 5
Enumerated value for the -Z axis.

## BONE_DIRECTION_PLUS_X :: const SkeletonModifier3D.BONE_DIRECTION_PLUS_X: BoneDirection = 0
Enumerated value for the +X axis.

## BONE_DIRECTION_MINUS_X :: const SkeletonModifier3D.BONE_DIRECTION_MINUS_X: BoneDirection = 1
Enumerated value for the -X axis.

## BONE_DIRECTION_PLUS_Y :: const SkeletonModifier3D.BONE_DIRECTION_PLUS_Y: BoneDirection = 2
Enumerated value for the +Y axis.

## BONE_DIRECTION_MINUS_Y :: const SkeletonModifier3D.BONE_DIRECTION_MINUS_Y: BoneDirection = 3
Enumerated value for the -Y axis.

## BONE_DIRECTION_PLUS_Z :: const SkeletonModifier3D.BONE_DIRECTION_PLUS_Z: BoneDirection = 4
Enumerated value for the +Z axis.

## BONE_DIRECTION_MINUS_Z :: const SkeletonModifier3D.BONE_DIRECTION_MINUS_Z: BoneDirection = 5
Enumerated value for the -Z axis.

## BONE_DIRECTION_FROM_PARENT :: const SkeletonModifier3D.BONE_DIRECTION_FROM_PARENT: BoneDirection = 6
Enumerated value for the axis from a parent bone to the child bone.

## SECONDARY_DIRECTION_NONE :: const SkeletonModifier3D.SECONDARY_DIRECTION_NONE: SecondaryDirection = 0
Enumerated value for the case when the axis is undefined.

## SECONDARY_DIRECTION_PLUS_X :: const SkeletonModifier3D.SECONDARY_DIRECTION_PLUS_X: SecondaryDirection = 1
Enumerated value for the +X axis.

## SECONDARY_DIRECTION_MINUS_X :: const SkeletonModifier3D.SECONDARY_DIRECTION_MINUS_X: SecondaryDirection = 2
Enumerated value for the -X axis.

## SECONDARY_DIRECTION_PLUS_Y :: const SkeletonModifier3D.SECONDARY_DIRECTION_PLUS_Y: SecondaryDirection = 3
Enumerated value for the +Y axis.

## SECONDARY_DIRECTION_MINUS_Y :: const SkeletonModifier3D.SECONDARY_DIRECTION_MINUS_Y: SecondaryDirection = 4
Enumerated value for the -Y axis.

## SECONDARY_DIRECTION_PLUS_Z :: const SkeletonModifier3D.SECONDARY_DIRECTION_PLUS_Z: SecondaryDirection = 5
Enumerated value for the +Z axis.

## SECONDARY_DIRECTION_MINUS_Z :: const SkeletonModifier3D.SECONDARY_DIRECTION_MINUS_Z: SecondaryDirection = 6
Enumerated value for the -Z axis.

## SECONDARY_DIRECTION_CUSTOM :: const SkeletonModifier3D.SECONDARY_DIRECTION_CUSTOM: SecondaryDirection = 7
Enumerated value for an optional axis.

## ROTATION_AXIS_X :: const SkeletonModifier3D.ROTATION_AXIS_X: RotationAxis = 0
Enumerated value for the rotation of the X axis.

## ROTATION_AXIS_Y :: const SkeletonModifier3D.ROTATION_AXIS_Y: RotationAxis = 1
Enumerated value for the rotation of the Y axis.

## ROTATION_AXIS_Z :: const SkeletonModifier3D.ROTATION_AXIS_Z: RotationAxis = 2
Enumerated value for the rotation of the Z axis.

## ROTATION_AXIS_ALL :: const SkeletonModifier3D.ROTATION_AXIS_ALL: RotationAxis = 3
Enumerated value for the unconstrained rotation.

## ROTATION_AXIS_CUSTOM :: const SkeletonModifier3D.ROTATION_AXIS_CUSTOM: RotationAxis = 4
Enumerated value for an optional rotation axis.

## active :: var SkeletonModifier3D.active: bool
If [code]true[/code], the [SkeletonModifier3D] will be processing.

## influence :: var SkeletonModifier3D.influence: float
Sets the influence of the modification.
[b]Note:[/b] This value is used by [Skeleton3D] to blend, so the [SkeletonModifier3D] should always apply only 100% of the result without interpolation.

## _process_modification :: func SkeletonModifier3D._process_modification() -> void
Override this virtual method to implement a custom skeleton modifier. You should do things like get the [Skeleton3D]'s current pose and apply the pose here.
[method _process_modification] must not apply [member influence] to bone poses because the [Skeleton3D] automatically applies influence to all bone poses set by the modifier.

## _process_modification_with_delta :: func SkeletonModifier3D._process_modification_with_delta(delta: float) -> void
Override this virtual method to implement a custom skeleton modifier. You should do things like get the [Skeleton3D]'s current pose and apply the pose here.
[method _process_modification_with_delta] must not apply [member influence] to bone poses because the [Skeleton3D] automatically applies influence to all bone poses set by the modifier.
[param delta] is passed from parent [Skeleton3D]. See also [method Skeleton3D.advance].
[b]Note:[/b] This method may be called outside [method Node._process] and [method Node._physics_process] with [param delta] is [code]0.0[/code], since the modification should be processed immediately after initialization of the [Skeleton3D].

### delta :: float

## _skeleton_changed :: func SkeletonModifier3D._skeleton_changed(old_skeleton: Skeleton3D, new_skeleton: Skeleton3D) -> void
Called when the skeleton is changed.

### old_skeleton :: Skeleton3D

### new_skeleton :: Skeleton3D

## _validate_bone_names :: func SkeletonModifier3D._validate_bone_names() -> void
Called when bone names and indices need to be validated, such as when entering the scene tree or changing skeleton.

## get_skeleton :: func SkeletonModifier3D.get_skeleton() -> Skeleton3D
Returns the parent [Skeleton3D] node if it exists. Otherwise, returns [code]null[/code].

## modification_processed :: func SkeletonModifier3D.modification_processed() -> void
Notifies when the modification have been finished.
[b]Note:[/b] If you want to get the modified bone pose by the modifier, you must use [method Skeleton3D.get_bone_pose] or [method Skeleton3D.get_bone_global_pose] at the moment this signal is fired.
