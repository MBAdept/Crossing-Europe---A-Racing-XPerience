# OmniLight3D :: <Native> class OmniLight3D extends Light3D
Omnidirectional light, such as a light bulb or a candle.
An Omnidirectional light is a type of [Light3D] that emits light in all directions. The light is attenuated by distance and this attenuation can be configured by changing its energy, radius, and attenuation parameters.
[b]Note:[/b] When using the Mobile rendering method, only 8 omni lights can be displayed on each mesh resource. Attempting to display more than 8 omni lights on a single mesh resource will result in omni lights flickering in and out as the camera moves. When using the Compatibility rendering method, only 8 omni lights can be displayed on each mesh resource by default, but this can be increased by adjusting [member ProjectSettings.rendering/limits/opengl/max_lights_per_object].
[b]Note:[/b] When using the Mobile or Compatibility rendering methods, omni lights will only correctly affect meshes whose visibility AABB intersects with the light's AABB. If using a shader to deform the mesh in a way that makes it go outside its AABB, [member GeometryInstance3D.extra_cull_margin] must be increased on the mesh. Otherwise, the light may not be visible on the mesh.

## SHADOW_DUAL_PARABOLOID :: const OmniLight3D.SHADOW_DUAL_PARABOLOID: ShadowMode = 0
Shadows are rendered to a dual-paraboloid texture. Faster than [constant SHADOW_CUBE], but lower-quality.

## SHADOW_CUBE :: const OmniLight3D.SHADOW_CUBE: ShadowMode = 1
Shadows are rendered to a cubemap. Slower than [constant SHADOW_DUAL_PARABOLOID], but higher-quality.

## light_specular :: var OmniLight3D.light_specular: float

## omni_attenuation :: var OmniLight3D.omni_attenuation: float
Controls the distance attenuation function for omnilights.
A value of [code]0.0[/code] will maintain a constant brightness through most of the range, but smoothly attenuate the light at the edge of the range. Use a value of [code]2.0[/code] for physically accurate lights as it results in the proper inverse square attenutation.
[b]Note:[/b] Setting attenuation to [code]2.0[/code] or higher may result in distant objects receiving minimal light, even within range. For example, with a range of [code]4096[/code], an object at [code]100[/code] units is attenuated by a factor of [code]0.0001[/code]. With a default brightness of [code]1[/code], the light would not be visible at that distance.
[b]Note:[/b] Using negative or values higher than [code]10.0[/code] may lead to unexpected results.

## omni_range :: var OmniLight3D.omni_range: float
The light's radius. Note that the effectively lit area may appear to be smaller depending on the [member omni_attenuation] in use. No matter the [member omni_attenuation] in use, the light will never reach anything outside this radius.
[b]Note:[/b] [member omni_range] is not affected by [member Node3D.scale] (the light's scale or its parent's scale).

## omni_shadow_mode :: var OmniLight3D.omni_shadow_mode: OmniLight3D.ShadowMode

## shadow_normal_bias :: var OmniLight3D.shadow_normal_bias: float
