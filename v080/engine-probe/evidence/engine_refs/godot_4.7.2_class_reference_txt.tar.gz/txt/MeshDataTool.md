# MeshDataTool :: <Native> class MeshDataTool extends RefCounted
Helper tool to access and edit [Mesh] data.
MeshDataTool provides access to individual vertices in a [Mesh]. It allows users to read and edit vertex data of meshes. It also creates an array of faces and edges.
To use MeshDataTool, load a mesh with [method create_from_surface]. When you are finished editing the data commit the data to a mesh with [method commit_to_surface].
Below is an example of how MeshDataTool may be used.
[codeblocks]
[gdscript]
var mesh = ArrayMesh.new()
mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, BoxMesh.new().get_mesh_arrays())
var mdt = MeshDataTool.new()
mdt.create_from_surface(mesh, 0)
for i in range(mdt.get_vertex_count()):
	var vertex = mdt.get_vertex(i)
	# In this example we extend the mesh by one unit, which results in separated faces as it is flat shaded.
	vertex += mdt.get_vertex_normal(i)
	# Save your change.
	mdt.set_vertex(i, vertex)
mesh.clear_surfaces()
mdt.commit_to_surface(mesh)
var mi = MeshInstance.new()
mi.mesh = mesh
add_child(mi)
[/gdscript]
[csharp]
var mesh = new ArrayMesh();
mesh.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, new BoxMesh().GetMeshArrays());
var mdt = new MeshDataTool();
mdt.CreateFromSurface(mesh, 0);
for (var i = 0; i < mdt.GetVertexCount(); i++)
{
	Vector3 vertex = mdt.GetVertex(i);
	// In this example we extend the mesh by one unit, which results in separated faces as it is flat shaded.
	vertex += mdt.GetVertexNormal(i);
	// Save your change.
	mdt.SetVertex(i, vertex);
}
mesh.ClearSurfaces();
mdt.CommitToSurface(mesh);
var mi = new MeshInstance();
mi.Mesh = mesh;
AddChild(mi);
[/csharp]
[/codeblocks]
See also [ArrayMesh], [ImmediateMesh] and [SurfaceTool] for procedural geometry generation.
[b]Note:[/b] Godot uses clockwise [url=https://learnopengl.com/Advanced-OpenGL/Face-culling]winding order[/url] for front faces of triangle primitive modes.

## clear :: func MeshDataTool.clear() -> void
Clears all data currently in MeshDataTool.

## commit_to_surface :: func MeshDataTool.commit_to_surface(mesh: ArrayMesh, compression_flags: int = 0) -> int
Adds a new surface to specified [Mesh] with edited data.

### mesh :: ArrayMesh

### compression_flags :: int

## create_from_surface :: func MeshDataTool.create_from_surface(mesh: ArrayMesh, surface: int) -> int
Uses specified surface of given [Mesh] to populate data for MeshDataTool.
Requires [Mesh] with primitive type [constant Mesh.PRIMITIVE_TRIANGLES].

### mesh :: ArrayMesh

### surface :: int

## get_edge_count :: func MeshDataTool.get_edge_count() -> int
Returns the number of edges in this [Mesh].

## get_edge_faces :: func MeshDataTool.get_edge_faces(idx: int) -> PackedInt32Array
Returns array of faces that touch given edge.

### idx :: int

## get_edge_meta :: func MeshDataTool.get_edge_meta(idx: int) -> Variant
Returns meta information assigned to given edge.

### idx :: int

## get_edge_vertex :: func MeshDataTool.get_edge_vertex(idx: int, vertex: int) -> int
Returns the index of the specified [param vertex] connected to the edge at index [param idx].
[param vertex] can only be [code]0[/code] or [code]1[/code], as edges are composed of two vertices.

### idx :: int

### vertex :: int

## get_face_count :: func MeshDataTool.get_face_count() -> int
Returns the number of faces in this [Mesh].

## get_face_edge :: func MeshDataTool.get_face_edge(idx: int, edge: int) -> int
Returns the edge associated with the face at index [param idx].
[param edge] argument must be either [code]0[/code], [code]1[/code], or [code]2[/code] because a face only has three edges.

### idx :: int

### edge :: int

## get_face_meta :: func MeshDataTool.get_face_meta(idx: int) -> Variant
Returns the metadata associated with the given face.

### idx :: int

## get_face_normal :: func MeshDataTool.get_face_normal(idx: int) -> Vector3
Calculates and returns the face normal of the given face.

### idx :: int

## get_face_vertex :: func MeshDataTool.get_face_vertex(idx: int, vertex: int) -> int
Returns the specified vertex index of the given face.
[param vertex] must be either [code]0[/code], [code]1[/code], or [code]2[/code] because faces contain three vertices.
[codeblocks]
[gdscript]
var index = mesh_data_tool.get_face_vertex(0, 1) # Gets the index of the second vertex of the first face.
var position = mesh_data_tool.get_vertex(index)
var normal = mesh_data_tool.get_vertex_normal(index)
[/gdscript]
[csharp]
int index = meshDataTool.GetFaceVertex(0, 1); // Gets the index of the second vertex of the first face.
Vector3 position = meshDataTool.GetVertex(index);
Vector3 normal = meshDataTool.GetVertexNormal(index);
[/csharp]
[/codeblocks]

### idx :: int

### vertex :: int

## get_format :: func MeshDataTool.get_format() -> int
Returns the [Mesh]'s format as a combination of the [enum Mesh.ArrayFormat] flags. For example, a mesh containing both vertices and normals would return a format of [code]3[/code] because [constant Mesh.ARRAY_FORMAT_VERTEX] is [code]1[/code] and [constant Mesh.ARRAY_FORMAT_NORMAL] is [code]2[/code].

## get_material :: func MeshDataTool.get_material() -> Material
Returns the material assigned to the [Mesh].

## get_vertex :: func MeshDataTool.get_vertex(idx: int) -> Vector3
Returns the position of the given vertex.

### idx :: int

## get_vertex_bones :: func MeshDataTool.get_vertex_bones(idx: int) -> PackedInt32Array
Returns the bones of the given vertex.

### idx :: int

## get_vertex_color :: func MeshDataTool.get_vertex_color(idx: int) -> Color
Returns the color of the given vertex.

### idx :: int

## get_vertex_count :: func MeshDataTool.get_vertex_count() -> int
Returns the total number of vertices in [Mesh].

## get_vertex_edges :: func MeshDataTool.get_vertex_edges(idx: int) -> PackedInt32Array
Returns an array of edges that share the given vertex.

### idx :: int

## get_vertex_faces :: func MeshDataTool.get_vertex_faces(idx: int) -> PackedInt32Array
Returns an array of faces that share the given vertex.

### idx :: int

## get_vertex_meta :: func MeshDataTool.get_vertex_meta(idx: int) -> Variant
Returns the metadata associated with the given vertex.

### idx :: int

## get_vertex_normal :: func MeshDataTool.get_vertex_normal(idx: int) -> Vector3
Returns the normal of the given vertex.

### idx :: int

## get_vertex_tangent :: func MeshDataTool.get_vertex_tangent(idx: int) -> Plane
Returns the tangent of the given vertex.

### idx :: int

## get_vertex_uv :: func MeshDataTool.get_vertex_uv(idx: int) -> Vector2
Returns the UV of the given vertex.

### idx :: int

## get_vertex_uv2 :: func MeshDataTool.get_vertex_uv2(idx: int) -> Vector2
Returns the UV2 of the given vertex.

### idx :: int

## get_vertex_weights :: func MeshDataTool.get_vertex_weights(idx: int) -> PackedFloat32Array
Returns bone weights of the given vertex.

### idx :: int

## set_edge_meta :: func MeshDataTool.set_edge_meta(idx: int, meta: Variant) -> void
Sets the metadata of the given edge.

### idx :: int

### meta :: Variant

## set_face_meta :: func MeshDataTool.set_face_meta(idx: int, meta: Variant) -> void
Sets the metadata of the given face.

### idx :: int

### meta :: Variant

## set_material :: func MeshDataTool.set_material(material: Material) -> void
Sets the material to be used by newly-constructed [Mesh].

### material :: Material

## set_vertex :: func MeshDataTool.set_vertex(idx: int, vertex: Vector3) -> void
Sets the position of the given vertex.

### idx :: int

### vertex :: Vector3

## set_vertex_bones :: func MeshDataTool.set_vertex_bones(idx: int, bones: PackedInt32Array) -> void
Sets the bones of the given vertex.

### idx :: int

### bones :: PackedInt32Array

## set_vertex_color :: func MeshDataTool.set_vertex_color(idx: int, color: Color) -> void
Sets the color of the given vertex.

### idx :: int

### color :: Color

## set_vertex_meta :: func MeshDataTool.set_vertex_meta(idx: int, meta: Variant) -> void
Sets the metadata associated with the given vertex.

### idx :: int

### meta :: Variant

## set_vertex_normal :: func MeshDataTool.set_vertex_normal(idx: int, normal: Vector3) -> void
Sets the normal of the given vertex.

### idx :: int

### normal :: Vector3

## set_vertex_tangent :: func MeshDataTool.set_vertex_tangent(idx: int, tangent: Plane) -> void
Sets the tangent of the given vertex.
[b]Note:[/b] Even though [param tangent] is a [Plane], it does not directly represent the tangent plane. Its [member Plane.x], [member Plane.y], and [member Plane.z] represent the tangent vector and [member Plane.d] should be either [code]-1[/code] or [code]1[/code]. See also [constant Mesh.ARRAY_TANGENT].

### idx :: int

### tangent :: Plane

## set_vertex_uv :: func MeshDataTool.set_vertex_uv(idx: int, uv: Vector2) -> void
Sets the UV of the given vertex.

### idx :: int

### uv :: Vector2

## set_vertex_uv2 :: func MeshDataTool.set_vertex_uv2(idx: int, uv2: Vector2) -> void
Sets the UV2 of the given vertex.

### idx :: int

### uv2 :: Vector2

## set_vertex_weights :: func MeshDataTool.set_vertex_weights(idx: int, weights: PackedFloat32Array) -> void
Sets the bone weights of the given vertex.

### idx :: int

### weights :: PackedFloat32Array
