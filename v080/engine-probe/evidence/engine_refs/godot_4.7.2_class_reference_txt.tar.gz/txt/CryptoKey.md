# CryptoKey :: <Native> class CryptoKey extends Resource
A cryptographic key (RSA or elliptic-curve).
The CryptoKey class represents a cryptographic key. Keys can be loaded and saved like any other [Resource].
They can be used to generate a self-signed [X509Certificate] via [method Crypto.generate_self_signed_certificate] and as private key in [method StreamPeerTLS.accept_stream] along with the appropriate certificate.

## is_public_only :: func CryptoKey.is_public_only() -> bool
Returns [code]true[/code] if this CryptoKey only has the public part, and not the private one.

## load :: func CryptoKey.load(path: String, public_only: bool = false) -> int
Loads a key from [param path]. If [param public_only] is [code]true[/code], only the public key will be loaded.
[b]Note:[/b] [param path] should be a "*.pub" file if [param public_only] is [code]true[/code], a "*.key" file otherwise.

### path :: String

### public_only :: bool

## load_from_string :: func CryptoKey.load_from_string(string_key: String, public_only: bool = false) -> int
Loads a key from the given [param string_key]. If [param public_only] is [code]true[/code], only the public key will be loaded.

### string_key :: String

### public_only :: bool

## save :: func CryptoKey.save(path: String, public_only: bool = false) -> int
Saves a key to the given [param path]. If [param public_only] is [code]true[/code], only the public key will be saved.
[b]Note:[/b] [param path] should be a "*.pub" file if [param public_only] is [code]true[/code], a "*.key" file otherwise.

### path :: String

### public_only :: bool

## save_to_string :: func CryptoKey.save_to_string(public_only: bool = false) -> String
Returns a string containing the key in PEM format. If [param public_only] is [code]true[/code], only the public key will be included.

### public_only :: bool
