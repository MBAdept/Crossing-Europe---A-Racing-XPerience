# OpenXRAPIExtension :: <Native> class OpenXRAPIExtension extends RefCounted
Makes the OpenXR API available for GDExtension.
[OpenXRAPIExtension] makes OpenXR available for GDExtension. It provides the OpenXR API to GDExtension through the [method get_instance_proc_addr] method, and the OpenXR instance through [method get_instance].
It also provides methods for querying the status of OpenXR initialization, and helper methods for ease of use of the API with GDExtension.

## OPENXR_ALPHA_BLEND_MODE_SUPPORT_NONE :: const OpenXRAPIExtension.OPENXR_ALPHA_BLEND_MODE_SUPPORT_NONE: OpenXRAlphaBlendModeSupport = 0
Means that [constant XRInterface.XR_ENV_BLEND_MODE_ALPHA_BLEND] isn't supported at all.

## OPENXR_ALPHA_BLEND_MODE_SUPPORT_REAL :: const OpenXRAPIExtension.OPENXR_ALPHA_BLEND_MODE_SUPPORT_REAL: OpenXRAlphaBlendModeSupport = 1
Means that [constant XRInterface.XR_ENV_BLEND_MODE_ALPHA_BLEND] is really supported.

## OPENXR_ALPHA_BLEND_MODE_SUPPORT_EMULATING :: const OpenXRAPIExtension.OPENXR_ALPHA_BLEND_MODE_SUPPORT_EMULATING: OpenXRAlphaBlendModeSupport = 2
Means that [constant XRInterface.XR_ENV_BLEND_MODE_ALPHA_BLEND] is emulated.

## action_get_handle :: func OpenXRAPIExtension.action_get_handle(action: RID) -> int
Returns the corresponding [code]XrAction[/code] OpenXR handle for the given action RID.

### action :: RID

## begin_debug_label_region :: func OpenXRAPIExtension.begin_debug_label_region(label_name: String) -> void
Begins a new debug label region, this label will be reported in debug messages for any calls following this until [method end_debug_label_region] is called. Debug labels can be stacked.

### label_name :: String

## can_render :: func OpenXRAPIExtension.can_render() -> bool
Returns [code]true[/code] if OpenXR is initialized for rendering with an XR viewport.

## end_debug_label_region :: func OpenXRAPIExtension.end_debug_label_region() -> void
Marks the end of a debug label region. Removes the latest debug label region added by calling [method begin_debug_label_region].

## find_action :: func OpenXRAPIExtension.find_action(name: String, action_set: RID) -> RID
Returns the [RID] corresponding to an [code]Action[/code] of a matching name, optionally limited to a specified action set.

### name :: String

### action_set :: RID

## get_error_string :: func OpenXRAPIExtension.get_error_string(result: int) -> String
Returns an error string for the given [url=https://registry.khronos.org/OpenXR/specs/1.0/man/html/XrResult.html]XrResult[/url].

### result :: int

## get_hand_tracker :: func OpenXRAPIExtension.get_hand_tracker(hand_index: int) -> int
Returns the corresponding [code]XRHandTrackerEXT[/code] handle for the given hand index value.

### hand_index :: int

## get_instance :: func OpenXRAPIExtension.get_instance() -> int
Returns the [url=https://registry.khronos.org/OpenXR/specs/1.0/man/html/XrInstance.html]XrInstance[/url] created during the initialization of the OpenXR API.

## get_instance_proc_addr :: func OpenXRAPIExtension.get_instance_proc_addr(name: String) -> int
Returns the function pointer of the OpenXR function with the specified name, cast to an integer. If the function with the given name does not exist, the method returns [code]0[/code].
[b]Note:[/b] [code]openxr/util.h[/code] contains utility macros for acquiring OpenXR functions, e.g. [code]GDEXTENSION_INIT_XR_FUNC_V(xrCreateAction)[/code].

### name :: String

## get_next_frame_time :: func OpenXRAPIExtension.get_next_frame_time() -> int
Returns the predicted display timing for the next frame.

## get_openxr_version :: func OpenXRAPIExtension.get_openxr_version() -> int
Returns the version of OpenXR that was initialized. Only valid after the OpenXR instance has been created. See [url=https://registry.khronos.org/OpenXR/specs/1.1/html/xrspec.html#XR_MAKE_VERSION]XR_MAKE_VERSION[/url] for how the version is calculated.

## get_play_space :: func OpenXRAPIExtension.get_play_space() -> int
Returns the play space, which is an [url=https://registry.khronos.org/OpenXR/specs/1.0/man/html/XrSpace.html]XrSpace[/url] cast to an integer.

## get_predicted_display_time :: func OpenXRAPIExtension.get_predicted_display_time() -> int
Returns the predicted display timing for the current frame.

## get_projection_layer :: func OpenXRAPIExtension.get_projection_layer() -> int
Returns a pointer to the render state's [code]XrCompositionLayerProjection[/code] struct.
[b]Note:[/b] This method should only be called from the rendering thread.

## get_render_state_z_far :: func OpenXRAPIExtension.get_render_state_z_far() -> float
Returns the far boundary value of the camera frustum.
[b]Note:[/b] This is only accessible in the render thread.

## get_render_state_z_near :: func OpenXRAPIExtension.get_render_state_z_near() -> float
Returns the near boundary value of the camera frustum.
[b]Note:[/b] This is only accessible in the render thread.

## get_session :: func OpenXRAPIExtension.get_session() -> int
Returns the OpenXR session, which is an [url=https://registry.khronos.org/OpenXR/specs/1.0/man/html/XrSession.html]XrSession[/url] cast to an integer.

## get_supported_swapchain_formats :: func OpenXRAPIExtension.get_supported_swapchain_formats() -> PackedInt64Array
Returns an array of supported swapchain formats.

## get_swapchain_format_name :: func OpenXRAPIExtension.get_swapchain_format_name(swapchain_format: int) -> String
Returns the name of the specified swapchain format.

### swapchain_format :: int

## get_system_id :: func OpenXRAPIExtension.get_system_id() -> int
Returns the ID of the system, which is an [url=https://registry.khronos.org/OpenXR/specs/1.0/man/html/XrSystemId.html]XrSystemId[/url] cast to an integer.

## get_view_configuration :: func OpenXRAPIExtension.get_view_configuration() -> int
Returns the view configuration type, which is an [url=https://registry.khronos.org/OpenXR/specs/1.0/man/html/XrViewConfigurationType.html]XrViewConfigurationType[/url] cast to an integer.

## get_view_count :: func OpenXRAPIExtension.get_view_count() -> int
Returns the number of views. It is usually two, one for each eye, but may differ with different view configurations.

## insert_debug_label :: func OpenXRAPIExtension.insert_debug_label(label_name: String) -> void
Inserts a debug label, this label is reported in any debug message resulting from the OpenXR calls that follows, until any of [method begin_debug_label_region], [method end_debug_label_region], or [method insert_debug_label] is called.

### label_name :: String

## is_environment_blend_mode_alpha_supported :: func OpenXRAPIExtension.is_environment_blend_mode_alpha_supported() -> int
Returns [enum OpenXRAPIExtension.OpenXRAlphaBlendModeSupport] denoting if [constant XRInterface.XR_ENV_BLEND_MODE_ALPHA_BLEND] is really supported, emulated or not supported at all.

## is_initialized :: func OpenXRAPIExtension.is_initialized() -> bool
Returns [code]true[/code] if OpenXR is initialized.

## is_running :: func OpenXRAPIExtension.is_running() -> bool
Returns [code]true[/code] if OpenXR is running ([url=https://registry.khronos.org/OpenXR/specs/1.0/man/html/xrBeginSession.html]xrBeginSession[/url] was successfully called and the swapchains were created).

## openxr_is_enabled :: func OpenXRAPIExtension.openxr_is_enabled(check_run_in_editor: bool) -> bool
Returns [code]true[/code] if OpenXR is enabled.

### check_run_in_editor :: bool

## openxr_swapchain_acquire :: func OpenXRAPIExtension.openxr_swapchain_acquire(swapchain: int) -> void
Acquires the image of the provided swapchain.

### swapchain :: int

## openxr_swapchain_create :: func OpenXRAPIExtension.openxr_swapchain_create(create_flags: int, usage_flags: int, swapchain_format: int, width: int, height: int, sample_count: int, array_size: int) -> int
Returns a pointer to a new swapchain created using the provided parameters.

### create_flags :: int

### usage_flags :: int

### swapchain_format :: int

### width :: int

### height :: int

### sample_count :: int

### array_size :: int

## openxr_swapchain_free :: func OpenXRAPIExtension.openxr_swapchain_free(swapchain: int) -> void
Destroys the provided swapchain and frees it from memory.

### swapchain :: int

## openxr_swapchain_get_image :: func OpenXRAPIExtension.openxr_swapchain_get_image(swapchain: int) -> RID
Returns the RID of the provided swapchain's image.

### swapchain :: int

## openxr_swapchain_get_swapchain :: func OpenXRAPIExtension.openxr_swapchain_get_swapchain(swapchain: int) -> int
Returns the [code]XrSwapchain[/code] handle of the provided swapchain.

### swapchain :: int

## openxr_swapchain_release :: func OpenXRAPIExtension.openxr_swapchain_release(swapchain: int) -> void
Releases the image of the provided swapchain.

### swapchain :: int

## register_composition_layer_provider :: func OpenXRAPIExtension.register_composition_layer_provider(extension: OpenXRExtensionWrapper) -> void
Registers the given extension as a composition layer provider.
[b]Note:[/b] This cannot be called after the OpenXR session has started. However, it can be called in [method OpenXRExtensionWrapper._on_session_created].

### extension :: OpenXRExtensionWrapper

## register_frame_info_extension :: func OpenXRAPIExtension.register_frame_info_extension(extension: OpenXRExtensionWrapper) -> void
Registers the given extension as modifying frame info via the [method OpenXRExtensionWrapper._set_frame_wait_info_and_get_next_pointer], [method OpenXRExtensionWrapper._set_view_locate_info_and_get_next_pointer], or [method OpenXRExtensionWrapper._set_frame_end_info_and_get_next_pointer] virtual methods.
[b]Note:[/b] This cannot be called after the OpenXR session has started. However, it can be called in [method OpenXRExtensionWrapper._on_session_created].

### extension :: OpenXRExtensionWrapper

## register_projection_layer_extension :: func OpenXRAPIExtension.register_projection_layer_extension(extension: OpenXRExtensionWrapper) -> void
Registers the given extension as modifying [code]XrCompositionLayerProjection[/code] via the [method OpenXRExtensionWrapper._set_projection_layer_and_get_next_pointer] virtual method.
[b]Note:[/b] This cannot be called after the OpenXR session has started. However, it can be called in [method OpenXRExtensionWrapper._on_session_created].

### extension :: OpenXRExtensionWrapper

## register_projection_views_extension :: func OpenXRAPIExtension.register_projection_views_extension(extension: OpenXRExtensionWrapper) -> void
Registers the given extension as a provider of additional data structures to projections views.
[b]Note:[/b] This cannot be called after the OpenXR session has started. However, it can be called in [method OpenXRExtensionWrapper._on_session_created].

### extension :: OpenXRExtensionWrapper

## set_custom_play_space :: func OpenXRAPIExtension.set_custom_play_space(space: const void*) -> void
Sets the reference space used by OpenXR to the given [url=https://registry.khronos.org/OpenXR/specs/1.0/man/html/XrSpace.html]XrSpace[/url] (cast to a [code]void *[/code]).

### space :: const void*

## set_emulate_environment_blend_mode_alpha_blend :: func OpenXRAPIExtension.set_emulate_environment_blend_mode_alpha_blend(enabled: bool) -> void
If set to [code]true[/code], an OpenXR extension is loaded which is capable of emulating the [constant XRInterface.XR_ENV_BLEND_MODE_ALPHA_BLEND] blend mode.

### enabled :: bool

## set_object_name :: func OpenXRAPIExtension.set_object_name(object_type: int, object_handle: int, object_name: String) -> void
Set the object name of an OpenXR object, used for debug output. [param object_type] must be a valid OpenXR [code]XrObjectType[/code] enum and [param object_handle] must be a valid OpenXR object handle.

### object_type :: int

### object_handle :: int

### object_name :: String

## set_render_region :: func OpenXRAPIExtension.set_render_region(render_region: Rect2i) -> void
Sets the render region to [param render_region], overriding the normal render target's rect.

### render_region :: Rect2i

## set_velocity_depth_texture :: func OpenXRAPIExtension.set_velocity_depth_texture(render_target: RID) -> void
Sets the render target of the velocity depth texture.

### render_target :: RID

## set_velocity_target_size :: func OpenXRAPIExtension.set_velocity_target_size(target_size: Vector2i) -> void
Sets the target size of the velocity and velocity depth textures.

### target_size :: Vector2i

## set_velocity_texture :: func OpenXRAPIExtension.set_velocity_texture(render_target: RID) -> void
Sets the render target of the velocity texture.

### render_target :: RID

## transform_from_pose :: func OpenXRAPIExtension.transform_from_pose(pose: const void*) -> Transform3D
Creates a [Transform3D] from an [url=https://registry.khronos.org/OpenXR/specs/1.0/man/html/XrPosef.html]XrPosef[/url].

### pose :: const void*

## unregister_composition_layer_provider :: func OpenXRAPIExtension.unregister_composition_layer_provider(extension: OpenXRExtensionWrapper) -> void
Unregisters the given extension as a composition layer provider.
[b]Note:[/b] This cannot be called while the OpenXR session is still running.

### extension :: OpenXRExtensionWrapper

## unregister_frame_info_extension :: func OpenXRAPIExtension.unregister_frame_info_extension(extension: OpenXRExtensionWrapper) -> void
Unregisters the given extension as modifying frame info.
[b]Note:[/b] This cannot be called while the OpenXR session is still running.

### extension :: OpenXRExtensionWrapper

## unregister_projection_layer_extension :: func OpenXRAPIExtension.unregister_projection_layer_extension(extension: OpenXRExtensionWrapper) -> void
Unregisters the given extension as modifying [code]XrCompositionLayerProjection[/code].
[b]Note:[/b] This cannot be called while the OpenXR session is still running.

### extension :: OpenXRExtensionWrapper

## unregister_projection_views_extension :: func OpenXRAPIExtension.unregister_projection_views_extension(extension: OpenXRExtensionWrapper) -> void
Unregisters the given extension as a provider of additional data structures to projections views.
[b]Note:[/b] This cannot be called while the OpenXR session is still running.

### extension :: OpenXRExtensionWrapper

## update_main_swapchain_size :: func OpenXRAPIExtension.update_main_swapchain_size() -> void
Request the recommended resolution from the OpenXR runtime and update the main swapchain size if it has changed.

## xr_result :: func OpenXRAPIExtension.xr_result(result: int, format: String, args: Array) -> bool
Returns [code]true[/code] if the provided [url=https://registry.khronos.org/OpenXR/specs/1.0/man/html/XrResult.html]XrResult[/url] (cast to an integer) is successful. Otherwise returns [code]false[/code] and prints the [url=https://registry.khronos.org/OpenXR/specs/1.0/man/html/XrResult.html]XrResult[/url] converted to a string, with the specified additional information.

### result :: int

### format :: String

### args :: Array
