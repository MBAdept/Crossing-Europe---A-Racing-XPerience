# EditorSceneFormatImporterFBX2GLTF :: <Native> class EditorSceneFormatImporterFBX2GLTF extends EditorSceneFormatImporter
Importer for the [code].fbx[/code] scene file format.
Imports Autodesk FBX 3D scenes by way of converting them to glTF 2.0 using the FBX2glTF command line tool.
The location of the FBX2glTF binary is set via the [member EditorSettings.filesystem/import/fbx/fbx2gltf_path] editor setting.
This importer is only used if [member ProjectSettings.filesystem/import/fbx2gltf/enabled] is set to [code]true[/code].
