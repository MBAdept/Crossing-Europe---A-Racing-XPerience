# Joint3D :: <Native> class Joint3D extends Node3D
Abstract base class for all 3D physics joints.
Abstract base class for all joints in 3D physics. 3D joints bind together two physics bodies ([member node_a] and [member node_b]) and apply a constraint. If only one body is defined, it is attached to a fixed [StaticBody3D] without collision shapes.

## exclude_nodes_from_collision :: var Joint3D.exclude_nodes_from_collision: bool
If [code]true[/code], the two bodies bound together do not collide with each other.

## node_a :: var Joint3D.node_a: NodePath
Path to the first node (A) attached to the joint. The node must inherit [PhysicsBody3D].
If left empty and [member node_b] is set, the body is attached to a fixed [StaticBody3D] without collision shapes.

## node_b :: var Joint3D.node_b: NodePath
Path to the second node (B) attached to the joint. The node must inherit [PhysicsBody3D].
If left empty and [member node_a] is set, the body is attached to a fixed [StaticBody3D] without collision shapes.

## solver_priority :: var Joint3D.solver_priority: int
The priority used to define which solver is executed first for multiple joints. The lower the value, the higher the priority.
[b]Note:[/b] Only supported when using GodotPhysics3D. This property is ignored when using Jolt Physics.

## get_rid :: func Joint3D.get_rid() -> RID
Returns the joint's internal [RID] from the [PhysicsServer3D].
