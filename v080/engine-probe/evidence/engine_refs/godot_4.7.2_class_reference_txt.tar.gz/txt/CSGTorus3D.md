# CSGTorus3D :: <Native> class CSGTorus3D extends CSGPrimitive3D
A CSG Torus shape.
This node allows you to create a torus for use with the CSG system.
[b]Note:[/b] CSG nodes are intended to be used for level prototyping. Creating CSG nodes has a significant CPU cost compared to creating a [MeshInstance3D] with a [PrimitiveMesh]. Moving a CSG node within another CSG node also has a significant CPU cost, so it should be avoided during gameplay.

## inner_radius :: var CSGTorus3D.inner_radius: float
The inner radius of the torus.

## material :: var CSGTorus3D.material: Material
The material used to render the torus.

## outer_radius :: var CSGTorus3D.outer_radius: float
The outer radius of the torus.

## ring_sides :: var CSGTorus3D.ring_sides: int
The number of edges each ring of the torus is constructed of.

## sides :: var CSGTorus3D.sides: int
The number of slices the torus is constructed of.

## smooth_faces :: var CSGTorus3D.smooth_faces: bool
If [code]true[/code] the normals of the torus are set to give a smooth effect making the torus seem rounded. If [code]false[/code] the torus will have a flat shaded look.
