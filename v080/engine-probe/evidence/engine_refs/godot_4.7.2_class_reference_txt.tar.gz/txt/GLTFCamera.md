# GLTFCamera :: <Native> class GLTFCamera extends Resource
Represents a glTF camera.
Represents a camera as defined by the base glTF spec.

## depth_far :: var GLTFCamera.depth_far: float
The distance to the far culling boundary for this camera relative to its local Z axis, in meters. This maps to glTF's [code]zfar[/code] property.

## depth_near :: var GLTFCamera.depth_near: float
The distance to the near culling boundary for this camera relative to its local Z axis, in meters. This maps to glTF's [code]znear[/code] property.

## fov :: var GLTFCamera.fov: float
The FOV of the camera. This class and glTF define the camera FOV in radians, while Godot uses degrees. This maps to glTF's [code]yfov[/code] property. This value is only used for perspective cameras, when [member perspective] is [code]true[/code].

## perspective :: var GLTFCamera.perspective: bool
If [code]true[/code], the camera is in perspective mode. Otherwise, the camera is in orthographic/orthogonal mode. This maps to glTF's camera [code]type[/code] property. See [member Camera3D.projection] and the glTF spec for more information.

## size_mag :: var GLTFCamera.size_mag: float
The size of the camera. This class and glTF define the camera size magnitude as a radius in meters, while Godot defines it as a diameter in meters. This maps to glTF's [code]ymag[/code] property. This value is only used for orthographic/orthogonal cameras, when [member perspective] is [code]false[/code].

## from_dictionary :: func GLTFCamera.from_dictionary(dictionary: Dictionary) -> GLTFCamera
Creates a new GLTFCamera instance by parsing the given [Dictionary].

### dictionary :: Dictionary

## from_node :: func GLTFCamera.from_node(camera_node: Camera3D) -> GLTFCamera
Create a new GLTFCamera instance from the given Godot [Camera3D] node.

### camera_node :: Camera3D

## to_dictionary :: func GLTFCamera.to_dictionary() -> Dictionary
Serializes this GLTFCamera instance into a [Dictionary].

## to_node :: func GLTFCamera.to_node() -> Camera3D
Converts this GLTFCamera instance into a Godot [Camera3D] node.
