# ResourceImporter :: <Native> class ResourceImporter extends RefCounted
Base class for resource importers.
This is the base class for Godot's resource importers. To implement your own resource importers using editor plugins, see [EditorImportPlugin].

## IMPORT_ORDER_DEFAULT :: const ResourceImporter.IMPORT_ORDER_DEFAULT: ImportOrder = 0
The default import order.

## IMPORT_ORDER_SCENE :: const ResourceImporter.IMPORT_ORDER_SCENE: ImportOrder = 100
The import order for scenes, which ensures scenes are imported [i]after[/i] all other core resources such as textures. Custom importers should generally have an import order lower than [code]100[/code] to avoid issues when importing scenes that rely on custom resources.

## _get_build_dependencies :: func ResourceImporter._get_build_dependencies(path: String) -> PackedStringArray
Called when the engine compilation profile editor wants to check what build options an imported resource needs. For example, [ResourceImporterDynamicFont] has a property called [member ResourceImporterDynamicFont.multichannel_signed_distance_field], that depends on the engine to be build with the "msdfgen" module. If that resource happened to be a custom one, it would be handled like this:
[codeblock]
func _get_build_dependencies(path):
	var resource = load(path)
	var dependencies = PackedStringArray()

	if resource.multichannel_signed_distance_field:
		dependencies.push_back("module_msdfgen_enabled")

	return dependencies
[/codeblock]

### path :: String
