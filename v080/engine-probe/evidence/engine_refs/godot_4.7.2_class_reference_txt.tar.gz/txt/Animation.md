# Animation :: <Native> class Animation extends Resource
Holds data that can be used to animate anything in the engine.
This resource holds data that can be used to animate anything in the engine. Animations are divided into tracks and each track must be linked to a node. The state of that node can be changed through time, by adding timed keys (events) to the track.
[codeblocks]
[gdscript]
# This creates an animation that makes the node "Enemy" move to the right by
# 100 pixels in 2.0 seconds.
var animation = Animation.new()
var track_index = animation.add_track(Animation.TYPE_VALUE)
animation.track_set_path(track_index, "Enemy:position:x")
animation.track_insert_key(track_index, 0.0, 0)
animation.track_insert_key(track_index, 2.0, 100)
animation.length = 2.0
[/gdscript]
[csharp]
// This creates an animation that makes the node "Enemy" move to the right by
// 100 pixels in 2.0 seconds.
var animation = new Animation();
int trackIndex = animation.AddTrack(Animation.TrackType.Value);
animation.TrackSetPath(trackIndex, "Enemy:position:x");
animation.TrackInsertKey(trackIndex, 0.0f, 0);
animation.TrackInsertKey(trackIndex, 2.0f, 100);
animation.Length = 2.0f;
[/csharp]
[/codeblocks]
Animations are just data containers, and must be added to nodes such as an [AnimationPlayer] to be played back. Animation tracks have different types, each with its own set of dedicated methods. Check [enum TrackType] to see available types.
[b]Note:[/b] For 3D position/rotation/scale, using the dedicated [constant TYPE_POSITION_3D], [constant TYPE_ROTATION_3D] and [constant TYPE_SCALE_3D] track types instead of [constant TYPE_VALUE] is recommended for performance reasons.

## TYPE_VALUE :: const Animation.TYPE_VALUE: TrackType = 0
Value tracks set values in node properties, but only those which can be interpolated. For 3D position/rotation/scale, using the dedicated [constant TYPE_POSITION_3D], [constant TYPE_ROTATION_3D] and [constant TYPE_SCALE_3D] track types instead of [constant TYPE_VALUE] is recommended for performance reasons.

## TYPE_POSITION_3D :: const Animation.TYPE_POSITION_3D: TrackType = 1
3D position track (values are stored in [Vector3]s).

## TYPE_ROTATION_3D :: const Animation.TYPE_ROTATION_3D: TrackType = 2
3D rotation track (values are stored in [Quaternion]s).

## TYPE_SCALE_3D :: const Animation.TYPE_SCALE_3D: TrackType = 3
3D scale track (values are stored in [Vector3]s).

## TYPE_BLEND_SHAPE :: const Animation.TYPE_BLEND_SHAPE: TrackType = 4
Blend shape track.

## TYPE_METHOD :: const Animation.TYPE_METHOD: TrackType = 5
Method tracks call functions with given arguments per key.

## TYPE_BEZIER :: const Animation.TYPE_BEZIER: TrackType = 6
Bezier tracks are used to interpolate a value using custom curves. They can also be used to animate sub-properties of vectors and colors (e.g. alpha value of a [Color]).

## TYPE_AUDIO :: const Animation.TYPE_AUDIO: TrackType = 7
Audio tracks are used to play an audio stream with either type of [AudioStreamPlayer]. The stream can be trimmed and previewed in the animation.

## TYPE_ANIMATION :: const Animation.TYPE_ANIMATION: TrackType = 8
Animation tracks play animations in other [AnimationPlayer] nodes.

## INTERPOLATION_NEAREST :: const Animation.INTERPOLATION_NEAREST: InterpolationType = 0
No interpolation (nearest value).

## INTERPOLATION_LINEAR :: const Animation.INTERPOLATION_LINEAR: InterpolationType = 1
Linear interpolation.

## INTERPOLATION_CUBIC :: const Animation.INTERPOLATION_CUBIC: InterpolationType = 2
Cubic interpolation. This looks smoother than linear interpolation, but is more expensive to interpolate. Stick to [constant INTERPOLATION_LINEAR] for complex 3D animations imported from external software, even if it requires using a higher animation framerate in return.

## INTERPOLATION_LINEAR_ANGLE :: const Animation.INTERPOLATION_LINEAR_ANGLE: InterpolationType = 3
Linear interpolation with shortest path rotation.
[b]Note:[/b] The result value is always normalized and may not match the key value.

## INTERPOLATION_CUBIC_ANGLE :: const Animation.INTERPOLATION_CUBIC_ANGLE: InterpolationType = 4
Cubic interpolation with shortest path rotation.
[b]Note:[/b] The result value is always normalized and may not match the key value.

## UPDATE_CONTINUOUS :: const Animation.UPDATE_CONTINUOUS: UpdateMode = 0
Update between keyframes and hold the value.

## UPDATE_DISCRETE :: const Animation.UPDATE_DISCRETE: UpdateMode = 1
Update at the keyframes.

## UPDATE_CAPTURE :: const Animation.UPDATE_CAPTURE: UpdateMode = 2
Same as [constant UPDATE_CONTINUOUS] but works as a flag to capture the value of the current object and perform interpolation in some methods. See also [method AnimationMixer.capture], [member AnimationPlayer.playback_auto_capture], and [method AnimationPlayer.play_with_capture].

## LOOP_NONE :: const Animation.LOOP_NONE: LoopMode = 0
At both ends of the animation, the animation will stop playing.

## LOOP_LINEAR :: const Animation.LOOP_LINEAR: LoopMode = 1
At both ends of the animation, the animation will be repeated without changing the playback direction.

## LOOP_PINGPONG :: const Animation.LOOP_PINGPONG: LoopMode = 2
Repeats playback and reverse playback at both ends of the animation.

## LOOPED_FLAG_NONE :: const Animation.LOOPED_FLAG_NONE: LoopedFlag = 0
This flag indicates that the animation proceeds without any looping.

## LOOPED_FLAG_END :: const Animation.LOOPED_FLAG_END: LoopedFlag = 1
This flag indicates that the animation has reached the end of the animation and just after loop processed.

## LOOPED_FLAG_START :: const Animation.LOOPED_FLAG_START: LoopedFlag = 2
This flag indicates that the animation has reached the start of the animation and just after loop processed.

## FIND_MODE_NEAREST :: const Animation.FIND_MODE_NEAREST: FindMode = 0
Finds the nearest time key.

## FIND_MODE_APPROX :: const Animation.FIND_MODE_APPROX: FindMode = 1
Finds only the key with approximating the time.

## FIND_MODE_EXACT :: const Animation.FIND_MODE_EXACT: FindMode = 2
Finds only the key with matching the time.

## capture_included :: var Animation.capture_included: bool
Returns [code]true[/code] if the capture track is included. This is a cached readonly value for performance.

## length :: var Animation.length: float
The total length of the animation (in seconds).
[b]Note:[/b] Length is not delimited by the last key, as this one may be before or after the end to ensure correct interpolation and looping.

## loop_mode :: var Animation.loop_mode: Animation.LoopMode
Determines the behavior of both ends of the animation timeline during animation playback. This indicates whether and how the animation should be restarted, and is also used to correctly interpolate animation cycles.

## step :: var Animation.step: float
The animation step value.

## add_marker :: func Animation.add_marker(name: StringName, time: float) -> void
Adds a marker to this Animation.

### name :: StringName

### time :: float

## add_track :: func Animation.add_track(type: int, at_position: int = -1) -> int
Adds a track to the Animation.

### type :: int

### at_position :: int

## animation_track_get_key_animation :: func Animation.animation_track_get_key_animation(track_idx: int, key_idx: int) -> StringName
Returns the animation name at the key identified by [param key_idx]. The [param track_idx] must be the index of an Animation Track.

### track_idx :: int

### key_idx :: int

## animation_track_insert_key :: func Animation.animation_track_insert_key(track_idx: int, time: float, animation: StringName) -> int
Inserts a key with value [param animation] at the given [param time] (in seconds). The [param track_idx] must be the index of an Animation Track.

### track_idx :: int

### time :: float

### animation :: StringName

## animation_track_set_key_animation :: func Animation.animation_track_set_key_animation(track_idx: int, key_idx: int, animation: StringName) -> void
Sets the key identified by [param key_idx] to value [param animation]. The [param track_idx] must be the index of an Animation Track.

### track_idx :: int

### key_idx :: int

### animation :: StringName

## audio_track_get_key_end_offset :: func Animation.audio_track_get_key_end_offset(track_idx: int, key_idx: int) -> float
Returns the end offset of the key identified by [param key_idx]. The [param track_idx] must be the index of an Audio Track.
End offset is the number of seconds cut off at the ending of the audio stream.

### track_idx :: int

### key_idx :: int

## audio_track_get_key_start_offset :: func Animation.audio_track_get_key_start_offset(track_idx: int, key_idx: int) -> float
Returns the start offset of the key identified by [param key_idx]. The [param track_idx] must be the index of an Audio Track.
Start offset is the number of seconds cut off at the beginning of the audio stream.

### track_idx :: int

### key_idx :: int

## audio_track_get_key_stream :: func Animation.audio_track_get_key_stream(track_idx: int, key_idx: int) -> Resource
Returns the audio stream of the key identified by [param key_idx]. The [param track_idx] must be the index of an Audio Track.

### track_idx :: int

### key_idx :: int

## audio_track_insert_key :: func Animation.audio_track_insert_key(track_idx: int, time: float, stream: Resource, start_offset: float = 0, end_offset: float = 0) -> int
Inserts an Audio Track key at the given [param time] in seconds. The [param track_idx] must be the index of an Audio Track.
[param stream] is the [AudioStream] resource to play. [param start_offset] is the number of seconds cut off at the beginning of the audio stream, while [param end_offset] is at the ending.

### track_idx :: int

### time :: float

### stream :: Resource

### start_offset :: float

### end_offset :: float

## audio_track_is_use_blend :: func Animation.audio_track_is_use_blend(track_idx: int) -> bool
Returns [code]true[/code] if the track at [param track_idx] will be blended with other animations.

### track_idx :: int

## audio_track_set_key_end_offset :: func Animation.audio_track_set_key_end_offset(track_idx: int, key_idx: int, offset: float) -> void
Sets the end offset of the key identified by [param key_idx] to value [param offset]. The [param track_idx] must be the index of an Audio Track.

### track_idx :: int

### key_idx :: int

### offset :: float

## audio_track_set_key_start_offset :: func Animation.audio_track_set_key_start_offset(track_idx: int, key_idx: int, offset: float) -> void
Sets the start offset of the key identified by [param key_idx] to value [param offset]. The [param track_idx] must be the index of an Audio Track.

### track_idx :: int

### key_idx :: int

### offset :: float

## audio_track_set_key_stream :: func Animation.audio_track_set_key_stream(track_idx: int, key_idx: int, stream: Resource) -> void
Sets the stream of the key identified by [param key_idx] to value [param stream]. The [param track_idx] must be the index of an Audio Track.

### track_idx :: int

### key_idx :: int

### stream :: Resource

## audio_track_set_use_blend :: func Animation.audio_track_set_use_blend(track_idx: int, enable: bool) -> void
Sets whether the track will be blended with other animations. If [code]true[/code], the audio playback volume changes depending on the blend value.

### track_idx :: int

### enable :: bool

## bezier_track_get_key_in_handle :: func Animation.bezier_track_get_key_in_handle(track_idx: int, key_idx: int) -> Vector2
Returns the in handle of the key identified by [param key_idx]. The [param track_idx] must be the index of a Bezier Track.

### track_idx :: int

### key_idx :: int

## bezier_track_get_key_out_handle :: func Animation.bezier_track_get_key_out_handle(track_idx: int, key_idx: int) -> Vector2
Returns the out handle of the key identified by [param key_idx]. The [param track_idx] must be the index of a Bezier Track.

### track_idx :: int

### key_idx :: int

## bezier_track_get_key_value :: func Animation.bezier_track_get_key_value(track_idx: int, key_idx: int) -> float
Returns the value of the key identified by [param key_idx]. The [param track_idx] must be the index of a Bezier Track.

### track_idx :: int

### key_idx :: int

## bezier_track_insert_key :: func Animation.bezier_track_insert_key(track_idx: int, time: float, value: float, in_handle: Vector2 = Vector2(0, 0), out_handle: Vector2 = Vector2(0, 0)) -> int
Inserts a Bezier Track key at the given [param time] in seconds. The [param track_idx] must be the index of a Bezier Track.
[param in_handle] is the left-side weight of the added Bezier curve point, [param out_handle] is the right-side one, while [param value] is the actual value at this point.

### track_idx :: int

### time :: float

### value :: float

### in_handle :: Vector2

### out_handle :: Vector2

## bezier_track_interpolate :: func Animation.bezier_track_interpolate(track_idx: int, time: float) -> float
Returns the interpolated value at the given [param time] (in seconds). The [param track_idx] must be the index of a Bezier Track.

### track_idx :: int

### time :: float

## bezier_track_set_key_in_handle :: func Animation.bezier_track_set_key_in_handle(track_idx: int, key_idx: int, in_handle: Vector2, balanced_value_time_ratio: float = 1.0) -> void
Sets the in handle of the key identified by [param key_idx] to value [param in_handle]. The [param track_idx] must be the index of a Bezier Track.

### track_idx :: int

### key_idx :: int

### in_handle :: Vector2

### balanced_value_time_ratio :: float

## bezier_track_set_key_out_handle :: func Animation.bezier_track_set_key_out_handle(track_idx: int, key_idx: int, out_handle: Vector2, balanced_value_time_ratio: float = 1.0) -> void
Sets the out handle of the key identified by [param key_idx] to value [param out_handle]. The [param track_idx] must be the index of a Bezier Track.

### track_idx :: int

### key_idx :: int

### out_handle :: Vector2

### balanced_value_time_ratio :: float

## bezier_track_set_key_value :: func Animation.bezier_track_set_key_value(track_idx: int, key_idx: int, value: float) -> void
Sets the value of the key identified by [param key_idx] to the given value. The [param track_idx] must be the index of a Bezier Track.

### track_idx :: int

### key_idx :: int

### value :: float

## blend_shape_track_insert_key :: func Animation.blend_shape_track_insert_key(track_idx: int, time: float, amount: float) -> int
Inserts a key in a given blend shape track. Returns the key index.

### track_idx :: int

### time :: float

### amount :: float

## blend_shape_track_interpolate :: func Animation.blend_shape_track_interpolate(track_idx: int, time_sec: float, backward: bool = false) -> float
Returns the interpolated blend shape value at the given time (in seconds). The [param track_idx] must be the index of a blend shape track.

### track_idx :: int

### time_sec :: float

### backward :: bool

## clear :: func Animation.clear() -> void
Clear the animation (clear all tracks and reset all).

## compress :: func Animation.compress(page_size: int = 8192, fps: int = 120, split_tolerance: float = 4.0) -> void
Compress the animation and all its tracks in-place. This will make [method track_is_compressed] return [code]true[/code] once called on this [Animation]. Compressed tracks require less memory to be played, and are designed to be used for complex 3D animations (such as cutscenes) imported from external 3D software. Compression is lossy, but the difference is usually not noticeable in real world conditions.
[b]Note:[/b] Compressed tracks have various limitations (such as not being editable from the editor), so only use compressed animations if you actually need them.

### page_size :: int

### fps :: int

### split_tolerance :: float

## copy_track :: func Animation.copy_track(track_idx: int, to_animation: Animation) -> void
Adds a new track to [param to_animation] that is a copy of the given track from this animation.

### track_idx :: int

### to_animation :: Animation

## find_track :: func Animation.find_track(path: NodePath, type: int) -> int
Returns the index of the specified track. If the track is not found, return -1.

### path :: NodePath

### type :: int

## get_marker_at_time :: func Animation.get_marker_at_time(time: float) -> StringName
Returns the name of the marker located at the given time.

### time :: float

## get_marker_color :: func Animation.get_marker_color(name: StringName) -> Color
Returns the given marker's color.

### name :: StringName

## get_marker_names :: func Animation.get_marker_names() -> PackedStringArray
Returns every marker in this Animation, sorted ascending by time.

## get_marker_time :: func Animation.get_marker_time(name: StringName) -> float
Returns the given marker's time.

### name :: StringName

## get_next_marker :: func Animation.get_next_marker(time: float) -> StringName
Returns the closest marker that comes after the given time. If no such marker exists, an empty string is returned.

### time :: float

## get_prev_marker :: func Animation.get_prev_marker(time: float) -> StringName
Returns the closest marker that comes before the given time. If no such marker exists, an empty string is returned.

### time :: float

## get_track_count :: func Animation.get_track_count() -> int
Returns the amount of tracks in the animation.

## has_marker :: func Animation.has_marker(name: StringName) -> bool
Returns [code]true[/code] if this Animation contains a marker with the given name.

### name :: StringName

## method_track_get_name :: func Animation.method_track_get_name(track_idx: int, key_idx: int) -> StringName
Returns the method name of a method track.

### track_idx :: int

### key_idx :: int

## method_track_get_params :: func Animation.method_track_get_params(track_idx: int, key_idx: int) -> Array
Returns the arguments values to be called on a method track for a given key in a given track.

### track_idx :: int

### key_idx :: int

## optimize :: func Animation.optimize(allowed_velocity_err: float = 0.01, allowed_angular_err: float = 0.01, precision: int = 3) -> void
Optimize the animation and all its tracks in-place. This will preserve only as many keys as are necessary to keep the animation within the specified bounds.

### allowed_velocity_err :: float

### allowed_angular_err :: float

### precision :: int

## position_track_insert_key :: func Animation.position_track_insert_key(track_idx: int, time: float, position: Vector3) -> int
Inserts a key in a given 3D position track. Returns the key index.

### track_idx :: int

### time :: float

### position :: Vector3

## position_track_interpolate :: func Animation.position_track_interpolate(track_idx: int, time_sec: float, backward: bool = false) -> Vector3
Returns the interpolated position value at the given time (in seconds). The [param track_idx] must be the index of a 3D position track.

### track_idx :: int

### time_sec :: float

### backward :: bool

## remove_marker :: func Animation.remove_marker(name: StringName) -> void
Removes the marker with the given name from this Animation.

### name :: StringName

## remove_track :: func Animation.remove_track(track_idx: int) -> void
Removes a track by specifying the track index.

### track_idx :: int

## rotation_track_insert_key :: func Animation.rotation_track_insert_key(track_idx: int, time: float, rotation: Quaternion) -> int
Inserts a key in a given 3D rotation track. Returns the key index.

### track_idx :: int

### time :: float

### rotation :: Quaternion

## rotation_track_interpolate :: func Animation.rotation_track_interpolate(track_idx: int, time_sec: float, backward: bool = false) -> Quaternion
Returns the interpolated rotation value at the given time (in seconds). The [param track_idx] must be the index of a 3D rotation track.

### track_idx :: int

### time_sec :: float

### backward :: bool

## scale_track_insert_key :: func Animation.scale_track_insert_key(track_idx: int, time: float, scale: Vector3) -> int
Inserts a key in a given 3D scale track. Returns the key index.

### track_idx :: int

### time :: float

### scale :: Vector3

## scale_track_interpolate :: func Animation.scale_track_interpolate(track_idx: int, time_sec: float, backward: bool = false) -> Vector3
Returns the interpolated scale value at the given time (in seconds). The [param track_idx] must be the index of a 3D scale track.

### track_idx :: int

### time_sec :: float

### backward :: bool

## set_marker_color :: func Animation.set_marker_color(name: StringName, color: Color) -> void
Sets the given marker's color.

### name :: StringName

### color :: Color

## track_find_key :: func Animation.track_find_key(track_idx: int, time: float, find_mode: int = 0, limit: bool = false, backward: bool = false) -> int
Finds the key index by time in a given track. Optionally, only find it if the approx/exact time is given.
If [param limit] is [code]true[/code], it does not return keys outside the animation range.
If [param backward] is [code]true[/code], the direction is reversed in methods that rely on one directional processing.
For example, in case [param find_mode] is [constant FIND_MODE_NEAREST], if there is no key in the current position just after seeked, the first key found is retrieved by searching before the position, but if [param backward] is [code]true[/code], the first key found is retrieved after the position.

### track_idx :: int

### time :: float

### find_mode :: int

### limit :: bool

### backward :: bool

## track_get_interpolation_loop_wrap :: func Animation.track_get_interpolation_loop_wrap(track_idx: int) -> bool
Returns [code]true[/code] if the track at [param track_idx] wraps the interpolation loop. New tracks wrap the interpolation loop by default.

### track_idx :: int

## track_get_interpolation_type :: func Animation.track_get_interpolation_type(track_idx: int) -> int
Returns the interpolation type of a given track.

### track_idx :: int

## track_get_key_count :: func Animation.track_get_key_count(track_idx: int) -> int
Returns the number of keys in a given track.

### track_idx :: int

## track_get_key_time :: func Animation.track_get_key_time(track_idx: int, key_idx: int) -> float
Returns the time at which the key is located.

### track_idx :: int

### key_idx :: int

## track_get_key_transition :: func Animation.track_get_key_transition(track_idx: int, key_idx: int) -> float
Returns the transition curve (easing) for a specific key (see the built-in math function [method @GlobalScope.ease]).

### track_idx :: int

### key_idx :: int

## track_get_key_value :: func Animation.track_get_key_value(track_idx: int, key_idx: int) -> Variant
Returns the value of a given key in a given track.

### track_idx :: int

### key_idx :: int

## track_get_path :: func Animation.track_get_path(track_idx: int) -> NodePath
Gets the path of a track. For more information on the path format, see [method track_set_path].

### track_idx :: int

## track_get_type :: func Animation.track_get_type(track_idx: int) -> int
Gets the type of a track.

### track_idx :: int

## track_insert_key :: func Animation.track_insert_key(track_idx: int, time: float, key: Variant, transition: float = 1) -> int
Inserts a generic key in a given track. Returns the key index.

### track_idx :: int

### time :: float

### key :: Variant

### transition :: float

## track_is_compressed :: func Animation.track_is_compressed(track_idx: int) -> bool
Returns [code]true[/code] if the track is compressed, [code]false[/code] otherwise. See also [method compress].

### track_idx :: int

## track_is_enabled :: func Animation.track_is_enabled(track_idx: int) -> bool
Returns [code]true[/code] if the track at index [param track_idx] is enabled.

### track_idx :: int

## track_is_imported :: func Animation.track_is_imported(track_idx: int) -> bool
Returns [code]true[/code] if the given track is imported. Else, return [code]false[/code].

### track_idx :: int

## track_move_down :: func Animation.track_move_down(track_idx: int) -> void
Moves a track down.

### track_idx :: int

## track_move_to :: func Animation.track_move_to(track_idx: int, to_idx: int) -> void
Changes the index position of track [param track_idx] to the one defined in [param to_idx].

### track_idx :: int

### to_idx :: int

## track_move_up :: func Animation.track_move_up(track_idx: int) -> void
Moves a track up.

### track_idx :: int

## track_remove_key :: func Animation.track_remove_key(track_idx: int, key_idx: int) -> void
Removes a key by index in a given track.

### track_idx :: int

### key_idx :: int

## track_remove_key_at_time :: func Animation.track_remove_key_at_time(track_idx: int, time: float) -> void
Removes a key at [param time] in a given track.

### track_idx :: int

### time :: float

## track_set_enabled :: func Animation.track_set_enabled(track_idx: int, enabled: bool) -> void
Enables/disables the given track. Tracks are enabled by default.

### track_idx :: int

### enabled :: bool

## track_set_imported :: func Animation.track_set_imported(track_idx: int, imported: bool) -> void
Sets the given track as imported or not.

### track_idx :: int

### imported :: bool

## track_set_interpolation_loop_wrap :: func Animation.track_set_interpolation_loop_wrap(track_idx: int, interpolation: bool) -> void
If [code]true[/code], the track at [param track_idx] wraps the interpolation loop.

### track_idx :: int

### interpolation :: bool

## track_set_interpolation_type :: func Animation.track_set_interpolation_type(track_idx: int, interpolation: int) -> void
Sets the interpolation type of a given track.

### track_idx :: int

### interpolation :: int

## track_set_key_time :: func Animation.track_set_key_time(track_idx: int, key_idx: int, time: float) -> void
Sets the time of an existing key.

### track_idx :: int

### key_idx :: int

### time :: float

## track_set_key_transition :: func Animation.track_set_key_transition(track_idx: int, key_idx: int, transition: float) -> void
Sets the transition curve (easing) for a specific key (see the built-in math function [method @GlobalScope.ease]).

### track_idx :: int

### key_idx :: int

### transition :: float

## track_set_key_value :: func Animation.track_set_key_value(track_idx: int, key: int, value: Variant) -> void
Sets the value of an existing key.

### track_idx :: int

### key :: int

### value :: Variant

## track_set_path :: func Animation.track_set_path(track_idx: int, path: NodePath) -> void
Sets the path of a track. Paths must be valid scene-tree paths to a node and must be specified starting from the [member AnimationMixer.root_node] that will reproduce the animation. Tracks that control properties or bones must append their name after the path, separated by [code]":"[/code].
For example, [code]"character/skeleton:ankle"[/code] or [code]"character/mesh:transform/local"[/code].

### track_idx :: int

### path :: NodePath

## track_swap :: func Animation.track_swap(track_idx: int, with_idx: int) -> void
Swaps the track [param track_idx]'s index position with the track [param with_idx].

### track_idx :: int

### with_idx :: int

## value_track_get_update_mode :: func Animation.value_track_get_update_mode(track_idx: int) -> int
Returns the update mode of a value track.

### track_idx :: int

## value_track_interpolate :: func Animation.value_track_interpolate(track_idx: int, time_sec: float, backward: bool = false) -> Variant
Returns the interpolated value at the given time (in seconds). The [param track_idx] must be the index of a value track.
A [param backward] mainly affects the direction of key retrieval of the track with [constant UPDATE_DISCRETE] converted by [constant AnimationMixer.ANIMATION_CALLBACK_MODE_DISCRETE_FORCE_CONTINUOUS] to match the result with [method track_find_key].

### track_idx :: int

### time_sec :: float

### backward :: bool

## value_track_set_update_mode :: func Animation.value_track_set_update_mode(track_idx: int, mode: int) -> void
Sets the update mode of a value track.

### track_idx :: int

### mode :: int
