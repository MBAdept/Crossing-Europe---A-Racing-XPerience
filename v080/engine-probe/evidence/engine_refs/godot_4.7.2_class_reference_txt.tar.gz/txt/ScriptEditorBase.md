# ScriptEditorBase :: <Native> class ScriptEditorBase extends VBoxContainer
Base editor for editing scripts in the [ScriptEditor].
Base editor for editing scripts in the [ScriptEditor]. This does not include documentation items.

## add_syntax_highlighter :: func ScriptEditorBase.add_syntax_highlighter(highlighter: EditorSyntaxHighlighter) -> void
Adds an [EditorSyntaxHighlighter] to the open script.

### highlighter :: EditorSyntaxHighlighter

## get_base_editor :: func ScriptEditorBase.get_base_editor() -> Control
Returns the underlying [Control] used for editing scripts. For text scripts, this is a [CodeEdit].

## edited_script_changed :: func ScriptEditorBase.edited_script_changed() -> void
Emitted after script validation.

## go_to_help :: func ScriptEditorBase.go_to_help(what: String) -> void
Emitted when the user requests a specific documentation page.

### what :: String

## go_to_method :: func ScriptEditorBase.go_to_method(script: Object, method: String) -> void
Emitted when the user requests to view a specific method of a script, similar to [signal request_open_script_at_line].

### script :: Object

### method :: String

## name_changed :: func ScriptEditorBase.name_changed() -> void
Emitted after script validation or when the edited resource has changed.

## replace_in_files_requested :: func ScriptEditorBase.replace_in_files_requested(text: String) -> void
Emitted when the user request to find and replace text in the file system.

### text :: String

## request_help :: func ScriptEditorBase.request_help(topic: String) -> void
Emitted when the user requests contextual help.

### topic :: String

## request_open_script_at_line :: func ScriptEditorBase.request_open_script_at_line(script: Object, line: int) -> void
Emitted when the user requests to view a specific line of a script, similar to [signal go_to_method].

### script :: Object

### line :: int

## request_save_history :: func ScriptEditorBase.request_save_history() -> void
Emitted when the user contextual goto and the item is in the same script.

## request_save_previous_state :: func ScriptEditorBase.request_save_previous_state(state: Dictionary) -> void
Emitted when the user changes current script or moves caret by 10 or more columns within the same script.

### state :: Dictionary

## search_in_files_requested :: func ScriptEditorBase.search_in_files_requested(text: String) -> void
Emitted when the user request to search text in the file system.

### text :: String
