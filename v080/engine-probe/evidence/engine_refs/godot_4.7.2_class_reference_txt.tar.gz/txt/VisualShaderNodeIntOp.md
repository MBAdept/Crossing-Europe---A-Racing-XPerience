# VisualShaderNodeIntOp :: <Native> class VisualShaderNodeIntOp extends VisualShaderNode
An integer scalar operator to be used within the visual shader graph.
Applies [member operator] to two integer inputs: [code]a[/code] and [code]b[/code].

## OP_ADD :: const VisualShaderNodeIntOp.OP_ADD: Operator = 0
Sums two numbers using [code]a + b[/code].

## OP_SUB :: const VisualShaderNodeIntOp.OP_SUB: Operator = 1
Subtracts two numbers using [code]a - b[/code].

## OP_MUL :: const VisualShaderNodeIntOp.OP_MUL: Operator = 2
Multiplies two numbers using [code]a * b[/code].

## OP_DIV :: const VisualShaderNodeIntOp.OP_DIV: Operator = 3
Divides two numbers using [code]a / b[/code].

## OP_MOD :: const VisualShaderNodeIntOp.OP_MOD: Operator = 4
Calculates the remainder of two numbers using [code]a % b[/code].

## OP_MAX :: const VisualShaderNodeIntOp.OP_MAX: Operator = 5
Returns the greater of two numbers. Translates to [code]max(a, b)[/code] in the Godot Shader Language.

## OP_MIN :: const VisualShaderNodeIntOp.OP_MIN: Operator = 6
Returns the lesser of two numbers. Translates to [code]max(a, b)[/code] in the Godot Shader Language.

## OP_BITWISE_AND :: const VisualShaderNodeIntOp.OP_BITWISE_AND: Operator = 7
Returns the result of bitwise [code]AND[/code] operation on the integer. Translates to [code]a & b[/code] in the Godot Shader Language.

## OP_BITWISE_OR :: const VisualShaderNodeIntOp.OP_BITWISE_OR: Operator = 8
Returns the result of bitwise [code]OR[/code] operation for two integers. Translates to [code]a | b[/code] in the Godot Shader Language.

## OP_BITWISE_XOR :: const VisualShaderNodeIntOp.OP_BITWISE_XOR: Operator = 9
Returns the result of bitwise [code]XOR[/code] operation for two integers. Translates to [code]a ^ b[/code] in the Godot Shader Language.

## OP_BITWISE_LEFT_SHIFT :: const VisualShaderNodeIntOp.OP_BITWISE_LEFT_SHIFT: Operator = 10
Returns the result of bitwise left shift operation on the integer. Translates to [code]a << b[/code] in the Godot Shader Language.

## OP_BITWISE_RIGHT_SHIFT :: const VisualShaderNodeIntOp.OP_BITWISE_RIGHT_SHIFT: Operator = 11
Returns the result of bitwise right shift operation on the integer. Translates to [code]a >> b[/code] in the Godot Shader Language.

## OP_ENUM_SIZE :: const VisualShaderNodeIntOp.OP_ENUM_SIZE: Operator = 12
Represents the size of the [enum Operator] enum.

## operator :: var VisualShaderNodeIntOp.operator: VisualShaderNodeIntOp.Operator
An operator to be applied to the inputs.
