# StatusIndicator :: <Native> class StatusIndicator extends Node
Application status indicator (aka notification area icon).
[b]Note:[/b] Status indicator is implemented on macOS and Windows.

## icon :: var StatusIndicator.icon: Texture2D
Status indicator icon.

## menu :: var StatusIndicator.menu: NodePath
Status indicator native popup menu. If this is set, the [signal pressed] signal is not emitted.
[b]Note:[/b] Native popup is only supported if [NativeMenu] supports [constant NativeMenu.FEATURE_POPUP_MENU] feature.

## tooltip :: var StatusIndicator.tooltip: String
Status indicator tooltip.

## visible :: var StatusIndicator.visible: bool
If [code]true[/code], the status indicator is visible.

## get_rect :: func StatusIndicator.get_rect() -> Rect2
Returns the status indicator rectangle in screen coordinates. If this status indicator is not visible, returns an empty [Rect2].

## pressed :: func StatusIndicator.pressed(mouse_button: int, mouse_position: Vector2i) -> void
Emitted when the status indicator is pressed.

### mouse_button :: int

### mouse_position :: Vector2i
