# ConfirmationDialog :: <Native> class ConfirmationDialog extends AcceptDialog
A dialog used for confirmation of actions.
A dialog used for confirmation of actions. This window is similar to [AcceptDialog], but pressing its Cancel button can have a different outcome from pressing the OK button. The order of the two buttons varies depending on the host OS.
To get cancel action, you can use:
[codeblocks]
[gdscript]
get_cancel_button().pressed.connect(_on_canceled)
[/gdscript]
[csharp]
GetCancelButton().Pressed += OnCanceled;
[/csharp]
[/codeblocks]
[b]Note:[/b] [AcceptDialog] is invisible by default. To make it visible, call one of the [code]popup_*[/code] methods from [Window] on the node, such as [method Window.popup_centered_clamped].

## cancel_button_text :: var ConfirmationDialog.cancel_button_text: String
The text displayed by the cancel button (see [method get_cancel_button]).

## min_size :: var ConfirmationDialog.min_size: Vector2i

## size :: var ConfirmationDialog.size: Vector2i

## title :: var ConfirmationDialog.title: String

## get_cancel_button :: func ConfirmationDialog.get_cancel_button() -> Button
Returns the cancel button.
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member CanvasItem.visible] property.
