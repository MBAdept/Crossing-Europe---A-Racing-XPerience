# AudioStreamPlayback :: <Native> class AudioStreamPlayback extends RefCounted
Meta class for playing back audio.
Can play, loop, pause a scroll through audio. See [AudioStream] and [AudioStreamOggVorbis] for usage.

## _get_loop_count :: func AudioStreamPlayback._get_loop_count() -> int
Overridable method. Should return how many times this audio stream has looped. Most built-in playbacks always return [code]0[/code].

## _get_parameter :: func AudioStreamPlayback._get_parameter(name: StringName) -> Variant
Return the current value of a playback parameter by name (see [method AudioStream._get_parameter_list]).

### name :: StringName

## _get_playback_position :: func AudioStreamPlayback._get_playback_position() -> float
Overridable method. Should return the current progress along the audio stream, in seconds.

## _is_playing :: func AudioStreamPlayback._is_playing() -> bool
Overridable method. Should return [code]true[/code] if this playback is active and playing its audio stream.

## _mix :: func AudioStreamPlayback._mix(buffer: AudioFrame*, rate_scale: float, frames: int) -> int
Override this method to customize how the audio stream is mixed. This method is called even if the playback is not active.
[b]Note:[/b] It is not useful to override this method in GDScript or C#. Only GDExtension can take advantage of it.

### buffer :: AudioFrame*

### rate_scale :: float

### frames :: int

## _seek :: func AudioStreamPlayback._seek(position: float) -> void
Override this method to customize what happens when seeking this audio stream at the given [param position], such as by calling [method AudioStreamPlayer.seek].

### position :: float

## _set_parameter :: func AudioStreamPlayback._set_parameter(name: StringName, value: Variant) -> void
Set the current value of a playback parameter by name (see [method AudioStream._get_parameter_list]).

### name :: StringName

### value :: Variant

## _start :: func AudioStreamPlayback._start(from_pos: float) -> void
Override this method to customize what happens when the playback starts at the given position, such as by calling [method AudioStreamPlayer.play].

### from_pos :: float

## _stop :: func AudioStreamPlayback._stop() -> void
Override this method to customize what happens when the playback is stopped, such as by calling [method AudioStreamPlayer.stop].

## _tag_used_streams :: func AudioStreamPlayback._tag_used_streams() -> void
Overridable method. Called whenever the audio stream is mixed if the playback is active and [method AudioServer.set_enable_tagging_used_audio_streams] has been set to [code]true[/code]. Editor plugins may use this method to "tag" the current position along the audio stream and display it in a preview.

## get_loop_count :: func AudioStreamPlayback.get_loop_count() -> int
Returns the number of times the stream has looped.

## get_playback_position :: func AudioStreamPlayback.get_playback_position() -> float
Returns the current position in the stream, in seconds.

## get_sample_playback :: func AudioStreamPlayback.get_sample_playback() -> AudioSamplePlayback
Returns the [AudioSamplePlayback] associated with this [AudioStreamPlayback] for playing back the audio sample of this stream.

## is_playing :: func AudioStreamPlayback.is_playing() -> bool
Returns [code]true[/code] if the stream is playing.

## mix_audio :: func AudioStreamPlayback.mix_audio(rate_scale: float, frames: int) -> PackedVector2Array
Mixes up to [param frames] of audio from the stream from the current position, at a rate of [param rate_scale], advancing the stream.
Returns a [PackedVector2Array] where each element holds the left and right channel volume levels of each frame.
[b]Note:[/b] Can return fewer frames than requested, make sure to use the size of the return value.

### rate_scale :: float

### frames :: int

## seek :: func AudioStreamPlayback.seek(time: float = 0.0) -> void
Seeks the stream at the given [param time], in seconds.

### time :: float

## set_sample_playback :: func AudioStreamPlayback.set_sample_playback(playback_sample: AudioSamplePlayback) -> void
Associates [AudioSamplePlayback] to this [AudioStreamPlayback] for playing back the audio sample of this stream.

### playback_sample :: AudioSamplePlayback

## start :: func AudioStreamPlayback.start(from_pos: float = 0.0) -> void
Starts the stream from the given [param from_pos], in seconds.

### from_pos :: float

## stop :: func AudioStreamPlayback.stop() -> void
Stops the stream.
