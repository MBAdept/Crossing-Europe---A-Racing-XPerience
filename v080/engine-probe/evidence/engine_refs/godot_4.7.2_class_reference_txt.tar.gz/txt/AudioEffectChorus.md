# AudioEffectChorus :: <Native> class AudioEffectChorus extends AudioEffect
Adds a chorus audio effect to an audio bus.
Gives the impression of multiple audio sources.
A "chorus" effect creates multiple copies of the original audio (called "voices") with variations in pitch, and layers on top of the original, giving the impression that the sound comes from multiple sources. This creates spectral and spatial movement.
Each voice is played a short period of time after the original audio, controlled by [code]delay[/code]. An internal low-frequency oscillator (LFO) controls their pitch, and [code]depth[/code] controls the LFO's maximum amount.
In the real world, this kind of effect is found in pianos, choirs, and instrument ensembles.
This effect can also be used to widen mono audio and make digital sounds have a more natural or analog quality.

## dry :: var AudioEffectChorus.dry: float
The volume ratio of the original audio. Value can range from 0 to 1.

## voice/1/cutoff_hz :: var AudioEffectChorus.voice/1/cutoff_hz: float
The frequency threshold of the voice's low-pass filter in Hz.

## voice/1/delay_ms :: var AudioEffectChorus.voice/1/delay_ms: float
The delay of the voice in milliseconds, compared to the original audio.

## voice/1/depth_ms :: var AudioEffectChorus.voice/1/depth_ms: float
The depth of the voice's low-frequency oscillator in milliseconds.

## voice/1/level_db :: var AudioEffectChorus.voice/1/level_db: float
The gain of the voice in dB.

## voice/1/pan :: var AudioEffectChorus.voice/1/pan: float
The pan position of the voice.

## voice/1/rate_hz :: var AudioEffectChorus.voice/1/rate_hz: float
The rate of the voice's low-frequency oscillator in Hz.

## voice/2/cutoff_hz :: var AudioEffectChorus.voice/2/cutoff_hz: float
The frequency threshold of the voice's low-pass filter in Hz.

## voice/2/delay_ms :: var AudioEffectChorus.voice/2/delay_ms: float
The delay of the voice in milliseconds, compared to the original audio.

## voice/2/depth_ms :: var AudioEffectChorus.voice/2/depth_ms: float
The depth of the voice's low-frequency oscillator in milliseconds.

## voice/2/level_db :: var AudioEffectChorus.voice/2/level_db: float
The gain of the voice in dB.

## voice/2/pan :: var AudioEffectChorus.voice/2/pan: float
The pan position of the voice.

## voice/2/rate_hz :: var AudioEffectChorus.voice/2/rate_hz: float
The rate of the voice's low-frequency oscillator in Hz.

## voice/3/cutoff_hz :: var AudioEffectChorus.voice/3/cutoff_hz: float
The frequency threshold of the voice's low-pass filter in Hz.

## voice/3/delay_ms :: var AudioEffectChorus.voice/3/delay_ms: float
The delay of the voice in milliseconds, compared to the original audio.

## voice/3/depth_ms :: var AudioEffectChorus.voice/3/depth_ms: float
The depth of the voice's low-frequency oscillator in milliseconds.

## voice/3/level_db :: var AudioEffectChorus.voice/3/level_db: float
The gain of the voice in dB.

## voice/3/pan :: var AudioEffectChorus.voice/3/pan: float
The pan position of the voice.

## voice/3/rate_hz :: var AudioEffectChorus.voice/3/rate_hz: float
The rate of the voice's low-frequency oscillator in Hz.

## voice/4/cutoff_hz :: var AudioEffectChorus.voice/4/cutoff_hz: float
The frequency threshold of the voice's low-pass filter in Hz.

## voice/4/delay_ms :: var AudioEffectChorus.voice/4/delay_ms: float
The delay of the voice in milliseconds, compared to the original audio.

## voice/4/depth_ms :: var AudioEffectChorus.voice/4/depth_ms: float
The depth of the voice's low-frequency oscillator in milliseconds.

## voice/4/level_db :: var AudioEffectChorus.voice/4/level_db: float
The gain of the voice in dB.

## voice/4/pan :: var AudioEffectChorus.voice/4/pan: float
The pan position of the voice.

## voice/4/rate_hz :: var AudioEffectChorus.voice/4/rate_hz: float
The rate of the voice's low-frequency oscillator in Hz.

## voice_count :: var AudioEffectChorus.voice_count: int
The number of voices in the effect. Value can range from 1 to 4.

## wet :: var AudioEffectChorus.wet: float
The volume ratio of all voices. Value can range from 0 to 1.

## get_voice_cutoff_hz :: func AudioEffectChorus.get_voice_cutoff_hz(voice_idx: int) -> float
Returns the frequency threshold of a given [param voice_idx]'s low-pass filter in Hz. Frequencies above this value are removed from the voice.

### voice_idx :: int

## get_voice_delay_ms :: func AudioEffectChorus.get_voice_delay_ms(voice_idx: int) -> float
Returns the delay of a given [param voice_idx] in milliseconds, compared to the original audio.

### voice_idx :: int

## get_voice_depth_ms :: func AudioEffectChorus.get_voice_depth_ms(voice_idx: int) -> float
Returns the depth of a given [param voice_idx]'s low-frequency oscillator in milliseconds.

### voice_idx :: int

## get_voice_level_db :: func AudioEffectChorus.get_voice_level_db(voice_idx: int) -> float
Returns the gain of a given [param voice_idx] in dB.

### voice_idx :: int

## get_voice_pan :: func AudioEffectChorus.get_voice_pan(voice_idx: int) -> float
Returns the pan position of a given [param voice_idx]. Negative values mean the left channel, positive mean the right.

### voice_idx :: int

## get_voice_rate_hz :: func AudioEffectChorus.get_voice_rate_hz(voice_idx: int) -> float
Returns the rate of a given [param voice_idx]'s low-frequency oscillator in Hz.

### voice_idx :: int

## set_voice_cutoff_hz :: func AudioEffectChorus.set_voice_cutoff_hz(voice_idx: int, cutoff_hz: float) -> void
Sets the frequency threshold of a given [param voice_idx]'s low-pass filter in Hz. Frequencies above [param cutoff_hz] are removed from [param voice_idx]. Value can range from 1 to 20500.

### voice_idx :: int

### cutoff_hz :: float

## set_voice_delay_ms :: func AudioEffectChorus.set_voice_delay_ms(voice_idx: int, delay_ms: float) -> void
Sets the delay of a given [param voice_idx] in milliseconds, compared to the original audio. Value can range from 0 to 50.

### voice_idx :: int

### delay_ms :: float

## set_voice_depth_ms :: func AudioEffectChorus.set_voice_depth_ms(voice_idx: int, depth_ms: float) -> void
Sets the depth of a given [param voice_idx]'s low-frequency oscillator in milliseconds. Value can range from 0 to 20.

### voice_idx :: int

### depth_ms :: float

## set_voice_level_db :: func AudioEffectChorus.set_voice_level_db(voice_idx: int, level_db: float) -> void
Sets the gain of a given [param voice_idx] in dB. Value can range from -60 to 24.

### voice_idx :: int

### level_db :: float

## set_voice_pan :: func AudioEffectChorus.set_voice_pan(voice_idx: int, pan: float) -> void
Sets the pan position of a given [param voice_idx]. Negative values pan the sound to the left, positive pan to the right. Value can range from -1 to 1.

### voice_idx :: int

### pan :: float

## set_voice_rate_hz :: func AudioEffectChorus.set_voice_rate_hz(voice_idx: int, rate_hz: float) -> void
Sets the rate of a given [param voice_idx]'s low-frequency oscillator in Hz. Value can range from 0.1 to 20.

### voice_idx :: int

### rate_hz :: float
