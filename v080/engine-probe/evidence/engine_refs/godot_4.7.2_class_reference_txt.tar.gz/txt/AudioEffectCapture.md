# AudioEffectCapture :: <Native> class AudioEffectCapture extends AudioEffect
Exposes audio samples from an audio bus in real-time, such that it can be accessed as data.
Copies all audio frames, also known as "samples" or "audio samples", from the attached audio bus into its internal ring buffer. This effect does not alter the audio. Can be used for storing real-time audio data for playback, and for creating real-time audio visualizations, like an oscilloscope.
Application code should consume these audio frames from this ring buffer using [method get_buffer] and process it as needed, for example to capture data from an [AudioStreamMicrophone], implement application-defined effects, or to transmit audio over the network. When capturing audio data from a microphone, the format of the samples will be stereo 32-bit floating-point PCM.
Unlike [AudioEffectRecord], this effect only returns the raw audio samples instead of encoding them into an [AudioStream].

## buffer_length :: var AudioEffectCapture.buffer_length: float
Length of the internal ring buffer, in seconds. Higher values keep data around for longer, but require more memory. Value can range from 0.01 to 10.
[b]Note:[/b] Setting the buffer length will have no effect if already initialized.

## can_get_buffer :: func AudioEffectCapture.can_get_buffer(frames: int) -> bool
Returns [code]true[/code] if at least [param frames] samples are available to read in the internal ring buffer.

### frames :: int

## clear_buffer :: func AudioEffectCapture.clear_buffer() -> void
Clears the internal ring buffer.
[b]Note:[/b] Calling this during a capture can cause the loss of samples which causes popping in the playback.

## get_buffer :: func AudioEffectCapture.get_buffer(frames: int) -> PackedVector2Array
Gets the next [param frames] samples from the internal ring buffer.
Returns a [PackedVector2Array] containing exactly [param frames] samples if available, or an empty [PackedVector2Array] if insufficient data was available.
The samples are signed floating-point PCM between [code]-1[/code] and [code]1[/code]. You will have to scale them if you want to use them as 8 or 16-bit integer samples. ([code]v = 0x7fff * samples[0].x[/code])

### frames :: int

## get_buffer_length_frames :: func AudioEffectCapture.get_buffer_length_frames() -> int
Returns the total size of the internal ring buffer in number of samples.

## get_discarded_frames :: func AudioEffectCapture.get_discarded_frames() -> int
Returns the number of samples discarded from the audio bus due to full buffer.

## get_frames_available :: func AudioEffectCapture.get_frames_available() -> int
Returns the number of samples available to read using [method get_buffer].

## get_pushed_frames :: func AudioEffectCapture.get_pushed_frames() -> int
Returns the number of samples inserted from the audio bus.
