# GLTFSpecGloss :: <Native> class GLTFSpecGloss extends Resource
Archived glTF extension for specular/glossy materials.
KHR_materials_pbrSpecularGlossiness is an archived glTF extension. This means that it is deprecated and not recommended for new files. However, it is still supported for loading old files.

## diffuse_factor :: var GLTFSpecGloss.diffuse_factor: Color
The reflected diffuse factor of the material.

## diffuse_img :: var GLTFSpecGloss.diffuse_img: Image
The diffuse texture.

## gloss_factor :: var GLTFSpecGloss.gloss_factor: float
The glossiness or smoothness of the material.

## spec_gloss_img :: var GLTFSpecGloss.spec_gloss_img: Image
The specular-glossiness texture.

## specular_factor :: var GLTFSpecGloss.specular_factor: Color
The specular RGB color of the material. The alpha channel is unused.
