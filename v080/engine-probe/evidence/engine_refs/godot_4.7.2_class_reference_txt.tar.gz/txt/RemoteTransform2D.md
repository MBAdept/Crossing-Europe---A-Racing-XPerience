# RemoteTransform2D :: <Native> class RemoteTransform2D extends Node2D
RemoteTransform2D pushes its own [Transform2D] to another [Node2D] derived node in the scene.
RemoteTransform2D pushes its own [Transform2D] to another [Node2D] derived node (called the remote node) in the scene.
It can be set to update another node's position, rotation and/or scale. It can use either global or local coordinates.

## remote_path :: var RemoteTransform2D.remote_path: NodePath
The [NodePath] to the remote node, relative to the RemoteTransform2D's position in the scene.

## update_position :: var RemoteTransform2D.update_position: bool
If [code]true[/code], the remote node's position is updated.

## update_rotation :: var RemoteTransform2D.update_rotation: bool
If [code]true[/code], the remote node's rotation is updated.

## update_scale :: var RemoteTransform2D.update_scale: bool
If [code]true[/code], the remote node's scale is updated.

## use_global_coordinates :: var RemoteTransform2D.use_global_coordinates: bool
If [code]true[/code], global coordinates are used. If [code]false[/code], local coordinates are used.

## force_update_cache :: func RemoteTransform2D.force_update_cache() -> void
[RemoteTransform2D] caches the remote node. It may not notice if the remote node disappears; [method force_update_cache] forces it to update the cache again.
