# AnimationNodeBlendSpace2D :: <Native> class AnimationNodeBlendSpace2D extends AnimationRootNode
A set of [AnimationRootNode]s placed on 2D coordinates, crossfading between the three adjacent ones. Used by [AnimationTree].
A resource used by [AnimationNodeBlendTree].
[AnimationNodeBlendSpace2D] represents a virtual 2D space on which [AnimationRootNode]s are placed. Outputs the linear blend of the three adjacent animations using a [Vector2] weight. Adjacent in this context means the three [AnimationRootNode]s making up the triangle that contains the current value.
You can add vertices to the blend space with [method add_blend_point] and automatically triangulate it by setting [member auto_triangles] to [code]true[/code]. Otherwise, use [method add_triangle] and [method remove_triangle] to triangulate the blend space by hand.

## BLEND_MODE_INTERPOLATED :: const AnimationNodeBlendSpace2D.BLEND_MODE_INTERPOLATED: BlendMode = 0
The interpolation between animations is linear.

## BLEND_MODE_DISCRETE :: const AnimationNodeBlendSpace2D.BLEND_MODE_DISCRETE: BlendMode = 1
The blend space plays the animation of the animation node which blending position is closest to. Useful for frame-by-frame 2D animations.

## BLEND_MODE_DISCRETE_CARRY :: const AnimationNodeBlendSpace2D.BLEND_MODE_DISCRETE_CARRY: BlendMode = 2
Similar to [constant BLEND_MODE_DISCRETE], but starts the new animation at the last animation's playback position.

## SYNC_MODE_NONE :: const AnimationNodeBlendSpace2D.SYNC_MODE_NONE: SyncMode = 0
Inactive animations are frozen and do not advance.

## SYNC_MODE_INDEPENDENT :: const AnimationNodeBlendSpace2D.SYNC_MODE_INDEPENDENT: SyncMode = 1
Inactive animations advance with a weight of [code]0[/code]. This is equivalent to the previous [code]sync = true[/code] behavior.

## SYNC_MODE_CYCLIC_MUTABLE :: const AnimationNodeBlendSpace2D.SYNC_MODE_CYCLIC_MUTABLE: SyncMode = 2
All animations are time-scaled so they stay in sync, with the cycle length dynamically computed from active blend weights. This is self-normalizing: a solo animation plays at normal speed.
[b]Note:[/b] If you apply [AnimationNodeTimeSeek] to the result when handling animations of different lengths, synchronization will be broken. In such cases, it is recommended to use [member AnimationNodeAnimation.use_custom_timeline] to align the animation lengths.

## SYNC_MODE_CYCLIC_CONSTANT :: const AnimationNodeBlendSpace2D.SYNC_MODE_CYCLIC_CONSTANT: SyncMode = 3
All animations are time-scaled so they complete one cycle in [member cyclic_length] seconds, keeping them in sync regardless of their individual lengths.
[b]Note:[/b] If you apply [AnimationNodeTimeSeek] to the result when handling animations of different lengths, synchronization will be broken. In such cases, it is recommended to use [member AnimationNodeAnimation.use_custom_timeline] to align the animation lengths.

## auto_triangles :: var AnimationNodeBlendSpace2D.auto_triangles: bool
If [code]true[/code], the blend space is triangulated automatically. The mesh updates every time you add or remove points with [method add_blend_point] and [method remove_blend_point].

## blend_mode :: var AnimationNodeBlendSpace2D.blend_mode: AnimationNodeBlendSpace2D.BlendMode
Controls the interpolation between animations.

## cyclic_length :: var AnimationNodeBlendSpace2D.cyclic_length: float
The cycle length in seconds used by [constant SYNC_MODE_CYCLIC_CONSTANT]. All animations are time-scaled so they complete one full cycle in this duration. Must be greater than [code]0[/code] for cyclic sync to take effect.

## max_space :: var AnimationNodeBlendSpace2D.max_space: Vector2
The blend space's X and Y axes' upper limit for the points' position. See [method add_blend_point].

## min_space :: var AnimationNodeBlendSpace2D.min_space: Vector2
The blend space's X and Y axes' lower limit for the points' position. See [method add_blend_point].

## snap :: var AnimationNodeBlendSpace2D.snap: Vector2
Position increment to snap to when moving a point.

## sync :: var AnimationNodeBlendSpace2D.sync: bool
If [code]true[/code], sync mode is enabled (equivalent to [constant SYNC_MODE_INDEPENDENT]). This property is kept for backward compatibility.

## sync_mode :: var AnimationNodeBlendSpace2D.sync_mode: AnimationNodeBlendSpace2D.SyncMode
Controls how animations are synced when blended. See [enum SyncMode] for available options.

## x_label :: var AnimationNodeBlendSpace2D.x_label: String
Name of the blend space's X axis.

## y_label :: var AnimationNodeBlendSpace2D.y_label: String
Name of the blend space's Y axis.

## add_blend_point :: func AnimationNodeBlendSpace2D.add_blend_point(node: AnimationRootNode, pos: Vector2, at_index: int = -1, name: StringName = &"") -> void
Adds a new point with [param name] that represents a [param node] at the position set by [param pos]. You can insert it at a specific index using the [param at_index] argument. If you use the default value for [param at_index], the point is inserted at the end of the blend points array.
[b]Note:[/b] If no name is provided, safe index is used as reference. In the future, empty names will be deprecated, so explicitly passing a name is recommended.

### node :: AnimationRootNode

### pos :: Vector2

### at_index :: int

### name :: StringName

## add_triangle :: func AnimationNodeBlendSpace2D.add_triangle(x: int, y: int, z: int, at_index: int = -1) -> void
Creates a new triangle using three points [param x], [param y], and [param z]. Triangles can overlap. You can insert the triangle at a specific index using the [param at_index] argument. If you use the default value for [param at_index], the point is inserted at the end of the blend points array.

### x :: int

### y :: int

### z :: int

### at_index :: int

## find_blend_point_by_name :: func AnimationNodeBlendSpace2D.find_blend_point_by_name(name: StringName) -> int
Returns the index of the blend point with the given [param name]. Returns [code]-1[/code] if no blend point with that name is found.

### name :: StringName

## get_blend_point_count :: func AnimationNodeBlendSpace2D.get_blend_point_count() -> int
Returns the number of points in the blend space.

## get_blend_point_name :: func AnimationNodeBlendSpace2D.get_blend_point_name(point: int) -> StringName
Returns the name of the blend point at index [param point].

### point :: int

## get_blend_point_node :: func AnimationNodeBlendSpace2D.get_blend_point_node(point: int) -> AnimationRootNode
Returns the [AnimationRootNode] referenced by the point at index [param point].

### point :: int

## get_blend_point_position :: func AnimationNodeBlendSpace2D.get_blend_point_position(point: int) -> Vector2
Returns the position of the point at index [param point].

### point :: int

## get_triangle_count :: func AnimationNodeBlendSpace2D.get_triangle_count() -> int
Returns the number of triangles in the blend space.

## get_triangle_point :: func AnimationNodeBlendSpace2D.get_triangle_point(triangle: int, point: int) -> int
Returns the position of the point at index [param point] in the triangle of index [param triangle].

### triangle :: int

### point :: int

## remove_blend_point :: func AnimationNodeBlendSpace2D.remove_blend_point(point: int) -> void
Removes the point at index [param point] from the blend space.

### point :: int

## remove_triangle :: func AnimationNodeBlendSpace2D.remove_triangle(triangle: int) -> void
Removes the triangle at index [param triangle] from the blend space.

### triangle :: int

## reorder_blend_point :: func AnimationNodeBlendSpace2D.reorder_blend_point(from_index: int, to_index: int) -> void
Swaps the blend points at indices [param from_index] and [param to_index], exchanging their positions and properties.

### from_index :: int

### to_index :: int

## set_blend_point_name :: func AnimationNodeBlendSpace2D.set_blend_point_name(point: int, name: StringName) -> void
Sets the name of the blend point at index [param point]. If the name conflicts with an existing point, a unique name will be generated automatically.

### point :: int

### name :: StringName

## set_blend_point_node :: func AnimationNodeBlendSpace2D.set_blend_point_node(point: int, node: AnimationRootNode) -> void
Changes the [AnimationNode] referenced by the point at index [param point].

### point :: int

### node :: AnimationRootNode

## set_blend_point_position :: func AnimationNodeBlendSpace2D.set_blend_point_position(point: int, pos: Vector2) -> void
Updates the position of the point at index [param point] in the blend space.

### point :: int

### pos :: Vector2

## triangles_updated :: func AnimationNodeBlendSpace2D.triangles_updated() -> void
Emitted every time the blend space's triangles are created, removed, or when one of their vertices changes position.
