# VisualShaderNodeIntConstant :: <Native> class VisualShaderNodeIntConstant extends VisualShaderNodeConstant
A scalar integer constant to be used within the visual shader graph.
Translated to [code skip-lint]int[/code] in the shader language.

## constant :: var VisualShaderNodeIntConstant.constant: int
An integer constant which represents a state of this node.
