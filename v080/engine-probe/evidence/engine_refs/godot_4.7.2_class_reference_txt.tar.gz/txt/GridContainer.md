# GridContainer :: <Native> class GridContainer extends Container
A container that arranges its child controls in a grid layout.
[GridContainer] arranges its child controls in a grid layout. The number of columns is specified by the [member columns] property, whereas the number of rows depends on how many are needed for the child controls. The number of rows and columns is preserved for every size of the container.
[b]Note:[/b] [GridContainer] only works with child nodes inheriting from [Control]. It won't rearrange child nodes inheriting from [Node2D].

## columns :: var GridContainer.columns: int
The number of columns in the [GridContainer]. If modified, [GridContainer] reorders its Control-derived children to accommodate the new layout.

## h_separation :: <Theme> var GridContainer.h_separation: int
The horizontal separation of child nodes.

## v_separation :: <Theme> var GridContainer.v_separation: int
The vertical separation of child nodes.
