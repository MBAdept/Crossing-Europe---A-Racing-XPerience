# Curve3D :: <Native> class Curve3D extends Resource
Describes a Bézier curve in 3D space.
This class describes a Bézier curve in 3D space. It is mainly used to give a shape to a [Path3D], but can be manually sampled for other purposes.
It keeps a cache of precalculated points along the curve, to speed up further calculations.

## bake_interval :: var Curve3D.bake_interval: float
The distance in meters between two adjacent cached points. Changing it forces the cache to be recomputed the next time the [method get_baked_points] or [method get_baked_length] function is called. The smaller the distance, the more points in the cache and the more memory it will consume, so use with care.

## closed :: var Curve3D.closed: bool
If [code]true[/code], and the curve has more than 2 control points, the last point and the first one will be connected in a loop.

## point_count :: var Curve3D.point_count: int
The number of points describing the curve.

## point_{index}/in :: var Curve3D.point_{index}/in: Vector3
The position of the control point leading to the vertex at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. point_count - 1[/code] range.

## point_{index}/out :: var Curve3D.point_{index}/out: Vector3
The position of the control point leading out of the vertex at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. point_count - 1[/code] range.

## point_{index}/position :: var Curve3D.point_{index}/position: Vector3
The position of for the vertex at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. point_count - 1[/code] range.

## point_{index}/tilt :: var Curve3D.point_{index}/tilt: float
The tilt angle in radians for the point at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. point_count - 1[/code] range.

## up_vector_enabled :: var Curve3D.up_vector_enabled: bool
If [code]true[/code], the curve will bake up vectors used for orientation. This is used when [member PathFollow3D.rotation_mode] is set to [constant PathFollow3D.ROTATION_ORIENTED]. Changing it forces the cache to be recomputed.

## add_point :: func Curve3D.add_point(position: Vector3, in: Vector3 = Vector3(0, 0, 0), out: Vector3 = Vector3(0, 0, 0), index: int = -1) -> void
Adds a point with the specified [param position] relative to the curve's own position, with control points [param in] and [param out]. Appends the new point at the end of the point list.
If [param index] is given, the new point is inserted before the existing point identified by index [param index]. Every existing point starting from [param index] is shifted further down the list of points. The index must be greater than or equal to [code]0[/code] and must not exceed the number of existing points in the line. See [member point_count].

### position :: Vector3

### in :: Vector3

### out :: Vector3

### index :: int

## clear_points :: func Curve3D.clear_points() -> void
Removes all points from the curve.

## get_baked_length :: func Curve3D.get_baked_length() -> float
Returns the total length of the curve, based on the cached points. Given enough density (see [member bake_interval]), it should be approximate enough.

## get_baked_points :: func Curve3D.get_baked_points() -> PackedVector3Array
Returns the cache of points as a [PackedVector3Array].

## get_baked_tilts :: func Curve3D.get_baked_tilts() -> PackedFloat32Array
Returns the cache of tilts as a [PackedFloat32Array].

## get_baked_up_vectors :: func Curve3D.get_baked_up_vectors() -> PackedVector3Array
Returns the cache of up vectors as a [PackedVector3Array].
If [member up_vector_enabled] is [code]false[/code], the cache will be empty.

## get_closest_offset :: func Curve3D.get_closest_offset(to_point: Vector3) -> float
Returns the closest offset to [param to_point]. This offset is meant to be used in [method sample_baked] or [method sample_baked_up_vector].
[param to_point] must be in this curve's local space.

### to_point :: Vector3

## get_closest_point :: func Curve3D.get_closest_point(to_point: Vector3) -> Vector3
Returns the closest point on baked segments (in curve's local space) to [param to_point].
[param to_point] must be in this curve's local space.

### to_point :: Vector3

## get_point_in :: func Curve3D.get_point_in(idx: int) -> Vector3
Returns the position of the control point leading to the vertex [param idx]. The returned position is relative to the vertex [param idx]. If the index is out of bounds, the function sends an error to the console, and returns [code](0, 0, 0)[/code].

### idx :: int

## get_point_out :: func Curve3D.get_point_out(idx: int) -> Vector3
Returns the position of the control point leading out of the vertex [param idx]. The returned position is relative to the vertex [param idx]. If the index is out of bounds, the function sends an error to the console, and returns [code](0, 0, 0)[/code].

### idx :: int

## get_point_position :: func Curve3D.get_point_position(idx: int) -> Vector3
Returns the position of the vertex [param idx]. If the index is out of bounds, the function sends an error to the console, and returns [code](0, 0, 0)[/code].

### idx :: int

## get_point_tilt :: func Curve3D.get_point_tilt(idx: int) -> float
Returns the tilt angle in radians for the point [param idx]. If the index is out of bounds, the function sends an error to the console, and returns [code]0[/code].

### idx :: int

## remove_point :: func Curve3D.remove_point(idx: int) -> void
Deletes the point [param idx] from the curve. Sends an error to the console if [param idx] is out of bounds.

### idx :: int

## sample :: func Curve3D.sample(idx: int, t: float) -> Vector3
Returns the position between the vertex [param idx] and the vertex [code]idx + 1[/code], where [param t] controls if the point is the first vertex ([code]t = 0.0[/code]), the last vertex ([code]t = 1.0[/code]), or in between. Values of [param t] outside the range ([code]0.0 >= t <=1[/code]) give strange, but predictable results.
If [param idx] is out of bounds it is truncated to the first or last vertex, and [param t] is ignored. If the curve has no points, the function sends an error to the console, and returns [code](0, 0, 0)[/code].

### idx :: int

### t :: float

## sample_baked :: func Curve3D.sample_baked(offset: float = 0.0, cubic: bool = false) -> Vector3
Returns a point within the curve at position [param offset], where [param offset] is measured as a distance in 3D units along the curve. To do that, it finds the two cached points where the [param offset] lies between, then interpolates the values. This interpolation is cubic if [param cubic] is set to [code]true[/code], or linear if set to [code]false[/code].
Cubic interpolation tends to follow the curves better, but linear is faster (and often, precise enough).

### offset :: float

### cubic :: bool

## sample_baked_up_vector :: func Curve3D.sample_baked_up_vector(offset: float, apply_tilt: bool = false) -> Vector3
Returns an up vector within the curve at position [param offset], where [param offset] is measured as a distance in 3D units along the curve. To do that, it finds the two cached up vectors where the [param offset] lies between, then interpolates the values. If [param apply_tilt] is [code]true[/code], an interpolated tilt is applied to the interpolated up vector.
If the curve has no up vectors, the function sends an error to the console, and returns [code](0, 1, 0)[/code].

### offset :: float

### apply_tilt :: bool

## sample_baked_with_rotation :: func Curve3D.sample_baked_with_rotation(offset: float = 0.0, cubic: bool = false, apply_tilt: bool = false) -> Transform3D
Returns a [Transform3D] with [code]origin[/code] as point position, [code]basis.x[/code] as sideway vector, [code]basis.y[/code] as up vector, [code]basis.z[/code] as forward vector. When the curve length is 0, there is no reasonable way to calculate the rotation, all vectors aligned with global space axes. See also [method sample_baked].

### offset :: float

### cubic :: bool

### apply_tilt :: bool

## samplef :: func Curve3D.samplef(fofs: float) -> Vector3
Returns the position at the vertex [param fofs]. It calls [method sample] using the integer part of [param fofs] as [code]idx[/code], and its fractional part as [code]t[/code].

### fofs :: float

## set_point_in :: func Curve3D.set_point_in(idx: int, position: Vector3) -> void
Sets the position of the control point leading to the vertex [param idx]. If the index is out of bounds, the function sends an error to the console. The position is relative to the vertex.

### idx :: int

### position :: Vector3

## set_point_out :: func Curve3D.set_point_out(idx: int, position: Vector3) -> void
Sets the position of the control point leading out of the vertex [param idx]. If the index is out of bounds, the function sends an error to the console. The position is relative to the vertex.

### idx :: int

### position :: Vector3

## set_point_position :: func Curve3D.set_point_position(idx: int, position: Vector3) -> void
Sets the position for the vertex [param idx]. If the index is out of bounds, the function sends an error to the console.

### idx :: int

### position :: Vector3

## set_point_tilt :: func Curve3D.set_point_tilt(idx: int, tilt: float) -> void
Sets the tilt angle in radians for the point [param idx]. If the index is out of bounds, the function sends an error to the console.
The tilt controls the rotation along the look-at axis an object traveling the path would have. In the case of a curve controlling a [PathFollow3D], this tilt is an offset over the natural tilt the [PathFollow3D] calculates.

### idx :: int

### tilt :: float

## tessellate :: func Curve3D.tessellate(max_stages: int = 5, tolerance_degrees: float = 4) -> PackedVector3Array
Returns a list of points along the curve, with a curvature controlled point density. That is, the curvier parts will have more points than the straighter parts.
This approximation makes straight segments between each point, then subdivides those segments until the resulting shape is similar enough.
[param max_stages] controls how many subdivisions a curve segment may face before it is considered approximate enough. Each subdivision splits the segment in half, so the default 5 stages may mean up to 32 subdivisions per curve segment. Increase with care!
[param tolerance_degrees] controls how many degrees the midpoint of a segment may deviate from the real curve, before the segment has to be subdivided.

### max_stages :: int

### tolerance_degrees :: float

## tessellate_even_length :: func Curve3D.tessellate_even_length(max_stages: int = 5, tolerance_length: float = 0.2) -> PackedVector3Array
Returns a list of points along the curve, with almost uniform density. [param max_stages] controls how many subdivisions a curve segment may face before it is considered approximate enough. Each subdivision splits the segment in half, so the default 5 stages may mean up to 32 subdivisions per curve segment. Increase with care!
[param tolerance_length] controls the maximal distance between two neighboring points, before the segment has to be subdivided.

### max_stages :: int

### tolerance_length :: float
