# XRHandTracker :: <Native> class XRHandTracker extends XRPositionalTracker
A tracked hand in XR.
A hand tracking system will create an instance of this object and add it to the [XRServer]. This tracking system will then obtain skeleton data, convert it to the Godot Humanoid hand skeleton and store this data on the [XRHandTracker] object.
Use [XRHandModifier3D] to animate a hand mesh using hand tracking data.

## HAND_TRACKING_SOURCE_UNKNOWN :: const XRHandTracker.HAND_TRACKING_SOURCE_UNKNOWN: HandTrackingSource = 0
The source of hand tracking data is unknown.

## HAND_TRACKING_SOURCE_UNOBSTRUCTED :: const XRHandTracker.HAND_TRACKING_SOURCE_UNOBSTRUCTED: HandTrackingSource = 1
The source of hand tracking data is unobstructed, meaning that an accurate method of hand tracking is used. These include optical hand tracking, data gloves, etc.

## HAND_TRACKING_SOURCE_CONTROLLER :: const XRHandTracker.HAND_TRACKING_SOURCE_CONTROLLER: HandTrackingSource = 2
The source of hand tracking data is a controller, meaning that joint positions are inferred from controller inputs.

## HAND_TRACKING_SOURCE_NOT_TRACKED :: const XRHandTracker.HAND_TRACKING_SOURCE_NOT_TRACKED: HandTrackingSource = 3
No hand tracking data is tracked, this either means the hand is obscured, the controller is turned off, or tracking is not supported for the current input type.

## HAND_TRACKING_SOURCE_MAX :: const XRHandTracker.HAND_TRACKING_SOURCE_MAX: HandTrackingSource = 4
Represents the size of the [enum HandTrackingSource] enum.

## HAND_JOINT_PALM :: const XRHandTracker.HAND_JOINT_PALM: HandJoint = 0
Palm joint.

## HAND_JOINT_WRIST :: const XRHandTracker.HAND_JOINT_WRIST: HandJoint = 1
Wrist joint.

## HAND_JOINT_THUMB_METACARPAL :: const XRHandTracker.HAND_JOINT_THUMB_METACARPAL: HandJoint = 2
Thumb metacarpal joint.

## HAND_JOINT_THUMB_PHALANX_PROXIMAL :: const XRHandTracker.HAND_JOINT_THUMB_PHALANX_PROXIMAL: HandJoint = 3
Thumb phalanx proximal joint.

## HAND_JOINT_THUMB_PHALANX_DISTAL :: const XRHandTracker.HAND_JOINT_THUMB_PHALANX_DISTAL: HandJoint = 4
Thumb phalanx distal joint.

## HAND_JOINT_THUMB_TIP :: const XRHandTracker.HAND_JOINT_THUMB_TIP: HandJoint = 5
Thumb tip joint.

## HAND_JOINT_INDEX_FINGER_METACARPAL :: const XRHandTracker.HAND_JOINT_INDEX_FINGER_METACARPAL: HandJoint = 6
Index finger metacarpal joint.

## HAND_JOINT_INDEX_FINGER_PHALANX_PROXIMAL :: const XRHandTracker.HAND_JOINT_INDEX_FINGER_PHALANX_PROXIMAL: HandJoint = 7
Index finger phalanx proximal joint.

## HAND_JOINT_INDEX_FINGER_PHALANX_INTERMEDIATE :: const XRHandTracker.HAND_JOINT_INDEX_FINGER_PHALANX_INTERMEDIATE: HandJoint = 8
Index finger phalanx intermediate joint.

## HAND_JOINT_INDEX_FINGER_PHALANX_DISTAL :: const XRHandTracker.HAND_JOINT_INDEX_FINGER_PHALANX_DISTAL: HandJoint = 9
Index finger phalanx distal joint.

## HAND_JOINT_INDEX_FINGER_TIP :: const XRHandTracker.HAND_JOINT_INDEX_FINGER_TIP: HandJoint = 10
Index finger tip joint.

## HAND_JOINT_MIDDLE_FINGER_METACARPAL :: const XRHandTracker.HAND_JOINT_MIDDLE_FINGER_METACARPAL: HandJoint = 11
Middle finger metacarpal joint.

## HAND_JOINT_MIDDLE_FINGER_PHALANX_PROXIMAL :: const XRHandTracker.HAND_JOINT_MIDDLE_FINGER_PHALANX_PROXIMAL: HandJoint = 12
Middle finger phalanx proximal joint.

## HAND_JOINT_MIDDLE_FINGER_PHALANX_INTERMEDIATE :: const XRHandTracker.HAND_JOINT_MIDDLE_FINGER_PHALANX_INTERMEDIATE: HandJoint = 13
Middle finger phalanx intermediate joint.

## HAND_JOINT_MIDDLE_FINGER_PHALANX_DISTAL :: const XRHandTracker.HAND_JOINT_MIDDLE_FINGER_PHALANX_DISTAL: HandJoint = 14
Middle finger phalanx distal joint.

## HAND_JOINT_MIDDLE_FINGER_TIP :: const XRHandTracker.HAND_JOINT_MIDDLE_FINGER_TIP: HandJoint = 15
Middle finger tip joint.

## HAND_JOINT_RING_FINGER_METACARPAL :: const XRHandTracker.HAND_JOINT_RING_FINGER_METACARPAL: HandJoint = 16
Ring finger metacarpal joint.

## HAND_JOINT_RING_FINGER_PHALANX_PROXIMAL :: const XRHandTracker.HAND_JOINT_RING_FINGER_PHALANX_PROXIMAL: HandJoint = 17
Ring finger phalanx proximal joint.

## HAND_JOINT_RING_FINGER_PHALANX_INTERMEDIATE :: const XRHandTracker.HAND_JOINT_RING_FINGER_PHALANX_INTERMEDIATE: HandJoint = 18
Ring finger phalanx intermediate joint.

## HAND_JOINT_RING_FINGER_PHALANX_DISTAL :: const XRHandTracker.HAND_JOINT_RING_FINGER_PHALANX_DISTAL: HandJoint = 19
Ring finger phalanx distal joint.

## HAND_JOINT_RING_FINGER_TIP :: const XRHandTracker.HAND_JOINT_RING_FINGER_TIP: HandJoint = 20
Ring finger tip joint.

## HAND_JOINT_PINKY_FINGER_METACARPAL :: const XRHandTracker.HAND_JOINT_PINKY_FINGER_METACARPAL: HandJoint = 21
Pinky finger metacarpal joint.

## HAND_JOINT_PINKY_FINGER_PHALANX_PROXIMAL :: const XRHandTracker.HAND_JOINT_PINKY_FINGER_PHALANX_PROXIMAL: HandJoint = 22
Pinky finger phalanx proximal joint.

## HAND_JOINT_PINKY_FINGER_PHALANX_INTERMEDIATE :: const XRHandTracker.HAND_JOINT_PINKY_FINGER_PHALANX_INTERMEDIATE: HandJoint = 23
Pinky finger phalanx intermediate joint.

## HAND_JOINT_PINKY_FINGER_PHALANX_DISTAL :: const XRHandTracker.HAND_JOINT_PINKY_FINGER_PHALANX_DISTAL: HandJoint = 24
Pinky finger phalanx distal joint.

## HAND_JOINT_PINKY_FINGER_TIP :: const XRHandTracker.HAND_JOINT_PINKY_FINGER_TIP: HandJoint = 25
Pinky finger tip joint.

## HAND_JOINT_MAX :: const XRHandTracker.HAND_JOINT_MAX: HandJoint = 26
Represents the size of the [enum HandJoint] enum.

## HAND_JOINT_FLAG_ORIENTATION_VALID :: const XRHandTracker.HAND_JOINT_FLAG_ORIENTATION_VALID: HandJointFlags = 1
The hand joint's orientation data is valid.

## HAND_JOINT_FLAG_ORIENTATION_TRACKED :: const XRHandTracker.HAND_JOINT_FLAG_ORIENTATION_TRACKED: HandJointFlags = 2
The hand joint's orientation is actively tracked. May not be set if tracking has been temporarily lost.

## HAND_JOINT_FLAG_POSITION_VALID :: const XRHandTracker.HAND_JOINT_FLAG_POSITION_VALID: HandJointFlags = 4
The hand joint's position data is valid.

## HAND_JOINT_FLAG_POSITION_TRACKED :: const XRHandTracker.HAND_JOINT_FLAG_POSITION_TRACKED: HandJointFlags = 8
The hand joint's position is actively tracked. May not be set if tracking has been temporarily lost.

## HAND_JOINT_FLAG_LINEAR_VELOCITY_VALID :: const XRHandTracker.HAND_JOINT_FLAG_LINEAR_VELOCITY_VALID: HandJointFlags = 16
The hand joint's linear velocity data is valid.

## HAND_JOINT_FLAG_ANGULAR_VELOCITY_VALID :: const XRHandTracker.HAND_JOINT_FLAG_ANGULAR_VELOCITY_VALID: HandJointFlags = 32
The hand joint's angular velocity data is valid.

## hand :: var XRHandTracker.hand: XRPositionalTracker.TrackerHand

## hand_tracking_source :: var XRHandTracker.hand_tracking_source: XRHandTracker.HandTrackingSource
The source of the hand tracking data.

## has_tracking_data :: var XRHandTracker.has_tracking_data: bool
If [code]true[/code], the hand tracking data is valid.

## type :: var XRHandTracker.type: XRServer.TrackerType

## get_hand_joint_angular_velocity :: func XRHandTracker.get_hand_joint_angular_velocity(joint: int) -> Vector3
Returns the angular velocity for the given hand joint.

### joint :: int

## get_hand_joint_flags :: func XRHandTracker.get_hand_joint_flags(joint: int) -> int
Returns flags about the validity of the tracking data for the given hand joint.

### joint :: int

## get_hand_joint_linear_velocity :: func XRHandTracker.get_hand_joint_linear_velocity(joint: int) -> Vector3
Returns the linear velocity for the given hand joint.

### joint :: int

## get_hand_joint_radius :: func XRHandTracker.get_hand_joint_radius(joint: int) -> float
Returns the radius of the given hand joint.

### joint :: int

## get_hand_joint_transform :: func XRHandTracker.get_hand_joint_transform(joint: int) -> Transform3D
Returns the transform for the given hand joint.

### joint :: int

## set_hand_joint_angular_velocity :: func XRHandTracker.set_hand_joint_angular_velocity(joint: int, angular_velocity: Vector3) -> void
Sets the angular velocity for the given hand joint.

### joint :: int

### angular_velocity :: Vector3

## set_hand_joint_flags :: func XRHandTracker.set_hand_joint_flags(joint: int, flags: int) -> void
Sets flags about the validity of the tracking data for the given hand joint.

### joint :: int

### flags :: int

## set_hand_joint_linear_velocity :: func XRHandTracker.set_hand_joint_linear_velocity(joint: int, linear_velocity: Vector3) -> void
Sets the linear velocity for the given hand joint.

### joint :: int

### linear_velocity :: Vector3

## set_hand_joint_radius :: func XRHandTracker.set_hand_joint_radius(joint: int, radius: float) -> void
Sets the radius of the given hand joint.

### joint :: int

### radius :: float

## set_hand_joint_transform :: func XRHandTracker.set_hand_joint_transform(joint: int, transform: Transform3D) -> void
Sets the transform for the given hand joint.

### joint :: int

### transform :: Transform3D
