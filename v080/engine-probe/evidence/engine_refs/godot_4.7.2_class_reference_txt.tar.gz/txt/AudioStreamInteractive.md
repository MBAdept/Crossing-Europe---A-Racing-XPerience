# AudioStreamInteractive :: <Native> class AudioStreamInteractive extends AudioStream
Audio stream that can playback music interactively, combining clips and a transition table.
This is an audio stream that can playback music interactively, combining clips and a transition table. Clips must be added first, and then the transition rules via the [method add_transition]. Additionally, this stream exports a property parameter to control the playback via [AudioStreamPlayer], [AudioStreamPlayer2D], or [AudioStreamPlayer3D].
The way this is used is by filling a number of clips, then configuring the transition table. From there, clips are selected for playback and the music will smoothly go from the current to the new one while using the corresponding transition rule defined in the transition table.

## TRANSITION_FROM_TIME_IMMEDIATE :: const AudioStreamInteractive.TRANSITION_FROM_TIME_IMMEDIATE: TransitionFromTime = 0
Start transition as soon as possible, don't wait for any specific time position.

## TRANSITION_FROM_TIME_NEXT_BEAT :: const AudioStreamInteractive.TRANSITION_FROM_TIME_NEXT_BEAT: TransitionFromTime = 1
Transition when the clip playback position reaches the next beat.

## TRANSITION_FROM_TIME_NEXT_BAR :: const AudioStreamInteractive.TRANSITION_FROM_TIME_NEXT_BAR: TransitionFromTime = 2
Transition when the clip playback position reaches the next bar.

## TRANSITION_FROM_TIME_END :: const AudioStreamInteractive.TRANSITION_FROM_TIME_END: TransitionFromTime = 3
Transition when the current clip finished playing.

## TRANSITION_TO_TIME_SAME_POSITION :: const AudioStreamInteractive.TRANSITION_TO_TIME_SAME_POSITION: TransitionToTime = 0
Transition to the same position in the destination clip. This is useful when both clips have exactly the same length and the music should fade between them.

## TRANSITION_TO_TIME_START :: const AudioStreamInteractive.TRANSITION_TO_TIME_START: TransitionToTime = 1
Transition to the start of the destination clip.

## TRANSITION_TO_TIME_PREVIOUS_POSITION :: const AudioStreamInteractive.TRANSITION_TO_TIME_PREVIOUS_POSITION: TransitionToTime = 2
Transition to the last played position in the destination clip, if there was a previous transition from that clip. Otherwise, plays from the start of the destination clip.

## FADE_DISABLED :: const AudioStreamInteractive.FADE_DISABLED: FadeMode = 0
Do not use fade for the transition. This is useful when transitioning from a clip-end to clip-beginning, and each clip has their begin/end.

## FADE_IN :: const AudioStreamInteractive.FADE_IN: FadeMode = 1
Use a fade-in in the next clip, let the current clip finish.

## FADE_OUT :: const AudioStreamInteractive.FADE_OUT: FadeMode = 2
Use a fade-out in the current clip, the next clip will start by itself.

## FADE_CROSS :: const AudioStreamInteractive.FADE_CROSS: FadeMode = 3
Use a cross-fade between clips.

## FADE_AUTOMATIC :: const AudioStreamInteractive.FADE_AUTOMATIC: FadeMode = 4
Use automatic fade logic depending on the transition from/to. It is recommended to use this by default.

## AUTO_ADVANCE_DISABLED :: const AudioStreamInteractive.AUTO_ADVANCE_DISABLED: AutoAdvanceMode = 0
Disable auto-advance (default).

## AUTO_ADVANCE_ENABLED :: const AudioStreamInteractive.AUTO_ADVANCE_ENABLED: AutoAdvanceMode = 1
Enable auto-advance, a clip must be specified.

## AUTO_ADVANCE_RETURN_TO_HOLD :: const AudioStreamInteractive.AUTO_ADVANCE_RETURN_TO_HOLD: AutoAdvanceMode = 2
Enable auto-advance, but instead of specifying a clip, the playback will return to hold (see [method add_transition]).

## CLIP_ANY :: const AudioStreamInteractive.CLIP_ANY = -1
This constant describes that any clip is valid for a specific transition as either source or destination.

## clip_count :: var AudioStreamInteractive.clip_count: int
Amount of clips contained in this interactive player.

## initial_clip :: var AudioStreamInteractive.initial_clip: int
Index of the initial clip, which will be played first when this stream is played.

## add_transition :: func AudioStreamInteractive.add_transition(from_clip: int, to_clip: int, from_time: int, to_time: int, fade_mode: int, fade_beats: float, use_filler_clip: bool = false, filler_clip: int = -1, hold_previous: bool = false) -> void
Add a transition between two clips. Provide the indices of the source and destination clips, or use the [constant CLIP_ANY] constant to indicate that transition happens to/from any clip to this one.
* [param from_time] indicates the moment in the current clip the transition will begin after triggered.
* [param to_time] indicates the time in the next clip that the playback will start from.
* [param fade_mode] indicates how the fade will happen between clips. If unsure, just use [constant FADE_AUTOMATIC] which uses the most common type of fade for each situation.
* [param fade_beats] indicates how many beats the fade will take. Using decimals is allowed.
* [param use_filler_clip] indicates that there will be a filler clip used between the source and destination clips.
* [param filler_clip] the index of the filler clip.
* If [param hold_previous] is used, then this clip will be remembered. This can be used together with [constant AUTO_ADVANCE_RETURN_TO_HOLD] to return to this clip after another is done playing.

### from_clip :: int

### to_clip :: int

### from_time :: int

### to_time :: int

### fade_mode :: int

### fade_beats :: float

### use_filler_clip :: bool

### filler_clip :: int

### hold_previous :: bool

## erase_transition :: func AudioStreamInteractive.erase_transition(from_clip: int, to_clip: int) -> void
Erase a transition by providing [param from_clip] and [param to_clip] clip indices. [constant CLIP_ANY] can be used for either argument or both.

### from_clip :: int

### to_clip :: int

## get_clip_auto_advance :: func AudioStreamInteractive.get_clip_auto_advance(clip_index: int) -> int
Return whether a clip has auto-advance enabled. See [method set_clip_auto_advance].

### clip_index :: int

## get_clip_auto_advance_next_clip :: func AudioStreamInteractive.get_clip_auto_advance_next_clip(clip_index: int) -> int
Return the clip towards which the clip referenced by [param clip_index] will auto-advance to.

### clip_index :: int

## get_clip_name :: func AudioStreamInteractive.get_clip_name(clip_index: int) -> StringName
Return the name of a clip.

### clip_index :: int

## get_clip_stream :: func AudioStreamInteractive.get_clip_stream(clip_index: int) -> AudioStream
Return the [AudioStream] associated with a clip.

### clip_index :: int

## get_transition_fade_beats :: func AudioStreamInteractive.get_transition_fade_beats(from_clip: int, to_clip: int) -> float
Return the time (in beats) for a transition (see [method add_transition]).

### from_clip :: int

### to_clip :: int

## get_transition_fade_mode :: func AudioStreamInteractive.get_transition_fade_mode(from_clip: int, to_clip: int) -> int
Return the mode for a transition (see [method add_transition]).

### from_clip :: int

### to_clip :: int

## get_transition_filler_clip :: func AudioStreamInteractive.get_transition_filler_clip(from_clip: int, to_clip: int) -> int
Return the filler clip for a transition (see [method add_transition]).

### from_clip :: int

### to_clip :: int

## get_transition_from_time :: func AudioStreamInteractive.get_transition_from_time(from_clip: int, to_clip: int) -> int
Return the source time position for a transition (see [method add_transition]).

### from_clip :: int

### to_clip :: int

## get_transition_list :: func AudioStreamInteractive.get_transition_list() -> PackedInt32Array
Return the list of transitions (from, to interleaved).

## get_transition_to_time :: func AudioStreamInteractive.get_transition_to_time(from_clip: int, to_clip: int) -> int
Return the destination time position for a transition (see [method add_transition]).

### from_clip :: int

### to_clip :: int

## has_transition :: func AudioStreamInteractive.has_transition(from_clip: int, to_clip: int) -> bool
Returns [code]true[/code] if a given transition exists (was added via [method add_transition]).

### from_clip :: int

### to_clip :: int

## is_transition_holding_previous :: func AudioStreamInteractive.is_transition_holding_previous(from_clip: int, to_clip: int) -> bool
Return whether a transition uses the [i]hold previous[/i] functionality (see [method add_transition]).

### from_clip :: int

### to_clip :: int

## is_transition_using_filler_clip :: func AudioStreamInteractive.is_transition_using_filler_clip(from_clip: int, to_clip: int) -> bool
Return whether a transition uses the [i]filler clip[/i] functionality (see [method add_transition]).

### from_clip :: int

### to_clip :: int

## set_clip_auto_advance :: func AudioStreamInteractive.set_clip_auto_advance(clip_index: int, mode: int) -> void
Set whether a clip will auto-advance by changing the auto-advance mode.

### clip_index :: int

### mode :: int

## set_clip_auto_advance_next_clip :: func AudioStreamInteractive.set_clip_auto_advance_next_clip(clip_index: int, auto_advance_next_clip: int) -> void
Set the index of the next clip towards which this clip will auto advance to when finished. If the clip being played loops, then auto-advance will be ignored.

### clip_index :: int

### auto_advance_next_clip :: int

## set_clip_name :: func AudioStreamInteractive.set_clip_name(clip_index: int, name: StringName) -> void
Set the name of the current clip (for easier identification).

### clip_index :: int

### name :: StringName

## set_clip_stream :: func AudioStreamInteractive.set_clip_stream(clip_index: int, stream: AudioStream) -> void
Set the [AudioStream] associated with the current clip.

### clip_index :: int

### stream :: AudioStream
