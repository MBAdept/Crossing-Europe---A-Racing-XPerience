# HScrollBar :: <Native> class HScrollBar extends ScrollBar
A horizontal scrollbar that goes from left (min) to right (max).
A horizontal scrollbar, typically used to navigate through content that extends beyond the visible width of a control. It is a [Range]-based control and goes from left (min) to right (max).

## padding_bottom :: <Theme> var HScrollBar.padding_bottom: int
Padding between the bottom of the [theme_item ScrollBar.scroll] element and the [theme_item ScrollBar.grabber].
[b]Note:[/b] To apply horizontal padding, modify the left/right content margins of [theme_item ScrollBar.scroll] instead.

## padding_top :: <Theme> var HScrollBar.padding_top: int
Padding between the top of the [theme_item ScrollBar.scroll] element and the [theme_item ScrollBar.grabber].
[b]Note:[/b] To apply horizontal padding, modify the left/right content margins of [theme_item ScrollBar.scroll] instead.
