# Shortcut :: <Native> class Shortcut extends Resource
A shortcut for binding input.
Shortcuts (also known as hotkeys) are containers of [InputEvent] resources. They are commonly used to interact with a [Control] element from an [InputEvent].
One shortcut can contain multiple [InputEvent] resources, making it possible to trigger one action with multiple different inputs.
[b]Example:[/b] Capture the [kbd]Ctrl + S[/kbd] shortcut using a [Shortcut] resource:
[codeblocks]
[gdscript]
extends Node

var save_shortcut = Shortcut.new()
func _ready():
	var key_event = InputEventKey.new()
	key_event.keycode = KEY_S
	key_event.ctrl_pressed = true
	key_event.command_or_control_autoremap = true # Swaps Ctrl for Command on Mac.
	save_shortcut.events = [key_event]

func _input(event):
	if save_shortcut.matches_event(event) and event.is_pressed() and not event.is_echo():
		print("Save shortcut pressed!")
		get_viewport().set_input_as_handled()
[/gdscript]
[csharp]
using Godot;

public partial class MyNode : Node
{
	private readonly Shortcut _saveShortcut = new Shortcut();

	public override void _Ready()
	{
		InputEventKey keyEvent = new InputEventKey
		{
			Keycode = Key.S,
			CtrlPressed = true,
			CommandOrControlAutoremap = true, // Swaps Ctrl for Command on Mac.
		};

		_saveShortcut.Events = [keyEvent];
	}

	public override void _Input(InputEvent @event)
	{
		if (@event is InputEventKey keyEvent &&
			_saveShortcut.MatchesEvent(@event) &&
			keyEvent.Pressed && !keyEvent.Echo)
		{
			GD.Print("Save shortcut pressed!");
			GetViewport().SetInputAsHandled();
		}
	}
}
[/csharp]
[/codeblocks]

## events :: var Shortcut.events: Array
The shortcut's [InputEvent] array.
Generally the [InputEvent] used is an [InputEventKey], though it can be any [InputEvent], including an [InputEventAction].

## get_as_text :: func Shortcut.get_as_text() -> String
Returns the shortcut's first valid [InputEvent] as a [String].

## has_valid_event :: func Shortcut.has_valid_event() -> bool
Returns whether [member events] contains an [InputEvent] which is valid.

## matches_event :: func Shortcut.matches_event(event: InputEvent) -> bool
Returns whether any [InputEvent] in [member events] equals [param event]. This uses [method InputEvent.is_match] to compare events.

### event :: InputEvent
