# CollisionPolygon2D :: <Native> class CollisionPolygon2D extends Node2D
A node that provides a polygon shape to a [CollisionObject2D] parent.
A node that provides a polygon shape to a [CollisionObject2D] parent and allows it to be edited. The polygon can be concave or convex. This can give a detection shape to an [Area2D], turn a [PhysicsBody2D] into a solid object, or give a hollow shape to a [StaticBody2D].
[b]Warning:[/b] A non-uniformly scaled [CollisionPolygon2D] will likely not behave as expected. Make sure to keep its scale the same on all axes and adjust its polygon instead.

## BUILD_SOLIDS :: const CollisionPolygon2D.BUILD_SOLIDS: BuildMode = 0
Collisions will include the polygon and its contained area. In this mode the node has the same effect as several [ConvexPolygonShape2D] nodes, one for each convex shape in the convex decomposition of the polygon (but without the overhead of multiple nodes).

## BUILD_SEGMENTS :: const CollisionPolygon2D.BUILD_SEGMENTS: BuildMode = 1
Collisions will only include the polygon edges. In this mode the node has the same effect as a single [ConcavePolygonShape2D] made of segments, with the restriction that each segment (after the first one) starts where the previous one ends, and the last one ends where the first one starts (forming a closed but hollow polygon).

## build_mode :: var CollisionPolygon2D.build_mode: CollisionPolygon2D.BuildMode
Collision build mode.

## disabled :: var CollisionPolygon2D.disabled: bool
If [code]true[/code], no collisions will be detected. This property should be changed with [method Object.set_deferred].

## one_way_collision :: var CollisionPolygon2D.one_way_collision: bool
If [code]true[/code], only edges that face up, relative to [CollisionPolygon2D]'s rotation, will collide with other objects.
[b]Note:[/b] This property has no effect if this [CollisionPolygon2D] is a child of an [Area2D] node.
[b]Note:[/b] The one way collision direction can be configured by setting [member one_way_collision_direction].

## one_way_collision_direction :: var CollisionPolygon2D.one_way_collision_direction: Vector2
The direction used for one-way collision.

## one_way_collision_margin :: var CollisionPolygon2D.one_way_collision_margin: float
The margin used for one-way collision (in pixels). Higher values will make the shape thicker, and work better for colliders that enter the polygon at a high velocity.

## polygon :: var CollisionPolygon2D.polygon: PackedVector2Array
The polygon's list of vertices. Each point will be connected to the next, and the final point will be connected to the first.
[b]Note:[/b] The returned vertices are in the local coordinate space of the given [CollisionPolygon2D].
