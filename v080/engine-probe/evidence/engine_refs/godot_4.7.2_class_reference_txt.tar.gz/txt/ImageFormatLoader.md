# ImageFormatLoader :: <Native> class ImageFormatLoader extends RefCounted
Base class to add support for specific image formats.
The engine supports multiple image formats out of the box (PNG, SVG, JPEG, WebP to name a few), but you can choose to implement support for additional image formats by extending [ImageFormatLoaderExtension].

## FLAG_NONE :: const ImageFormatLoader.FLAG_NONE: LoaderFlags = 0
Default loading behavior. No processing is applied to the image.

## FLAG_FORCE_LINEAR :: const ImageFormatLoader.FLAG_FORCE_LINEAR: LoaderFlags = 1
If set, the image is converted from sRGB to linear encoding.

## FLAG_CONVERT_COLORS :: const ImageFormatLoader.FLAG_CONVERT_COLORS: LoaderFlags = 2
If set, a predefined color map is applied to the image. Used when [member ResourceImporterTexture.editor/convert_colors_with_editor_theme] is [code]true[/code].
