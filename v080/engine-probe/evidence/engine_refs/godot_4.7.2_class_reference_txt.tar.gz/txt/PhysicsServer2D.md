# PhysicsServer2D :: <Native> class PhysicsServer2D extends Object
A server interface for low-level 2D physics access.
PhysicsServer2D is the server responsible for all 2D physics. It can directly create and manipulate all physics objects:
- A [i]space[/i] is a self-contained world for a physics simulation. It contains bodies, areas, and joints. Its state can be queried for collision and intersection information, and several parameters of the simulation can be modified.
- A [i]shape[/i] is a geometric shape such as a circle, a rectangle, a capsule, or a polygon. It can be used for collision detection by adding it to a body/area, possibly with an extra transformation relative to the body/area's origin. Bodies/areas can have multiple (transformed) shapes added to them, and a single shape can be added to bodies/areas multiple times with different local transformations.
- A [i]body[/i] is a physical object which can be in static, kinematic, or rigid mode. Its state (such as position and velocity) can be queried and updated. A force integration callback can be set to customize the body's physics.
- An [i]area[/i] is a region in space which can be used to detect bodies and areas entering and exiting it. A body monitoring callback can be set to report entering/exiting body shapes, and similarly an area monitoring callback can be set. Gravity and damping can be overridden within the area by setting area parameters.
- A [i]joint[/i] is a constraint, either between two bodies or on one body relative to a point. Parameters such as the joint bias and the rest length of a spring joint can be adjusted.
Physics objects in [PhysicsServer2D] may be created and manipulated independently; they do not have to be tied to nodes in the scene tree.
[b]Note:[/b] All the 2D physics nodes use the physics server internally. Adding a physics node to the scene tree will cause a corresponding physics object to be created in the physics server. A rigid body node registers a callback that updates the node's transform with the transform of the respective body object in the physics server (every physics update). An area node registers a callback to inform the area node about overlaps with the respective area object in the physics server. The raycast node queries the direct state of the relevant space in the physics server.

## SPACE_PARAM_CONTACT_RECYCLE_RADIUS :: const PhysicsServer2D.SPACE_PARAM_CONTACT_RECYCLE_RADIUS: SpaceParameter = 0
Constant to set/get the maximum distance a pair of bodies has to move before their collision status has to be recalculated. The default value of this parameter is [member ProjectSettings.physics/2d/solver/contact_recycle_radius].

## SPACE_PARAM_CONTACT_MAX_SEPARATION :: const PhysicsServer2D.SPACE_PARAM_CONTACT_MAX_SEPARATION: SpaceParameter = 1
Constant to set/get the maximum distance a shape can be from another before they are considered separated and the contact is discarded. The default value of this parameter is [member ProjectSettings.physics/2d/solver/contact_max_separation].

## SPACE_PARAM_CONTACT_MAX_ALLOWED_PENETRATION :: const PhysicsServer2D.SPACE_PARAM_CONTACT_MAX_ALLOWED_PENETRATION: SpaceParameter = 2
Constant to set/get the maximum distance a shape can penetrate another shape before it is considered a collision. The default value of this parameter is [member ProjectSettings.physics/2d/solver/contact_max_allowed_penetration].

## SPACE_PARAM_CONTACT_DEFAULT_BIAS :: const PhysicsServer2D.SPACE_PARAM_CONTACT_DEFAULT_BIAS: SpaceParameter = 3
Constant to set/get the default solver bias for all physics contacts. A solver bias is a factor controlling how much two objects "rebound", after overlapping, to avoid leaving them in that state because of numerical imprecision. The default value of this parameter is [member ProjectSettings.physics/2d/solver/default_contact_bias].

## SPACE_PARAM_BODY_LINEAR_VELOCITY_SLEEP_THRESHOLD :: const PhysicsServer2D.SPACE_PARAM_BODY_LINEAR_VELOCITY_SLEEP_THRESHOLD: SpaceParameter = 4
Constant to set/get the threshold linear velocity of activity. A body marked as potentially inactive for both linear and angular velocity will be put to sleep after the time given. The default value of this parameter is [member ProjectSettings.physics/2d/sleep_threshold_linear].

## SPACE_PARAM_BODY_ANGULAR_VELOCITY_SLEEP_THRESHOLD :: const PhysicsServer2D.SPACE_PARAM_BODY_ANGULAR_VELOCITY_SLEEP_THRESHOLD: SpaceParameter = 5
Constant to set/get the threshold angular velocity of activity. A body marked as potentially inactive for both linear and angular velocity will be put to sleep after the time given. The default value of this parameter is [member ProjectSettings.physics/2d/sleep_threshold_angular].

## SPACE_PARAM_BODY_TIME_TO_SLEEP :: const PhysicsServer2D.SPACE_PARAM_BODY_TIME_TO_SLEEP: SpaceParameter = 6
Constant to set/get the maximum time of activity. A body marked as potentially inactive for both linear and angular velocity will be put to sleep after this time. The default value of this parameter is [member ProjectSettings.physics/2d/time_before_sleep].

## SPACE_PARAM_CONSTRAINT_DEFAULT_BIAS :: const PhysicsServer2D.SPACE_PARAM_CONSTRAINT_DEFAULT_BIAS: SpaceParameter = 7
Constant to set/get the default solver bias for all physics constraints. A solver bias is a factor controlling how much two objects "rebound", after violating a constraint, to avoid leaving them in that state because of numerical imprecision. The default value of this parameter is [member ProjectSettings.physics/2d/solver/default_constraint_bias].

## SPACE_PARAM_SOLVER_ITERATIONS :: const PhysicsServer2D.SPACE_PARAM_SOLVER_ITERATIONS: SpaceParameter = 8
Constant to set/get the number of solver iterations for all contacts and constraints. The greater the number of iterations, the more accurate the collisions will be. However, a greater number of iterations requires more CPU power, which can decrease performance. The default value of this parameter is [member ProjectSettings.physics/2d/solver/solver_iterations].

## SHAPE_WORLD_BOUNDARY :: const PhysicsServer2D.SHAPE_WORLD_BOUNDARY: ShapeType = 0
This is the constant for creating world boundary shapes. A world boundary shape is an [i]infinite[/i] line with an origin point, and a normal. Thus, it can be used for front/behind checks.

## SHAPE_SEPARATION_RAY :: const PhysicsServer2D.SHAPE_SEPARATION_RAY: ShapeType = 1
This is the constant for creating separation ray shapes. A separation ray is defined by a length and separates itself from what is touching its far endpoint. Useful for character controllers.

## SHAPE_SEGMENT :: const PhysicsServer2D.SHAPE_SEGMENT: ShapeType = 2
This is the constant for creating segment shapes. A segment shape is a [i]finite[/i] line from a point A to a point B. It can be checked for intersections.

## SHAPE_CIRCLE :: const PhysicsServer2D.SHAPE_CIRCLE: ShapeType = 3
This is the constant for creating circle shapes. A circle shape only has a radius. It can be used for intersections and inside/outside checks.

## SHAPE_RECTANGLE :: const PhysicsServer2D.SHAPE_RECTANGLE: ShapeType = 4
This is the constant for creating rectangle shapes. A rectangle shape is defined by a width and a height. It can be used for intersections and inside/outside checks.

## SHAPE_CAPSULE :: const PhysicsServer2D.SHAPE_CAPSULE: ShapeType = 5
This is the constant for creating capsule shapes. A capsule shape is defined by a radius and a length. It can be used for intersections and inside/outside checks.

## SHAPE_CONVEX_POLYGON :: const PhysicsServer2D.SHAPE_CONVEX_POLYGON: ShapeType = 6
This is the constant for creating convex polygon shapes. A polygon is defined by a list of points. It can be used for intersections and inside/outside checks.

## SHAPE_CONCAVE_POLYGON :: const PhysicsServer2D.SHAPE_CONCAVE_POLYGON: ShapeType = 7
This is the constant for creating concave polygon shapes. A polygon is defined by a list of points. It can be used for intersections checks, but not for inside/outside checks.

## SHAPE_CUSTOM :: const PhysicsServer2D.SHAPE_CUSTOM: ShapeType = 8
This constant is used internally by the engine. Any attempt to create this kind of shape results in an error.

## AREA_PARAM_GRAVITY_OVERRIDE_MODE :: const PhysicsServer2D.AREA_PARAM_GRAVITY_OVERRIDE_MODE: AreaParameter = 0
Constant to set/get gravity override mode in an area. See [enum AreaSpaceOverrideMode] for possible values. The default value of this parameter is [constant AREA_SPACE_OVERRIDE_DISABLED].

## AREA_PARAM_GRAVITY :: const PhysicsServer2D.AREA_PARAM_GRAVITY: AreaParameter = 1
Constant to set/get gravity strength in an area. The default value of this parameter is [code]9.80665[/code].

## AREA_PARAM_GRAVITY_VECTOR :: const PhysicsServer2D.AREA_PARAM_GRAVITY_VECTOR: AreaParameter = 2
Constant to set/get gravity vector/center in an area. The default value of this parameter is [code]Vector2(0, -1)[/code].

## AREA_PARAM_GRAVITY_IS_POINT :: const PhysicsServer2D.AREA_PARAM_GRAVITY_IS_POINT: AreaParameter = 3
Constant to set/get whether the gravity vector of an area is a direction, or a center point. The default value of this parameter is [code]false[/code].

## AREA_PARAM_GRAVITY_POINT_UNIT_DISTANCE :: const PhysicsServer2D.AREA_PARAM_GRAVITY_POINT_UNIT_DISTANCE: AreaParameter = 4
Constant to set/get the distance at which the gravity strength is equal to the gravity controlled by [constant AREA_PARAM_GRAVITY]. For example, on a planet 100 pixels in radius with a surface gravity of 4.0 px/s², set the gravity to 4.0 and the unit distance to 100.0. The gravity will have falloff according to the inverse square law, so in the example, at 200 pixels from the center the gravity will be 1.0 px/s² (twice the distance, 1/4th the gravity), at 50 pixels it will be 16.0 px/s² (half the distance, 4x the gravity), and so on.
The above is true only when the unit distance is a positive number. When the unit distance is set to 0.0, the gravity will be constant regardless of distance. The default value of this parameter is [code]0.0[/code].

## AREA_PARAM_LINEAR_DAMP_OVERRIDE_MODE :: const PhysicsServer2D.AREA_PARAM_LINEAR_DAMP_OVERRIDE_MODE: AreaParameter = 5
Constant to set/get linear damping override mode in an area. See [enum AreaSpaceOverrideMode] for possible values. The default value of this parameter is [constant AREA_SPACE_OVERRIDE_DISABLED].

## AREA_PARAM_LINEAR_DAMP :: const PhysicsServer2D.AREA_PARAM_LINEAR_DAMP: AreaParameter = 6
Constant to set/get the linear damping factor of an area. The default value of this parameter is [code]0.1[/code].

## AREA_PARAM_ANGULAR_DAMP_OVERRIDE_MODE :: const PhysicsServer2D.AREA_PARAM_ANGULAR_DAMP_OVERRIDE_MODE: AreaParameter = 7
Constant to set/get angular damping override mode in an area. See [enum AreaSpaceOverrideMode] for possible values. The default value of this parameter is [constant AREA_SPACE_OVERRIDE_DISABLED].

## AREA_PARAM_ANGULAR_DAMP :: const PhysicsServer2D.AREA_PARAM_ANGULAR_DAMP: AreaParameter = 8
Constant to set/get the angular damping factor of an area. The default value of this parameter is [code]1.0[/code].

## AREA_PARAM_PRIORITY :: const PhysicsServer2D.AREA_PARAM_PRIORITY: AreaParameter = 9
Constant to set/get the priority (order of processing) of an area. The default value of this parameter is [code]0[/code].

## AREA_SPACE_OVERRIDE_DISABLED :: const PhysicsServer2D.AREA_SPACE_OVERRIDE_DISABLED: AreaSpaceOverrideMode = 0
This area does not affect gravity/damp. These are generally areas that exist only to detect collisions, and objects entering or exiting them.

## AREA_SPACE_OVERRIDE_COMBINE :: const PhysicsServer2D.AREA_SPACE_OVERRIDE_COMBINE: AreaSpaceOverrideMode = 1
This area adds its gravity/damp values to whatever has been calculated so far. This way, many overlapping areas can combine their physics to make interesting effects.

## AREA_SPACE_OVERRIDE_COMBINE_REPLACE :: const PhysicsServer2D.AREA_SPACE_OVERRIDE_COMBINE_REPLACE: AreaSpaceOverrideMode = 2
This area adds its gravity/damp values to whatever has been calculated so far. Then stops taking into account the rest of the areas, even the default one.

## AREA_SPACE_OVERRIDE_REPLACE :: const PhysicsServer2D.AREA_SPACE_OVERRIDE_REPLACE: AreaSpaceOverrideMode = 3
This area replaces any gravity/damp, even the default one, and stops taking into account the rest of the areas.

## AREA_SPACE_OVERRIDE_REPLACE_COMBINE :: const PhysicsServer2D.AREA_SPACE_OVERRIDE_REPLACE_COMBINE: AreaSpaceOverrideMode = 4
This area replaces any gravity/damp calculated so far, but keeps calculating the rest of the areas, down to the default one.

## BODY_MODE_STATIC :: const PhysicsServer2D.BODY_MODE_STATIC: BodyMode = 0
Constant for static bodies. In this mode, a body can be only moved by user code and doesn't collide with other bodies along its path when moved.

## BODY_MODE_KINEMATIC :: const PhysicsServer2D.BODY_MODE_KINEMATIC: BodyMode = 1
Constant for kinematic bodies. In this mode, a body can be only moved by user code and collides with other bodies along its path.

## BODY_MODE_RIGID :: const PhysicsServer2D.BODY_MODE_RIGID: BodyMode = 2
Constant for rigid bodies. In this mode, a body can be pushed by other bodies and has forces applied.

## BODY_MODE_RIGID_LINEAR :: const PhysicsServer2D.BODY_MODE_RIGID_LINEAR: BodyMode = 3
Constant for linear rigid bodies. In this mode, a body can not rotate, and only its linear velocity is affected by external forces.

## BODY_PARAM_BOUNCE :: const PhysicsServer2D.BODY_PARAM_BOUNCE: BodyParameter = 0
Constant to set/get a body's bounce factor. The default value of this parameter is [code]0.0[/code].

## BODY_PARAM_FRICTION :: const PhysicsServer2D.BODY_PARAM_FRICTION: BodyParameter = 1
Constant to set/get a body's friction. The default value of this parameter is [code]1.0[/code].

## BODY_PARAM_MASS :: const PhysicsServer2D.BODY_PARAM_MASS: BodyParameter = 2
Constant to set/get a body's mass. The default value of this parameter is [code]1.0[/code]. If the body's mode is set to [constant BODY_MODE_RIGID], then setting this parameter will have the following additional effects:
- If the parameter [constant BODY_PARAM_CENTER_OF_MASS] has never been set explicitly, then the value of that parameter will be recalculated based on the body's shapes.
- If the parameter [constant BODY_PARAM_INERTIA] is set to a value [code]<= 0.0[/code], then the value of that parameter will be recalculated based on the body's shapes, mass, and center of mass.

## BODY_PARAM_INERTIA :: const PhysicsServer2D.BODY_PARAM_INERTIA: BodyParameter = 3
Constant to set/get a body's inertia. The default value of this parameter is [code]0.0[/code]. If the body's inertia is set to a value [code]<= 0.0[/code], then the inertia will be recalculated based on the body's shapes, mass, and center of mass.

## BODY_PARAM_CENTER_OF_MASS :: const PhysicsServer2D.BODY_PARAM_CENTER_OF_MASS: BodyParameter = 4
Constant to set/get a body's center of mass position in the body's local coordinate system. The default value of this parameter is [code]Vector2(0, 0)[/code]. If this parameter is never set explicitly, then it is recalculated based on the body's shapes when setting the parameter [constant BODY_PARAM_MASS] or when calling [method body_set_space].

## BODY_PARAM_GRAVITY_SCALE :: const PhysicsServer2D.BODY_PARAM_GRAVITY_SCALE: BodyParameter = 5
Constant to set/get a body's gravity multiplier. The default value of this parameter is [code]1.0[/code].

## BODY_PARAM_LINEAR_DAMP_MODE :: const PhysicsServer2D.BODY_PARAM_LINEAR_DAMP_MODE: BodyParameter = 6
Constant to set/get a body's linear damping mode. See [enum BodyDampMode] for possible values. The default value of this parameter is [constant BODY_DAMP_MODE_COMBINE].

## BODY_PARAM_ANGULAR_DAMP_MODE :: const PhysicsServer2D.BODY_PARAM_ANGULAR_DAMP_MODE: BodyParameter = 7
Constant to set/get a body's angular damping mode. See [enum BodyDampMode] for possible values. The default value of this parameter is [constant BODY_DAMP_MODE_COMBINE].

## BODY_PARAM_LINEAR_DAMP :: const PhysicsServer2D.BODY_PARAM_LINEAR_DAMP: BodyParameter = 8
Constant to set/get a body's linear damping factor. The default value of this parameter is [code]0.0[/code].

## BODY_PARAM_ANGULAR_DAMP :: const PhysicsServer2D.BODY_PARAM_ANGULAR_DAMP: BodyParameter = 9
Constant to set/get a body's angular damping factor. The default value of this parameter is [code]0.0[/code].

## BODY_PARAM_MAX :: const PhysicsServer2D.BODY_PARAM_MAX: BodyParameter = 10
Represents the size of the [enum BodyParameter] enum.

## BODY_DAMP_MODE_COMBINE :: const PhysicsServer2D.BODY_DAMP_MODE_COMBINE: BodyDampMode = 0
The body's damping value is added to any value set in areas or the default value.

## BODY_DAMP_MODE_REPLACE :: const PhysicsServer2D.BODY_DAMP_MODE_REPLACE: BodyDampMode = 1
The body's damping value replaces any value set in areas or the default value.

## BODY_STATE_TRANSFORM :: const PhysicsServer2D.BODY_STATE_TRANSFORM: BodyState = 0
Constant to set/get the current transform matrix of the body.

## BODY_STATE_LINEAR_VELOCITY :: const PhysicsServer2D.BODY_STATE_LINEAR_VELOCITY: BodyState = 1
Constant to set/get the current linear velocity of the body.

## BODY_STATE_ANGULAR_VELOCITY :: const PhysicsServer2D.BODY_STATE_ANGULAR_VELOCITY: BodyState = 2
Constant to set/get the current angular velocity of the body.

## BODY_STATE_SLEEPING :: const PhysicsServer2D.BODY_STATE_SLEEPING: BodyState = 3
Constant to sleep/wake up a body, or to get whether it is sleeping.

## BODY_STATE_CAN_SLEEP :: const PhysicsServer2D.BODY_STATE_CAN_SLEEP: BodyState = 4
Constant to set/get whether the body can sleep.

## JOINT_TYPE_PIN :: const PhysicsServer2D.JOINT_TYPE_PIN: JointType = 0
Constant to create pin joints.

## JOINT_TYPE_GROOVE :: const PhysicsServer2D.JOINT_TYPE_GROOVE: JointType = 1
Constant to create groove joints.

## JOINT_TYPE_DAMPED_SPRING :: const PhysicsServer2D.JOINT_TYPE_DAMPED_SPRING: JointType = 2
Constant to create damped spring joints.

## JOINT_TYPE_MAX :: const PhysicsServer2D.JOINT_TYPE_MAX: JointType = 3
Represents the size of the [enum JointType] enum.

## JOINT_PARAM_BIAS :: const PhysicsServer2D.JOINT_PARAM_BIAS: JointParam = 0
Constant to set/get how fast the joint pulls the bodies back to satisfy the joint constraint. The lower the value, the more the two bodies can pull on the joint. The default value of this parameter is [code]0.0[/code].
[b]Note:[/b] In Godot Physics, this parameter is only used for pin joints and groove joints.

## JOINT_PARAM_MAX_BIAS :: const PhysicsServer2D.JOINT_PARAM_MAX_BIAS: JointParam = 1
Constant to set/get the maximum speed with which the joint can apply corrections. The default value of this parameter is [code]3.40282e+38[/code].
[b]Note:[/b] In Godot Physics, this parameter is only used for groove joints.

## JOINT_PARAM_MAX_FORCE :: const PhysicsServer2D.JOINT_PARAM_MAX_FORCE: JointParam = 2
Constant to set/get the maximum force that the joint can use to act on the two bodies. The default value of this parameter is [code]3.40282e+38[/code].
[b]Note:[/b] In Godot Physics, this parameter is only used for groove joints.

## PIN_JOINT_SOFTNESS :: const PhysicsServer2D.PIN_JOINT_SOFTNESS: PinJointParam = 0
Constant to set/get a how much the bond of the pin joint can flex. The default value of this parameter is [code]0.0[/code].

## PIN_JOINT_LIMIT_UPPER :: const PhysicsServer2D.PIN_JOINT_LIMIT_UPPER: PinJointParam = 1
The maximum rotation around the pin.

## PIN_JOINT_LIMIT_LOWER :: const PhysicsServer2D.PIN_JOINT_LIMIT_LOWER: PinJointParam = 2
The minimum rotation around the pin.

## PIN_JOINT_MOTOR_TARGET_VELOCITY :: const PhysicsServer2D.PIN_JOINT_MOTOR_TARGET_VELOCITY: PinJointParam = 3
Target speed for the motor. In radians per second.

## PIN_JOINT_FLAG_ANGULAR_LIMIT_ENABLED :: const PhysicsServer2D.PIN_JOINT_FLAG_ANGULAR_LIMIT_ENABLED: PinJointFlag = 0
If [code]true[/code], the pin has a maximum and a minimum rotation.

## PIN_JOINT_FLAG_MOTOR_ENABLED :: const PhysicsServer2D.PIN_JOINT_FLAG_MOTOR_ENABLED: PinJointFlag = 1
If [code]true[/code], a motor turns the pin.

## DAMPED_SPRING_REST_LENGTH :: const PhysicsServer2D.DAMPED_SPRING_REST_LENGTH: DampedSpringParam = 0
Sets the resting length of the spring joint. The joint will always try to go to back this length when pulled apart. The default value of this parameter is the distance between the joint's anchor points.

## DAMPED_SPRING_STIFFNESS :: const PhysicsServer2D.DAMPED_SPRING_STIFFNESS: DampedSpringParam = 1
Sets the stiffness of the spring joint. The joint applies a force equal to the stiffness times the distance from its resting length. The default value of this parameter is [code]20.0[/code].

## DAMPED_SPRING_DAMPING :: const PhysicsServer2D.DAMPED_SPRING_DAMPING: DampedSpringParam = 2
Sets the damping ratio of the spring joint. A value of 0 indicates an undamped spring, while 1 causes the system to reach equilibrium as fast as possible (critical damping). The default value of this parameter is [code]1.5[/code].

## CCD_MODE_DISABLED :: const PhysicsServer2D.CCD_MODE_DISABLED: CCDMode = 0
Disables continuous collision detection. This is the fastest way to detect body collisions, but it can miss small and/or fast-moving objects.

## CCD_MODE_CAST_RAY :: const PhysicsServer2D.CCD_MODE_CAST_RAY: CCDMode = 1
Enables continuous collision detection by raycasting. It is faster than shapecasting, but less precise.

## CCD_MODE_CAST_SHAPE :: const PhysicsServer2D.CCD_MODE_CAST_SHAPE: CCDMode = 2
Enables continuous collision detection by shapecasting. It is the slowest CCD method, and the most precise.

## AREA_BODY_ADDED :: const PhysicsServer2D.AREA_BODY_ADDED: AreaBodyStatus = 0
The value of the first parameter and area callback function receives, when an object enters one of its shapes.

## AREA_BODY_REMOVED :: const PhysicsServer2D.AREA_BODY_REMOVED: AreaBodyStatus = 1
The value of the first parameter and area callback function receives, when an object exits one of its shapes.

## INFO_ACTIVE_OBJECTS :: const PhysicsServer2D.INFO_ACTIVE_OBJECTS: ProcessInfo = 0
Constant to get the number of objects that are not sleeping.

## INFO_COLLISION_PAIRS :: const PhysicsServer2D.INFO_COLLISION_PAIRS: ProcessInfo = 1
Constant to get the number of possible collisions.

## INFO_ISLAND_COUNT :: const PhysicsServer2D.INFO_ISLAND_COUNT: ProcessInfo = 2
Constant to get the number of space regions where a collision could occur.

## area_add_shape :: func PhysicsServer2D.area_add_shape(area: RID, shape: RID, transform: Transform2D = Transform2D(1, 0, 0, 1, 0, 0), disabled: bool = false) -> void
Adds a shape to the area, with the given local transform. The shape (together with its [param transform] and [param disabled] properties) is added to an array of shapes, and the shapes of an area are usually referenced by their index in this array.

### area :: RID

### shape :: RID

### transform :: Transform2D

### disabled :: bool

## area_attach_canvas_instance_id :: func PhysicsServer2D.area_attach_canvas_instance_id(area: RID, id: int) -> void
Attaches the [code]ObjectID[/code] of a canvas to the area. Use [method Object.get_instance_id] to get the [code]ObjectID[/code] of a [CanvasLayer].

### area :: RID

### id :: int

## area_attach_object_instance_id :: func PhysicsServer2D.area_attach_object_instance_id(area: RID, id: int) -> void
Attaches the [code]ObjectID[/code] of an [Object] to the area. Use [method Object.get_instance_id] to get the [code]ObjectID[/code] of a [CollisionObject2D].

### area :: RID

### id :: int

## area_clear_shapes :: func PhysicsServer2D.area_clear_shapes(area: RID) -> void
Removes all shapes from the area. This does not delete the shapes themselves, so they can continue to be used elsewhere or added back later.

### area :: RID

## area_create :: func PhysicsServer2D.area_create() -> RID
Creates a 2D area object in the physics server, and returns the [RID] that identifies it. The default settings for the created area include a collision layer and mask set to [code]1[/code], and [code]monitorable[/code] set to [code]false[/code].
Use [method area_add_shape] to add shapes to it, use [method area_set_transform] to set its transform, and use [method area_set_space] to add the area to a space. If you want the area to be detectable use [method area_set_monitorable].

## area_get_canvas_instance_id :: func PhysicsServer2D.area_get_canvas_instance_id(area: RID) -> int
Returns the [code]ObjectID[/code] of the canvas attached to the area. Use [method @GlobalScope.instance_from_id] to retrieve a [CanvasLayer] from a nonzero [code]ObjectID[/code].

### area :: RID

## area_get_collision_layer :: func PhysicsServer2D.area_get_collision_layer(area: RID) -> int
Returns the physics layer or layers the area belongs to, as a bitmask.

### area :: RID

## area_get_collision_mask :: func PhysicsServer2D.area_get_collision_mask(area: RID) -> int
Returns the physics layer or layers the area can contact with, as a bitmask.

### area :: RID

## area_get_object_instance_id :: func PhysicsServer2D.area_get_object_instance_id(area: RID) -> int
Returns the [code]ObjectID[/code] attached to the area. Use [method @GlobalScope.instance_from_id] to retrieve an [Object] from a nonzero [code]ObjectID[/code].

### area :: RID

## area_get_param :: func PhysicsServer2D.area_get_param(area: RID, param: int) -> Variant
Returns the value of the given area parameter.

### area :: RID

### param :: int

## area_get_shape :: func PhysicsServer2D.area_get_shape(area: RID, shape_idx: int) -> RID
Returns the [RID] of the shape with the given index in the area's array of shapes.

### area :: RID

### shape_idx :: int

## area_get_shape_count :: func PhysicsServer2D.area_get_shape_count(area: RID) -> int
Returns the number of shapes added to the area.

### area :: RID

## area_get_shape_transform :: func PhysicsServer2D.area_get_shape_transform(area: RID, shape_idx: int) -> Transform2D
Returns the local transform matrix of the shape with the given index in the area's array of shapes.

### area :: RID

### shape_idx :: int

## area_get_space :: func PhysicsServer2D.area_get_space(area: RID) -> RID
Returns the [RID] of the space assigned to the area. Returns an empty [RID] if no space is assigned.

### area :: RID

## area_get_transform :: func PhysicsServer2D.area_get_transform(area: RID) -> Transform2D
Returns the transform matrix of the area.

### area :: RID

## area_remove_shape :: func PhysicsServer2D.area_remove_shape(area: RID, shape_idx: int) -> void
Removes the shape with the given index from the area's array of shapes. The shape itself is not deleted, so it can continue to be used elsewhere or added back later. As a result of this operation, the area's shapes which used to have indices higher than [param shape_idx] will have their index decreased by one.

### area :: RID

### shape_idx :: int

## area_set_area_monitor_callback :: func PhysicsServer2D.area_set_area_monitor_callback(area: RID, callback: Callable) -> void
Sets the area's area monitor callback. This callback will be called when any other (shape of an) area enters or exits (a shape of) the given area, and must take the following five parameters:
1. an integer [code]status[/code]: either [constant AREA_BODY_ADDED] or [constant AREA_BODY_REMOVED] depending on whether the other area's shape entered or exited the area,
2. an [RID] [code]area_rid[/code]: the [RID] of the other area that entered or exited the area,
3. an integer [code]instance_id[/code]: the [code]ObjectID[/code] attached to the other area,
4. an integer [code]area_shape_idx[/code]: the index of the shape of the other area that entered or exited the area,
5. an integer [code]self_shape_idx[/code]: the index of the shape of the area where the other area entered or exited.
By counting (or keeping track of) the shapes that enter and exit, it can be determined if an area (with all its shapes) is entering for the first time or exiting for the last time.

### area :: RID

### callback :: Callable

## area_set_collision_layer :: func PhysicsServer2D.area_set_collision_layer(area: RID, layer: int) -> void
Assigns the area to one or many physics layers, via a bitmask.

### area :: RID

### layer :: int

## area_set_collision_mask :: func PhysicsServer2D.area_set_collision_mask(area: RID, mask: int) -> void
Sets which physics layers the area will monitor, via a bitmask.

### area :: RID

### mask :: int

## area_set_monitor_callback :: func PhysicsServer2D.area_set_monitor_callback(area: RID, callback: Callable) -> void
Sets the area's body monitor callback. This callback will be called when any other (shape of a) body enters or exits (a shape of) the given area, and must take the following five parameters:
1. an integer [code]status[/code]: either [constant AREA_BODY_ADDED] or [constant AREA_BODY_REMOVED] depending on whether the other body shape entered or exited the area,
2. an [RID] [code]body_rid[/code]: the [RID] of the body that entered or exited the area,
3. an integer [code]instance_id[/code]: the [code]ObjectID[/code] attached to the body,
4. an integer [code]body_shape_idx[/code]: the index of the shape of the body that entered or exited the area,
5. an integer [code]self_shape_idx[/code]: the index of the shape of the area where the body entered or exited.
By counting (or keeping track of) the shapes that enter and exit, it can be determined if a body (with all its shapes) is entering for the first time or exiting for the last time.

### area :: RID

### callback :: Callable

## area_set_monitorable :: func PhysicsServer2D.area_set_monitorable(area: RID, monitorable: bool) -> void
Sets whether the area is monitorable or not. If [param monitorable] is [code]true[/code], the area monitoring callback of other areas will be called when this area enters or exits them.

### area :: RID

### monitorable :: bool

## area_set_param :: func PhysicsServer2D.area_set_param(area: RID, param: int, value: Variant) -> void
Sets the value of the given area parameter.

### area :: RID

### param :: int

### value :: Variant

## area_set_shape :: func PhysicsServer2D.area_set_shape(area: RID, shape_idx: int, shape: RID) -> void
Replaces the area's shape at the given index by another shape, while not affecting the [code]transform[/code] and [code]disabled[/code] properties at the same index.

### area :: RID

### shape_idx :: int

### shape :: RID

## area_set_shape_disabled :: func PhysicsServer2D.area_set_shape_disabled(area: RID, shape_idx: int, disabled: bool) -> void
Sets the disabled property of the area's shape with the given index. If [param disabled] is [code]true[/code], then the shape will not detect any other shapes entering or exiting it.

### area :: RID

### shape_idx :: int

### disabled :: bool

## area_set_shape_transform :: func PhysicsServer2D.area_set_shape_transform(area: RID, shape_idx: int, transform: Transform2D) -> void
Sets the local transform matrix of the area's shape with the given index.

### area :: RID

### shape_idx :: int

### transform :: Transform2D

## area_set_space :: func PhysicsServer2D.area_set_space(area: RID, space: RID) -> void
Adds the area to the given space, after removing the area from the previously assigned space (if any).
[b]Note:[/b] To remove an area from a space without immediately adding it back elsewhere, use [code]PhysicsServer2D.area_set_space(area, RID())[/code].

### area :: RID

### space :: RID

## area_set_transform :: func PhysicsServer2D.area_set_transform(area: RID, transform: Transform2D) -> void
Sets the transform matrix of the area.

### area :: RID

### transform :: Transform2D

## body_add_collision_exception :: func PhysicsServer2D.body_add_collision_exception(body: RID, excepted_body: RID) -> void
Adds [param excepted_body] to the body's list of collision exceptions, so that collisions with it are ignored.

### body :: RID

### excepted_body :: RID

## body_add_constant_central_force :: func PhysicsServer2D.body_add_constant_central_force(body: RID, force: Vector2) -> void
Adds a constant directional force to the body. The force does not affect rotation. The force remains applied over time until cleared with [code]PhysicsServer2D.body_set_constant_force(body, Vector2(0, 0))[/code].
This is equivalent to using [method body_add_constant_force] at the body's center of mass.

### body :: RID

### force :: Vector2

## body_add_constant_force :: func PhysicsServer2D.body_add_constant_force(body: RID, force: Vector2, position: Vector2 = Vector2(0, 0)) -> void
Adds a constant positioned force to the body. The force can affect rotation if [param position] is different from the body's center of mass. The force remains applied over time until cleared with [code]PhysicsServer2D.body_set_constant_force(body, Vector2(0, 0))[/code].
[param position] is the offset from the body origin in global coordinates.

### body :: RID

### force :: Vector2

### position :: Vector2

## body_add_constant_torque :: func PhysicsServer2D.body_add_constant_torque(body: RID, torque: float) -> void
Adds a constant rotational force to the body. The force does not affect position. The force remains applied over time until cleared with [code]PhysicsServer2D.body_set_constant_torque(body, 0)[/code].

### body :: RID

### torque :: float

## body_add_shape :: func PhysicsServer2D.body_add_shape(body: RID, shape: RID, transform: Transform2D = Transform2D(1, 0, 0, 1, 0, 0), disabled: bool = false) -> void
Adds a shape to the area, with the given local transform. The shape (together with its [param transform] and [param disabled] properties) is added to an array of shapes, and the shapes of a body are usually referenced by their index in this array.

### body :: RID

### shape :: RID

### transform :: Transform2D

### disabled :: bool

## body_apply_central_force :: func PhysicsServer2D.body_apply_central_force(body: RID, force: Vector2) -> void
Applies a directional force to the body, at the body's center of mass. The force does not affect rotation. A force is time dependent and meant to be applied every physics update.
This is equivalent to using [method body_apply_force] at the body's center of mass.

### body :: RID

### force :: Vector2

## body_apply_central_impulse :: func PhysicsServer2D.body_apply_central_impulse(body: RID, impulse: Vector2) -> void
Applies a directional impulse to the body, at the body's center of mass. The impulse does not affect rotation.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).
This is equivalent to using [method body_apply_impulse] at the body's center of mass.

### body :: RID

### impulse :: Vector2

## body_apply_force :: func PhysicsServer2D.body_apply_force(body: RID, force: Vector2, position: Vector2 = Vector2(0, 0)) -> void
Applies a positioned force to the body. The force can affect rotation if [param position] is different from the body's center of mass. A force is time dependent and meant to be applied every physics update.
[param position] is the offset from the body origin in global coordinates.

### body :: RID

### force :: Vector2

### position :: Vector2

## body_apply_impulse :: func PhysicsServer2D.body_apply_impulse(body: RID, impulse: Vector2, position: Vector2 = Vector2(0, 0)) -> void
Applies a positioned impulse to the body. The impulse can affect rotation if [param position] is different from the body's center of mass.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).
[param position] is the offset from the body origin in global coordinates.

### body :: RID

### impulse :: Vector2

### position :: Vector2

## body_apply_torque :: func PhysicsServer2D.body_apply_torque(body: RID, torque: float) -> void
Applies a rotational force to the body. The force does not affect position. A force is time dependent and meant to be applied every physics update.

### body :: RID

### torque :: float

## body_apply_torque_impulse :: func PhysicsServer2D.body_apply_torque_impulse(body: RID, impulse: float) -> void
Applies a rotational impulse to the body. The impulse does not affect position.
An impulse is time-independent! Applying an impulse every frame would result in a framerate-dependent force. For this reason, it should only be used when simulating one-time impacts (use the "_force" functions otherwise).

### body :: RID

### impulse :: float

## body_attach_canvas_instance_id :: func PhysicsServer2D.body_attach_canvas_instance_id(body: RID, id: int) -> void
Attaches the [code]ObjectID[/code] of a canvas to the body. Use [method Object.get_instance_id] to get the [code]ObjectID[/code] of a [CanvasLayer].

### body :: RID

### id :: int

## body_attach_object_instance_id :: func PhysicsServer2D.body_attach_object_instance_id(body: RID, id: int) -> void
Attaches the [code]ObjectID[/code] of an [Object] to the body. Use [method Object.get_instance_id] to get the [code]ObjectID[/code] of a [CollisionObject2D].

### body :: RID

### id :: int

## body_clear_shapes :: func PhysicsServer2D.body_clear_shapes(body: RID) -> void
Removes all shapes from the body. This does not delete the shapes themselves, so they can continue to be used elsewhere or added back later.

### body :: RID

## body_create :: func PhysicsServer2D.body_create() -> RID
Creates a 2D body object in the physics server, and returns the [RID] that identifies it. The default settings for the created area include a collision layer and mask set to [code]1[/code], and body mode set to [constant BODY_MODE_RIGID].
Use [method body_add_shape] to add shapes to it, use [method body_set_state] to set its transform, and use [method body_set_space] to add the body to a space.

## body_get_canvas_instance_id :: func PhysicsServer2D.body_get_canvas_instance_id(body: RID) -> int
Returns the [code]ObjectID[/code] of the canvas attached to the body. Use [method @GlobalScope.instance_from_id] to retrieve a [CanvasLayer] from a nonzero [code]ObjectID[/code].

### body :: RID

## body_get_collision_layer :: func PhysicsServer2D.body_get_collision_layer(body: RID) -> int
Returns the physics layer or layers the body belongs to, as a bitmask.

### body :: RID

## body_get_collision_mask :: func PhysicsServer2D.body_get_collision_mask(body: RID) -> int
Returns the physics layer or layers the body can collide with, as a bitmask.

### body :: RID

## body_get_collision_priority :: func PhysicsServer2D.body_get_collision_priority(body: RID) -> float
Returns the body's collision priority. This is used in the depenetration phase of [method body_test_motion]. The higher the priority is, the lower the penetration into the body will be.

### body :: RID

## body_get_constant_force :: func PhysicsServer2D.body_get_constant_force(body: RID) -> Vector2
Returns the body's total constant positional force applied during each physics update.
See [method body_add_constant_force] and [method body_add_constant_central_force].

### body :: RID

## body_get_constant_torque :: func PhysicsServer2D.body_get_constant_torque(body: RID) -> float
Returns the body's total constant rotational force applied during each physics update.
See [method body_add_constant_torque].

### body :: RID

## body_get_continuous_collision_detection_mode :: func PhysicsServer2D.body_get_continuous_collision_detection_mode(body: RID) -> int
Returns the body's continuous collision detection mode.

### body :: RID

## body_get_direct_state :: func PhysicsServer2D.body_get_direct_state(body: RID) -> PhysicsDirectBodyState2D
Returns the [PhysicsDirectBodyState2D] of the body. Returns [code]null[/code] if the body is destroyed or not assigned to a space.

### body :: RID

## body_get_max_contacts_reported :: func PhysicsServer2D.body_get_max_contacts_reported(body: RID) -> int
Returns the maximum number of contacts that the body can report. See [method body_set_max_contacts_reported].

### body :: RID

## body_get_mode :: func PhysicsServer2D.body_get_mode(body: RID) -> int
Returns the body's mode.

### body :: RID

## body_get_object_instance_id :: func PhysicsServer2D.body_get_object_instance_id(body: RID) -> int
Returns the [code]ObjectID[/code] attached to the body. Use [method @GlobalScope.instance_from_id] to retrieve an [Object] from a nonzero [code]ObjectID[/code].

### body :: RID

## body_get_param :: func PhysicsServer2D.body_get_param(body: RID, param: int) -> Variant
Returns the value of the given body parameter.

### body :: RID

### param :: int

## body_get_shape :: func PhysicsServer2D.body_get_shape(body: RID, shape_idx: int) -> RID
Returns the [RID] of the shape with the given index in the body's array of shapes.

### body :: RID

### shape_idx :: int

## body_get_shape_count :: func PhysicsServer2D.body_get_shape_count(body: RID) -> int
Returns the number of shapes added to the body.

### body :: RID

## body_get_shape_transform :: func PhysicsServer2D.body_get_shape_transform(body: RID, shape_idx: int) -> Transform2D
Returns the local transform matrix of the shape with the given index in the area's array of shapes.

### body :: RID

### shape_idx :: int

## body_get_space :: func PhysicsServer2D.body_get_space(body: RID) -> RID
Returns the [RID] of the space assigned to the body. Returns an empty [RID] if no space is assigned.

### body :: RID

## body_get_state :: func PhysicsServer2D.body_get_state(body: RID, state: int) -> Variant
Returns the value of the given state of the body.

### body :: RID

### state :: int

## body_is_omitting_force_integration :: func PhysicsServer2D.body_is_omitting_force_integration(body: RID) -> bool
Returns [code]true[/code] if the body is omitting the standard force integration. See [method body_set_omit_force_integration].

### body :: RID

## body_remove_collision_exception :: func PhysicsServer2D.body_remove_collision_exception(body: RID, excepted_body: RID) -> void
Removes [param excepted_body] from the body's list of collision exceptions, so that collisions with it are no longer ignored.

### body :: RID

### excepted_body :: RID

## body_remove_shape :: func PhysicsServer2D.body_remove_shape(body: RID, shape_idx: int) -> void
Removes the shape with the given index from the body's array of shapes. The shape itself is not deleted, so it can continue to be used elsewhere or added back later. As a result of this operation, the body's shapes which used to have indices higher than [param shape_idx] will have their index decreased by one.

### body :: RID

### shape_idx :: int

## body_reset_mass_properties :: func PhysicsServer2D.body_reset_mass_properties(body: RID) -> void
Restores the default inertia and center of mass of the body based on its shapes. This undoes any custom values previously set using [method body_set_param].

### body :: RID

## body_set_axis_velocity :: func PhysicsServer2D.body_set_axis_velocity(body: RID, axis_velocity: Vector2) -> void
Modifies the body's linear velocity so that its projection to the axis [code]axis_velocity.normalized()[/code] is exactly [code]axis_velocity.length()[/code]. This is useful for jumping behavior.

### body :: RID

### axis_velocity :: Vector2

## body_set_collision_layer :: func PhysicsServer2D.body_set_collision_layer(body: RID, layer: int) -> void
Sets the physics layer or layers the body belongs to, via a bitmask.

### body :: RID

### layer :: int

## body_set_collision_mask :: func PhysicsServer2D.body_set_collision_mask(body: RID, mask: int) -> void
Sets the physics layer or layers the body can collide with, via a bitmask.

### body :: RID

### mask :: int

## body_set_collision_priority :: func PhysicsServer2D.body_set_collision_priority(body: RID, priority: float) -> void
Sets the body's collision priority. This is used in the depenetration phase of [method body_test_motion]. The higher the priority is, the lower the penetration into the body will be.

### body :: RID

### priority :: float

## body_set_constant_force :: func PhysicsServer2D.body_set_constant_force(body: RID, force: Vector2) -> void
Sets the body's total constant positional force applied during each physics update.
See [method body_add_constant_force] and [method body_add_constant_central_force].

### body :: RID

### force :: Vector2

## body_set_constant_torque :: func PhysicsServer2D.body_set_constant_torque(body: RID, torque: float) -> void
Sets the body's total constant rotational force applied during each physics update.
See [method body_add_constant_torque].

### body :: RID

### torque :: float

## body_set_continuous_collision_detection_mode :: func PhysicsServer2D.body_set_continuous_collision_detection_mode(body: RID, mode: int) -> void
Sets the continuous collision detection mode.
Continuous collision detection tries to predict where a moving body would collide in between physics updates, instead of moving it and correcting its movement if it collided.

### body :: RID

### mode :: int

## body_set_force_integration_callback :: func PhysicsServer2D.body_set_force_integration_callback(body: RID, callable: Callable, userdata: Variant = null) -> void
Sets the body's custom force integration callback function to [param callable]. Use an empty [Callable] ([code skip-lint]Callable()[/code]) to clear the custom callback.
The function [param callable] will be called every physics tick, before the standard force integration (see [method body_set_omit_force_integration]). It can be used for example to update the body's linear and angular velocity based on contact with other bodies.
If [param userdata] is not [code]null[/code], the function [param callable] must take the following two parameters:
1. [code]state[/code]: a [PhysicsDirectBodyState2D] used to retrieve and modify the body's state,
2. [code skip-lint]userdata[/code]: a [Variant]; its value will be the [param userdata] passed into this method.
If [param userdata] is [code]null[/code], then [param callable] must take only the [code]state[/code] parameter.

### body :: RID

### callable :: Callable

### userdata :: Variant

## body_set_max_contacts_reported :: func PhysicsServer2D.body_set_max_contacts_reported(body: RID, amount: int) -> void
Sets the maximum number of contacts that the body can report. If [param amount] is greater than zero, then the body will keep track of at most this many contacts with other bodies.

### body :: RID

### amount :: int

## body_set_mode :: func PhysicsServer2D.body_set_mode(body: RID, mode: int) -> void
Sets the body's mode.

### body :: RID

### mode :: int

## body_set_omit_force_integration :: func PhysicsServer2D.body_set_omit_force_integration(body: RID, enable: bool) -> void
Sets whether the body omits the standard force integration. If [param enable] is [code]true[/code], the body will not automatically use applied forces, torques, and damping to update the body's linear and angular velocity. In this case, [method body_set_force_integration_callback] can be used to manually update the linear and angular velocity instead.
This method is called when the property [member RigidBody2D.custom_integrator] is set.

### body :: RID

### enable :: bool

## body_set_param :: func PhysicsServer2D.body_set_param(body: RID, param: int, value: Variant) -> void
Sets the value of the given body parameter.

### body :: RID

### param :: int

### value :: Variant

## body_set_shape :: func PhysicsServer2D.body_set_shape(body: RID, shape_idx: int, shape: RID) -> void
Replaces the body's shape at the given index by another shape, while not affecting the [code]transform[/code], [code]disabled[/code], and one-way collision properties at the same index.

### body :: RID

### shape_idx :: int

### shape :: RID

## body_set_shape_as_one_way_collision :: func PhysicsServer2D.body_set_shape_as_one_way_collision(body: RID, shape_idx: int, enable: bool, margin: float, direction: Vector2 = Vector2(0, 1)) -> void
Sets the one-way collision properties of the body's shape with the given index. If [param enable] is [code]true[/code], the one-way collision direction given by [param direction] in the shape's local space (that is [code]body_get_shape_transform(body, shape_idx).basis_xform(direction).normalized()[/code] in the body's local space) will be used to ignore collisions with the shape in the opposite direction, and to ensure depenetration of kinematic bodies happens in this direction.

### body :: RID

### shape_idx :: int

### enable :: bool

### margin :: float

### direction :: Vector2

## body_set_shape_disabled :: func PhysicsServer2D.body_set_shape_disabled(body: RID, shape_idx: int, disabled: bool) -> void
Sets the disabled property of the body's shape with the given index. If [param disabled] is [code]true[/code], then the shape will be ignored in all collision detection.

### body :: RID

### shape_idx :: int

### disabled :: bool

## body_set_shape_transform :: func PhysicsServer2D.body_set_shape_transform(body: RID, shape_idx: int, transform: Transform2D) -> void
Sets the local transform matrix of the body's shape with the given index.

### body :: RID

### shape_idx :: int

### transform :: Transform2D

## body_set_space :: func PhysicsServer2D.body_set_space(body: RID, space: RID) -> void
Adds the body to the given space, after removing the body from the previously assigned space (if any). If the body's mode is set to [constant BODY_MODE_RIGID], then adding the body to a space will have the following additional effects:
- If the parameter [constant BODY_PARAM_CENTER_OF_MASS] has never been set explicitly, then the value of that parameter will be recalculated based on the body's shapes.
- If the parameter [constant BODY_PARAM_INERTIA] is set to a value [code]<= 0.0[/code], then the value of that parameter will be recalculated based on the body's shapes, mass, and center of mass.
[b]Note:[/b] To remove a body from a space without immediately adding it back elsewhere, use [code]PhysicsServer2D.body_set_space(body, RID())[/code].

### body :: RID

### space :: RID

## body_set_state :: func PhysicsServer2D.body_set_state(body: RID, state: int, value: Variant) -> void
Sets the value of a body's state.
[b]Note:[/b] The state change doesn't take effect immediately. The state will change on the next physics frame.

### body :: RID

### state :: int

### value :: Variant

## body_set_state_sync_callback :: func PhysicsServer2D.body_set_state_sync_callback(body: RID, callable: Callable) -> void
Sets the body's state synchronization callback function to [param callable]. Use an empty [Callable] ([code skip-lint]Callable()[/code]) to clear the callback.
The function [param callable] will be called every physics frame, assuming that the body was active during the previous physics tick, and can be used to fetch the latest state from the physics server.
The function [param callable] must take the following parameters:
1. [code]state[/code]: a [PhysicsDirectBodyState2D], used to retrieve the body's state.

### body :: RID

### callable :: Callable

## body_test_motion :: func PhysicsServer2D.body_test_motion(body: RID, parameters: PhysicsTestMotionParameters2D, result: PhysicsTestMotionResult2D = null) -> bool
Returns [code]true[/code] if a collision would result from moving the body along a motion vector from a given point in space. See [PhysicsTestMotionParameters2D] for the available motion parameters. Optionally a [PhysicsTestMotionResult2D] object can be passed, which will be used to store the information about the resulting collision.

### body :: RID

### parameters :: PhysicsTestMotionParameters2D

### result :: PhysicsTestMotionResult2D

## capsule_shape_create :: func PhysicsServer2D.capsule_shape_create() -> RID
Creates a 2D capsule shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the capsule's height and radius.

## circle_shape_create :: func PhysicsServer2D.circle_shape_create() -> RID
Creates a 2D circle shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the circle's radius.

## concave_polygon_shape_create :: func PhysicsServer2D.concave_polygon_shape_create() -> RID
Creates a 2D concave polygon shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the concave polygon's segments.

## convex_polygon_shape_create :: func PhysicsServer2D.convex_polygon_shape_create() -> RID
Creates a 2D convex polygon shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the convex polygon's points.

## damped_spring_joint_get_param :: func PhysicsServer2D.damped_spring_joint_get_param(joint: RID, param: int) -> float
Returns the value of the given damped spring joint parameter.

### joint :: RID

### param :: int

## damped_spring_joint_set_param :: func PhysicsServer2D.damped_spring_joint_set_param(joint: RID, param: int, value: float) -> void
Sets the value of the given damped spring joint parameter.

### joint :: RID

### param :: int

### value :: float

## free_rid :: func PhysicsServer2D.free_rid(rid: RID) -> void
Destroys any of the objects created by PhysicsServer2D. If the [RID] passed is not one of the objects that can be created by PhysicsServer2D, an error will be printed to the console.

### rid :: RID

## get_process_info :: func PhysicsServer2D.get_process_info(process_info: int) -> int
Returns the value of a physics engine state specified by [param process_info].

### process_info :: int

## joint_clear :: func PhysicsServer2D.joint_clear(joint: RID) -> void
Destroys the joint with the given [RID], creates a new uninitialized joint, and makes the [RID] refer to this new joint.

### joint :: RID

## joint_create :: func PhysicsServer2D.joint_create() -> RID
Creates a 2D joint in the physics server, and returns the [RID] that identifies it. To set the joint type, use [method joint_make_damped_spring], [method joint_make_groove] or [method joint_make_pin]. Use [method joint_set_param] to set generic joint parameters.

## joint_disable_collisions_between_bodies :: func PhysicsServer2D.joint_disable_collisions_between_bodies(joint: RID, disable: bool) -> void
Sets whether the bodies attached to the [Joint2D] will collide with each other.

### joint :: RID

### disable :: bool

## joint_get_param :: func PhysicsServer2D.joint_get_param(joint: RID, param: int) -> float
Returns the value of the given joint parameter.

### joint :: RID

### param :: int

## joint_get_type :: func PhysicsServer2D.joint_get_type(joint: RID) -> int
Returns the joint's type.

### joint :: RID

## joint_is_disabled_collisions_between_bodies :: func PhysicsServer2D.joint_is_disabled_collisions_between_bodies(joint: RID) -> bool
Returns whether the bodies attached to the [Joint2D] will collide with each other.

### joint :: RID

## joint_make_damped_spring :: func PhysicsServer2D.joint_make_damped_spring(joint: RID, anchor_a: Vector2, anchor_b: Vector2, body_a: RID, body_b: RID = RID()) -> void
Makes the joint a damped spring joint, attached at the point [param anchor_a] (given in global coordinates) on the body [param body_a] and at the point [param anchor_b] (given in global coordinates) on the body [param body_b]. To set the parameters which are specific to the damped spring, see [method damped_spring_joint_set_param].

### joint :: RID

### anchor_a :: Vector2

### anchor_b :: Vector2

### body_a :: RID

### body_b :: RID

## joint_make_groove :: func PhysicsServer2D.joint_make_groove(joint: RID, groove1_a: Vector2, groove2_a: Vector2, anchor_b: Vector2, body_a: RID = RID(), body_b: RID = RID()) -> void
Makes the joint a groove joint.

### joint :: RID

### groove1_a :: Vector2

### groove2_a :: Vector2

### anchor_b :: Vector2

### body_a :: RID

### body_b :: RID

## joint_make_pin :: func PhysicsServer2D.joint_make_pin(joint: RID, anchor: Vector2, body_a: RID, body_b: RID = RID()) -> void
Makes the joint a pin joint. If [param body_b] is an empty [RID], then [param body_a] is pinned to the point [param anchor] (given in global coordinates); otherwise, [param body_a] is pinned to [param body_b] at the point [param anchor] (given in global coordinates). To set the parameters which are specific to the pin joint, see [method pin_joint_set_param].

### joint :: RID

### anchor :: Vector2

### body_a :: RID

### body_b :: RID

## joint_set_param :: func PhysicsServer2D.joint_set_param(joint: RID, param: int, value: float) -> void
Sets the value of the given joint parameter.

### joint :: RID

### param :: int

### value :: float

## pin_joint_get_flag :: func PhysicsServer2D.pin_joint_get_flag(joint: RID, flag: int) -> bool
Gets a pin joint flag.

### joint :: RID

### flag :: int

## pin_joint_get_param :: func PhysicsServer2D.pin_joint_get_param(joint: RID, param: int) -> float
Returns the value of a pin joint parameter.

### joint :: RID

### param :: int

## pin_joint_set_flag :: func PhysicsServer2D.pin_joint_set_flag(joint: RID, flag: int, enabled: bool) -> void
Sets a pin joint flag.

### joint :: RID

### flag :: int

### enabled :: bool

## pin_joint_set_param :: func PhysicsServer2D.pin_joint_set_param(joint: RID, param: int, value: float) -> void
Sets a pin joint parameter.

### joint :: RID

### param :: int

### value :: float

## rectangle_shape_create :: func PhysicsServer2D.rectangle_shape_create() -> RID
Creates a 2D rectangle shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the rectangle's half-extents.

## segment_shape_create :: func PhysicsServer2D.segment_shape_create() -> RID
Creates a 2D segment shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the segment's start and end points.

## separation_ray_shape_create :: func PhysicsServer2D.separation_ray_shape_create() -> RID
Creates a 2D separation ray shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the shape's [code]length[/code] and [code]slide_on_slope[/code] properties.

## set_active :: func PhysicsServer2D.set_active(active: bool) -> void
Activates or deactivates the 2D physics server. If [param active] is [code]false[/code], then the physics server will not do anything in its physics step.

### active :: bool

## shape_get_data :: func PhysicsServer2D.shape_get_data(shape: RID) -> Variant
Returns the shape data that defines the configuration of the shape, such as the half-extents of a rectangle or the segments of a concave shape. See [method shape_set_data] for the precise format of this data in each case.

### shape :: RID

## shape_get_type :: func PhysicsServer2D.shape_get_type(shape: RID) -> int
Returns the shape's type.

### shape :: RID

## shape_set_data :: func PhysicsServer2D.shape_set_data(shape: RID, data: Variant) -> void
Sets the shape data that defines the configuration of the shape. The [param data] to be passed depends on the shape's type (see [method shape_get_type]):
- [constant SHAPE_WORLD_BOUNDARY]: an array of length two containing a [Vector2] [code]normal[/code] direction and a [float] distance [code]d[/code],
- [constant SHAPE_SEPARATION_RAY]: a dictionary containing the key [code]length[/code] with a [float] value and the key [code]slide_on_slope[/code] with a [bool] value,
- [constant SHAPE_SEGMENT]: a [Rect2] [code]rect[/code] containing the first point of the segment in [code]rect.position[/code] and the second point of the segment in [code]rect.size[/code],
- [constant SHAPE_CIRCLE]: a [float] [code]radius[/code],
- [constant SHAPE_RECTANGLE]: a [Vector2] [code]half_extents[/code],
- [constant SHAPE_CAPSULE]: an array of length two (or a [Vector2]) containing a [float] [code]height[/code] and a [float] [code]radius[/code],
- [constant SHAPE_CONVEX_POLYGON]: either a [PackedVector2Array] of points defining a convex polygon in counterclockwise order (the clockwise outward normal of each segment formed by consecutive points is calculated internally), or a [PackedFloat32Array] of length divisible by four so that every 4-tuple of [float]s contains the coordinates of a point followed by the coordinates of the clockwise outward normal vector to the segment between the current point and the next point,
- [constant SHAPE_CONCAVE_POLYGON]: a [PackedVector2Array] of length divisible by two (each pair of points forms one segment).
[b]Warning:[/b] In the case of [constant SHAPE_CONVEX_POLYGON], this method does not check if the points supplied actually form a convex polygon (unlike the [member CollisionPolygon2D.polygon] property).

### shape :: RID

### data :: Variant

## space_create :: func PhysicsServer2D.space_create() -> RID
Creates a 2D space in the physics server, and returns the [RID] that identifies it. A space contains bodies and areas, and controls the stepping of the physics simulation of the objects in it.

## space_get_direct_state :: func PhysicsServer2D.space_get_direct_state(space: RID) -> PhysicsDirectSpaceState2D
Returns the state of a space, a [PhysicsDirectSpaceState2D]. This object can be used for collision/intersection queries.

### space :: RID

## space_get_param :: func PhysicsServer2D.space_get_param(space: RID, param: int) -> float
Returns the value of the given space parameter.

### space :: RID

### param :: int

## space_is_active :: func PhysicsServer2D.space_is_active(space: RID) -> bool
Returns [code]true[/code] if the space is active.

### space :: RID

## space_set_active :: func PhysicsServer2D.space_set_active(space: RID, active: bool) -> void
Activates or deactivates the space. If [param active] is [code]false[/code], then the physics server will not do anything with this space in its physics step.

### space :: RID

### active :: bool

## space_set_param :: func PhysicsServer2D.space_set_param(space: RID, param: int, value: float) -> void
Sets the value of the given space parameter.

### space :: RID

### param :: int

### value :: float

## world_boundary_shape_create :: func PhysicsServer2D.world_boundary_shape_create() -> RID
Creates a 2D world boundary shape in the physics server, and returns the [RID] that identifies it. Use [method shape_set_data] to set the shape's normal direction and distance properties.
