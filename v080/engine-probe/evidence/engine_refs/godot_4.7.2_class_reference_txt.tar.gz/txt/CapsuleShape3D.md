# CapsuleShape3D :: <Native> class CapsuleShape3D extends Shape3D
A 3D capsule shape used for physics collision.
A 3D capsule shape, intended for use in physics. Usually used to provide a shape for a [CollisionShape3D].
[b]Performance:[/b] [CapsuleShape3D] is fast to check collisions against. It is faster than [CylinderShape3D], but slower than [SphereShape3D] and [BoxShape3D].

## height :: var CapsuleShape3D.height: float
The capsule's full height, including the hemispheres.
[b]Note:[/b] The [member height] of a capsule must be at least twice its [member radius]. Otherwise, the capsule becomes a sphere. If the [member height] is less than twice the [member radius], the properties adjust to a valid value.

## mid_height :: var CapsuleShape3D.mid_height: float
The capsule's height, excluding the hemispheres. This is the height of the central cylindrical part in the middle of the capsule, and is the distance between the centers of the two hemispheres. This is a wrapper for [member height].

## radius :: var CapsuleShape3D.radius: float
The capsule's radius.
[b]Note:[/b] The [member radius] of a capsule cannot be greater than half of its [member height]. Otherwise, the capsule becomes a sphere. If the [member radius] is greater than half of the [member height], the properties adjust to a valid value.
