# GLTFNode :: <Native> class GLTFNode extends Resource
glTF node class.
Represents a glTF node. glTF nodes may have names, transforms, children (other glTF nodes), and more specialized properties (represented by their own classes).
glTF nodes generally exist inside of [GLTFState] which represents all data of a glTF file. Most of GLTFNode's properties are indices of other data in the glTF file. You can extend a glTF node with additional properties by using [method get_additional_data] and [method set_additional_data].

## camera :: var GLTFNode.camera: int
If this glTF node is a camera, the index of the [GLTFCamera] in the [GLTFState] that describes the camera's properties. If [code]-1[/code], this node is not a camera.

## children :: var GLTFNode.children: PackedInt32Array
The indices of the child nodes in the [GLTFState]. If this glTF node has no children, this will be an empty array.

## height :: var GLTFNode.height: int
How deep into the node hierarchy this node is. A root node will have a height of 0, its children will have a height of 1, and so on. If -1, the height has not been calculated.

## light :: var GLTFNode.light: int
If this glTF node is a light, the index of the [GLTFLight] in the [GLTFState] that describes the light's properties. If -1, this node is not a light.

## mesh :: var GLTFNode.mesh: int
If this glTF node is a mesh, the index of the [GLTFMesh] in the [GLTFState] that describes the mesh's properties. If -1, this node is not a mesh.

## original_name :: var GLTFNode.original_name: String
The original name of the node.

## parent :: var GLTFNode.parent: int
The index of the parent node in the [GLTFState]. If -1, this node is a root node.

## position :: var GLTFNode.position: Vector3
The position of the glTF node relative to its parent.

## rotation :: var GLTFNode.rotation: Quaternion
The rotation of the glTF node relative to its parent.

## scale :: var GLTFNode.scale: Vector3
The scale of the glTF node relative to its parent.

## skeleton :: var GLTFNode.skeleton: int
If this glTF node has a skeleton, the index of the [GLTFSkeleton] in the [GLTFState] that describes the skeleton's properties. If -1, this node does not have a skeleton.

## skin :: var GLTFNode.skin: int
If this glTF node has a skin, the index of the [GLTFSkin] in the [GLTFState] that describes the skin's properties. If -1, this node does not have a skin.

## visible :: var GLTFNode.visible: bool
If [code]true[/code], the GLTF node is visible. If [code]false[/code], the GLTF node is not visible. This is converted to the [member Node3D.visible] property in the Godot scene, and is exported to [code]KHR_node_visibility[/code] when [code]false[/code].

## xform :: var GLTFNode.xform: Transform3D
The transform of the glTF node relative to its parent. This property is usually unused since the position, rotation, and scale properties are preferred.

## append_child_index :: func GLTFNode.append_child_index(child_index: int) -> void
Appends the given child node index to the [member children] array.

### child_index :: int

## get_additional_data :: func GLTFNode.get_additional_data(extension_name: StringName) -> Variant
Gets additional arbitrary data in this [GLTFNode] instance. This can be used to keep per-node state data in [GLTFDocumentExtension] classes, which is important because they are stateless.
The argument should be the [GLTFDocumentExtension] name (does not have to match the extension name in the glTF file), and the return value can be anything you set. If nothing was set, the return value is [code]null[/code].

### extension_name :: StringName

## get_scene_node_path :: func GLTFNode.get_scene_node_path(gltf_state: GLTFState, handle_skeletons: bool = true) -> NodePath
Returns the [NodePath] that this GLTF node will have in the Godot scene tree after being imported. This is useful when importing glTF object model pointers with [GLTFObjectModelProperty], for handling extensions such as [code]KHR_animation_pointer[/code] or [code]KHR_interactivity[/code].
If [param handle_skeletons] is [code]true[/code], paths to skeleton bone glTF nodes will be resolved properly. For example, a path that would be [code]^"A/B/C/Bone1/Bone2/Bone3"[/code] if [code]false[/code] will become [code]^"A/B/C/Skeleton3D:Bone3"[/code].

### gltf_state :: GLTFState

### handle_skeletons :: bool

## set_additional_data :: func GLTFNode.set_additional_data(extension_name: StringName, additional_data: Variant) -> void
Sets additional arbitrary data in this [GLTFNode] instance. This can be used to keep per-node state data in [GLTFDocumentExtension] classes, which is important because they are stateless.
The first argument should be the [GLTFDocumentExtension] name (does not have to match the extension name in the glTF file), and the second argument can be anything you want.

### extension_name :: StringName

### additional_data :: Variant
