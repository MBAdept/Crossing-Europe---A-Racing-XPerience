# BlitMaterial :: <Native> class BlitMaterial extends Material
A material that processes blit calls to a DrawableTexture.
A material resource that can be used by DrawableTextures when processing blit calls to draw.

## BLEND_MODE_MIX :: const BlitMaterial.BLEND_MODE_MIX: BlendMode = 0
Mix blending mode. Colors are assumed to be independent of the alpha (opacity) value.

## BLEND_MODE_ADD :: const BlitMaterial.BLEND_MODE_ADD: BlendMode = 1
Additive blending mode.

## BLEND_MODE_SUB :: const BlitMaterial.BLEND_MODE_SUB: BlendMode = 2
Subtractive blending mode.

## BLEND_MODE_MUL :: const BlitMaterial.BLEND_MODE_MUL: BlendMode = 3
Multiplicative blending mode.

## BLEND_MODE_DISABLED :: const BlitMaterial.BLEND_MODE_DISABLED: BlendMode = 4
No blending mode, direct color copy.

## blend_mode :: var BlitMaterial.blend_mode: BlitMaterial.BlendMode
The manner in which the newly blitted texture is blended with the original DrawableTexture.
