# SpriteBase3D :: <Native> class SpriteBase3D extends GeometryInstance3D
2D sprite node in 3D environment.
A node that displays 2D texture information in a 3D environment. See also [Sprite3D] where many other properties are defined.

## FLAG_TRANSPARENT :: const SpriteBase3D.FLAG_TRANSPARENT: DrawFlags = 0
If set, the texture's transparency and the opacity are used to make those parts of the sprite invisible.

## FLAG_SHADED :: const SpriteBase3D.FLAG_SHADED: DrawFlags = 1
If set, lights in the environment affect the sprite.

## FLAG_DOUBLE_SIDED :: const SpriteBase3D.FLAG_DOUBLE_SIDED: DrawFlags = 2
If set, texture can be seen from the back as well. If not, the texture is invisible when looking at it from behind.

## FLAG_DISABLE_DEPTH_TEST :: const SpriteBase3D.FLAG_DISABLE_DEPTH_TEST: DrawFlags = 3
Disables the depth test, so this object is drawn on top of all others. However, objects drawn after it in the draw order may cover it.

## FLAG_FIXED_SIZE :: const SpriteBase3D.FLAG_FIXED_SIZE: DrawFlags = 4
Label is scaled by depth so that it always appears the same size on screen.

## FLAG_MAX :: const SpriteBase3D.FLAG_MAX: DrawFlags = 5
Represents the size of the [enum DrawFlags] enum.

## ALPHA_CUT_DISABLED :: const SpriteBase3D.ALPHA_CUT_DISABLED: AlphaCutMode = 0
This mode performs standard alpha blending. It can display translucent areas, but transparency sorting issues may be visible when multiple transparent materials are overlapping.

## ALPHA_CUT_DISCARD :: const SpriteBase3D.ALPHA_CUT_DISCARD: AlphaCutMode = 1
This mode only allows fully transparent or fully opaque pixels. Harsh edges will be visible unless some form of screen-space antialiasing is enabled (see [member ProjectSettings.rendering/anti_aliasing/quality/screen_space_aa]). On the bright side, this mode doesn't suffer from transparency sorting issues when multiple transparent materials are overlapping. This mode is also known as [i]alpha testing[/i] or [i]1-bit transparency[/i].

## ALPHA_CUT_OPAQUE_PREPASS :: const SpriteBase3D.ALPHA_CUT_OPAQUE_PREPASS: AlphaCutMode = 2
This mode draws fully opaque pixels in the depth prepass. This is slower than [constant ALPHA_CUT_DISABLED] or [constant ALPHA_CUT_DISCARD], but it allows displaying translucent areas and smooth edges while using proper sorting.

## ALPHA_CUT_HASH :: const SpriteBase3D.ALPHA_CUT_HASH: AlphaCutMode = 3
This mode draws cuts off all values below a spatially-deterministic threshold, the rest will remain opaque.

## alpha_antialiasing_edge :: var SpriteBase3D.alpha_antialiasing_edge: float
Threshold at which antialiasing will be applied on the alpha channel.

## alpha_antialiasing_mode :: var SpriteBase3D.alpha_antialiasing_mode: BaseMaterial3D.AlphaAntiAliasing
The type of alpha antialiasing to apply.

## alpha_cut :: var SpriteBase3D.alpha_cut: SpriteBase3D.AlphaCutMode
The alpha cutting mode to use for the sprite.

## alpha_hash_scale :: var SpriteBase3D.alpha_hash_scale: float
The hashing scale for Alpha Hash. Recommended values between [code]0[/code] and [code]2[/code].

## alpha_scissor_threshold :: var SpriteBase3D.alpha_scissor_threshold: float
Threshold at which the alpha scissor will discard values.

## axis :: var SpriteBase3D.axis: Vector3.Axis
The direction in which the front of the texture faces.

## billboard :: var SpriteBase3D.billboard: BaseMaterial3D.BillboardMode
The billboard mode to use for the sprite.
[b]Note:[/b] When billboarding is enabled and the material also casts shadows, billboards will face [b]the[/b] camera in the scene when rendering shadows. In scenes with multiple cameras, the intended shadow cannot be determined and this will result in undefined behavior. See [url=https://github.com/godotengine/godot/pull/72638]GitHub Pull Request #72638[/url] for details.

## centered :: var SpriteBase3D.centered: bool
If [code]true[/code], texture will be centered.

## double_sided :: var SpriteBase3D.double_sided: bool
If [code]true[/code], texture can be seen from the back as well, if [code]false[/code], it is invisible when looking at it from behind.

## fixed_size :: var SpriteBase3D.fixed_size: bool
If [code]true[/code], the texture is rendered at the same size regardless of distance. The texture's size on screen is the same as if the camera was [code]1.0[/code] units away from the texture's origin, regardless of the actual distance from the camera. The [Camera3D]'s field of view (or [member Camera3D.size] when in orthogonal/frustum mode) still affects the size the sprite is drawn at.

## flip_h :: var SpriteBase3D.flip_h: bool
If [code]true[/code], texture is flipped horizontally.

## flip_v :: var SpriteBase3D.flip_v: bool
If [code]true[/code], texture is flipped vertically.

## modulate :: var SpriteBase3D.modulate: Color
A color value used to [i]multiply[/i] the texture's colors. Can be used for mood-coloring or to simulate the color of ambient light.
[b]Note:[/b] Unlike [member CanvasItem.modulate] for 2D, colors with values above [code]1.0[/code] (overbright) are not supported.
[b]Note:[/b] If a [member GeometryInstance3D.material_override] is defined on the [SpriteBase3D], the material override must be configured to take vertex colors into account for albedo. Otherwise, the color defined in [member modulate] will be ignored. For a [BaseMaterial3D], [member BaseMaterial3D.vertex_color_use_as_albedo] must be [code]true[/code]. For a [ShaderMaterial], [code]ALBEDO *= COLOR.rgb;[/code] must be inserted in the shader's [code]fragment()[/code] function.

## no_depth_test :: var SpriteBase3D.no_depth_test: bool
If [code]true[/code], depth testing is disabled and the object will be drawn in render order.

## offset :: var SpriteBase3D.offset: Vector2
The texture's drawing offset.
[b]Note:[/b] When you increase [member offset].y in Sprite3D, the sprite moves upward in world space (i.e., +Y is up).

## pixel_size :: var SpriteBase3D.pixel_size: float
The size of one pixel's width on the sprite to scale it in 3D.

## render_priority :: var SpriteBase3D.render_priority: int
Sets the render priority for the sprite. Higher priority objects will be sorted in front of lower priority objects.
[b]Note:[/b] This only applies if [member alpha_cut] is set to [constant ALPHA_CUT_DISABLED] (default value).
[b]Note:[/b] This only applies to sorting of transparent objects. This will not impact how transparent objects are sorted relative to opaque objects. This is because opaque objects are not sorted, while transparent objects are sorted from back to front (subject to priority).

## shaded :: var SpriteBase3D.shaded: bool
If [code]true[/code], the [Light3D] in the [Environment] has effects on the sprite.

## texture_filter :: var SpriteBase3D.texture_filter: BaseMaterial3D.TextureFilter
Filter flags for the texture.
[b]Note:[/b] Linear filtering may cause artifacts around the edges, which are especially noticeable on opaque textures. To prevent this, use textures with transparent or identical colors around the edges.

## transparent :: var SpriteBase3D.transparent: bool
If [code]true[/code], the texture's transparency and the opacity are used to make those parts of the sprite invisible.

## generate_triangle_mesh :: func SpriteBase3D.generate_triangle_mesh() -> TriangleMesh
Returns a [TriangleMesh] with the sprite's vertices following its current configuration (such as its [member axis] and [member pixel_size]).

## get_draw_flag :: func SpriteBase3D.get_draw_flag(flag: int) -> bool
Returns the value of the specified flag.

### flag :: int

## get_item_rect :: func SpriteBase3D.get_item_rect() -> Rect2
Returns the rectangle representing this sprite.

## set_draw_flag :: func SpriteBase3D.set_draw_flag(flag: int, enabled: bool) -> void
If [code]true[/code], the specified flag will be enabled.

### flag :: int

### enabled :: bool
