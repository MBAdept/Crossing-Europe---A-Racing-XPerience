# VirtualJoystick :: <Native> class VirtualJoystick extends Control
A virtual joystick control for touchscreen devices.
A customizable on-screen joystick control designed for touchscreen devices. It allows users to provide directional input by dragging a virtual tip within a defined circular area.
This control can simulate directional actions (see [member action_up], [member action_down], [member action_left], and [member action_right]), which are triggered when the joystick is moved in the corresponding directions.

## JOYSTICK_FIXED :: const VirtualJoystick.JOYSTICK_FIXED: JoystickMode = 0
The joystick doesn't move.

## JOYSTICK_DYNAMIC :: const VirtualJoystick.JOYSTICK_DYNAMIC: JoystickMode = 1
The joystick is moved to the initial touch position as long as it's within the joystick's bounds. It moves back to its original position when released.

## JOYSTICK_FOLLOWING :: const VirtualJoystick.JOYSTICK_FOLLOWING: JoystickMode = 2
The joystick is moved to the initial touch position as long as it's within the joystick's bounds. It will follow the touch input if it goes outside the joystick's range. It moves back to its original position when released.

## VISIBILITY_ALWAYS :: const VirtualJoystick.VISIBILITY_ALWAYS: VisibilityMode = 0
The joystick is always visible.

## VISIBILITY_WHEN_TOUCHED :: const VirtualJoystick.VISIBILITY_WHEN_TOUCHED: VisibilityMode = 1
The joystick is only visible when being touched.

## action_down :: var VirtualJoystick.action_down: StringName
The action to trigger when the joystick is moved down.

## action_left :: var VirtualJoystick.action_left: StringName
The action to trigger when the joystick is moved left.

## action_right :: var VirtualJoystick.action_right: StringName
The action to trigger when the joystick is moved right.

## action_up :: var VirtualJoystick.action_up: StringName
The action to trigger when the joystick is moved up.

## clampzone_ratio :: var VirtualJoystick.clampzone_ratio: float
The multiplier applied to the joystick's radius that defines the clamp zone.
This zone limits how far the joystick tip can move from its center before being clamped.
A value of [code]1.0[/code] means the tip can move up to the edge of the joystick's visual size.
In [constant JOYSTICK_FOLLOWING] mode, this radius also determines how far the finger can move before the joystick base starts following the touch input.

## deadzone_ratio :: var VirtualJoystick.deadzone_ratio: float
The ratio of the joystick size that defines the joystick deadzone. The joystick tip must move beyond this ratio before being considered active.
This deadzone is applied before triggering input actions and affects the joystick's input vector and all related signals.
Note that input actions may also define their own deadzones in the InputMap. If both are set, the joystick deadzone is applied first, followed by the action's deadzone.
By default, this value is [code]0.0[/code], meaning the joystick does not apply its own deadzone and relies entirely on the InputMap action deadzones.

## initial_offset_ratio :: var VirtualJoystick.initial_offset_ratio: Vector2
The initial position of the joystick as a ratio of the control's size. [code](0, 0)[/code] is top-left and [code](1, 1)[/code] is bottom-right.

## joystick_mode :: var VirtualJoystick.joystick_mode: VirtualJoystick.JoystickMode
The joystick mode to use.

## joystick_size :: var VirtualJoystick.joystick_size: float
The size of the joystick in pixels.

## tip_size :: var VirtualJoystick.tip_size: float
The size of the joystick tip in pixels.

## visibility_mode :: var VirtualJoystick.visibility_mode: VirtualJoystick.VisibilityMode
The visibility mode to use.

## normal_joystick :: <Theme> var VirtualJoystick.normal_joystick: StyleBox
Base joystick [StyleBox].

## normal_tip :: <Theme> var VirtualJoystick.normal_tip: StyleBox
Tip joystick [StyleBox].

## pressed_joystick :: <Theme> var VirtualJoystick.pressed_joystick: StyleBox
Base joystick [StyleBox] when pressed.

## pressed_tip :: <Theme> var VirtualJoystick.pressed_tip: StyleBox
Tip joystick [StyleBox] when pressed.

## flick_canceled :: func VirtualJoystick.flick_canceled() -> void
Emitted when the tip enters the deadzone after being outside of it.

## flicked :: func VirtualJoystick.flicked(input_vector: Vector2) -> void
Emitted when the tip moved outside the deadzone and the joystick is released. The [param input_vector] contains the last input direction and strength before release. Its length is between [code]0.0[/code] and [code]1.0[/code].

### input_vector :: Vector2

## pressed :: func VirtualJoystick.pressed() -> void
Emitted when the joystick is pressed.

## released :: func VirtualJoystick.released(input_vector: Vector2) -> void
Emitted when the joystick is released. The [param input_vector] is the final input direction and strength, with a length between [code]0.0[/code] and [code]1.0[/code].

### input_vector :: Vector2

## tapped :: func VirtualJoystick.tapped() -> void
Emitted when the joystick is released without moving the tip.
