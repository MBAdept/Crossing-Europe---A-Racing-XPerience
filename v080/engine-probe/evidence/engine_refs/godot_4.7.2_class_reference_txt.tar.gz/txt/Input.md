# Input :: <Native> class Input extends Object
A singleton for handling inputs.
The [Input] singleton handles key presses, mouse buttons and movement, gamepads, and input actions. Actions and their events can be set in the [b]Input Map[/b] tab in [b]Project > Project Settings[/b], or with the [InputMap] class.
[b]Note:[/b] [Input]'s methods reflect the global input state and are not affected by [method Control.accept_event] or [method Viewport.set_input_as_handled], as those methods only deal with the way input is propagated in the [SceneTree].

## MOUSE_MODE_VISIBLE :: const Input.MOUSE_MODE_VISIBLE: MouseMode = 0
Makes the mouse cursor visible if it is hidden.

## MOUSE_MODE_HIDDEN :: const Input.MOUSE_MODE_HIDDEN: MouseMode = 1
Makes the mouse cursor hidden if it is visible.

## MOUSE_MODE_CAPTURED :: const Input.MOUSE_MODE_CAPTURED: MouseMode = 2
Captures the mouse. The mouse will be hidden and its position locked at the center of the window manager's window.
[b]Note:[/b] If you want to process the mouse's movement in this mode, you need to use [member InputEventMouseMotion.relative].

## MOUSE_MODE_CONFINED :: const Input.MOUSE_MODE_CONFINED: MouseMode = 3
Confines the mouse cursor to the game window, and make it visible.

## MOUSE_MODE_CONFINED_HIDDEN :: const Input.MOUSE_MODE_CONFINED_HIDDEN: MouseMode = 4
Confines the mouse cursor to the game window, and make it hidden.

## MOUSE_MODE_MAX :: const Input.MOUSE_MODE_MAX: MouseMode = 5
Max value of the [enum MouseMode].

## CURSOR_ARROW :: const Input.CURSOR_ARROW: CursorShape = 0
Arrow cursor. Standard, default pointing cursor.

## CURSOR_IBEAM :: const Input.CURSOR_IBEAM: CursorShape = 1
I-beam cursor. Usually used to show where the text cursor will appear when the mouse is clicked.

## CURSOR_POINTING_HAND :: const Input.CURSOR_POINTING_HAND: CursorShape = 2
Pointing hand cursor. Usually used to indicate the pointer is over a link or other interactable item.

## CURSOR_CROSS :: const Input.CURSOR_CROSS: CursorShape = 3
Cross cursor. Typically appears over regions in which a drawing operation can be performed or for selections.

## CURSOR_WAIT :: const Input.CURSOR_WAIT: CursorShape = 4
Wait cursor. Indicates that the application is busy performing an operation, and that it cannot be used during the operation (e.g. something is blocking its main thread).

## CURSOR_BUSY :: const Input.CURSOR_BUSY: CursorShape = 5
Busy cursor. Indicates that the application is busy performing an operation, and that it is still usable during the operation.

## CURSOR_DRAG :: const Input.CURSOR_DRAG: CursorShape = 6
Drag cursor. Usually displayed when dragging something.
[b]Note:[/b] Windows lacks a dragging cursor, so [constant CURSOR_DRAG] is the same as [constant CURSOR_MOVE] for this platform.

## CURSOR_CAN_DROP :: const Input.CURSOR_CAN_DROP: CursorShape = 7
Can drop cursor. Usually displayed when dragging something to indicate that it can be dropped at the current position.

## CURSOR_FORBIDDEN :: const Input.CURSOR_FORBIDDEN: CursorShape = 8
Forbidden cursor. Indicates that the current action is forbidden (for example, when dragging something) or that the control at a position is disabled.

## CURSOR_VSIZE :: const Input.CURSOR_VSIZE: CursorShape = 9
Vertical resize mouse cursor. A double-headed vertical arrow. It tells the user they can resize the window or the panel vertically.

## CURSOR_HSIZE :: const Input.CURSOR_HSIZE: CursorShape = 10
Horizontal resize mouse cursor. A double-headed horizontal arrow. It tells the user they can resize the window or the panel horizontally.

## CURSOR_BDIAGSIZE :: const Input.CURSOR_BDIAGSIZE: CursorShape = 11
Window resize mouse cursor. The cursor is a double-headed arrow that goes from the bottom left to the top right. It tells the user they can resize the window or the panel both horizontally and vertically.

## CURSOR_FDIAGSIZE :: const Input.CURSOR_FDIAGSIZE: CursorShape = 12
Window resize mouse cursor. The cursor is a double-headed arrow that goes from the top left to the bottom right, the opposite of [constant CURSOR_BDIAGSIZE]. It tells the user they can resize the window or the panel both horizontally and vertically.

## CURSOR_MOVE :: const Input.CURSOR_MOVE: CursorShape = 13
Move cursor. Indicates that something can be moved.

## CURSOR_VSPLIT :: const Input.CURSOR_VSPLIT: CursorShape = 14
Vertical split mouse cursor. On Windows, it's the same as [constant CURSOR_VSIZE].

## CURSOR_HSPLIT :: const Input.CURSOR_HSPLIT: CursorShape = 15
Horizontal split mouse cursor. On Windows, it's the same as [constant CURSOR_HSIZE].

## CURSOR_HELP :: const Input.CURSOR_HELP: CursorShape = 16
Help cursor. Usually a question mark.

## emulate_mouse_from_touch :: var Input.emulate_mouse_from_touch: bool
If [code]true[/code], sends mouse input events when tapping or swiping on the touchscreen. See also [member ProjectSettings.input_devices/pointing/emulate_mouse_from_touch].

## emulate_touch_from_mouse :: var Input.emulate_touch_from_mouse: bool
If [code]true[/code], sends touch input events when clicking or dragging the mouse. See also [member ProjectSettings.input_devices/pointing/emulate_touch_from_mouse].

## ignore_joypad_on_unfocused_application :: var Input.ignore_joypad_on_unfocused_application: bool
If [code]true[/code], joypad input (including motion sensors) and LED light changes will be ignored and joypad vibration will be stopped when the application is not focused.

## mouse_mode :: var Input.mouse_mode: Input.MouseMode
Controls the mouse mode.

## use_accumulated_input :: var Input.use_accumulated_input: bool
If [code]true[/code], similar input events sent by the operating system are accumulated. When input accumulation is enabled, all input events generated during a frame will be merged and emitted when the frame is done rendering. Therefore, this limits the number of input method calls per second to the rendering FPS.
Input accumulation can be disabled to get slightly more precise/reactive input at the cost of increased CPU usage. In applications where drawing freehand lines is required, input accumulation should generally be disabled while the user is drawing the line to get results that closely follow the actual input.
[b]Note:[/b] Input accumulation is [i]enabled[/i] by default.

## action_press :: func Input.action_press(action: StringName, strength: float = 1.0) -> void
This will simulate pressing the specified action.
The strength can be used for non-boolean actions, it's ranged between 0 and 1 representing the intensity of the given action.
[b]Note:[/b] This method will not cause any [method Node._input] calls. It is intended to be used with [method is_action_pressed] and [method is_action_just_pressed]. If you want to simulate [code]_input[/code], use [method parse_input_event] instead.

### action :: StringName

### strength :: float

## action_release :: func Input.action_release(action: StringName) -> void
If the specified action is already pressed, this will release it.

### action :: StringName

## add_joy_mapping :: func Input.add_joy_mapping(mapping: String, update_existing: bool = false) -> void
Adds a new mapping entry (in SDL2 format) to the mapping database. Optionally update already connected devices.

### mapping :: String

### update_existing :: bool

## clear_joy_motion_sensors_calibration :: func Input.clear_joy_motion_sensors_calibration(device: int) -> void
Clears the calibration information for the specified joypad's motion sensors, if it has any and if they were calibrated.
See [method start_joy_motion_sensors_calibration] for an example on how to use joypad motion sensors and calibration in your games.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

## flush_buffered_events :: func Input.flush_buffered_events() -> void
Sends all input events which are in the current buffer to the game loop. These events may have been buffered as a result of accumulated input ([member use_accumulated_input]) or agile input flushing ([member ProjectSettings.input_devices/buffering/agile_event_flushing]).
The engine will already do this itself at key execution points (at least once per frame). However, this can be useful in advanced cases where you want precise control over the timing of event handling.

## get_accelerometer :: func Input.get_accelerometer() -> Vector3
Returns the acceleration in m/s² of the device's accelerometer sensor, if the device has one. Otherwise, the method returns [constant Vector3.ZERO].
Note this method returns an empty [Vector3] when running from the editor even when your device has an accelerometer. You must export your project to a supported device to read values from the accelerometer.
[b]Note:[/b] This method only works on Android and iOS. On other platforms, it always returns [constant Vector3.ZERO].
[b]Note:[/b] For Android, [member ProjectSettings.input_devices/sensors/enable_accelerometer] must be enabled.

## get_action_raw_strength :: func Input.get_action_raw_strength(action: StringName, exact_match: bool = false) -> float
Returns a value between 0 and 1 representing the raw intensity of the given action, ignoring the action's deadzone. In most cases, you should use [method get_action_strength] instead.
If [param exact_match] is [code]false[/code], it ignores additional input modifiers for [InputEventKey] and [InputEventMouseButton] events, and the direction for [InputEventJoypadMotion] events.

### action :: StringName

### exact_match :: bool

## get_action_strength :: func Input.get_action_strength(action: StringName, exact_match: bool = false) -> float
Returns a value between 0 and 1 representing the intensity of the given action. In a joypad, for example, the further away the axis (analog sticks or L2, R2 triggers) is from the dead zone, the closer the value will be to 1. If the action is mapped to a control that has no axis such as the keyboard, the value returned will be 0 or 1.
If [param exact_match] is [code]false[/code], it ignores additional input modifiers for [InputEventKey] and [InputEventMouseButton] events, and the direction for [InputEventJoypadMotion] events.

### action :: StringName

### exact_match :: bool

## get_axis :: func Input.get_axis(negative_action: StringName, positive_action: StringName) -> float
Get axis input by specifying two actions, one negative and one positive.
This is a shorthand for writing [code]Input.get_action_strength("positive_action") - Input.get_action_strength("negative_action")[/code].

### negative_action :: StringName

### positive_action :: StringName

## get_connected_joypads :: func Input.get_connected_joypads() -> int[]
Returns an [Array] containing the device IDs of all currently connected joypads.
[b]Note:[/b] The order of connected joypads can not be guaranteed to be the same after a project and/or the editor is restarted, because Godot doesn't save the order of joypad connections. Joypads are registered in the order they are discovered by Godot.

## get_current_cursor_shape :: func Input.get_current_cursor_shape() -> int
Returns the currently assigned cursor shape.

## get_gravity :: func Input.get_gravity() -> Vector3
Returns the gravity in m/s² of the device's accelerometer sensor, if the device has one. Otherwise, the method returns [constant Vector3.ZERO].
[b]Note:[/b] This method only works on Android and iOS. On other platforms, it always returns [constant Vector3.ZERO].
[b]Note:[/b] For Android, [member ProjectSettings.input_devices/sensors/enable_gravity] must be enabled.

## get_gyroscope :: func Input.get_gyroscope() -> Vector3
Returns the rotation rate in rad/s around a device's X, Y, and Z axes of the gyroscope sensor, if the device has one. Otherwise, the method returns [constant Vector3.ZERO].
[b]Note:[/b] This method only works on Android and iOS. On other platforms, it always returns [constant Vector3.ZERO].
[b]Note:[/b] For Android, [member ProjectSettings.input_devices/sensors/enable_gyroscope] must be enabled.

## get_joy_accelerometer :: func Input.get_joy_accelerometer(device: int) -> Vector3
Returns the acceleration, including the force of gravity, in m/s² of the joypad's accelerometer sensor, if the joypad has one and it's currently enabled. Otherwise, the method returns [constant Vector3.ZERO]. See also [method get_joy_gravity] and [method set_joy_motion_sensors_enabled].
For a joypad held in front of you, the returned axes are defined as follows:
+X ... -X: left ... right;
+Y ... -Y: bottom ... top;
+Z ... -Z: farther ... closer.
The gravity part value is measured as a vector with length of [code]9.8[/code] away from the center of the Earth, which is a negative Y value.
[b]Note:[/b] This feature is only supported on Windows, Linux, and macOS. On iOS, joypad accelerometer sensor reading is not supported due to OS limitations.

### device :: int

## get_joy_axis :: func Input.get_joy_axis(device: int, axis: int) -> float
Returns the current value of the joypad axis at index [param axis].

### device :: int

### axis :: int

## get_joy_gravity :: func Input.get_joy_gravity(device: int) -> Vector3
Returns the gravity in m/s² of the joypad's accelerometer sensor, if the joypad has one and it's currently enabled. Otherwise, the method returns [constant Vector3.ZERO]. See also [method get_joy_accelerometer] and [method set_joy_motion_sensors_enabled].
For a joypad held in front of you, the returned axes are defined as follows:
+X ... -X: left ... right;
+Y ... -Y: bottom ... top;
+Z ... -Z: farther ... closer.
The gravity part value is measured as a vector with length of [code]9.8[/code] away from the center of the Earth, which is a negative Y value.
[b]Note:[/b] This feature is only supported on Windows, Linux, and macOS. On iOS, joypad accelerometer sensor reading is not supported due to OS limitations.

### device :: int

## get_joy_guid :: func Input.get_joy_guid(device: int) -> String
Returns an SDL-compatible device GUID on platforms that use gamepad remapping, e.g. [code]030000004c050000c405000000010000[/code]. Returns an empty string if it cannot be found. Godot uses SDL's internal mappings, supplemented by community-contributed mappings, to determine gamepad names and mappings based on this GUID.
On Windows, all XInput joypad GUIDs will be overridden by Godot to [code]__XINPUT_DEVICE__[/code], because their mappings are the same.

### device :: int

## get_joy_gyroscope :: func Input.get_joy_gyroscope(device: int) -> Vector3
Returns the rotation rate in rad/s around a joypad's X, Y, and Z axes of the gyroscope sensor, if the joypad has one and it's currently enabled. Otherwise, the method returns [constant Vector3.ZERO]. See also [method set_joy_motion_sensors_enabled].
The rotation is positive in the counter-clockwise direction.
For a joypad held in front of you, the returned axes are defined as follows:
X: Angular speed around the X axis (pitch);
Y: Angular speed around the Y axis (yaw);
Z: Angular speed around the Z axis (roll).
See [method start_joy_motion_sensors_calibration] for an example on how to use joypad gyroscope and gyroscope calibration in your games.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

## get_joy_info :: func Input.get_joy_info(device: int) -> Dictionary
Returns a dictionary with extra platform-specific information about the device, e.g. the raw gamepad name from the OS or the Steam Input index.
On Windows, Linux, macOS, and iOS, the dictionary contains the following fields:
[code]raw_name[/code]: The name of the controller as it came from the OS, before getting renamed by the controller database.
[code]vendor_id[/code]: The USB vendor ID of the device.
[code]product_id[/code]: The USB product ID of the device.
[code]serial_number[/code]: The serial number of the device. This key won't be present if the serial number is unavailable.
The dictionary can also include the following fields under selected platforms:
[code]steam_input_index[/code]: The Steam Input gamepad index (Windows, Linux, and macOS only). If the device is not a Steam Input device this key won't be present.
[code]xinput_index[/code]: The index of the controller in the XInput system (Windows only). This key won't be present for devices not handled by XInput.
[b]Note:[/b] The returned dictionary is always empty on Android and Web.

### device :: int

## get_joy_motion_sensors_calibration :: func Input.get_joy_motion_sensors_calibration(device: int) -> Dictionary
Returns the calibration information about the specified joypad's motion sensors in the form of a [Dictionary], if it has any and if they have been calibrated, otherwise returns an empty [Dictionary].
The dictionary contains the following fields:
[code]gyroscope_offset[/code]: average offset in gyroscope values from [constant Vector2.ZERO] in rad/s.
See [method start_joy_motion_sensors_calibration] for an example on how to use joypad motion sensors and calibration in your games.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

## get_joy_motion_sensors_rate :: func Input.get_joy_motion_sensors_rate(device: int) -> float
Returns the joypad's motion sensor rate in Hz, if the joypad has motion sensors and they're currently enabled. See also [method set_joy_motion_sensors_enabled].
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

## get_joy_name :: func Input.get_joy_name(device: int) -> String
Returns the name of the joypad at the specified device index, e.g. [code]PS4 Controller[/code]. Godot uses the [url=https://github.com/gabomdq/SDL_GameControllerDB]SDL2 game controller database[/url] to determine gamepad names.

### device :: int

## get_joy_vibration_duration :: func Input.get_joy_vibration_duration(device: int) -> float
Returns the duration of the current vibration effect in seconds.
[b]Note:[/b] This method returns the same value that was passed to [method start_joy_vibration], and this value does [b]not[/b] change when the joypad's vibration runs out, it only gets reset after a call to [method stop_joy_vibration].
If you want to check if a joypad is still vibrating, use [method is_joy_vibrating] instead.

### device :: int

## get_joy_vibration_remaining_duration :: func Input.get_joy_vibration_remaining_duration(device: int) -> float
Returns the remaining duration of the current vibration effect in seconds.

### device :: int

## get_joy_vibration_strength :: func Input.get_joy_vibration_strength(device: int) -> Vector2
Returns the strength of the joypad vibration: x is the strength of the weak motor, and y is the strength of the strong motor.
[b]Note:[/b] This method returns the same values that were passed to [method start_joy_vibration], and these values do [b]not[/b] change when the joypad's vibration runs out, they only get reset after a call to [method stop_joy_vibration].
If you want to check if a joypad is still vibrating, use [method is_joy_vibrating] instead.

### device :: int

## get_last_mouse_screen_velocity :: func Input.get_last_mouse_screen_velocity() -> Vector2
Returns the last mouse velocity in screen coordinates. To provide a precise and jitter-free velocity, mouse velocity is only calculated every 0.1s. Therefore, mouse velocity will lag mouse movements.

## get_last_mouse_velocity :: func Input.get_last_mouse_velocity() -> Vector2
Returns the last mouse velocity. To provide a precise and jitter-free velocity, mouse velocity is only calculated every 0.1s. Therefore, mouse velocity will lag mouse movements.

## get_magnetometer :: func Input.get_magnetometer() -> Vector3
Returns the magnetic field strength in micro-Tesla for all axes of the device's magnetometer sensor, if the device has one. Otherwise, the method returns [constant Vector3.ZERO].
[b]Note:[/b] This method only works on Android and iOS. On other platforms, it always returns [constant Vector3.ZERO].
[b]Note:[/b] For Android, [member ProjectSettings.input_devices/sensors/enable_magnetometer] must be enabled.

## get_mouse_button_mask :: func Input.get_mouse_button_mask() -> int
Returns mouse buttons as a bitmask. If multiple mouse buttons are pressed at the same time, the bits are added together. Equivalent to [method DisplayServer.mouse_get_button_state].

## get_vector :: func Input.get_vector(negative_x: StringName, positive_x: StringName, negative_y: StringName, positive_y: StringName, deadzone: float = -1.0) -> Vector2
Gets an input vector by specifying four actions for the positive and negative X and Y axes.
This method is useful when getting vector input, such as from a joystick, directional pad, arrows, or WASD. The vector has its length limited to 1 and has a circular deadzone, which is useful for using vector input as movement.
By default, the deadzone is automatically calculated from the average of the action deadzones. However, you can override the deadzone to be whatever you want (on the range of 0 to 1).

### negative_x :: StringName

### positive_x :: StringName

### negative_y :: StringName

### positive_y :: StringName

### deadzone :: float

## has_joy_light :: func Input.has_joy_light(device: int) -> bool
Returns [code]true[/code] if the joypad has an LED light that can change colors and/or brightness. See also [method set_joy_light].
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

## has_joy_motion_sensors :: func Input.has_joy_motion_sensors(device: int) -> bool
Returns [code]true[/code] if the joypad has motion sensors (accelerometer and gyroscope).
[b]Note:[/b] On iOS, joypad accelerometer sensor reading is not supported due to OS limitations.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

## has_joy_vibration :: func Input.has_joy_vibration(device: int) -> bool
Returns [code]true[/code] if the joypad supports vibration. See also [method start_joy_vibration].
[b]Note:[/b] For macOS, vibration is only supported in macOS 11 and later. When connected via USB, vibration is only supported for major brand controllers (except Xbox One and Xbox Series X/S controllers) due to macOS limitations.

### device :: int

## is_action_just_pressed :: func Input.is_action_just_pressed(action: StringName, exact_match: bool = false) -> bool
Returns [code]true[/code] when the user has [i]started[/i] pressing the action event in the current frame or physics tick. It will only return [code]true[/code] on the frame or tick that the user pressed down the button.
This is useful for code that needs to run only once when an action is pressed, instead of every frame while it's pressed.
If [param exact_match] is [code]false[/code], it ignores additional input modifiers for [InputEventKey] and [InputEventMouseButton] events, and the direction for [InputEventJoypadMotion] events.
[b]Note:[/b] Returning [code]true[/code] does not imply that the action is [i]still[/i] pressed. An action can be pressed and released again rapidly, and [code]true[/code] will still be returned so as not to miss input.
[b]Note:[/b] Due to keyboard ghosting, [method is_action_just_pressed] may return [code]false[/code] even if one of the action's keys is pressed. See [url=https://docs.godotengine.org/en/4.7/tutorials/inputs/input_examples.html#keyboard-events]Input examples[/url] in the documentation for more information.
[b]Note:[/b] During input handling (e.g. [method Node._input]), use [method InputEvent.is_action_pressed] instead to query the action state of the current event. See also [method is_action_just_pressed_by_event].

### action :: StringName

### exact_match :: bool

## is_action_just_pressed_by_event :: func Input.is_action_just_pressed_by_event(action: StringName, event: InputEvent, exact_match: bool = false) -> bool
Returns [code]true[/code] when the user has [i]started[/i] pressing the action event in the current frame or physics tick, and the first event that triggered action press in the current frame/physics tick was [param event]. It will only return [code]true[/code] on the frame or tick that the user pressed down the button.
This is useful for code that needs to run only once when an action is pressed, and the action is processed during input handling (e.g. [method Node._input]).
If [param exact_match] is [code]false[/code], it ignores additional input modifiers for [InputEventKey] and [InputEventMouseButton] events, and the direction for [InputEventJoypadMotion] events.
[b]Note:[/b] Returning [code]true[/code] does not imply that the action is [i]still[/i] pressed. An action can be pressed and released again rapidly, and [code]true[/code] will still be returned so as not to miss input.
[b]Note:[/b] Due to keyboard ghosting, [method is_action_just_pressed] may return [code]false[/code] even if one of the action's keys is pressed. See [url=https://docs.godotengine.org/en/4.7/tutorials/inputs/input_examples.html#keyboard-events]Input examples[/url] in the documentation for more information.

### action :: StringName

### event :: InputEvent

### exact_match :: bool

## is_action_just_released :: func Input.is_action_just_released(action: StringName, exact_match: bool = false) -> bool
Returns [code]true[/code] when the user [i]stops[/i] pressing the action event in the current frame or physics tick. It will only return [code]true[/code] on the frame or tick that the user releases the button.
[b]Note:[/b] Returning [code]true[/code] does not imply that the action is [i]still[/i] not pressed. An action can be released and pressed again rapidly, and [code]true[/code] will still be returned so as not to miss input.
If [param exact_match] is [code]false[/code], it ignores additional input modifiers for [InputEventKey] and [InputEventMouseButton] events, and the direction for [InputEventJoypadMotion] events.
[b]Note:[/b] During input handling (e.g. [method Node._input]), use [method InputEvent.is_action_released] instead to query the action state of the current event. See also [method is_action_just_released_by_event].

### action :: StringName

### exact_match :: bool

## is_action_just_released_by_event :: func Input.is_action_just_released_by_event(action: StringName, event: InputEvent, exact_match: bool = false) -> bool
Returns [code]true[/code] when the user [i]stops[/i] pressing the action event in the current frame or physics tick, and the first event that triggered action release in the current frame/physics tick was [param event]. It will only return [code]true[/code] on the frame or tick that the user releases the button.
This is useful when an action is processed during input handling (e.g. [method Node._input]).
[b]Note:[/b] Returning [code]true[/code] does not imply that the action is [i]still[/i] not pressed. An action can be released and pressed again rapidly, and [code]true[/code] will still be returned so as not to miss input.
If [param exact_match] is [code]false[/code], it ignores additional input modifiers for [InputEventKey] and [InputEventMouseButton] events, and the direction for [InputEventJoypadMotion] events.

### action :: StringName

### event :: InputEvent

### exact_match :: bool

## is_action_pressed :: func Input.is_action_pressed(action: StringName, exact_match: bool = false) -> bool
Returns [code]true[/code] if you are pressing the action event.
If [param exact_match] is [code]false[/code], it ignores additional input modifiers for [InputEventKey] and [InputEventMouseButton] events, and the direction for [InputEventJoypadMotion] events.
[b]Note:[/b] Due to keyboard ghosting, [method is_action_pressed] may return [code]false[/code] even if one of the action's keys is pressed. See [url=https://docs.godotengine.org/en/4.7/tutorials/inputs/input_examples.html#keyboard-events]Input examples[/url] in the documentation for more information.

### action :: StringName

### exact_match :: bool

## is_anything_pressed :: func Input.is_anything_pressed() -> bool
Returns [code]true[/code] if any action, key, joypad button, or mouse button is being pressed. This will also return [code]true[/code] if any action is simulated via code by calling [method action_press].

## is_joy_button_pressed :: func Input.is_joy_button_pressed(device: int, button: int) -> bool
Returns [code]true[/code] if you are pressing the joypad button at index [param button].
[b]Note:[/b] If you want to check if a joypad button was just pressed, use Godot's input action system with [method is_action_just_pressed] or use the [method Node._input] method like this instead:
[codeblocks]
[gdscript]
func _input(event):
	if event is InputEventJoypadButton and event.is_pressed() and event.button_index == JOY_BUTTON_A:
		pass # Your code here.
[/gdscript]
[csharp]
public override void _Input(InputEvent @event)
{
	if (@event is InputEventJoypadButton eventButton && eventButton.Pressed && eventButton.ButtonIndex == JoyButton.A)
	{
		// Your code here.
	}
}
[/csharp]
[/codeblocks]

### device :: int

### button :: int

## is_joy_known :: func Input.is_joy_known(device: int) -> bool
Returns [code]true[/code] if the system knows the specified device. This means that it sets all button and axis indices. Unknown joypads are not expected to match these constants, but you can still retrieve events from them.

### device :: int

## is_joy_motion_sensors_calibrated :: func Input.is_joy_motion_sensors_calibrated(device: int) -> bool
Returns [code]true[/code] if the joypad's motion sensors have been calibrated.
See [method start_joy_motion_sensors_calibration] for an example on how to use joypad motion sensors and calibration in your games.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

## is_joy_motion_sensors_calibrating :: func Input.is_joy_motion_sensors_calibrating(device: int) -> bool
Returns [code]true[/code] if the joypad's motion sensors are currently being calibrated.
See [method start_joy_motion_sensors_calibration] for an example on how to use joypad motion sensors and calibration in your games.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

## is_joy_motion_sensors_enabled :: func Input.is_joy_motion_sensors_enabled(device: int) -> bool
Returns [code]true[/code] if the requested joypad has motion sensors (accelerometer and gyroscope) and they are currently enabled. See also [method set_joy_motion_sensors_enabled] and [method has_joy_motion_sensors].
See [method start_joy_motion_sensors_calibration] for an example on how to use joypad motion sensors and calibration in your games.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

## is_joy_vibrating :: func Input.is_joy_vibrating(device: int) -> bool
Returns [code]true[/code] if the joypad is still vibrating after a call to [method start_joy_vibration].
Unlike [method get_joy_vibration_strength] and [method get_joy_vibration_duration], this method returns [code]false[/code] after the joypad's vibration runs out.

### device :: int

## is_key_label_pressed :: func Input.is_key_label_pressed(keycode: int) -> bool
Returns [code]true[/code] if you are pressing the key with the [param keycode] printed on it. You can pass a [enum Key] constant or any Unicode character code.
[b]Note:[/b] If you want to check if a key was just pressed by using its label, use Godot's input action system with [method is_action_just_pressed] or use the [method Node._input] method like this instead:
[codeblocks]
[gdscript]
func _input(event):
	if event is InputEventKey and not event.is_echo() and event.is_pressed() and event.key_label == KEY_SPACE:
		pass # Your code here.
[/gdscript]
[csharp]
public override void _Input(InputEvent @event)
{
	if (@event is InputEventKey eventKey && !eventKey.IsEcho() && eventKey.Pressed && eventKey.KeyLabel == Key.Space)
	{
		// Your code here.
	}
}
[/csharp]
[/codeblocks]

### keycode :: int

## is_key_pressed :: func Input.is_key_pressed(keycode: int) -> bool
Returns [code]true[/code] if you are pressing the Latin key in the current keyboard layout. You can pass a [enum Key] constant.
[method is_key_pressed] is only recommended over [method is_physical_key_pressed] in non-game applications. This ensures that shortcut keys behave as expected depending on the user's keyboard layout, as keyboard shortcuts are generally dependent on the keyboard layout in non-game applications. If in doubt, use [method is_physical_key_pressed].
[b]Note:[/b] Due to keyboard ghosting, [method is_key_pressed] may return [code]false[/code] even if one of the action's keys is pressed. See [url=https://docs.godotengine.org/en/4.7/tutorials/inputs/input_examples.html#keyboard-events]Input examples[/url] in the documentation for more information.
[b]Note:[/b] If you want to check if a key was just pressed by using its keycode, use Godot's input action system with [method is_action_just_pressed] or use the [method Node._input] method like this instead:
[codeblocks]
[gdscript]
func _input(event):
	if event is InputEventKey and not event.is_echo() and event.is_pressed() and event.keycode == KEY_SPACE:
		pass # Your code here.
[/gdscript]
[csharp]
public override void _Input(InputEvent @event)
{
	if (@event is InputEventKey eventKey && !eventKey.IsEcho() && eventKey.Pressed && eventKey.Keycode == Key.Space)
	{
		// Your code here.
	}
}
[/csharp]
[/codeblocks]

### keycode :: int

## is_mouse_button_pressed :: func Input.is_mouse_button_pressed(button: int) -> bool
Returns [code]true[/code] if you are pressing the mouse button specified with [enum MouseButton].
[b]Note:[/b] If you want to check if a mouse button was just pressed, use Godot's input action system with [method is_action_just_pressed] or use the [method Node._input] method like this instead:
[codeblocks]
[gdscript]
func _input(event):
	if event is InputEventMouseButton and event.is_pressed() and event.button_index == MOUSE_BUTTON_LEFT:
		pass # Your code here.
[/gdscript]
[csharp]
public override void _Input(InputEvent @event)
{
	if (@event is InputEventMouseButton eventMouseButton && eventMouseButton.Pressed && eventMouseButton.ButtonIndex == MouseButton.Left)
	{
		// Your code here.
	}
}
[/csharp]
[/codeblocks]

### button :: int

## is_physical_key_pressed :: func Input.is_physical_key_pressed(keycode: int) -> bool
Returns [code]true[/code] if you are pressing the key in the physical location on the 101/102-key US QWERTY keyboard. You can pass a [enum Key] constant.
[method is_physical_key_pressed] is recommended over [method is_key_pressed] for in-game actions, as it will make [kbd]W[/kbd]/[kbd]A[/kbd]/[kbd]S[/kbd]/[kbd]D[/kbd] layouts work regardless of the user's keyboard layout. [method is_physical_key_pressed] will also ensure that the top row number keys work on any keyboard layout. If in doubt, use [method is_physical_key_pressed].
[b]Note:[/b] Due to keyboard ghosting, [method is_physical_key_pressed] may return [code]false[/code] even if one of the action's keys is pressed. See [url=https://docs.godotengine.org/en/4.7/tutorials/inputs/input_examples.html#keyboard-events]Input examples[/url] in the documentation for more information.
[b]Note:[/b] If you want to check if a key was just pressed by using its physical keycode, use Godot's input action system with [method is_action_just_pressed] or use the [method Node._input] method like this instead:
[codeblocks]
[gdscript]
func _input(event):
	if event is InputEventKey and not event.is_echo() and event.is_pressed() and event.physical_keycode == KEY_SPACE:
		pass # Your code here.
[/gdscript]
[csharp]
public override void _Input(InputEvent @event)
{
	if (@event is InputEventKey eventKey && !eventKey.IsEcho() && eventKey.Pressed && eventKey.PhysicalKeycode == Key.Space)
	{
		// Your code here.
	}
}
[/csharp]
[/codeblocks]

### keycode :: int

## parse_input_event :: func Input.parse_input_event(event: InputEvent) -> void
Feeds an [InputEvent] to the game. Can be used to artificially trigger input events from code. Also generates [method Node._input] calls.
[codeblocks]
[gdscript]
var cancel_event = InputEventAction.new()
cancel_event.action = "ui_cancel"
cancel_event.pressed = true
Input.parse_input_event(cancel_event)
[/gdscript]
[csharp]
var cancelEvent = new InputEventAction();
cancelEvent.Action = "ui_cancel";
cancelEvent.Pressed = true;
Input.ParseInputEvent(cancelEvent);
[/csharp]
[/codeblocks]
[b]Note:[/b] Calling this function has no influence on the operating system. So for example sending an [InputEventMouseMotion] will not move the OS mouse cursor to the specified position (use [method warp_mouse] instead) and sending [kbd]Alt/Cmd + Tab[/kbd] as [InputEventKey] won't toggle between active windows.

### event :: InputEvent

## remove_joy_mapping :: func Input.remove_joy_mapping(guid: String) -> void
Removes all mappings from the internal database that match the given GUID. All currently connected joypads that use this GUID will become unmapped.
On Android, Godot will map to an internal fallback mapping.

### guid :: String

## set_accelerometer :: func Input.set_accelerometer(value: Vector3) -> void
Sets the acceleration value of the accelerometer sensor. Can be used for debugging on devices without a hardware sensor, for example in an editor on a PC.
[b]Note:[/b] This value can be immediately overwritten by the hardware sensor value on Android and iOS.

### value :: Vector3

## set_custom_mouse_cursor :: func Input.set_custom_mouse_cursor(image: Resource, shape: int = 0, hotspot: Vector2 = Vector2(0, 0)) -> void
Sets a custom mouse cursor image, which is only visible inside the game window, for the given mouse [param shape]. The hotspot can also be specified. Passing [code]null[/code] to the image parameter resets to the system cursor.
[param image] can be either [Texture2D] or [Image] and its size must be lower than or equal to 256×256. To avoid rendering issues, sizes lower than or equal to 128×128 are recommended.
[param hotspot] must be within [param image]'s size.
[b]Note:[/b] [AnimatedTexture]s aren't supported as custom mouse cursors. If using an [AnimatedTexture], only the first frame will be displayed.
[b]Note:[/b] The [b]Lossless[/b], [b]Lossy[/b] or [b]Uncompressed[/b] compression modes are recommended. The [b]Video RAM[/b] compression mode can be used, but it will be decompressed on the CPU, which means loading times are slowed down and no memory is saved compared to lossless modes.
[b]Note:[/b] On the web platform, the maximum allowed cursor image size is 128×128. Cursor images larger than 32×32 will also only be displayed if the mouse cursor image is entirely located within the page for [url=https://chromestatus.com/feature/5825971391299584]security reasons[/url].

### image :: Resource

### shape :: int

### hotspot :: Vector2

## set_default_cursor_shape :: func Input.set_default_cursor_shape(shape: int = 0) -> void
Sets the default cursor shape to be used in the viewport instead of [constant CURSOR_ARROW].
[b]Note:[/b] If you want to change the default cursor shape for [Control]'s nodes, use [member Control.mouse_default_cursor_shape] instead.
[b]Note:[/b] This method generates an [InputEventMouseMotion] to update cursor immediately.

### shape :: int

## set_gravity :: func Input.set_gravity(value: Vector3) -> void
Sets the gravity value of the accelerometer sensor. Can be used for debugging on devices without a hardware sensor, for example in an editor on a PC.
[b]Note:[/b] This value can be immediately overwritten by the hardware sensor value on Android and iOS.

### value :: Vector3

## set_gyroscope :: func Input.set_gyroscope(value: Vector3) -> void
Sets the value of the rotation rate of the gyroscope sensor. Can be used for debugging on devices without a hardware sensor, for example in an editor on a PC.
[b]Note:[/b] This value can be immediately overwritten by the hardware sensor value on Android and iOS.

### value :: Vector3

## set_joy_light :: func Input.set_joy_light(device: int, color: Color) -> void
Sets the joypad's LED light, if available, to the specified color. See also [method has_joy_light].
[b]Note:[/b] There is no way to get the color of the light from a joypad. If you need to know the assigned color, store it separately.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

### color :: Color

## set_joy_motion_sensors_calibration :: func Input.set_joy_motion_sensors_calibration(device: int, calibration_info: Dictionary) -> void
Sets the specified joypad's calibration information. See also [method get_joy_motion_sensors_calibration].
See [method start_joy_motion_sensors_calibration] for an example on how to use joypad motion sensors and calibration in your games.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

### calibration_info :: Dictionary

## set_joy_motion_sensors_enabled :: func Input.set_joy_motion_sensors_enabled(device: int, enable: bool) -> void
Enables or disables the motion sensors (accelerometer and gyroscope), if available, on the specified joypad.
See [method start_joy_motion_sensors_calibration] for an example on how to use joypad motion sensors and calibration in your games.
It's recommended to disable the motion sensors when they're no longer being used, because otherwise it might drain the controller battery faster.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

### enable :: bool

## set_magnetometer :: func Input.set_magnetometer(value: Vector3) -> void
Sets the value of the magnetic field of the magnetometer sensor. Can be used for debugging on devices without a hardware sensor, for example in an editor on a PC.
[b]Note:[/b] This value can be immediately overwritten by the hardware sensor value on Android and iOS.

### value :: Vector3

## should_ignore_device :: func Input.should_ignore_device(vendor_id: int, product_id: int) -> bool
Queries whether an input device should be ignored or not. Devices can be ignored by setting the environment variable [code]SDL_GAMECONTROLLER_IGNORE_DEVICES[/code]. Read the [url=https://wiki.libsdl.org/SDL2]SDL documentation[/url] for more information.
[b]Note:[/b] Some 3rd party tools can contribute to the list of ignored devices. For example, [i]SteamInput[/i] creates virtual devices from physical devices for remapping purposes. To avoid handling the same input device twice, the original device is added to the ignore list.

### vendor_id :: int

### product_id :: int

## start_joy_motion_sensors_calibration :: func Input.start_joy_motion_sensors_calibration(device: int) -> void
Starts the process of calibrating the specified joypad's gyroscope, if it has one.
Once a joypad's gyroscope has been calibrated correctly (e.g. laying still on a table without being rotated), [method get_joy_gyroscope] will return values close or equal to [constant Vector3.ZERO] when the joypad is not being rotated.
Here's an example of how to use joypad gyroscope and gyroscope calibration in your games:
[codeblocks]
[gdscript]
const GYRO_SENSITIVITY = 10.0

func _ready():
	# In this example we only use the first connected joypad (id 0).
	if 0 not in Input.get_connected_joypads():
		return

	if not Input.has_joy_motion_sensors(0):
		return

	# We must enable the motion sensors before using them.
	Input.set_joy_motion_sensors_enabled(0, true)

	# (Tell the users here that they need to put their joypads on a flat surface and wait for confirmation.)

	# Start the calibration process.
	calibrate_motion()

func _process(delta):
	# Only move the object if the joypad motion sensors are calibrated.
	if Input.is_joy_motion_sensors_calibrated(0):
		move_object(delta)

func calibrate_motion():
	Input.start_joy_motion_sensors_calibration(0)

	# Wait for some time.
	await get_tree().create_timer(1.0).timeout

	Input.stop_joy_motion_sensors_calibration(0)
	# The joypad is now calibrated.

func move_object(delta):
	var node: Node3D = ... # Put your node here.

	var gyro := Input.get_joy_gyroscope(0)
	node.rotation.x -= -gyro.y * GYRO_SENSITIVITY * delta # Use rotation around the Y axis (yaw) here.
	node.rotation.y += -gyro.x * GYRO_SENSITIVITY * delta # Use rotation around the X axis (pitch) here.
[/gdscript]
[csharp]
private const float GyroSensitivity = 10.0;

public override void _Ready()
{
	// In this example we only use the first connected joypad (id 0).
	if (!Input.GetConnectedJoypads().Contains(0))
	{
		return;
	}

	if (!Input.HasJoyMotionSensors(0))
	{
		return;
	}

	// We must enable the accelerometer and the gyroscope before using them.
	Input.SetJoyMotionSensorsEnabled(0, true);

	// (Tell the users here that they need to put their joypads on a flat surface and wait for confirmation.)

	// Start the calibration process.
	CalibrateMotion();
}

public override void _Process(double delta)
{
	// Only move the object if the joypad motion sensors are calibrated.
	if (Input.IsJoyMotionSensorsCalibrated(0))
	{
		MoveObject(delta);
	}
}

private async Task CalibrateMotion()
{
	Input.StartJoyMotionSensorsCalibration(0);

	// Wait for some time.
	await ToSignal(GetTree().CreateTimer(1.0), SceneTreeTimer.SignalName.Timeout);

	Input.StopJoyMotionSensorsCalibration(0);
	// The joypad is now calibrated.
}

private void MoveObject(double delta)
{
	Node3D node = ... ; // Put your object here.
	Vector3 gyro = Input.GetJoyGyroscope(0);
	Vector3 rotation = node.Rotation;
	rotation.X -= -gyro.Y * GyroSensitivity * (float)delta; // Use rotation around the Y axis (yaw) here.
	rotation.Y += -gyro.X * GyroSensitivity * (float)delta; // Use rotation around the X axis (pitch) here.
	node.Rotation = rotation;
}
[/csharp]
[/codeblocks]
[b]Note:[/b] Accelerometer sensor doesn't usually require calibration.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

## start_joy_vibration :: func Input.start_joy_vibration(device: int, weak_magnitude: float, strong_magnitude: float, duration: float = 0) -> void
Starts to vibrate the joypad. See also [method has_joy_vibration] and [method is_joy_vibrating].
Joypads usually come with two rumble motors, a strong and a weak one.
[param weak_magnitude] is the strength of the weak motor (between [code]0.0[/code] and [code]1.0[/code]).
[param strong_magnitude] is the strength of the strong motor (between [code]0.0[/code] and [code]1.0[/code]).
[param duration] is the duration of the effect in seconds (a duration of [code]0.0[/code] will try to play the vibration as long as possible, which is about 65 seconds).
The vibration can be stopped early by calling [method stop_joy_vibration].
See also [method get_joy_vibration_strength] and [method get_joy_vibration_duration].
[b]Note:[/b] For macOS, vibration is only supported in macOS 11 and later. When connected via USB, vibration is only supported for major brand controllers (except Xbox One and Xbox Series X/S controllers) due to macOS limitations.

### device :: int

### weak_magnitude :: float

### strong_magnitude :: float

### duration :: float

## stop_joy_motion_sensors_calibration :: func Input.stop_joy_motion_sensors_calibration(device: int) -> void
Stops the calibration process of the specified joypad's motion sensors.
See [method start_joy_motion_sensors_calibration] for an example on how to use joypad motion sensors and calibration in your games.
[b]Note:[/b] This feature is only supported on Windows, Linux, macOS, and iOS.

### device :: int

## stop_joy_vibration :: func Input.stop_joy_vibration(device: int) -> void
Stops the vibration of the joypad started with [method start_joy_vibration].

### device :: int

## vibrate_handheld :: func Input.vibrate_handheld(duration_ms: int = 500, amplitude: float = -1.0) -> void
Vibrate the handheld device for the specified duration in milliseconds.
[param amplitude] is the strength of the vibration, as a value between [code]0.0[/code] and [code]1.0[/code]. If set to [code]-1.0[/code], the default vibration strength of the device is used.
[b]Note:[/b] This method is implemented on Android, iOS, and Web. It has no effect on other platforms.
[b]Note:[/b] For Android, [method vibrate_handheld] requires enabling the [code]VIBRATE[/code] permission in the export preset. Otherwise, [method vibrate_handheld] will have no effect.
[b]Note:[/b] For iOS, specifying the duration is only supported in iOS 13 and later.
[b]Note:[/b] For Web, the amplitude cannot be changed.
[b]Note:[/b] Some web browsers such as Safari and Firefox for Android do not support [method vibrate_handheld].
[b]Note:[/b] Device settings such as vibration on/off, "do not disturb" mode or specific haptic feedback on/off may prevent [method vibrate_handheld] effects.

### duration_ms :: int

### amplitude :: float

## warp_mouse :: func Input.warp_mouse(position: Vector2) -> void
Sets the mouse position to the specified vector, provided in pixels and relative to an origin at the upper left corner of the currently focused Window Manager game window.
Mouse position is clipped to the limits of the screen resolution, or to the limits of the game window if [enum MouseMode] is set to [constant MOUSE_MODE_CONFINED] or [constant MOUSE_MODE_CONFINED_HIDDEN].
[b]Note:[/b] [method warp_mouse] is only supported on Windows, macOS and Linux. It has no effect on Android, iOS and Web.

### position :: Vector2

## joy_connection_changed :: func Input.joy_connection_changed(device: int, connected: bool) -> void
Emitted when a joypad device has been connected or disconnected.

### device :: int

### connected :: bool
