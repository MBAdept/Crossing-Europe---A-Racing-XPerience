# Marshalls :: <Native> class Marshalls extends Object
Data transformation (marshaling) and encoding helpers.
Provides data transformation and encoding utility functions.

## base64_to_raw :: func Marshalls.base64_to_raw(base64_str: String) -> PackedByteArray
Returns a decoded [PackedByteArray] corresponding to the Base64-encoded string [param base64_str].

### base64_str :: String

## base64_to_utf8 :: func Marshalls.base64_to_utf8(base64_str: String) -> String
Returns a decoded string corresponding to the Base64-encoded string [param base64_str].

### base64_str :: String

## base64_to_variant :: func Marshalls.base64_to_variant(base64_str: String, allow_objects: bool = false) -> Variant
Returns a decoded [Variant] corresponding to the Base64-encoded string [param base64_str]. If [param allow_objects] is [code]true[/code], decoding objects is allowed.
Internally, this uses the same decoding mechanism as the [method @GlobalScope.bytes_to_var] method.
[b]Warning:[/b] Deserialized objects can contain code which gets executed. Do not use this option if the serialized object comes from untrusted sources to avoid potential security threats such as remote code execution.

### base64_str :: String

### allow_objects :: bool

## raw_to_base64 :: func Marshalls.raw_to_base64(array: PackedByteArray) -> String
Returns a Base64-encoded string of a given [PackedByteArray].

### array :: PackedByteArray

## utf8_to_base64 :: func Marshalls.utf8_to_base64(utf8_str: String) -> String
Returns a Base64-encoded string of the UTF-8 string [param utf8_str].

### utf8_str :: String

## variant_to_base64 :: func Marshalls.variant_to_base64(variant: Variant, full_objects: bool = false) -> String
Returns a Base64-encoded string of the [Variant] [param variant]. If [param full_objects] is [code]true[/code], encoding objects is allowed (and can potentially include code).
Internally, this uses the same encoding mechanism as the [method @GlobalScope.var_to_bytes] method.

### variant :: Variant

### full_objects :: bool
