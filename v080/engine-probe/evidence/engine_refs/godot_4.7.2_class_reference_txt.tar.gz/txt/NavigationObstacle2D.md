# NavigationObstacle2D :: <Native> class NavigationObstacle2D extends Node2D
2D obstacle used to affect navigation mesh baking or constrain velocities of avoidance controlled agents.
An obstacle needs a navigation map and outline [member vertices] defined to work correctly. The outlines can not cross or overlap.
Obstacles can be included in the navigation mesh baking process when [member affect_navigation_mesh] is enabled. They do not add walkable geometry, instead their role is to discard other source geometry inside the shape. This can be used to prevent navigation mesh from appearing in unwanted places. If [member carve_navigation_mesh] is enabled the baked shape will not be affected by offsets of the navigation mesh baking, e.g. the agent radius.
With [member avoidance_enabled] the obstacle can constrain the avoidance velocities of avoidance using agents. If the obstacle's vertices are wound in clockwise order, avoidance agents will be pushed in by the obstacle, otherwise, avoidance agents will be pushed out. Obstacles using vertices and avoidance can warp to a new position but should not be moved every single frame as each change requires a rebuild of the avoidance map.

## affect_navigation_mesh :: var NavigationObstacle2D.affect_navigation_mesh: bool
If enabled and parsed in a navigation mesh baking process the obstacle will discard source geometry inside its [member vertices] defined shape.

## avoidance_enabled :: var NavigationObstacle2D.avoidance_enabled: bool
If [code]true[/code] the obstacle affects avoidance using agents.

## avoidance_layers :: var NavigationObstacle2D.avoidance_layers: int
A bitfield determining the avoidance layers for this obstacle. Agents with a matching bit on the their avoidance mask will avoid this obstacle.

## carve_navigation_mesh :: var NavigationObstacle2D.carve_navigation_mesh: bool
If enabled the obstacle vertices will carve into the baked navigation mesh with the shape unaffected by additional offsets (e.g. agent radius).
It will still be affected by further postprocessing of the baking process, like edge and polygon simplification.
Requires [member affect_navigation_mesh] to be enabled.

## radius :: var NavigationObstacle2D.radius: float
Sets the avoidance radius for the obstacle.

## velocity :: var NavigationObstacle2D.velocity: Vector2
Sets the wanted velocity for the obstacle so other agent's can better predict the obstacle if it is moved with a velocity regularly (every frame) instead of warped to a new position. Does only affect avoidance for the obstacles [member radius]. Does nothing for the obstacles static vertices.

## vertices :: var NavigationObstacle2D.vertices: PackedVector2Array
The outline vertices of the obstacle. If the vertices are winded in clockwise order agents will be pushed in by the obstacle, else they will be pushed out. Outlines can not be crossed or overlap. Should the vertices using obstacle be warped to a new position agent's can not predict this movement and may get trapped inside the obstacle.

## get_avoidance_layer_value :: func NavigationObstacle2D.get_avoidance_layer_value(layer_number: int) -> bool
Returns whether or not the specified layer of the [member avoidance_layers] bitmask is enabled, given a [param layer_number] between 1 and 32.

### layer_number :: int

## get_navigation_map :: func NavigationObstacle2D.get_navigation_map() -> RID
Returns the [RID] of the navigation map for this NavigationObstacle node. This function returns always the map set on the NavigationObstacle node and not the map of the abstract obstacle on the NavigationServer. If the obstacle map is changed directly with the NavigationServer API the NavigationObstacle node will not be aware of the map change. Use [method set_navigation_map] to change the navigation map for the NavigationObstacle and also update the obstacle on the NavigationServer.

## get_rid :: func NavigationObstacle2D.get_rid() -> RID
Returns the [RID] of this obstacle on the [NavigationServer2D].

## set_avoidance_layer_value :: func NavigationObstacle2D.set_avoidance_layer_value(layer_number: int, value: bool) -> void
Based on [param value], enables or disables the specified layer in the [member avoidance_layers] bitmask, given a [param layer_number] between 1 and 32.

### layer_number :: int

### value :: bool

## set_navigation_map :: func NavigationObstacle2D.set_navigation_map(navigation_map: RID) -> void
Sets the [RID] of the navigation map this NavigationObstacle node should use and also updates the [code]obstacle[/code] on the NavigationServer.

### navigation_map :: RID
