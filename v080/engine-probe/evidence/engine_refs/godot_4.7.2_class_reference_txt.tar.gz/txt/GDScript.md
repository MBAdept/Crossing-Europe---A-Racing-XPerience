# GDScript :: <Native> class GDScript extends Script
A script implemented in the GDScript programming language.
A script implemented in the GDScript programming language, saved with the [code].gd[/code] extension. The script extends the functionality of all objects that instantiate it.
Calling [method new] creates a new instance of the script. [method Object.set_script] extends an existing object, if that object's class matches one of the script's base classes.
If you are looking for GDScript's built-in functions, see [@GDScript] instead.

## new :: func GDScript.new(...) -> Variant
Returns a new instance of the script.
[codeblock]
var MyClass = load("myclass.gd")
var instance = MyClass.new()
print(instance.get_script() == MyClass) # Prints true
[/codeblock]
