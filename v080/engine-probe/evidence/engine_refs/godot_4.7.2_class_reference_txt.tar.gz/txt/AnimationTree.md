# AnimationTree :: <Native> class AnimationTree extends AnimationMixer
A node used for advanced animation transitions in an [AnimationPlayer].
A node used for advanced animation transitions in an [AnimationPlayer].
[b]Note:[/b] When linked with an [AnimationPlayer], several properties and methods of the corresponding [AnimationPlayer] will not function as expected. Playback and transitions should be handled using only the [AnimationTree] and its constituent [AnimationNode](s). The [AnimationPlayer] node should be used solely for adding, deleting, and editing animations.

## ANIMATION_PROCESS_PHYSICS :: const AnimationTree.ANIMATION_PROCESS_PHYSICS: AnimationProcessCallback = 0

## ANIMATION_PROCESS_IDLE :: const AnimationTree.ANIMATION_PROCESS_IDLE: AnimationProcessCallback = 1

## ANIMATION_PROCESS_MANUAL :: const AnimationTree.ANIMATION_PROCESS_MANUAL: AnimationProcessCallback = 2

## advance_expression_base_node :: var AnimationTree.advance_expression_base_node: NodePath
The path to the [Node] used to evaluate the [AnimationNode] [Expression] if one is not explicitly specified internally.

## anim_player :: var AnimationTree.anim_player: NodePath
The path to the [AnimationPlayer] used for animating.

## callback_mode_discrete :: var AnimationTree.callback_mode_discrete: AnimationMixer.AnimationCallbackModeDiscrete

## deterministic :: var AnimationTree.deterministic: bool

## tree_root :: var AnimationTree.tree_root: AnimationRootNode
The root animation node of this [AnimationTree]. See [AnimationRootNode].

## get_process_callback :: func AnimationTree.get_process_callback() -> int
Returns the process notification in which to update animations.

## set_process_callback :: func AnimationTree.set_process_callback(mode: int) -> void
Sets the process notification in which to update animations.

### mode :: int

## animation_player_changed :: func AnimationTree.animation_player_changed() -> void
Emitted when the [member anim_player] is changed.
