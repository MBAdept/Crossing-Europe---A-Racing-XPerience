# OpenXRIPBinding :: <Native> class OpenXRIPBinding extends Resource
Defines a binding between an [OpenXRAction] and an XR input or output.
This binding resource binds an [OpenXRAction] to an input or output. As most controllers have left hand and right versions that are handled by the same interaction profile we can specify multiple bindings. For instance an action "Fire" could be bound to both "/user/hand/left/input/trigger" and "/user/hand/right/input/trigger". This would require two binding entries.

## action :: var OpenXRIPBinding.action: OpenXRAction
[OpenXRAction] that is bound to [member binding_path].

## binding_modifiers :: var OpenXRIPBinding.binding_modifiers: Array
Binding modifiers for this binding.

## binding_path :: var OpenXRIPBinding.binding_path: String
Binding path that defines the input or output bound to [member action].
[b]Note:[/b] Binding paths are suggestions, an XR runtime may choose to bind the action to a different input or output emulating this input or output.

## paths :: var OpenXRIPBinding.paths: PackedStringArray
Paths that define the inputs or outputs bound on the device.

## add_path :: func OpenXRIPBinding.add_path(path: String) -> void
Add an input/output path to this binding.

### path :: String

## get_binding_modifier :: func OpenXRIPBinding.get_binding_modifier(index: int) -> OpenXRActionBindingModifier
Get the [OpenXRBindingModifier] at this index.

### index :: int

## get_binding_modifier_count :: func OpenXRIPBinding.get_binding_modifier_count() -> int
Get the number of binding modifiers for this binding.

## get_path_count :: func OpenXRIPBinding.get_path_count() -> int
Get the number of input/output paths in this binding.

## has_path :: func OpenXRIPBinding.has_path(path: String) -> bool
Returns [code]true[/code] if this input/output path is part of this binding.

### path :: String

## remove_path :: func OpenXRIPBinding.remove_path(path: String) -> void
Removes this input/output path from this binding.

### path :: String
