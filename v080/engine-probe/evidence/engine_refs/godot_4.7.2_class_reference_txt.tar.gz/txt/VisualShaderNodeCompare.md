# VisualShaderNodeCompare :: <Native> class VisualShaderNodeCompare extends VisualShaderNode
A comparison function for common types within the visual shader graph.
Compares [code]a[/code] and [code]b[/code] of [member type] by [member function]. Returns a boolean scalar. Translates to [code]if[/code] instruction in shader code.

## CTYPE_SCALAR :: const VisualShaderNodeCompare.CTYPE_SCALAR: ComparisonType = 0
A floating-point scalar.

## CTYPE_SCALAR_INT :: const VisualShaderNodeCompare.CTYPE_SCALAR_INT: ComparisonType = 1
An integer scalar.

## CTYPE_SCALAR_UINT :: const VisualShaderNodeCompare.CTYPE_SCALAR_UINT: ComparisonType = 2
An unsigned integer scalar.

## CTYPE_VECTOR_2D :: const VisualShaderNodeCompare.CTYPE_VECTOR_2D: ComparisonType = 3
A 2D vector type.

## CTYPE_VECTOR_3D :: const VisualShaderNodeCompare.CTYPE_VECTOR_3D: ComparisonType = 4
A 3D vector type.

## CTYPE_VECTOR_4D :: const VisualShaderNodeCompare.CTYPE_VECTOR_4D: ComparisonType = 5
A 4D vector type.

## CTYPE_BOOLEAN :: const VisualShaderNodeCompare.CTYPE_BOOLEAN: ComparisonType = 6
A boolean type.

## CTYPE_TRANSFORM :: const VisualShaderNodeCompare.CTYPE_TRANSFORM: ComparisonType = 7
A transform ([code]mat4[/code]) type.

## CTYPE_MAX :: const VisualShaderNodeCompare.CTYPE_MAX: ComparisonType = 8
Represents the size of the [enum ComparisonType] enum.

## FUNC_EQUAL :: const VisualShaderNodeCompare.FUNC_EQUAL: Function = 0
Comparison for equality ([code]a == b[/code]).

## FUNC_NOT_EQUAL :: const VisualShaderNodeCompare.FUNC_NOT_EQUAL: Function = 1
Comparison for inequality ([code]a != b[/code]).

## FUNC_GREATER_THAN :: const VisualShaderNodeCompare.FUNC_GREATER_THAN: Function = 2
Comparison for greater than ([code]a > b[/code]). Cannot be used if [member type] set to [constant CTYPE_BOOLEAN] or [constant CTYPE_TRANSFORM].

## FUNC_GREATER_THAN_EQUAL :: const VisualShaderNodeCompare.FUNC_GREATER_THAN_EQUAL: Function = 3
Comparison for greater than or equal ([code]a >= b[/code]). Cannot be used if [member type] set to [constant CTYPE_BOOLEAN] or [constant CTYPE_TRANSFORM].

## FUNC_LESS_THAN :: const VisualShaderNodeCompare.FUNC_LESS_THAN: Function = 4
Comparison for less than ([code]a < b[/code]). Cannot be used if [member type] set to [constant CTYPE_BOOLEAN] or [constant CTYPE_TRANSFORM].

## FUNC_LESS_THAN_EQUAL :: const VisualShaderNodeCompare.FUNC_LESS_THAN_EQUAL: Function = 5
Comparison for less than or equal ([code]a <= b[/code]). Cannot be used if [member type] set to [constant CTYPE_BOOLEAN] or [constant CTYPE_TRANSFORM].

## FUNC_MAX :: const VisualShaderNodeCompare.FUNC_MAX: Function = 6
Represents the size of the [enum Function] enum.

## COND_ALL :: const VisualShaderNodeCompare.COND_ALL: Condition = 0
The result will be [code]true[/code] if all components in the vector satisfy the comparison condition.

## COND_ANY :: const VisualShaderNodeCompare.COND_ANY: Condition = 1
The result will be [code]true[/code] if any component in the vector satisfies the comparison condition.

## COND_MAX :: const VisualShaderNodeCompare.COND_MAX: Condition = 2
Represents the size of the [enum Condition] enum.

## condition :: var VisualShaderNodeCompare.condition: VisualShaderNodeCompare.Condition
Extra condition which is applied if [member type] is set to [constant CTYPE_VECTOR_3D].

## function :: var VisualShaderNodeCompare.function: VisualShaderNodeCompare.Function
A comparison function.

## type :: var VisualShaderNodeCompare.type: VisualShaderNodeCompare.ComparisonType
The type to be used in the comparison.
