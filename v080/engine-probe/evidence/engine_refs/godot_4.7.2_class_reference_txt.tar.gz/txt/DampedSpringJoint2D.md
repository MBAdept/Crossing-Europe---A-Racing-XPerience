# DampedSpringJoint2D :: <Native> class DampedSpringJoint2D extends Joint2D
A physics joint that connects two 2D physics bodies with a spring-like force.
A physics joint that connects two 2D physics bodies with a spring-like force. This behaves like a spring that always wants to stretch to a given length.

## damping :: var DampedSpringJoint2D.damping: float
The spring joint's damping ratio. A value between [code]0[/code] and [code]1[/code]. When the two bodies move into different directions the system tries to align them to the spring axis again. A high [member damping] value forces the attached bodies to align faster.

## length :: var DampedSpringJoint2D.length: float
The spring joint's maximum length. The two attached bodies cannot stretch it past this value.

## rest_length :: var DampedSpringJoint2D.rest_length: float
When the bodies attached to the spring joint move they stretch or squash it. The joint always tries to resize towards this length.

## stiffness :: var DampedSpringJoint2D.stiffness: float
The higher the value, the less the bodies attached to the joint will deform it. The joint applies an opposing force to the bodies, the product of the stiffness multiplied by the size difference from its resting length.
