# KinematicCollision3D :: <Native> class KinematicCollision3D extends RefCounted
Holds collision data from the movement of a [PhysicsBody3D].
Holds collision data from the movement of a [PhysicsBody3D], usually from [method PhysicsBody3D.move_and_collide]. When a [PhysicsBody3D] is moved, it stops if it detects a collision with another body. If a collision is detected, a [KinematicCollision3D] object is returned.
The collision data includes the colliding object, the remaining motion, and the collision position. This data can be used to determine a custom response to the collision.

## get_angle :: func KinematicCollision3D.get_angle(collision_index: int = 0, up_direction: Vector3 = Vector3(0, 1, 0)) -> float
Returns the collision angle according to [param up_direction], which is [constant Vector3.UP] by default. This value is always positive.

### collision_index :: int

### up_direction :: Vector3

## get_collider :: func KinematicCollision3D.get_collider(collision_index: int = 0) -> Object
Returns the colliding body's attached [Object] given a collision index (the deepest collision by default).

### collision_index :: int

## get_collider_id :: func KinematicCollision3D.get_collider_id(collision_index: int = 0) -> int
Returns the unique instance ID of the colliding body's attached [Object] given a collision index (the deepest collision by default). See [method Object.get_instance_id].

### collision_index :: int

## get_collider_rid :: func KinematicCollision3D.get_collider_rid(collision_index: int = 0) -> RID
Returns the colliding body's [RID] used by the [PhysicsServer3D] given a collision index (the deepest collision by default).

### collision_index :: int

## get_collider_shape :: func KinematicCollision3D.get_collider_shape(collision_index: int = 0) -> Object
Returns the colliding body's shape given a collision index (the deepest collision by default).

### collision_index :: int

## get_collider_shape_index :: func KinematicCollision3D.get_collider_shape_index(collision_index: int = 0) -> int
Returns the colliding body's shape index given a collision index (the deepest collision by default). See [CollisionObject3D].

### collision_index :: int

## get_collider_velocity :: func KinematicCollision3D.get_collider_velocity(collision_index: int = 0) -> Vector3
Returns the colliding body's velocity given a collision index (the deepest collision by default).

### collision_index :: int

## get_collision_count :: func KinematicCollision3D.get_collision_count() -> int
Returns the number of detected collisions.

## get_depth :: func KinematicCollision3D.get_depth() -> float
Returns the colliding body's length of overlap along the collision normal.

## get_local_shape :: func KinematicCollision3D.get_local_shape(collision_index: int = 0) -> Object
Returns the moving object's colliding shape given a collision index (the deepest collision by default).

### collision_index :: int

## get_normal :: func KinematicCollision3D.get_normal(collision_index: int = 0) -> Vector3
Returns the colliding body's shape's normal at the point of collision given a collision index (the deepest collision by default).

### collision_index :: int

## get_position :: func KinematicCollision3D.get_position(collision_index: int = 0) -> Vector3
Returns the point of collision in global coordinates given a collision index (the deepest collision by default).

### collision_index :: int

## get_remainder :: func KinematicCollision3D.get_remainder() -> Vector3
Returns the moving object's remaining movement vector.

## get_travel :: func KinematicCollision3D.get_travel() -> Vector3
Returns the moving object's travel before collision.
