# FABRIK3D :: <Native> class FABRIK3D extends IterateIK3D
Position based forward and backward reaching inverse kinematics solver.
[FABRIK3D] is position based IK, allowing precise and accurate tracking of targets. It's ideal for simple chains without limitations.
The resulting twist around the forward vector will always be kept from the previous pose.
[b]Note:[/b] When the target is close to the root, it tends to produce zig-zag patterns, resulting in unnatural visual movement.
