# TextMesh :: <Native> class TextMesh extends PrimitiveMesh
Generate a [PrimitiveMesh] from the text.
Generate a [PrimitiveMesh] from the text.
TextMesh can be generated only when using dynamic fonts with vector glyph contours. Bitmap fonts (including bitmap data in the TrueType/OpenType containers, like color emoji fonts) are not supported.
The UV layout is arranged in 4 horizontal strips, top to bottom: 40% of the height for the front face, 40% for the back face, 10% for the outer edges and 10% for the inner edges.

## autowrap_mode :: var TextMesh.autowrap_mode: TextServer.AutowrapMode
If set to something other than [constant TextServer.AUTOWRAP_OFF], the text gets wrapped inside the node's bounding rectangle. If you resize the node, it will change its height automatically to show all the text.

## curve_step :: var TextMesh.curve_step: float
Step (in pixels) used to approximate Bézier curves. Lower values result in smoother curves, but is slower to generate and render. Consider adjusting this according to the font size and the typical viewing distance.
[b]Note:[/b] Changing this property will regenerate the mesh, which is a slow operation, especially with large font sizes and long texts.

## depth :: var TextMesh.depth: float
Depths of the mesh, if set to [code]0.0[/code] only front surface, is generated, and UV layout is changed to use full texture for the front face only.

## font :: var TextMesh.font: Font
Font configuration used to display text.

## font_size :: var TextMesh.font_size: int
Font size of the [TextMesh]'s text. This property works in tandem with [member pixel_size]. Higher values will result in a more detailed font, regardless of [member curve_step] and [member pixel_size]. Consider keeping this value below 63 (inclusive) for good performance, and adjust [member pixel_size] as needed to enlarge text.
[b]Note:[/b] Changing this property will regenerate the mesh, which is a slow operation, especially with large font sizes and long texts. To change the text's size in real-time efficiently, change the node's [member Node3D.scale] instead.

## horizontal_alignment :: var TextMesh.horizontal_alignment: HorizontalAlignment
Controls the text's horizontal alignment. Supports left, center, right, and fill (also known as justify).

## justification_flags :: var TextMesh.justification_flags: TextServer.JustificationFlag
Line fill alignment rules.

## language :: var TextMesh.language: String
Language code used for line-breaking and text shaping algorithms. If left empty, the current locale is used instead.

## line_spacing :: var TextMesh.line_spacing: float
Additional vertical spacing between lines (in pixels), spacing is added to line descent. This value can be negative.

## offset :: var TextMesh.offset: Vector2
The text drawing offset (in pixels).
[b]Note:[/b] Changing this property will regenerate the mesh, which is a slow operation. To change the text's position in real-time efficiently, change the node's [member Node3D.position] instead.

## pixel_size :: var TextMesh.pixel_size: float
The size of one pixel's width on the text to scale it in 3D. This property works in tandem with [member font_size].
[b]Note:[/b] Changing this property will regenerate the mesh, which is a slow operation, especially with large font sizes and long texts. To change the text's size in real-time efficiently, change the node's [member Node3D.scale] instead.

## structured_text_bidi_override :: var TextMesh.structured_text_bidi_override: TextServer.StructuredTextParser
Set BiDi algorithm override for the structured text.

## structured_text_bidi_override_options :: var TextMesh.structured_text_bidi_override_options: Array
Set additional options for BiDi override.

## text :: var TextMesh.text: String
The text to generate mesh from.
[b]Note:[/b] Due to being a [Resource], it doesn't follow the rules of [member Node.auto_translate_mode]. If disabling translation is desired, it should be done manually with [method Object.set_message_translation].

## text_direction :: var TextMesh.text_direction: TextServer.Direction
Base text writing direction.

## uppercase :: var TextMesh.uppercase: bool
If [code]true[/code], all the text displays as UPPERCASE.

## vertical_alignment :: var TextMesh.vertical_alignment: VerticalAlignment
Controls the text's vertical alignment. Supports top, center, and bottom.

## width :: var TextMesh.width: float
Text width (in pixels), used for fill alignment.
