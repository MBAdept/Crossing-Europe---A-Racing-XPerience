# MenuButton :: <Native> class MenuButton extends Button
A button that brings up a [PopupMenu] when clicked.
A button that brings up a [PopupMenu] when clicked. To create new items inside this [PopupMenu], use [code]get_popup().add_item("My Item Name")[/code]. You can also create them directly from Godot editor's inspector.
See also [BaseButton] which contains common properties and methods associated with this node.

## action_mode :: var MenuButton.action_mode: BaseButton.ActionMode

## flat :: var MenuButton.flat: bool

## focus_mode :: var MenuButton.focus_mode: Control.FocusMode

## item_count :: var MenuButton.item_count: int
The number of items currently in the list.

## popup/item_{index}/checkable :: var MenuButton.popup/item_{index}/checkable: int
The checkable item type of the item at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. item_count - 1[/code] range.

## popup/item_{index}/checked :: var MenuButton.popup/item_{index}/checked: bool
If [code]true[/code], the item at [code]index[/code] is checked.
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. item_count - 1[/code] range.

## popup/item_{index}/disabled :: var MenuButton.popup/item_{index}/disabled: bool
If [code]true[/code], the item at [code]index[/code] is disabled.
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. item_count - 1[/code] range.

## popup/item_{index}/icon :: var MenuButton.popup/item_{index}/icon: Texture2D
The icon of the item at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. item_count - 1[/code] range.

## popup/item_{index}/id :: var MenuButton.popup/item_{index}/id: int
The ID of the item at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. item_count - 1[/code] range.

## popup/item_{index}/separator :: var MenuButton.popup/item_{index}/separator: bool
If [code]true[/code], the item at [code]index[/code] is a separator.
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. item_count - 1[/code] range.

## popup/item_{index}/text :: var MenuButton.popup/item_{index}/text: String
The text of the item at [code]index[/code].
[b]Note:[/b] [code]index[/code] is a value in the [code]0 .. item_count - 1[/code] range.

## switch_on_hover :: var MenuButton.switch_on_hover: bool
If [code]true[/code], when the cursor hovers above another [MenuButton] within the same parent which also has [member switch_on_hover] enabled, it will close the current [MenuButton] and open the other one.

## toggle_mode :: var MenuButton.toggle_mode: bool

## get_popup :: func MenuButton.get_popup() -> PopupMenu
Returns the [PopupMenu] contained in this button.
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member Window.visible] property.

## set_disable_shortcuts :: func MenuButton.set_disable_shortcuts(disabled: bool) -> void
If [code]true[/code], shortcuts are disabled and cannot be used to trigger the button.

### disabled :: bool

## show_popup :: func MenuButton.show_popup() -> void
Adjusts popup position and sizing for the [MenuButton], then shows the [PopupMenu]. Prefer this over using [code]get_popup().popup()[/code].

## about_to_popup :: func MenuButton.about_to_popup() -> void
Emitted when the [PopupMenu] of this MenuButton is about to show.
