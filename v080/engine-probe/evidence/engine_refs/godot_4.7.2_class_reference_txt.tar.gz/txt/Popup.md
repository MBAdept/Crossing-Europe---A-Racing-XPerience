# Popup :: <Native> class Popup extends Window
Base class for contextual windows and panels with fixed position.
[Popup] is a base class for contextual windows and panels with fixed position. It's a modal by default (see [member Window.popup_window]) and provides methods for implementing custom popup behavior.
[b]Note:[/b] [Popup] is invisible by default. To make it visible, call one of the [code]popup_*[/code] methods from [Window] on the node, such as [method Window.popup_centered_clamped].

## borderless :: var Popup.borderless: bool

## maximize_disabled :: var Popup.maximize_disabled: bool

## minimize_disabled :: var Popup.minimize_disabled: bool

## popup_window :: var Popup.popup_window: bool

## popup_wm_hint :: var Popup.popup_wm_hint: bool

## transient :: var Popup.transient: bool

## unresizable :: var Popup.unresizable: bool

## visible :: var Popup.visible: bool

## wrap_controls :: var Popup.wrap_controls: bool

## popup_hide :: func Popup.popup_hide() -> void
Emitted when the popup is hidden.
