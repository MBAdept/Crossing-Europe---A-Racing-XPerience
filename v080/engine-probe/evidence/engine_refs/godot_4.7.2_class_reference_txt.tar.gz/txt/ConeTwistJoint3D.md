# ConeTwistJoint3D :: <Native> class ConeTwistJoint3D extends Joint3D
A physics joint that connects two 3D physics bodies in a way that simulates a ball-and-socket joint.
A physics joint that connects two 3D physics bodies in a way that simulates a ball-and-socket joint. The twist axis is initiated as the X axis of the [ConeTwistJoint3D]. Once the physics bodies swing, the twist axis is calculated as the middle of the X axes of the joint in the local space of the two physics bodies. Useful for limbs like shoulders and hips, lamps hanging off a ceiling, etc.

## PARAM_SWING_SPAN :: const ConeTwistJoint3D.PARAM_SWING_SPAN: Param = 0
Swing is rotation from side to side, around the axis perpendicular to the twist axis.
The swing span defines, how much rotation will not get corrected along the swing axis.
Could be defined as looseness in the [ConeTwistJoint3D].
If below 0.05, this behavior is locked.

## PARAM_TWIST_SPAN :: const ConeTwistJoint3D.PARAM_TWIST_SPAN: Param = 1
Twist is the rotation around the twist axis, this value defined how far the joint can twist.
Twist is locked if below 0.05.

## PARAM_BIAS :: const ConeTwistJoint3D.PARAM_BIAS: Param = 2
The speed with which the swing or twist will take place.
The higher, the faster.

## PARAM_SOFTNESS :: const ConeTwistJoint3D.PARAM_SOFTNESS: Param = 3
The ease with which the joint starts to twist. If it's too low, it takes more force to start twisting the joint.

## PARAM_RELAXATION :: const ConeTwistJoint3D.PARAM_RELAXATION: Param = 4
Defines, how fast the swing- and twist-speed-difference on both sides gets synced.

## PARAM_MAX :: const ConeTwistJoint3D.PARAM_MAX: Param = 5
Represents the size of the [enum Param] enum.

## bias :: var ConeTwistJoint3D.bias: float
The speed with which the swing or twist will take place.
The higher, the faster.

## relaxation :: var ConeTwistJoint3D.relaxation: float
Defines, how fast the swing- and twist-speed-difference on both sides gets synced.

## softness :: var ConeTwistJoint3D.softness: float
The ease with which the joint starts to twist. If it's too low, it takes more force to start twisting the joint.

## swing_span :: var ConeTwistJoint3D.swing_span: float
Swing is rotation from side to side, around the axis perpendicular to the twist axis.
The swing span defines, how much rotation will not get corrected along the swing axis.
Could be defined as looseness in the [ConeTwistJoint3D].
If below 0.05, this behavior is locked.

## twist_span :: var ConeTwistJoint3D.twist_span: float
Twist is the rotation around the twist axis, this value defined how far the joint can twist.
Twist is locked if below 0.05.

## get_param :: func ConeTwistJoint3D.get_param(param: int) -> float
Returns the value of the specified parameter.

### param :: int

## set_param :: func ConeTwistJoint3D.set_param(param: int, value: float) -> void
Sets the value of the specified parameter.

### param :: int

### value :: float
