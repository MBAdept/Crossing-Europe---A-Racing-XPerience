# AwaitTweener :: <Native> class AwaitTweener extends Tweener
Awaits a specified signal.
[AwaitTweener] is used to await a specified signal, allowing asynchronous steps in [Tween] animation. See [method Tween.tween_await] for more usage information.
The [signal Tweener.finished] signal is emitted when either the awaited signal is received, when timeout is reached, or when the target object is freed.

## set_timeout :: func AwaitTweener.set_timeout(timeout: float) -> AwaitTweener
Sets the maximum time an [AwaitTweener] can wait for the signal. Can be used as a safeguard for signals that may never be emitted. If not specified, the tweener will wait indefinitely.

### timeout :: float
