# VisualShaderNodeSmoothStep :: <Native> class VisualShaderNodeSmoothStep extends VisualShaderNode
Calculates a SmoothStep function within the visual shader graph.
Translates to [code]smoothstep(edge0, edge1, x)[/code] in the shader language.
Returns [code]0.0[/code] if [code]x[/code] is smaller than [code]edge0[/code] and [code]1.0[/code] if [code]x[/code] is larger than [code]edge1[/code]. Otherwise, the return value is interpolated between [code]0.0[/code] and [code]1.0[/code] using Hermite polynomials.

## OP_TYPE_SCALAR :: const VisualShaderNodeSmoothStep.OP_TYPE_SCALAR: OpType = 0
A floating-point scalar type.

## OP_TYPE_VECTOR_2D :: const VisualShaderNodeSmoothStep.OP_TYPE_VECTOR_2D: OpType = 1
A 2D vector type.

## OP_TYPE_VECTOR_2D_SCALAR :: const VisualShaderNodeSmoothStep.OP_TYPE_VECTOR_2D_SCALAR: OpType = 2
The [code]x[/code] port uses a 2D vector type. The first two ports use a floating-point scalar type.

## OP_TYPE_VECTOR_3D :: const VisualShaderNodeSmoothStep.OP_TYPE_VECTOR_3D: OpType = 3
A 3D vector type.

## OP_TYPE_VECTOR_3D_SCALAR :: const VisualShaderNodeSmoothStep.OP_TYPE_VECTOR_3D_SCALAR: OpType = 4
The [code]x[/code] port uses a 3D vector type. The first two ports use a floating-point scalar type.

## OP_TYPE_VECTOR_4D :: const VisualShaderNodeSmoothStep.OP_TYPE_VECTOR_4D: OpType = 5
A 4D vector type.

## OP_TYPE_VECTOR_4D_SCALAR :: const VisualShaderNodeSmoothStep.OP_TYPE_VECTOR_4D_SCALAR: OpType = 6
The [code]a[/code] and [code]b[/code] ports use a 4D vector type. The [code]weight[/code] port uses a scalar type.

## OP_TYPE_MAX :: const VisualShaderNodeSmoothStep.OP_TYPE_MAX: OpType = 7
Represents the size of the [enum OpType] enum.

## op_type :: var VisualShaderNodeSmoothStep.op_type: VisualShaderNodeSmoothStep.OpType
A type of operands and returned value.
