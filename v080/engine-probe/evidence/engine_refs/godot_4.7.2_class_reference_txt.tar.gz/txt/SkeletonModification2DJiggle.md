# SkeletonModification2DJiggle :: <Native> class SkeletonModification2DJiggle extends SkeletonModification2D
A modification that jiggles [Bone2D] nodes as they move towards a target.
This modification moves a series of bones, typically called a bone chain, towards a target. What makes this modification special is that it calculates the velocity and acceleration for each bone in the bone chain, and runs a very light physics-like calculation using the inputted values. This allows the bones to overshoot the target and "jiggle" around. It can be configured to act more like a spring, or sway around like cloth might.
This modification is useful for adding additional motion to things like hair, the edges of clothing, and more. It has several settings to that allow control over how the joint moves when the target moves.
[b]Note:[/b] The Jiggle modifier has [code]jiggle_joints[/code], which are the data objects that hold the data for each joint in the Jiggle chain. This is different from than [Bone2D] nodes! Jiggle joints hold the data needed for each [Bone2D] in the bone chain used by the Jiggle modification.

## damping :: var SkeletonModification2DJiggle.damping: float
The default amount of damping applied to the Jiggle joints, if they are not overridden. Higher values lead to more of the calculated velocity being applied.

## gravity :: var SkeletonModification2DJiggle.gravity: Vector2
The default amount of gravity applied to the Jiggle joints, if they are not overridden.

## jiggle_data_chain_length :: var SkeletonModification2DJiggle.jiggle_data_chain_length: int
The amount of Jiggle joints in the Jiggle modification.

## mass :: var SkeletonModification2DJiggle.mass: float
The default amount of mass assigned to the Jiggle joints, if they are not overridden. Higher values lead to faster movements and more overshooting.

## stiffness :: var SkeletonModification2DJiggle.stiffness: float
The default amount of stiffness assigned to the Jiggle joints, if they are not overridden. Higher values act more like springs, quickly moving into the correct position.

## target_nodepath :: var SkeletonModification2DJiggle.target_nodepath: NodePath
The NodePath to the node that is the target for the Jiggle modification. This node is what the Jiggle chain will attempt to rotate the bone chain to.

## use_gravity :: var SkeletonModification2DJiggle.use_gravity: bool
Whether the gravity vector, [member gravity], should be applied to the Jiggle joints, assuming they are not overriding the default settings.

## get_collision_mask :: func SkeletonModification2DJiggle.get_collision_mask() -> int
Returns the collision mask used by the Jiggle modifier when collisions are enabled.

## get_jiggle_joint_bone2d_node :: func SkeletonModification2DJiggle.get_jiggle_joint_bone2d_node(joint_idx: int) -> NodePath
Returns the [Bone2D] node assigned to the Jiggle joint at [param joint_idx].

### joint_idx :: int

## get_jiggle_joint_bone_index :: func SkeletonModification2DJiggle.get_jiggle_joint_bone_index(joint_idx: int) -> int
Returns the index of the [Bone2D] node assigned to the Jiggle joint at [param joint_idx].

### joint_idx :: int

## get_jiggle_joint_damping :: func SkeletonModification2DJiggle.get_jiggle_joint_damping(joint_idx: int) -> float
Returns the amount of damping of the Jiggle joint at [param joint_idx].

### joint_idx :: int

## get_jiggle_joint_gravity :: func SkeletonModification2DJiggle.get_jiggle_joint_gravity(joint_idx: int) -> Vector2
Returns a [Vector2] representing the amount of gravity the Jiggle joint at [param joint_idx] is influenced by.

### joint_idx :: int

## get_jiggle_joint_mass :: func SkeletonModification2DJiggle.get_jiggle_joint_mass(joint_idx: int) -> float
Returns the amount of mass of the jiggle joint at [param joint_idx].

### joint_idx :: int

## get_jiggle_joint_override :: func SkeletonModification2DJiggle.get_jiggle_joint_override(joint_idx: int) -> bool
Returns a boolean that indicates whether the joint at [param joint_idx] is overriding the default Jiggle joint data defined in the modification.

### joint_idx :: int

## get_jiggle_joint_stiffness :: func SkeletonModification2DJiggle.get_jiggle_joint_stiffness(joint_idx: int) -> float
Returns the stiffness of the Jiggle joint at [param joint_idx].

### joint_idx :: int

## get_jiggle_joint_use_gravity :: func SkeletonModification2DJiggle.get_jiggle_joint_use_gravity(joint_idx: int) -> bool
Returns a boolean that indicates whether the joint at [param joint_idx] is using gravity or not.

### joint_idx :: int

## get_use_colliders :: func SkeletonModification2DJiggle.get_use_colliders() -> bool
Returns whether the jiggle modifier is taking physics colliders into account when solving.

## reset :: func SkeletonModification2DJiggle.reset() -> void
Resets the internal jiggle simulation state to the current bone positions, clearing velocity, acceleration, and accumulated forces.

## set_collision_mask :: func SkeletonModification2DJiggle.set_collision_mask(collision_mask: int) -> void
Sets the collision mask that the Jiggle modifier will use when reacting to colliders, if the Jiggle modifier is set to take colliders into account.

### collision_mask :: int

## set_jiggle_joint_bone2d_node :: func SkeletonModification2DJiggle.set_jiggle_joint_bone2d_node(joint_idx: int, bone2d_node: NodePath) -> void
Sets the [Bone2D] node assigned to the Jiggle joint at [param joint_idx].

### joint_idx :: int

### bone2d_node :: NodePath

## set_jiggle_joint_bone_index :: func SkeletonModification2DJiggle.set_jiggle_joint_bone_index(joint_idx: int, bone_idx: int) -> void
Sets the bone index, [param bone_idx], of the Jiggle joint at [param joint_idx]. When possible, this will also update the [code]bone2d_node[/code] of the Jiggle joint based on data provided by the linked skeleton.

### joint_idx :: int

### bone_idx :: int

## set_jiggle_joint_damping :: func SkeletonModification2DJiggle.set_jiggle_joint_damping(joint_idx: int, damping: float) -> void
Sets the amount of damping of the Jiggle joint at [param joint_idx].

### joint_idx :: int

### damping :: float

## set_jiggle_joint_gravity :: func SkeletonModification2DJiggle.set_jiggle_joint_gravity(joint_idx: int, gravity: Vector2) -> void
Sets the gravity vector of the Jiggle joint at [param joint_idx].

### joint_idx :: int

### gravity :: Vector2

## set_jiggle_joint_mass :: func SkeletonModification2DJiggle.set_jiggle_joint_mass(joint_idx: int, mass: float) -> void
Sets the of mass of the Jiggle joint at [param joint_idx].

### joint_idx :: int

### mass :: float

## set_jiggle_joint_override :: func SkeletonModification2DJiggle.set_jiggle_joint_override(joint_idx: int, override: bool) -> void
Sets whether the Jiggle joint at [param joint_idx] should override the default Jiggle joint settings. Setting this to [code]true[/code] will make the joint use its own settings rather than the default ones attached to the modification.

### joint_idx :: int

### override :: bool

## set_jiggle_joint_stiffness :: func SkeletonModification2DJiggle.set_jiggle_joint_stiffness(joint_idx: int, stiffness: float) -> void
Sets the of stiffness of the Jiggle joint at [param joint_idx].

### joint_idx :: int

### stiffness :: float

## set_jiggle_joint_use_gravity :: func SkeletonModification2DJiggle.set_jiggle_joint_use_gravity(joint_idx: int, use_gravity: bool) -> void
Sets whether the Jiggle joint at [param joint_idx] should use gravity.

### joint_idx :: int

### use_gravity :: bool

## set_use_colliders :: func SkeletonModification2DJiggle.set_use_colliders(use_colliders: bool) -> void
If [code]true[/code], the Jiggle modifier will take colliders into account, keeping them from entering into these collision objects.

### use_colliders :: bool
