# SpinBox :: <Native> class SpinBox extends Range
An input field for numbers.
[SpinBox] is a numerical input text field. It allows entering integers and floating-point numbers. The [SpinBox] also has up and down buttons that can be clicked to increase or decrease the value. The value can also be changed by dragging the mouse up or down over the [SpinBox]'s arrows.
Additionally, mathematical expressions can be entered. These are evaluated when the user presses [kbd]Enter[/kbd] while editing the [SpinBox]'s text field. This uses the [Expression] class to parse and evaluate the expression. The result of the expression is then set as the value of the [SpinBox]. Some examples of valid expressions are [code]5 + 2 * 3[/code], [code]pow(2, 4)[/code], and [code]PI + sin(0.5)[/code]. Expressions are case-sensitive.
[b]Example:[/b] Create a [SpinBox], disable its context menu and set its text alignment to right.
[codeblocks]
[gdscript]
var spin_box = SpinBox.new()
add_child(spin_box)
var line_edit = spin_box.get_line_edit()
line_edit.context_menu_enabled = false
spin_box.horizontal_alignment = LineEdit.HORIZONTAL_ALIGNMENT_RIGHT
[/gdscript]
[csharp]
var spinBox = new SpinBox();
AddChild(spinBox);
var lineEdit = spinBox.GetLineEdit();
lineEdit.ContextMenuEnabled = false;
spinBox.AlignHorizontal = LineEdit.HorizontalAlignEnum.Right;
[/csharp]
[/codeblocks]
See [Range] class for more options over the [SpinBox].
[b]Note:[/b] With the [SpinBox]'s context menu disabled, you can right-click the bottom half of the spinbox to set the value to its minimum, while right-clicking the top half sets the value to its maximum.
[b]Note:[/b] [SpinBox] relies on an underlying [LineEdit] node. To theme a [SpinBox]'s background, add theme items for [LineEdit] and customize them. The [LineEdit] has the [code]SpinBoxInnerLineEdit[/code] theme variation, so that you can give it a distinct appearance from regular [LineEdit]s.
[b]Note:[/b] If you want to implement drag and drop for the underlying [LineEdit], you can use [method Control.set_drag_forwarding] on the node returned by [method get_line_edit].

## alignment :: var SpinBox.alignment: HorizontalAlignment
Changes the alignment of the underlying [LineEdit].

## custom_arrow_round :: var SpinBox.custom_arrow_round: bool
If [code]true[/code], the value will be rounded to a multiple of [member custom_arrow_step] when interacting with the arrow buttons. Otherwise, increments the value by [member custom_arrow_step] and then rounds it according to [member Range.step].

## custom_arrow_step :: var SpinBox.custom_arrow_step: float
If not [code]0[/code], sets the step when interacting with the arrow buttons of the [SpinBox].
[b]Note:[/b] [member Range.value] will still be rounded to a multiple of [member Range.step].

## editable :: var SpinBox.editable: bool
If [code]true[/code], the [SpinBox] will be editable. Otherwise, it will be read only.

## prefix :: var SpinBox.prefix: String
Adds the specified prefix string before the numerical value of the [SpinBox].

## select_all_on_focus :: var SpinBox.select_all_on_focus: bool
If [code]true[/code], the [SpinBox] will select the whole text when the [LineEdit] gains focus. Clicking the up and down arrows won't trigger this behavior.

## size_flags_vertical :: var SpinBox.size_flags_vertical: Control.SizeFlags

## step :: var SpinBox.step: float

## suffix :: var SpinBox.suffix: String
Adds the specified suffix string after the numerical value of the [SpinBox].

## update_on_text_changed :: var SpinBox.update_on_text_changed: bool
Sets the value of the [Range] for this [SpinBox] when the [LineEdit] text is [i]changed[/i] instead of [i]submitted[/i]. See [signal LineEdit.text_changed] and [signal LineEdit.text_submitted].
[b]Note:[/b] If set to [code]true[/code], this will interfere with entering mathematical expressions in the [SpinBox]. The [SpinBox] will try to evaluate the expression as you type, which means symbols like a trailing [code]+[/code] are removed immediately by the expression being evaluated.

## down_disabled_icon_modulate :: <Theme> var SpinBox.down_disabled_icon_modulate: Color
Down button icon modulation color, when the button is disabled.

## down_hover_icon_modulate :: <Theme> var SpinBox.down_hover_icon_modulate: Color
Down button icon modulation color, when the button is hovered.

## down_icon_modulate :: <Theme> var SpinBox.down_icon_modulate: Color
Down button icon modulation color.

## down_pressed_icon_modulate :: <Theme> var SpinBox.down_pressed_icon_modulate: Color
Down button icon modulation color, when the button is being pressed.

## up_disabled_icon_modulate :: <Theme> var SpinBox.up_disabled_icon_modulate: Color
Up button icon modulation color, when the button is disabled.

## up_hover_icon_modulate :: <Theme> var SpinBox.up_hover_icon_modulate: Color
Up button icon modulation color, when the button is hovered.

## up_icon_modulate :: <Theme> var SpinBox.up_icon_modulate: Color
Up button icon modulation color.

## up_pressed_icon_modulate :: <Theme> var SpinBox.up_pressed_icon_modulate: Color
Up button icon modulation color, when the button is being pressed.

## buttons_vertical_separation :: <Theme> var SpinBox.buttons_vertical_separation: int
Vertical separation between the up and down buttons.

## buttons_width :: <Theme> var SpinBox.buttons_width: int
Width of the up and down buttons. If smaller than any icon set on the buttons, the respective icon may overlap neighboring elements. If smaller than [code]0[/code], the width is automatically adjusted from the icon size.

## field_and_buttons_separation :: <Theme> var SpinBox.field_and_buttons_separation: int
Width of the horizontal separation between the text input field ([LineEdit]) and the buttons.

## set_min_buttons_width_from_icons :: <Theme> var SpinBox.set_min_buttons_width_from_icons: int
If not [code]0[/code], the minimum button width corresponds to the widest of all icons set on those buttons, even if [theme_item buttons_width] is smaller.

## down :: <Theme> var SpinBox.down: Texture2D
Down button icon, displayed in the middle of the down (value-decreasing) button.

## down_disabled :: <Theme> var SpinBox.down_disabled: Texture2D
Down button icon when the button is disabled.

## down_hover :: <Theme> var SpinBox.down_hover: Texture2D
Down button icon when the button is hovered.

## down_pressed :: <Theme> var SpinBox.down_pressed: Texture2D
Down button icon when the button is being pressed.

## up :: <Theme> var SpinBox.up: Texture2D
Up button icon, displayed in the middle of the up (value-increasing) button.

## up_disabled :: <Theme> var SpinBox.up_disabled: Texture2D
Up button icon when the button is disabled.

## up_hover :: <Theme> var SpinBox.up_hover: Texture2D
Up button icon when the button is hovered.

## up_pressed :: <Theme> var SpinBox.up_pressed: Texture2D
Up button icon when the button is being pressed.

## updown :: <Theme> var SpinBox.updown: Texture2D
Single texture representing both the up and down buttons icons. It is displayed in the middle of the buttons and does not change upon interaction. If a valid icon is assigned, it will replace [theme_item up] and [theme_item down].

## down_background :: <Theme> var SpinBox.down_background: StyleBox
Background style of the down button.

## down_background_disabled :: <Theme> var SpinBox.down_background_disabled: StyleBox
Background style of the down button when disabled.

## down_background_hovered :: <Theme> var SpinBox.down_background_hovered: StyleBox
Background style of the down button when hovered.

## down_background_pressed :: <Theme> var SpinBox.down_background_pressed: StyleBox
Background style of the down button when being pressed.

## field_and_buttons_separator :: <Theme> var SpinBox.field_and_buttons_separator: StyleBox
[StyleBox] drawn in the space occupied by the separation between the input field and the buttons.

## up_background :: <Theme> var SpinBox.up_background: StyleBox
Background style of the up button.

## up_background_disabled :: <Theme> var SpinBox.up_background_disabled: StyleBox
Background style of the up button when disabled.

## up_background_hovered :: <Theme> var SpinBox.up_background_hovered: StyleBox
Background style of the up button when hovered.

## up_background_pressed :: <Theme> var SpinBox.up_background_pressed: StyleBox
Background style of the up button when being pressed.

## up_down_buttons_separator :: <Theme> var SpinBox.up_down_buttons_separator: StyleBox
[StyleBox] drawn in the space occupied by the separation between the up and down buttons.

## apply :: func SpinBox.apply() -> void
Applies the current value of this [SpinBox]. This is equivalent to pressing [kbd]Enter[/kbd] while editing the [LineEdit] used by the [SpinBox]. This will cause [signal LineEdit.text_submitted] to be emitted and its currently contained expression to be evaluated.

## get_line_edit :: func SpinBox.get_line_edit() -> LineEdit
Returns the [LineEdit] instance from this [SpinBox]. You can use it to access properties and methods of [LineEdit].
[b]Warning:[/b] This is a required internal node, removing and freeing it may cause a crash. If you wish to hide it or any of its children, use their [member CanvasItem.visible] property.
