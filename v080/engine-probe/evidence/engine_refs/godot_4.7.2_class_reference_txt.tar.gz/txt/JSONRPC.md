# JSONRPC :: <Native> class JSONRPC extends Object
A helper to handle dictionaries which look like JSONRPC documents.
[url=https://www.jsonrpc.org/]JSON-RPC[/url] is a standard which wraps a method call in a [JSON] object. The object has a particular structure and identifies which method is called, the parameters to that function, and carries an ID to keep track of responses. This class implements that standard on top of [Dictionary]; you will have to convert between a [Dictionary] and [JSON] with other functions.

## PARSE_ERROR :: const JSONRPC.PARSE_ERROR: ErrorCode = -32700
The request could not be parsed as it was not valid by JSON standard ([method JSON.parse] failed).

## INVALID_REQUEST :: const JSONRPC.INVALID_REQUEST: ErrorCode = -32600
A method call was requested but the request's format is not valid.

## METHOD_NOT_FOUND :: const JSONRPC.METHOD_NOT_FOUND: ErrorCode = -32601
A method call was requested but no function of that name existed in the JSONRPC subclass.

## INVALID_PARAMS :: const JSONRPC.INVALID_PARAMS: ErrorCode = -32602
A method call was requested but the given method parameters are not valid. Not used by the built-in JSONRPC.

## INTERNAL_ERROR :: const JSONRPC.INTERNAL_ERROR: ErrorCode = -32603
An internal error occurred while processing the request. Not used by the built-in JSONRPC.

## make_notification :: func JSONRPC.make_notification(method: String, params: Variant) -> Dictionary
Returns a dictionary in the form of a JSON-RPC notification. Notifications are one-shot messages which do not expect a response.
- [param method]: Name of the method being called.
- [param params]: An array or dictionary of parameters being passed to the method.

### method :: String

### params :: Variant

## make_request :: func JSONRPC.make_request(method: String, params: Variant, id: Variant) -> Dictionary
Returns a dictionary in the form of a JSON-RPC request. Requests are sent to a server with the expectation of a response. The ID field is used for the server to specify which exact request it is responding to.
- [param method]: Name of the method being called.
- [param params]: An array or dictionary of parameters being passed to the method.
- [param id]: Uniquely identifies this request. The server is expected to send a response with the same ID.

### method :: String

### params :: Variant

### id :: Variant

## make_response :: func JSONRPC.make_response(result: Variant, id: Variant) -> Dictionary
When a server has received and processed a request, it is expected to send a response. If you did not want a response then you need to have sent a Notification instead.
- [param result]: The return value of the function which was called.
- [param id]: The ID of the request this response is targeted to.

### result :: Variant

### id :: Variant

## make_response_error :: func JSONRPC.make_response_error(code: int, message: String, id: Variant = null) -> Dictionary
Creates a response which indicates a previous reply has failed in some way.
- [param code]: The error code corresponding to what kind of error this is. See the [enum ErrorCode] constants.
- [param message]: A custom message about this error.
- [param id]: The request this error is a response to.

### code :: int

### message :: String

### id :: Variant

## process_action :: func JSONRPC.process_action(action: Variant, recurse: bool = false) -> Variant
Given a Dictionary which takes the form of a JSON-RPC request: unpack the request and run it. Methods are resolved by looking at the field called "method" and looking for an equivalently named function in the JSONRPC object. If one is found that method is called.
To add new supported methods extend the JSONRPC class and call [method process_action] on your subclass.
[param action]: The action to be run, as a Dictionary in the form of a JSON-RPC request or notification.

### action :: Variant

### recurse :: bool

## process_string :: func JSONRPC.process_string(action: String) -> String

### action :: String

## set_method :: func JSONRPC.set_method(name: String, callback: Callable) -> void
Registers a callback for the given method name.
- [param name]: The name that clients can use to access the callback.
- [param callback]: The callback which will handle the specified method.

### name :: String

### callback :: Callable
