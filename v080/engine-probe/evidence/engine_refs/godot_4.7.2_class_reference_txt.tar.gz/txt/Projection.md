# Projection :: <Native> class Projection
A 4×4 matrix for 3D projective transformations.
A 4×4 matrix used for 3D projective transformations. It can represent transformations such as translation, rotation, scaling, shearing, and perspective division. It consists of four [Vector4] columns.
For purely linear transformations (translation, rotation, and scale), it is recommended to use [Transform3D], as it is more performant and requires less memory.
Used internally as [Camera3D]'s projection matrix.
[b]Note:[/b] In a boolean context, a projection will evaluate to [code]false[/code] if it's equal to [constant IDENTITY]. Otherwise, a projection will always evaluate to [code]true[/code].

## PLANE_NEAR :: const Projection.PLANE_NEAR: Planes = 0
The index value of the projection's near clipping plane.

## PLANE_FAR :: const Projection.PLANE_FAR: Planes = 1
The index value of the projection's far clipping plane.

## PLANE_LEFT :: const Projection.PLANE_LEFT: Planes = 2
The index value of the projection's left clipping plane.

## PLANE_TOP :: const Projection.PLANE_TOP: Planes = 3
The index value of the projection's top clipping plane.

## PLANE_RIGHT :: const Projection.PLANE_RIGHT: Planes = 4
The index value of the projection's right clipping plane.

## PLANE_BOTTOM :: const Projection.PLANE_BOTTOM: Planes = 5
The index value of the projection bottom clipping plane.

## IDENTITY :: const Projection.IDENTITY = Projection(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
A [Projection] with no transformation defined. When applied to other data structures, no transformation is performed.

## ZERO :: const Projection.ZERO = Projection(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
A [Projection] with all values initialized to 0. When applied to other data structures, they will be zeroed.

## w :: var Projection.w: Vector4
The projection matrix's W vector (column 3). Equivalent to array index [code]3[/code].

## x :: var Projection.x: Vector4
The projection matrix's X vector (column 0). Equivalent to array index [code]0[/code].

## y :: var Projection.y: Vector4
The projection matrix's Y vector (column 1). Equivalent to array index [code]1[/code].

## z :: var Projection.z: Vector4
The projection matrix's Z vector (column 2). Equivalent to array index [code]2[/code].

## create_depth_correction :: func Projection.create_depth_correction(flip_y: bool) -> Projection
Creates a new [Projection] that projects positions from a depth range of [code]-1[/code] to [code]1[/code] to one that ranges from [code]0[/code] to [code]1[/code], and flips the projected positions vertically, according to [param flip_y].

### flip_y :: bool

## create_fit_aabb :: func Projection.create_fit_aabb(aabb: AABB) -> Projection
Creates a new [Projection] that scales a given projection to fit around a given [AABB] in projection space.

### aabb :: AABB

## create_for_hmd :: func Projection.create_for_hmd(eye: int, aspect: float, intraocular_dist: float, display_width: float, display_to_lens: float, oversample: float, z_near: float, z_far: float) -> Projection
Creates a new [Projection] for projecting positions onto a head-mounted display with the given X:Y aspect ratio, distance between eyes, display width, distance to lens, oversampling factor, and depth clipping planes.
[param eye] creates the projection for the left eye when set to 1, or the right eye when set to 2.

### eye :: int

### aspect :: float

### intraocular_dist :: float

### display_width :: float

### display_to_lens :: float

### oversample :: float

### z_near :: float

### z_far :: float

## create_frustum :: func Projection.create_frustum(left: float, right: float, bottom: float, top: float, z_near: float, z_far: float) -> Projection
Creates a new [Projection] that projects positions in a frustum with the given clipping planes.

### left :: float

### right :: float

### bottom :: float

### top :: float

### z_near :: float

### z_far :: float

## create_frustum_aspect :: func Projection.create_frustum_aspect(size: float, aspect: float, offset: Vector2, z_near: float, z_far: float, flip_fov: bool = false) -> Projection
Creates a new [Projection] that projects positions in a frustum with the given size, X:Y aspect ratio, offset, and clipping planes.
[param flip_fov] determines whether the projection's field of view is flipped over its diagonal.

### size :: float

### aspect :: float

### offset :: Vector2

### z_near :: float

### z_far :: float

### flip_fov :: bool

## create_light_atlas_rect :: func Projection.create_light_atlas_rect(rect: Rect2) -> Projection
Creates a new [Projection] that projects positions into the given [Rect2].

### rect :: Rect2

## create_orthogonal :: func Projection.create_orthogonal(left: float, right: float, bottom: float, top: float, z_near: float, z_far: float) -> Projection
Creates a new [Projection] that projects positions using an orthogonal projection with the given clipping planes.

### left :: float

### right :: float

### bottom :: float

### top :: float

### z_near :: float

### z_far :: float

## create_orthogonal_aspect :: func Projection.create_orthogonal_aspect(size: float, aspect: float, z_near: float, z_far: float, flip_fov: bool = false) -> Projection
Creates a new [Projection] that projects positions using an orthogonal projection with the given size, X:Y aspect ratio, and clipping planes.
[param flip_fov] determines whether the projection's field of view is flipped over its diagonal.

### size :: float

### aspect :: float

### z_near :: float

### z_far :: float

### flip_fov :: bool

## create_perspective :: func Projection.create_perspective(fovy: float, aspect: float, z_near: float, z_far: float, flip_fov: bool = false) -> Projection
Creates a new [Projection] that projects positions using a perspective projection with the given Y-axis field of view (in degrees), X:Y aspect ratio, and clipping planes.
[param flip_fov] determines whether the projection's field of view is flipped over its diagonal.

### fovy :: float

### aspect :: float

### z_near :: float

### z_far :: float

### flip_fov :: bool

## create_perspective_hmd :: func Projection.create_perspective_hmd(fovy: float, aspect: float, z_near: float, z_far: float, flip_fov: bool, eye: int, intraocular_dist: float, convergence_dist: float) -> Projection
Creates a new [Projection] that projects positions using a perspective projection with the given Y-axis field of view (in degrees), X:Y aspect ratio, and clipping distances. The projection is adjusted for a head-mounted display with the given distance between eyes and distance to a point that can be focused on.
[param eye] creates the projection for the left eye when set to 1, or the right eye when set to 2.
[param flip_fov] determines whether the projection's field of view is flipped over its diagonal.

### fovy :: float

### aspect :: float

### z_near :: float

### z_far :: float

### flip_fov :: bool

### eye :: int

### intraocular_dist :: float

### convergence_dist :: float

## determinant :: func Projection.determinant() -> float
Returns a scalar value that is the signed factor by which areas are scaled by this matrix. If the sign is negative, the matrix flips the orientation of the area.
The determinant can be used to calculate the invertibility of a matrix or solve linear systems of equations involving the matrix, among other applications.

## flipped_y :: func Projection.flipped_y() -> Projection
Returns a copy of this [Projection] with the signs of the values of the Y column flipped.

## get_aspect :: func Projection.get_aspect() -> float
Returns the X:Y aspect ratio of this [Projection]'s viewport.

## get_far_plane_half_extents :: func Projection.get_far_plane_half_extents() -> Vector2
Returns the dimensions of the far clipping plane of the projection, divided by two.

## get_fov :: func Projection.get_fov() -> float
Returns the horizontal field of view of the projection (in degrees).

## get_fovy :: func Projection.get_fovy(fovx: float, aspect: float) -> float
Returns the vertical field of view of the projection (in degrees) associated with the given horizontal field of view (in degrees) and aspect ratio.
[b]Note:[/b] Unlike most methods of [Projection], [param aspect] is expected to be 1 divided by the X:Y aspect ratio.

### fovx :: float

### aspect :: float

## get_lod_multiplier :: func Projection.get_lod_multiplier() -> float
Returns the factor by which the visible level of detail is scaled by this [Projection].

## get_pixels_per_meter :: func Projection.get_pixels_per_meter(for_pixel_width: int) -> int
Returns [param for_pixel_width] divided by the viewport's width measured in meters on the near plane, after this [Projection] is applied.

### for_pixel_width :: int

## get_projection_plane :: func Projection.get_projection_plane(plane: int) -> Plane
Returns the clipping plane of this [Projection] whose index is given by [param plane].
[param plane] should be equal to one of [constant PLANE_NEAR], [constant PLANE_FAR], [constant PLANE_LEFT], [constant PLANE_TOP], [constant PLANE_RIGHT], or [constant PLANE_BOTTOM].

### plane :: int

## get_viewport_half_extents :: func Projection.get_viewport_half_extents() -> Vector2
Returns the dimensions of the viewport plane that this [Projection] projects positions onto, divided by two.

## get_z_far :: func Projection.get_z_far() -> float
Returns the distance for this [Projection] beyond which positions are clipped.

## get_z_near :: func Projection.get_z_near() -> float
Returns the distance for this [Projection] before which positions are clipped.

## inverse :: func Projection.inverse() -> Projection
Returns a [Projection] that performs the inverse of this [Projection]'s projective transformation.

## is_orthogonal :: func Projection.is_orthogonal() -> bool
Returns [code]true[/code] if this [Projection] performs an orthogonal projection.

## jitter_offseted :: func Projection.jitter_offseted(offset: Vector2) -> Projection
Returns a [Projection] with the X and Y values from the given [Vector2] added to the first and second values of the final column respectively.

### offset :: Vector2

## perspective_znear_adjusted :: func Projection.perspective_znear_adjusted(new_znear: float) -> Projection
Returns a [Projection] with the near clipping distance adjusted to be [param new_znear].
[b]Note:[/b] The original [Projection] must be a perspective projection.

### new_znear :: float

## Projection :: func Projection.Projection() -> Projection
Constructs a default-initialized [Projection] identical to [constant IDENTITY].
[b]Note:[/b] In C#, this constructs a [Projection] identical to [constant ZERO].

## Projection :: func Projection.Projection(from: Projection) -> Projection
Constructs a [Projection] as a copy of the given [Projection].

### from :: Projection

## Projection :: func Projection.Projection(from: Transform3D) -> Projection
Constructs a Projection as a copy of the given [Transform3D].

### from :: Transform3D

## Projection :: func Projection.Projection(x_axis: Vector4, y_axis: Vector4, z_axis: Vector4, w_axis: Vector4) -> Projection
Constructs a Projection from four [Vector4] values (matrix columns).

### x_axis :: Vector4

### y_axis :: Vector4

### z_axis :: Vector4

### w_axis :: Vector4

## operator != :: func Projection.operator !=(right: Projection) -> bool
Returns [code]true[/code] if the projections are not equal.
[b]Note:[/b] Due to floating-point precision errors, this may return [code]true[/code], even if the projections are virtually equal. An [code]is_equal_approx[/code] method may be added in a future version of Godot.

### right :: Projection

## operator * :: func Projection.operator *(right: Projection) -> Projection
Returns a [Projection] that applies the combined transformations of this [Projection] and [param right].

### right :: Projection

## operator * :: func Projection.operator *(right: Vector4) -> Vector4
Projects (multiplies) the given [Vector4] by this [Projection] matrix.

### right :: Vector4

## operator == :: func Projection.operator ==(right: Projection) -> bool
Returns [code]true[/code] if the projections are equal.
[b]Note:[/b] Due to floating-point precision errors, this may return [code]false[/code], even if the projections are virtually equal. An [code]is_equal_approx[/code] method may be added in a future version of Godot.

### right :: Projection

## operator [] :: func Projection.operator [](index: int) -> Vector4
Returns the column of the [Projection] with the given index.
Indices are in the following order: x, y, z, w.

### index :: int
