# GLTFMesh :: <Native> class GLTFMesh extends Resource
GLTFMesh represents a glTF mesh.
GLTFMesh handles 3D mesh data imported from glTF files. It includes properties for blend channels, blend weights, instance materials, and the mesh itself.

## blend_weights :: var GLTFMesh.blend_weights: PackedFloat32Array
An array of floats representing the blend weights of the mesh.

## instance_materials :: var GLTFMesh.instance_materials: Material[]
An array of Material objects representing the materials used in the mesh.

## mesh :: var GLTFMesh.mesh: ImporterMesh
The [ImporterMesh] object representing the mesh itself.

## original_name :: var GLTFMesh.original_name: String
The original name of the mesh.

## get_additional_data :: func GLTFMesh.get_additional_data(extension_name: StringName) -> Variant
Gets additional arbitrary data in this [GLTFMesh] instance. This can be used to keep per-node state data in [GLTFDocumentExtension] classes, which is important because they are stateless.
The argument should be the [GLTFDocumentExtension] name (does not have to match the extension name in the glTF file), and the return value can be anything you set. If nothing was set, the return value is [code]null[/code].

### extension_name :: StringName

## set_additional_data :: func GLTFMesh.set_additional_data(extension_name: StringName, additional_data: Variant) -> void
Sets additional arbitrary data in this [GLTFMesh] instance. This can be used to keep per-node state data in [GLTFDocumentExtension] classes, which is important because they are stateless.
The first argument should be the [GLTFDocumentExtension] name (does not have to match the extension name in the glTF file), and the second argument can be anything you want.

### extension_name :: StringName

### additional_data :: Variant
