# CameraFeed :: <Native> class CameraFeed extends RefCounted
A camera feed gives you access to a single physical camera attached to your device.
A camera feed gives you access to a single physical camera attached to your device. When enabled, Godot will start capturing frames from the camera which can then be used. See also [CameraServer].
[b]Note:[/b] Many cameras will return YCbCr images which are split into two textures and need to be combined in a shader. Godot does this automatically for you if you set the environment to show the camera image in the background.
[b]Note:[/b] This class is currently only implemented on Linux, Android, macOS, and iOS. On other platforms no [CameraFeed]s will be available. To get a [CameraFeed] on iOS, enable [member EditorExportPlatformIOS.modules/camera].

## FEED_NOIMAGE :: const CameraFeed.FEED_NOIMAGE: FeedDataType = 0
No image set for the feed.

## FEED_RGB :: const CameraFeed.FEED_RGB: FeedDataType = 1
Feed supplies RGB images.

## FEED_YCBCR :: const CameraFeed.FEED_YCBCR: FeedDataType = 2
Feed supplies YCbCr images that need to be converted to RGB.

## FEED_YCBCR_SEP :: const CameraFeed.FEED_YCBCR_SEP: FeedDataType = 3
Feed supplies separate Y and CbCr images that need to be combined and converted to RGB.

## FEED_EXTERNAL :: const CameraFeed.FEED_EXTERNAL: FeedDataType = 4
Feed supplies external image.

## FEED_UNSPECIFIED :: const CameraFeed.FEED_UNSPECIFIED: FeedPosition = 0
Unspecified position.

## FEED_FRONT :: const CameraFeed.FEED_FRONT: FeedPosition = 1
Camera is mounted at the front of the device.

## FEED_BACK :: const CameraFeed.FEED_BACK: FeedPosition = 2
Camera is mounted at the back of the device.

## feed_is_active :: var CameraFeed.feed_is_active: bool
If [code]true[/code], the feed is active.

## feed_transform :: var CameraFeed.feed_transform: Transform2D
The transform applied to the camera's image.

## formats :: var CameraFeed.formats: Array
Formats supported by the feed. Each entry is a [Dictionary] describing format parameters.

## _activate_feed :: func CameraFeed._activate_feed() -> bool
Called when the camera feed is activated.

## _deactivate_feed :: func CameraFeed._deactivate_feed() -> void
Called when the camera feed is deactivated.

## _get_formats :: func CameraFeed._get_formats() -> Array
Override this method to define supported formats of the camera feed.

## _set_format :: func CameraFeed._set_format(index: int, parameters: Dictionary) -> bool
Override this method to set the format of the camera feed.

### index :: int

### parameters :: Dictionary

## get_datatype :: func CameraFeed.get_datatype() -> int
Returns feed image data type.

## get_id :: func CameraFeed.get_id() -> int
Returns the unique ID for this feed.

## get_name :: func CameraFeed.get_name() -> String
Returns the camera's name.

## get_position :: func CameraFeed.get_position() -> int
Returns the position of camera on the device.

## get_texture_tex_id :: func CameraFeed.get_texture_tex_id(feed_image_type: int) -> int
Returns the texture backend ID (usable by some external libraries that need a handle to a texture to write data).

### feed_image_type :: int

## set_external :: func CameraFeed.set_external(width: int, height: int) -> void
Sets the feed as external feed provided by another library.

### width :: int

### height :: int

## set_format :: func CameraFeed.set_format(index: int, parameters: Dictionary) -> bool
Sets the feed format parameters for the given [param index] in the [member formats] array. Returns [code]true[/code] on success. By default, the YUYV encoded stream is transformed to [constant FEED_RGB]. The YUYV encoded stream output format can be changed by setting [param parameters]'s [code]output[/code] entry to one of the following:
- [code]"separate"[/code] will result in [constant FEED_YCBCR_SEP];
- [code]"grayscale"[/code] will result in desaturated [constant FEED_RGB];
- [code]"copy"[/code] will result in [constant FEED_YCBCR].

### index :: int

### parameters :: Dictionary

## set_name :: func CameraFeed.set_name(name: String) -> void
Sets the camera's name.

### name :: String

## set_position :: func CameraFeed.set_position(position: int) -> void
Sets the position of this camera.

### position :: int

## set_rgb_image :: func CameraFeed.set_rgb_image(rgb_image: Image) -> void
Sets RGB image for this feed.

### rgb_image :: Image

## set_ycbcr_image :: func CameraFeed.set_ycbcr_image(ycbcr_image: Image) -> void
Sets YCbCr image for this feed.

### ycbcr_image :: Image

## set_ycbcr_images :: func CameraFeed.set_ycbcr_images(y_image: Image, cbcr_image: Image) -> void
Sets Y and CbCr images for this feed.

### y_image :: Image

### cbcr_image :: Image

## format_changed :: func CameraFeed.format_changed() -> void
Emitted when the format has changed.

## frame_changed :: func CameraFeed.frame_changed() -> void
Emitted when a new frame is available.
