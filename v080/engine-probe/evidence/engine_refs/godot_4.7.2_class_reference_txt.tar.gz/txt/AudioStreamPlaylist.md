# AudioStreamPlaylist :: <Native> class AudioStreamPlaylist extends AudioStream
[AudioStream] that includes sub-streams and plays them back like a playlist.
An audio stream that can play back sub-streams in sequence. Streams can be added to the Playlist with [method set_list_stream], and shuffled with [member shuffle].

## MAX_STREAMS :: const AudioStreamPlaylist.MAX_STREAMS = 64
Maximum amount of streams supported in the playlist.

## fade_time :: var AudioStreamPlaylist.fade_time: float
Fade time used when a stream ends, when going to the next one. Streams are expected to have an extra bit of audio after the end to help with fading.

## loop :: var AudioStreamPlaylist.loop: bool
If [code]true[/code], the playlist will loop, otherwise the playlist will end when the last stream is finished.

## shuffle :: var AudioStreamPlaylist.shuffle: bool
If [code]true[/code], the playlist will shuffle each time playback starts and each time it loops.

## stream_count :: var AudioStreamPlaylist.stream_count: int
Amount of streams in the playlist.

## get_bpm :: func AudioStreamPlaylist.get_bpm() -> float
Returns the BPM of the playlist, which can vary depending on the clip being played.

## get_list_stream :: func AudioStreamPlaylist.get_list_stream(stream_index: int) -> AudioStream
Returns the stream at playback position index.

### stream_index :: int

## set_list_stream :: func AudioStreamPlaylist.set_list_stream(stream_index: int, audio_stream: AudioStream) -> void
Sets the stream at playback position index.

### stream_index :: int

### audio_stream :: AudioStream
